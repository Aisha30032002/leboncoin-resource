! function() {
    var a;
    const b = function(a, ...b) {
            var d = document.location.search.substring(1),
                e = /adomiktag_debug/i.test(d);
            e ? console.log(`%cADOMIKTAG`, "color: white; border: solid 1px black; background-color: #302a67; padding: 3px;", `${a}`, ...b) : void 0
        },
        d = ["timeout", "bidders", "modules"],
        e = {
            timeout: "adm_abtest_timeout",
            modules: "adm_abtest_modules",
            bidders: "adm_abtest_bidders"
        };
    Object.defineProperty(adomiktag.que, "push", {
        value: function() {
            for (var a = 0, b = this.length, d = arguments.length; a < d; a++, b++) f.getFuncsFromQueArray(this, b, this[b] = arguments[a])
        }
    });
    const f = {
        data: {},
        storage: function(a) {
            var b, d;
            return d = a && "session" === a ? window.sessionStorage : window.localStorage, b = {
                stock: {},
                set: function(a, b) {
                    this.stock = b ? JSON.stringify(b) : {};
                    try {
                        if (d) d.setItem(a, this.stock);
                        else return ""
                    } catch (a) {}
                },
                get: function(a) {
                    var b;
                    return d ? (b = a ? d.getItem(a) : "[]", b ? (b = JSON.parse(b), b) : "") : ""
                },
                delete: function(a) {
                    d && d.removeItem(a)
                }
            }, b
        },
        prebid: {
            eventsList: ["addAdUnits", "bidRequested", "requestBids", "beforeBidderHttp", "beforeRequestBids", "auctionInit", "auctionEnd", "bidResponse", "bidWon", "bidTimeout", "bidderError", "bidderDone", "adRenderSucceeded", "adRenderFailed"],
            methods: {
                filterBids: function a(b, d) {
                    function e(b, e, f) {
                        var g = new RegExp("^(" + d.join("|") + ")$", "i");
                        "exclude" in a.filteredBidders && a.filteredBidders.exclude ? g.test(b) && (a.filteredBidders.bids.push({
                            code: a.currentElement.code,
                            bidder: b
                        }), f[e] = {}) : !g.test(b) && (a.filteredBidders.bids.push({
                            code: a.currentElement.code,
                            bidder: b
                        }), f[e] = {})
                    }
                    if (!a.filteredBidders) {
                        var f = adomiktag._.get("abtests") ? adomiktag._.get("abtests").get("bidders") : void 0;
                        if (f) var [{
                            exclude: g
                        }] = f;
                        a.filteredBidders = {
                            exclude: g,
                            bids: []
                        }
                    }
                    return "undefined" == typeof d ? b : (b.forEach((f, g) => {
                        for (var h in f)
                            if (f.hasOwnProperty(h)) {
                                if (Array.isArray(f[h])) return a.currentElement = f, a(f[h], d);
                                "bidder" === h && e(f.bidder, g, b)
                            }
                    }), adomiktag._.set("filteredBidders", a.filteredBidders), {
                        filteredBidders: a.filteredBidders
                    })
                }
            },
            init: function(a) {
                b("Prebid Init", a);
                var d = "adUnits" in a ? a.adUnits : this.pbjs.adUnits;
                a && adomiktag._.get("timeout") && (b("Changing Timeout"), a.timeout = adomiktag._.get("timeout")), adomiktag._.get("bidders") && Array.isArray(adomiktag._.get("bidders")) && 0 < adomiktag._.get("bidders").length && (b("Filtering Bids..."), this.methods.filterBids(d, adomiktag._.get("bidders"))), adomiktag._.get("filteredBidders") && b("Filtered Bidders", adomiktag._.get("filteredBidders"))
            },
            events: function a() {
                if (!a.called) {
                    var d, e = this.pbsjs,
                        f = _pbjsGlobals;
                    if (d = e ? e.onEvent : void 0, d)
                        for (let a, b = 0; b < this.eventsList.length; b++) a = this.eventsList[b], e.onEvent(a, b => {
                            this.run(a, b)
                        });
                    else {
                        if ("undefined" == typeof f || 0 === f.length) return;
                        for (let a = 0; a < f.length; a++)
                            if (e = f[a], e = window[e], e && e.onEvent)
                                for (let a, b = 0; b < this.eventsList.length; b++) a = this.eventsList[b], e.onEvent(a, b => {
                                    this.run(a, b)
                                })
                    }
                    a.called = !0, b("Prebid Events")
                }
            },
            run: async function(a, d) {
                b(a, d)
            }
        },
        gam: {
            conf: function() {
                "undefined" != typeof googletag && googletag.cmd && (googletag.cmd.push(this.setKeyvalues.bind(null)), googletag.cmd.push(f.ga.conf))
            },
            setKeyvalues: function() {
                function a(a, b) {
                    return Array.isArray(b) ? adomiktag.utils.indexOfForArrays(a, b) : (b += "", a.findIndex(a => (a += "", a === b)))
                }

                function f(a, b) {
                    var d, e = adomiktag._.get("targeting"),
                        f = e && e.value ? e.value : null,
                        g = f && f[b] ? f[b] : void 0;
                    return Array.isArray(g) && 0 < g.length && (d = g[a]), d
                }
                var h = adomiktag._.get("abtests");
                for (var i of d) {
                    var j = e[i],
                        k = h.get(i);
                    if ("undefined" != typeof k) {
                        var [{
                            list: l
                        }] = k, m = g._.get(i), n = a(l, m), o = f(n, i);
                        m = g.utils.isEmpty(m) ? "" : m + "", j && m && (m = o || m, googletag.pubads().setTargeting(j, m), b("Setting GAM Key Value", j, "=", m))
                    }
                }
            }
        },
        ga: {
            conf: function() {
                "ga" in window && "function" == typeof window.ga && f.ga.setKevalues()
            },
            setKevalues: function() {
                var a = 0;
                for (var b of d) {
                    a++;
                    var f = e[b],
                        h = g._.get(b);
                    h = g.utils.isEmpty(h) ? "" : h + "", f && h && ga("set", "dimension" + a, h)
                }
            }
        },
        queue: function() {
            var a = [],
                b = 0;
            this.getLength = function() {
                return a.length - b
            }, this.isEmpty = function() {
                return 0 === a.length
            }, this.enqueue = function(b) {
                a.push(b)
            }, this.dequeue = function() {
                if (0 !== a.length) {
                    var d = a[b];
                    return 2 * ++b >= a.length && (a = a.slice(b), b = 0), d
                }
            }, this.peek = function() {
                return 0 < a.length ? a[b] : void 0
            }, this.show = function() {
                return a
            }
        },
        initExt: function() {
            this.getFuncsFromQueArray = async function(a) {
                for (var b, d = 0; d < a.length; d++) b = a[d], "function" != typeof b || b.called || (b.called = !0, b.call())
            }, this.getFuncsFromQueArray(adomiktag.que)
        }
    };
    var g = {
        loadScript: function(a) {
            return new Promise(function(b, d) {
                const e = document.createElement("script");
                let f = !1;
                e.type = "text/javascript", e.src = a, e.async = !0, e.onerror = function(a) {
                    d(a, e)
                }, e.onload = e.onreadystatechange = function() {
                    f || this.readyState && "complete" != this.readyState || (f = !0, b())
                };
                const g = document.getElementsByTagName("script")[0];
                g.parentElement.insertBefore(e, g)
            })
        },
        utils: {
            calc: {
                avg: function(a) {
                    return a.reduce(function(d, a) {
                        return d + a
                    }, 0) / a.length
                }
            },
            format: {
                currencyToNumber: function(a) {
                    return +a.replace(/[^0-9.-]+/g, "")
                }
            },
            weighing: {
                generateWeighedList: function(a, b) {
                    for (var d, e = [], f = 0; f < b.length; f++) {
                        d = 100 * b[f];
                        for (var g = 0; g < d; g++) e.push(a[f])
                    }
                    return e
                },
                rand: function(a, b) {
                    return Math.floor(Math.random() * (b - a + 1)) + a
                }
            },
            isEmpty: function(a) {
                return !a || !!(a instanceof Array && 0 === a.length) || !("object" != typeof a || 0 !== Object.keys(a).length) || !("function" != typeof a)
            },
            URL: function(a = document.location.href) {
                return new URL(a)
            },
            indexOfForArrays: function(a, b) {
                var d = JSON.stringify(b),
                    e = a.map(JSON.stringify);
                return e.indexOf(d)
            }
        },
        init: function() {
            f.storage = f.storage("session");
            for (v of d) f.data[v] = {}
        },
        _: {
            ABTestConfStack: {},
            ABTestNameStack: {},
            ABTestWeighting: {},
            ABCurrentWeighting: void 0,
            domainPasses: {},
            config: function(a) {
                this.ABTestConfStack = new f.queue, this.ABTestNameStack = new f.queue;
                var b = new Map,
                    {
                        targeting: e
                    } = a;
                if (a.filter && a.filter.domain) var {
                    filter: h,
                    filter: {
                        domain: {
                            list: j = [],
                            include: i
                        }
                    }
                } = a;
                else var h = {},
                    j = [];
                var {
                    hostname: k
                } = g.utils.URL(), l = j && 0 < j.length, m = !!(h && l) && new RegExp(j.join("|"), "ig").test(k) || h && 0 === j.length;
                this.domainPasses = {
                    hasDomains: m,
                    hasList: l,
                    include: i
                };
                for (el of d) {
                    var n = a.ABtest && el in a.ABtest ? a.ABtest[el] : void 0;
                    n && b.set(el, n)
                }
                return f.data = {
                    abtests: b,
                    targeting: e
                }, this
            },
            getAbTest(a) {
                if (!this.domainPasses.hasDomains) return this;
                var b = f.data.abtests.get(a);
                return this.currentABTestName = a, this.currentABTestConf = b, this.ABTestConfStack.enqueue(b), this.ABTestNameStack.enqueue(a), this
            },
            weighting: function(a = 1) {
                if (!this.domainPasses.hasDomains) return this;
                var b, d = this.ABTestNameStack.peek(),
                    e = f.storage.get("adm_weighting") || {};
                if (e[d]) return this.ABCurrentWeighting = void 0, this;
                if (!1 === e[d]) return this.ABCurrentWeighting = !1, this;
                var h = 1 - (!1 === isNaN(a) && 1 >= a ? a : 1),
                    i = g.utils.weighing.generateWeighedList([!0, !1], [a, h]),
                    j = g.utils.weighing.rand(0, i.length - 1);
                return b = i[j], this.ABCurrentWeighting = b, e[d] = b, f.storage.set("adm_weighting", e), this
            },
            execute: function() {
                if (!this.domainPasses.hasDomains) return this;
                var a = this.ABTestNameStack.peek(),
                    d = this.ABTestConfStack.peek();
                if (void 0 === d || !1 === this.ABCurrentWeighting) return this.ABTestNameStack.dequeue(), this.ABTestConfStack.dequeue(), this;
                if (f.storage.get(e[a])) return b("Cache hit for " + a), f.data[a] = f.storage.get(e[a]), this.ABTestNameStack.dequeue(), this.ABTestConfStack.dequeue(), this;
                var h, i, j;
                const [k] = this.currentABTestConf, {
                    list: l,
                    weigh: m
                } = k;
                return (h = g.utils.weighing.generateWeighedList(l, m), i = g.utils.weighing.rand(0, h.length - 1), j = h[i], !j) ? (this.ABTestNameStack.dequeue(), this.ABTestConfStack.dequeue(), this) : (b("Setting New ABTest for " + a), f.storage.set(e[a], j), f.data[a] = j, this.ABTestNameStack.dequeue(), this.ABTestConfStack.dequeue(), this)
            },
            get: function(a) {
                return f.data[a]
            },
            set: function(a, b) {
                return f.data[a] || (f.data[a] = {}), f.data[a] = b, f.data[a]
            }
        },
        cb: function(a, b, d, e) {
            return new Promise(a => {
                f.prebid.pbjs = b, e && "object" == typeof e && (f.prebid.pbjs.withProxy = e.withProxy), f.prebid.init(d), f.prebid.events(d), f.gam.conf(d), setTimeout(function() {
                    a()
                }, 0)
            })
        },
        int: function() {
            var b, d = "unshift";
            try {
                a = function() {
                    return window[_pbjsGlobals.toString()]
                }(), this.prx(a)
            } catch (a) {
                window._pbjsGlobals = [""], window._pbjsGlobals = new Proxy(window._pbjsGlobals, {
                    set: (a, e, f) => (a[e] = f, "0" === e.toString() && (b = window[f], 0 === b.que.length && (d = "push"), b.que[d](() => {
                        this.prx(b)
                    })), !0)
                })
            }
        },
        launch: function(a) {
            var d = !1;
            (c = window[a] = window[a] || {}).que = c.que || [];
            var e = function() {
                return {
                    get: function(a, b) {
                        return !("_isProxy" !== b) || ("object" != typeof a[b] || a[b]._isProxy ? a[b] : new Proxy(a[b], e()))
                    },
                    set: function(a, e, f) {
                        return !(a[e] !== f) || (a[e] = f, d || (d = !0, c.requestBids = new Proxy(c.requestBids, {
                            apply: async function(a, d, e) {
                                try {
                                    await new Promise(function(f) {
                                        b("Init Proxy"), adomiktag.cb(a, d, ...e, {
                                            withProxy: !0
                                        }), f()
                                    })
                                } catch (a) {
                                    b("Error", a)
                                }
                                return Reflect.apply(a, d, e)
                            }
                        })), !0)
                    }
                }
            };
            c.que = new Proxy(c.que, e())
        },
        prx: function(a) {
            f.prebid.pbjs = a, f.prebid.events(), f.gam.conf(), f.prebid.pbjs.requestBids = new Proxy(f.prebid.pbjs.requestBids, {
                apply: async function(a, b, d) {
                    return await adomiktag.cb(a, b, ...d, {
                        withProxy: !0
                    }), f.prebid.pbjs.withProxy = !0, Reflect.apply(a, b, d)
                }
            })
        }
    };
    Object.assign(adomiktag, g), adomiktag.init(), b("Framework Loaded!");
    const h = adomiktag._.config({
        ABtest: {
            bidders: [{
                exclude: !0,
                list: [
                    ["nobidder"],
                    ["nobidder"]
                ],
                weigh: [.5, .5]
            }]
        },
        targeting: {
            value: {
                bidders: ["bidder_1", "bidder_2"]
            }
        }
    });
    h.getAbTest("bidders").weighting(1).execute(), f.initExt()
}();