(function(sttc) {
    'use strict';
    var aa = {};
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var p = this || self;

    function ba(a, b) {
        var c = ca("CLOSURE_FLAGS");
        a = c && c[a];
        return null != a ? a : b
    }

    function ca(a) {
        a = a.split(".");
        for (var b = p, c = 0; c < a.length; c++)
            if (b = b[a[c]], null == b) return null;
        return b
    }

    function da(a) {
        var b = typeof a;
        return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function ea(a) {
        var b = da(a);
        return "array" == b || "object" == b && "number" == typeof a.length
    }

    function fa(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }

    function ha(a) {
        return Object.prototype.hasOwnProperty.call(a, ia) && a[ia] || (a[ia] = ++ja)
    }
    var ia = "closure_uid_" + (1E9 * Math.random() >>> 0),
        ja = 0;

    function ka(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function la(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function ma(a, b, c) {
        ma = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ka : la;
        return ma.apply(null, arguments)
    }

    function na(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function oa(a, b, c) {
        a = a.split(".");
        c = c || p;
        a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function pa(a) {
        return a
    };
    let qa = (new Date).getTime();

    function ra(a) {
        p.setTimeout(() => {
            throw a;
        }, 0)
    };

    function sa(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function ta(a, b) {
        let c = 0;
        a = sa(String(a)).split(".");
        b = sa(String(b)).split(".");
        const d = Math.max(a.length, b.length);
        for (let g = 0; 0 == c && g < d; g++) {
            var e = a[g] || "",
                f = b[g] || "";
            do {
                e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                if (0 == e[0].length && 0 == f[0].length) break;
                c = ua(0 == e[1].length ? 0 : parseInt(e[1], 10), 0 == f[1].length ? 0 : parseInt(f[1], 10)) || ua(0 == e[2].length, 0 == f[2].length) || ua(e[2], f[2]);
                e = e[3];
                f = f[3]
            } while (0 == c)
        }
        return c
    }

    function ua(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
    var va = ba(610401301, !1),
        wa = ba(572417392, ba(1, !0));

    function xa() {
        var a = p.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var ya;
    const Aa = p.navigator;
    ya = Aa ? Aa.userAgentData || null : null;

    function Ba(a) {
        return va ? ya ? ya.brands.some(({
            brand: b
        }) => b && -1 != b.indexOf(a)) : !1 : !1
    }

    function q(a) {
        return -1 != xa().indexOf(a)
    };

    function Ca() {
        return va ? !!ya && 0 < ya.brands.length : !1
    }

    function Da() {
        return Ca() ? !1 : q("Trident") || q("MSIE")
    }

    function Ea() {
        return Ca() ? Ba("Microsoft Edge") : q("Edg/")
    }

    function Fa() {
        !q("Safari") || Ga() || (Ca() ? 0 : q("Coast")) || (Ca() ? 0 : q("Opera")) || (Ca() ? 0 : q("Edge")) || Ea() || Ca() && Ba("Opera")
    }

    function Ga() {
        return Ca() ? Ba("Chromium") : (q("Chrome") || q("CriOS")) && !(Ca() ? 0 : q("Edge")) || q("Silk")
    }

    function Ha(a) {
        const b = {};
        a.forEach(c => {
            b[c[0]] = c[1]
        });
        return c => b[c.find(d => d in b)] || ""
    }

    function Ia() {
        var a = xa();
        if (Da()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
        b = [];
        let d;
        for (; d = c.exec(a);) b.push([d[1], d[2], d[3] || void 0]);
        a = Ha(b);
        return (Ca() ? 0 : q("Opera")) ? a(["Version",
            "Opera"
        ]) : (Ca() ? 0 : q("Edge")) ? a(["Edge"]) : Ea() ? a(["Edg"]) : q("Silk") ? a(["Silk"]) : Ga() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
    };

    function Ja(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function La(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function Ma(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = "string" === typeof a ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Na(a, b) {
        const c = a.length,
            d = Array(c),
            e = "string" === typeof a ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function Oa(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function Ra(a, b) {
        a: {
            var c = a.length;
            const d = "string" === typeof a ? a.split("") : a;
            for (--c; 0 <= c; c--)
                if (c in d && b.call(void 0, d[c], c, a)) {
                    b = c;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    }

    function Ta(a, b) {
        return 0 <= Ja(a, b)
    }

    function Ua(a) {
        const b = a.length;
        if (0 < b) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Va(a) {
        Va[" "](a);
        return a
    }
    Va[" "] = function() {};
    var Wa = Da();
    !q("Android") || Ga();
    Ga();
    Fa();
    var Xa = null;

    function Ya(a) {
        var b = [];
        Za(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Za(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var m = a.charAt(d++),
                    l = Xa[m];
                if (null != l) return l;
                if (!/^[\s\xa0]*$/.test(m)) throw Error("Unknown base64 encoding at char: " + m);
            }
            return k
        }
        $a();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (64 === h && -1 === e) break;
            b(e << 2 | f >> 4);
            64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
        }
    }

    function $a() {
        if (!Xa) {
            Xa = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++)
                for (var d = a.concat(b[c].split("")), e = 0; e < d.length; e++) {
                    var f = d[e];
                    void 0 === Xa[f] && (Xa[f] = e)
                }
        }
    };
    var ab = !wa;
    let cb = !wa;
    let db = 0,
        eb = 0;

    function fb(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        if (b) {
            b = c;
            c = ~a;
            b ? b = ~b + 1 : c += 1;
            const [d, e] = [b, c];
            a = e;
            c = d
        }
        db = c >>> 0;
        eb = a >>> 0
    }

    function gb() {
        var a = db,
            b = eb;
        if (b & 2147483648) var c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0));
        else b >>>= 0, a >>>= 0, 2097151 >= b ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    };

    function hb(a) {
        return Array.prototype.slice.call(a)
    };
    const r = Symbol();

    function jb(a) {
        const b = a[r] | 0;
        1 !== (b & 1) && (Object.isFrozen(a) && (a = hb(a)), a[r] = b | 1)
    }

    function t(a, b, c) {
        return c ? a | b : a & ~b
    }

    function kb() {
        var a = [];
        a[r] |= 1;
        return a
    }

    function lb(a) {
        a[r] |= 32;
        return a
    }

    function mb(a, b) {
        b[r] = (a | 0) & -14591
    }

    function nb(a, b) {
        b[r] = (a | 34) & -14557
    }

    function ob(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var pb = {},
        qb = {};

    function rb(a) {
        return !(!a || "object" !== typeof a || a.oc !== qb)
    }

    function sb(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let tb, ub = !wa;

    function vb(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        const d = a[r] | 0;
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        a[r] = d | 1;
        return !0
    }
    var wb;
    const xb = [];
    xb[r] = 55;
    wb = Object.freeze(xb);

    function yb(a) {
        if (a & 2) throw Error();
    };

    function zb(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    let Ab;

    function Bb(a) {
        if (Ab) throw Error("");
        Ab = a
    }

    function Cb(a) {
        if (Ab) try {
            Ab(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function Db() {
        const a = Eb();
        Ab ? p.setTimeout(() => {
            Cb(a)
        }, 0) : ra(a)
    }

    function Fb(a) {
        a = Error(a);
        zb(a, "warning");
        Cb(a);
        return a
    }

    function Eb() {
        const a = Error();
        zb(a, "incident");
        return a
    };

    function Gb(a) {
        if (null != a && "boolean" !== typeof a) throw Error(`Expected boolean but got ${da(a)}: ${a}`);
        return a
    }
    const Ib = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Jb(a) {
        const b = typeof a;
        return "number" === b ? Number.isFinite(a) : "string" !== b ? !1 : Ib.test(a)
    }

    function Kb(a) {
        null != a && (Number.isFinite(a) || Db());
        return a
    }

    function Lb(a) {
        return a
    }

    function Mb(a) {
        if ("number" !== typeof a) throw Fb("int32");
        Number.isFinite(a) || Db();
        return a
    }

    function Nb(a) {
        return null == a ? a : Mb(a)
    }

    function Ob(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return a
    }

    function Pb(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return a
    }

    function Qb(a) {
        return "-" === a[0] ? 20 > a.length ? !0 : 20 === a.length && -922337 < Number(a.substring(0, 7)) : 19 > a.length ? !0 : 19 === a.length && 922337 > Number(a.substring(0, 6))
    }

    function Rb(a) {
        return a = Math.trunc(a)
    }

    function Sb(a, b) {
        var c = Math.trunc(Number(a));
        if (Number.isSafeInteger(c)) return String(c);
        c = a.indexOf("."); - 1 !== c && (a = a.substring(0, c));
        b && (Qb(a) || (16 > a.length ? fb(Number(a)) : (a = BigInt(a), db = Number(a & BigInt(4294967295)) >>> 0, eb = Number(a >> BigInt(32) & BigInt(4294967295))), a = gb()));
        return a
    }

    function Tb(a) {
        if (null == a) return a;
        if (Jb(a)) return "number" === typeof a ? Rb(a) : Sb(a, !1)
    }

    function Ub(a) {
        if ("string" !== typeof a) throw Error();
        return a
    }

    function Vb(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    }

    function Wb(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function Xb(a, b, c, d) {
        if (null != a && "object" === typeof a && a.na === pb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? (a = b[Yb]) ? b = a : (a = new b, d = a.u, d[r] |= 34, b = b[Yb] = a) : b = new b : b = void 0, b;
        let e = c = a[r] | 0;
        0 === e && (e |= d & 32);
        e |= d & 2;
        e !== c && (a[r] = e);
        return new b(a)
    }
    const Yb = Symbol();
    let Zb;

    function $b(a, b) {
        Zb = b;
        a = new a(b);
        Zb = void 0;
        return a
    };

    function ac(a, b) {
        return bc(b)
    }

    function bc(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return ub || !vb(a, void 0, 9999) ? a : void 0;
                    if (null != a && a instanceof Uint8Array) {
                        let b = "",
                            c = 0;
                        const d = a.length - 10240;
                        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                        return btoa(b)
                    }
                }
        }
        return a
    };

    function cc(a, b, c) {
        a = hb(a);
        var d = a.length;
        const e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (const f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    }

    function dc(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && (a[r] | 0) & 1 ? void 0 : f && (a[r] | 0) & 2 ? a : ec(a, b, c, void 0 !== d, e, f);
            else if (sb(a)) {
                const g = {};
                for (let h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = dc(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function ec(a, b, c, d, e, f) {
        const g = d || c ? a[r] | 0 : 0;
        d = d ? !!(g & 32) : void 0;
        a = hb(a);
        for (let h = 0; h < a.length; h++) a[h] = dc(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    }

    function fc(a) {
        return a.na === pb ? gc(a, ec(a.u, fc, void 0, void 0, !1, !1), !0) : null != a && a instanceof Uint8Array ? new Uint8Array(a) : a
    }

    function hc(a) {
        return a.na === pb ? a.toJSON() : bc(a)
    }
    var ic = "undefined" != typeof structuredClone ? structuredClone : a => ec(a, fc, void 0, void 0, !1, !1);

    function jc(a, b, c = nb) {
        if (null != a) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[r] | 0;
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[r] = (d | 34) & -12293, a) : ec(a, jc, d & 4 ? nb : c, !0, !1, !0)
            }
            a.na === pb && (c = a.u, d = c[r], a = d & 2 ? a : $b(a.constructor, kc(c, d, !0)));
            return a
        }
    }

    function kc(a, b, c) {
        const d = c || b & 2 ? nb : mb,
            e = !!(b & 32);
        a = cc(a, b, f => jc(f, e, d));
        a[r] = a[r] | 32 | (c ? 2 : 0);
        return a
    }

    function lc(a) {
        const b = a.u,
            c = b[r];
        return c & 2 ? $b(a.constructor, kc(b, c, !1)) : a
    };
    Object.freeze({});

    function v(a, b) {
        a = a.u;
        return mc(a, a[r], b)
    }

    function mc(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= ob(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < e) return a[b]
        }
    }

    function y(a, b, c) {
        const d = a.u;
        let e = d[r];
        yb(e);
        B(d, e, b, c);
        return a
    }

    function B(a, b, c, d, e) {
        var f = ob(b);
        if (c >= f || e) {
            e = b;
            if (b & 256) f = a[a.length - 1];
            else {
                if (null == d) return e;
                f = a[f + (+!!(b & 512) - 1)] = {};
                e |= 256
            }
            f[c] = d;
            e !== b && (a[r] = e);
            return e
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    }

    function nc(a, b, c) {
        return void 0 !== oc(a, b, c, !1)
    }

    function pc(a, b, c, d) {
        var e = b & 2;
        let f = mc(a, b, c);
        Array.isArray(f) || (f = wb);
        const g = !(d & 2);
        d = !(d & 1);
        const h = !!(b & 32);
        let k = f[r] | 0;
        0 !== k || !h || e || g ? k & 1 || (k |= 1, f[r] = k) : (k |= 33, f[r] = k);
        e ? (a = !1, k & 2 || (f[r] |= 34, a = !!(4 & k)), (d || a) && Object.freeze(f)) : (e = !!(2 & k) || !!(2048 & k), d && e ? (f = hb(f), d = 1, h && !g && (d |= 32), f[r] = d, B(a, b, c, f)) : g && k & 32 && !e && (a = f, a[r] &= -33));
        return f
    }

    function qc(a, b) {
        a = v(a, b);
        return null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0
    }

    function rc(a, b, c) {
        var d = 2;
        a = a.u;
        let e = a[r];
        2 & e && (d = 1);
        let f = pc(a, e, b, 1);
        e = a[r];
        let g = f[r] | 0,
            h = g,
            k = !!(2 & g);
        var m = !!(4 & g);
        const l = k && m;
        if (!(4 & g)) {
            m && (f = hb(f), h = 0, g = sc(g, e, !1), k = !!(2 & g), e = B(a, e, b, f));
            let n = m = 0;
            for (; m < f.length; m++) {
                const x = c(f[m]);
                null != x && (f[n++] = x)
            }
            n < m && (f.length = n);
            c = t(g, 4096, !1);
            g = c = t(c, 8192, !1);
            g = t(g, 20, !0)
        }
        l || ((c = 1 === d) && (g = t(g, 2, !0)), g !== h && (f[r] = g), (c || k) && Object.freeze(f));
        2 === d && k && (f = hb(f), g = sc(g, e, !1), f[r] = g, B(a, e, b, f));
        return f
    }

    function tc(a, b, c, d) {
        const e = a.u;
        let f = e[r];
        yb(f);
        if (null == c) return B(e, f, b), a;
        let g = c[r] | 0,
            h = g;
        var k = !!(2 & g) || Object.isFrozen(c);
        const m = !k && !1;
        if (!(4 & g))
            for (g = 21, k && (c = hb(c), h = 0, g = sc(g, f, !0)), k = 0; k < c.length; k++) c[k] = d(c[k]);
        m && (g = t(g, 2, !0));
        g !== h && (c[r] = g);
        m && Object.freeze(c);
        B(e, f, b, c);
        return a
    }

    function uc(a, b, c, d) {
        const e = a.u;
        let f = e[r];
        yb(f);
        B(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
        return a
    }

    function vc(a, b, c, d) {
        const e = a.u;
        let f = e[r];
        yb(f);
        (c = wc(e, f, c)) && c !== b && null != d && (f = B(e, f, c));
        B(e, f, b, d);
        return a
    }

    function xc(a, b, c) {
        a = a.u;
        return wc(a, a[r], b) === c ? c : -1
    }

    function yc(a, b) {
        a = a.u;
        return wc(a, a[r], b)
    }

    function wc(a, b, c) {
        let d = 0;
        for (let e = 0; e < c.length; e++) {
            const f = c[e];
            null != mc(a, b, f) && (0 !== d && (b = B(a, b, d)), d = f)
        }
        return d
    }

    function zc(a) {
        var b = Ac;
        a = a.u;
        let c = a[r];
        yb(c);
        const d = mc(a, c, 3);
        b = lc(Xb(d, b, !0, c));
        d !== b && B(a, c, 3, b);
        return b
    }

    function oc(a, b, c, d) {
        a = a.u;
        let e = a[r];
        const f = mc(a, e, c, d);
        b = Xb(f, b, !1, e);
        b !== f && null != b && B(a, e, c, b, d);
        return b
    }

    function C(a, b, c) {
        b = oc(a, b, c, !1);
        if (null == b) return b;
        a = a.u;
        let d = a[r];
        if (!(d & 2)) {
            const e = lc(b);
            e !== b && (b = e, B(a, d, c, b, !1))
        }
        return b
    }

    function D(a, b, c) {
        a = a.u;
        var d = a[r],
            e = !!(2 & d),
            f = e ? 1 : 2;
        const g = 1 === f;
        f = 2 === f;
        var h = !!(2 & d) && f;
        let k = pc(a, d, c, 3);
        d = a[r];
        var m = k[r] | 0,
            l = !!(2 & m);
        const n = !!(4 & m),
            x = !!(32 & m);
        let u = l && n || !!(2048 & m);
        if (!n) {
            var w = k,
                z = d;
            const A = !!(2 & m);
            A && (z = t(z, 2, !0));
            let E = !A,
                M = !0,
                H = 0,
                za = 0;
            for (; H < w.length; H++) {
                const Ka = Xb(w[H], b, !1, z);
                if (Ka instanceof b) {
                    if (!A) {
                        const Sa = !!((Ka.u[r] | 0) & 2);
                        E && (E = !Sa);
                        M && (M = Sa)
                    }
                    w[za++] = Ka
                }
            }
            za < H && (w.length = za);
            m = t(m, 4, !0);
            m = t(m, 16, M);
            m = t(m, 8, E);
            w[r] = m;
            l && !h && (Object.freeze(k), u = !0)
        }
        b = m;
        h = !!(8 &
            m) || g && !k.length;
        if (!e && !h) {
            u && (k = hb(k), u = !1, b = 0, m = sc(m, d, !1), d = B(a, d, c, k));
            e = k;
            h = m;
            for (l = 0; l < e.length; l++) w = e[l], m = lc(w), w !== m && (e[l] = m);
            h = t(h, 8, !0);
            m = h = t(h, 16, !e.length)
        }
        u || (g ? m = t(m, !k.length || 16 & m && (!n || x) ? 2 : 2048, !0) : m = t(m, 32, !1), m !== b && (k[r] = m), g && (Object.freeze(k), u = !0));
        f && u && (k = hb(k), m = sc(m, d, !1), k[r] = m, B(a, d, c, k));
        return k
    }

    function Bc(a, b, c) {
        null == c && (c = void 0);
        return y(a, b, c)
    }

    function Cc(a, b, c, d) {
        null == d && (d = void 0);
        return vc(a, b, c, d)
    }

    function Dc(a, b, c) {
        const d = a.u;
        let e = d[r];
        yb(e);
        if (null == c) return B(d, e, b), a;
        let f = c[r] | 0;
        const g = f,
            h = !!(2 & f) || !!(2048 & f),
            k = h || Object.isFrozen(c),
            m = !k && !1;
        let l = !0,
            n = !0;
        for (let u = 0; u < c.length; u++) {
            var x = c[u];
            h || (x = !!((x.u[r] | 0) & 2), l && (l = !x), n && (n = x))
        }
        h || (f = t(f, 5, !0), f = t(f, 8, l), f = t(f, 16, n), m && (f = t(f, n ? 2 : 2048, !0)), f !== g && (k && (c = hb(c), f = sc(f, e, !0)), c[r] = f), m && Object.freeze(c));
        B(d, e, b, c);
        return a
    }

    function sc(a, b, c) {
        a = t(a, 2, !!(2 & b));
        a = t(a, 32, !!(32 & b) && c);
        return a = t(a, 2048, !1)
    }

    function Ec(a, b) {
        return Ob(v(a, b))
    }

    function F(a, b) {
        return Wb(v(a, b))
    }

    function Fc(a, b) {
        return v(a, b)
    }

    function Gc(a) {
        return a ? ? 0
    }

    function G(a, b, c = !1) {
        return qc(a, b) ? ? c
    }

    function Hc(a, b) {
        return Gc(Ec(a, b))
    }

    function Ic(a, b) {
        return Gc(Tb(v(a, b)))
    }

    function Jc(a, b) {
        a = a.u;
        let c = a[r];
        const d = mc(a, c, b);
        var e = null == d ? d : "number" === typeof d || "NaN" === d || "Infinity" === d || "-Infinity" === d ? Number(d) : void 0;
        null != e && e !== d && B(a, c, b, e);
        return e ? ? 0
    }

    function I(a, b) {
        return F(a, b) ? ? ""
    }

    function J(a, b) {
        return v(a, b) ? ? 0
    }

    function Kc(a, b, c, d) {
        return C(a, b, xc(a, d, c))
    }

    function Mc(a, b, c) {
        if (null == c) var d = c;
        else {
            d = !!d;
            if (!Jb(c)) throw Fb("int64");
            "string" === typeof c ? d = Sb(c, d) : d ? (c = Math.trunc(c), !d || Number.isSafeInteger(c) ? d = String(c) : (d = String(c), Qb(d) || (fb(c), d = gb()))) : d = Rb(c)
        }
        return uc(a, b, d, "0")
    }

    function Nc(a, b) {
        var c = performance.now();
        if (null != c && "number" !== typeof c) throw Error(`Value of float/double field must be a number, found ${typeof c}: ${c}`);
        uc(a, b, c, 0)
    }

    function Oc(a, b, c) {
        return uc(a, b, Vb(c), "")
    }

    function K(a, b, c) {
        return uc(a, b, Kb(c), 0)
    };
    var L = class {
        constructor(a) {
            a: {
                null == a && (a = Zb);Zb = void 0;
                if (null == a) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error();
                    b = a[r] | 0;
                    if (b & 64) break a;
                    b |= 64;
                    var c = a.length;
                    if (c && (--c, sb(a[c]))) {
                        b |= 256;
                        c -= +!!(b & 512) - 1;
                        if (1024 <= c) throw Error();
                        b = b & -16760833 | (c & 1023) << 14
                    }
                }
                a[r] = b
            }
            this.u = a
        }
        toJSON() {
            if (tb) var a = gc(this, this.u, !1);
            else a = ec(this.u, hc, void 0, void 0, !1, !1), a = gc(this, a, !0);
            return a
        }
    };
    L.prototype.na = pb;

    function gc(a, b, c) {
        const d = a.constructor.s;
        var e = (c ? a.u : b)[r],
            f = ob(e),
            g = !1;
        if (d && ub) {
            if (!c) {
                b = hb(b);
                var h;
                if (b.length && sb(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            Object.assign(b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            h = a.u[r];
            a = ob(h);
            h = +!!(h & 512) - 1;
            var k;
            for (let E = 0; E < d.length; E++) {
                var m = d[E];
                if (m < a) {
                    m += h;
                    var l = f[m];
                    null == l ? f[m] = c ? wb : kb() : c && l !== wb && jb(l)
                } else {
                    if (!k) {
                        var n = void 0;
                        f.length && sb(n = f[f.length - 1]) ? k = n : f.push(k = {})
                    }
                    l = k[m];
                    null == k[m] ? k[m] = c ? wb : kb() : c && l !== wb && jb(l)
                }
            }
        }
        k = b.length;
        if (!k) return b;
        let x, u;
        if (sb(n = b[k - 1])) {
            a: {
                var w = n;f = {};c = !1;
                for (var z in w)
                    if (Object.prototype.hasOwnProperty.call(w, z)) {
                        a = w[z];
                        if (Array.isArray(a)) {
                            h = a;
                            if (!cb && vb(a, d, +z) || !ab && rb(a) && 0 === a.size) a = null;
                            a != h && (c = !0)
                        }
                        null != a ? f[z] = a : c = !0
                    }
                if (c) {
                    for (let E in f) {
                        w = f;
                        break a
                    }
                    w = null
                }
            }
            w != n && (x = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            z = k - 1;
            n = b[z];
            if (!(null == n || !cb && vb(n, d, z - e) || !ab && rb(n) && 0 === n.size)) break;
            u = !0
        }
        if (!x && !u) return b;
        var A;
        g ? A = b : A = Array.prototype.slice.call(b, 0, k);
        b = A;
        g && (b.length = k);
        w && b.push(w);
        return b
    }

    function Pc(a, b) {
        if (null == b) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        b[r] |= 128;
        return $b(a, lb(b))
    };

    function Qc(a, b) {
        const c = Rc;
        Rc = void 0;
        if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
    }
    const Sc = a => null !== a && void 0 !== a;
    let Rc = void 0;

    function Tc(a) {
        return b => {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = $b(a, lb(b))
            }
            return b
        }
    };
    var Uc = class extends L {};
    var Vc = class extends L {};
    Vc.s = [2, 3, 4];

    function Wc(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function Xc(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function Yc(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    };

    function Zc(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    }

    function $c(a, b, c) {
        return a.removeEventListener ? (a.removeEventListener(b, c, !1), !0) : !1
    };

    function ad(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function bd(a, b) {
        for (const c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function cd(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function dd(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    };
    var ed;
    var fd = class {
        constructor(a) {
            this.h = a
        }
        toString() {
            return this.h + ""
        }
    };

    function gd(a, b) {
        a = hd.exec(id(a).toString());
        var c = a[3] || "";
        return jd(a[1] + kd("?", a[2] || "", b) + kd("#", c))
    }

    function id(a) {
        return a instanceof fd && a.constructor === fd ? a.h : "type_error:TrustedResourceUrl"
    }
    var hd = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        ld = {};

    function jd(a) {
        if (void 0 === ed) {
            var b = null;
            var c = p.trustedTypes;
            if (c && c.createPolicy) {
                try {
                    b = c.createPolicy("goog#html", {
                        createHTML: pa,
                        createScript: pa,
                        createScriptURL: pa
                    })
                } catch (d) {
                    p.console && p.console.error(d.message)
                }
                ed = b
            } else ed = b
        }
        a = (b = ed) ? b.createScriptURL(a) : a;
        return new fd(a, ld)
    }

    function kd(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var md = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    };

    function nd(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };

    function od(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!ea(f) || fa(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (fa(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                La(g ? Ua(f) : f, d)
            }
        }
    }

    function pd(a) {
        this.g = a || p.document || document
    }
    pd.prototype.getElementsByTagName = function(a, b) {
        return (b || this.g).getElementsByTagName(String(a))
    };
    pd.prototype.createElement = function(a) {
        var b = this.g;
        a = String(a);
        "application/xhtml+xml" === b.contentType && (a = a.toLowerCase());
        return b.createElement(a)
    };
    pd.prototype.createTextNode = function(a) {
        return this.g.createTextNode(String(a))
    };
    pd.prototype.append = function(a, b) {
        od(9 == a.nodeType ? a : a.ownerDocument || a.document, a, arguments)
    };
    pd.prototype.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function qd() {
        return va && ya ? ya.mobile : !rd() && (q("iPod") || q("iPhone") || q("Android") || q("IEMobile"))
    }

    function rd() {
        return va && ya ? !ya.mobile && (q("iPad") || q("Android") || q("Silk")) : q("iPad") || q("Android") && !q("Mobile") || q("Silk")
    };
    var sd = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        td = /#|$/;

    function ud(a, b) {
        var c = a.search(td);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    };

    function vd(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    const wd = "alternate author bookmark canonical cite help icon license next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function xd(a) {
        try {
            var b;
            if (b = !!a && null != a.location.href) a: {
                try {
                    Va(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch {
            return !1
        }
    }

    function yd(a) {
        return xd(a.top) ? a.top : null
    }

    function zd(a, b) {
        const c = Ad("SCRIPT", a);
        c.src = id(b);
        (void 0) ? .qc || (b = (b = (c.ownerDocument && c.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && c.setAttribute("nonce", b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    }

    function Bd(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function Cd() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function Dd(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Ed(a) {
        const b = a.length;
        if (0 == b) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    }
    var Fd = /^([0-9.]+)px$/,
        Gd = /^(-?[0-9.]{1,30})$/;

    function Hd(a) {
        if (!Gd.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function N(a) {
        return (a = Fd.exec(a)) ? +a[1] : null
    }
    var Id = (a, b) => {
            for (let e = 0; 50 > e; ++e) {
                try {
                    var c = !(!a.frames || !a.frames[b])
                } catch {
                    c = !1
                }
                if (c) return a;
                a: {
                    try {
                        const f = a.parent;
                        if (f && f != a) {
                            var d = f;
                            break a
                        }
                    } catch {}
                    d = null
                }
                if (!(a = d)) break
            }
            return null
        },
        Jd = Xc(() => qd() ? 2 : rd() ? 1 : 0),
        Kd = a => {
            Dd({
                display: "none"
            }, (b, c) => {
                a.style.setProperty(c, b, "important")
            })
        };
    let Ld = [];
    const Md = () => {
        const a = Ld;
        Ld = [];
        for (const b of a) try {
            b()
        } catch {}
    };

    function Nd() {
        var a = P(Od).h(Pd.g, Pd.defaultValue),
            b = Q.document;
        if (a.length && b.head)
            for (const c of a) c && b.head && (a = Ad("META"), b.head.appendChild(a), a.httpEquiv = "origin-trial", a.content = c)
    }
    var Qd = () => {
            var a = Math.random;
            return Math.floor(a() * 2 ** 52)
        },
        Rd = a => {
            if ("number" !== typeof a.goog_pvsid) try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: Qd(),
                    configurable: !1
                })
            } catch (b) {}
            return Number(a.goog_pvsid) || -1
        },
        Td = a => {
            var b = Sd;
            "complete" === b.readyState || "interactive" === b.readyState ? (Ld.push(a), 1 == Ld.length && (window.Promise ? Promise.resolve().then(Md) : window.setImmediate ? setImmediate(Md) : setTimeout(Md, 0))) : b.addEventListener("DOMContentLoaded", a)
        };

    function Ad(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function Ud(a, b, c = null, d = !1, e = !1) {
        Vd(a, b, c, d, e)
    }

    function Vd(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = Ad("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    const k = Ja(h, f);
                    0 <= k && Array.prototype.splice.call(h, k, 1)
                }
                $c(f, "load", g);
                $c(f, "error", g)
            };
            Zc(f, "load", g);
            Zc(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var Xd = a => {
            let b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
            Dd(a, (c, d) => {
                if (c || 0 === c) b += `&${d}=${encodeURIComponent(""+c)}`
            });
            Wd(b)
        },
        Wd = a => {
            var b = window;
            b.fetch ? b.fetch(a, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }) : Ud(b, a, void 0, !1, !1)
        };
    let Yd = null;
    var Sd = document,
        Q = window;

    function $d(a) {
        this.g = a || {
            cookie: ""
        }
    }
    $d.prototype.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        "object" === typeof c && (h = c.rc, g = c.sc || !1, f = c.domain || void 0, e = c.path || void 0, d = c.zb);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === d && (d = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (0 > d ? "" : 0 == d ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * d)).toUTCString()) + (g ? ";secure" : "") + (null != h ? ";samesite=" + h : "")
    };
    $d.prototype.get = function(a, b) {
        const c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = sa(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    $d.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    $d.prototype.clear = function() {
        var a = (this.g.cookie || "").split(";");
        const b = [];
        var c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = sa(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (c = b.length - 1; 0 <= c; c--) a = b[c], this.get(a), this.set(a, "", {
            zb: 0,
            path: void 0,
            domain: void 0
        })
    };

    function ae(a, b = window) {
        if (G(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    }

    function be(a = window) {
        try {
            return a.localStorage
        } catch {
            return null
        }
    };

    function ce(a, ...b) {
        if (0 === b.length) return jd(a[0]);
        let c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return jd(c)
    };
    let de = null;
    var ee = (a, b = []) => {
        let c = !1;
        p.google_logging_queue || (c = !0, p.google_logging_queue = []);
        p.google_logging_queue.push([a, b]);
        if (a = c) {
            if (null == de) {
                de = !1;
                try {
                    const d = yd(p);
                    d && -1 !== d.location.hash.indexOf("google_logging") && (de = !0);
                    be(p) ? .getItem("google_logging") && (de = !0)
                } catch (d) {}
            }
            a = de
        }
        a && zd(p.document, ce `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function fe(a = p) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function ge(a = fe()) {
        return a ? xd(a.master) ? a.master : null : null
    };
    var he = a => {
            a = ge(fe(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1;
            return a.google_unique_id
        },
        ie = a => {
            a = a.google_unique_id;
            return "number" === typeof a ? a : 0
        },
        je = () => {
            if (!Q) return !1;
            try {
                return !(!Q.navigator.standalone && !Q.top.navigator.standalone)
            } catch (a) {
                return !1
            }
        },
        ke = a => {
            if (!a) return "";
            a = a.toLowerCase();
            "ca-" != a.substring(0, 3) && (a = "ca-" + a);
            return a
        };
    class le {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    }
    var me = a => !!(a.error && a.meta && a.id);
    const ne = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var oe = class {
            constructor(a, b) {
                this.g = a;
                this.h = b
            }
        },
        pe = class {
            constructor(a, b, c) {
                this.url = a;
                this.l = b;
                this.Ya = !!c;
                this.depth = null
            }
        };
    let qe = null;

    function re() {
        if (null === qe) {
            qe = "";
            try {
                let a = "";
                try {
                    a = p.top.location.hash
                } catch (b) {
                    a = p.location.hash
                }
                if (a) {
                    const b = a.match(/\bdeid=([\d,]+)/);
                    qe = b ? b[1] : ""
                }
            } catch (a) {}
        }
        return qe
    };

    function se() {
        const a = p.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function te() {
        const a = p.performance;
        return a && a.now ? a.now() : null
    };
    var ue = class {
        constructor(a, b) {
            var c = te() || se();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const ve = p.performance,
        we = !!(ve && ve.mark && ve.measure && ve.clearMarks),
        xe = Xc(() => {
            var a;
            if (a = we) a = re(), a = !!a.indexOf && 0 <= a.indexOf("1337");
            return a
        });

    function ye(a) {
        a && ve && xe() && (ve.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), ve.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function ze(a) {
        a.g = !1;
        a.h != a.i.google_js_reporting_queue && (xe() && La(a.h, ye), a.h.length = 0)
    }
    class Ae {
        constructor(a) {
            this.h = [];
            this.i = a || p;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.h = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = xe() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.g) return null;
            a = new ue(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            ve && xe() && ve.mark(b);
            return a
        }
        end(a) {
            if (this.g && "number" === typeof a.value) {
                a.duration = (te() || se()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                ve && xe() && ve.mark(b);
                !this.g || 2048 < this.h.length ||
                    this.h.push(a)
            }
        }
    };

    function Be(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function Ce(a, b, c, d, e) {
        const f = [];
        Dd(a, function(g, h) {
            (g = De(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    }

    function De(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(De(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(Ce(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Ee(a) {
        let b = 1;
        for (const c in a.h) b = c.length > b ? c.length : b;
        return 3997 - b - a.i.length - 1
    }

    function Fe(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = Ee(a) - b.length;
        if (0 > d) return "";
        a.g.sort(function(f, g) {
            return f - g
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.h[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                let m = Ce(h[k], a.i, ",$");
                if (m) {
                    m = e + m;
                    if (d >= m.length) {
                        d -= m.length;
                        c += m;
                        e = a.i;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    }
    class Ge {
        constructor() {
            this.i = "&";
            this.h = {};
            this.j = 0;
            this.g = []
        }
    };

    function He(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        if (a.stack) {
            a = a.stack;
            var c = b;
            try {
                -1 == a.indexOf(c) && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n")
            } catch (d) {
                b = c
            }
        }
        return b
    }
    var Je = class {
        constructor(a, b, c = null) {
            this.v = a;
            this.A = b;
            this.h = c;
            this.g = null;
            this.i = !1;
            this.m = this.H
        }
        gb(a) {
            this.m = a
        }
        Da(a) {
            this.g = a
        }
        j(a) {
            this.i = a
        }
        ea(a, b, c) {
            let d, e;
            try {
                this.h && this.h.g ? (e = this.h.start(a.toString(), 3), d = b(), this.h.end(e)) : d = b()
            } catch (f) {
                b = this.A;
                try {
                    ye(e), b = this.m(a, new le(f, {
                        message: He(f)
                    }), void 0, c)
                } catch (g) {
                    this.H(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        pa(a, b) {
            return (...c) => this.ea(a, () => b.apply(void 0, c))
        }
        H(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const H = new Ge;
                H.g.push(1);
                H.h[1] = Be("context", a);
                me(b) || (b = new le(b, {
                    message: He(b)
                }));
                if (b.msg) {
                    var g = b.msg.substring(0, 512);
                    H.g.push(2);
                    H.h[2] = Be("msg", g)
                }
                const za = b.meta || {};
                if (this.g) try {
                    this.g(za)
                } catch (Pa) {}
                if (d) try {
                    d(za)
                } catch (Pa) {}
                b = [za];
                H.g.push(3);
                H.h[3] = b;
                d = p;
                b = [];
                g = null;
                do {
                    var h = d;
                    if (xd(h)) {
                        var k = h.location.href;
                        g = h.document && h.document.referrer || null
                    } else k = g, g = null;
                    b.push(new pe(k || "", h));
                    try {
                        d = h.parent
                    } catch (Pa) {
                        d = null
                    }
                } while (d && h != d);
                for (let Pa = 0, Lc = b.length - 1; Pa <= Lc; ++Pa) b[Pa].depth = Lc - Pa;
                h = p;
                if (h.location &&
                    h.location.ancestorOrigins && h.location.ancestorOrigins.length == b.length - 1)
                    for (k = 1; k < b.length; ++k) {
                        var m = b[k];
                        m.url || (m.url = h.location.ancestorOrigins[k - 1] || "", m.Ya = !0)
                    }
                var l = b;
                let Ka = new pe(p.location.href, p, !1);
                h = null;
                const Sa = l.length - 1;
                for (m = Sa; 0 <= m; --m) {
                    var n = l[m];
                    !h && ne.test(n.url) && (h = n);
                    if (n.url && !n.Ya) {
                        Ka = n;
                        break
                    }
                }
                n = null;
                const Zd = l.length && l[Sa].url;
                0 != Ka.depth && Zd && (n = l[Sa]);
                f = new oe(Ka, n);
                if (f.h) {
                    var x = f.h.url || "";
                    H.g.push(4);
                    H.h[4] = Be("top", x)
                }
                var u = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    var w =
                        f.g.url.match(sd),
                        z = w[1],
                        A = w[3],
                        E = w[4];
                    l = "";
                    z && (l += z + ":");
                    A && (l += "//", l += A, E && (l += ":" + E));
                    var M = l
                } else M = "";
                u = [u, {
                    url: M
                }];
                H.g.push(5);
                H.h[5] = u;
                Ie(this.v, e, H, this.i, c)
            } catch (H) {
                try {
                    Ie(this.v, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: He(H),
                        url: f && f.g.url
                    }, this.i, c)
                } catch (za) {}
            }
            return this.A
        }
        X(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.H(a, c instanceof Error ? c : Error(c), void 0, this.g || void 0)
            })
        }
    };
    var Ke = a => "string" === typeof a,
        Le = a => void 0 === a;
    var Me = class extends L {};
    Me.s = [2, 8];
    var Ne = [3, 4, 5],
        Oe = [6, 7];

    function Pe(a) {
        return null != a ? !a : a
    }

    function Qe(a, b) {
        let c = !1;
        for (let d = 0; d < a.length; d++) {
            const e = a[d]();
            if (e === b) return e;
            null == e && (c = !0)
        }
        if (!c) return !b
    }

    function Se(a, b) {
        var c = D(a, Me, 2);
        if (!c.length) return Te(a, b);
        a = J(a, 1);
        if (1 === a) return Pe(Se(c[0], b));
        c = Na(c, d => () => Se(d, b));
        switch (a) {
            case 2:
                return Qe(c, !1);
            case 3:
                return Qe(c, !0)
        }
    }

    function Te(a, b) {
        const c = yc(a, Ne);
        a: {
            switch (c) {
                case 3:
                    var d = J(a, xc(a, Ne, 3));
                    break a;
                case 4:
                    d = J(a, xc(a, Ne, 4));
                    break a;
                case 5:
                    d = J(a, xc(a, Ne, 5));
                    break a
            }
            d = void 0
        }
        if (d && (b = (b = b[c]) && b[d])) {
            try {
                var e = b(...rc(a, 8, Wb))
            } catch (f) {
                return
            }
            b = J(a, 1);
            if (4 === b) return !!e;
            if (5 === b) return null != e;
            if (12 === b) a = I(a, xc(a, Oe, 7));
            else a: {
                switch (c) {
                    case 4:
                        a = Jc(a, xc(a, Oe, 6));
                        break a;
                    case 5:
                        a = I(a, xc(a, Oe, 7));
                        break a
                }
                a = void 0
            }
            if (null != a) {
                if (6 === b) return e === a;
                if (9 === b) return null != e && 0 === ta(String(e), a);
                if (null != e) switch (b) {
                    case 7:
                        return e <
                            a;
                    case 8:
                        return e > a;
                    case 12:
                        return Ke(a) && Ke(e) && (new RegExp(a)).test(e);
                    case 10:
                        return null != e && -1 === ta(String(e), a);
                    case 11:
                        return null != e && 1 === ta(String(e), a)
                }
            }
        }
    }

    function Ue(a, b) {
        return !a || !(!b || !Se(a, b))
    };
    var Ve = class extends L {};
    Ve.s = [4];
    var We = class extends L {
        getValue() {
            return C(this, Ve, 2)
        }
    };
    var Xe = class extends L {},
        Ye = Tc(Xe);
    Xe.s = [5];
    var Ze = [1, 2, 3, 6, 7];
    var $e = class extends L {
        constructor() {
            super()
        }
    };

    function af(a, b) {
        const c = d => [{
            [d.Ea]: d.Ba
        }];
        return JSON.stringify([a.filter(d => d.ma).map(c), b.toJSON(), a.filter(d => !d.ma).map(c)])
    }
    var bf = class {
        constructor(a, b) {
            var c = new $e;
            a = K(c, 1, a);
            b = Oc(a, 2, b);
            a = b.u;
            c = a[r];
            this.j = c & 2 ? b : $b(b.constructor, kc(a, c, !0))
        }
    };
    var cf = class extends L {
        constructor() {
            super()
        }
    };
    cf.s = [2];

    function df(a) {
        var b = new ef;
        return y(b, 1, Kb(a))
    }
    var ef = class extends L {
        constructor() {
            super()
        }
        getValue() {
            return J(this, 1)
        }
    };

    function ff(a, b) {
        return Mc(a, 1, b)
    }

    function gf(a, b) {
        return Mc(a, 2, b)
    }
    var hf = class extends L {
        constructor() {
            super()
        }
        getWidth() {
            return Ic(this, 1)
        }
        getHeight() {
            return Ic(this, 2)
        }
    };

    function jf(a, b) {
        return Bc(a, 1, b)
    }

    function kf(a, b) {
        return Bc(a, 2, b)
    }

    function lf(a, b) {
        Bc(a, 3, b)
    }

    function mf(a, b) {
        return uc(a, 5, Gb(b), !1)
    }
    var nf = class extends L {
        constructor() {
            super()
        }
        getContentUrl() {
            return I(this, 4)
        }
    };
    var Ac = class extends L {};
    var of = class extends L {};
    var pf = class extends L {
        constructor() {
            super()
        }
        getContentUrl() {
            return I(this, 1)
        }
    };

    function qf(a) {
        var b = new rf;
        return K(b, 1, a)
    }
    var rf = class extends L {
        constructor() {
            super()
        }
    };

    function sf(a, b) {
        return Cc(a, 4, tf, b)
    }
    var uf = class extends L {
            constructor() {
                super()
            }
        },
        tf = [4, 5, 6, 8, 9, 10, 11];
    var vf = class extends L {
        constructor() {
            super()
        }
    };

    function wf(a, b) {
        return K(a, 1, b)
    }

    function xf(a, b) {
        return K(a, 2, b)
    }
    var yf = class extends L {
        constructor() {
            super()
        }
    };
    var zf = class extends L {
            constructor() {
                super()
            }
        },
        Af = [1, 2];

    function Bf(a, b) {
        return Bc(a, 1, b)
    }

    function Cf(a, b) {
        return Dc(a, 2, b)
    }

    function Df(a, b) {
        return tc(a, 4, b, Mb)
    }

    function Ef(a, b) {
        return Dc(a, 5, b)
    }

    function Ff(a, b) {
        return K(a, 6, b)
    }
    var Gf = class extends L {
        constructor() {
            super()
        }
    };
    Gf.s = [2, 4, 5];
    var Hf = class extends L {
        constructor() {
            super()
        }
    };
    Hf.s = [5];
    var If = [1, 2, 3, 4];
    var Jf = class extends L {
        constructor() {
            super()
        }
    };
    Jf.s = [2, 3];

    function Kf(a) {
        var b = new Lf;
        return Cc(b, 4, Mf, a)
    }
    var Lf = class extends L {
            constructor() {
                super()
            }
            getTagSessionCorrelator() {
                return Ic(this, 2)
            }
        },
        Mf = [4, 5, 7, 8];
    var Nf = class extends L {
        constructor() {
            super()
        }
    };
    var Of = class extends L {
        constructor() {
            super()
        }
    };
    Of.s = [4, 5];
    var Pf = class extends L {
        constructor() {
            super()
        }
        getTagSessionCorrelator() {
            return Ic(this, 1)
        }
    };
    Pf.s = [2];
    var Qf = class extends L {
            constructor() {
                super()
            }
        },
        Rf = [4, 6];
    class Sf extends bf {}

    function Tf(a, ...b) {
        Uf(a, ...b.map(c => ({
            ma: !0,
            Ea: 3,
            Ba: c.toJSON()
        })))
    }

    function Vf(a, ...b) {
        Uf(a, ...b.map(c => ({
            ma: !0,
            Ea: 4,
            Ba: c.toJSON()
        })))
    }

    function Wf(a, ...b) {
        Uf(a, ...b.map(c => ({
            ma: !0,
            Ea: 7,
            Ba: c.toJSON()
        })))
    }
    var Xf = class extends Sf {};
    var Yf = (a, b) => {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    };

    function Uf(a, ...b) {
        a.A && 65536 <= af(a.g.concat(b), a.j).length && Zf(a);
        a.i && !a.m && (a.m = !0, $f(a.i, () => {
            Zf(a)
        }));
        a.g.push(...b);
        a.g.length >= a.v && Zf(a);
        a.g.length && null === a.h && (a.h = setTimeout(() => {
            Zf(a)
        }, a.G))
    }

    function Zf(a) {
        null !== a.h && (clearTimeout(a.h), a.h = null);
        if (a.g.length) {
            var b = af(a.g, a.j);
            a.B("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.g = []
        }
    }
    var ag = class extends Xf {
            constructor(a, b, c, d, e, f) {
                super(a, b);
                this.B = Yf;
                this.G = c;
                this.v = d;
                this.A = e;
                this.i = f;
                this.g = [];
                this.h = null;
                this.m = !1
            }
        },
        bg = class extends ag {
            constructor(a, b, c = 1E3, d = 100, e = !1, f) {
                super(a, b, c, d, e && !0, f)
            }
        };

    function cg(a, b) {
        var c = Date.now();
        c = Number.isFinite(c) ? Math.round(c) : 0;
        b = Mc(b, 1, c);
        c = Rd(window);
        b = Mc(b, 2, c);
        return Mc(b, 6, a.m)
    }

    function dg(a, b, c, d, e, f) {
        if (a.i) {
            var g = xf(wf(new yf, b), c);
            b = Ff(Cf(Bf(Ef(Df(new Gf, d), e), g), a.g.slice()), f);
            b = Kf(b);
            Vf(a.h, cg(a, b));
            if (1 === f || 3 === f || 4 === f && !a.g.some(h => J(h, 1) === J(g, 1) && J(h, 2) === c)) a.g.push(g), 100 < a.g.length && a.g.shift()
        }
    }

    function eg(a, b, c, d) {
        if (a.i && a.j) {
            var e = new Jf;
            b = Dc(e, 2, b);
            c = Dc(b, 3, c);
            d && uc(c, 1, Nb(d), 0);
            d = new Lf;
            d = Cc(d, 7, Mf, c);
            Vf(a.h, cg(a, d))
        }
    }

    function fg(a, b, c, d) {
        if (a.i) {
            var e = new vf;
            b = y(e, 1, Nb(b));
            c = y(b, 2, Nb(c));
            d = y(c, 3, Kb(d));
            c = new Lf;
            d = Cc(c, 8, Mf, d);
            Vf(a.h, cg(a, d))
        }
    }
    var gg = class {
        constructor(a, b, c, d = new bg(6, "unknown", b)) {
            this.m = a;
            this.j = c;
            this.h = d;
            this.g = [];
            this.i = 0 < a && Cd() < 1 / a
        }
    };
    var P = a => {
        var b = "Aa";
        if (a.Aa && a.hasOwnProperty(b)) return a.Aa;
        b = new a;
        return a.Aa = b
    };
    var hg = class {
        constructor() {
            this.F = {
                [3]: {},
                [4]: {},
                [5]: {}
            }
        }
    };
    var ig = /^true$/.test("false");

    function jg(a, b) {
        switch (b) {
            case 1:
                return J(a, xc(a, Ze, 1));
            case 2:
                return J(a, xc(a, Ze, 2));
            case 3:
                return J(a, xc(a, Ze, 3));
            case 6:
                return J(a, xc(a, Ze, 6));
            default:
                return null
        }
    }

    function kg(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return G(a, 1);
            case 7:
                return I(a, 3);
            case 2:
                return Jc(a, 2);
            case 3:
                return I(a, 3);
            case 6:
                return rc(a, 4, Wb);
            default:
                return null
        }
    }
    const lg = Xc(() => {
        if (!ig) return {};
        try {
            var a = window;
            try {
                var b = a.sessionStorage
            } catch {
                b = null
            }
            if (b = b ? .getItem("GGDFSSK")) return JSON.parse(b)
        } catch {}
        return {}
    });

    function mg(a, b, c, d = 0) {
        P(ng).i[d] = P(ng).i[d] ? .add(b) ? ? (new Set).add(b);
        const e = lg();
        if (null != e[b]) return e[b];
        b = og(d)[b];
        if (!b) return c;
        b = Ye(JSON.stringify(b));
        b = pg(b);
        a = kg(b, a);
        return null != a ? a : c
    }

    function pg(a) {
        const b = P(hg).F;
        if (b) {
            const c = Ra(D(a, We, 5), d => Ue(C(d, Me, 1), b));
            if (c) return c.getValue() ? ? null
        }
        return C(a, Ve, 4) ? ? null
    }
    class ng {
        constructor() {
            this.h = {};
            this.j = [];
            this.i = {};
            this.g = new Map
        }
    }

    function qg(a, b = !1, c) {
        return !!mg(1, a, b, c)
    }

    function rg(a, b = 0, c) {
        a = Number(mg(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function sg(a, b = "", c) {
        a = mg(3, a, b, c);
        return "string" === typeof a ? a : b
    }

    function tg(a, b = [], c) {
        a = mg(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function og(a) {
        return P(ng).h[a] || (P(ng).h[a] = {})
    }

    function ug(a, b) {
        const c = og(b);
        Dd(a, (d, e) => c[e] = d)
    }

    function vg(a, b, c, d, e = !1) {
        const f = [],
            g = [];
        La(b, h => {
            const k = og(h);
            La(a, m => {
                var l = yc(m, Ze);
                const n = jg(m, l);
                if (n) {
                    var x = P(ng).g.get(h) ? .get(n) ? .slice(0) ? ? [];
                    a: {
                        const u = new Hf;
                        switch (l) {
                            case 1:
                                vc(u, 1, If, Kb(n));
                                break;
                            case 2:
                                vc(u, 2, If, Kb(n));
                                break;
                            case 3:
                                vc(u, 3, If, Kb(n));
                                break;
                            case 6:
                                vc(u, 4, If, Kb(n));
                                break;
                            default:
                                l = void 0;
                                break a
                        }
                        tc(u, 5, x, Mb);l = u
                    }
                    if (x = l) x = !!P(ng).i[h] ? .has(n);
                    x && f.push(l);
                    if (x = l) x = !!P(ng).g.get(h) ? .has(n);
                    x && g.push(l);
                    e || (l = P(ng), l.g.has(h) || l.g.set(h, new Map), l.g.get(h).has(n) || l.g.get(h).set(n, []), d && l.g.get(h).get(n).push(d));
                    k[n] = m.toJSON()
                }
            })
        });
        (f.length || g.length) && eg(c, f, g, d ? ? void 0)
    }

    function wg(a, b) {
        const c = og(b);
        La(a, d => {
            var e = Ye(JSON.stringify(d));
            const f = yc(e, Ze);
            (e = jg(e, f)) && (c[e] || (c[e] = d))
        })
    }

    function xg() {
        return Na(Object.keys(P(ng).h), a => Number(a))
    }

    function yg(a) {
        Ta(P(ng).j, a) || ug(og(4), a)
    };

    function R(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function zg(a, b, c) {
        return b[a] || c
    }

    function Ag(a) {
        R(5, qg, a);
        R(6, rg, a);
        R(7, sg, a);
        R(8, tg, a);
        R(13, wg, a);
        R(15, yg, a)
    }

    function Bg(a) {
        R(4, b => {
            P(hg).F = b
        }, a);
        R(9, (b, c) => {
            var d = P(hg);
            null == d.F[3][b] && (d.F[3][b] = c)
        }, a);
        R(10, (b, c) => {
            var d = P(hg);
            null == d.F[4][b] && (d.F[4][b] = c)
        }, a);
        R(11, (b, c) => {
            var d = P(hg);
            null == d.F[5][b] && (d.F[5][b] = c)
        }, a);
        R(14, b => {
            var c = P(hg);
            for (const d of [3, 4, 5]) Object.assign(c.F[d], b[d])
        }, a)
    }

    function Cg(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };

    function Dg(a, b, c) {
        a.i = zg(1, b, () => {});
        a.j = (d, e) => zg(2, b, () => [])(d, c, e);
        a.g = () => zg(3, b, () => [])(c);
        a.h = d => {
            zg(16, b, () => {})(d, c)
        }
    }
    class Eg {
        i() {}
        h() {}
        j() {
            return []
        }
        g() {
            return []
        }
    };

    function Ie(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Ge ? f = c : (f = new Ge, Dd(c, (h, k) => {
                var m = f;
                const l = m.j++;
                h = Be(k, h);
                m.g.push(l);
                m.h[l] = h
            }));
            const g = Fe(f, "/pagead/gen_204?id=" + b + "&");
            g && Ud(p, g)
        } catch (f) {}
    }

    function Fg(a, b) {
        0 <= b && 1 >= b && (a.g = b)
    }
    class Gg {
        constructor() {
            this.g = Math.random()
        }
    };
    let Hg, Ig;
    const Jg = new Ae(window);
    (a => {
        Hg = a ? ? new Gg;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        Fg(Hg, window.google_srt);
        Ig = new Je(Hg, !0, Jg);
        Ig.Da(() => {});
        Ig.j(!0);
        "complete" == window.document.readyState ? window.google_measure_js_timing || ze(Jg) : Jg.g && Zc(window, "load", () => {
            window.google_measure_js_timing || ze(Jg)
        })
    })();
    var Kg = {
        Yb: 0,
        Xb: 1,
        Ub: 2,
        Pb: 3,
        Vb: 4,
        Qb: 5,
        Wb: 6,
        Sb: 7,
        Tb: 8,
        Ob: 9,
        Rb: 10,
        Zb: 11
    };
    var Lg = {
        bc: 0,
        cc: 1,
        ac: 2
    };

    function Mg(a) {
        if (0 != a.g) throw Error("Already resolved/rejected.");
    }
    var Pg = class {
        constructor() {
            this.h = new Ng(this);
            this.g = 0
        }
        resolve(a) {
            Mg(this);
            this.g = 1;
            this.j = a;
            Og(this.h)
        }
    };

    function Og(a) {
        switch (a.g.g) {
            case 0:
                break;
            case 1:
                a.h && a.h(a.g.j);
                break;
            case 2:
                a.i && a.i(a.g.i);
                break;
            default:
                throw Error("Unhandled deferred state.");
        }
    }
    var Ng = class {
        constructor(a) {
            this.g = a
        }
        then(a, b) {
            if (this.h) throw Error("Then functions already set.");
            this.h = a;
            this.i = b;
            Og(this)
        }
    };
    const Qg = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new Qg(Ma(this.g, a))
        }
        apply(a) {
            return new Qg(a(this.g.slice(0)))
        }
        sort(a) {
            return new Qg(this.g.slice(0).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            const b = this.g.slice(0);
            b.push(a);
            return new Qg(b)
        }
    };

    function Rg(a, b) {
        for (var c = [], d = a.length, e = 0; e < d; e++) c.push(a[e]);
        c.forEach(b, void 0)
    };
    const Tg = class {
        constructor() {
            this.g = {};
            this.h = {}
        }
        set(a, b) {
            const c = Sg(a);
            this.g[c] = b;
            this.h[c] = a
        }
        get(a, b) {
            a = Sg(a);
            return void 0 !== this.g[a] ? this.g[a] : b
        }
        clear() {
            this.g = {};
            this.h = {}
        }
    };

    function Sg(a) {
        return a instanceof Object ? String(ha(a)) : a + ""
    };

    function Ug(a) {
        return new Vg({
            value: a
        }, null)
    }

    function Wg(a) {
        return new Vg(null, a)
    }

    function Xg(a) {
        try {
            return Ug(a())
        } catch (b) {
            return Wg(b)
        }
    }

    function Yg(a) {
        return null != a.g ? a.getValue() : null
    }

    function Zg(a, b) {
        null != a.g && b(a.getValue());
        return a
    }

    function $g(a, b) {
        null != a.g || b(a.h);
        return a
    }
    class Vg {
        constructor(a, b) {
            this.g = a;
            this.h = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return null != this.g ? (a = a(this.getValue()), a instanceof Vg ? a : Ug(a)) : this
        }
    };
    const ah = class {
        constructor(a) {
            this.g = new Tg;
            if (a)
                for (var b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return void 0 !== this.g.g[Sg(a)]
        }
    };
    class bh {
        constructor() {
            this.g = new Tg
        }
        set(a, b) {
            let c = this.g.get(a);
            c || (c = new ah, this.g.set(a, c));
            c.add(b)
        }
    };
    var S = class extends L {
        getId() {
            return F(this, 3)
        }
    };
    S.s = [4];
    class ch {
        constructor({
            lb: a,
            dc: b,
            nc: c,
            Db: d
        }) {
            this.g = b;
            this.j = new Qg(a || []);
            this.i = d;
            this.h = c
        }
    };
    const eh = a => {
            const b = [],
                c = a.j;
            c && c.g.length && b.push({
                U: "a",
                da: dh(c)
            });
            null != a.g && b.push({
                U: "as",
                da: a.g
            });
            null != a.h && b.push({
                U: "i",
                da: String(a.h)
            });
            null != a.i && b.push({
                U: "rp",
                da: String(a.i)
            });
            b.sort(function(d, e) {
                return d.U.localeCompare(e.U)
            });
            b.unshift({
                U: "t",
                da: "aa"
            });
            return b
        },
        dh = a => {
            a = a.g.slice(0).map(fh);
            a = JSON.stringify(a);
            return Ed(a)
        },
        fh = a => {
            const b = {};
            null != F(a, 7) && (b.q = F(a, 7));
            null != Ec(a, 2) && (b.o = Ec(a, 2));
            null != Ec(a, 5) && (b.p = Ec(a, 5));
            return b
        };
    var gh = class extends L {
        setLocation(a) {
            return y(this, 1, Kb(a))
        }
    };

    function hh(a) {
        const b = [].slice.call(arguments).filter(Wc(e => null === e));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Va || []);
            d = Object.assign(d, e.fb)
        });
        return new ih(c, d)
    }

    function jh(a) {
        switch (a) {
            case 1:
                return new ih(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new ih(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new ih(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new ih(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function kh(a) {
        if (null == a) var b = null;
        else {
            var c = eh(a);
            a = [];
            for (b of c) c = String(b.da), a.push(b.U + "." + (20 >= c.length ? c : c.slice(0, 19) + "_"));
            b = new ih(null, {
                google_placement_id: a.join("~")
            })
        }
        return b
    }
    class ih {
        constructor(a, b) {
            this.Va = a;
            this.fb = b
        }
    };
    const lh = new ih(["google-auto-placed"], {
        google_reactive_ad_format: 40,
        google_tag_origin: "qs"
    });
    var mh = Tc(class extends L {});
    var nh = class extends L {};
    var oh = class extends L {};
    var ph = class extends L {};
    ph.s = [6, 7, 9, 10, 11];
    var qh = class extends L {};
    var rh = class extends L {
        constructor() {
            super()
        }
    };
    rh.s = [1];

    function sh(a) {
        if (1 != a.nodeType) var b = !1;
        else if (b = "INS" == a.tagName) a: {
            b = ["adsbygoogle-placeholder"];a = a.className ? a.className.split(/\s+/) : [];
            for (var c = {}, d = 0; d < a.length; ++d) c[a[d]] = !0;
            for (d = 0; d < b.length; ++d)
                if (!c[b[d]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    };
    var T = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        th = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        uh = class {
            constructor(a) {
                this.g = a;
                this.defaultValue = ""
            }
        },
        vh = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var wh = new T(1082, !0),
        xh = new T(1271),
        yh = new T(1308),
        zh = new T(1305, !0),
        Ah = new th(1130, 100),
        Bh = new uh(14),
        Ch = new T(1247, !0),
        Dh = new T(1272),
        Eh = new T(316),
        Fh = new T(1207, !0),
        Gh = new T(313),
        Hh = new T(369),
        Ih = new T(1289),
        Jh = new T(1298),
        Kh = new T(1230, !0),
        Lh = new T(1229, !0),
        Mh = new T(1231, !0),
        Nh = new T(1302),
        Oh = new T(217),
        Ph = new uh(1307),
        Qh = new th(572636916),
        Rh = new th(579884443),
        Sh = new T(568515114, !0),
        Th = new vh(556791602, ["1", "2"]),
        Uh = new T(572636914),
        Vh = new T(529362570, !0),
        Wh = new T(579884441),
        Xh = new th(572636915),
        Yh = new th(579884442),
        Zh = new T(506914611),
        $h = new T(506852289),
        ai = new T(1120),
        bi = new T(567362967, !0),
        ci = new th(1079, 5),
        di = new T(10009, !0),
        Pd = new vh(1934, ["As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==",
            "A/ERL66fN363FkXxgDc6F1+ucRUkAhjEca9W3la6xaLnD2Y1lABsqmdaJmPNaUKPKVBRpyMKEhXYl7rSvrQw+AkAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A6OdGH3fVf4eKRDbXb4thXA4InNqDJDRhZ8U533U/roYjp4Yau0T3YSuc63vmAs/8ga1cD0E3A7LEq6AXk1uXgsAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"
        ]),
        gi = new T(84);
    var Od = class {
        constructor() {
            const a = {};
            this.i = (b, c) => null != a[b] ? a[b] : c;
            this.j = (b, c) => null != a[b] ? a[b] : c;
            this.g = (b, c) => null != a[b] ? a[b] : c;
            this.h = (b, c) => null != a[b] ? a[b] : c;
            this.m = () => {}
        }
    };

    function U(a) {
        return P(Od).i(a.g, a.defaultValue)
    }

    function hi(a) {
        return P(Od).j(a.g, a.defaultValue)
    };

    function ii(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    var d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && 8 == d.nodeType;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        sh(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    };

    function ji(a, b) {
        const c = e => {
                e = ki(e);
                return null == e ? !1 : 0 < e
            },
            d = e => {
                e = ki(e);
                return null == e ? !1 : 0 > e
            };
        switch (b) {
            case 0:
                return {
                    init: li(a.previousSibling, c),
                    ia: e => li(e.previousSibling, c),
                    oa: 0
                };
            case 2:
                return {
                    init: li(a.lastChild, c),
                    ia: e => li(e.previousSibling, c),
                    oa: 0
                };
            case 3:
                return {
                    init: li(a.nextSibling, d),
                    ia: e => li(e.nextSibling, d),
                    oa: 3
                };
            case 1:
                return {
                    init: li(a.firstChild, d),
                    ia: e => li(e.nextSibling, d),
                    oa: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function ki(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function li(a, b) {
        return a && b(a) ? a : null
    };
    var mi = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };
    var ni = {
        overlays: 1,
        interstitials: 2,
        vignettes: 2,
        inserts: 3,
        immersives: 4,
        list_view: 5,
        full_page: 6,
        side_rails: 7
    };

    function oi(a) {
        a = a.document;
        let b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    }

    function pi(a) {
        return oi(a).clientWidth
    };
    var qi = a => {
        if (a == a.top) return 0;
        for (; a && a != a.top && xd(a); a = a.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };
    var ri = (a, b) => {
        do {
            const c = Bd(a, b);
            if (c && "fixed" == c.position) return !1
        } while (a = a.parentElement);
        return !0
    };

    function si(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            const f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = N(a[c[e]]);
                d = null === d ? null : Math.round(d);
                null != d && (b[f] = d)
            }
        }
    }
    var ti = (a, b) => !((Gd.test(b.google_ad_width) || Fd.test(a.style.width)) && (Gd.test(b.google_ad_height) || Fd.test(a.style.height))),
        vi = (a, b) => (a = ui(a, b)) ? a.y : 0,
        ui = (a, b) => {
            try {
                const c = b.document.documentElement.getBoundingClientRect(),
                    d = a.getBoundingClientRect();
                return {
                    x: d.left - c.left,
                    y: d.top - c.top
                }
            } catch (c) {
                return null
            }
        },
        wi = (a, b, c, d, e) => {
            if (a !== a.top) return yd(a) ? 3 : 16;
            if (!(488 > pi(a))) return 4;
            if (!(a.innerHeight >= a.innerWidth)) return 5;
            const f = pi(a);
            if (!f || (f - c) / f > d) a = 6;
            else {
                if (c = "true" != e.google_full_width_responsive) a: {
                    c =
                    b.parentElement;
                    for (b = pi(a); c; c = c.parentElement)
                        if ((d = Bd(c, a)) && (e = N(d.width)) && !(e >= b) && "visible" != d.overflow) {
                            c = !0;
                            break a
                        }
                    c = !1
                }
                a = c ? 7 : !0
            }
            return a
        },
        xi = (a, b, c, d) => {
            const e = wi(b, c, a, .3, d);
            !0 !== e ? a = e : "true" == d.google_full_width_responsive || ri(c, b) ? (b = pi(b), a = b - a, a = b && 0 <= a ? !0 : b ? -10 > a ? 11 : 0 > a ? 14 : 12 : 10) : a = 9;
            return a
        },
        yi = (a, b, c) => {
            a = a.style;
            "rtl" == b ? a.marginRight = c : a.marginLeft = c
        };
    const zi = (a, b) => {
            if (3 == b.nodeType) return /\S/.test(b.data);
            if (1 == b.nodeType) {
                if (/^(script|style)$/i.test(b.nodeName)) return !1;
                let c;
                try {
                    c = Bd(b, a)
                } catch (d) {}
                return !c || "none" != c.display && !("absolute" == c.position && ("hidden" == c.visibility || "collapse" == c.visibility))
            }
            return !1
        },
        Ai = (a, b, c) => {
            a = ui(b, a);
            return "rtl" == c ? -a.x : a.x
        };
    var Bi = (a, b) => {
        var c;
        c = (c = b.parentElement) ? (c = Bd(c, a)) ? c.direction : "" : "";
        if (c) {
            b.style.border = b.style.borderStyle = b.style.outline = b.style.outlineStyle = b.style.transition = "none";
            b.style.borderSpacing = b.style.padding = "0";
            yi(b, c, "0px");
            b.style.width = pi(a) + "px";
            if (0 !== Ai(a, b, c)) {
                yi(b, c, "0px");
                var d = Ai(a, b, c);
                yi(b, c, -1 * d + "px");
                a = Ai(a, b, c);
                0 !== a && a !== d && yi(b, c, d / (a - d) * d + "px")
            }
            b.style.zIndex = 30
        }
    };
    var Ci = class {
        constructor(a, b) {
            this.I = a;
            this.i = b
        }
        height() {
            return this.i
        }
        g(a) {
            return 300 < a && 300 < this.i ? this.I : Math.min(1200, Math.round(a))
        }
        h() {}
    };
    var Di = (a, b, c, d = e => e) => {
            let e;
            return a.style && a.style[c] && d(a.style[c]) || (e = Bd(a, b)) && e[c] && d(e[c]) || null
        },
        Ei = a => b => b.I <= a,
        Hi = (a, b, c, d) => {
            const e = a && Fi(c, b),
                f = Gi(b, d);
            return g => !(e && g.height() >= f)
        },
        Ii = a => b => b.height() <= a,
        Fi = (a, b) => vi(a, b) < oi(b).clientHeight - 100,
        Ji = (a, b) => {
            var c = Di(b, a, "height", N);
            if (c) return c;
            var d = b.style.height;
            b.style.height = "inherit";
            c = Di(b, a, "height", N);
            b.style.height = d;
            if (c) return c;
            c = Infinity;
            do(d = b.style && N(b.style.height)) && (c = Math.min(c, d)), (d = Di(b, a, "maxHeight", N)) && (c =
                Math.min(c, d)); while ((b = b.parentElement) && "HTML" != b.tagName);
            return c
        };
    const Gi = (a, b) => {
        const c = 0 == ie(a);
        return b && c ? Math.max(250, 2 * oi(a).clientHeight / 3) : 250
    };
    var Ki = {
        google_ad_channel: !0,
        google_ad_client: !0,
        google_ad_host: !0,
        google_ad_host_channel: !0,
        google_adtest: !0,
        google_tag_for_child_directed_treatment: !0,
        google_tag_for_under_age_of_consent: !0,
        google_tag_partner: !0,
        google_restrict_data_processing: !0,
        google_page_url: !0,
        google_debug_params: !0,
        google_shadow_mode: !0,
        google_adbreak_test: !0,
        google_ad_frequency_hint: !0,
        google_admob_interstitial_slot: !0,
        google_admob_rewarded_slot: !0,
        google_admob_ads_only: !0,
        google_max_ad_content_rating: !0,
        google_traffic_source: !0,
        google_overlays: !0,
        google_privacy_treatments: !0,
        google_xz: !0
    };
    const Li = RegExp("(^| )adsbygoogle($| )");

    function Mi(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = nd(d.property);
            a[e] = d.value
        }
    };
    var Ni = class extends L {};
    var Oi = class extends L {};
    var Pi = class extends L {
        g() {
            return qc(this, 23)
        }
    };
    var Qi = class extends L {};
    var Ri = class extends L {};
    var Si = class extends L {};
    var Ti = class extends L {};
    var Ui = class extends L {};
    var Vi = class extends L {
            getName() {
                return F(this, 4)
            }
        },
        Wi = [1, 2, 3];
    var Xi = class extends L {};
    Xi.s = [2, 5, 6, 11];
    var Yi = class extends L {};
    var $i = class extends L {
            g() {
                return Kc(this, Yi, 2, Zi)
            }
        },
        Zi = [1, 2];
    var aj = class extends L {
        g() {
            return C(this, $i, 3)
        }
    };
    aj.s = [1, 4];
    var bj = class extends L {},
        cj = Tc(bj);
    bj.s = [1, 2, 5, 7];

    function dj(a) {
        var b = [];
        Rg(a.getElementsByTagName("p"), function(c) {
            100 <= ej(c) && b.push(c)
        });
        return b
    }

    function ej(a) {
        if (3 == a.nodeType) return a.length;
        if (1 != a.nodeType || "SCRIPT" == a.tagName) return 0;
        var b = 0;
        Rg(a.childNodes, function(c) {
            b += ej(c)
        });
        return b
    }

    function fj(a) {
        return 0 == a.length || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function gj(a, b) {
        if (null == a.g) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }
    const hj = class {
        constructor(a, b, c, d) {
            this.j = a;
            this.h = b;
            this.i = c;
            this.g = d
        }
        query(a) {
            var b = [];
            try {
                b = a.querySelectorAll(this.j)
            } catch (f) {}
            if (!b.length) return [];
            a = Ua(b);
            a = gj(this, a);
            "number" === typeof this.h && (b = this.h, 0 > b && (b += a.length), a = 0 <= b && b < a.length ? [a[b]] : []);
            if ("number" === typeof this.i) {
                b = [];
                for (var c = 0; c < a.length; c++) {
                    var d = dj(a[c]),
                        e = this.i;
                    0 > e && (e += d.length);
                    0 <= e && e < d.length && b.push(d[e])
                }
                a = b
            }
            return a
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.j,
                occurrenceIndex: this.h,
                paragraphIndex: this.i,
                ignoreMode: this.g
            })
        }
    };
    class ij {
        constructor() {
            var a = ce `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
            this.g = null;
            this.i = !1;
            this.m = Math.random();
            this.h = this.H;
            this.v = a
        }
        Da(a) {
            this.g = a
        }
        j(a) {
            this.i = a
        }
        gb(a) {
            this.h = a
        }
        H(a, b, c = .01, d, e = "jserror") {
            if ((this.i ? this.m : Math.random()) > c) return !1;
            me(b) || (b = new le(b, {
                context: a,
                id: e
            }));
            if (d || this.g) b.meta = {}, this.g && this.g(b.meta), d && d(b.meta);
            p.google_js_errors = p.google_js_errors || [];
            p.google_js_errors.push(b);
            p.error_rep_loaded || (zd(p.document, this.v), p.error_rep_loaded = !0);
            return !1
        }
        ea(a, b, c) {
            try {
                return b()
            } catch (d) {
                if (!this.h(a, d, .01, c, "jserror")) throw d;
            }
        }
        pa(a, b) {
            return (...c) => this.ea(a, () => b.apply(void 0, c))
        }
        X(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.H(a, c instanceof Error ? c : Error(c), void 0, this.g || void 0)
            })
        }
    };
    const jj = (a, b) => {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    var kj = (a, b, c, d, e = !1) => {
            const f = d || window,
                g = "undefined" !== typeof queueMicrotask;
            return function() {
                e && g && queueMicrotask(() => {
                    f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                    f.google_rum_task_id_counter += 1
                });
                const h = te();
                let k, m = 3;
                try {
                    k = b.apply(this, arguments)
                } catch (l) {
                    m = 13;
                    if (!c) throw l;
                    c(a, l)
                } finally {
                    f.google_measure_js_timing && h && jj({
                        label: a.toString(),
                        value: h,
                        duration: (te() || 0) - h,
                        type: m,
                        ...(e && g && {
                            taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                        })
                    }, f)
                }
                return k
            }
        },
        lj = (a, b) => kj(a, b, (c, d) => {
            (new ij).H(c, d)
        }, void 0, !1);

    function mj(a, b, c) {
        return kj(a, b, void 0, c, !0).apply()
    }

    function nj(a) {
        if (!a) return null;
        var b = F(a, 7);
        if (F(a, 1) || a.getId() || 0 < rc(a, 4, Wb).length) {
            var c = rc(a, 4, Wb);
            b = Ec(a, 2);
            var d = Ec(a, 5),
                e = oj(v(a, 6)),
                f = F(a, 3),
                g = F(a, 1);
            a = "";
            g && (a += g);
            f && (a += "#" + fj(f));
            if (c)
                for (f = 0; f < c.length; f++) a += "." + fj(c[f]);
            b = (c = a) ? new hj(c, b, d, e) : null
        } else b = b ? new hj(b, Ec(a, 2), Ec(a, 5), oj(v(a, 6))) : null;
        return b
    }
    var pj = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function oj(a) {
        return null == a ? a : pj[a]
    }
    var qj = {
        1: 0,
        2: 1,
        3: 2,
        4: 3
    };

    function rj(a) {
        return a.google_ama_state = a.google_ama_state || {}
    }

    function sj(a) {
        a = rj(a);
        return a.optimization = a.optimization || {}
    };
    var tj = a => {
        switch (v(a, 8)) {
            case 1:
            case 2:
                if (null == a) var b = null;
                else b = C(a, S, 1), null == b ? b = null : (a = v(a, 2), b = null == a ? null : new ch({
                    lb: [b],
                    Db: a
                }));
                return null != b ? Ug(b) : Wg(Error("Missing dimension when creating placement id"));
            case 3:
                return Wg(Error("Missing dimension when creating placement id"));
            default:
                return Wg(Error("Invalid type: " + v(a, 8)))
        }
    };
    var uj = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function vj(a, b) {
        const c = new bh,
            d = new ah;
        b.forEach(e => {
            if (Kc(e, Ti, 1, Wi)) {
                e = Kc(e, Ti, 1, Wi);
                if (C(e, nh, 1) && C(C(e, nh, 1), S, 1) && C(e, nh, 2) && C(C(e, nh, 2), S, 1)) {
                    const g = wj(a, C(C(e, nh, 1), S, 1)),
                        h = wj(a, C(C(e, nh, 2), S, 1));
                    if (g && h)
                        for (var f of uj({
                                anchor: g,
                                position: Fc(C(e, nh, 1), 2)
                            }, {
                                anchor: h,
                                position: Fc(C(e, nh, 2), 2)
                            })) c.set(ha(f.anchor), f.position)
                }
                C(e, nh, 3) && C(C(e, nh, 3), S, 1) && (f = wj(a, C(C(e, nh, 3), S, 1))) && c.set(ha(f), Fc(C(e, nh, 3), 2))
            } else Kc(e, Ui, 2, Wi) ? xj(a, Kc(e, Ui, 2, Wi), c) : Kc(e, Si, 3, Wi) && yj(a, Kc(e, Si, 3, Wi), d)
        });
        return new zj(c,
            d)
    }
    class zj {
        constructor(a, b) {
            this.h = a;
            this.g = b
        }
    }
    const xj = (a, b, c) => {
            C(b, nh, 2) ? (b = C(b, nh, 2), (a = wj(a, C(b, S, 1))) && c.set(ha(a), v(b, 2))) : C(b, S, 1) && (a = Aj(a, C(b, S, 1))) && a.forEach(d => {
                d = ha(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        yj = (a, b, c) => {
            C(b, S, 1) && (a = Aj(a, C(b, S, 1))) && a.forEach(d => {
                c.add(ha(d))
            })
        },
        wj = (a, b) => (a = Aj(a, b)) && 0 < a.length ? a[0] : null,
        Aj = (a, b) => (b = nj(b)) ? b.query(a) : null;
    class V extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, V) : this.stack = Error().stack || ""
        }
    };
    let Bj, W;
    const Cj = new Ae(p);
    var Dj = a => {
        null != a && (p.google_measure_js_timing = a);
        p.google_measure_js_timing || ze(Cj)
    };
    ((a, b = !0) => {
        Bj = a || new Gg;
        "number" !== typeof p.google_srt && (p.google_srt = Math.random());
        Fg(Bj, p.google_srt);
        W = new Je(Bj, b, Cj);
        W.j(!0);
        "complete" == p.document.readyState ? Dj() : Cj.g && Zc(p, "load", () => {
            Dj()
        })
    })();
    var Ej = (a, b, c) => W.ea(a, b, c),
        Fj = (a, b, c) => {
            const d = P(Eg).g();
            !b.eid && d.length && (b.eid = d.toString());
            Ie(Bj, a, b, !0, c)
        },
        Gj = (a, b) => {
            W.X(a, b)
        },
        Hj = (a, b, c, d) => {
            let e;
            me(b) ? e = b.msg || He(b.error) : e = He(b);
            return 0 == e.indexOf("TagError") ? ((b instanceof le ? b.error : b).pbr = !0, !1) : W.H(a, b, c, d)
        };
    var Ij = class {
        constructor() {
            this.g = Qd();
            this.h = 0
        }
    };

    function Jj(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (Kj(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function Lj(a) {
        a = Mj(a);
        return a.has("all") || a.has("after")
    }

    function Nj(a) {
        a = Mj(a);
        return a.has("all") || a.has("before")
    }

    function Mj(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function Kj(a) {
        const b = Mj(a);
        return a && ("AUTO-ADS-EXCLUSION-AREA" === a.tagName || b.has("inside") || b.has("all"))
    }
    var Oj = class {
        constructor() {
            this.g = new Set;
            this.h = new Ij
        }
    };

    function Pj(a, b) {
        if (!a) return !1;
        a = Bd(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return "left" == a || "right" == a
    }

    function Qj(a) {
        for (a = a.previousSibling; a && 1 != a.nodeType;) a = a.previousSibling;
        return a ? a : null
    }

    function Rj(a) {
        return !!a.nextSibling || !!a.parentNode && Rj(a.parentNode)
    };

    function Sj(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };
    const Tj = a => {
        const b = Sj(a);
        return b ? Ma(Na(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => null != c) : null
    };
    var Uj = a => {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };

    function Vj(a, b) {
        if (a.j) return !0;
        a.j = !0;
        const c = D(a.i, ph, 1);
        a.h = 0;
        const d = Wj(a.B);
        var e = a.g;
        var f;
        try {
            var g = (f = e.localStorage.getItem("google_ama_settings")) ? mh(f) : null
        } catch (n) {
            g = null
        }
        f = null !== g && G(g, 2, !1);
        g = rj(e);
        f && (g.eatf = !0, ee(7, [!0, 0, !1]));
        b: {
            var h = {
                    tb: !1,
                    ub: !1
                },
                k = Ua(e.document.querySelectorAll(".google-auto-placed"));
            const n = Ua(e.document.querySelectorAll("ins.adsbygoogle[data-anchor-shown],ins.adsbygoogle[data-anchor-status]")),
                x = Ua(e.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]"));
            var m = (Tj(e) || Ua(e.document.querySelectorAll("div[id^=div-gpt-ad]"))).concat(Ua(e.document.querySelectorAll("iframe[id^=google_ads_iframe]")));
            const u = Ua(e.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")),
                w = Ua(e.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
                z = Ua(e.document.querySelectorAll("div.googlepublisherpluginad")),
                A = Ua(e.document.querySelectorAll("html > ins.adsbygoogle"));
            let E = [].concat(Ua(e.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")), Ua(e.document.querySelectorAll("body ins.adsbygoogle")));f = [];
            for (const [M, H] of [
                    [h.ic, k],
                    [h.tb, n],
                    [h.lc, x],
                    [h.jc, m],
                    [h.mc, u],
                    [h.hc, w],
                    [h.kc, z],
                    [h.ub, A]
                ]) !1 === M ? f = f.concat(H) : E = E.concat(H);h = Uj(E);f = Uj(f);h = h.slice(0);
            for (l of f)
                for (f = 0; f < h.length; f++)(l.contains(h[f]) || h[f].contains(l)) && h.splice(f, 1);
            var l = h;e = oi(e).clientHeight;
            for (f = 0; f < l.length; f++)
                if (!(l[f].getBoundingClientRect().top > e)) {
                    e = !0;
                    break b
                }
            e = !1
        }
        e = e ? g.eatfAbg = !0 : !1;
        if (e) return !0;
        e = new ah([2]);
        for (g = 0; g < c.length; g++) {
            l = a;
            h = c[g];
            f = g;
            m = b;
            if (C(h, gh, 4) && e.contains(Fc(C(h, gh, 4), 1)) && 1 === v(h, 8) && Xj(h, d)) {
                l.h++;
                if (m = Yj(l, h, m, d)) k = rj(l.g), k.numAutoAdsPlaced || (k.numAutoAdsPlaced = 0), C(h, S, 1) && null != Ec(C(h, S, 1), 5) && (k.numPostPlacementsPlaced ? k.numPostPlacementsPlaced++ :
                    k.numPostPlacementsPlaced = 1), null == k.placed && (k.placed = []), k.numAutoAdsPlaced++, k.placed.push({
                    index: f,
                    element: m.ga
                }), ee(7, [!1, l.h, !0]);
                l = m
            } else l = null;
            if (l) return !0
        }
        ee(7, [!1, a.h, !1]);
        return !1
    }

    function Yj(a, b, c, d) {
        if (!Xj(b, d) || 1 != v(b, 8)) return null;
        d = C(b, S, 1);
        if (!d) return null;
        d = nj(d);
        if (!d) return null;
        d = d.query(a.g.document);
        if (0 == d.length) return null;
        d = d[0];
        var e = qj[v(b, 2)];
        e = void 0 === e ? null : e;
        var f;
        if (!(f = null == e)) {
            a: {
                f = a.g;
                switch (e) {
                    case 0:
                        f = Pj(Qj(d), f);
                        break a;
                    case 3:
                        f = Pj(d, f);
                        break a;
                    case 2:
                        var g = d.lastChild;
                        f = Pj(g ? 1 == g.nodeType ? g : Qj(g) : null, f);
                        break a
                }
                f = !1
            }
            if (c = !f && !(!c && 2 == e && !Rj(d))) c = 1 == e || 2 == e ? d : d.parentNode,
            c = !(c && !sh(c) && 0 >= c.offsetWidth);f = !c
        }
        if (!(c = f)) {
            c = a.v;
            f = v(b, 2);
            g = ha(d);
            g = c.h.g.get(g);
            if (!(g = g ? g.contains(f) : !1)) a: {
                if (c.g.contains(ha(d))) switch (f) {
                    case 2:
                    case 3:
                        g = !0;
                        break a;
                    default:
                        g = !1;
                        break a
                }
                for (f = d.parentElement; f;) {
                    if (c.g.contains(ha(f))) {
                        g = !0;
                        break a
                    }
                    f = f.parentElement
                }
                g = !1
            }
            c = g
        }
        if (!c) {
            c = a.A;
            g = v(b, 2);
            a: switch (g) {
                case 1:
                    f = Lj(d.previousElementSibling) || Nj(d);
                    break a;
                case 4:
                    f = Lj(d) || Nj(d.nextElementSibling);
                    break a;
                case 2:
                    f = Nj(d.firstElementChild);
                    break a;
                case 3:
                    f = Lj(d.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + g);
            }
            g = Jj(c, d, g);
            c = c.h;
            Fj("ama_exclusion_zone", {
                typ: f ? g ? "siuex" : "siex" : g ? "suex" : "noex",
                cor: c.g,
                num: c.h++,
                dvc: Jd()
            }, .1);
            c = f || g
        }
        if (c) return null;
        f = C(b, oh, 3);
        c = {};
        f && (c.ib = F(f, 1), c.Ta = F(f, 2), c.ob = !!qc(f, 3));
        f = C(b, gh, 4) && Fc(C(b, gh, 4), 2) ? Fc(C(b, gh, 4), 2) : null;
        f = jh(f);
        g = null != Ec(b, 12) ? Ec(b, 12) : null;
        g = null == g ? null : new ih(null, {
            google_ml_rank: g
        });
        b = Zj(a, b);
        b = hh(a.m, f, g, b);
        f = a.g;
        a = a.G;
        var h = f.document,
            k = c.ob || !1;
        g = (new pd(h)).createElement("DIV");
        const m = g.style;
        m.width = "100%";
        m.height = "auto";
        m.clear = k ? "both" : "none";
        k = g.style;
        k.textAlign =
            "center";
        c.Cb && Mi(k, c.Cb);
        h = (new pd(h)).createElement("INS");
        k = h.style;
        k.display = "block";
        k.margin = "auto";
        k.backgroundColor = "transparent";
        c.ib && (k.marginTop = c.ib);
        c.Ta && (k.marginBottom = c.Ta);
        c.kb && Mi(k, c.kb);
        g.appendChild(h);
        c = {
            ya: g,
            ga: h
        };
        c.ga.setAttribute("data-ad-format", "auto");
        g = [];
        if (h = b && b.Va) c.ya.className = h.join(" ");
        h = c.ga;
        h.className = "adsbygoogle";
        h.setAttribute("data-ad-client", a);
        g.length && h.setAttribute("data-ad-channel", g.join("+"));
        a: {
            try {
                var l = c.ya;
                if (U(Gh)) {
                    {
                        const z = ji(d, e);
                        if (z.init) {
                            var n =
                                z.init;
                            for (d = n; d = z.ia(d);) n = d;
                            var x = {
                                anchor: n,
                                position: z.oa
                            }
                        } else x = {
                            anchor: d,
                            position: e
                        }
                    }
                    l["google-ama-order-assurance"] = 0;
                    ii(l, x.anchor, x.position)
                } else ii(l, d, e);
                b: {
                    var u = c.ga;u.dataset.adsbygoogleStatus = "reserved";u.className += " adsbygoogle-noablate";l = {
                        element: u
                    };
                    var w = b && b.fb;
                    if (u.hasAttribute("data-pub-vars")) {
                        try {
                            w = JSON.parse(u.getAttribute("data-pub-vars"))
                        } catch (z) {
                            break b
                        }
                        u.removeAttribute("data-pub-vars")
                    }
                    w && (l.params = w);
                    (f.adsbygoogle = f.adsbygoogle || []).push(l)
                }
            } catch (z) {
                (u = c.ya) && u.parentNode &&
                    (w = u.parentNode, w.removeChild(u), sh(w) && (w.style.display = w.getAttribute("data-init-display") || "none"));
                u = !1;
                break a
            }
            u = !0
        }
        return u ? c : null
    }

    function Zj(a, b) {
        return Yg($g(tj(b).map(kh), c => {
            rj(a.g).exception = c
        }))
    }
    const ak = class {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.G = b;
            this.i = c;
            this.m = e || null;
            this.v = (this.B = d) ? vj(a.document, D(d, Vi, 5)) : vj(a.document, []);
            this.A = new Oj;
            this.h = 0;
            this.j = !1
        }
    };

    function Wj(a) {
        const b = {};
        a && rc(a, 6, Lb).forEach(c => {
            b[c] = !0
        });
        return b
    }

    function Xj(a, b) {
        return a && nc(a, gh, 4) && b[Fc(C(a, gh, 4), 2)] ? !1 : !0
    };
    var bk = Tc(class extends L {});

    function ck(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? Xg(() => bk(c)) : Ug(null)
    };

    function dk() {
        if (ek) return ek;
        var a = ge() || window;
        const b = a.google_persistent_state_async;
        return null != b && "object" == typeof b && null != b.S && "object" == typeof b.S ? ek = b : a.google_persistent_state_async = ek = new fk
    }

    function gk(a, b, c) {
        b = hk[b] || `google_ps_${b}`;
        a = a.S;
        const d = a[b];
        return void 0 === d ? (a[b] = c(), a[b]) : d
    }

    function ik(a, b, c) {
        return gk(a, b, () => c)
    }

    function jk(a, b, c) {
        a.S[hk[b] || `google_ps_${b}`] = c
    }

    function kk(a, b) {
        jk(a, 38, b)
    }
    var fk = class {
            constructor() {
                this.S = {}
            }
        },
        ek = null;
    const hk = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function lk(a) {
        var b = new mk;
        return y(b, 5, Gb(a))
    }
    var mk = class extends L {
        constructor() {
            super()
        }
    };
    mk.s = [10];

    function nk() {
        this.m = this.m;
        this.i = this.i
    }
    nk.prototype.m = !1;

    function ok(a, b) {
        a.m ? b() : (a.i || (a.i = []), a.i.push(b))
    };
    const pk = a => {
        void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
        void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
        return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
    };

    function qk(a) {
        if (!1 === a.gdprApplies) return !0;
        void 0 === a.internalErrorState && (a.internalErrorState = pk(a));
        return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (Xd({
            e: String(a.internalErrorState)
        }), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
    }

    function rk(a) {
        if (a.g) return a.g;
        a.g = Id(a.h, "__tcfapiLocator");
        return a.g
    }

    function sk(a) {
        return "function" === typeof a.h.__tcfapi || null != rk(a)
    }

    function tk(a, b, c, d) {
        c || (c = () => {});
        if ("function" === typeof a.h.__tcfapi) a = a.h.__tcfapi, a(b, 2, c, d);
        else if (rk(a)) {
            uk(a);
            const e = ++a.G;
            a.A[e] = c;
            a.g && a.g.postMessage({
                __tcfapiCall: {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }
            }, "*")
        } else c({}, !1)
    }

    function uk(a) {
        a.j || (a.j = b => {
            try {
                var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                a.A[c.callId](c.returnValue, c.success)
            } catch (d) {}
        }, Zc(a.h, "message", a.j))
    }
    class vk extends nk {
        constructor(a) {
            var b = {};
            super();
            this.h = a;
            this.g = null;
            this.A = {};
            this.G = 0;
            this.B = b.timeoutMs ? ? 500;
            this.v = b.ec ? ? !1;
            this.j = null
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.v
            };
            const c = Yc(() => a(b));
            let d = 0; - 1 !== this.B && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.B));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState = pk(b), b.internalBlockOnErrors = this.v, g && 0 === b.internalErrorState || (b.tcString = "tcunavailable", g || (b.internalErrorState =
                    3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                tk(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && tk(this, "removeEventListener", null, a.listenerId)
        }
    };
    var Ak = ({
            l: a,
            R: b,
            timeoutMs: c,
            ca: d,
            ja: e = !1,
            ka: f = !1
        }) => {
            b = wk({
                l: a,
                R: b,
                ja: e,
                ka: f
            });
            null != b.g || "tcunav" != b.h.message ? d(b) : xk(a, c).then(g => g.map(yk)).then(g => g.map(h => zk(a, h))).then(d)
        },
        wk = ({
            l: a,
            R: b,
            ja: c = !1,
            ka: d = !1
        }) => {
            if (!Bk({
                    l: a,
                    R: b,
                    ja: c,
                    ka: d
                })) return zk(a, lk(!0));
            b = dk();
            return (b = ik(b, 24)) ? zk(a, yk(b)) : Wg(Error("tcunav"))
        };

    function Bk({
        l: a,
        R: b,
        ja: c,
        ka: d
    }) {
        if (!(d = !d && sk(new vk(a)))) {
            if (c = !c) {
                if (b) {
                    a = ck(a);
                    if (null != a.g)
                        if ((a = a.getValue()) && null != v(a, 1)) b: switch (a = v(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else W.H(806, a.h, void 0, void 0), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function xk(a, b) {
        return Promise.race([Ck(), Dk(a, b)])
    }

    function Ck() {
        return (new Promise(a => {
            var b = dk();
            a = {
                resolve: a
            };
            const c = ik(b, 25, []);
            c.push(a);
            jk(b, 25, c)
        })).then(Ek)
    }

    function Dk(a, b) {
        return new Promise(c => {
            a.setTimeout(c, b, Wg(Error("tcto")))
        })
    }

    function Ek(a) {
        return a ? Ug(a) : Wg(Error("tcnull"))
    }

    function yk(a) {
        if (qk(a))
            if (!1 !== a.gdprApplies && "tcunavailable" !== a.tcString && void 0 !== a.gdprApplies && "string" === typeof a.tcString && a.tcString.length) {
                b: {
                    if (a.publisher && a.publisher.restrictions) {
                        var b = a.publisher.restrictions["1"];
                        if (void 0 !== b) {
                            b = b["755"];
                            break b
                        }
                    }
                    b = void 0
                }
                0 === b ? a = !1 : a.purpose && a.vendor ? (b = a.vendor.consents, (b = !(!b || !b["755"])) && a.purposeOneTreatment && "CH" === a.publisherCC ? a = !0 : (b && (a = a.purpose.consents, b = !(!a || !a["1"])), a = b)) : a = !0
            }
        else a = !0;
        else a = !1;
        return lk(a)
    }

    function zk(a, b) {
        return (a = ae(b, a)) ? Ug(a) : Wg(Error("unav"))
    };
    var Fk = class extends L {};
    Fk.s = [1, 2, 3];
    var Gk = class extends L {};
    Gk.s = [1, 2, 3];
    var Hk = class extends L {
        g() {
            return C(this, Fk, 2)
        }
        h() {
            return C(this, Gk, 3)
        }
    };
    const Ik = class {
        constructor(a) {
            this.exception = a
        }
    };

    function Jk(a, b) {
        try {
            var c = a.h,
                d = c.resolve,
                e = a.g;
            rj(e.g);
            D(e.i, ph, 1);
            d.call(c, new Ik(b))
        } catch (f) {
            a = a.h, b = f, Mg(a), a.g = 2, a.i = b, Og(a.h)
        }
    }
    var Kk = class {
        constructor(a, b, c) {
            this.i = a;
            this.g = b;
            this.h = c
        }
        start() {
            this.j()
        }
        j() {
            try {
                switch (this.i.document.readyState) {
                    case "complete":
                    case "interactive":
                        Vj(this.g, !0);
                        Jk(this);
                        break;
                    default:
                        Vj(this.g, !1) ? Jk(this) : this.i.setTimeout(ma(this.j, this), 100)
                }
            } catch (a) {
                Jk(this, a)
            }
        }
    };
    var Lk = class extends L {
        constructor() {
            super()
        }
    };
    const Mk = {
            "-": 0,
            Y: 2,
            N: 1
        },
        Nk = {
            [0]: "-",
            [2]: "Y",
            [1]: "N"
        };
    var Ok = class extends L {
        constructor() {
            super()
        }
        getVersion() {
            return Hc(this, 2)
        }
    };
    Ok.s = [3];

    function Pk(a) {
        return Ya(2 > (a.length + 3) % 4 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function Qk(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function Rk(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        const b = [1, 2, 3, 5];
        let c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function Sk(a) {
        var b = Pk(a + "A"),
            c = Qk(b.slice(0, 6));
        a = Qk(b.slice(6, 12));
        var d = new Ok;
        c = uc(d, 1, Nb(c), 0);
        a = uc(c, 2, Nb(a), 0);
        b = b.slice(12);
        c = Qk(b.slice(0, 12));
        d = [];
        let e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (0 === e.length) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = 0 === Qk(e[0]);
            e = e.slice(1);
            var g = Tk(e, b),
                h = 0 === d.length ? 0 : d[d.length - 1];
            h = Rk(g) + h;
            e = e.slice(g.length);
            if (f) d.push(h);
            else {
                f = Tk(e, b);
                g = Rk(f);
                for (let m = 0; m <= g; m++) d.push(h + m);
                e = e.slice(f.length)
            }
        }
        if (0 <
            e.length) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return tc(a, 3, d, Mb)
    }

    function Tk(a, b) {
        const c = a.indexOf("11");
        if (-1 === c) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var Uk = class extends L {
        constructor() {
            super()
        }
    };
    var Vk = class extends L {
        constructor() {
            super()
        }
    };

    function Wk(a) {
        var b = new Xk;
        return uc(b, 1, Nb(a), 0)
    }
    var Xk = class extends L {
        getVersion() {
            return Hc(this, 1)
        }
    };
    var Yk = class extends L {
        constructor() {
            super()
        }
    };

    function Zk(a) {
        var b = new $k;
        return Bc(b, 1, a)
    }
    var $k = class extends L {
        constructor() {
            super()
        }
    };
    const al = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        bl = al.reduce((a, b) => a + b);
    var cl = "a".charCodeAt(),
        dl = cd(Kg),
        el = cd(Lg);

    function fl() {
        var a = new gl;
        return Mc(a, 1, 0)
    }

    function hl(a) {
        const b = Ic(a, 1);
        a = Hc(a, 2);
        return new Date(1E3 * b + a / 1E6)
    }
    var gl = class extends L {};

    function il(a, b) {
        if (a.g + b > a.h.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.h.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function jl(a) {
        let b = il(a, 12);
        const c = [];
        for (; b--;) {
            var d = !0 === !!il(a, 1),
                e = il(a, 16);
            if (d)
                for (d = il(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function kl(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (il(a, 1)) {
                const f = e + 1;
                if (c && -1 === c.indexOf(f)) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function ll(a) {
        const b = il(a, 16);
        return !0 === !!il(a, 1) ? (a = jl(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : kl(a, b)
    }
    class ml {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.h = a;
            this.g = 0
        }
    };
    var ol = (a, b) => {
        try {
            var c = Ya(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new ml(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = !0;
            d.g += 78;
            c.cmpId = il(d, 12);
            c.cmpVersion = il(d, 12);
            d.g += 30;
            c.tcfPolicyVersion = il(d, 6);
            c.isServiceSpecific = !!il(d, 1);
            c.useNonStandardStacks = !!il(d, 1);
            c.specialFeatureOptins = nl(kl(d, 12, el), el);
            c.purpose = {
                consents: nl(kl(d, 24, dl), dl),
                legitimateInterests: nl(kl(d, 24, dl), dl)
            };
            c.purposeOneTreatment = !!il(d, 1);
            c.publisherCC = String.fromCharCode(cl + il(d, 6)) + String.fromCharCode(cl +
                il(d, 6));
            c.vendor = {
                consents: nl(ll(d), b),
                legitimateInterests: nl(ll(d), b)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const nl = (a, b) => {
        const c = {};
        if (Array.isArray(b) && 0 !== b.length)
            for (const d of b) c[d] = -1 !== a.indexOf(d);
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var pl = new T(203);
    var ql = class extends L {
        g() {
            return null != F(this, 2)
        }
    };
    var rl = class extends L {
        g() {
            return null != F(this, 2)
        }
    };
    var sl = class extends L {};
    var tl = class extends L {},
        ul = Tc(tl);
    tl.s = [7];

    function vl(a) {
        a = wl(a);
        try {
            var b = a ? ul(a) : null
        } catch (c) {
            b = null
        }
        return b ? C(b, sl, 4) || null : null
    }

    function wl(a) {
        a = (new $d(a)).get("FCCDCF", "");
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };

    function xl(a) {
        a.__uspapiPostMessageReady || yl(new zl(a))
    }

    function yl(a) {
        a.g = b => {
            const c = "string" === typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__uspapiCall;
            e && "getUSPData" === e.command && a.l.__uspapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.l.addEventListener("message", a.g);
        a.l.__uspapiPostMessageReady = !0
    }
    var zl = class {
        constructor(a) {
            this.l = a;
            this.g = null
        }
    };
    [...(new Map([
        [8, "usca"],
        [9, "usva"],
        [10, "usco"],
        [12, "usct"],
        [11, "usut"]
    ]))].sort((a, b) => a[0] - b[0]).map(a => a[1]);
    const Al = Zk(Wk(1));

    function Bl(a) {
        try {
            if (0 === a.length) throw Error("Cannot decode empty USCA section string");
            const Hb = a.split(".");
            if (2 < Hb.length) throw Error(`Expected at most 1 sub-section but got ${Hb.length-1} when decoding ${a}`);
            let bb = Pk(Hb[0]);
            const Re = Qk(bb.slice(0, 6));
            bb = bb.slice(6);
            if (1 !== Re) throw Error(`Unable to decode unsupported USCA Section specification version ${Re} - only version 1 is supported.`);
            if (bb.length < bl)
                if (bb.length + 8 >= bl) bb += "00000000";
                else throw Error(`Expected core segment bitstring minus version plus padding to be at least of length ${bl} but was ${bb.length+8}`);
            a = 0;
            const O = [];
            for (let Qa = 0; Qa < al.length; Qa++) {
                const ib = al[Qa];
                O.push(Qk(bb.slice(a, a + ib)));
                a += ib
            }
            var b = Wk(Re),
                c = O.shift();
            var d = K(b, 2, c);
            var e = O.shift();
            var f = K(d, 3, e);
            var g = O.shift();
            var h = K(f, 4, g);
            var k = O.shift();
            var m = K(h, 5, k);
            var l = O.shift();
            var n = K(m, 6, l);
            var x = new Vk,
                u = O.shift();
            var w = K(x, 1, u);
            var z = O.shift();
            var A = K(w, 2, z);
            var E = O.shift();
            var M = K(A, 3, E);
            var H = O.shift();
            var za = K(M, 4, H);
            var Ka = O.shift();
            var Sa = K(za, 5, Ka);
            var Zd = O.shift();
            var Pa = K(Sa, 6, Zd);
            var Lc = O.shift();
            var In = K(Pa, 7, Lc);
            var Jn = O.shift();
            var Kn = K(In, 8, Jn);
            var Ln = O.shift();
            var Mn = K(Kn, 9, Ln);
            var Nn = Bc(n, 7, Mn);
            var On = new Uk,
                Pn = O.shift();
            var Qn = K(On, 1, Pn);
            var Rn = O.shift();
            var Sn = K(Qn, 2, Rn);
            var Tn = Bc(Nn, 8, Sn);
            var Un = O.shift();
            var Vn = K(Tn, 9, Un);
            var Wn = O.shift();
            var Xn = K(Vn, 10, Wn);
            var Yn = O.shift();
            var Zn = K(Xn, 11, Yn);
            var $n = O.shift();
            var ei = K(Zn, 12, $n);
            if (1 === Hb.length) var fi = Zk(ei);
            else {
                var ao = Zk(ei);
                const Qa = Pk(Hb[1]);
                if (3 > Qa.length) throw Error(`Invalid GPC Segment [${Qa}]. Expected length ${3}, but was ${Qa.length}.`);
                const ib = Qk(Qa.slice(0, 2));
                if (0 > ib || 1 < ib) throw Error(`Attempting to decode unknown GPC segment subsection type ${ib}.`);
                var bo = ib + 1;
                const co = Qk(Qa.charAt(2));
                var eo = new Yk;
                var fo = K(eo, 2, bo);
                var go = uc(fo, 1, Gb(!!co), !1);
                fi = Bc(ao, 2, go)
            }
            return fi
        } catch (Hb) {
            return null
        }
    }

    function Cl(a) {
        var b = new Lk;
        b = uc(b, 1, Nb(1), 0);
        var c = J(C(a.g, Xk, 1), 2);
        const d = J(C(a.g, Xk, 1), 3);
        0 === c && 0 === d ? K(b, 2, 0) : 2 === c || 2 === d ? K(b, 2, 1) : K(b, 2, 2);
        c = J(C(a.g, Xk, 1), 5);
        a = J(C(a.g, Xk, 1), 6);
        0 === c && 0 === a ? K(b, 3, 0) : 1 === c || 1 === a ? K(b, 3, 2) : K(b, 3, 1);
        K(b, 4, 1);
        a = [Hc(b, 1), Nk[J(b, 2)], Nk[J(b, 3)], Nk[J(b, 4)]].join("");
        return 4 === a.length && (-1 === a.indexOf("-") || "---" === a.substring(1)) && "1" <= a[0] && "9" >= a[0] && Mk.hasOwnProperty(a[1]) && Mk.hasOwnProperty(a[2]) && Mk.hasOwnProperty(a[3]) ? a : null
    }
    var Dl = class {
        constructor(a = Al, b = new gl) {
            this.g = a;
            this.timestamp = b
        }
        getTimestamp() {
            return this.timestamp
        }
    };
    cd(Kg).map(a => Number(a));
    cd(Lg).map(a => Number(a));

    function El(a) {
        a.__tcfapiPostMessageReady || Fl(new Gl(a))
    }

    function Fl(a) {
        a.h = b => {
            const c = "string" == typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.g.__tcfapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = "removeEventListener" === e.command ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.g.addEventListener("message", a.h);
        a.g.__tcfapiPostMessageReady = !0
    }
    var Gl = class {
        constructor(a) {
            this.g = a;
            this.h = null
        }
    };
    var Hl = class extends L {
        g() {
            return nc(this, gl, 2)
        }
    };
    var Il = class extends L {
            g() {
                return null != F(this, 1)
            }
        },
        Jl = Tc(Il);
    Il.s = [2];

    function Kl(a, b, c) {
        function d(l) {
            if (10 > l.length) return null;
            var n = g(l.slice(0, 4));
            n = h(n);
            l = g(l.slice(6, 10));
            l = k(l);
            return "1" + n + l + "N"
        }

        function e(l) {
            if (10 > l.length) return null;
            var n = g(l.slice(0, 6));
            n = h(n);
            l = g(l.slice(6, 10));
            l = k(l);
            return "1" + n + l + "N"
        }

        function f(l) {
            if (12 > l.length) return null;
            var n = g(l.slice(0, 6));
            n = h(n);
            l = g(l.slice(8, 12));
            l = k(l);
            return "1" + n + l + "N"
        }

        function g(l) {
            const n = [];
            let x = 0;
            for (let u = 0; u < l.length / 2; u++) n.push(Qk(l.slice(x, x + 2))), x += 2;
            return n
        }

        function h(l) {
            return l.every(n => 1 === n) ?
                "Y" : "N"
        }

        function k(l) {
            return l.some(n => 1 === n) ? "Y" : "N"
        }
        if (0 === a.length) return null;
        a = a.split(".");
        if (2 < a.length) return null;
        a = Pk(a[0]);
        const m = Qk(a.slice(0, 6));
        a = a.slice(6);
        if (1 !== m) return null;
        switch (b) {
            case 8:
                return d(a);
            case 10:
            case 12:
            case 9:
                return e(a);
            case 11:
                return c ? f(a) : null;
            default:
                return null
        }
    };
    var Ll = (a, b) => {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = Ad("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };

    function Ml() {
        var a = U(zh),
            b = U(yh);
        Q !== Q.top || Q.__uspapi || Q.frames.__uspapiLocator || (a = new Nl(a, b), Ol(a), Pl(a))
    }

    function Ol(a) {
        !a.m || a.g.__uspapi || a.g.frames.__uspapiLocator || (a.g.__uspapiManager = "fc", Ll(a.g, "__uspapiLocator"), oa("__uspapi", (...b) => Ql(a, ...b), a.g), a.j && xl(a.g))
    }

    function Pl(a) {
        !a.h || a.g.__tcfapi || a.g.frames.__tcfapiLocator || (a.g.__tcfapiManager = "fc", Ll(a.g, "__tcfapiLocator"), a.g.__tcfapiEventListeners = a.g.__tcfapiEventListeners || [], oa("__tcfapi", (...b) => Rl(a, ...b), a.g), El(a.g))
    }

    function Ql(a, b, c, d) {
        "function" === typeof d && "getUSPData" === b && d({
            version: 1,
            uspString: a.m
        }, !0)
    }

    function Sl(a, b) {
        if (!b ? .g() || 0 === I(b, 1).length || 0 == D(b, Hl, 2).length) return null;
        const c = I(b, 1);
        let d;
        try {
            var e = Sk(c.split("~")[0]);
            d = c.includes("~") ? c.split("~").slice(1) : []
        } catch (f) {
            return null
        }
        if (a.j) return b = D(b, Hl, 2).reduce((f, g) => Ic(Tl(f), 1) > Ic(Tl(g), 1) ? f : g), e = rc(e, 3, Ob).indexOf(Hc(b, 1)), -1 === e || e >= d.length ? null : {
            uspString: Kl(d[e], Hc(b, 1), a.v),
            ha: hl(Tl(b))
        };
        a = D(b, Hl, 2).find(f => 8 === Hc(f, 1));
        a = a ? .g() ? C(a, gl, 2) : fl();
        e = rc(e, 3, Ob).indexOf(8);
        return -1 === e ? null : {
            uspString: Cl(new Dl(Bl(d[e]) ? ? Al, a)),
            ha: hl(a)
        }
    }

    function Ul(a) {
        a = a.find(b => 13 === J(b, 1));
        if (a ? .g()) try {
            return Jl(I(a, 2))
        } catch (b) {}
        return null
    }

    function Tl(a) {
        return a.g() ? C(a, gl, 2) : fl()
    }

    function Rl(a, b, c, d, e = null) {
        if ("function" === typeof d)
            if (c && (2.1 < c || 1 >= c)) d(null, !1);
            else switch (c = a.g.__tcfapiEventListeners, b) {
                case "getTCData":
                    !e || Array.isArray(e) && e.every(f => "number" === typeof f) ? d(Vl(a, e, null), !0) : d(null, !1);
                    break;
                case "ping":
                    d({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.1",
                        cmpVersion: 2,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    b = c.push(d);
                    d(Vl(a, null, b - 1), !0);
                    break;
                case "removeEventListener":
                    c[e] ? (c[e] = null, d(!0)) : d(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    d(null, !1)
            }
    }

    function Vl(a, b, c) {
        if (!a.h) return null;
        b = ol(a.h, b);
        b.addtlConsent = null != a.i ? a.i : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    }
    class Nl {
        constructor(a, b) {
            var c = Q;
            this.g = c;
            this.j = a;
            this.v = b;
            a = wl(this.g.document);
            try {
                var d = a ? ul(a) : null
            } catch (e) {
                d = null
            }(a = d) ? (d = C(a, rl, 5) || null, a = D(a, ql, 7) ? ? [], a = Ul(a), d = {
                Ua: d,
                Xa: a
            }) : d = {
                Ua: null,
                Xa: null
            };
            a = d;
            d = Sl(this, a.Xa);
            a = a.Ua;
            a ? .g() && 0 !== I(a, 2).length ? (b = nc(a, gl, 1) ? C(a, gl, 1) : fl(), a = {
                uspString: I(a, 2),
                ha: hl(b)
            }) : a = null;
            this.m = a && d ? d.ha > a.ha ? d.uspString : a.uspString : a ? a.uspString : d ? d.uspString : null;
            this.h = (d = vl(c.document)) && null != F(d, 1) ? I(d, 1) : null;
            this.i = (c = vl(c.document)) && null != F(c, 2) ? I(c,
                2) : null
        }
    };
    const Wl = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function Xl(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        Fj("ama", b, .01)
    }

    function Yl(a) {
        const b = {};
        Dd(Wl, (c, d) => {
            d in a && (b[d] = a[d])
        });
        return b
    };
    const Zl = a => {
            const b = /[a-zA-Z0-9._~-]/,
                c = /%[89a-zA-Z]./;
            return a.replace(/(%[a-zA-Z0-9]{2})/g, function(d) {
                if (!d.match(c)) {
                    const e = decodeURIComponent(d);
                    if (e.match(b)) return e
                }
                return d.toUpperCase()
            })
        },
        $l = a => {
            let b = "";
            const c = /[/%?&=]/;
            for (let d = 0; d < a.length; ++d) {
                const e = a[d];
                b = e.match(c) ? b + e : b + encodeURIComponent(e)
            }
            return b
        };
    var am = a => {
            a = rc(a, 2, Lb);
            if (!a) return !1;
            for (let b = 0; b < a.length; b++)
                if (1 == a[b]) return !0;
            return !1
        },
        cm = (a, b) => {
            a = $l(Zl(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
            const c = Ed(a),
                d = bm(a);
            return b.find(e => {
                if (nc(e, Ri, 7)) {
                    var f = C(e, Ri, 7);
                    f = Pb(v(f, 1))
                } else f = Pb(v(e, 1));
                e = nc(e, Ri, 7) ? Fc(C(e, Ri, 7), 2) : 2;
                if ("number" !== typeof f) return !1;
                switch (e) {
                    case 1:
                        return f == c;
                    case 2:
                        return d[f] || !1
                }
                return !1
            }) || null
        };
    const bm = a => {
        const b = {};
        for (;;) {
            b[Ed(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };
    var dm = a => {
        a = C(a, Qi, 3);
        return !a || Tb(v(a, 1)) <= Date.now() ? !1 : !0
    };

    function em(a) {
        if (U(Eh)) var b = null;
        else try {
            b = a.getItem("google_ama_config")
        } catch (d) {
            b = null
        }
        try {
            var c = b ? cj(b) : null
        } catch (d) {
            c = null
        }
        return c
    };
    var fm = class extends L {
        g() {
            return C(this, Hk, 2)
        }
        h() {
            return G(this, 3)
        }
    };
    var gm = class extends L {
        g() {
            return rc(this, 1, Wb)
        }
        h() {
            return C(this, fm, 2)
        }
    };
    gm.s = [1];
    var hm = class extends L {
        getId() {
            return Hc(this, 1)
        }
    };
    hm.s = [2];
    var im = class extends L {};
    im.s = [2];
    var jm = class extends L {};
    jm.s = [2];
    var km = class extends L {
        g() {
            return Ic(this, 2)
        }
        h() {
            return Ic(this, 4)
        }
        i() {
            return G(this, 3)
        }
    };
    var lm = class extends L {};
    lm.s = [1, 4, 2, 3];
    var nm = class extends L {
        h() {
            return Kc(this, fm, 13, mm)
        }
        j() {
            return void 0 !== oc(this, fm, xc(this, mm, 13))
        }
        g() {
            return Kc(this, gm, 14, mm)
        }
        i() {
            return void 0 !== oc(this, gm, xc(this, mm, 14))
        }
    };
    nm.s = [19];
    var mm = [13, 14];
    let om = void 0;

    function pm(a) {
        Qc(om, Le);
        om = a
    };

    function X(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function qm(a) {
        a = X(a);
        const b = a.space_collapsing || "none";
        return a.remove_ads_by_default ? {
            Sa: !0,
            Ib: b,
            va: a.ablation_viewport_offset
        } : null
    }

    function rm(a, b) {
        a = X(a);
        a.had_ads_ablation = !0;
        a.remove_ads_by_default = !0;
        a.space_collapsing = "slot";
        a.ablation_viewport_offset = b
    }

    function sm(a) {
        X(Q).allow_second_reactive_tag = a
    }

    function tm() {
        const a = X(window);
        a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
        return a.afg_slotcar_vars
    };

    function um(a) {
        return X(a) ? .head_tag_slot_vars ? .google_ad_host ? ? vm(a)
    }

    function vm(a) {
        return a.document ? .querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };
    const wm = [2, 7, 1];
    var zm = (a, b, c = "", d = null) => 1 === b && xm(c, d) ? !0 : ym(a, c, e => Oa(D(e, Uc, 2), f => v(f, 1) === b)),
        xm = (a, b) => b ? b.j() ? G(b.h(), 1) : b.i() && "" !== a && 1 === b.g().g().length && b.g().g()[0] === a ? G(b.g().h(), 1) : !1 : !1,
        Am = (a, b) => {
            b = Hc(b, 18); - 1 !== b && (a.tmod = b)
        },
        Cm = a => {
            const b = yd(Q) || Q;
            return Bm(b, a) ? !0 : ym(Q, "", c => Oa(rc(c, 3, Lb), d => d === a))
        };

    function Bm(a, b) {
        a = (a = (a = a.location && a.location.hash) && a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
        return !!a && Ta(a.split(","), b.toString())
    }

    function ym(a, b, c) {
        a = yd(a) || a;
        const d = Dm(a);
        b && (b = ke(String(b)));
        return bd(d, (e, f) => Object.prototype.hasOwnProperty.call(d, f) && (!b || b === f) && c(e))
    }

    function Dm(a) {
        a = Em(a);
        const b = {};
        Dd(a, (c, d) => {
            try {
                const e = new Vc(c);
                b[d] = e
            } catch (e) {}
        });
        return b
    }
    var Em = a => U(wh) ? (Qc(om, Sc), a = wk({
        l: a,
        R: om
    }), null != a.g ? Fm(a.getValue()) : {}) : Fm(a.localStorage);

    function Fm(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : ad(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && "string" === typeof e && Array.isArray(d))
        } catch (b) {
            return {}
        }
    }

    function Gm(a) {
        Fj("atf_ad_settings_from_ppabg", {
            p_s: a
        }, .01)
    }
    const Hm = a => {
            Fj("overlay_settings_from_ppabg", {
                p_s: a
            }, .01)
        },
        Im = (a, b) => {
            if (um(p)) return wm;
            if (b ? .j()) {
                var c = I(b.h(), 9);
                b = b ? .h() ? .g() ? .h();
                if (!a || c != a || !b) return wm;
                Hm(!1);
                return rc(b, 3, Lb)
            }
            if (b ? .i()) {
                c = b ? .g() ? .g();
                if (!c || 1 !== c.length || !a || c[0] !== a || I(b, 17) != p.location.host) return wm;
                a = b ? .g() ? .h() ? .g() ? .h();
                if (!a) return wm;
                Hm(!0);
                return rc(a, 3, Lb)
            }
            return wm
        };
    var Jm = (a, b) => {
        const c = [];
        let d = wm;
        if (U(Lh) || U(Kh) || U(Mh)) d = Im(a, b);
        U(Lh) && !d.includes(1) && c.push(1);
        U(Kh) && !d.includes(2) && c.push(2);
        U(Mh) && !d.includes(7) && c.push(7);
        return c
    };

    function Km(a, b, c, d) {
        Lm(new Mm(a, b, c, d))
    }

    function Lm(a) {
        $g(Zg(wk({
            l: a.l,
            R: G(a.g, 6)
        }), b => {
            Nm(a, b, !0)
        }), () => {
            Om(a)
        })
    }

    function Nm(a, b, c) {
        $g(Zg(Pm(b), d => {
            Qm("ok");
            a.h(d, {
                fromLocalStorage: !0
            })
        }), () => {
            var d = a.l;
            try {
                b.removeItem("google_ama_config")
            } catch (e) {
                Xl(d, {
                    lserr: 1
                })
            }
            c ? Om(a) : a.h(null, null)
        })
    }

    function Om(a) {
        $g(Zg(Rm(a), b => {
            a.h(b, {
                fromPABGSettings: !0
            })
        }), () => {
            Sm(a)
        })
    }

    function Pm(a) {
        return (a = (a = em(a)) ? dm(a) ? a : null : null) ? Ug(a) : Wg(Error("invlocst"))
    }

    function Rm(a) {
        if (um(a.l) && !G(a.g, 22)) return Wg(Error("invtag"));
        a: {
            var b = a.l;
            var c = a.i;a = a.g;
            if (a ? .j())(b = a ? .h() ? .g() ? .g()) && (0 < D(b, ph, 1).length || U(Fh) && 0 < D(b, qh, 3).length) ? Gm(!1) : b = null;
            else {
                if (a ? .i()) {
                    const d = a ? .g() ? .g(),
                        e = a ? .g() ? .h() ? .g() ? .g();
                    if (d && 1 === d.length && d[0] === c && e && (0 < D(e, ph, 1).length || U(Fh) && 0 < D(e, qh, 3).length) && I(a, 17) === b.location.host) {
                        Gm(!0);
                        b = e;
                        break a
                    }
                }
                b = null
            }
        }
        b ? (c = new bj, a = D(b, ph, 1), c = Dc(c, 1, a), a = D(b, Xi, 2), c = Dc(c, 7, a), U(Fh) && 0 < D(b, qh, 3).length && (a = new rh, b = D(b, qh, 3), b = Dc(a,
            1, b), Bc(c, 6, b)), b = Ug(c)) : b = Wg(Error("invtag"));
        return b
    }

    function Sm(a) {
        Ak({
            l: a.l,
            R: G(a.g, 6),
            timeoutMs: 50,
            ca: b => {
                Tm(a, b)
            }
        })
    }

    function Tm(a, b) {
        $g(Zg(b, c => {
            Nm(a, c, !1)
        }), c => {
            Qm(c.message);
            a.h(null, null)
        })
    }

    function Qm(a) {
        Fj("abg::amalserr", {
            status: a,
            guarding: "true",
            timeout: 50,
            rate: .01
        }, .01)
    }
    class Mm {
        constructor(a, b, c, d) {
            this.l = a;
            this.g = b;
            this.i = c;
            this.h = d
        }
    };
    var Wm = (a, b, c, d) => {
        try {
            const e = cm(a, D(c, Xi, 7));
            if (e && am(e)) {
                F(e, 4) && (d = hh(d, new ih(null, {
                    google_package: F(e, 4)
                })));
                const f = new ak(a, b, c, e, d);
                mj(1E3, () => {
                    var g = new Pg;
                    (new Kk(a, f, g)).start();
                    return g.h
                }, a).then(na(Um, a), na(Vm, a))
            }
        } catch (e) {
            Xl(a, {
                atf: -1
            })
        }
    };
    const Um = a => {
            Xl(a, {
                atf: 1
            })
        },
        Vm = (a, b) => {
            (a.google_ama_state = a.google_ama_state || {}).exception = b;
            Xl(a, {
                atf: 0
            })
        };

    function Xm(a) {
        a.easpi = U(ai);
        a.asla = .4;
        a.asaa = -1;
        a.sedf = !1;
        a.asro = U(Zh);
        U(Vh) && (a.asiscm = !0);
        a.sefa = !0;
        U($h) && (a.sugawps = !0);
        U(Sh) && (a.ascmds = !0);
        const b = P(Od).h(Th.g, Th.defaultValue);
        b.length && (a.seiel = b.join("~"));
        U(Uh) && (a.slcwct = hi(Xh), a.sacwct = hi(Qh));
        U(Wh) && (a.slmct = hi(Yh), a.samct = hi(Rh))
    };

    function Ym(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (-1 != a.indexOf(b)) return !0;
        b = Zm(b);
        return "go" != b && -1 != a.indexOf(b) ? !0 : !1
    }

    function Zm(a) {
        let b = "";
        Dd(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    };
    Wa || Fa();

    function $m() {
        const a = {};
        P(Od).g(Bh.g, Bh.defaultValue) && (a.bust = P(Od).g(Bh.g, Bh.defaultValue));
        var b = dk();
        b = ik(b, 38, "");
        "" !== b && (a.sbust = b);
        return a
    };
    class an {
        constructor() {
            this.promise = new Promise(a => {
                this.resolve = a
            })
        }
    };

    function bn() {
        const {
            promise: a,
            resolve: b
        } = new an;
        return {
            promise: a,
            resolve: b
        }
    };

    function cn(a = () => {}) {
        p.google_llp || (p.google_llp = {});
        const b = p.google_llp;
        let c = b[7];
        if (c) return c;
        c = bn();
        b[7] = c;
        a();
        return c
    }

    function dn(a) {
        return cn(() => {
            zd(p.document, a)
        }).promise
    };

    function en(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), null == a.google_reactive_ads_global_state.sideRailPlasParam && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map)) : a.google_reactive_ads_global_state = new fn;
        return a.google_reactive_ads_global_state
    }
    class fn {
        constructor() {
            this.wasPlaTagProcessed = !1;
            this.wasReactiveAdConfigReceived = {};
            this.adCount = {};
            this.wasReactiveAdVisible = {};
            this.stateForType = {};
            this.reactiveTypeEnabledInAsfe = {};
            this.wasReactiveTagRequestSent = !1;
            this.reactiveTypeDisabledByPublisher = {};
            this.tagSpecificState = {};
            this.messageValidationEnabled = !1;
            this.floatingAdsStacking = new gn;
            this.sideRailProcessedFixedElements = new Set;
            this.sideRailAvailableSpace = new Map;
            this.sideRailPlasParam = new Map
        }
    }
    var gn = class {
        constructor() {
            this.maxZIndexRestrictions = {};
            this.nextRestrictionId = 0;
            this.maxZIndexListeners = []
        }
    };
    var hn = a => {
        if (p.google_apltlad || p !== p.top && !U(Nh) || !a.google_ad_client) return null;
        p.google_apltlad = !0;
        const b = {
                enable_page_level_ads: {
                    pltais: !0
                },
                google_ad_client: a.google_ad_client
            },
            c = b.enable_page_level_ads;
        Dd(a, (d, e) => {
            Ki[e] && "google_ad_client" !== e && (c[e] = d)
        });
        c.google_pgb_reactive = 7;
        Xm(c);
        if ("google_ad_section" in a || "google_ad_region" in a) c.google_ad_section = a.google_ad_section || a.google_ad_region;
        return b
    };

    function jn(a, b) {
        X(Q).ama_ran_on_page || mj(1001, () => {
            kn(new ln(a, b))
        }, p)
    }

    function kn(a) {
        Km(a.l, a.h, a.g.google_ad_client || "", (b, c) => {
            var d = a.l,
                e = a.g;
            X(Q).ama_ran_on_page || b && mn(d, e, b, c)
        })
    }
    class ln {
        constructor(a, b) {
            this.l = p;
            this.g = a;
            this.h = b
        }
    }

    function mn(a, b, c, d) {
        d && (rj(a).configSourceInAbg = d);
        nc(c, aj, 24) && (d = sj(a), d.availableAbg = !0, d.ablationFromStorage = !!C(c, aj, 24) ? .g() ? .g());
        if (fa(b.enable_page_level_ads) && 7 === b.enable_page_level_ads.google_pgb_reactive) {
            if (!cm(a, D(c, Xi, 7))) {
                Fj("amaait", {
                    value: "true"
                });
                return
            }
            Fj("amaait", {
                value: "false"
            })
        }
        X(Q).ama_ran_on_page = !0;
        C(c, Pi, 15) ? .g() && (X(a).enable_overlap_observer = !0);
        var e = C(c, Oi, 13);
        e && 1 === v(e, 1) ? (d = 0, (e = C(e, Ni, 6)) && Ec(e, 3) && (d = Ec(e, 3) || 0), rm(a, d)) : C(c, aj, 24) ? .g() ? .g() && (sj(a).ablatingThisPageview = !0, rm(a, 1));
        ee(3, [c.toJSON()]);
        const f = b.google_ad_client || "";
        b = Yl(fa(b.enable_page_level_ads) ? b.enable_page_level_ads : {});
        const g = hh(lh, new ih(null, b));
        Ej(782, () => {
            Wm(a, f, c, g)
        })
    };

    function nn(a, b) {
        a = a.document;
        for (var c = void 0, d = 0; !c || a.getElementById(c + "_host");) c = "aswift_" + d++;
        a = c;
        c = Number(b.google_ad_width || 0);
        b = Number(b.google_ad_height || 0);
        d = document.createElement("div");
        d.id = a + "_host";
        const e = d.style;
        e.border = "none";
        e.height = `${b}px`;
        e.width = `${c}px`;
        e.margin = "0px";
        e.padding = "0px";
        e.position = "relative";
        e.visibility = "visible";
        e.backgroundColor = "transparent";
        e.display = "inline-block";
        return {
            sb: a,
            Kb: d
        }
    };

    function on({
        wa: a,
        Ca: b
    }) {
        return a || ("dev" === b ? "dev" : "")
    };
    var pn = {
            google_analytics_domain_name: !0,
            google_analytics_uacct: !0,
            google_pause_ad_requests: !0,
            google_user_agent_client_hint: !0
        },
        qn = a => (a = a.innerText || a.innerHTML) && (a = a.replace(/^\s+/, "").split(/\r?\n/, 1)[0].match(/^\x3c!--+(.*?)(?:--+>)?\s*$/)) && RegExp("google_ad_client").test(a[1]) ? a[1] : null,
        rn = a => {
            if (a = a.innerText || a.innerHTML)
                if (a = a.replace(/^\s+|\s+$/g, "").replace(/\s*(\r?\n)+\s*/g, ";"), (a = a.match(/^\x3c!--+(.*?)(?:--+>)?$/) || a.match(/^\/*\s*<!\[CDATA\[(.*?)(?:\/*\s*\]\]>)?$/i)) && RegExp("google_ad_client").test(a[1])) return a[1];
            return null
        },
        sn = a => {
            switch (a) {
                case "true":
                    return !0;
                case "false":
                    return !1;
                case "null":
                    return null;
                case "undefined":
                    break;
                default:
                    try {
                        const b = a.match(/^(?:'(.*)'|"(.*)")$/);
                        if (b) return b[1] || b[2] || "";
                        if (/^[-+]?\d*(\.\d+)?$/.test(a)) {
                            const c = parseFloat(a);
                            return c === c ? c : void 0
                        }
                    } catch (b) {}
            }
        };

    function tn(a) {
        if (a.google_ad_client) var b = String(a.google_ad_client);
        else {
            if (null == (b = X(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client"))) {
                b: {
                    b = a.document.getElementsByTagName("script");a = a.navigator && a.navigator.userAgent || "";a = RegExp("appbankapppuzdradb|daumapps|fban|fbios|fbav|fb_iab|gsa/|messengerforios|naver|niftyappmobile|nonavigation|pinterest|twitter|ucbrowser|yjnewsapp|youtube", "i").test(a) || /i(phone|pad|pod)/i.test(a) &&
                    /applewebkit/i.test(a) && !/version|safari/i.test(a) && !je() ? qn : rn;
                    for (var c = b.length - 1; 0 <= c; c--) {
                        var d = b[c];
                        if (!d.google_parsed_script_for_pub_code && (d.google_parsed_script_for_pub_code = !0, d = a(d))) {
                            b = d;
                            break b
                        }
                    }
                    b = null
                }
                if (b) {
                    a = /(google_\w+) *= *(['"]?[\w.-]+['"]?) *(?:;|$)/gm;
                    for (c = {}; d = a.exec(b);) c[d[1]] = sn(d[2]);
                    b = c;
                    b = b.google_ad_client ? b.google_ad_client : ""
                } else b = ""
            }
            b = b ? ? ""
        }
        return b
    };
    var un = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function vn(a, b) {
        if (15 == b) {
            if (728 <= a) return 728;
            if (468 <= a) return 468
        } else if (90 == b) {
            if (200 <= a) return 200;
            if (180 <= a) return 180;
            if (160 <= a) return 160;
            if (120 <= a) return 120
        }
        return null
    };
    var wn = class extends L {
        constructor() {
            super()
        }
        getVersion() {
            return I(this, 2)
        }
    };

    function xn(a, b) {
        return y(a, 2, Vb(b))
    }

    function yn(a, b) {
        return y(a, 3, Vb(b))
    }

    function zn(a, b) {
        return y(a, 4, Vb(b))
    }

    function An(a, b) {
        return y(a, 5, Vb(b))
    }

    function Bn(a, b) {
        return y(a, 9, Vb(b))
    }

    function Cn(a, b) {
        return Dc(a, 10, b)
    }

    function Dn(a, b) {
        return y(a, 11, Gb(b))
    }

    function En(a, b) {
        return y(a, 1, Vb(b))
    }

    function Fn(a, b) {
        return y(a, 7, Gb(b))
    }
    var Gn = class extends L {
        constructor() {
            super()
        }
    };
    Gn.s = [10, 6];
    const Hn = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function ho() {
        var a = Q;
        if ("function" !== typeof a.navigator ? .userAgentData ? .getHighEntropyValues) return null;
        const b = a.google_tag_data ? ? (a.google_tag_data = {});
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Hn).then(c => {
            b.uach ? ? (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function io(a) {
        return Dn(Cn(An(xn(En(zn(Fn(Bn(yn(new Gn, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), a.fullVersionList ? .map(b => {
            var c = new wn;
            c = y(c, 1, Vb(b.brand));
            return y(c, 2, Vb(b.version))
        }) || []), a.wow64 || !1)
    }

    function jo() {
        return ho() ? .then(a => io(a)) ? ? null
    };

    function ko() {
        var a = Q;
        a.google_sa_impl && !a.document.getElementById("google_shimpl") && (delete a.google_sa_queue, delete a.google_sa_impl)
    }

    function lo(a, b) {
        b.google_ad_host || (a = vm(a)) && (b.google_ad_host = a)
    }

    function mo(a, b, c = "") {
        ko();
        Q.google_sa_queue || (Q.google_sa_queue = [], Q.google_process_slots = W.pa(215, () => {
            no(Q.google_sa_queue)
        }), a = oo(c, a, b), zd(Q.document, a).id = "google_shimpl")
    }

    function no(a) {
        const b = a.shift();
        "function" === typeof b && W.ea(216, b);
        a.length && p.setTimeout(W.pa(215, () => {
            no(a)
        }), 0)
    }

    function po(a, b) {
        a.google_sa_queue = a.google_sa_queue || [];
        a.google_sa_impl ? b() : a.google_sa_queue.push(b)
    }

    function oo(a, b, c) {
        b = G(c, 4) ? b.Eb : b.Fb;
        const d = {};
        a: {
            if (G(c, 4)) {
                if (a = a || tn(Q)) {
                    a = {
                        client: a,
                        plah: Q.location.host
                    };
                    break a
                }
                throw Error("PublisherCodeNotFoundForAma");
            }
            a = {}
        }
        qo(a, d);
        qo($m(), d);
        return gd(b, d)
    }

    function qo(a, b) {
        Dd(a, (c, d) => {
            void 0 === b[d] && (b[d] = c)
        })
    }

    function ro(a) {
        a: {
            var b = [p.top];
            var c = [];
            let e = 0,
                f;
            for (; f = b[e++];) {
                c.push(f);
                try {
                    if (f.frames)
                        for (let g = 0; g < f.frames.length && 1024 > b.length; ++g) b.push(f.frames[g])
                } catch {}
            }
            b = c;
            for (c = 0; c < b.length; c++) try {
                var d = b[c].frames.google_esf;
                if (d) {
                    Yd = d;
                    break a
                }
            } catch (g) {}
            Yd = null
        }
        if (Yd) return null;d = Ad("IFRAME");d.id = "google_esf";d.name = "google_esf";b = a.Nb;c = P(Od).g(Ph.g, Ph.defaultValue);
        "inhead" === c ? b = a.Lb : "nohtml" === c && (b = a.Mb);U(Ih) && (b = gd(b, {
            hello: "world"
        }));d.src = id(b).toString();d.style.display = "none";
        return d
    }

    function so(a, b, c, d) {
        const {
            sb: e,
            Kb: f
        } = nn(a, b);
        c.appendChild(f);
        to(a, c, b);
        c = b.google_start_time ? ? qa;
        const g = (new Date).getTime();
        b.google_lrv = on({
            wa: "m202311150101",
            Ca: I(d, 2)
        });
        b.google_async_iframe_id = e;
        b.google_start_time = c;
        b.google_bpp = g > c ? g - c : 1;
        a.google_sv_map = a.google_sv_map || {};
        a.google_sv_map[e] = b;
        po(a, () => {
            var h = f;
            if (!h || !h.isConnected)
                if (h = a.document.getElementById(String(b.google_async_iframe_id) + "_host"), null == h) throw Error("no_div");
            (h = a.google_sa_impl({
                pubWin: a,
                vars: b,
                innerInsElement: h
            })) &&
            W.X(911, h)
        })
    }

    function to(a, b, c) {
        var d = c.google_ad_output,
            e = c.google_ad_format,
            f = c.google_ad_width || 0,
            g = c.google_ad_height || 0;
        e || "html" !== d && null != d || (e = f + "x" + g);
        d = !c.google_ad_slot || c.google_override_format || !un[c.google_ad_width + "x" + c.google_ad_height] && "aa" === c.google_loader_used;
        e && d ? e = e.toLowerCase() : e = "";
        c.google_ad_format = e;
        if ("number" !== typeof c.google_reactive_sra_index || !c.google_ad_unit_key) {
            e = [c.google_ad_slot, c.google_orig_ad_format || c.google_ad_format, c.google_ad_type, c.google_orig_ad_width || c.google_ad_width,
                c.google_orig_ad_height || c.google_ad_height
            ];
            d = [];
            f = 0;
            for (g = b; g && 25 > f; g = g.parentNode, ++f) 9 === g.nodeType ? d.push("") : d.push(g.id);
            (d = d.join()) && e.push(d);
            c.google_ad_unit_key = Ed(e.join(":")).toString();
            e = [];
            for (d = 0; b && 25 > d; ++d) {
                f = (f = 9 !== b.nodeType && b.id) ? "/" + f : "";
                a: {
                    if (b && b.nodeName && b.parentElement) {
                        g = b.nodeName.toString().toLowerCase();
                        const h = b.parentElement.childNodes;
                        let k = 0;
                        for (let m = 0; m < h.length; ++m) {
                            const l = h[m];
                            if (l.nodeName && l.nodeName.toString().toLowerCase() === g) {
                                if (b === l) {
                                    g = "." + k;
                                    break a
                                }++k
                            }
                        }
                    }
                    g =
                    ""
                }
                e.push((b.nodeName && b.nodeName.toString().toLowerCase()) + f + g);
                b = b.parentElement
            }
            b = e.join() + ":";
            e = [];
            if (a) try {
                let h = a.parent;
                for (d = 0; h && h !== a && 25 > d; ++d) {
                    const k = h.frames;
                    for (f = 0; f < k.length; ++f)
                        if (a === k[f]) {
                            e.push(f);
                            break
                        }
                    a = h;
                    h = a.parent
                }
            } catch (h) {}
            c.google_ad_dom_fingerprint = Ed(b + e.join()).toString()
        }
    }

    function uo() {
        var a = yd(p);
        a && (a = en(a), a.tagSpecificState[1] || (a.tagSpecificState[1] = {
            debugCard: null,
            debugCardRequested: !1
        }))
    }

    function vo() {
        const a = jo();
        null != a && a.then(b => {
            a: {
                tb = !0;
                try {
                    var c = JSON.stringify(b.toJSON(), ac);
                    break a
                } finally {
                    tb = !1
                }
                c = void 0
            }
            Q.google_user_agent_client_hint = c
        });
        Nd()
    };

    function wo(a) {
        return b => !!(b.fa & a)
    }
    class Y extends Ci {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.fa = c;
            this.wb = d
        }
        qa() {
            return this.fa
        }
        h(a, b, c) {
            if (!b.google_ad_resize || U(Jh)) c.style.height = this.height() + "px", b.rpe = !0
        }
    };
    const xo = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        yo = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        zo = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function Ao(a) {
        var b = 0;
        a.P && b++;
        a.J && b++;
        a.K && b++;
        if (3 > b) return {
            M: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.P.split(",");
        const c = a.K.split(",");
        a = a.J.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            M: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (2 < b.length) return {
            M: "The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while " + `you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        const d = [],
            e = [];
        for (let g = 0; g <
            b.length; g++) {
            var f = Number(c[g]);
            if (Number.isNaN(f) || 0 === f) return {
                M: `Wrong value '${c[g]}' for ${"data-matched-content-rows-num"}.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || 0 === f) return {
                M: `Wrong value '${a[g]}' for ${"data-matched-content-columns-num"}.`
            };
            e.push(f)
        }
        return {
            K: d,
            J: e,
            ab: b
        }
    }

    function Bo(a) {
        return 1200 <= a ? {
            width: 1200,
            height: 600
        } : 850 <= a ? {
            width: a,
            height: Math.floor(.5 * a)
        } : 550 <= a ? {
            width: a,
            height: Math.floor(.6 * a)
        } : 468 <= a ? {
            width: a,
            height: Math.floor(.7 * a)
        } : {
            width: a,
            height: Math.floor(3.44 * a)
        }
    };
    const Co = Va("script");

    function Do(a, b, c) {
        null != a.fa && (c.google_responsive_formats = a.fa);
        null != a.W && (c.google_safe_for_responsive_override = a.W);
        null != a.h && (!0 === a.h ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = a.h));
        null != a.i && !0 !== a.i && (c.gfwrnher = a.i);
        var d = a.m || c.google_ad_width;
        null != d && (c.google_resizing_width = d);
        d = a.j || c.google_ad_height;
        null != d && (c.google_resizing_height = d);
        d = a.size().g(b);
        const e = a.size().height();
        if (!c.google_ad_resize || U(Jh)) {
            c.google_ad_width = d;
            c.google_ad_height = e;
            var f = a.size();
            b = f.g(b) + "x" + f.height();
            c.google_ad_format = b;
            c.google_responsive_auto_format = a.v;
            null != a.g && (c.armr = a.g);
            c.google_ad_resizable = !0;
            c.google_override_format = 1;
            c.google_loader_features_used = 128;
            !0 === a.h && (c.gfwrnh = a.size().height() + "px")
        }
        null != a.A && (c.gfwroml = a.A);
        null != a.B && (c.gfwromr = a.B);
        null != a.j && (c.gfwroh = a.j);
        null != a.m && (c.gfwrow = a.m);
        null != a.G && (c.gfwroz = a.G);
        b = yd(window) || window;
        Ym(b.location, "google_responsive_dummy_ad") && (Ta([1, 2, 3, 4, 5, 6, 7, 8], a.v) || 1 ===
            a.g) && 2 !== a.g && (a = JSON.stringify({
            googMsgType: "adpnt",
            key_value: [{
                key: "qid",
                value: "DUMMY_AD"
            }]
        }), c.dash = `<${Co}>window.top.postMessage('${a}', '*'); 
          </${Co}> 
          <div id="dummyAd" style="width:${d}px;height:${e}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${e}</p> 
            <p>Rendered size:${d}x${e}</p> 
          </div>`)
    }
    class Eo {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, m = null, l = null, n = null) {
            this.v = a;
            this.ba = b;
            this.fa = c;
            this.g = d;
            this.W = e;
            this.h = f;
            this.i = g;
            this.A = h;
            this.B = k;
            this.j = m;
            this.m = l;
            this.G = n
        }
        size() {
            return this.ba
        }
    };
    const Fo = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var Go = class extends Ci {
            g(a) {
                return Math.min(1200, Math.max(this.I, Math.round(a)))
            }
        },
        Jo = (a, b) => {
            Ho(a, b);
            if ("pedestal" == b.google_content_recommendation_ui_type) return new Eo(9, new Go(a, Math.floor(a * b.google_phwr)));
            var c = qd();
            468 > a ? c ? (c = a - 8 - 8, c = Math.floor(c / 1.91 + 70) + Math.floor(11 * (c * xo.mobile_banner_image_sidebyside + yo.mobile_banner_image_sidebyside) + 96), a = {
                aa: a,
                Z: c,
                J: 1,
                K: 12,
                P: "mobile_banner_image_sidebyside"
            }) : (a = Bo(a), a = {
                aa: a.width,
                Z: a.height,
                J: 1,
                K: 13,
                P: "image_sidebyside"
            }) : (a = Bo(a), a = {
                aa: a.width,
                Z: a.height,
                J: 4,
                K: 2,
                P: "image_stacked"
            });
            Io(b, a);
            return new Eo(9, new Go(a.aa, a.Z))
        },
        Ko = (a, b) => {
            Ho(a, b);
            var c = Ao({
                K: b.google_content_recommendation_rows_num,
                J: b.google_content_recommendation_columns_num,
                P: b.google_content_recommendation_ui_type
            });
            if (c.M) a = {
                aa: 0,
                Z: 0,
                J: 0,
                K: 0,
                P: "image_stacked",
                M: c.M
            };
            else {
                var d = 2 === c.ab.length && 468 <= a ? 1 : 0;
                var e = c.ab[d];
                e = 0 === e.indexOf("pub_control_") ? e : "pub_control_" + e;
                var f = zo[e];
                let g = c.J[d];
                for (; a / g < f && 1 < g;) g--;
                f = g;
                d = c.K[d];
                c = Math.floor(((a - 8 * f - 8) / f * xo[e] + yo[e]) * d + 8 *
                    d + 8);
                a = 1500 < a ? {
                    width: 0,
                    height: 0,
                    Gb: "Calculated slot width is too large: " + a
                } : 1500 < c ? {
                    width: 0,
                    height: 0,
                    Gb: "Calculated slot height is too large: " + c
                } : {
                    width: a,
                    height: c
                };
                a = {
                    aa: a.width,
                    Z: a.height,
                    J: f,
                    K: d,
                    P: e
                }
            }
            if (a.M) throw new V(a.M);
            Io(b, a);
            return new Eo(9, new Go(a.aa, a.Z))
        };

    function Ho(a, b) {
        if (0 >= a) throw new V("Invalid responsive width from Matched Content slot " + b.google_ad_slot + ": " + a + ". Please ensure to put this Matched Content slot into a non-zero width div container.");
    }

    function Io(a, b) {
        a.google_content_recommendation_ui_type = b.P;
        a.google_content_recommendation_columns_num = b.J;
        a.google_content_recommendation_rows_num = b.K
    };
    class Lo extends Ci {
        g() {
            return this.I
        }
        h(a, b, c) {
            Bi(a, c);
            if (!b.google_ad_resize || U(Jh)) c.style.height = this.height() + "px", b.rpe = !0
        }
    };
    const Mo = {
        "image-top": a => 600 >= a ? 284 + .414 * (a - 250) : 429,
        "image-middle": a => 500 >= a ? 196 - .13 * (a - 250) : 164 + .2 * (a - 500),
        "image-side": a => 500 >= a ? 205 - .28 * (a - 250) : 134 + .21 * (a - 500),
        "text-only": a => 500 >= a ? 187 - .228 * (a - 250) : 130,
        "in-article": a => 420 >= a ? a / 1.2 : 460 >= a ? a / 1.91 + 130 : 800 >= a ? a / 4 : 200
    };
    var No = class extends Ci {
            g() {
                return Math.min(1200, this.I)
            }
        },
        Oo = (a, b, c, d, e) => {
            var f = e.google_ad_layout || "image-top";
            if ("in-article" == f) {
                var g = a;
                if ("false" == e.google_full_width_responsive) a = g;
                else if (a = wi(b, c, g, .2, e), !0 !== a) e.gfwrnwer = a, a = g;
                else if (a = pi(b))
                    if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                        b: {
                            g = c;
                            for (let h = 0; 100 > h && g.parentElement; ++h) {
                                const k = g.parentElement.childNodes;
                                for (let m = 0; m < k.length; ++m) {
                                    const l = k[m];
                                    if (l != g && zi(b, l)) break b
                                }
                                g = g.parentElement;
                                g.style.width = "100%";
                                g.style.height = "auto"
                            }
                        }
                        Bi(b, c)
                    }
                else a = g;
                else a = g
            }
            if (250 > a) throw new V("Fluid responsive ads must be at least 250px wide: availableWidth=" + a);
            a = Math.min(1200, Math.floor(a));
            if (d && "in-article" != f) {
                f = Math.ceil(d);
                if (50 > f) throw new V("Fluid responsive ads must be at least 50px tall: height=" + f);
                return new Eo(11, new Ci(a, f))
            }
            if ("in-article" != f && (d = e.google_ad_layout_key)) {
                f = "" + d;
                c = Math.pow(10, 3);
                if (e = (d = f.match(/([+-][0-9a-z]+)/g)) && d.length)
                    for (b = [], g = 0; g < e; g++) b.push(parseInt(d[g], 36) / c);
                else b = null;
                if (!b) throw new V("Invalid data-ad-layout-key value: " + f);
                f = (a + -725) / 1E3;
                c = 0;
                d = 1;
                e = b.length;
                for (g = 0; g < e; g++) c += b[g] * d, d *= f;
                f = Math.ceil(1E3 * c - -725 + 10);
                if (isNaN(f)) throw new V("Invalid height: height=" + f);
                if (50 > f) throw new V("Fluid responsive ads must be at least 50px tall: height=" + f);
                if (1200 < f) throw new V("Fluid responsive ads must be at most 1200px tall: height=" + f);
                return new Eo(11, new Ci(a, f))
            }
            d = Mo[f];
            if (!d) throw new V("Invalid data-ad-layout value: " + f);
            c = Fi(c, b);
            b = pi(b);
            b = "in-article" !== f ||
                c || a !== b ? Math.ceil(d(a)) : Math.ceil(1.25 * d(a));
            return new Eo(11, "in-article" == f ? new No(a, b) : new Ci(a, b))
        };
    var Po = a => b => {
            for (let c = a.length - 1; 0 <= c; --c)
                if (!a[c](b)) return !1;
            return !0
        },
        Ro = (a, b) => {
            var c = Qo.slice(0);
            const d = c.length;
            let e = null;
            for (let f = 0; f < d; ++f) {
                const g = c[f];
                if (a(g)) {
                    if (!b || b(g)) return g;
                    null === e && (e = g)
                }
            }
            return e
        };
    var Z = [new Y(970, 90, 2), new Y(728, 90, 2), new Y(468, 60, 2), new Y(336, 280, 1), new Y(320, 100, 2), new Y(320, 50, 2), new Y(300, 600, 4), new Y(300, 250, 1), new Y(250, 250, 1), new Y(234, 60, 2), new Y(200, 200, 1), new Y(180, 150, 1), new Y(160, 600, 4), new Y(125, 125, 1), new Y(120, 600, 4), new Y(120, 240, 4), new Y(120, 120, 1, !0)],
        Qo = [Z[6], Z[12], Z[3], Z[0], Z[7], Z[14], Z[1], Z[8], Z[10], Z[4], Z[15], Z[2], Z[11], Z[5], Z[13], Z[9], Z[16]];
    var To = (a, b, c, d, e) => {
            "false" == e.google_full_width_responsive ? c = {
                C: a,
                D: 1
            } : "autorelaxed" == b && e.google_full_width_responsive || So(b) || e.google_ad_resize ? (b = xi(a, c, d, e), c = !0 !== b ? {
                C: a,
                D: b
            } : {
                C: pi(c) || a,
                D: !0
            }) : c = {
                C: a,
                D: 2
            };
            const {
                C: f,
                D: g
            } = c;
            return !0 !== g ? {
                C: a,
                D: g
            } : d.parentElement ? {
                C: f,
                D: g
            } : {
                C: a,
                D: g
            }
        },
        Wo = (a, b, c, d, e) => {
            const {
                C: f,
                D: g
            } = Ej(247, () => To(a, b, c, d, e));
            var h = !0 === g;
            const k = N(d.style.width),
                m = N(d.style.height),
                {
                    V: l,
                    T: n,
                    qa: x,
                    Za: u
                } = Uo(f, b, c, d, e, h);
            h = Vo(b, x);
            var w;
            const z = (w = Di(d, c, "marginLeft", N)) ? w + "px" :
                "",
                A = (w = Di(d, c, "marginRight", N)) ? w + "px" : "";
            w = Di(d, c, "zIndex") || "";
            return new Eo(h, l, x, null, u, g, n, z, A, m, k, w)
        },
        So = a => "auto" == a || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a),
        Uo = (a, b, c, d, e, f) => {
            b = Xo(c, a, b);
            let g;
            var h = !1;
            let k = !1;
            var m = 488 > pi(c);
            if (m) {
                g = ri(d, c);
                var l = Fi(d, c);
                h = !l && g;
                k = l && g
            }
            l = [Ei(a), wo(b)];
            l.push(Hi(m, c, d, k));
            null != e.google_max_responsive_height && l.push(Ii(e.google_max_responsive_height));
            m = [w => !w.wb];
            if (h || k) h = Ji(c, d), m.push(Ii(h));
            let n = Ro(Po(l), Po(m));
            if (!n) throw new V("No slot size for availableWidth=" +
                a);
            const {
                V: x,
                T: u
            } = Ej(248, () => {
                var w;
                a: if (f) {
                    if (e.gfwrnh && (w = N(e.gfwrnh))) {
                        w = {
                            V: new Lo(a, w),
                            T: !0
                        };
                        break a
                    }
                    w = a / 1.2;
                    var z = Math;
                    var A = z.min;
                    if (e.google_resizing_allowed || "true" == e.google_full_width_responsive) var E = Infinity;
                    else {
                        E = d;
                        let H = Infinity;
                        do {
                            var M = Di(E, c, "height", N);
                            M && (H = Math.min(H, M));
                            (M = Di(E, c, "maxHeight", N)) && (H = Math.min(H, M))
                        } while ((E = E.parentElement) && "HTML" != E.tagName);
                        E = H
                    }
                    z = A.call(z, w, E);
                    if (z < .5 * w || 100 > z) z = w;
                    w = {
                        V: new Lo(a, Math.floor(z)),
                        T: z < w ? 102 : !0
                    }
                } else w = {
                    V: n,
                    T: 100
                };
                return w
            });
            return "in-article" ===
                e.google_ad_layout && c.location && "#hffwroe2etoq" == c.location.hash ? {
                    V: Yo(a, c, d, x, e),
                    T: !1,
                    qa: b,
                    Za: g
                } : {
                    V: x,
                    T: u,
                    qa: b,
                    Za: g
                }
        };
    const Vo = (a, b) => {
            if ("auto" == a) return 1;
            switch (b) {
                case 2:
                    return 2;
                case 1:
                    return 3;
                case 4:
                    return 4;
                case 3:
                    return 5;
                case 6:
                    return 6;
                case 5:
                    return 7;
                case 7:
                    return 8
            }
            throw Error("bad mask");
        },
        Xo = (a, b, c) => {
            if ("auto" == c) c = Math.min(1200, pi(a)), b = .25 >= b / c ? 4 : 3;
            else {
                b = 0;
                for (let d in mi) - 1 != c.indexOf(d) && (b |= mi[d])
            }
            return b
        },
        Yo = (a, b, c, d, e) => {
            const f = e.google_ad_height || Di(c, b, "height", N);
            b = Oo(a, b, c, f, e).size();
            return b.I * b.height() > a * d.height() ? new Y(b.I, b.height(), 1) : d
        };
    var Zo = (a, b, c, d, e) => {
        var f;
        (f = pi(b)) ? 488 > pi(b) ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, Bi(b, c), f = {
            C: f,
            D: !0
        }) : f = {
            C: a,
            D: 5
        } : f = {
            C: a,
            D: 4
        }: f = {
            C: a,
            D: 10
        };
        const {
            C: g,
            D: h
        } = f;
        if (!0 !== h || a == g) return new Eo(12, new Ci(a, d), null, null, !0, h, 100);
        const {
            V: k,
            T: m,
            qa: l
        } = Uo(g, "auto", b, c, e, !0);
        return new Eo(1, k, l, 2, !0, h, m)
    };
    var ap = (a, b) => {
            const c = b.google_ad_format;
            if ("autorelaxed" == c) {
                a: {
                    if ("pedestal" != b.google_content_recommendation_ui_type)
                        for (const d of Fo)
                            if (null != b[d]) {
                                a = !0;
                                break a
                            }
                    a = !1
                }
                return a ? 9 : 5
            }
            if (So(c)) return 1;
            if ("link" === c) return 4;
            if ("fluid" == c) return "in-article" !== b.google_ad_layout || !a.location || "#hffwroe2etop" != a.location.hash && "#hffwroe2etoq" != a.location.hash ? 8 : ($o(b), 1);
            if (27 === b.google_reactive_ad_format) return $o(b), 1
        },
        cp = (a, b, c, d, e = !1) => {
            e = b.offsetWidth || (c.google_ad_resize || e) && Di(b, d, "width",
                N) || c.google_ad_width || 0;
            4 === a && (c.google_ad_format = "auto", a = 1);
            var f = (f = bp(a, e, b, c, d)) ? f : Wo(e, c.google_ad_format, d, b, c);
            f.size().h(d, c, b);
            Do(f, e, c);
            1 != a && (a = f.size().height(), b.style.height = a + "px")
        };
    const bp = (a, b, c, d, e) => {
            const f = d.google_ad_height || Di(c, e, "height", N);
            switch (a) {
                case 5:
                    const {
                        C: g,
                        D: h
                    } = Ej(247, () => To(b, d.google_ad_format, e, c, d));
                    !0 === h && b != g && Bi(e, c);
                    !0 === h ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                    return Jo(g, d);
                case 9:
                    return Ko(b, d);
                case 8:
                    return Oo(b, e, c, f, d);
                case 10:
                    return Zo(b, e, c, f, d)
            }
        },
        $o = a => {
            a.google_ad_format = "auto";
            a.armr = 3
        };

    function dp(a, b) {
        a.google_resizing_allowed = !0;
        a.ovlp = !0;
        a.google_ad_format = "auto";
        a.iaaso = !0;
        a.armr = b
    };

    function ep(a, b) {
        var c = yd(b);
        if (c) {
            c = pi(c);
            const d = Bd(a, b) || {},
                e = d.direction;
            if ("0px" === d.width && "none" !== d.cssFloat) return -1;
            if ("ltr" === e && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if ("rtl" === e && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function fp(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return a = parseInt(b, 10), isNaN(a) ? 0 : a;
            case "google_allow_expandable_ads":
                return /^true$/.test(b);
            default:
                return b
        }
    }

    function gp(a, b) {
        if (a.getAttribute("src")) {
            var c = a.getAttribute("src") || "",
                d = ud(c, "client");
            d && (b.google_ad_client = fp("google_ad_client", d));
            (c = ud(c, "host")) && (b.google_ad_host = fp("google_ad_host", c))
        }
        a = a.attributes;
        c = a.length;
        for (d = 0; d < c; d++) {
            var e = a[d];
            if (/data-/.test(e.name)) {
                const f = sa(e.name.replace("data-matched-content", "google_content_recommendation").replace("data", "google").replace(/-/g, "_"));
                b.hasOwnProperty(f) || (e = fp(f, e.value), null !== e && (b[f] = e))
            }
        }
    }

    function hp(a) {
        if (a = fe(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else return 12
    }

    function ip(a, b, c, d) {
        gp(a, b);
        if (c.document && c.document.body && !ap(c, b) && !b.google_reactive_ad_format) {
            var e = parseInt(a.style.width, 10),
                f = ep(a, c);
            if (0 < f && e > f) {
                var g = parseInt(a.style.height, 10);
                e = !!un[e + "x" + g];
                var h = f;
                if (e) {
                    const k = vn(f, g);
                    if (k) h = k, b.google_ad_format = k + "x" + g + "_0ads_al";
                    else throw new V("No slot size for availableWidth=" + f);
                }
                b.google_ad_resize = !0;
                b.google_ad_width = h;
                e || (b.google_ad_format = null, b.google_override_format = !0);
                f = h;
                a.style.width = `${f}px`;
                U(Jh) ? dp(b, 4) : (h = Wo(f, "auto", c, a, b),
                    g = f, h.size().h(c, b, a), Do(h, g, b), g = h.size(), b.google_responsive_formats = null, b.ovlp = !0, g.I > f && !e && (b.google_ad_width = g.I, a.style.width = `${g.I}px`))
            }
        }
        if (488 > pi(c)) {
            f = yd(c) || c;
            (e = a.offsetWidth) || (e = Di(a, c, "width", N));
            e = e || b.google_ad_width || 0;
            g = b.google_ad_client;
            if (d = Ym(f.location, "google_responsive_slot_preview") || U(Oh) || zm(f, 1, g, d)) b: if (b.google_reactive_ad_format || b.google_ad_resize || ap(c, b) || ti(a, b)) d = !1;
                else {
                    for (d = a; d; d = d.parentElement) {
                        f = Bd(d, c);
                        if (!f) {
                            b.gfwrnwer = 18;
                            d = !1;
                            break b
                        }
                        if (!Ta(["static",
                                "relative"
                            ], f.position)) {
                            b.gfwrnwer = 17;
                            d = !1;
                            break b
                        }
                    }
                    d = wi(c, a, e, .3, b);
                    !0 !== d ? (b.gfwrnwer = d, d = !1) : d = c === c.top ? !0 : !1
                }
            d ? (dp(b, 1), d = !0) : d = !1
        } else d = !1;
        if (e = ap(c, b)) cp(e, a, b, c, d);
        else {
            if (ti(a, b)) {
                if (d = Bd(a, c)) a.style.width = d.width, a.style.height = d.height, si(d, b);
                b.google_ad_width || (b.google_ad_width = a.offsetWidth);
                b.google_ad_height || (b.google_ad_height = a.offsetHeight);
                b.google_loader_features_used = 256;
                b.google_responsive_auto_format = hp(c)
            } else si(a.style, b);
            c.location && "#gfwmrp" == c.location.hash || 12 ==
                b.google_responsive_auto_format && "true" == b.google_full_width_responsive ? cp(10, a, b, c, !1) : .01 > Math.random() && 12 === b.google_responsive_auto_format && (a = xi(a.offsetWidth || parseInt(a.style.width, 10) || b.google_ad_width, c, a, b), !0 !== a ? (b.efwr = !1, b.gfwrnwer = a) : b.efwr = !0)
        }
    };

    function $f(a, b, c = 0) {
        0 < a.g.size || jp(a);
        c = Math.min(Math.max(0, c), 9);
        const d = a.g.get(c);
        d ? d.push(b) : a.g.set(c, [b])
    }

    function kp(a, b, c, d) {
        Zc(b, c, d);
        ok(a, () => $c(b, c, d))
    }

    function lp(a, b) {
        1 !== a.h && (a.h = 1, 0 < a.g.size && mp(a, b))
    }

    function jp(a) {
        a.l.document.visibilityState ? kp(a, a.l.document, "visibilitychange", b => {
            "hidden" === a.l.document.visibilityState && lp(a, b);
            "visible" === a.l.document.visibilityState && (a.h = 0)
        }) : "onpagehide" in a.l ? (kp(a, a.l, "pagehide", b => {
            lp(a, b)
        }), kp(a, a.l, "pageshow", () => {
            a.h = 0
        })) : kp(a, a.l, "beforeunload", b => {
            lp(a, b)
        })
    }

    function mp(a, b) {
        for (let c = 9; 0 <= c; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var np = class extends nk {
        constructor(a) {
            super();
            this.l = a;
            this.h = 0;
            this.g = new Map
        }
    };
    async function op(a, b) {
        var c = 10;
        return 0 >= c ? Promise.reject() : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e())
            }, 200)
        })
    };

    function pp(a) {
        const b = a.g.pc;
        return null !== b && 0 !== b ? b : a.g.pc = Rd(a.l)
    }

    function qp(a) {
        const b = a.g.wpc;
        return null !== b && "" !== b ? b : a.g.wpc = tn(a.l)
    }

    function rp(a, b) {
        var c = new uf;
        var d = pp(a);
        c = Mc(c, 1, d);
        d = qp(a);
        c = Oc(c, 2, d);
        c = Mc(c, 3, a.g.sd);
        return Mc(c, 7, Math.round(b || a.l.performance.now()))
    }
    async function sp(a) {
        await op(a.l, () => !(!pp(a) || !qp(a)))
    }

    function tp(a) {
        var b = P(up);
        b.j && Ej(1178, () => {
            const c = b.v;
            a(c);
            b.g.psi = c.toJSON()
        })
    }
    async function vp(a) {
        var b = P(up);
        if (b.j && !b.g.le.includes(1)) {
            b.g.le.push(1);
            var c = b.l.performance.now();
            await sp(b);
            a = jf(kf(mf(new nf, a), gf(ff(new hf, oi(b.l).scrollWidth), oi(b.l).scrollHeight)), gf(ff(new hf, pi(b.l)), oi(b.l).clientHeight));
            var d = new pf;
            U(Ch) ? (Oc(a, 4, b.i), Oc(d, 1, b.i)) : (Oc(a, 4, b.l ? .document ? .URL), Oc(d, 1, b.l ? .document ? .URL));
            var e = qi(b.l);
            0 !== e && lf(a, df(e));
            Wf(b.h, sf(rp(b, c), a));
            $f(b.m, () => {
                try {
                    if (null != b.g ? .psi) {
                        var f = Pc( of , ic(b.g.psi));
                        Bc(d, 2, f)
                    }
                } catch {}
                f = b.h;
                var g = rp(b);
                g = Cc(g, 8,
                    tf, d);
                Wf(f, g)
            }, 9)
        }
    }
    async function wp(a, b, c) {
        if (a.j && c.length && !a.g.lgdp.includes(Number(b))) {
            a.g.lgdp.push(Number(b));
            var d = a.l.performance.now();
            await sp(a);
            var e = a.h;
            a = rp(a, d);
            d = new cf;
            b = K(d, 1, b);
            c = tc(b, 2, c, Mb);
            c = Cc(a, 9, tf, c);
            Wf(e, c)
        }
    }
    async function xp(a, b) {
        await sp(a);
        var c = a.h;
        a = rp(a);
        a = Mc(a, 3, 1);
        b = Cc(a, 10, tf, b);
        Wf(c, b)
    }
    var up = class {
        constructor(a, b) {
            this.l = ge() || window;
            this.m = b ? ? new np(this.l);
            this.h = a ? ? new bg(2, "m202311150101", 100, 100, !0, this.m);
            this.g = gk(dk(), 33, () => {
                const c = hi(Ah);
                return {
                    sd: c,
                    ssp: 0 < c && Cd() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null
                }
            })
        }
        get j() {
            return this.g.ssp
        }
        get i() {
            return this.g.cu
        }
        set i(a) {
            this.g.cu = a
        }
        get v() {
            return null === this.g.psi ? new of : Pc( of , ic(this.g.psi))
        }
    };

    function yp() {
        var a = window;
        return "on" === p.google_adtest || "on" === p.google_adbreak_test || a.location.host.endsWith("h5games.usercontent.goog") ? a.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(b => Math.floor(Number(b))).filter(b => !isNaN(b) && 0 < b) || [] : []
    };

    function zp(a, b) {
        return a instanceof HTMLScriptElement && b.test(a.src) ? 0 : 1
    }

    function Ap(a) {
        var b = Q.document;
        if (b.currentScript) return zp(b.currentScript, a);
        for (const c of b.scripts)
            if (0 === zp(c, a)) return 0;
        return 1
    };

    function Bp(a, b) {
        return {
            [3]: {
                [55]: () => 0 === a,
                [23]: c => zm(Q, Number(c)),
                [24]: c => Cm(Number(c)),
                [61]: () => G(b, 6),
                [63]: () => G(b, 6) || ".google.ch" === I(b, 8)
            },
            [4]: {},
            [5]: {
                [6]: () => I(b, 15)
            }
        }
    };

    function Cp(a = p) {
        return a.ggeac || (a.ggeac = {})
    };

    function Dp(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function Ep(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    };

    function Fp(a, b) {
        try {
            const d = a.split(".");
            a = p;
            let e = 0,
                f;
            for (; null != a && e < d.length; e++) f = a, a = a[d[e]], "function" === typeof a && (a = f[d[e]]());
            var c = a;
            if (typeof c === b) return c
        } catch {}
    }
    var Gp = {
        [3]: {
            [8]: a => {
                try {
                    return null != ca(a)
                } catch {}
            },
            [9]: a => {
                try {
                    var b = ca(a)
                } catch {
                    return
                }
                if (a = "function" === typeof b) b = b && b.toString && b.toString(), a = "string" === typeof b && -1 != b.indexOf("[native code]");
                return a
            },
            [10]: () => window === window.top,
            [6]: a => Ta(P(Eg).g(), Number(a)),
            [27]: a => {
                a = Fp(a, "boolean");
                return void 0 !== a ? a : void 0
            },
            [60]: a => {
                try {
                    return !!p.document.querySelector(a)
                } catch {}
            },
            [69]: a => Dp(a, p.document),
            [70]: a => Ep(a, p.document)
        },
        [4]: {
            [3]: () => Jd(),
            [6]: a => {
                a = Fp(a, "number");
                return void 0 !== a ? a : void 0
            }
        },
        [5]: {
            [2]: () => window.location.href,
            [3]: () => {
                try {
                    return window.top.location.hash
                } catch {
                    return ""
                }
            },
            [4]: a => {
                a = Fp(a, "string");
                return void 0 !== a ? a : void 0
            }
        }
    };

    function Hp(a, b) {
        const c = new Map;
        for (const [f, g] of a[1].entries()) {
            var d = f,
                e = g;
            const {
                hb: h,
                bb: k,
                eb: m
            } = e[e.length - 1];
            c.set(d, h + k * m)
        }
        for (const f of b)
            for (const g of D(f, im, 2))
                if (0 !== D(g, hm, 2).length) {
                    b = Gc(Pb(v(g, 8)));
                    J(g, 4) && !J(g, 13) && (b = c.get(J(g, 4)) ? ? 0, d = Gc(Pb(v(g, 1))) * D(g, hm, 2).length, c.set(J(g, 4), b + d));
                    d = [];
                    for (e = 0; e < D(g, hm, 2).length; e++) {
                        const h = {
                            hb: b,
                            bb: Gc(Pb(v(g, 1))),
                            eb: D(g, hm, 2).length,
                            Ab: e,
                            Wa: J(f, 1),
                            ra: g,
                            O: D(g, hm, 2)[e]
                        };
                        d.push(h)
                    }
                    Ip(a[2], J(g, 10), d) || Ip(a[1], J(g, 4), d) || Ip(a[0], D(g, hm, 2)[0].getId(),
                        d)
                }
        return a
    }

    function Ip(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        a.get(b).push(...c);
        return !0
    };

    function Jp(a = Cd()) {
        return b => Ed(`${b} + ${a}`) % 1E3
    };
    const Kp = [12, 13, 20];

    function Lp(a, b, c) {
        a.g[c] || (a.g[c] = []);
        a = a.g[c];
        a.includes(b) || a.push(b)
    }

    function Mp(a, b, c, d) {
        const e = [];
        var f;
        if (f = 9 !== b) a.j[b] ? f = !0 : (a.j[b] = !0, f = !1);
        if (f) return dg(a.L, b, c, e, [], 4), e;
        f = Kp.includes(b);
        const g = [],
            h = P(hg).F,
            k = [];
        for (const x of [0, 1, 2])
            for (const [u, w] of a.la[x].entries()) {
                var m = u,
                    l = w;
                const z = new zf;
                var n = l.filter(A => A.Wa === b && !!a.h[A.O.getId()] && Ue(C(A.ra, Me, 3), h) && Ue(C(A.O, Me, 3), h));
                if (n.length)
                    for (const A of n) k.push(A.O);
                else if (!a.za && (2 === x ? (n = d[1], vc(z, 2, Af, Kb(m))) : n = d[0], m = n ? .(String(m)) ? ? (2 === x && 1 === J(l[0].ra, 11) ? void 0 : d[0](String(m))), void 0 !== m)) {
                    for (const A of l)
                        if (A.Wa ===
                            b) {
                            l = m - A.hb;
                            n = A.bb;
                            const E = A.eb,
                                M = A.Ab;
                            0 <= l && l < n * E && l % E === M && Ue(C(A.ra, Me, 3), h) && Ue(C(A.O, Me, 3), h) && (l = J(A.ra, 13), 0 !== l && void 0 !== l && (n = a.i[String(l)], void 0 !== n && n !== A.O.getId() ? fg(a.L, a.i[String(l)], A.O.getId(), l) : a.i[String(l)] = A.O.getId()), k.push(A.O))
                        }
                    0 !== yc(z, Af) && (uc(z, 3, Nb(m), 0), g.push(z))
                }
            }
        for (const x of k) d = x.getId(), e.push(d), Lp(a, d, f ? 4 : c), vg(D(x, Xe, 2), f ? xg() : [c], a.L, d);
        dg(a.L, b, c, e, g, 1);
        return e
    }

    function Np(a, b) {
        b = b.map(c => new jm(c)).filter(c => !Kp.includes(J(c, 1)));
        a.la = Hp(a.la, b)
    }

    function Op(a, b) {
        R(1, c => {
            a.h[c] = !0
        }, b);
        R(2, (c, d, e) => Mp(a, c, d, e), b);
        R(3, c => (a.g[c] || []).concat(a.g[4]), b);
        R(12, c => void Np(a, c), b);
        R(16, (c, d) => void Lp(a, c, d), b)
    }
    var Pp = class {
        constructor(a, b, c, {
            za: d = !1,
            tc: e = []
        } = {}) {
            this.la = a;
            this.L = c;
            this.j = {};
            this.za = d;
            this.g = {
                [b]: [],
                [4]: []
            };
            this.h = {};
            this.i = {};
            if (a = re()) {
                a = a.split(",") || [];
                for (const f of a)(a = Number(f)) && (this.h[a] = !0)
            }
            for (const f of e) this.h[f] = !0
        }
    };

    function Qp(a, b) {
        a.g = zg(14, b, () => {})
    }
    class Rp {
        constructor() {
            this.g = () => {}
        }
    }

    function Sp(a) {
        P(Rp).g(a)
    };

    function Tp({
        rb: a,
        F: b,
        config: c,
        mb: d = Cp(),
        nb: e = 0,
        L: f = new gg(C(a, km, 5) ? .g() ? ? 0, C(a, km, 5) ? .h() ? ? 0, C(a, km, 5) ? .i() ? ? !1),
        la: g = Hp({
            [0]: new Map,
            [1]: new Map,
            [2]: new Map
        }, D(a, jm, 2))
    }) {
        d.hasOwnProperty("init-done") ? (zg(12, d, () => {})(D(a, jm, 2).map(h => h.toJSON())), zg(13, d, () => {})(D(a, Xe, 1).map(h => h.toJSON()), e), b && zg(14, d, () => {})(b), Up(e, d)) : (Op(new Pp(g, e, f, c), d), Ag(d), Bg(d), Cg(d), Up(e, d), vg(D(a, Xe, 1), [e], f, void 0, !0), ig = ig || !(!c || !c.vb), Sp(Gp), b && Sp(b))
    }

    function Up(a, b = Cp()) {
        Dg(P(Eg), b, a);
        Vp(b, a);
        Qp(P(Rp), b);
        P(Od).m()
    }

    function Vp(a, b) {
        const c = P(Od);
        c.i = (d, e) => zg(5, a, () => !1)(d, e, b);
        c.j = (d, e) => zg(6, a, () => 0)(d, e, b);
        c.g = (d, e) => zg(7, a, () => "")(d, e, b);
        c.h = (d, e) => zg(8, a, () => [])(d, e, b);
        c.m = () => {
            zg(15, a, () => {})(b)
        }
    };

    function Wp(a, b) {
        b = {
            [0]: Jp(Rd(b).toString())
        };
        b = P(Eg).j(a, b);
        Ig.X(1085, wp(P(up), a, b))
    }
    var Xp = (a, b, c) => {
        var d = X(a);
        if (d.plle) Up(1, Cp(a));
        else {
            d.plle = !0;
            d = C(b, lm, 12);
            var e = G(b, 9);
            Tp({
                rb: d,
                F: Bp(c, b),
                config: {
                    za: e && !!a.google_disable_experiments,
                    vb: e
                },
                mb: Cp(a),
                nb: 1
            });
            if (c = I(b, 15)) c = Number(c), P(Eg).i(c);
            for (const f of rc(b, 19, Ob)) P(Eg).h(f);
            Wp(12, a);
            Wp(10, a);
            a = yd(a) || a;
            Ym(a.location, "google_mc_lab") && P(Eg).h(44738307);
            Ym(a.location, "google_auto_storify_swipeable") && P(Eg).h(44773747);
            Ym(a.location, "google_auto_storify_scrollable") && P(Eg).h(44773746)
        }
    };

    function Yp(a) {
        W.Da(b => {
            b.shv = String(a);
            b.mjsv = on({
                wa: "m202311150101",
                Ca: a
            });
            const c = P(Eg).g(),
                d = yp();
            b.eid = c.concat(d).join(",")
        })
    };

    function Zp(a) {
        var b = W;
        try {
            return Qc(a, Ke), new nm(JSON.parse(a))
        } catch (c) {
            b.H(838, c instanceof Error ? c : Error(String(c)), void 0, d => {
                d.jspb = String(a)
            })
        }
        return new nm
    };

    function $p(a) {
        if (a.g) return a.g;
        a.v && a.v(a.h) ? a.g = a.h : a.g = Id(a.h, a.B);
        return a.g ? ? null
    }
    var aq = class extends nk {
        constructor(a, b, c) {
            super();
            this.B = b;
            this.v = c;
            this.A = new Map;
            this.j = new Map;
            this.h = a
        }
    };
    const bq = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.ca({
                    xa: c ? ? void 0,
                    qb: d ? void 0 : 2
                })
            })
        },
        cq = {
            xb: a => a.ca,
            yb: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            Bb: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    xa: b.returnValue ? ? void 0,
                    qb: b.success ? void 0 : 2
                })
            }
        };
    var dq = class extends nk {
        constructor() {
            var a = Q;
            super();
            this.timeoutMs = {}.timeoutMs ? ? 500;
            this.caller = new aq(a, "__uspapiLocator", b => "function" === typeof b.__uspapi);
            this.caller.A.set("getDataWithCallback", bq);
            this.caller.j.set("getDataWithCallback", cq)
        }
    };
    var eq = Tc(class extends L {});
    const fq = (a, b) => {
            const c = {
                cb: d => {
                    d = eq(d);
                    b.ca({
                        xa: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        gq = {
            xb: a => a.ca,
            yb: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command,
                    spsp: a.spsp || void 0
                }
            }),
            Bb: (a, b) => {
                a({
                    xa: b
                })
            }
        };
    var hq = class extends nk {
        constructor() {
            var a = Q;
            super();
            this.g = this.h = !1;
            this.caller = new aq(a, "googlefcPresent");
            this.caller.A.set("getDataWithCallback", fq);
            this.caller.j.set("getDataWithCallback", gq)
        }
    };
    var iq = a => {
        Zc(window, "message", b => {
            let c;
            try {
                c = JSON.parse(b.data)
            } catch (d) {
                return
            }!c || "sc-cnf" !== c.googMsgType || a(c, b)
        })
    };

    function jq(a, b) {
        return null == b ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function kq(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function lq() {
        const a = new Set,
            b = Sj();
        try {
            if (!b) return a;
            const c = b.pubads();
            for (const d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch {}
        return a
    }

    function mq(a) {
        a = a.id;
        return null != a && (lq().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function nq(a, b, c) {
        if (!a.sources) return !1;
        switch (oq(a)) {
            case 2:
                const d = pq(a);
                if (d) return c.some(f => qq(d, f));
                break;
            case 1:
                const e = rq(a);
                if (e) return b.some(f => qq(e, f))
        }
        return !1
    }

    function oq(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (1 <= a.length) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function rq(a) {
        return sq(a, b => b.currentRect)
    }

    function pq(a) {
        return sq(a, b => b.previousRect)
    }

    function sq(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function qq(a, b) {
        const c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
    }

    function tq() {
        const a = Array.from(document.getElementsByTagName("iframe")).filter(mq),
            b = [...lq()].map(c => document.getElementById(c)).filter(c => null !== c);
        uq = window.scrollX;
        vq = window.scrollY;
        return wq = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function xq() {
        var a = new yq;
        if (U(pl)) {
            var b = window;
            if (!b.google_plmetrics && window.PerformanceObserver) {
                b.google_plmetrics = !0;
                b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                a.jb.pb && b.push("event");
                for (const c of b) b = {
                    type: c,
                    buffered: !0
                }, "event" === c && (b.durationThreshold = 40), zq(a).observe(b);
                Aq(a)
            }
        }
    }

    function Bq(a, b) {
        const c = uq !== window.scrollX || vq !== window.scrollY ? [] : wq,
            d = tq();
        for (const e of b.getEntries()) switch (b = e.entryType, b) {
            case "layout-shift":
                Cq(a, e, c, d);
                break;
            case "largest-contentful-paint":
                b = e;
                a.Ka = Math.floor(b.renderTime || b.loadTime);
                a.Ja = b.size;
                break;
            case "first-input":
                b = e;
                a.Ga = Number((b.processingStart - b.startTime).toFixed(3));
                a.Ha = !0;
                a.g.some(f => f.entries.some(g => e.duration === g.duration && e.startTime === g.startTime)) || Dq(a, e);
                break;
            case "longtask":
                b = Math.max(0, e.duration - 50);
                a.v +=
                    b;
                a.G = Math.max(a.G, b);
                a.ta += 1;
                break;
            case "event":
                Dq(a, e);
                break;
            default:
                vd(b, void 0)
        }
    }

    function zq(a) {
        a.L || (a.L = new PerformanceObserver(lj(640, b => {
            Bq(a, b)
        })));
        return a.L
    }

    function Aq(a) {
        const b = lj(641, () => {
                var d = document;
                2 === (d.prerendering ? 3 : {
                    visible: 1,
                    hidden: 2,
                    prerender: 3,
                    preview: 4,
                    unloaded: 5
                }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] || 0) && Eq(a)
            }),
            c = lj(641, () => void Eq(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.Fa = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            zq(a).disconnect()
        }
    }

    function Eq(a) {
        if (!a.Na) {
            a.Na = !0;
            zq(a).takeRecords();
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
            window.LayoutShift && (b += kq("cls", a.A), b += kq("mls", a.W), b += jq("nls", a.sa), window.LayoutShiftAttribution && (b += kq("cas", a.m), b += jq("nas", a.Ma), b += kq("was", a.Ra)), b += kq("wls", a.ua), b += kq("tls", a.Qa));
            window.LargestContentfulPaint && (b += jq("lcp", a.Ka), b += jq("lcps", a.Ja));
            window.PerformanceEventTiming && a.Ha && (b += jq("fid", a.Ga));
            window.PerformanceLongTaskTiming && (b += jq("cbt", a.v),
                b += jq("mbt", a.G), b += jq("nlt", a.ta));
            let d = 0;
            for (var c of document.getElementsByTagName("iframe")) mq(c) && d++;
            b += jq("nif", d);
            b += jq("ifi", ie(window));
            c = P(Eg).g();
            b += `&${"eid"}=${encodeURIComponent(c.join())}`;
            b += `&${"top"}=${p===p.top?1:0}`;
            b += a.Pa ? `&${"qqid"}=${encodeURIComponent(a.Pa)}` : jq("pvsid", Rd(p));
            window.googletag && (b += "&gpt=1");
            c = Math.min(a.g.length - 1, Math.floor((a.L ? a.Ia : performance.interactionCount || 0) / 50));
            0 <= c && (c = a.g[c].latency, 0 <= c && (b += jq("inp", c)));
            window.fetch(b, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            });
            a.Fa()
        }
    }

    function Cq(a, b, c, d) {
        if (!b.hadRecentInput) {
            a.A += Number(b.value);
            Number(b.value) > a.W && (a.W = Number(b.value));
            a.sa += 1;
            if (c = nq(b, c, d)) a.m += b.value, a.Ma++;
            if (5E3 < b.startTime - a.La || 1E3 < b.startTime - a.Oa) a.La = b.startTime, a.h = 0, a.i = 0;
            a.Oa = b.startTime;
            a.h += b.value;
            c && (a.i += b.value);
            a.h > a.ua && (a.ua = a.h, a.Ra = a.i, a.Qa = b.startTime + b.duration)
        }
    }

    function Dq(a, b) {
        Fq(a, b);
        const c = a.g[a.g.length - 1],
            d = a.B[b.interactionId];
        if (d || 10 > a.g.length || b.duration > c.latency) d ? (d.entries.push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
            id: b.interactionId,
            latency: b.duration,
            entries: [b]
        }, a.B[b.id] = b, a.g.push(b)), a.g.sort((e, f) => f.latency - e.latency), a.g.splice(10).forEach(e => {
            delete a.B[e.id]
        })
    }

    function Fq(a, b) {
        b.interactionId && (a.ba = Math.min(a.ba, b.interactionId), a.j = Math.max(a.j, b.interactionId), a.Ia = a.j ? (a.j - a.ba) / 7 + 1 : 0)
    }
    var yq = class {
            constructor() {
                var a = {
                    pb: U(bi)
                };
                this.i = this.h = this.sa = this.W = this.A = 0;
                this.Oa = this.La = Number.NEGATIVE_INFINITY;
                this.g = [];
                this.B = {};
                this.Ia = 0;
                this.ba = Infinity;
                this.Ga = this.Ja = this.Ka = this.Ma = this.Ra = this.m = this.Qa = this.ua = this.j = 0;
                this.Ha = !1;
                this.ta = this.G = this.v = 0;
                this.L = null;
                this.Na = !1;
                this.Fa = () => {};
                const b = document.querySelector("[data-google-query-id]");
                this.Pa = b ? b.getAttribute("data-google-query-id") : null;
                this.jb = a
            }
        },
        uq, vq, wq = [];
    let Gq = null;
    const Hq = [],
        Iq = new Map;
    let Jq = -1;

    function Kq(a) {
        return Li.test(a.className) && "done" !== a.dataset.adsbygoogleStatus
    }

    function Lq(a, b, c) {
        a.dataset.adsbygoogleStatus = "done";
        Mq(a, b, c)
    }

    function Mq(a, b, c) {
        var d = window;
        d.google_spfd || (d.google_spfd = ip);
        var e = b.google_reactive_ads_config;
        e || ip(a, b, d, c);
        lo(d, b);
        if (!Nq(a, b, d)) {
            if (e) {
                e = e.page_level_pubvars || {};
                if (X(Q).page_contains_reactive_tag && !X(Q).allow_second_reactive_tag) {
                    if (e.pltais) {
                        sm(!1);
                        return
                    }
                    throw new V("Only one 'enable_page_level_ads' allowed per page.");
                }
                X(Q).page_contains_reactive_tag = !0;
                sm(7 === e.google_pgb_reactive)
            }
            b.google_unique_id = he(d);
            Dd(pn, (f, g) => {
                b[g] = b[g] || d[g]
            });
            "sd" !== b.google_loader_used && (b.google_loader_used =
                "aa");
            b.google_reactive_tag_first = 1 === (X(Q).first_tag_on_page || 0);
            Ej(164, () => {
                so(d, b, a, c)
            })
        }
    }

    function Nq(a, b, c) {
        var d = b.google_reactive_ads_config,
            e = "string" === typeof a.className && RegExp("(\\W|^)adsbygoogle-noablate(\\W|$)").test(a.className),
            f = qm(c);
        if (f && f.Sa && "on" !== b.google_adtest && !e) {
            e = vi(a, c);
            const g = oi(c).clientHeight;
            e = 0 == g ? null : e / g;
            if (!f.va || f.va && (e || 0) >= f.va) return a.className += " adsbygoogle-ablated-ad-slot", c = c.google_sv_map = c.google_sv_map || {}, d = ha(a), b.google_element_uid = d, c[b.google_element_uid] = b, a.setAttribute("google_element_uid", String(d)), "slot" === f.Ib && (null !== Hd(a.getAttribute("width")) &&
                a.setAttribute("width", "0"), null !== Hd(a.getAttribute("height")) && a.setAttribute("height", "0"), a.style.width = "0px", a.style.height = "0px"), !0
        }
        if ((f = Bd(a, c)) && "none" === f.display && !("on" === b.google_adtest || 0 < b.google_reactive_ad_format || d)) return c.document.createComment && a.appendChild(c.document.createComment("No ad requested because of display:none on the adsbygoogle tag")), !0;
        a = null == b.google_pgb_reactive || 3 === b.google_pgb_reactive;
        return 1 !== b.google_reactive_ad_format && 8 !== b.google_reactive_ad_format ||
            !a ? !1 : (p.console && p.console.warn("Adsbygoogle tag with data-reactive-ad-format=" + String(b.google_reactive_ad_format) + " is deprecated. Check out page-level ads at https://www.google.com/adsense"), !0)
    }

    function Oq(a) {
        var b = document.getElementsByTagName("INS");
        for (let d = 0, e = b[d]; d < b.length; e = b[++d]) {
            var c = e;
            if (Kq(c) && "reserved" !== c.dataset.adsbygoogleStatus && (!a || e.id === a)) return e
        }
        return null
    }

    function Pq(a, b, c) {
        if (a && "shift" in a) {
            tp(e => {
                Jc(zc(e), 2) || (e = zc(e), Nc(e, 2))
            });
            for (var d = 20; 0 < a.length && 0 < d;) {
                try {
                    Qq(a.shift(), b, c)
                } catch (e) {
                    setTimeout(() => {
                        throw e;
                    })
                }--d
            }
        }
    }

    function Rq() {
        const a = Ad("INS");
        a.className = "adsbygoogle";
        a.className += " adsbygoogle-noablate";
        Kd(a);
        return a
    }

    function Sq(a, b) {
        const c = {},
            d = Jm(a.google_ad_client, b);
        Dd(ni, (g, h) => {
            !1 === a.enable_page_level_ads ? c[h] = !1 : a.hasOwnProperty(h) ? c[h] = a[h] : d.includes(g) && (c[h] = !1)
        });
        fa(a.enable_page_level_ads) && (c.page_level_pubvars = a.enable_page_level_ads);
        const e = Rq();
        Sd.body.appendChild(e);
        const f = {
            google_reactive_ads_config: c,
            google_ad_client: a.google_ad_client
        };
        f.google_pause_ad_requests = !!X(Q).pause_ad_requests;
        Lq(e, f, b);
        tp(g => {
            Jc(zc(g), 6) || (g = zc(g), Nc(g, 6))
        })
    }

    function Tq(a, b) {
        en(p).wasPlaTagProcessed = !0;
        const c = () => {
                Sq(a, b)
            },
            d = p.document;
        if (d.body || "complete" === d.readyState || "interactive" === d.readyState) Sq(a, b);
        else {
            const e = Yc(W.pa(191, c));
            Zc(d, "DOMContentLoaded", e);
            (new p.MutationObserver((f, g) => {
                d.body && (e(), g.disconnect())
            })).observe(d, {
                childList: !0,
                subtree: !0
            })
        }
    }

    function Qq(a, b, c) {
        const d = {};
        Ej(165, () => {
            Uq(a, d, b, c)
        }, e => {
            e.client = e.client || d.google_ad_client || a.google_ad_client;
            e.slotname = e.slotname || d.google_ad_slot;
            e.tag_origin = e.tag_origin || d.google_tag_origin
        })
    }

    function Vq(a) {
        delete a.google_checked_head;
        Dd(a, (b, c) => {
            Ki[c] || (delete a[c], b = c.replace("google", "data").replace(/_/g, "-"), p.console.warn(`AdSense head tag doesn't support ${b} attribute.`))
        })
    }

    function Wq(a, b) {
        var c = Q.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])') || Q.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])');
        if (c) {
            c.setAttribute("data-checked-head", "true");
            var d = X(window);
            if (d.head_tag_slot_vars) Xq(c);
            else {
                tp(g => {
                    g = zc(g);
                    uc(g, 7, Gb(!0), !1)
                });
                var e = {};
                gp(c, e);
                Vq(e);
                var f = dd(e);
                d.head_tag_slot_vars = f;
                c = {
                    google_ad_client: e.google_ad_client,
                    enable_page_level_ads: e
                };
                "bottom" ===
                e.google_overlays && (c.overlays = {
                    bottom: !0
                });
                delete e.google_overlays;
                Q.adsbygoogle || (Q.adsbygoogle = []);
                d = Q.adsbygoogle;
                d.loaded ? d.push(c) : d.splice && d.splice(0, 0, c);
                e.google_adbreak_test || b.h() ? .h() ? Yq(f, a) : iq(() => {
                    Yq(f, a)
                })
            }
        }
    }

    function Xq(a) {
        const b = X(window).head_tag_slot_vars,
            c = a.getAttribute("src") || "";
        if ((a = ud(c, "client") || a.getAttribute("data-ad-client") || "") && a !== b.google_ad_client) throw new V("Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page " + a + ", " + b.google_ad_client);
    }

    function Zq(a) {
        if ("object" === typeof a && null != a) {
            if ("string" === typeof a.type) return 2;
            if ("string" === typeof a.sound || "string" === typeof a.preloadAdBreaks) return 3
        }
        return 0
    }

    function Uq(a, b, c, d) {
        if (null == a) throw new V("push() called with no parameters.");
        tp(f => {
            Jc(zc(f), 3) || (f = zc(f), Nc(f, 3))
        });
        d.i() && $q(a, d.g().g(), I(d, 2));
        var e = Zq(a);
        if (0 !== e)
            if (d = tm(), d.first_slotcar_request_processing_time || (d.first_slotcar_request_processing_time = Date.now(), d.adsbygoogle_execution_start_time = qa), null == Gq) ar(a), Hq.push(a);
            else if (3 === e) {
            const f = Gq;
            Ej(787, () => {
                f.handleAdConfig(a)
            })
        } else Gj(730, Gq.handleAdBreak(a));
        else {
            qa = (new Date).getTime();
            mo(c, d, br(a));
            cr();
            a: {
                if (void 0 != a.enable_page_level_ads) {
                    if ("string" ===
                        typeof a.google_ad_client) {
                        e = !0;
                        break a
                    }
                    throw new V("'google_ad_client' is missing from the tag config.");
                }
                e = !1
            }
            if (e) tp(f => {
                Jc(zc(f), 4) || (f = zc(f), Nc(f, 4))
            }), dr(a, d);
            else if ((e = a.params) && Dd(e, (f, g) => {
                    b[g] = f
                }), "js" === b.google_ad_output) console.warn("Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads.");
            else {
                e = er(a.element);
                gp(e, b);
                c = X(p).head_tag_slot_vars || {};
                Dd(c, (f, g) => {
                    b.hasOwnProperty(g) || (b[g] = f)
                });
                if (e.hasAttribute("data-require-head") &&
                    !X(p).head_tag_slot_vars) throw new V("AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com.");
                if (!b.google_ad_client) throw new V("Ad client is missing from the slot.");
                if (c = 0 === (X(Q).first_tag_on_page || 0) && hn(b)) tp(f => {
                    Jc(zc(f), 5) || (f = zc(f), Nc(f, 5))
                }), fr(c);
                0 === (X(Q).first_tag_on_page || 0) && (X(Q).first_tag_on_page = 2);
                b.google_pause_ad_requests = !!X(Q).pause_ad_requests;
                Lq(e, b, d)
            }
        }
    }
    let gr = !1;

    function $q(a, b, c) {
        gr || (gr = !0, a = br(a) || tn(Q), Fj("predictive_abg", {
            a_c: a,
            p_c: b.join(),
            b_v: c
        }, .01))
    }

    function br(a) {
        return a.google_ad_client ? a.google_ad_client : (a = a.params) && a.google_ad_client ? a.google_ad_client : ""
    }

    function cr() {
        if (U(Hh)) {
            var a = qm(Q);
            if (!(a = a && a.Sa)) {
                a = Q;
                try {
                    var b = a.localStorage
                } catch (c) {
                    b = null
                }
                b = b ? em(b) : null;
                a = !(b && dm(b) && b)
            }
            a || rm(Q, 1)
        }
    }

    function fr(a) {
        Td(() => {
            en(p).wasPlaTagProcessed || p.adsbygoogle && p.adsbygoogle.push(a)
        })
    }

    function dr(a, b) {
        0 === (X(Q).first_tag_on_page || 0) && (X(Q).first_tag_on_page = 1);
        if (a.tag_partner) {
            var c = a.tag_partner;
            const d = X(p);
            d.tag_partners = d.tag_partners || [];
            d.tag_partners.push(c)
        }
        jn(a, b);
        Tq(a, b)
    }

    function er(a) {
        if (a) {
            if (!Kq(a) && (a.id ? a = Oq(a.id) : a = null, !a)) throw new V("'element' has already been filled.");
            if (!("innerHTML" in a)) throw new V("'element' is not a good DOM element.");
        } else if (a = Oq(), !a) throw new V("All ins elements in the DOM with class=adsbygoogle already have ads in them.");
        return a
    }

    function hr() {
        var a = new vk(Q),
            b = new dq,
            c = new hq,
            d = Q.__cmp ? 1 : 0;
        a = sk(a) ? 1 : 0;
        b = $p(b.caller) ? 1 : 0;
        c.h || (c.g = !!$p(c.caller), c.h = !0);
        c = c.g;
        Fj("cmpMet", {
            tcfv1: d,
            tcfv2: a,
            usp: b,
            fc: c ? 1 : 0,
            ptt: 9
        }, .001)
    }

    function ir(a) {
        var b = dk();
        jk(b, 26, !!Number(a))
    }

    function jr(a) {
        Number(a) ? X(Q).pause_ad_requests = !0 : (X(Q).pause_ad_requests = !1, a = () => {
            if (!X(Q).pause_ad_requests) {
                var b = {};
                let c;
                "function" === typeof window.CustomEvent ? c = new CustomEvent("adsbygoogle-pub-unpause-ad-requests-event", b) : (c = document.createEvent("CustomEvent"), c.initCustomEvent("adsbygoogle-pub-unpause-ad-requests-event", !!b.bubbles, !!b.cancelable, b.detail));
                Q.dispatchEvent(c)
            }
        }, p.setTimeout(a, 0), p.setTimeout(a, 1E3))
    }

    function kr(a) {
        a && a.call && "function" === typeof a && window.setTimeout(a, 0)
    }

    function Yq(a, b) {
        b = dn(gd(b.Hb, $m())).then(c => {
            null == Gq && (c.init(a), Gq = c, lr(c))
        });
        W.X(723, b);
        b.finally(() => {
            Hq.length = 0;
            Fj("slotcar", {
                event: "api_ld",
                time: Date.now() - qa,
                time_pr: Date.now() - Jq
            });
            U(di) && xp(P(up), qf(23))
        })
    }

    function lr(a) {
        for (const [c, d] of Iq) {
            var b = c;
            const e = d; - 1 !== e && (p.clearTimeout(e), Iq.delete(b))
        }
        for (b = 0; b < Hq.length; b++) {
            if (Iq.has(b)) continue;
            const c = Hq[b],
                d = Zq(c);
            Ej(723, () => {
                if (3 === d) a.handleAdConfig(c);
                else if (2 === d) {
                    var e = a.handleAdBreakBeforeReady(c);
                    W.X(730, e)
                }
            })
        }
    }

    function ar(a) {
        var b = Hq.length;
        if (2 === Zq(a) && "preroll" === a.type && null != a.adBreakDone) {
            var c = a.adBreakDone; - 1 === Jq && (Jq = Date.now());
            var d = p.setTimeout(() => {
                try {
                    c({
                        breakType: "preroll",
                        breakName: a.name,
                        breakFormat: "preroll",
                        breakStatus: "timeout"
                    }), Iq.set(b, -1), Fj("slotcar", {
                        event: "pr_to",
                        source: "adsbygoogle"
                    }), U(di) && xp(P(up), qf(22))
                } catch (e) {
                    console.error("[Ad Placement API] adBreakDone callback threw an error:", e instanceof Error ? e : Error(String(e)))
                }
            }, 1E3 * hi(ci));
            Iq.set(b, d)
        }
    }

    function mr() {
        var a = Q.document,
            b = ce `https://googleads.g.doubleclick.net`;
        const c = a.createElement("LINK");
        c.crossOrigin = "";
        a: {
            if (b instanceof fd) c.href = id(b).toString();
            else {
                if (-1 === wd.indexOf("preconnect")) throw Error('TrustedResourceUrl href attribute required with rel="preconnect"');
                if (b instanceof md) b = b instanceof md && b.constructor === md ? b.g : "type_error:SafeUrl";
                else {
                    c: {
                        try {
                            var d = new URL(b)
                        } catch (e) {
                            d = "https:";
                            break c
                        }
                        d = d.protocol
                    }
                    b = "javascript:" !== d ? b : void 0
                }
                if (void 0 === b) break a;
                c.href = b
            }
            c.rel =
            "preconnect"
        }
        a.head.appendChild(c)
    };
    (function(a, b, c, d = () => {}) {
        W.gb(Hj);
        Ej(166, () => {
            const e = new bg(2, a);
            try {
                Bb(n => {
                    var x = new Qf;
                    var u = new Pf;
                    try {
                        var w = Rd(window);
                        Mc(u, 1, w)
                    } catch (M) {}
                    try {
                        var z = P(Eg).g();
                        tc(u, 2, z, Mb)
                    } catch (M) {}
                    try {
                        Oc(u, 3, window.document.URL)
                    } catch (M) {}
                    x = Bc(x, 2, u);
                    u = new Of;
                    u = K(u, 1, 1191);
                    try {
                        var A = Ke(n ? .name) ? n.name : "Unknown error";
                        Oc(u, 2, A)
                    } catch (M) {}
                    try {
                        var E = Ke(n ? .message) ? n.message : `Caught ${n}`;
                        Oc(u, 3, E)
                    } catch (M) {}
                    try {
                        const M = Ke(n ? .stack) ? n.stack : Error().stack;
                        M && tc(u, 4, M.split(/\n\s*/), Ub)
                    } catch (M) {}
                    n = Bc(x, 1, u);
                    A =
                        new Nf;
                    try {
                        Oc(A, 1, "m202311150101")
                    } catch {}
                    Cc(n, 6, Rf, A);
                    Mc(n, 5, 1);
                    Tf(e, n)
                })
            } catch (n) {}
            const f = Zp(b);
            Yp(I(f, 2));
            pm(G(f, 6));
            kk(dk(), I(f, 24));
            d();
            ee(16, [1, f.toJSON()]);
            var g = ge(fe(Q)) || Q;
            const h = c(on({
                wa: a,
                Ca: I(f, 2)
            }), f);
            var k = null === Q.document.currentScript ? 1 : Ap(h.Jb);
            Am(g, f);
            Xp(g, f, k);
            U(xh) && mr();
            tp(n => {
                var x = Hc(n, 1) + 1;
                uc(n, 1, Nb(x), 0);
                Q.top === Q && (x = Hc(n, 2) + 1, uc(n, 2, Nb(x), 0));
                Jc(zc(n), 1) || (n = zc(n), Nc(n, 1))
            });
            Gj(1086, vp(0 === k));
            if (!Da() || 0 <= ta(Ia(), 11)) {
                Dj(U(gi));
                vo();
                Ml();
                try {
                    xq()
                } catch {}
                uo();
                Wq(h, f);
                g = window;
                k = g.adsbygoogle;
                if (!k || !k.loaded) {
                    Fj("new_abg_tag", {
                        value: `${G(f,16)}`,
                        host_v: `${G(f,22)}`,
                        frequency: .01
                    }, .01);
                    hr();
                    var m = {
                        push: n => {
                            Qq(n, h, f)
                        },
                        loaded: !0
                    };
                    try {
                        Object.defineProperty(m, "requestNonPersonalizedAds", {
                            set: ir
                        }), Object.defineProperty(m, "pauseAdRequests", {
                            set: jr
                        }), Object.defineProperty(m, "onload", {
                            set: kr
                        })
                    } catch {}
                    if (k)
                        for (var l of ["requestNonPersonalizedAds", "pauseAdRequests"]) void 0 !== k[l] && (m[l] = k[l]);
                    Pq(k, h, f);
                    g.adsbygoogle = m;
                    k && (m.onload = k.onload);
                    U(Dh) || (l = ro(h)) && document.documentElement.appendChild(l)
                }
            }
        })
    })("m202311150101",
        "undefined" === typeof sttc ? void 0 : sttc,
        function(a, b) {
            const c = 2012 < Hc(b, 1) ? `_fy${Hc(b,1)}` : "",
                d = I(b, 3);
            b = I(b, 2);
            ce `data:text/javascript,//show_ads_impl_preview.js`;
            return {
                Hb: ce `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}slotcar_library${c}.js`,
                Fb: ce `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}show_ads_impl${c}.js`,
                Eb: ce `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}show_ads_impl_with_ama${c}.js`,
                Nb: ce `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup${c}.html`,
                Lb: ce `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup_inhead${c}.html`,
                Mb: ce `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup_nohtml${c}.html`,
                Jb: /^(?:https?:)?\/\/(?:pagead2\.googlesyndication\.com|securepubads\.g\.doubleclick\.net)\/pagead\/(?:js\/)?(?:show_ads|adsbygoogle)\.js(?:[?#].*)?$/
            }
        });
}).call(this, "[2021,\"r20231109\",\"r20190131\",null,null,null,null,\".google.co.in\",null,null,null,[[[1082,null,null,[1]],[1277,null,null,[1]],[1305,null,null,[1]],[null,1130,null,[null,100]],[1270,null,null,[1]],[null,1032,null,[null,200],[[[12,null,null,null,4,null,\"Android\",[\"navigator.userAgent\"]],[null,500]]]],[1247,null,null,[1]],[null,1224,null,[null,0.01]],[null,1159,null,[null,500]],[576992373,null,null,[1]],[1207,null,null,[1]],[null,1263,null,[null,-1]],[null,1265,null,[null,-1]],[null,1264,null,[null,-1]],[1267,null,null,[1]],[1268,null,null,[1]],[null,66,null,[null,-1]],[null,65,null,[null,-1]],[1241,null,null,[1]],[1287,null,null,[1]],[1285,null,null,[1]],[1300,null,null,[1]],[null,null,null,[null,null,null,[\"en\",\"de\"]],null,1273],[1223,null,null,[1]],[null,null,null,[null,null,null,[\"44786015\",\"44786016\"]],null,1261],[1298,null,null,[1]],[1167,null,null,[1]],[1129,null,null,[1]],[1280,null,null,[1]],[45460962,null,null,[1]],[1230,null,null,[1]],[1229,null,null,[1]],[1231,null,null,[1]],[1292,null,null,[1]],[1199,null,null,[1]],[1161,null,null,[1]],[1288,null,null,[1]],[null,1072,null,[null,0.75]],[1101,null,null,[1]],[1198,null,null,[1]],[1206,null,null,[1]],[1190,null,null,[1]],[null,1245,null,[null,3600]],[1284,null,null,[1]],[null,566560958,null,[null,30000]],[null,506864295,null,[null,300]],[null,508040914,null,[null,100]],[null,547455356,null,[null,49]],[568515114,null,null,[]],[576840663,null,null,[1]],[null,null,null,[null,null,null,[\"1\",\"2\"]],null,556791602],[529362570,null,null,[1]],[null,null,549581487,[null,null,\"#1A73E8\"]],[null,null,549581486,[null,null,\"#FFFFFF\"]],[575790354,null,null,[1]],[null,561668774,null,[null,0.1]],[576554717,null,null,[1]],[576780579,null,null,[1]],[577117848,null,null,[1]],[null,469675170,null,[null,30000]],[570095433,null,null,[1]],[573506525,null,null,[1]],[573506524,null,null,[1]],[567362967,null,null,[1]],[570863962,null,null,[1]],[null,null,570879859,[null,null,\"control_1\\\\\\\\.\\\\\\\\d\"]],[null,570863961,null,[null,50]],[null,1085,null,[null,5]],[null,63,null,[null,30]],[null,1080,null,[null,5]],[1086,null,null,[1]],[10010,null,null,[1]],[null,1027,null,[null,10]],[null,57,null,[null,120]],[null,1079,null,[null,5]],[10009,null,null,[1]],[null,1050,null,[null,30]],[null,58,null,[null,120]],[10005,null,null,[1]],[555237685,null,null,[1]],[45460956,null,null,[1]],[45414947,null,null,[1]],[null,472785970,null,[null,500]],[557143911,null,null,[1]],[541943501,null,null,[1]],[null,550718588,null,[null,250]],[null,null,null,[null,null,null,[\"As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ\/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX\/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A\/ERL66fN363FkXxgDc6F1+ucRUkAhjEca9W3la6xaLnD2Y1lABsqmdaJmPNaUKPKVBRpyMKEhXYl7rSvrQw+AkAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A6OdGH3fVf4eKRDbXb4thXA4InNqDJDRhZ8U533U\/roYjp4Yau0T3YSuc63vmAs\/8ga1cD0E3A7LEq6AXk1uXgsAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934],[485990406,null,null,[]]],[[12,[[40,[[21065724],[21065725,[[203,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71],[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]],[1000,[[31078663,null,[2,[[4,null,70,null,null,null,null,[\"browsing-topics\"]],[4,null,8,null,null,null,null,[\"document.browsingTopics\"]]]]]]],[1000,[[31078664,null,[2,[[4,null,69,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,70,null,null,null,null,[\"browsing-topics\"]]]]]]]]],[1000,[[31078665,null,[2,[[4,null,8,null,null,null,null,[\"navigator.runAdAuction\"]],[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]],[1000,[[31078666,null,[2,[[4,null,69,null,null,null,null,[\"join-ad-interest-group\"]],[1,[[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]]]],[1000,[[31078667,null,[2,[[4,null,69,null,null,null,null,[\"run-ad-auction\"]],[1,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]]]]]]]]],[1000,[[31078668,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[1000,[[31078669,null,[2,[[4,null,69,null,null,null,null,[\"attribution-reporting\"]],[1,[[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]]]],[1000,[[31078670,null,[4,null,70,null,null,null,null,[\"shared-storage\"]]]]],[1000,[[31078671,null,[2,[[4,null,69,null,null,null,null,[\"shared-storage\"]],[1,[[4,null,70,null,null,null,null,[\"shared-storage\"]]]]]]]]]]],[10,[[50,[[31067422],[31067423,[[null,1032,null,[]]]],[44776369],[44792510],[44804781],[44806359]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[10,[[31078019],[31078020]]],[10,[[31078237],[31078238,[[1302,null,null,[1]]]]]],[500,[[31078297],[31078301,[[1230,null,null,[]],[1229,null,null,[]],[1231,null,null,[]]]]],null,87],[null,[[31078995],[31078996,[[45459826,null,null,[1]],[531007060,null,null,[1]],[45430975,null,null,[1]],[531582260,null,null,[1]]]]]],[50,[[31079265],[31079266,[[573506525,null,null,[]]]]]],[50,[[31079437],[31079438,[[573506524,null,null,[]]]]]],[10,[[31079714],[31079715,[[1275,null,null,[1]]]]]],[10,[[31079721],[31079722,[[570879858,null,null,[1]]]]],null,102],[50,[[31079758],[31079759,[[1298,null,null,[]],[1292,null,null,[]]]]]],[1000,[[31079811,[[null,null,14,[null,null,\"31079811\"]]],[6,null,null,null,6,null,\"31079811\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31079812,[[null,null,14,[null,null,\"31079812\"]]],[6,null,null,null,6,null,\"31079812\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[10,[[31079825],[31079826,[[null,null,null,[null,null,null,[\"1\",\"2\",\"4\",\"6\"]],null,556791602]]]]],[1000,[[31079860,[[null,null,14,[null,null,\"31079860\"]]],[6,null,null,null,6,null,\"31079860\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31079861,[[null,null,14,[null,null,\"31079861\"]]],[6,null,null,null,6,null,\"31079861\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1,[[42531513],[42531514,[[316,null,null,[1]]]]]],[1,[[42531644],[42531645,[[368,null,null,[1]]]],[42531646,[[369,null,null,[1]],[368,null,null,[1]]]]]],[50,[[42531705],[42531706]]],[1,[[42532242],[42532243,[[1256,null,null,[1]],[290,null,null,[1]]]]]],[1,[[42532262],[42532263,[[null,1263,null,[null,16]]]],[42532264,[[null,1263,null,[null,4294967296]]]],[42532265,[[null,1265,null,[null,60]],[null,1264,null,[null,0.2]],[1266,null,null,[1]]]],[42532266,[[null,1263,null,[null,4294967296]],[null,1265,null,[null,60]],[null,1264,null,[null,0.2]],[1266,null,null,[1]]]],[42532267,[[null,1263,null,[null,16]],[null,1265,null,[null,60]],[null,1264,null,[null,0.2]],[1266,null,null,[1]]]],[42532268,[[1266,null,null,[1]]]]]],[1,[[42532360],[42532361,[[1260,null,null,[1]],[1291,null,null,[1]]]]],null,90],[1,[[42532362],[42532363]]],[50,[[42532523],[42532524,[[1300,null,null,[]]]]]],[null,[[42532525],[42532526]]],[10,[[42532598],[42532599,[[1271,null,null,[1]]]],[42532600,[[1272,null,null,[1]]]],[42532601,[[1271,null,null,[1]],[1272,null,null,[1]]]]]],[1,[[44719338],[44719339,[[334,null,null,[1]],[null,54,null,[null,100]],[null,66,null,[null,10]],[null,65,null,[null,1000]]]]]],[10,[[44776368],[44779257]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[10,[[44785292],[44785293,[[1239,null,null,[1]]]]]],[10,[[44785294],[44785295]]],[1,[[44795552],[44795553,[[1260,null,null,[1]]]]],null,90],[1,[[44795554],[44795555]]],[100,[[44795921],[44795922,[[1222,null,null,[1]]]],[44798934,[[1222,null,null,[1]]]]]],[10,[[44800658],[44800659,[[1185,null,null,[1]]]]],null,76],[1,[[44801778],[44801779,[[506914611,null,null,[1]]]]],[4,null,55]],[1000,[[44802674,[[506852289,null,null,[1]]],[12,null,null,null,2,null,\"smitmehta\\\\.com\/\"]]],[4,null,55]],[10,[[44805914],[44805915,[[571859167,null,null,[1]]]]],[4,null,55]],[50,[[44807405],[44807406,[[570863962,null,null,[]]]]],null,102],[50,[[44807749],[44807751,[[1185,null,null,[1]]]]],null,76],[10,[[44807750],[44807752,[[1185,null,null,[1]]]]],null,76],[50,[[44807753],[44807754,[[1185,null,null,[1]]]]],null,76],[50,[[44809003,[[1289,null,null,[1]]]],[44809004,[[1289,null,null,[1]],[null,null,1307,[null,null,\"inhead\"]]]],[44809005,[[1289,null,null,[1]],[null,null,1307,[null,null,\"nohtml\"]]]]]],[100,[[44809314],[44809315,[[null,572636916,null,[null,50]],[572636914,null,null,[1]],[null,572636915,null,[null,300]]]],[44809316,[[null,572636916,null,[null,25]],[572636914,null,null,[1]],[null,572636915,null,[null,150]]]],[44809317,[[null,572636916,null,[null,1]],[572636914,null,null,[1]],[null,572636915,null,[null,1]]]]],[4,null,55]]]],[11,[[1000,[[31079716,null,[4,null,6,null,null,null,null,[\"31079714\"]]]],[4,null,8,null,null,null,null,[\"__gpp\"]],88,null,null,null,null,null,null,null,null,9],[1000,[[31079717,null,[4,null,6,null,null,null,null,[\"31079715\"]]]],[4,null,8,null,null,null,null,[\"__gpp\"]],88,null,null,null,null,null,null,null,null,9],[1000,[[31079729,null,[4,null,6,null,null,null,null,[\"31079721\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],103,null,null,null,null,null,null,null,null,16],[1000,[[31079730,null,[4,null,6,null,null,null,null,[\"31079722\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],103,null,null,null,null,null,null,null,null,16],[1000,[[44807497,null,[4,null,6,null,null,null,null,[\"44807405\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],103,null,null,null,null,null,null,null,null,16],[1000,[[44807498,null,[4,null,6,null,null,null,null,[\"44807406\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],103,null,null,null,null,null,null,null,null,16]]],[17,[[1,[[44797663,[[null,506871937,null,[null,44797663]],[1120,null,null,[1]]]],[44797664,[[null,506871937,null,[null,44797664]],[160889229,null,null,[1]],[1120,null,null,[1]]]]],[4,null,55],null,null,null,null,300,null,123],[95,[[44806139,[[null,506871937,null,[null,44806139]]]],[44806140,[[545453532,null,null,[1]],[null,506871937,null,[null,44806140]],[1120,null,null,[1]]]],[44806141,[[null,506871937,null,[null,44806141]],[1120,null,null,[1]]]]],[4,null,55],null,null,null,null,610,null,123],[1,[[44806145,[[null,506871937,null,[null,44806145]],[1120,null,null,[1]]]],[44806146,[[566279275,null,null,[1]],[null,506871937,null,[null,44806146]],[1120,null,null,[1]]]],[44806147,[[566279276,null,null,[1]],[null,506871937,null,[null,44806147]],[1120,null,null,[1]]]]],[4,null,55],null,null,null,null,910,null,123],[500,[[44807763],[44807764,[[576499818,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,126],[500,[[44808148],[44808149,[[575790353,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,124],[500,[[44808284],[44808285,[[577127756,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,125],[500,[[44809071],[44809072,[[561639568,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,128],[50,[[318512601]],null,null,null,null,null,600,null,102],[50,[[318512602,[[541943501,null,null,[]],[1284,null,null,[]]]]],null,null,null,null,null,650,null,102]]]],null,null,[null,1000,1,1000]],null,[[\"ca-pub-5173402840022387\",\"ca-pub-4110520444943253\",\"ca-pub-9945624415527048\",\"ca-pub-1427805825892953\"],[null,[]]],null,null,null,1139858143,[44759876,44759927,44759837]]");