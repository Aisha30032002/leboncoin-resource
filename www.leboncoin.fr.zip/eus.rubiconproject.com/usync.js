var comments = 'User-Sync: generated: 2023-11-29 03:57:42 PST';
var rtb_sync = {
    "consent_rate": 100,
    "reset_rate": 40,
    "ttl": 14,
    "sample": 100,
    "max_pixels": 16,
    "pixel_sets": {
        "rtb": {
            "sample": 100,
            "pixels": {
                "1185": {
                    "ttl": 7,
                    "img": "https:\/\/ad.turn.com\/r\/cs?pid=6",
                    "secure": {
                        "img": "https:\/\/ad.turn.com\/r\/cs?pid=6"
                    },
                    "priority": 7,
                    "partner": "amobee"
                },
                "1902": {
                    "priority": 17,
                    "ttl": 2,
                    "img": "https:\/\/cms.quantserve.com\/pixel\/p-e4m3Yko6bFYVc.gif?idmatch=0",
                    "secure": {
                        "img": "https:\/\/cms.quantserve.com\/pixel\/p-e4m3Yko6bFYVc.gif?idmatch=0"
                    },
                    "partner": "quantcast"
                },
                "1986": {
                    "priority": 7,
                    "ttl": 1,
                    "img": "https:\/\/ib.adnxs.com\/getuidnb?http%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D4894%26nid%3D1986%26put%3D$UID%26expires%3D30",
                    "secure": {
                        "img": "https:\/\/secure.adnxs.com\/getuidnb?https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D4894%26nid%3D1986%26put%3D$UID%26expires%3D30"
                    },
                    "partner": "xandr"
                },
                "2046": {
                    "priority": 13,
                    "ttl": 7,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=2046&pt=n&a=1",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=2046&pt=n&a=1"
                    },
                    "partner": "conversant"
                },
                "2082": {
                    "priority": 16,
                    "img": "https:\/\/ums.acuityplatform.com\/tum?umid=2",
                    "secure": {
                        "img": "https:\/\/ums.acuityplatform.com\/tum?umid=2"
                    },
                    "partner": "acuity"
                },
                "2132": {
                    "priority": 12,
                    "img": "https:\/\/um.simpli.fi\/rb_match",
                    "secure": {
                        "img": "https:\/\/um.simpli.fi\/rb_match"
                    },
                    "partner": "simpli.fi"
                },
                "2135": {
                    "img": "https:\/\/d5p.de17a.com\/cookies\/rubicon",
                    "secure": {
                        "img": "https:\/\/d5p.de17a.com\/cookies\/rubicon"
                    },
                    "partner": "delta-rtb",
                    "country": ["se", "dk", "nl", "de", "fi", "no"]
                },
                "2149": {
                    "priority": 6,
                    "img": "https:\/\/dis.criteo.com\/dis\/usersync.aspx?r=6&p=70&cp=Rubicon&cu=1&url=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D6434%26nid%3D2149%26put%3D%40%40CRITEO_USERID%40%40",
                    "secure": {
                        "img": "https:\/\/dis.criteo.com\/dis\/usersync.aspx?r=6&p=70&cp=Rubicon&cu=1&url=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D6434%26nid%3D2149%26put%3D%40%40CRITEO_USERID%40%40"
                    },
                    "partner": "criteo"
                },
                "2231": {
                    "img": "https:\/\/id.sharedid.org\/usync?redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D624210%26nid%3D2231%26put%3D%7Buser_token%7D",
                    "priority": 20,
                    "sample": 0,
                    "secure": {
                        "img": "https:\/\/id.sharedid.org\/usync?redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D624210%26nid%3D2231%26put%3D%7Buser_token%7D"
                    },
                    "partner": "myads",
                    "country": ["us", "ca", "mx"]
                },
                "2238": {
                    "sample": 0,
                    "priority": 10,
                    "img": "https:\/\/pixel-sync.sitescout.com\/dmp\/pixelSync?nid=1",
                    "secure": {
                        "img": "https:\/\/pixel-sync.sitescout.com\/dmp\/pixelSync?nid=1"
                    },
                    "partner": "basis"
                },
                "2249": {
                    "ttl": 1,
                    "img": "https:\/\/cm.g.doubleclick.net\/pixel?google_nid=rubicon&google_cm&google_sc",
                    "priority": 1,
                    "secure": {
                        "img": "https:\/\/cm.g.doubleclick.net\/pixel?google_nid=rubicon&google_cm&google_sc"
                    },
                    "partner": "dv360"
                },
                "2307": {
                    "img": "https:\/\/match.adsrvr.org\/track\/cmf\/rubicon",
                    "priority": 1,
                    "secure": {
                        "img": "https:\/\/match.adsrvr.org\/track\/cmf\/rubicon"
                    },
                    "partner": "thetradedesk"
                },
                "2313": {
                    "img": "https:\/\/rbp.mxptint.net\/sn.ashx",
                    "priority": 17,
                    "secure": {
                        "img": "https:\/\/rbp.mxptint.net\/sn.ashx"
                    },
                    "partner": "valassis",
                    "country": ["us", "ca"]
                },
                "2494": {
                    "img": "https:\/\/um4.eqads.com\/um\/rc",
                    "region": ["na"],
                    "secure": {
                        "img": "https:\/\/um4.eqads.com:443\/um\/rc"
                    },
                    "partner": "eq-ads"
                },
                "2528": {
                    "img": "https:\/\/sync.intentiq.com\/profiles_engine\/ProfilesEngineServlet?at=20&mi=10&dpi=54",
                    "secure": {
                        "img": "https:\/\/sync.intentiq.com\/profiles_engine\/ProfilesEngineServlet?at=20&mi=10&dpi=54"
                    },
                    "partner": "intent-iq",
                    "country": ["us", "ca"]
                },
                "2540": {
                    "priority": 13,
                    "img": "https:\/\/tr.blismedia.com\/v1\/api\/sync\/rubicon",
                    "secure": {
                        "img": "https:\/\/tr.blismedia.com\/v1\/api\/sync\/rubicon"
                    },
                    "partner": "blis"
                },
                "2596": {
                    "ttl": 7,
                    "priority": 20,
                    "img": "https:\/\/p.rfihub.com\/cm?in=1&pub=64",
                    "secure": {
                        "img": "https:\/\/p.rfihub.com\/cm?in=1&pub=64"
                    },
                    "partner": "zeta"
                },
                "2650": {
                    "priority": 18,
                    "img": "https:\/\/match.adsby.bidtheatre.com\/rubiconmatch",
                    "secure": {
                        "img": "https:\/\/match.adsby.bidtheatre.com\/rubiconmatch"
                    },
                    "partner": "bid-theatre"
                },
                "2676": {
                    "img": "https:\/\/c1.adform.net\/serving\/cookie\/match?party=1164",
                    "secure": {
                        "img": "https:\/\/c1.adform.net\/serving\/cookie\/match?party=1164"
                    },
                    "priority": 6,
                    "partner": "adform"
                },
                "2731": {
                    "img": "https:\/\/cm.ctnsnet.com\/int\/cm?exc=2&redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D14965%26nid%3D2731%26put%3D%5Buser_id%5D",
                    "secure": {
                        "img": "https:\/\/cm.ctnsnet.com\/int\/cm?exc=2&redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D14965%26nid%3D2731%26put%3D%5Buser_id%5D"
                    },
                    "region": ["eu", "au"],
                    "partner": "crimson-tangerine"
                },
                "2760": {
                    "img": "https:\/\/x.bidswitch.net\/sync?ssp=rubicon",
                    "secure": {
                        "img": "https:\/\/x.bidswitch.net\/sync?ssp=rubicon"
                    },
                    "partner": "bidswitch"
                },
                "2820": {
                    "img": "https:\/\/id5-sync.com\/i\/175\/9.gif",
                    "secure": {
                        "img": "https:\/\/id5-sync.com\/i\/175\/9.gif"
                    },
                    "partner": "platform-161",
                    "country": ["nl", "us"]
                },
                "2861": {
                    "priority": 5,
                    "img": "https:\/\/sync.ipredictive.com\/d\/sync\/cookie\/generic?https:\/\/pixel.rubiconproject.com\/tap.php?v=17149&nid=2861&put=${ADELPHIC_CUID}&expires=30",
                    "secure": {
                        "img": "https:\/\/sync.ipredictive.com\/d\/sync\/cookie\/generic?https:\/\/pixel.rubiconproject.com\/tap.php?v=17149&nid=2861&put=${ADELPHIC_CUID}&expires=30"
                    },
                    "partner": "adelphic"
                },
                "2915": {
                    "img": "https:\/\/sync.smartadserver.com\/getuid?gdpr=0&url=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D32128%26nid%3D2915%26put%3D[sas_uid]",
                    "secure": {
                        "img": "https:\/\/sync.smartadserver.com\/getuid?gdpr=0&url=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D32128%26nid%3D2915%26put%3D[sas_uid]"
                    },
                    "partner": "liquidm"
                },
                "2966": {
                    "img": "https:\/\/rtb.adentifi.com\/CookieSyncRubicon",
                    "secure": {
                        "img": "https:\/\/rtb.adentifi.com\/CookieSyncRubicon"
                    },
                    "partner": "adheorent"
                },
                "2974": {
                    "ttl": 7,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=2974&pt=n&a=1",
                    "priority": 1,
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=2974&pt=n&a=1"
                    },
                    "partner": "yahoo-openrtb"
                },
                "3632": {
                    "img": "https:\/\/rcp.c.appier.net\/rbcm",
                    "secure": {
                        "img": "https:\/\/rcp.c.appier.net\/rbcm"
                    },
                    "partner": "appier"
                },
                "3636": {
                    "img": "https:\/\/cm.smadex.com\/sync?sm_p=rbc&sm_r=rbc",
                    "secure": {
                        "img": "https:\/\/cm.smadex.com\/sync?sm_p=rbc&sm_r=rbc"
                    },
                    "partner": "smadex"
                },
                "3664": {
                    "priority": 6,
                    "img": "https:\/\/bttrack.com\/pixel\/cookiesync?source=c91bfcce-bb43-46f7-b14e-567c0a4332b3",
                    "secure": {
                        "img": "https:\/\/bttrack.com\/pixel\/cookiesync?source=c91bfcce-bb43-46f7-b14e-567c0a4332b3"
                    },
                    "partner": "bidtellect"
                },
                "3668": {
                    "img": "https:\/\/tg.socdm.com\/rtb\/sync?proto=rubicon",
                    "secure": {
                        "img": "https:\/\/tg.socdm.com\/rtb\/sync?proto=rubicon"
                    },
                    "partner": "supership"
                },
                "3778": {
                    "img": "https:\/\/sync-tm.everesttech.net\/upi\/pid\/btu4jd3a?redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D191940%26nid%3D3778%26put%3D%24%7BUSER_ID%7D",
                    "secure": {
                        "img": "https:\/\/sync-tm.everesttech.net\/upi\/pid\/btu4jd3a?redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D191940%26nid%3D3778%26put%3D%24%7BUSER_ID%7D"
                    },
                    "partner": "adobe",
                    "priority": 11
                },
                "3822": {
                    "priority": 15,
                    "img": "https:\/\/dsp.adfarm1.adition.com\/cookie\/?ssp=7",
                    "secure": {
                        "img": "https:\/\/dsp.adfarm1.adition.com\/cookie\/?ssp=7"
                    },
                    "partner": "active-agent"
                },
                "3856": {
                    "priority": 15,
                    "img": "https:\/\/a.tribalfusion.com\/i.match?p=b10&u={rubicon_user_token}&redirect=https%3A\/\/pixel.rubiconproject.com\/tap.php%3Fv%3D111756%26nid%3D3856%26put%3D%24TF_USER_ID_ENC%24%26expires%3D180",
                    "secure": {
                        "img": "https:\/\/a.tribalfusion.com\/i.match?p=b10&u={rubicon_user_token}&redirect=https%3A\/\/pixel.rubiconproject.com\/tap.php%3Fv%3D111756%26nid%3D3856%26put%3D%24TF_USER_ID_ENC%24%26expires%3D180"
                    },
                    "partner": "vdx.tv"
                },
                "3858": {
                    "priority": 6,
                    "img": "https:\/\/sync.srv.stackadapt.com\/sync?nid=14",
                    "secure": {
                        "img": "https:\/\/sync.srv.stackadapt.com\/sync?nid=14"
                    },
                    "partner": "stackadapt"
                },
                "3956": {
                    "img": "https:\/\/sync.adotmob.com\/cookie\/rubicon?r=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D123034%26nid%3D3956%26put%3D%7Buser_token%7D",
                    "secure": {
                        "img": "https:\/\/sync.adotmob.com\/cookie\/rubicon?r=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D123034%26nid%3D3956%26put%3D%7Buser_token%7D"
                    },
                    "partner": "AdotMob"
                },
                "3992": {
                    "priority": 16,
                    "img": "https:\/\/b1sync.zemanta.com\/usersync\/rubicon\/",
                    "secure": {
                        "img": "https:\/\/b1sync.zemanta.com\/usersync\/rubicon\/"
                    },
                    "partner": "zemanta"
                },
                "4016": {
                    "priority": 15,
                    "img": "https:\/\/cr-p16.ladsp.com\/cookiesender\/16",
                    "secure": {
                        "img": "https:\/\/cr-p16.ladsp.com\/cookiesender\/16"
                    },
                    "partner": "so-netmedia",
                    "country": ["jp"]
                },
                "4032": {
                    "priority": 12,
                    "img": "https:\/\/cm.adgrx.com\/bridge?AG_SETCOOKIE&AG_PID=rubicon",
                    "secure": {
                        "img": "https:\/\/cm.adgrx.com\/bridge?AG_SETCOOKIE&AG_PID=rubicon"
                    },
                    "partner": "samsung"
                },
                "4112": {
                    "priority": 8,
                    "img": "https:\/\/sync.1rx.io\/usersync2\/rubicon",
                    "secure": {
                        "img": "https:\/\/sync.1rx.io\/usersync2\/rubicon"
                    },
                    "partner": "rhythmone"
                },
                "4114": {
                    "priority": 4,
                    "img": "https:\/\/match.prod.bidr.io\/cookie-sync\/rp?bee_sync_partners=rp",
                    "secure": {
                        "img": "https:\/\/match.prod.bidr.io\/cookie-sync\/rp?bee_sync_partners=rp"
                    },
                    "partner": "beeswax"
                },
                "4584": {
                    "img": "https:\/\/onetag-sys.com\/match\/?int_id=4",
                    "secure": {
                        "img": "https:\/\/onetag-sys.com\/match\/?int_id=4"
                    },
                    "partner": "onetag",
                    "country": ["it", "de", "fr", "se", "at", "uk", "es", "gr", "ro", "us"]
                },
                "4604": {
                    "img": "https:\/\/api.primecaster.net\/adlogue\/api\/sync\/rubicon",
                    "secure": {
                        "img": "https:\/\/api.primecaster.net\/adlogue\/api\/sync\/rubicon"
                    },
                    "partner": "videowire",
                    "country": ["jp"]
                },
                "4804": {
                    "priority": 18,
                    "img": "https:\/\/ssbsync.smartadserver.com\/api\/sync?callerId=87",
                    "secure": {
                        "img": "https:\/\/ssbsync.smartadserver.com\/api\/sync?callerId=87"
                    },
                    "partner": "dynadmic"
                },
                "4858": {
                    "priority": 1,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=36584",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=36584"
                    },
                    "partner": "linkedin"
                },
                "4906": {
                    "img": "https:\/\/sync-dsp.ad-m.asia\/dsp\/api\/sync\/send?s=rubicon",
                    "secure": {
                        "img": "https:\/\/sync-dsp.ad-m.asia\/dsp\/api\/sync\/send?s=rubicon"
                    },
                    "partner": "craid",
                    "country": ["jp"]
                },
                "5120": {
                    "priority": 15,
                    "img": "https:\/\/bh.contextweb.com\/bh\/rtset?pid=560687&ev=1&rurl=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D390200%26nid%3D5120%26put%3D%25%25VGUID%25%25",
                    "secure": {
                        "img": "https:\/\/bh.contextweb.com\/bh\/rtset?pid=560687&ev=1&rurl=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D390200%26nid%3D5120%26put%3D%25%25VGUID%25%25"
                    },
                    "partner": "pulsepoint"
                },
                "5446": {
                    "img": "https:\/\/dmp.brand-display.com\/cm\/api\/rubicon",
                    "secure": {
                        "img": "https:\/\/dmp.brand-display.com\/cm\/api\/rubicon"
                    },
                    "partner": "knorex"
                },
                "5498": {
                    "img": "https:\/\/rubiconcm.digitaleast.mobi\/usersync\/rubicon.gif",
                    "secure": {
                        "img": "https:\/\/rubiconcm.digitaleast.mobi\/usersync\/rubicon.gif"
                    },
                    "partner": "digital-east"
                },
                "5500": {
                    "priority": 19,
                    "img": "https:\/\/ds.uncn.jp\/rp\/0\/sync",
                    "secure": {
                        "img": "https:\/\/ds.uncn.jp\/rp\/0\/sync"
                    },
                    "country": ["jp"],
                    "partner": "unicorn"
                },
                "5504": {
                    "img": "https:\/\/beacon.lynx.cognitivlabs.com\/rb.gif",
                    "secure": {
                        "img": "https:\/\/beacon.lynx.cognitivlabs.com\/rb.gif"
                    },
                    "partner": "cognitiv"
                },
                "5508": {
                    "img": "https:\/\/cs.adnear.net\/v2\/cookiesync\/rubicon",
                    "secure": {
                        "img": "https:\/\/cs.adnear.net\/v2\/cookiesync\/rubicon"
                    },
                    "country": ["au", "nz"],
                    "partner": "near"
                },
                "5528": {
                    "priority": 10,
                    "img": "https:\/\/match.deepintent.com\/usersync\/143",
                    "secure": {
                        "img": "https:\/\/match.deepintent.com\/usersync\/143"
                    },
                    "partner": "deepintent"
                },
                "5570": {
                    "img": "https:\/\/sid.storygize.net\/ccm\/729e4e94-63c3-438d-8ce4-184eb34e703f",
                    "secure": {
                        "img": "https:\/\/sid.storygize.net\/ccm\/729e4e94-63c3-438d-8ce4-184eb34e703f"
                    },
                    "partner": "storygize"
                },
                "5578": {
                    "img": "https:\/\/s.company-target.com\/s\/rp",
                    "secure": {
                        "img": "https:\/\/s.company-target.com\/s\/rp"
                    },
                    "partner": "demandbase"
                },
                "idl": {
                    "priority": 9,
                    "ttl": 1,
                    "img": "https:\/\/id.rlcdn.com\/709414.gif",
                    "secure": {
                        "img": "https:\/\/id.rlcdn.com\/709414.gif"
                    },
                    "partner": "liveramp"
                },
                "knsso": {
                    "img": "https:\/\/id.knsso.com\/usync?redir=https%3A%2F%2Fsync.graph.bluecava.com%2Fds.png%3Fp%3D2ee7c8d1-5aff-11ed-8eec-4201ac10000c%26segment%3Dkinessomagnite%26event%3Dimp%26uid%3D%7Buser_token%7D",
                    "priority": 20,
                    "sample": 0,
                    "secure": {
                        "img": "https:\/\/id.knsso.com\/usync?redir=https%3A%2F%2Fsync.graph.bluecava.com%2Fds.png%3Fp%3D2ee7c8d1-5aff-11ed-8eec-4201ac10000c%26segment%3Dkinessomagnite%26event%3Dimp%26uid%3D%7Buser_token%7D"
                    },
                    "partner": "knsso",
                    "country": ["us", "ca", "mx"]
                },
                "2179-na": {
                    "priority": 1,
                    "img": "https:\/\/s.amazon-adsystem.com\/dcm?pid=50cd21b7-d8d7-4615-9fb9-a2be831f8488&id=",
                    "secure": {
                        "img": "https:\/\/s.amazon-adsystem.com\/dcm?pid=50cd21b7-d8d7-4615-9fb9-a2be831f8488&id="
                    },
                    "partner": "amazon-na-sync"
                },
                "2179-eu": {
                    "priority": 1,
                    "img": "https:\/\/aax-eu.amazon-adsystem.com\/s\/dcm?pid=a38a8ddf-19a7-4ab8-ba05-0a61de92a7e5&id=",
                    "secure": {
                        "img": "https:\/\/aax-eu.amazon-adsystem.com\/s\/dcm?pid=a38a8ddf-19a7-4ab8-ba05-0a61de92a7e5&id="
                    },
                    "partner": "amazon-eu-sync"
                },
                "2249-DV360-Hosted": {
                    "priority": 1,
                    "ttl": 7,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=2249&pt=n",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=2249&pt=n"
                    },
                    "partner": "DV360-Google"
                },
                "w55c": {
                    "nid": 1523,
                    "priority": 20,
                    "ttl": 7,
                    "img": "https:\/\/i.w55c.net\/ping_match.gif?ei=RUBICON&rurl=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D4210%26nid%3D1523%26put%3D_wfivefivec_%26expires%3D30",
                    "secure": {
                        "img": "https:\/\/i.w55c.net\/ping_match.gif?ei=RUBICON&rurl=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D4210%26nid%3D1523%26put%3D_wfivefivec_%26expires%3D30"
                    },
                    "partner": "roku-oneview"
                },
                "1523ext": {
                    "iframe": "https:\/\/cti.w55c.net\/ct\/cms-2c-rubicon.html",
                    "secure": {
                        "iframe": "https:\/\/cti.w55c.net\/ct\/cms-2c-rubicon.html"
                    },
                    "partner": "roku-oneview"
                },
                "mediavine-seller": {
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=17404",
                    "priority": 10,
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=17404"
                    },
                    "partner": "mediavine-seller"
                },
                "undertone-seller": {
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=12776",
                    "priority": 15,
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=12776"
                    },
                    "partner": "undertone-seller"
                },
                "brx": {
                    "pingdom_id": "4147002",
                    "priority": 5,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=26594",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=26594"
                    },
                    "partner": "brx"
                },
                "goog": {
                    "priority": 1,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=25470",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=25470"
                    },
                    "partner": "goog"
                },
                "a9eu": {
                    "priority": 1,
                    "img": "http:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=a9eu",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=a9eu"
                    },
                    "partner": "a9eu",
                    "country": ["ie", "gb", "uk", "fr", "de", "es", "pt", "it", "no", "se", "nl", "be", "fi", "ch"]
                },
                "a9us": {
                    "priority": 1,
                    "img": "http:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=a9us",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=a9us"
                    },
                    "partner": "a9us",
                    "country": ["us", "ca", "mx", "br", "au", "nz", "jp"]
                },
                "adsyoulike": {
                    "priority": 10,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=adyoulike",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=adyoulike"
                    },
                    "partner": "adsyoulike-publisher"
                },
                "pb_appneuxs": {
                    "priority": 5,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=pbs-apn",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=pbs-apn"
                    },
                    "partner": "pb_appnexus-publisher"
                },
                "primis": {
                    "priority": 5,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=primis",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=primis"
                    },
                    "partner": "primis-publisher"
                },
                "sovrn": {
                    "priority": 5,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=sovrn",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=sovrn"
                    },
                    "partner": "sovrn-publisher"
                },
                "share-through": {
                    "priority": 5,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=18694",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=18694"
                    },
                    "partner": "share-through-publisher"
                },
                "yieldmo": {
                    "priority": 15,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=yieldmo",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=yieldmo"
                    },
                    "partner": "yieldmo-publisher"
                },
                "33across": {
                    "priority": 10,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=33across",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=33across"
                    },
                    "partner": "33across-publisher"
                },
                "pb_triple13": {
                    "priority": 10,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=pbs-triple13",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=pbs-triple13"
                    },
                    "partner": "pb_triple13-publisher"
                },
                "seedtag": {
                    "priority": 6,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=seedtag",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=seedtag"
                    },
                    "partner": "seedtag-publisher"
                },
                "unruly": {
                    "priority": 10,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=unruly",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=unruly"
                    },
                    "partner": "unruly-publisher"
                },
                "outbrain": {
                    "priority": 10,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=outbrain",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=outbrain"
                    },
                    "partner": "outbrain-publisher"
                },
                "pb_adaptmx": {
                    "priority": 5,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=pbs-adaptmx",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=pbs-adaptmx"
                    },
                    "partner": "pb_adaptmx-publisher"
                },
                "epsilon": {
                    "priority": 17,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=epsilon",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=epsilon"
                    },
                    "partner": "epsilon-publisher"
                },
                "loopme_global": {
                    "priority": 17,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=loopme",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=loopme"
                    },
                    "partner": "loopme_global-publisher"
                },
                "liveintent": {
                    "priority": 10,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=49096",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=49096"
                    },
                    "partner": "liveintent-publisher",
                    "country": ["us"]
                },
                "rise_engage": {
                    "priority": 10,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=rise_engage",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=rise_engage"
                    },
                    "partner": "rise_engage-publisher"
                },
                "minute_media": {
                    "priority": 10,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=minute_media",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=minute_media"
                    },
                    "partner": "minute_media-publisher"
                },
                "kargo": {
                    "priority": 15,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=11864",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=11864"
                    },
                    "partner": "kargo-publisher"
                },
                "smartadserver": {
                    "priority": 15,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=smartadserver",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=smartadserver"
                    },
                    "partner": "smartadserver-publisher"
                },
                "consumable_inc": {
                    "priority": 17,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=24856",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=24856"
                    },
                    "partner": "consumable_inc-publisher"
                },
                "spot_im": {
                    "priority": 15,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=17184",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=17184"
                    },
                    "partner": "spot_im-publisher"
                },
                "vrtcal": {
                    "priority": 20,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=16466",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=16466"
                    },
                    "partner": "vrtcal-publisher"
                },
                "smaato": {
                    "priority": 20,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=smaato",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=smaato"
                    },
                    "partner": "smaato-publisher"
                },
                "pb_forbes": {
                    "priority": 15,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=pbs-medianet",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=pbs-medianet"
                    },
                    "partner": "pb_forbes-publisher"
                },
                "connatix": {
                    "priority": 5,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=19564",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=19564"
                    },
                    "partner": "connatix-publisher"
                },
                "playbuzz": {
                    "priority": 17,
                    "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=17136_2",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/exchange\/sync.php?p=17136_2"
                    },
                    "partner": "playbuzz-publisher"
                }
            }
        },
        "rtb_ext": {
            "sample": 100,
            "pixels": {}
        },
        "aud": {
            "sample": 25,
            "pixels": {
                "bk": {
                    "pingdom_id": "605728",
                    "ttl": 4,
                    "img": "https:\/\/pixel.rubiconproject.com\/token?pid=3",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/token?pid=3"
                    },
                    "partner": "bluekai"
                },
                "aam": {
                    "pingdom_id": "661320",
                    "ttl": 14,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=6404",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=6404"
                    },
                    "partner": "adobe"
                },
                "neu": {
                    "pingdom_id": "1411157",
                    "ttl": 7,
                    "sample": 0,
                    "img": "http:\/\/adadvisor.net\/adscores\/g.pixel?sid=9212270498",
                    "secure": {
                        "img": "https:\/\/adadvisor.net\/adscores\/g.pixel?sid=9212270498"
                    },
                    "partner": "neustar",
                    "country": ["us"]
                },
                "turn": {
                    "pingdom_id": "1504062",
                    "ttl": 7,
                    "img": "http:\/\/token.rubiconproject.com\/token?pid=27&a=1",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=27&a=1"
                    },
                    "partner": "turn-dmp"
                },
                "mmpub": {
                    "pingdom_id": "2117306",
                    "ttl": 7,
                    "img": "http:\/\/pixel.mathtag.com\/sync\/img?redir=http%3A%2F%2Ftoken.rubiconproject.com%2Ftoken%3Fpid%3D35912%26puid%3D%5BMM_UUID%5D",
                    "secure": {
                        "img": "https:\/\/pixel.mathtag.com\/sync\/img?redir=https%3A%2F%2Ftoken.rubiconproject.com%2Ftoken%3Fpid%3D35912%26puid%3D%5BMM_UUID%5D"
                    },
                    "partner": "mediamath-pub"
                },
                "tapad-crossdevice": {
                    "ttl": 7,
                    "img": "http:\/\/token.rubiconproject.com\/token?pid=37556&a=1",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=37556&a=1"
                    },
                    "sample": 100,
                    "priority": 5,
                    "partner": "tapad-crossdevice"
                },
                "digitrust": {
                    "ttl": 14,
                    "img": "http:\/\/rubicon.digitru.st\/digitrust-sync",
                    "secure": {
                        "img": "https:\/\/rubicon.digitru.st\/digitrust-sync"
                    },
                    "sample": 0,
                    "partner": "digitrust"
                },
                "ownerIQ-dmp": {
                    "sample": 0,
                    "ttl": 14,
                    "img": "http:\/\/px.owneriq.net\/eucm\/p\/rc?redir=http%3A%2F%2Ftoken.rubiconproject.com%2Ftoken%3Fpid%3D3353%26puid%3D(OIQ_UUID)",
                    "secure": {
                        "img": "https:\/\/px.owneriq.net\/eucm\/p\/rc?redir=https%3A%2F%2Ftoken.rubiconproject.com%2Ftoken%3Fpid%3D3353%26puid%3D(OIQ_UUID)"
                    },
                    "partner": "ownerIQ-dmp"
                },
                "a9s": {
                    "ttl": 7,
                    "sample": 100,
                    "region": ["us"],
                    "iframe": "https:\/\/s.amazon-adsystem.com\/x\/1c2fd14bf310b6aff649",
                    "secure": {
                        "iframe": "https:\/\/s.amazon-adsystem.com\/x\/1c2fd14bf310b6aff649"
                    },
                    "partner": "amazon-pub-us-sync"
                },
                "a9s-eu": {
                    "ttl": 7,
                    "sample": 100,
                    "region": ["eu"],
                    "iframe": "https:\/\/aax-eu.amazon-adsystem.com\/s\/x\/1c2fd14bf310b6aff649",
                    "secure": {
                        "iframe": "https:\/\/aax-eu.amazon-adsystem.com\/s\/x\/1c2fd14bf310b6aff649"
                    },
                    "partner": "amazon-eu-sync"
                },
                "Merkle": {
                    "sample": 0,
                    "ttl": 14,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=28752",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=28752"
                    },
                    "partner": "Merkle"
                },
                "sirdata": {
                    "img": "https:\/\/pixel.rubiconproject.com\/token?pid=34458",
                    "secure": {
                        "img": "https:\/\/pixel.rubiconproject.com\/token?pid=34458"
                    },
                    "sample": 0,
                    "partner": "sirdata"
                },
                "sem": {
                    "ttl": 7,
                    "sample": 50,
                    "img": "https:\/\/token.rubiconproject.com\/token?pid=10362",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=10362"
                    },
                    "partner": "semasio",
                    "country": ["us", "ca", "mx", "au", "hk", "in", "nz", "sg", "at", "be", "dk", "fi", "fr", "de", "it", "nl", "es", "se", "ch", "uk"]
                },
                "spr": {
                    "img": "https:\/\/tv.springserve.com\/ssusersync",
                    "secure": {
                        "img": "https:\/\/tv.springserve.com\/ssusersync"
                    },
                    "partner": "springserve",
                    "country": ["de", "ca", "fr", "gb", "es", "br", "jp", "kr", "tr", "pl", "au", "mx", "it", "ar", "id", "ph", "tw", "nl", "at", "ch", "cl", "nz", "th", "se", "sg", "dk", "be", "in", "no", "fi", "pe", "co", "my"]
                },
                "transunion": {
                    "img": "http:\/\/token.rubiconproject.com\/token?pid=31224",
                    "secure": {
                        "img": "https:\/\/token.rubiconproject.com\/token?pid=31224"
                    },
                    "priority": 20,
                    "partner": "transunion"
                },
                "por": {
                    "ttl": 7,
                    "img": "https:\/\/ksk.t.zucks.net\/mc\/cs",
                    "secure": {
                        "img": "https:\/\/ksk.t.zucks.net\/mc\/cs"
                    },
                    "partner": "porto",
                    "country": ["jp"]
                },
                "sca": {
                    "ttl": 7,
                    "img": "https:\/\/tg.socdm.com\/aux\/idsync?proto=magnite_ctv",
                    "secure": {
                        "img": "https:\/\/tg.socdm.com\/aux\/idsync?proto=magnite_ctv"
                    },
                    "partner": "scaleout",
                    "country": ["jp"]
                }
            }
        },
        "nets": {
            "sample": 100,
            "pixels": {}
        },
        "pubs": {
            "sample": 0,
            "pixels": {}
        }
    },
    "notify": {
        "rubicon": {
            "sample": 0,
            "img": "http:\/\/tap.rubiconproject.com\/stats\/rtbsync"
        }
    },
    "priority": 20,
    "resync": 0,
    "max_ie_partners": 1000,
    "lastModified": "2018-05-10 09:19:59",
    "dateRetrieved": "2023-11-29 03:57:42 PST"
};

// http://tap.rubiconproject.com/partner/agent/rubicon/channels.js?cb=oz_onPixelsLoaded
function isSellerSync() { // "seller sync" (Multi-sync) if a "p" (partner) querystring param exists
    return !!retrieveQueryParams().p
}
var skipBuyerSync; // store so we don't calculate more than once
function shouldSkipBuyerSync() {
    var a = Math.floor; // only calculate once
    return skipBuyerSync || !1 === skipBuyerSync ? skipBuyerSync : a(100 * Math.random()) < +rtb_sync.sample ? alreadyRanOnPage() ? (log("skipping buyer sync cause already ran"), skipBuyerSync = !0, skipBuyerSync) : (skipBuyerSync = !1, skipBuyerSync) : (log("skipping buyer sync due to sampling"), skipBuyerSync = !0, skipBuyerSync); // buyer sync global throttle
    // don't run buyer sync multiple times per page
}
var consentParams, localStorageAccess, sessionStorageAccess, regionCountries = {
        af: ["ao", "bi", "bj", "bf", "bw", "cf", "ci", "cm", "cd", "cg", "km", "cv", "dj", "dz", "eg", "er", "eh", "et", "ga", "gh", "gn", "gm", "gw", "gq", "ke", "lr", "ly", "ls", "ma", "mg", "ml", "mz", "mr", "mu", "mw", "yt", "na", "ne", "ng", "re", "rw", "sd", "sn", "sh", "sl", "so", "ss", "st", "sz", "sc", "td", "tg", "tn", "tz", "ug", "za", "zm", "zw"],
        an: ["aq", "tf", "bv"],
        as: ["af", "ae", "am", "ap", "az", "bd", "bh", "bn", "bt", "cn", "hk", "id", "in", "io", "ir", "iq", "il", "jo", "jp", "kz", "kg", "kh", "kr", "kw", "la", "lb", "lk", "mo", "mv", "mm", "mn", "my", "np", "om", "pk", "ph", "kp", "ps", "qa", "sa", "sg", "sy", "th", "tj", "tm", "tl", "tw", "uz", "vn", "ye"],
        au: ["as", "au", "cc", "ck", "cx", "fj", "fm", "gu", "hm", "ki", "mh", "mp", "nc", "nf", "nu", "nr", "nz", "pn", "pw", "pg", "pf", "sb", "tk", "to", "tv", "um", "vu", "wf", "ws"],
        eu: ["ax", "al", "ad", "at", "be", "bg", "ba", "by", "ch", "cy", "cz", "de", "dk", "es", "ee", "eu", "fi", "fr", "fo", "uk", "ge", "gg", "gi", "gr", "hr", "hu", "im", "ie", "is", "it", "je", "li", "lt", "lu", "lv", "mc", "md", "mk", "mt", "me", "nl", "no", "pl", "pt", "ro", "ru", "sj", "sm", "rs", "sk", "si", "se", "tr", "ua", "va"],
        na: ["aw", "ai", "an", "ag", "bq", "bs", "bl", "bz", "bm", "bb", "ca", "cr", "cu", "cw", "ky", "dm", "do", "gp", "gd", "gl", "gt", "hn", "ht", "jm", "kn", "lc", "mf", "mx", "ms", "mq", "ni", "pa", "pr", "sv", "pm", "sx", "tc", "tt", "us", "vc", "vg", "vi"],
        sa: ["ar", "bo", "br", "cl", "co", "ec", "fk", "gf", "gy", "pe", "py", "gs", "sr", "uy", "ve"]
    },
    rtb_sync = window.rtb_sync || {},
    rtb_pixel_set = ["rtb", "aud", "nets", "pubs"],
    request_country = getQueryStringParam("co") || getCountry(),
    request_region = getQueryStringParam("geo") || getRegion(request_country),
    expiration = 86400,
    cap = 1; // should have been set already
try {
    document.cookie, document.noCookieAccess = !1
} catch (a) {
    document.noCookieAccess = !0
}
try {
    window.localStorage.getItem("any"), localStorageAccess = !0
} catch (a) {
    localStorageAccess = !1
}
try {
    window.sessionStorage.getItem("any"), sessionStorageAccess = !0
} catch (a) {
    sessionStorageAccess = !1
} // get fcaps object from localStorage or create new one if not present
function getPartnerFcaps(a) {
    try {
        var b = JSON.parse(lsGet(a))
    } catch (a) { /** nothing */ }
    return b || {}
} // get a specified partner's fcap value
function getPartnerFcap(a, b) {
    return b ? (a[b] = a[b] || createNewFcap(), a[b]) : null; // default new fcap object
}

function isExpired(a) {
    return !a || !a.exp || a.exp < new Date().getTime() / 1e3
}

function isCapped(a) {
    return !!a && a.cap >= cap && !isExpired(a)
}

function createNewFcap() {
    return {
        cap: 0,
        exp: new Date().getTime() / 1e3 + expiration
    }
} // increment the given partner fcap cap by 1
function incrementPartnerFcap(a) {
    a.cap++
} // removes partners with expired fcaps
function removeExpiredPartners(a) {
    for (var b in a) a.hasOwnProperty(b) && isExpired(a[b]) && delete a[b]
} // saves fcap values to local storage in json format
function savePartnerFcaps(a, b) {
    if (a) try {
        lsSet(a, JSON.stringify(b))
    } catch (a) { /** nothing */ }
}

function getConsentWindowFor(a) {
    for (var b = window; b !== window.top;) {
        b = b.parent;
        try {
            if (b.frames[a]) return b
        } catch (a) {}
    }
    return !1
}

function oz_onPixelsLoaded(a) {
    if (a && a.pixels)
        for (var b, c = 0; c < a.pixels.length; c++) b = a.pixels[c].url, b && 0 == b.indexOf("http") && (new Image().src = appendConsentQS(b))
}

function getReferrer() {
    var a, b = document.referrer;
    return b && 0 < b.length && (a = escape(b)), a
}

function setCookie(a, b, c) {
    var d;
    if (c) {
        var f = new Date;
        f.setTime(f.getTime() + 1e3 * (60 * (60 * (24 * c)))), d = "; expires=" + f.toGMTString()
    } else d = "";
    try {
        document.cookie = a + "=" + escape(b) + d + "; path=/; SameSite=None; Secure"
    } catch (a) {}
}

function deleteCookie(a) {
    try {
        document.cookie = a + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT; SameSite=None; Secure"
    } catch (a) {}
}

function readCookie(a) {
    var b = a + "=",
        d = "";
    try {
        d = document.cookie.split(";")
    } catch (a) {}
    for (var f, g = 0; g < d.length; g++) {
        for (f = d[g];
            " " == f.charAt(0);) f = f.substring(1, f.length);
        if (0 == f.indexOf(b)) return unescape(f.substring(b.length, f.length))
    }
    return null
}

function trim_whitespace(a) {
    return a.replace(/^\s+|\s+$/gm, "")
}

function countCookies(a) {
    var b = "";
    try {
        b = document.cookie.split(";")
    } catch (a) {}
    for (var d, f = 0, g = 0; g < b.length; g++) d = b[g], d = trim_whitespace(d), a ? 0 == d.indexOf(a) && f++ : f++;
    return f
}

function addScriptAsync(a, b) {
    var c;
    c = document.createElement("script"), b && c.setAttribute("id", b), c.setAttribute("type", "text/javascript"), a = a.replace(/\s/g, "+"), c.setAttribute("src", a), document.getElementsByTagName("head").item(0).appendChild(c)
}

function addScript(a) {
    document.write("<script type=\"text/javascript\" SRC=\"" + a + "\" async></script>")
} // Function to retrieve URl query parameters.
function retrieveQueryParams() {
    for (var a, b = window.location.search.substring(1), c = b.split("&"), d = {}, f = 0; f < c.length; f++) a = c[f].split("="), a[0] && (d[decodeURIComponent(a[0])] = decodeURIComponent(a[1] || ""));
    return d
} // get 2 character country code
function getCountry() { // retrieve country from browser language, or blank
    var a = navigator.language || navigator.userLanguage || "";
    return a.substr(-2).toLowerCase()
} // get 2 character region code for the given country
function getRegion(a) {
    if (a)
        for (var b in regionCountries)
            if (regionCountries.hasOwnProperty(b) && -1 < regionCountries[b].indexOf(a)) return b;
    return ""
} // get allowList from session storage (format: <timestamp>-[list,of,pixels])
function getAllowList() {
    try {
        var a = ssGet("emily_allowlist");
        return a ? (a = a.split("-"), 45e3 < new Date().getTime() - +a[0] ? void ssRemove("emily_allowlist") : JSON.parse(a[1])) : void 0; // return if nothing found
        // split date and list
    } catch (a) {
        return void log("allowlist error:", a)
    }
}
/**
 * @function getQueryStringParam
 * @summary retrieves the given querystring param, or null if it doesn't exist
 *            if the param appears multiple times, only the first occurrence is returned
 * @param {string} sParamName - the name of the querystring parameter
 * @returns {string} the value of the query string parameter or null if it doesn't exist
 */
function getQueryStringParam(a) { // for performance, first see if the substring exists in the querystring
    if (!a || -1 === (window.location.search || "").indexOf(a)) return null; // handle parameters with or without an '='
    var b = new RegExp("[?&]" + a + "((=([^&]*))|(&|$))"),
        c = b.exec(window.location.search);
    return !c || 5 > c.length ? null : decodeURIComponent(c[3] || "")
}

function loadExpiration() {
    var a;
    if (localStorageAccess) a = lsGet;
    else if (sessionStorageAccess) a = ssGet;
    else return log("No storage access. Expiration not loaded"), {};
    var b = {},
        d = a("pux");
    if (!d) return b;
    var c, f, g = d.split("&");
    for (var h in g) {
        var j = g[h].split("=");
        if (!(2 > j.length)) {
            c = j[0], f = j[1];
            var k = f.split(",");
            0 < k.length && (b[c] = {
                created: k[0]
            })
        }
    }
    return b
}

function saveExpiration(a) {
    var b;
    if (localStorageAccess) b = lsSet;
    else if (sessionStorageAccess) b = ssSet;
    else return void log("No storage access. Expiration not saved");
    var d = "";
    for (name in a) {
        var f = a[name];
        d += name + "=", d += f.created, d += "&"
    }
    b("pux", d)
}

function is_expired(a, b) {
    if (!b) return !0;
    a = +a;
    var c = new Date().getTime() / 3600000,
        d = new Date(2010, 0, 1, 0, 0, 0, 0).getTime() / 3600000,
        f = new Number(b.created) + 24 * a;
    return !(c - d < f)
}

function shouldFirePixel(a) {
    var b = Math.floor,
        c = expiration_info[a.nid];
    if (c && !is_expired(a.info.ttl || a.context.ttl || rtb_sync.ttl, c)) return !1;
    var d = 0 == a.info.sample ? a.info.sample : a.info.sample || a.context.sample || rtb_sync.pixel_sample || 0; // do simple parsing
    return d = +d, !!(b(100 * Math.random()) < d)
}

function firePixel(a) {
    var b = Math.floor(new Date().getTime() / 3600000),
        c = new Date(2010, 0, 1, 0, 0, 0, 0).getTime() / 3600000;
    expiration_info[a.nid] = {
        created: b - c
    };
    var d = a.info.secure ? a.info.secure : a.info;
    if (d) {
        var f = getReferrer();
        if (d.script) {
            var g = d.script;
            "rp" == a.nid && f && (g = appendQSParams(g, "rf=" + f))
        }
        d.img && setTimeout(function() {
            new Image().src = appendConsentQS(d.img)
        }, 100), d.iframe && document.write("<iframe src='" + appendConsentQS(d.iframe) + "' width='1' height='1' frameborder='0'></iframe>"), d.script && addScript(appendConsentQS(g))
    }
} // Fisher Yates
function shuffle(a) {
    var b = a.length;
    if (0 == b) return !1;
    for (; --b;) {
        var c = Math.floor(Math.random() * (b + 1)),
            d = a[b],
            f = a[c];
        a[b] = f, a[c] = d
    }
}

function prioritize(a) {
    a.sort(function(c, a) {
        return c.info.priority - a.info.priority
    })
}

function firePixelsToMax(a, b) {
    for (var c = 0; c < b && c < a.length; c++) firePixel(a[c])
}

function fireRandomPixelsByPriority(a, b) {
    var c = sortPixelsByPriority(a);
    allocatePixelCalls(c, b), fireXRandomPixels(c.p1, c.p1Calls), fireXRandomPixels(c.other, c.otherCalls)
}

function sortPixelsByPriority(a) {
    var b = {
        p1: [],
        other: []
    };
    return a.forEach(function(a) {
        sortPixel(a, b)
    }), b
}

function sortPixel(a, b) {
    1 === a.info.priority ? b.p1.push(a) : b.other.push(a)
}

function allocatePixelCalls(a, b) {
    var c = localStorageAccess || sessionStorageAccess,
        d = c ? 4 : 2,
        f = a.p1.length,
        g = a.other.length; // Total number of calls should never exceed the provided maximum;
    for (a.p1Calls = determineAllocation(f, g, d), a.otherCalls = determineAllocation(g, f, d); a.p1Calls + a.otherCalls > b && 0 < a.otherCalls;) a.otherCalls -= 1;
    for (; a.p1Calls + a.otherCalls > b && 0 < a.p1Calls;) a.p1Calls -= 1
}

function determineAllocation(a, b, c) {
    var f, d = Math.min,
        g = 0;
    return b < c && (g = c - b), f = d(a, c + g), f
}

function fireXRandomPixels(a, b) {
    for (var c = 0; c < b; c++) {
        var d = Math.floor(Math.random() * a.length),
            f = a.splice(d, 1)[0];
        firePixel(f)
    }
}
var expiration_info;

function array_contains(a, b) {
    for (e in a)
        if (b == a[e]) return !0;
    return !1
}

function detectIE() {
    var a = window.navigator.userAgent,
        b = a.indexOf("MSIE ");
    if (0 < b) return !0;
    var c = a.indexOf("Trident/");
    if (0 < c) return !0;
    var d = a.indexOf("Edge/");
    return !!(0 < d); // other browser
}

function doPixels() {
    var a = !0,
        b = [],
        c = [];
    expiration_info = loadExpiration();
    var d = getAllowList();
    for (var f in d && log("restricting to the following \"allowlist\" pixels:", d), rtb_pixel_set) {
        var g = rtb_pixel_set[f],
            h = rtb_sync.pixel_sets[g];
        if (h)
            for (o in h.pixels)
                if (!d || -1 < d.indexOf(o)) {
                    var j = h.pixels[o];
                    j.priority = j.priority || h.priority || rtb_sync.priority, isPixelAllowed(j.sample, j.region, request_region, j.country, request_country) && (j.ttl = j.ttl || h.ttl || rtb_sync.ttl, b[b.length] = {
                        pixel_set: g,
                        nid: o,
                        info: j,
                        context: h
                    })
                }
    }
    if (prioritize(b), detectIE()) {
        var k = rtb_sync.max_ie_partners || b.length;
        b.splice(k, b.length - k)
    }
    for (var f in b) {
        var l = b[f]; // check to see if pixel is expired
        is_expired(l.info.ttl, expiration_info[l.nid]) && 0 != l.info.sample && (c[c.length] = l)
    }
    a = 0 == c.length, shuffle(c), prioritize(c);
    var m = c.filter(shouldFirePixel),
        n = rtb_sync.max_pixels || 1;
    readCookie("khaos") ? firePixelsToMax(m, n) : fireRandomPixelsByPriority(c, n);
    var o = "rubicon",
        j = rtb_sync.notify[o],
        l = {
            nid: o,
            info: j,
            context: rtb_sync
        };
    shouldFirePixel(l) && (l.info.img += "?allfired=" + a, l.info.img += "&cookies=" + countCookies(), l.info.img += "&ie=" + (detectIE() ? "true" : "false"), firePixel(l)), saveExpiration(expiration_info)
}

function isPixelAllowed(a, b, c, d, f) {
    if (0 == a) return !1;
    var g = !!(b && c),
        h = !!(d && f); // allow pixel if region or country check is not possible in case when it was not defined in info or request
    return !!(!g && !h) || g && (b == c || array_contains(b, c)) || h && (d == f || array_contains(d, f)); // check if region or country from request is in scope of info region or country
}

function getConsentParams(a, b, c) {
    if (!1 === c) return b;
    var d = b || {}; // CMP 1.1 support
    return a && "object" == typeof a && (!a.uspString && (d.gdpr_consent = a.tcString || a.consentData), "undefined" != typeof a.gdprApplies && (d.gdpr = a.gdprApplies ? 1 : 0), a.uspString && (d.us_privacy = encodeURIComponent(a.uspString))), "string" == typeof a && (d.gdpr_consent = a), d
}

function getConsentQS(a) {
    return a = a || {}, ["gdpr_consent", "gdpr", "us_privacy"].filter(function(b) {
        return "undefined" != typeof a[b]
    }).map(function(b) {
        return b + "=" + a[b]
    }).join("&")
}

function appendQSParams(a, b) {
    return b && a && (a += a.match(/\?/) ? "&" : "?", a += b), a
}

function appendConsentQS(a) {
    return appendQSParams(a, getConsentQS(consentParams))
} // filter querystring params by exceptions
function appendQueryParams(a) {
    a = a || {};
    var b = ["endpoint", "region", "country", "p"];
    return Object.keys(a).filter(function(a) {
        return -1 === b.indexOf(a) && !a.match(/^rp_/)
    }).map(function(b) {
        return encodeURIComponent(b) + "=" + encodeURIComponent(a[b])
    }).join("&")
}

function getConsentQSParams() {
    var a = getQueryStringParam("gdpr"),
        b = getQueryStringParam("gdpr_consent"),
        c = getQueryStringParam("us_privacy");
    if (b) var d = {
        gdpr_consent: b
    };
    return a && (d = d || {}, d.gdpr = "false" === a || "0" === a ? 0 : 1), c && (d = d || {}, d.us_privacy = c), d
}

function getConsent(a) {
    function b(a, b, c) { // if we are not (or no longer) looking for this type of consent, return
        0 !== g.length && g.includes(a) && ( // remove current consent type from the list so we know it's done
            g = g.filter(function(b) {
                return b !== a
            }), consentParams = getConsentParams(c, consentParams, b), 0 === g.length && l())
    } // if don't already have gdpr params, get window with gdpr cmp
    if (consentParams = getConsentQSParams(), !consentParams || "undefined" == typeof consentParams.gdpr) var c = getConsentWindowFor("__tcfapiLocator"),
        d = c ? null : getConsentWindowFor("__cmpLocator"); // if don't already have usp params, get window with usp cmp
    if (!consentParams || !consentParams.us_privacy) var f = getConsentWindowFor("__uspapiLocator"); // if don't have either gdpr or usp cmps, call callback and return
    if (!c && !d && !f) return void a();
    var g = [],
        h = !1,
        i = "us-" + Math.random(),
        j = "us-" + Math.random(),
        k = "us-" + Math.random(),
        l = function() {
            h || (h = !0, a())
        }; // don't call more than once
    // failsafe so the callback is not called more than once
    // (do we need this?)
    if (c ? (g.push("tcf"), c.postMessage({
            __tcfapiCall: {
                callId: k,
                command: "addEventListener",
                version: 2
            }
        }, "*")) : d && (g.push("cmp"), d.postMessage({
            __cmpCall: {
                callId: i,
                command: "getConsentData",
                parameter: null
            }
        }, "*")), f && (g.push("usp"), f.postMessage({
            __uspapiCall: {
                callId: j,
                command: "getUSPData",
                version: 1
            }
        }, "*")), window.addEventListener("message", function(a) {
            try {
                if (a && a.data) {
                    var c = "string" == typeof a.data ? JSON.parse(a.data) : a.data,
                        d = c.__cmpReturn,
                        f = c.__uspapiReturn,
                        g = c.__tcfapiReturn;
                    g && g.callId === k && g.returnValue && ("tcloaded" === g.returnValue.eventStatus || "useractioncomplete" === g.returnValue.eventStatus) ? (clearTimeout(n), b("tcf", g.success, g.returnValue)) : d && d.callId === i && (clearTimeout(o), b("cmp", d.success, d.returnValue)), f && f.callId === j && (clearTimeout(m), b("usp", f.success, f.returnValue))
                }
            } catch (a) { /** do nothing */ }
        }), f) var m = setTimeout(function() {
        b("usp", !1)
    }, 100);
    if (c) var n = setTimeout(function() {
        b("tcf", !1)
    }, 500);
    else if (d) var o = setTimeout(function() {
        b("cmp", !1)
    }, 500)
}

function checkCookies() { // check for 'cookies enabled'
    if (document.noCookieAccess) return log("no access to document.cookie, running syncs anyway"), void runSyncs();
    /**
     * commenting this out because without consent, it may not be ok to set
     * this cookie even for a moment.  May add it back later. (see HB-17585)
     * if (!document.cookie) {
     *     setCookie("cd","false");
     *     if (!document.cookie) {
     *         log('will not request khaos cause cannot set cookies');
     *         runSyncs();
     *         return;
     *     } else {
     *         deleteCookie("cd");
     *     }
     * }
     */ // if trp_optout == "true", do not run syncs (see HB-17585)
    if ("true" === readCookie("trp_optout")) return log("trp_optout == true, not running syncs"), !1; // get device consent and khaos cookie (if don't already have)
    // using sampling to roll out the feature to avoid overwhelming servers
    // (see HB-17585)
    if (readCookie("khaos") && !checkSampling("check consent when we have khaos", rtb_sync.consent_rate)) runSyncs();
    else {
        log("making request for consent");
        var a = getConsentQS(consentParams),
            b = lsGet("khaos"),
            c = b ? (a.length ? "&" : "") + "khaos=" + b : "",
            d = !1,
            f = new XMLHttpRequest;
        f.withCredentials = !0, ["error", "abort"].forEach(function(a) {
            f.addEventListener(a, function() {
                log("request failed, not running syncs:", a)
            })
        }), f.addEventListener("load", function() {
            try {
                d = 1 === +JSON.parse(f.responseText).c
            } catch (a) {
                log("failed to parse consent response", f.responseText)
            }
            d ? (log("have consent"), processDeviceAccessCmdQue(), runSyncs()) : log("no consent, not running syncs")
        }), f.open("GET", "https://token.rubiconproject.com/khaos.json?" + a + c), f.send()
    }
}

function alreadyRanOnPage() {
    if (!navigator.cookieEnabled) return log("The browser does not support cookies"), !1; // prevent Emily from running multiple times within 5 mins per page
    //  (5 mins adds protection in case the unload event doesn't fire)
    try { // clear session when leaving page
        function b() {
            ssGet("emilyRan") && ssRemove("emilyRan")
        }
        window.addEventListener ? window.addEventListener("unload", b, !1) : window.attachEvent && window.attachEvent("onunload", b); // don't run Emily more than once within 5 mins on a page
        var a = ssGet("emilyRan");
        if (a = a && +a, a && 3e5 > new Date().getTime() - a) return !0; // must not have run in the last 5 minutes, store current time
        daCmdQue.push(function() {
            ssSet("emilyRan", new Date().getTime())
        })
    } catch (a) {
        return log("failed checking if already ran:", a), !1
    } // Emily must not have already run on the page
    return !1
}

function sellerSync(a, b, c, d) {
    a = a || {}; // object of valid region specific endpoint. Set as object to easily
    // parse for acceptable values in sync function
    var f = ""; // if value passed in by partner is not in acceptable values, leave blank.
    // this is to sanitatize / validate the inputs are correct.
    a.endpoint in {
        "us-west": "",
        "us-east": "",
        eu: "",
        apac: ""
    } && (f = "-" + a.endpoint); // If endpoint_region is left blank, the default domain will be
    // pixel.rubiconproject.com leaving for Akamai routing
    var g = ["https://pixel", f, ".rubiconproject.com/exchange/sync.php?p=", b].join(""); // append (pass through) any other params in the querystring
    // make request
    g = appendQSParams(g, appendQueryParams(a)), g = appendQSParams(g, appendQueryParams(c)), d && (g = appendQSParams(g, "khaos=" + d)), new Image().src = g
} // Function to determine if user should be synchronized controlled by cookie called "fcap".
function initiateSellerSync(a) { // if no partner, do not synchronize
    if (!a) return !1; // get from localStorage or create new fcap
    var b = getPartnerFcaps("fcap"); // remove any expired partners
    removeExpiredPartners(b); // get partner's fcap
    var c = getPartnerFcap(b, a),
        d = !1; // assume don't synchronize
    // synchronize if partner cap is less than fcap, then increment cap
    // return whether to synchronize
    return isCapped(c) || (d = !0, incrementPartnerFcap(c)), savePartnerFcaps("fcap", b), d
}

function runSyncs() {
    observeTopics();
    var a = readCookie("khaos"),
        b = a || document.noCookieAccess || checkSampling("runSyncs without khaos cookie", rtb_sync.reset_rate);
    if (!b) return void log("skipping syncs cause no khaos and not sampled");
    checkKhaosMatchesPrevious(a); // Do "seller sync" (Multi-Sync), if have any partners
    var c = retrieveQueryParams(),
        d = c.p;
    if (d) {
        log("doing seller sync");
        var f = lsGet("khaos"),
            g = ssGet("khaos");
        d.split(",").filter(function(a) {
            return initiateSellerSync(a)
        }).forEach(function(b) {
            return sellerSync(c, b, consentParams, a || f || g)
        })
    } // Do "buyer sync" (Emily User-Sync)
    shouldSkipBuyerSync() || (log("doing buyer sync"), doPixels())
}
async function observeTopics() {
    try { // Get the array of top topics for this user.
        var a = document.browsingTopics && (await document.browsingTopics());
        log("topics:", a)
    } catch (a) {
        log("failed to get topics:", a)
    }
}

function checkKhaosMatchesPrevious(a) { // if no cookieKhaos, not doing buyer sync, so no need to reset tracking
    // and seller sync will try to use prevKhaos from LS, if one exists, so
    // no way to see a discrepancy to necessitate resetting tracking
    if (a) {
        var b = lsGet("khaos");
        a !== b && (log("khaos (" + a + ") does not match previous khaos (" + b + ")"), resetSyncTracking(), lsSet("khaos", a))
    }
}

function resetSyncTracking() {
    log("resetting sync tracking"), lsRemove("pux"), lsRemove("fcap")
} // general purpose function to do sampling by checking the "rtb_sync.reseet_rate"
// against a random number and returning the result
// the "description" is just for logging purposes
function checkSampling(a, b) {
    var c = Math.floor;
    b = +b || 0; // get random percent
    var d = c(100 * Math.random());
    return log("checkSampling: sampleNumber:", d, "sampleRate:", b), d < b ? (log(a, ": Yes, sampled in"), !0) : (log(a, ": No, sampled out"), !1)
} // start the sync process
function startSync() { // if this is not "seller sync", and we are skipping "buyer sync", return
    return (log("starting"), !shouldSkipBuyerSync() || isSellerSync()) && (getConsent(checkCookies), !0); // call checkCookies() after getting gdpr consent, or on timeout
} // device access functions to call after we confirm we have device consent
var daCmdQue = [];

function processDeviceAccessCmdQue() {
    try {
        daCmdQue.forEach(function(a) {
            a()
        }), daCmdQue = {
            push: function(a) {
                a()
            }
        }
    } catch (a) {
        log("error processing device access:", a)
    }
}

function lsGet(a) {
    try {
        return window.localStorage.getItem(a)
    } catch (b) {
        return a !== debug_param && log("LS: failed to get:", a), null
    }
}

function lsSet(a, b) {
    try {
        window.localStorage.setItem(a, b)
    } catch (c) {
        log("LS: failed to set:", a, b)
    }
}

function lsRemove(a) {
    try {
        window.localStorage.removeItem(a)
    } catch (b) {
        log("LS: failed to remove:", a)
    }
}

function ssGet(a) {
    try {
        return window.sessionStorage.getItem(a)
    } catch (b) {
        return a !== debug_param && log("SS: failed to get:", a), null
    }
}

function ssSet(a, b) {
    try {
        window.sessionStorage.setItem(a, b)
    } catch (c) {
        log("SS: failed to set:", a, b)
    }
}

function ssRemove(a) {
    try {
        window.sessionStorage.removeItem(a)
    } catch (b) {
        log("SS: failed to remove:", a)
    }
}
var logPrefix;

function getLogPrefix() {
    if (!logPrefix) {
        var a = "" + Math.random();
        logPrefix = "Emily (" + a.substring(a.length - 3) + "):"
    }
    return logPrefix
}
var debug, debug_param = "emily_debug";

function log() {
    try {
        !1 !== debug && (!0 === debug || "true" === readCookie(debug_param) || "true" === lsGet(debug_param) || "true" === ssGet(debug_param) ? (debug = !0, console.log.apply(console, [getLogPrefix()].concat(Array.prototype.slice.call(arguments)))) : debug = !1)
    } catch (a) { // ignore
    }
} // start sync process
startSync();