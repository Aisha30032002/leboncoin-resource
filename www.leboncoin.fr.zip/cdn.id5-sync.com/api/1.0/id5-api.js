/**
 * @id5io/id5-api.js
 * @version v1.0.54
 * @link https://id5.io/
 * @license Apache-2.0
 */
! function(n) {
    var r = {};

    function o(e) {
        if (r[e]) return r[e].exports;
        var t = r[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return n[e].call(t.exports, t, t.exports, o), t.l = !0, t.exports
    }
    o.m = n, o.c = r, o.d = function(e, t, n) {
        o.o(e, t) || Object.defineProperty(e, t, {
            configurable: !1,
            enumerable: !0,
            get: n
        })
    }, o.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return o.d(t, "a", t), t
    }, o.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, o.p = "", o(o.s = 17)
}([function(e, g, m) {
    "use strict";
    Object.defineProperty(g, "__esModule", {
            value: !0
        }),
        function(e) {
            g.generateId = function() {
                if (void 0 !== e && void 0 !== e.crypto && void 0 !== e.crypto.randomUUID) return e.crypto.randomUUID();
                return "".concat(1e6 * Math.random() | 0)
            }, g.semanticVersionCompare = function(e, t) {
                var n = "^\\d+(\\.\\d+(\\.\\d+){0,1}){0,1}$";
                if (!e.match(n) || !t.match(n)) return;
                var r = e.split("."),
                    o = t.split("."),
                    n = function(e) {
                        return parseInt(e) || 0
                    },
                    e = function(e, t) {
                        t = e - t;
                        return 0 == t ? 0 : t < 0 ? -1 : 1
                    },
                    t = e(n(r[0]), n(o[0]));
                if (0 !== t) return t;
                t = e(n(r[1]), n(o[1]));
                return 0 !== t ? t : e(n(r[2]), n(o[2]))
            }, g.isA = c, g.isFn = d, g.isStr = h, g.isArray = p, g.isNumber = function(e) {
                return c(e, o)
            }, g.isPlainObject = function(e) {
                return c(e, i)
            }, g.isBoolean = function(e) {
                return c(e, a)
            }, g.isDefined = function(e) {
                return void 0 !== e
            }, g.isEmpty = v, g._each = y, g.ajax = function(e, t, n) {
                var r, o = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : {},
                    i = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : u.c;
                try {
                    var a = o.method || (n ? "POST" : "GET");
                    document.createElement("a").href = e;
                    var s, c = "object" === l(t) && null !== t ? t : {
                        success: function() {
                            i.info("ajax", "xhr success")
                        },
                        error: function(e) {
                            i.error("ajax", "xhr error", null, e)
                        }
                    };
                    "function" == typeof t && (c.success = t), (r = new window.XMLHttpRequest).onreadystatechange = function() {
                        var e;
                        4 === r.readyState && (200 <= (e = r.status) && e < 300 || 304 === e ? c.success(r.responseText, r) : c.error(r.statusText, r))
                    }, r.ontimeout = function() {
                        i.error("ajax", "xhr timeout after ", r.timeout, "ms")
                    }, "GET" === a && n && (s = function(e, t) {
                        var n = document.createElement("a");
                        t && "noDecodeWholeURL" in t && t.noDecodeWholeURL ? n.href = e : n.href = decodeURIComponent(e);
                        t = t && "decodeSearchAsString" in t && t.decodeSearchAsString;
                        return {
                            href: n.href,
                            protocol: (n.protocol || "").replace(/:$/, ""),
                            hostname: n.hostname,
                            port: +n.port,
                            pathname: n.pathname.replace(/^(?!\/)/, "/"),
                            search: t ? n.search : function(e) {
                                return e ? e.replace(/^\?/, "").split("&").reduce(function(e, t) {
                                    var n = t.split("="),
                                        n = (t = 2, function(e) {
                                            if (Array.isArray(e)) return e
                                        }(n = n) || function(e, t) {
                                            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                                            if (null != n) {
                                                var r, o, i, a, s = [],
                                                    c = !0,
                                                    u = !1;
                                                try {
                                                    if (i = (n = n.call(e)).next, 0 === t) {
                                                        if (Object(n) !== n) return;
                                                        c = !1
                                                    } else
                                                        for (; !(c = (r = i.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
                                                } catch (e) {
                                                    u = !0, o = e
                                                } finally {
                                                    try {
                                                        if (!c && null != n.return && (a = n.return(), Object(a) !== a)) return
                                                    } finally {
                                                        if (u) throw o
                                                    }
                                                }
                                                return s
                                            }
                                        }(n, t) || function(e, t) {
                                            if (e) {
                                                if ("string" == typeof e) return f(e, t);
                                                var n = Object.prototype.toString.call(e).slice(8, -1);
                                                return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? f(e, t) : void 0
                                            }
                                        }(n, t) || function() {
                                            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                        }()),
                                        t = n[0],
                                        n = n[1];
                                    return /\[\]$/.test(t) ? (e[t = t.replace("[]", "")] = e[t] || [], e[t].push(n)) : e[t] = n || "", e
                                }, {}) : {}
                            }(n.search || ""),
                            hash: (n.hash || "").replace(/^#/, ""),
                            host: n.host || window.location.host
                        }
                    }(e, o), Object.assign(s.search, n), e = function(e) {
                        return (e.protocol || "http") + "://" + (e.host || e.hostname + (e.port ? ":".concat(e.port) : "")) + (e.pathname || "") + (e.search ? "?".concat(function(e) {
                            return Object.keys(e).map(function(t) {
                                return Array.isArray(e[t]) ? e[t].map(function(e) {
                                    return "".concat(t, "[]=").concat(e)
                                }).join("&") : "".concat(t, "=").concat(e[t])
                            }).join("&")
                        }(e.search || "")) : "") + (e.hash ? "#".concat(e.hash) : "")
                    }(s)), r.open(a, e, !0), o.withCredentials && (r.withCredentials = !0), y(o.customHeaders, function(e, t) {
                        r.setRequestHeader(t, e)
                    }), o.preflight && r.setRequestHeader("X-Requested-With", "XMLHttpRequest"), r.setRequestHeader("Content-Type", o.contentType || "text/plain"), "POST" === a && n ? r.send(n) : r.send()
                } catch (e) {
                    i.error("ajax", "xhr construction", e)
                }
            }, g.cyrb53Hash = function(e) {
                for (var t, n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0, r = function(e, t) {
                        if (d(Math.imul)) return Math.imul(e, t);
                        var n = (4194303 & e) * (t |= 0);
                        return 4290772992 & e && (n += (4290772992 & e) * t | 0), 0 | n
                    }, o = 3735928559 ^ n, i = 1103547991 ^ n, a = 0; a < e.length; a++) t = e.charCodeAt(a), o = r(o ^ t, 2654435761), i = r(i ^ t, 1597334677);
                return o = r(o ^ o >>> 16, 2246822507) ^ r(i ^ i >>> 13, 3266489909), (4294967296 * (2097151 & (i = r(i ^ i >>> 16, 2246822507) ^ r(o ^ o >>> 13, 3266489909))) + (o >>> 0)).toString()
            }, g.objectEntries = function(e) {
                var t = Object.keys(e),
                    n = t.length,
                    r = new Array(n);
                for (; n--;) r[n] = [t[n], e[t[n]]];
                return r
            };
            var u = m(1);

            function l(e) {
                return (l = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function f(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var t = "Array",
                n = "String",
                r = "Function",
                o = "Number",
                i = "Object",
                a = "Boolean",
                s = Object.prototype.toString;

            function c(e, t) {
                return s.call(e) === "[object " + t + "]"
            }

            function d(e) {
                return c(e, r)
            }

            function h(e) {
                return c(e, n)
            }

            function p(e) {
                return c(e, t)
            }

            function v(e) {
                if (!e) return !0;
                if (p(e) || h(e)) return !(0 < e.length);
                for (var t in e)
                    if (hasOwnProperty.call(e, t)) return !1;
                return !0
            }

            function y(e, t) {
                if (!v(e)) {
                    if (d(e.forEach)) return e.forEach(t, this);
                    var n = 0,
                        r = e.length;
                    if (0 < r)
                        for (; n < r; n++) t(e[n], n, e);
                    else
                        for (n in e) hasOwnProperty.call(e, n) && t.call(this, e[n], n)
                }
            }
        }.call(g, m(20))
}, function(e, t, n) {
    "use strict";

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(e, t) {
        return (i = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function a(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = s(n);
            return function(e, t) {
                {
                    if (t && ("object" === o(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return function(e) {
                    if (void 0 !== e) return e;
                    throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
                }(e)
            }(this, r ? (e = s(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function s(e) {
        return (s = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function c(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, function(e) {
                e = function(e, t) {
                    if ("object" !== o(e) || null === e) return e;
                    var n = e[Symbol.toPrimitive];
                    if (void 0 === n) return ("string" === t ? String : Number)(e);
                    t = n.call(e, t || "default");
                    if ("object" !== o(t)) return t;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }(e, "string");
                return "symbol" === o(e) ? e : String(e)
            }(r.key), r)
        }
    }

    function u(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }
    n.d(t, "a", function() {
        return l
    }), n.d(t, "c", function() {
        return f
    }), n.d(t, "b", function() {
        return d
    });
    var l = function() {
            function e() {
                c(this, e)
            }
            return u(e, [{
                key: "debug",
                value: function() {}
            }, {
                key: "info",
                value: function() {}
            }, {
                key: "warn",
                value: function() {}
            }, {
                key: "error",
                value: function() {}
            }]), e
        }(),
        f = new l,
        d = function() {
            ! function(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && i(e, t)
            }(o, l);
            var r = a(o);

            function o(e, t) {
                var n;
                return c(this, o), (n = r.call(this))._prefix = e, n._delegate = t, n
            }
            return u(o, [{
                key: "debug",
                value: function() {
                    for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    (e = this._delegate).debug.apply(e, [this._prefix].concat(n))
                }
            }, {
                key: "info",
                value: function() {
                    for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    (e = this._delegate).info.apply(e, [this._prefix].concat(n))
                }
            }, {
                key: "warn",
                value: function() {
                    for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    (e = this._delegate).warn.apply(e, [this._prefix].concat(n))
                }
            }, {
                key: "error",
                value: function() {
                    for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    (e = this._delegate).error.apply(e, [this._prefix].concat(n))
                }
            }]), o
        }()
}, function(e, t, n) {
    "use strict";
    var o = n(19),
        r = (n(12), n(16), n(1));
    n.d(t, "h", function() {
        return r.a
    }), n.d(t, "i", function() {
        return r.c
    });
    var i = n(3);
    n.d(t, "a", function() {
        return i.a
    }), n.d(t, "e", function() {
        return i.b
    });
    var a = n(11);
    n.d(t, "f", function() {
        return a.a
    });
    var s = n(6);
    n.d(t, "j", function() {
        return s.a
    });
    var c = n(4);
    n.d(t, "g", function() {
        return c.a
    }), n.d(t, "k", function() {
        return c.e
    });
    var u = n(15);
    n.d(t, "d", function() {
        return u.a
    });
    var l = n(8);
    n.d(t, "b", function() {
        return l.a
    });
    var f = n(0);
    n.d(t, "m", function() {
        return f
    });
    var d = n(9);

    function h(e) {
        return (h = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function p(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, function(e) {
                e = function(e, t) {
                    if ("object" !== h(e) || null === e) return e;
                    var n = e[Symbol.toPrimitive];
                    if (void 0 === n) return ("string" === t ? String : Number)(e);
                    t = n.call(e, t || "default");
                    if ("object" !== h(t)) return t;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }(e, "string");
                return "symbol" === h(e) ? e : String(e)
            }(r.key), r)
        }
    }
    n.d(t, "c", function() {
        return d.a
    });
    n = new(function() {
        function e() {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e)
        }
        var t, n, r;
        return t = e, (n = [{
            key: "createInstance",
            value: function(e, t, n, r) {
                return new o.a(e, {}, r, n, t)
            }
        }]) && p(t.prototype, n), r && p(t, r), Object.defineProperty(t, "prototype", {
            writable: !1
        }), e
    }());
    t.l = n
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return b
    }), n.d(t, "f", function() {
        return _
    }), n.d(t, "b", function() {
        return w
    }), n.d(t, "d", function() {
        return O
    }), n.d(t, "e", function() {
        return S
    }), n.d(t, "c", function() {
        return C
    });
    var r = n(0),
        o = ["localStoragePurposeConsent", "ccpaString"];

    function i(e) {
        return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function a(e, t) {
        if (null == e) return {};
        var n, r = function(e, t) {
            if (null == e) return {};
            var n, r, o = {},
                i = Object.keys(e);
            for (r = 0; r < i.length; r++) n = i[r], 0 <= t.indexOf(n) || (o[n] = e[n]);
            return o
        }(e, t);
        if (Object.getOwnPropertySymbols)
            for (var o = Object.getOwnPropertySymbols(e), i = 0; i < o.length; i++) n = o[i], 0 <= t.indexOf(n) || Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
        return r
    }

    function s(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, m(r.key), r)
        }
    }

    function u(e, t, n) {
        return t && s(e.prototype, t), n && s(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function l(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function c(n) {
        var r = p();
        return function() {
            var e, t = y(n);
            return function(e, t) {
                {
                    if (t && ("object" === i(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return f(e)
            }(this, r ? (e = y(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function f(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }

    function d(e) {
        var n = "function" == typeof Map ? new Map : void 0;
        return (d = function(e) {
            if (null === e || -1 === Function.toString.call(e).indexOf("[native code]")) return e;
            if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
            if (void 0 !== n) {
                if (n.has(e)) return n.get(e);
                n.set(e, t)
            }

            function t() {
                return h(e, arguments, y(this).constructor)
            }
            return t.prototype = Object.create(e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), v(t, e)
        })(e)
    }

    function h(e, t, n) {
        return (h = p() ? Reflect.construct.bind() : function(e, t, n) {
            var r = [null];
            r.push.apply(r, t);
            r = new(Function.bind.apply(e, r));
            return n && v(r, n.prototype), r
        }).apply(null, arguments)
    }

    function p() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
        } catch (e) {
            return !1
        }
    }

    function v(e, t) {
        return (v = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function y(e) {
        return (y = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function g(e, t, n) {
        return (t = m(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function m(e) {
        e = function(e, t) {
            if ("object" !== i(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== i(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === i(e) ? e : String(e)
    }
    var b = Object.freeze({
            NONE: "none",
            TCF_V1: "TCFv1",
            TCF_V2: "TCFv2",
            USP_V1: "USPv1",
            ID5_ALLOWED_VENDORS: "ID5",
            PREBID: "PBJS"
        }),
        _ = function() {
            ! function(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && v(e, t)
            }(r, d(Error));
            var n = c(r);

            function r(e, t) {
                return l(this, r), g(f(t = n.call(this, t)), "consentData", void 0), t.consentData = e, t
            }
            return r
        }(),
        w = function() {
            function c() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : b.NONE,
                    t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
                    n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : void 0,
                    r = 3 < arguments.length && void 0 !== arguments[3] && arguments[3],
                    o = 4 < arguments.length && void 0 !== arguments[4] && arguments[4],
                    i = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : "",
                    a = 6 < arguments.length && void 0 !== arguments[6] ? arguments[6] : void 0,
                    s = 7 < arguments.length && void 0 !== arguments[7] && arguments[7];
                l(this, c), g(this, "api", void 0), g(this, "gdprApplies", void 0), g(this, "consentString", void 0), g(this, "localStoragePurposeConsent", void 0), g(this, "allowedVendors", void 0), g(this, "hasCcpaString", void 0), g(this, "ccpaString", void 0), g(this, "forcedGrantByConfig", void 0), this.api = e, this.gdprApplies = t, this.consentString = n, this.localStoragePurposeConsent = r, this.hasCcpaString = o, this.ccpaString = i, this.allowedVendors = a, this.forcedGrantByConfig = s
            }
            return u(c, [{
                key: "localStorageGrant",
                value: function() {
                    var e = !0 === this.forcedGrantByConfig ? O.FORCE_ALLOWED_BY_CONFIG : void 0 === this.api || this.api === b.NONE ? O.PROVISIONAL : O.CONSENT_API;
                    return new S(this.isGranted(), e, this.api)
                }
            }, {
                key: "isGranted",
                value: function() {
                    switch (this.api) {
                        case b.NONE:
                            return !0;
                        case b.TCF_V1:
                            return !this.gdprApplies || !0 === this.localStoragePurposeConsent;
                        case b.TCF_V2:
                        case b.PREBID:
                            return !1 === this.gdprApplies || !0 === this.localStoragePurposeConsent;
                        case b.ID5_ALLOWED_VENDORS:
                            return this.allowedVendors.includes("131");
                        case b.USP_V1:
                            return !0
                    }
                }
            }, {
                key: "hashCode",
                value: function() {
                    this.localStoragePurposeConsent, this.ccpaString;
                    var e = a(this, o);
                    return Object(r.cyrb53Hash)(JSON.stringify(e))
                }
            }]), c
        }(),
        O = Object.freeze({
            FORCE_ALLOWED_BY_CONFIG: "force_allowed_by_config",
            ID5_CONSENT: "id5_consent",
            PROVISIONAL: "provisional",
            JURISDICTION: "jurisdiction",
            CONSENT_API: "consent_api"
        }),
        S = function() {
            function r(e, t, n) {
                l(this, r), g(this, "allowed", !1), g(this, "grantType", O.NONE), g(this, "api", b.NONE), this.allowed = e, this.grantType = t, this.api = n
            }
            return u(r, [{
                key: "isDefinitivelyAllowed",
                value: function() {
                    return this.allowed && this.grantType !== O.PROVISIONAL
                }
            }]), r
        }(),
        C = function() {
            function e() {
                l(this, e)
            }
            return u(e, [{
                key: "getConsentData",
                value: function() {}
            }, {
                key: "localStorageGrant",
                value: function() {}
            }, {
                key: "setStoredPrivacy",
                value: function(e) {}
            }]), e
        }()
}, function(e, t, n) {
    "use strict";

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(e, t) {
        return (i = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function a(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = c(n);
            return function(e, t) {
                {
                    if (t && ("object" === o(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return s(e)
            }(this, r ? (e = c(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function s(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }

    function c(e) {
        return (c = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function u(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, d(r.key), r)
        }
    }

    function l(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function f(e, t, n) {
        return (t = d(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function d(e) {
        e = function(e, t) {
            if ("object" !== o(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== o(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === o(e) ? e : String(e)
    }
    n.d(t, "a", function() {
        return p
    }), n.d(t, "d", function() {
        return v
    }), n.d(t, "b", function() {
        return y
    }), n.d(t, "e", function() {
        return g
    }), n.d(t, "c", function() {
        return m
    });
    var h = "_exp",
        p = function() {
            function t(e) {
                u(this, t), f(this, "storage", void 0), this.storage = e
            }
            return l(t, [{
                key: "getItem",
                value: function(e) {
                    try {
                        return this.storage.getItem(e)
                    } catch (e) {}
                }
            }, {
                key: "setItem",
                value: function(e, t) {
                    try {
                        this.storage.setItem(e, t)
                    } catch (e) {}
                }
            }, {
                key: "removeItem",
                value: function(e) {
                    try {
                        this.storage.removeItem(e)
                    } catch (e) {}
                }
            }, {
                key: "getItemWithExpiration",
                value: function(e) {
                    var t = e.name,
                        e = this.getItem(t + h);
                    return !e || new Date(e).getTime() - Date.now() <= 0 ? (this.removeItemWithExpiration({
                        name: t
                    }), null) : this.getItem(t)
                }
            }, {
                key: "setItemWithExpiration",
                value: function(e, t) {
                    var n = e.name,
                        e = e.expiresDays,
                        e = Date.now() + 864e5 * e,
                        e = new Date(e).toUTCString();
                    this.setItem(n + h, e), this.setItem(n, t)
                }
            }, {
                key: "removeItemWithExpiration",
                value: function(e) {
                    e = e.name;
                    this.removeItem(e), this.removeItem(e + h)
                }
            }]), t
        }();
    var v = function() {
            function e() {
                u(this, e)
            }
            return l(e, [{
                key: "getItem",
                value: function(e) {}
            }, {
                key: "removeItem",
                value: function(e) {}
            }, {
                key: "setItem",
                value: function(e, t) {}
            }]), e
        }(),
        y = new v,
        g = function() {
            ! function(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && i(e, t)
            }(o, v);
            var r = a(o);

            function o(e) {
                var t, n = !(1 < arguments.length && void 0 !== arguments[1]) || arguments[1];
                u(this, o), f(s(t = r.call(this)), "_writingEnabled", void 0), f(s(t), "_underlying", void 0), t._writingEnabled = n;
                try {
                    t._underlying = e.localStorage
                } catch (e) {}
                return t
            }
            return l(o, [{
                key: "getItem",
                value: function(e) {
                    try {
                        return this._underlying.getItem(e)
                    } catch (e) {}
                }
            }, {
                key: "removeItem",
                value: function(e) {
                    try {
                        this._underlying.removeItem(e)
                    } catch (e) {}
                }
            }, {
                key: "setItem",
                value: function(e, t) {
                    try {
                        this._writingEnabled && this._underlying.setItem(e, t)
                    } catch (e) {}
                }
            }], [{
                key: "checkIfAccessible",
                value: function() {
                    var e = "__id5test";
                    try {
                        return window.localStorage.setItem(e, e), window.localStorage.removeItem(e), !0
                    } catch (e) {
                        return !1
                    }
                }
            }]), o
        }(),
        m = function() {
            function t(e) {
                u(this, t), f(this, "_replicas", []), f(this, "_lastKeyOperation", {}), f(this, "_primaryStorage", void 0), this._primaryStorage = e
            }
            return l(t, [{
                key: "getItem",
                value: function(e) {
                    return this._primaryStorage.getItem(e)
                }
            }, {
                key: "removeItem",
                value: function(t) {
                    this._primaryStorage.removeItem(t);

                    function e(e) {
                        e.removeItem(t)
                    }
                    this._replicas.forEach(e), this._lastKeyOperation[t] = e
                }
            }, {
                key: "setItem",
                value: function(t, n) {
                    this._primaryStorage.setItem(t, n);

                    function e(e) {
                        e.setItem(t, n)
                    }
                    this._replicas.forEach(e), this._lastKeyOperation[t] = e
                }
            }, {
                key: "addReplica",
                value: function(t) {
                    Object.values(this._lastKeyOperation).forEach(function(e) {
                        return e(t)
                    }), this._replicas.push(t)
                }
            }]), t
        }()
}, function(e, t, n) {
    "use strict";
    t.b = function(e, t) {
        var n = !0;
        return i.m._each(e, function(e) {
            return n = n && t(e)
        }), n
    }, t.p = function(e) {
        y = !!e
    }, t.k = m, t.l = function() {
        return p
    }, n.d(t, "a", function() {
        return b
    }), n.d(t, "g", function() {
        return w
    }), n.d(t, "j", function() {
        return O
    }), n.d(t, "o", function() {
        return S
    }), n.d(t, "h", function() {
        return C
    }), n.d(t, "m", function() {
        return j
    }), n.d(t, "n", function() {
        return I
    }), n.d(t, "i", function() {
        return k
    }), t.d = function(e, t, n) {
        "loading" !== document.readyState ? E(e, t, n) : document.addEventListener("DOMContentLoaded", function() {
            E(e, t, n)
        })
    }, t.e = function(e, t, n, r, o) {
        for (t = t.split ? t.split(".") : t, r = 0; r < t.length; r++) e = e ? e[t[r]] : o;
        return e === o ? n : e
    }, t.c = function e(t, n) {
        var r = T(t) && T(n);
        if (!r) return t === n;
        var o = Object.keys(t);
        r = Object.keys(n);
        if (o.length !== r.length) return !1;
        for (var i = 0, a = o; i < a.length; i++) {
            var s = a[i];
            if (!e(t[s], n[s])) return !1
        }
        return !0
    }, t.f = function(e, t) {
        return A.apply(this, arguments)
    };
    var i = n(2);

    function c(e, t, n, r, o, i, a) {
        try {
            var s = e[i](a),
                c = s.value
        } catch (e) {
            return void n(e)
        }
        s.done ? t(c) : Promise.resolve(c).then(r, o)
    }

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function a(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, h(r.key), r)
        }
    }

    function s(e, t) {
        return (s = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function u(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = f(n);
            return function(e, t) {
                {
                    if (t && ("object" === o(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return l(e)
            }(this, r ? (e = f(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function l(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }

    function f(e) {
        return (f = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function d(e, t, n) {
        return (t = h(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function h(e) {
        e = function(e, t) {
            if ("object" !== o(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== o(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === o(e) ? e : String(e)
    }
    var r = "TRUE" === _("id5_debug").toUpperCase(),
        p = "TRACE" === _("id5_debug").toUpperCase(),
        v = Boolean(window.console),
        y = !1;

    function g(e, t, n, r, o) {
        m() && v && e && e.apply(console, ["%cID5 - ".concat(t, "#").concat(n), "color: #fff; background: #1c307e; padding: 1px 4px; border-radius: 3px;", r].concat(o))
    }

    function m() {
        return r || p || y
    }
    var b = function() {
        ! function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && s(e, t)
        }(o, i["h"]);
        var e, t, n, r = u(o);

        function o(e, t) {
            var n;
            return function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, o), d(l(n = r.call(this)), "_invocationId", void 0), d(l(n), "_origin", void 0), n._invocationId = t, n._origin = e, n
        }
        return e = o, (t = [{
            key: "debug",
            value: function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                ! function(e, t) {
                    for (var n = arguments.length, r = new Array(2 < n ? n - 2 : 0), o = 2; o < n; o++) r[o - 2] = arguments[o];
                    g(console.info, e, t, "DEBUG", r)
                }.apply(void 0, [this._origin, this._invocationId].concat(t))
            }
        }, {
            key: "info",
            value: function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                ! function(e, t) {
                    for (var n = arguments.length, r = new Array(2 < n ? n - 2 : 0), o = 2; o < n; o++) r[o - 2] = arguments[o];
                    g(console.info, e, t, "INFO", r)
                }.apply(void 0, [this._origin, this._invocationId].concat(t))
            }
        }, {
            key: "warn",
            value: function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                ! function(e, t) {
                    for (var n = arguments.length, r = new Array(2 < n ? n - 2 : 0), o = 2; o < n; o++) r[o - 2] = arguments[o];
                    g(console.warn, e, t, "WARNING", r)
                }.apply(void 0, [this._origin, this._invocationId].concat(t))
            }
        }, {
            key: "error",
            value: function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                ! function(e, t) {
                    for (var n = arguments.length, r = new Array(2 < n ? n - 2 : 0), o = 2; o < n; o++) r[o - 2] = arguments[o];
                    g(console.error, e, t, "ERROR", r)
                }.apply(void 0, [this._origin, this._invocationId].concat(t))
            }
        }]) && a(e.prototype, t), n && a(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), o
    }();

    function _(e) {
        e = new RegExp("[\\?&]" + e + "=([^&#]*)").exec(window.location.search);
        return null === e ? "" : decodeURIComponent(e[1].replace(/\+/g, " "))
    }
    var w = i.m.isA,
        O = i.m.isFn,
        S = i.m.isStr,
        C = i.m.isArray,
        j = i.m.isNumber,
        I = i.m.isPlainObject,
        k = i.m.isBoolean,
        P = i.m.isDefined;
    i.m.isEmpty, new b("ajax");

    function E(e, t, n) {
        var r = new Image;
        r.src = e, O(t) && t(), O(n) && (r.complete ? n() : r.addEventListener("load", n))
    }

    function D(e, t) {
        var n = [];
        return i.m._each(e, function(e) {
            t(e) && n.push(e)
        }), n
    }
    var T = function(e) {
        return null != e && "object" === o(e)
    };

    function A() {
        var s;
        return s = regeneratorRuntime.mark(function e(t, n) {
            var r;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (!P(window.navigator.userAgentData) || t) return e.abrupt("return", void 0);
                        e.next = 2;
                        break;
                    case 2:
                        return e.prev = 2, e.next = 5, window.navigator.userAgentData.getHighEntropyValues(["architecture", "fullVersionList", "model", "platformVersion"]);
                    case 5:
                        r = e.sent, e.next = 12;
                        break;
                    case 8:
                        return e.prev = 8, e.t0 = e.catch(2), n.error("Error while calling navigator.userAgentData.getHighEntropyValues()", e.t0), e.abrupt("return", void 0);
                    case 12:
                        return e.abrupt("return", function(e) {
                            if (!P(e)) return;
                            var t = /[()-.:;=?_/]/g;
                            C(e.brands) && (e.brands = D(e.brands, function(e) {
                                return S(e.brand) && e.brand.search(t) < 0
                            }));
                            C(e.fullVersionList) && (e.fullVersionList = D(e.fullVersionList, function(e) {
                                return S(e.brand) && e.brand.search(t) < 0
                            }));
                            return e
                        }(r));
                    case 13:
                    case "end":
                        return e.stop()
                }
            }, e, null, [
                [2, 8]
            ])
        }), (A = function() {
            var e = this,
                a = arguments;
            return new Promise(function(t, n) {
                var r = s.apply(e, a);

                function o(e) {
                    c(r, t, n, o, i, "next", e)
                }

                function i(e) {
                    c(r, t, n, o, i, "throw", e)
                }
                o(void 0)
            })
        }).apply(this, arguments)
    }
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return d
    }), n.d(t, "b", function() {
        return p
    });
    var l = n(0),
        o = n(9);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(e, t, n) {
        return (t = u(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function a(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function s(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, u(r.key), r)
        }
    }

    function c(e, t, n) {
        return t && s(e.prototype, t), n && s(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function u(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    var f = function() {
            function s(e, t) {
                a(this, s), this.name = e, this.expiresDays = t
            }
            return c(s, [{
                key: "withNameSuffixed",
                value: function() {
                    for (var e = this.name, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    for (var o = 0, i = n; o < i.length; o++) {
                        var a = i[o];
                        e += "_".concat(a)
                    }
                    return new s(e, this.expiresDays)
                }
            }]), s
        }(),
        d = function e() {
            var n = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
            a(this, e);

            function t(e) {
                var t = void 0 !== n ? Math.max(1, n) : e.expiresDays;
                return new f(e.name, t)
            }
            var r = o.a.STORAGE_CONFIG;
            this.ID5 = t(r.ID5), this.LAST = t(r.LAST), this.CONSENT_DATA = t(r.CONSENT_DATA), this.PD = t(r.PD), this.PRIVACY = t(r.PRIVACY), this.SEGMENTS = t(r.SEGMENTS)
        },
        h = function() {
            function e() {
                a(this, e), i(this, "storedResponse", void 0), i(this, "storedDateTime", void 0), i(this, "pdHasChanged", void 0), i(this, "segmentsHaveChanged", void 0), i(this, "refreshInSeconds", void 0), i(this, "nb", void 0), i(this, "consentHasChanged", void 0)
            }
            return c(e, [{
                key: "isResponsePresent",
                value: function() {
                    return void 0 !== this.storedResponse
                }
            }, {
                key: "hasValidUid",
                value: function() {
                    return this.storedResponse && this.storedResponse.universal_uid
                }
            }, {
                key: "isResponseComplete",
                value: function() {
                    return this.storedResponse && this.storedResponse.universal_uid && this.storedResponse.signature
                }
            }, {
                key: "refreshInSecondsHasElapsed",
                value: function() {
                    return this.storedDateTime <= 0 || Date.now() - this.storedDateTime > 1e3 * this.refreshInSeconds
                }
            }, {
                key: "isStoredIdStale",
                value: function() {
                    return this.storedDateTime <= 0 || 12096e5 < Date.now() - this.storedDateTime
                }
            }]), e
        }(),
        p = function() {
            function t(e) {
                a(this, t), i(this, "_clientStoreV1", void 0), this._clientStoreV1 = e
            }
            return c(t, [{
                key: "getStoredDataState",
                value: function(e) {
                    var t, r = this,
                        n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0,
                        o = this._clientStoreV1.getResponse(),
                        i = this._clientStoreV1.getDateTime(),
                        a = {},
                        s = !1,
                        c = !1,
                        u = e[0].refreshInSeconds || 7200;
                    e.forEach(function(e) {
                        var t = e.partnerId,
                            n = r._clientStoreV1.getNb(t);
                        a[t] = void 0 !== n ? n : 0;
                        n = !r._clientStoreV1.isStoredPdUpToDate(t, e.pd), t = !r._clientStoreV1.storedSegmentsMatchesSegments(t, e.segments);
                        c = c || t, s = s || n, u > e.refreshInSeconds && (u = e.refreshInSeconds)
                    }), Object(l.isNumber)(null == o || null === (t = o.cache_control) || void 0 === t ? void 0 : t.max_age_sec) && (u = o.cache_control.max_age_sec);
                    n = n && !this._clientStoreV1.storedConsentDataMatchesConsentData(n);
                    return Object.assign(new h, {
                        storedResponse: o,
                        storedDateTime: i,
                        pdHasChanged: s,
                        segmentsHaveChanged: c,
                        refreshInSeconds: u,
                        nb: a,
                        consentHasChanged: n
                    })
                }
            }, {
                key: "storeRequestData",
                value: function(e, t) {
                    var r = this;
                    this._clientStoreV1.putHashedConsentData(e), t.forEach(function(e) {
                        var t = e.partnerId,
                            n = e.pd,
                            e = e.segments;
                        r._clientStoreV1.isStoredPdUpToDate(t, n) || r._clientStoreV1.putHashedPd(t, n), r._clientStoreV1.putHashedSegments(t, e)
                    })
                }
            }, {
                key: "incNbs",
                value: function(e, t) {
                    var n = this;
                    e.forEach(function(e) {
                        e = e.partnerId;
                        t.nb[e] = n._clientStoreV1.incNb(e, t.nb[e])
                    })
                }
            }, {
                key: "storeResponse",
                value: function(e, t, n) {
                    var r = this;
                    this._clientStoreV1.putResponse(t), this._clientStoreV1.setDateTime((new Date).toUTCString());
                    var o = n ? 0 : 1;
                    e.forEach(function(e) {
                        e = e.partnerId;
                        r._clientStoreV1.setNb(e, o)
                    })
                }
            }, {
                key: "clearAll",
                value: function(e) {
                    var t = this;
                    this._clientStoreV1.clearResponse(), this._clientStoreV1.clearDateTime(), e.forEach(function(e) {
                        e = e.partnerId;
                        t._clientStoreV1.clearNb(e), t._clientStoreV1.clearHashedPd(e), t._clientStoreV1.clearHashedSegments(e)
                    }), this._clientStoreV1.clearHashedConsentData()
                }
            }]), t
        }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "b", function() {
        return p
    }), n.d(t, "c", function() {
        return y
    }), n.d(t, "e", function() {
        return m
    }), n.d(t, "d", function() {
        return b
    }), n.d(t, "a", function() {
        return _
    });
    var o = n(1);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(e) {
        return function(e) {
            if (Array.isArray(e)) return a(e)
        }(e) || function(e) {
            if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
        }(e) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return a(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? a(e, t) : void 0
            }
        }(e) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function a(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function s(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, f(r.key), r)
        }
    }

    function c(e, t, n) {
        return t && s(e.prototype, t), n && s(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function u(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function l(e, t, n) {
        return (t = f(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function f(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }

    function d(e, t, n, r, o, i) {
        var a = 6 < arguments.length && void 0 !== arguments[6] ? arguments[6] : void 0;
        u(this, d), l(this, "_isId5Message", !0), l(this, "id", void 0), l(this, "timestamp", void 0), l(this, "type", void 0), l(this, "src", void 0), l(this, "dst", void 0), l(this, "request", void 0), l(this, "payload", void 0), this.id = r, this.timestamp = e, this.src = t, this.dst = n, this.type = i, this.request = a, this.payload = o
    }
    var h = "*",
        p = void 0,
        v = function() {
            function t(e) {
                u(this, t), l(this, "_senderId", void 0), l(this, "_messageSeqNb", 0), this._senderId = e, this._messageSeqNb = 0
            }
            return c(t, [{
                key: "createBroadcastMessage",
                value: function(e) {
                    var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : e.constructor.name;
                    return new d(Date.now(), this._senderId, p, ++this._messageSeqNb, e, t || e.constructor.name)
                }
            }, {
                key: "createResponse",
                value: function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : t.constructor.name;
                    return new d(Date.now(), this._senderId, e.src, ++this._messageSeqNb, t, n || t.constructor.name, e)
                }
            }, {
                key: "createUnicastMessage",
                value: function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : t.constructor.name;
                    return new d(Date.now(), this._senderId, e, ++this._messageSeqNb, t, n || t.constructor.name)
                }
            }]), t
        }(),
        y = function e(t) {
            var n = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
                r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : void 0;
            u(this, e), l(this, "instance", void 0), l(this, "instanceState", void 0), l(this, "isResponse", void 0), this.instance = t, this.instanceState = r, this.isResponse = n
        };
    l(y, "TYPE", "HelloMessage");

    function g(e, t, n) {
        u(this, g), l(this, "target", void 0), l(this, "methodName", void 0), l(this, "methodArguments", void 0), this.target = e, this.methodName = t, this.methodArguments = n
    }
    var m = Object.freeze({
        LEADER: "leader",
        FOLLOWER: "follower",
        STORAGE: "storage"
    });
    l(g, "TYPE", "RemoteMethodCallMessage");
    var b = function() {
            function t() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : o.c;
                u(this, t), l(this, "_targets", {}), l(this, "_log", void 0), this._log = e
            }
            return c(t, [{
                key: "registerTarget",
                value: function(e, t) {
                    return this._targets[e] = t, this
                }
            }, {
                key: "_handle",
                value: function(t) {
                    var e = this._targets[t.target];
                    if (e) try {
                        e[t.methodName].apply(e, i(t.methodArguments))
                    } catch (e) {
                        this._log.error("Error while handling method call ", t, e)
                    }
                }
            }]), t
        }(),
        _ = function() {
            function r(e, t) {
                var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : o.c;
                u(this, r), l(this, "_id", void 0), l(this, "_messageFactory", void 0), l(this, "_log", void 0), l(this, "_onMessageCallBackFunction", void 0), this._id = e, this._messageFactory = new v(this._id), this._log = n, this._window = t, this._handlers = {}, this._register()
            }
            return c(r, [{
                key: "_register",
                value: function() {
                    var r = this;
                    r._abortController = "undefined" != typeof AbortController ? new AbortController : void 0;
                    var e = null === (e = r._abortController) || void 0 === e ? void 0 : e.signal;
                    r._window.addEventListener("message", function(t) {
                        var n = t.data;
                        if (void 0 !== t.data && t.data._isId5Message)
                            if (t.data.src !== r._id)
                                if (void 0 === t.data.dst || t.data.dst === r._id) try {
                                    [h, n.type].forEach(function(e) {
                                        e = r._handlers[e];
                                        e && e.forEach(function(e) {
                                            return e(n, t.source)
                                        })
                                    })
                                } catch (e) {
                                    r._log.error("Error while handling message", n, e)
                                } else r._log.debug("Ignore msg not to me");
                                else r._log.debug("Ignore loopback msg")
                    }, {
                        capture: !1,
                        signal: e
                    })
                }
            }, {
                key: "deregister",
                value: function() {
                    this._abortController && this._abortController.abort()
                }
            }, {
                key: "onAnyMessage",
                value: function(e) {
                    return this.onMessage(h, e)
                }
            }, {
                key: "onMessage",
                value: function(e, t) {
                    var n = this._handlers[e];
                    return n ? n.push(t) : this._handlers[e] = [t], this
                }
            }, {
                key: "broadcastMessage",
                value: function(e, t) {
                    this._log.debug("Broadcasting message", t, e), this._postMessage(this._messageFactory.createBroadcastMessage(e, t))
                }
            }, {
                key: "sendResponseMessage",
                value: function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : t.constructor.name;
                    this._log.debug("Sending response message", e, n, t), this._postMessage(this._messageFactory.createResponse(e, t, n))
                }
            }, {
                key: "unicastMessage",
                value: function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : t.constructor.name;
                    this._log.debug("Sending message to", e, n, t), this._postMessage(this._messageFactory.createUnicastMessage(e, t, n))
                }
            }, {
                key: "_postToWindow",
                value: function(e, t) {
                    try {
                        e.postMessage(t, "*")
                    } catch (e) {
                        this._log.error("Could not post message to window", e)
                    }
                }
            }, {
                key: "_postMessage",
                value: function(o) {
                    var i = this;
                    (function e(t) {
                        try {
                            i._postToWindow(t, o);
                            var n = t.frames;
                            if (n)
                                for (var r = 0; r < n.length; r++) e(n[r])
                        } catch (e) {
                            i._log.error("Could not broadcast message", e)
                        }
                    })(i._window.top)
                }
            }, {
                key: "callProxyMethod",
                value: function(e, t, n, r) {
                    this._log.info("Calling ProxyMethodCall", {
                        target: t,
                        name: n,
                        args: r
                    }), this.unicastMessage(e, new g(t, n, r), g.TYPE)
                }
            }, {
                key: "onProxyMethodCall",
                value: function(t) {
                    return this.onMessage(g.TYPE, function(e) {
                        t._handle(Object.assign(new g, e.payload))
                    })
                }
            }]), r
        }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return f
    }), n.d(t, "c", function() {
        return d
    }), n.d(t, "b", function() {
        return p
    });
    var o = n(1);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, s(r.key), r)
        }
    }

    function a(e, t, n) {
        return (t = s(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function s(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }

    function c(e) {
        return function(e) {
            if (Array.isArray(e)) return l(e)
        }(e) || function(e) {
            if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
        }(e) || u(e) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function u(e, t) {
        if (e) {
            if ("string" == typeof e) return l(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(e, t) : void 0
        }
    }

    function l(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }
    var f = Object.freeze({
            CONSENT_UPDATED: "consent_updated",
            USER_ID_READY: "user_id_ready",
            CASCADE_NEEDED: "fire_sync_pixel",
            USER_ID_FETCH_CANCELED: "user_id_fetch_canceled",
            USER_ID_FETCH_FAILED: "user_id_fetch_failed"
        }),
        d = Object.freeze({
            ID5_MESSAGE_RECEIVED: "message",
            ID5_INSTANCE_JOINED: "instance-joined",
            ID5_LEADER_ELECTED: "leader-elected"
        }),
        h = Object.freeze([].concat(c(Object.values(d)), c(Object.values(f)))),
        p = function() {
            function t() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : o.c;
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, t), a(this, "_handlers", void 0), a(this, "_log", void 0), this._log = e, this._handlers = {}
            }
            var e, n, r;
            return e = t, (n = [{
                key: "_dispatch",
                value: function(t) {
                    var e = this._handlers[t];
                    if (e) {
                        for (var n = arguments.length, r = new Array(1 < n ? n - 1 : 0), o = 1; o < n; o++) r[o - 1] = arguments[o];
                        var i, a = function(e, t) {
                            var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                            if (!n) {
                                if (Array.isArray(e) || (n = u(e)) || t && e && "number" == typeof e.length) {
                                    n && (e = n);
                                    var r = 0,
                                        t = function() {};
                                    return {
                                        s: t,
                                        n: function() {
                                            return r >= e.length ? {
                                                done: !0
                                            } : {
                                                done: !1,
                                                value: e[r++]
                                            }
                                        },
                                        e: function(e) {
                                            throw e
                                        },
                                        f: t
                                    }
                                }
                                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                            }
                            var o, i = !0,
                                a = !1;
                            return {
                                s: function() {
                                    n = n.call(e)
                                },
                                n: function() {
                                    var e = n.next();
                                    return i = e.done, e
                                },
                                e: function(e) {
                                    a = !0, o = e
                                },
                                f: function() {
                                    try {
                                        i || null == n.return || n.return()
                                    } finally {
                                        if (a) throw o
                                    }
                                }
                            }
                        }(e);
                        try {
                            for (a.s(); !(i = a.n()).done;) {
                                var s = i.value;
                                try {
                                    s.apply(void 0, r)
                                } catch (e) {
                                    this._log.error("Event ".concat(t, " handler execution failed."), e)
                                }
                            }
                        } catch (e) {
                            a.e(e)
                        } finally {
                            a.f()
                        }
                    }
                }
            }, {
                key: "emit",
                value: function(e) {
                    if (void 0 !== e && h.includes(e)) {
                        for (var t = arguments.length, n = new Array(1 < t ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                        this._dispatch.apply(this, [e].concat(n))
                    } else this._log.warn("Unsupported event", e)
                }
            }, {
                key: "on",
                value: function(e, t) {
                    void 0 !== e && h.includes(e) ? (this._handlers[e] || (this._handlers[e] = []), this._handlers[e].push(t)) : this._log.warn("Unsupported event", e)
                }
            }]) && i(e.prototype, n), r && i(e, r), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t
        }()
}, function(e, t, n) {
    "use strict";
    t.a = Object.freeze({
        STORAGE_CONFIG: {
            ID5: {
                name: "id5id",
                expiresDays: 90
            },
            LAST: {
                name: "id5id_last",
                expiresDays: 90
            },
            CONSENT_DATA: {
                name: "id5id_cached_consent_data",
                expiresDays: 30
            },
            PD: {
                name: "id5id_cached_pd",
                expiresDays: 30
            },
            SEGMENTS: {
                name: "id5id_cached_segments",
                expiresDays: 30
            },
            PRIVACY: {
                name: "id5id_privacy",
                expiresDays: 30
            }
        },
        LEGACY_COOKIE_NAMES: ["id5.1st", "id5id.1st"],
        PRIVACY: {
            JURISDICTIONS: {
                gdpr: !0,
                ccpa: !1,
                lgpd: !0,
                other: !1
            }
        },
        ID5_EIDS_SOURCE: "id5-sync.com"
    })
}, function(e, t, n) {
    "use strict";
    t.b = function(n, r) {
        if (Math.random() < n && o.a) return function(e, t) {
            return new o.b(r, {
                sampling: n
            }).publish(e, t)
        };
        return function(e) {
            return e
        }
    }, t.d = function() {
        return new i.c
    }, t.c = p, n.d(t, "a", function() {
        return v
    });
    var o = n(25),
        r = n(26),
        i = n(13);

    function a(e) {
        return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function s(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function c(r) {
        for (var e = 1; e < arguments.length; e++) {
            var o = null != arguments[e] ? arguments[e] : {};
            e % 2 ? s(Object(o), !0).forEach(function(e) {
                var t, n;
                t = r, e = o[n = e], (n = l(n)) in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(o)) : s(Object(o)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(o, e))
            })
        }
        return r
    }

    function u(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, l(r.key), r)
        }
    }

    function l(e) {
        e = function(e, t) {
            if ("object" !== a(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== a(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === a(e) ? e : String(e)
    }

    function f(e, t) {
        return (f = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function d(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = h(n);
            return function(e, t) {
                {
                    if (t && ("object" === a(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return function(e) {
                    if (void 0 !== e) return e;
                    throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
                }(e)
            }(this, r ? (e = h(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function h(e) {
        return (h = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function p(e) {
        return {
            partner: e
        }
    }
    var v = function() {
        ! function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && f(e, t)
        }(i, r["a"]);
        var e, t, n, o = d(i);

        function i(e, t) {
            var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : void 0,
                r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : void 0;
            return function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, i), o.call(this, c(c({
                source: e,
                version: t
            }, p(n)), r), "id5.api")
        }
        return e = i, (t = [{
            key: "loadDelayTimer",
            value: function() {
                return this.timer("instance.load.delay", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "fetchCallTimer",
            value: function(e) {
                return this.timer("fetch.call.time", c({
                    status: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "fetchFailureCallTimer",
            value: function() {
                return this.fetchCallTimer("fail", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "fetchSuccessfulCallTimer",
            value: function() {
                return this.fetchCallTimer("success", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "extensionsCallTimer",
            value: function(e, t) {
                return this.timer("extensions.call.time", c({
                    extensionType: e,
                    status: t ? "success" : "fail"
                }, 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {}))
            }
        }, {
            key: "consentRequestTimer",
            value: function(e) {
                return this.timer("consent.request.time", c({
                    requestType: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "invocationCountSummary",
            value: function() {
                return this.summary("invocation.count", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "instanceCounter",
            value: function(e) {
                return this.counter("instance.count", c({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceUniqueDomainsCounter",
            value: function(e) {
                return this.counter("instance.domains.count", c({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceUniqWindowsCounter",
            value: function(e) {
                return this.counter("instance.windows.count", c({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceUniqPartnersCounter",
            value: function(e) {
                return this.counter("instance.partners.count", c({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceJoinDelayTimer",
            value: function() {
                return this.timer("instance.join.delay.time", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "instanceLateJoinCounter",
            value: function(e) {
                return this.counter("instance.lateJoin.count", c({
                    instanceId: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "instanceLateJoinDelayTimer",
            value: function() {
                return this.timer("instance.lateJoin.delay", c({}, 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}))
            }
        }, {
            key: "instanceLastJoinDelayTimer",
            value: function() {
                return this.timer("instance.lastJoin.delay", c({}, 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}))
            }
        }, {
            key: "instanceMsgDeliveryTimer",
            value: function() {
                return this.timer("instance.message.delivery.time", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }, {
            key: "userIdProvisioningDelayTimer",
            value: function(e) {
                return this.timer("userid.provisioning.delay", c({
                    cachedResponseUsed: e
                }, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}))
            }
        }, {
            key: "userIdNotificationDeliveryDelayTimer",
            value: function() {
                return this.timer("userid.provisioning.delivery.delay", c({}, 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}))
            }
        }, {
            key: "consentChangeCounter",
            value: function() {
                return this.counter("leader.consent.change.count", 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {})
            }
        }]) && u(e.prototype, t), n && u(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), i
    }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return v
    });
    var r = n(0),
        o = n(9),
        s = n(12),
        c = n(3);

    function i(e) {
        return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function u(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, p(r.key), r)
        }
    }

    function l(e, t) {
        return (l = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function f(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = a(n);
            return function(e, t) {
                {
                    if (t && ("object" === i(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return d(e)
            }(this, r ? (e = a(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function d(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }

    function a(e) {
        return (a = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function h(e, t, n) {
        return (t = p(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function p(e) {
        e = function(e, t) {
            if ("object" !== i(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== i(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === i(e) ? e : String(e)
    }
    var v = function() {
        ! function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(e, "prototype", {
                writable: !1
            }), t && l(e, t)
        }(a, c["c"]);
        var e, t, n, i = f(a);

        function a(e, t, n, r) {
            var o;
            return function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, a), h(d(o = i.call(this)), "_consentDataHolder", void 0), h(d(o), "storedPrivacyData", void 0), h(d(o), "localStorage", void 0), h(d(o), "_forceAllowLocalStorageGrant", void 0), o._log = r, o.localStorage = e, o.storageConfig = t, o._consentDataHolder = new s.a, o._forceAllowLocalStorageGrant = n, o
        }
        return e = a, (t = [{
            key: "resetConsentData",
            value: function(e) {
                this._consentDataHolder.reset(), this.storedPrivacyData = void 0, this._forceAllowLocalStorageGrant = e
            }
        }, {
            key: "localStorageGrant",
            value: function() {
                var e, t = this._log;
                if (!0 === this._forceAllowLocalStorageGrant) return t.warn("cmpApi: Local storage access granted by configuration override, consent will not be checked"), new c.e(!0, c.d.FORCE_ALLOWED_BY_CONFIG, c.a.NONE);
                if (this._consentDataHolder.hasValue() && this._consentDataHolder.getValue().api !== c.a.NONE) return this._consentDataHolder.getValue().localStorageGrant();
                if (Object(r.isPlainObject)(this.storedPrivacyData) || (e = this.localStorage.getItemWithExpiration(this.storageConfig.PRIVACY), this.storedPrivacyData = e && JSON.parse(e), t.info("cmpApi: Loaded stored privacy data from local storage", this.storedPrivacyData)), this.storedPrivacyData && !0 === this.storedPrivacyData.id5_consent) return new c.e(!0, c.d.ID5_CONSENT, c.a.NONE);
                if (!this.storedPrivacyData || !Object(r.isDefined)(this.storedPrivacyData.jurisdiction)) return new c.e(!0, c.d.PROVISIONAL, c.a.NONE);
                t = this.storedPrivacyData.jurisdiction, t = t in o.a.PRIVACY.JURISDICTIONS && o.a.PRIVACY.JURISDICTIONS[t];
                return new c.e(!1 === t, c.d.JURISDICTION, c.a.NONE)
            }
        }, {
            key: "setStoredPrivacy",
            value: function(e) {
                var t = this._log;
                try {
                    Object(r.isPlainObject)(e) ? (this.storedPrivacyData = e, this.localStorage.setItemWithExpiration(this.storageConfig.PRIVACY, JSON.stringify(e))) : t.error("cmpApi: Cannot store privacy data if it is not an object", e)
                } catch (e) {
                    t.error("cmpApi: Error while storing privacy data", e)
                }
            }
        }, {
            key: "setConsentData",
            value: function(e) {
                this._log.debug("Set consent data", e);
                e = Object.assign(new c.b, e);
                this._consentDataHolder.set(e)
            }
        }, {
            key: "getConsentData",
            value: function() {
                return this._consentDataHolder.getValuePromise()
            }
        }]) && u(e.prototype, t), n && u(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), a
    }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return c
    });
    var o = n(0);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, s(r.key), r)
        }
    }

    function a(e, t, n) {
        return (t = s(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function s(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    var c = function() {
        function e() {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e), a(this, "_valuePromise", void 0), a(this, "_value", void 0), a(this, "_resolve", void 0), this.reset()
        }
        var t, n, r;
        return t = e, (n = [{
            key: "reset",
            value: function() {
                var n = this;
                n._value = void 0, n._valuePromise = new Promise(function(e, t) {
                    n._resolve = e
                })
            }
        }, {
            key: "set",
            value: function(e) {
                this._value = e, this._resolve(this._value)
            }
        }, {
            key: "getValuePromise",
            value: function() {
                return this._valuePromise
            }
        }, {
            key: "hasValue",
            value: function() {
                return Object(o.isDefined)(this._value)
            }
        }, {
            key: "getValue",
            value: function() {
                return this._value
            }
        }]) && i(t.prototype, n), r && i(t, r), Object.defineProperty(t, "prototype", {
            writable: !1
        }), e
    }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "d", function() {
        return y
    }), n.d(t, "c", function() {
        return g
    }), n.d(t, "a", function() {
        return m
    }), n.d(t, "b", function() {
        return b
    });
    var o = n(14);

    function i(e) {
        return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function a(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                writable: !0,
                configurable: !0
            }
        }), Object.defineProperty(e, "prototype", {
            writable: !1
        }), t && r(e, t)
    }

    function r(e, t) {
        return (r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function s(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = c(n);
            return function(e, t) {
                {
                    if (t && ("object" === i(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return function(e) {
                    if (void 0 !== e) return e;
                    throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
                }(e)
            }(this, r ? (e = c(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function c(e) {
        return (c = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function u(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function l(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, h(r.key), r)
        }
    }

    function f(e, t, n) {
        return t && l(e.prototype, t), n && l(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function d(e, t, n) {
        return (t = h(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function h(e) {
        e = function(e, t) {
            if ("object" !== i(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== i(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === i(e) ? e : String(e)
    }
    var p = Object.freeze({
            TIMER: "TIMER",
            SUMMARY: "SUMMARY",
            COUNTER: "COUNTER"
        }),
        v = function() {
            function r(e, t, n) {
                u(this, r), d(this, "name", void 0), d(this, "tags", void 0), d(this, "values", void 0), this.name = e, this.tags = o.a.from(t), this.type = n, this.values = []
            }
            return f(r, [{
                key: "reset",
                value: function() {
                    this.values = []
                }
            }]), r
        }(),
        y = function() {
            a(r, v);
            var n = s(r);

            function r(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                return u(this, r), n.call(this, e, t, p.TIMER)
            }
            return f(r, [{
                key: "startMeasurement",
                value: function() {
                    try {
                        return new g(this)
                    } catch (e) {
                        return
                    }
                }
            }, {
                key: "record",
                value: function(e) {
                    try {
                        isNaN(e) || this.values.push({
                            value: e,
                            timestamp: Date.now()
                        })
                    } catch (e) {}
                }
            }, {
                key: "recordNow",
                value: function() {
                    try {
                        var e;
                        this.record(0 | (null === (e = performance) || void 0 === e ? void 0 : e.now()))
                    } catch (e) {}
                }
            }]), r
        }(),
        g = function() {
            function t() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
                u(this, t), this.timer = e, this.startTime = performance.now()
            }
            return f(t, [{
                key: "record",
                value: function() {
                    var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
                    try {
                        var t = performance.now() - this.startTime | 0,
                            n = e || this.timer;
                        return n && n.record(t), t
                    } catch (e) {
                        return
                    }
                }
            }]), t
        }(),
        m = function() {
            a(r, v);
            var n = s(r);

            function r(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                return u(this, r), n.call(this, e, t, p.COUNTER)
            }
            return f(r, [{
                key: "inc",
                value: function() {
                    var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 1;
                    try {
                        return 0 === this.values.length ? this.values.push({
                            value: e,
                            timestamp: Date.now()
                        }) : (this.values[0].value += e, this.values[0].timestamp = Date.now()), this.values[0].value
                    } catch (e) {}
                }
            }]), r
        }(),
        b = function() {
            a(r, v);
            var n = s(r);

            function r(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                return u(this, r), n.call(this, e, t, p.SUMMARY)
            }
            return f(r, [{
                key: "record",
                value: function(e) {
                    try {
                        this.values.push({
                            value: e,
                            timestamp: Date.now()
                        })
                    } catch (e) {}
                }
            }]), r
        }()
}, function(e, t, n) {
    "use strict";

    function r(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null != n) {
                var r, o, i, a, s = [],
                    c = !0,
                    u = !1;
                try {
                    if (i = (n = n.call(e)).next, 0 === t) {
                        if (Object(n) !== n) return;
                        c = !1
                    } else
                        for (; !(c = (r = i.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
                } catch (e) {
                    u = !0, o = e
                } finally {
                    try {
                        if (!c && null != n.return && (a = n.return(), Object(a) !== a)) return
                    } finally {
                        if (u) throw o
                    }
                }
                return s
            }
        }(e, t) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return o(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? o(e, t) : void 0
            }
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function o(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }
    var i = Object.freeze({});
    t.a = {
        EMPTY: i,
        from: function(e) {
            return e ? e instanceof Map ? Object.fromEntries(e) : e : i
        },
        toString: function(e) {
            return Array.from(Object.entries(e), function(e) {
                var t = r(e, 2),
                    e = t[0],
                    t = t[1];
                return "".concat(e, "=").concat(t)
            }).sort().toString()
        }
    }
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return u
    });
    var i = n(0),
        r = n(3);
    n(6), n(4);

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function a(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, c(r.key), r)
        }
    }

    function s(e, t, n) {
        return (t = c(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function c(e) {
        e = function(e, t) {
            if ("object" !== o(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== o(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === o(e) ? e : String(e)
    }
    var u = function() {
        function o(e, t, n, r) {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, o), s(this, "localStorageGrantChecker", void 0), s(this, "localStorage", void 0), s(this, "_log", void 0), this.localStorageGrantChecker = e, this.localStorage = t, this.storageConfig = n, this._log = r
        }
        var e, t, n;
        return e = o, n = [{
            key: "makeStoredHash",
            value: function(e) {
                return Object(i.cyrb53Hash)("string" == typeof e ? e : "")
            }
        }, {
            key: "storedDataMatchesCurrentData",
            value: function(e, t) {
                return null == e || e === t
            }
        }], (t = [{
            key: "get",
            value: function(e) {
                var t = this._log;
                try {
                    var n = this.localStorageGrant();
                    if (n.isDefinitivelyAllowed()) {
                        var r = this.localStorage.getItemWithExpiration(e);
                        return t.info("Local storage get key=".concat(e.name, " value=").concat(r)), r
                    }
                    t.warn("clientStore.get() has been called without definitive grant", n)
                } catch (e) {
                    t.error(e)
                }
            }
        }, {
            key: "clear",
            value: function(e) {
                var t = this._log;
                try {
                    this.localStorage.removeItemWithExpiration(e)
                } catch (e) {
                    t.error(e)
                }
            }
        }, {
            key: "put",
            value: function(e, t) {
                var n = this._log;
                try {
                    var r = this.localStorageGrant();
                    r.isDefinitivelyAllowed() ? (n.info("Local storage put key=".concat(e.name, " value=").concat(t)), this.localStorage.setItemWithExpiration(e, t)) : n.warn("clientStore.put() has been called without definitive grant", r)
                } catch (e) {
                    n.error(e)
                }
            }
        }, {
            key: "localStorageGrant",
            value: function() {
                return this.localStorageGrantChecker()
            }
        }, {
            key: "getResponse",
            value: function() {
                var e = this.get(this.storageConfig.ID5);
                return e && JSON.parse(decodeURIComponent(e))
            }
        }, {
            key: "clearResponse",
            value: function() {
                this.clear(this.storageConfig.ID5)
            }
        }, {
            key: "putResponse",
            value: function(e) {
                this.put(this.storageConfig.ID5, encodeURIComponent(Object(i.isStr)(e) ? e : JSON.stringify(e)))
            }
        }, {
            key: "getHashedConsentData",
            value: function() {
                return this.get(this.storageConfig.CONSENT_DATA)
            }
        }, {
            key: "clearHashedConsentData",
            value: function() {
                this.clear(this.storageConfig.CONSENT_DATA)
            }
        }, {
            key: "putHashedConsentData",
            value: function(e) {
                e !== new r.b && this.put(this.storageConfig.CONSENT_DATA, e.hashCode())
            }
        }, {
            key: "getHashedPd",
            value: function(e) {
                return this.get(this.pdCacheConfig(e))
            }
        }, {
            key: "isStoredPdUpToDate",
            value: function(e, t) {
                var n = this.getHashedPd(e),
                    r = Object(i.isEmpty)(t) && !Object(i.isEmpty)(n),
                    e = Object(i.isEmpty)(n) && Object(i.isEmpty)(t);
                return r || e || n === o.makeStoredHash(t)
            }
        }, {
            key: "clearHashedPd",
            value: function(e) {
                this.clear(this.pdCacheConfig(e))
            }
        }, {
            key: "putHashedPd",
            value: function(e, t) {
                this.put(this.pdCacheConfig(e), o.makeStoredHash(t))
            }
        }, {
            key: "getHashedSegments",
            value: function(e) {
                return this.get(this.segmentsCacheConfig(e))
            }
        }, {
            key: "putHashedSegments",
            value: function(e, t) {
                this.put(this.segmentsCacheConfig(e), o.makeStoredHash(JSON.stringify(t)))
            }
        }, {
            key: "storedSegmentsMatchesSegments",
            value: function(e, t) {
                return o.storedDataMatchesCurrentData(this.getHashedSegments(e), o.makeStoredHash(JSON.stringify(t)))
            }
        }, {
            key: "clearHashedSegments",
            value: function(e) {
                this.clear(this.segmentsCacheConfig(e))
            }
        }, {
            key: "getDateTime",
            value: function() {
                return new Date(this.get(this.storageConfig.LAST)).getTime()
            }
        }, {
            key: "clearDateTime",
            value: function() {
                this.clear(this.storageConfig.LAST)
            }
        }, {
            key: "setDateTime",
            value: function(e) {
                this.put(this.storageConfig.LAST, e)
            }
        }, {
            key: "getNb",
            value: function(e) {
                e = this.get(this.nbCacheConfig(e));
                return e ? parseInt(e) : 0
            }
        }, {
            key: "clearNb",
            value: function(e) {
                this.clear(this.nbCacheConfig(e))
            }
        }, {
            key: "setNb",
            value: function(e, t) {
                this.put(this.nbCacheConfig(e), t)
            }
        }, {
            key: "incNb",
            value: function(e, t) {
                return t = Math.round(t + 1), this.setNb(e, t), t
            }
        }, {
            key: "pdCacheConfig",
            value: function(e) {
                return this.storageConfig.PD.withNameSuffixed(e)
            }
        }, {
            key: "nbCacheConfig",
            value: function(e) {
                return this.storageConfig.ID5.withNameSuffixed(e, "nb")
            }
        }, {
            key: "segmentsCacheConfig",
            value: function(e) {
                return this.storageConfig.SEGMENTS.withNameSuffixed(e)
            }
        }, {
            key: "storedConsentDataMatchesConsentData",
            value: function(e) {
                return o.storedDataMatchesCurrentData(this.getHashedConsentData(), e.hashCode())
            }
        }]) && a(e.prototype, t), n && a(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), o
    }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return f
    });
    var a = n(10);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function o(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function s(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? arguments[e] : {};
            e % 2 ? o(Object(n), !0).forEach(function(e) {
                u(t, e, n[e])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
            })
        }
        return t
    }

    function c(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, i(r.key), r)
        }
    }

    function u(e, t, n) {
        return (t = i(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function i(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    var l = function() {
        function i(e, t) {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, i), u(this, "_metrics", void 0), u(this, "_log", void 0), this._metrics = e, this._log = t
        }
        var e, t, n;
        return e = i, n = [{
            key: "getChunkUrl",
            value: function(e, t) {
                return "https://c".concat(e, ".eu-").concat(t, "-id5-sync.com")
            }
        }], (t = [{
            key: "submitExtensionCall",
            value: function(t, n) {
                var r = this,
                    o = Object(a.d)();
                return fetch(t).then(function(e) {
                    if (e.ok) return o.record(r._metrics.extensionsCallTimer(n, !0)), e.json();
                    o.record(r._metrics.extensionsCallTimer(n, !1));
                    e = "The call to get extensions at ".concat(t, " was not ok, status: ").concat(e.status, ", statusText: ").concat(e.statusText);
                    return r._log.warn(e), Promise.reject(new Error(e))
                }).catch(function(e) {
                    return o.record(r._metrics.extensionsCallTimer(n, !1)), r._log.warn("Got error from ".concat(t, " endpoint"), e), {}
                })
            }
        }, {
            key: "gatherChunks",
            value: function(e, n) {
                var r = this;
                if (e.some(function(e) {
                        return null != e.pd && "" !== e.pd.trim()
                    })) {
                    var o = Object(a.d)();
                    return Promise.all(Array.from({
                        length: n.length
                    }, function(e, t) {
                        t = i.getChunkUrl(t, n.urlVersion);
                        return fetch(t).then(function(e) {
                            if (e.ok) return e.text();
                            throw new Error("The call to get ".concat(n.name, " was not ok, status: ").concat(e.status, ", statusText: ").concat(e.statusText))
                        })
                    })).then(function(e) {
                        var t;
                        return o.record(r._metrics.extensionsCallTimer(n.name, !0)), u(t = {}, n.name, e), u(t, n.name + "Version", "".concat(n.version)), t
                    }).catch(function(e) {
                        return o.record(r._metrics.extensionsCallTimer(n.name, !1)), r._log.warn("Got error when getting ".concat(n.name), e), {}
                    })
                }
                return Promise.resolve({})
            }
        }, {
            key: "gather",
            value: function(e) {
                var n = this,
                    r = Object(a.d)();
                return Promise.allSettled([this.submitExtensionCall("https://lb.eu-1-id5-sync.com/lb/v1", "lb"), this.gatherChunks(e, i.CHUNKS_CONFIGS.devChunks), this.gatherChunks(e, i.CHUNKS_CONFIGS.groupChunks)]).then(function(e) {
                    r.record(n._metrics.extensionsCallTimer("all", !0));
                    var t = i.DEFAULT_RESPONSE;
                    return e.forEach(function(e) {
                        e.value && (t = s(s({}, t), e.value))
                    }), t
                }).catch(function(e) {
                    return r.record(n._metrics.extensionsCallTimer("all", !1)), n._log.error("Got error ".concat(e, " when gathering extensions data")), i.DEFAULT_RESPONSE
                })
            }
        }]) && c(e.prototype, t), n && c(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), i
    }();
    u(l, "CHUNKS_CONFIGS", Object.freeze({
        devChunks: {
            name: "devChunks",
            urlVersion: 3,
            length: 8,
            version: 4
        },
        groupChunks: {
            name: "groupChunks",
            urlVersion: 4,
            length: 8,
            version: 4
        }
    })), u(l, "DEFAULT_RESPONSE", {
        lbCDN: "%%LB_CDN%%"
    });
    var f = {
        createExtensions: function(e, t) {
            return new l(e, t)
        }
    }
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var r = n(18),
        t = n(33);
    n.n(t);
    window.ID5 || (window.ID5 = r.a)
}, function(e, t, n) {
    "use strict";
    var p = n(5),
        o = n(27),
        v = n(28),
        y = n(30),
        g = n(31),
        m = n(32),
        b = n(10),
        _ = n(2);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function w(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? arguments[e] : {};
            e % 2 ? i(Object(n), !0).forEach(function(e) {
                s(t, e, n[e])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
            })
        }
        return t
    }

    function a(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, c(r.key), r)
        }
    }

    function s(e, t, n) {
        return (t = c(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function c(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    var O = "api",
        n = new(function() {
            function e() {
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, e), s(this, "loaded", !1), s(this, "_isUsingCdn", !1), s(this, "_referer", !1), s(this, "_version", g.a), s(this, "versions", {}), s(this, "invocationId", 0), this.loaded = !0, this._isUsingCdn = !!(document && document.currentScript && document.currentScript.src && 0 === document.currentScript.src.indexOf("https://cdn.id5-sync.com")), this._referer = Object(o.a)(), this.versions[g.a] = !0
            }
            var t, n, r;
            return t = e, (n = [{
                key: "debug",
                get: function() {
                    return Object(p.k)()
                },
                set: function(e) {
                    Object(p.p)(e)
                }
            }, {
                key: "init",
                value: function(e) {
                    this.invocationId += 1;
                    var r = new p.a(O, this.invocationId);
                    try {
                        r.info("ID5 API version ".concat(this._version, ". Invoking init()"), e);
                        var t = new m.a(e, r),
                            n = t.getOptions(),
                            o = this._configureDiagnostics(n.partnerId, n.diagnostics, r);
                        o && (o.loadDelayTimer().recordNow(), o.invocationCountSummary().record(this.invocationId));
                        var i = new _.k(window, !t.hasCreativeRestrictions()),
                            a = new _.g(i),
                            s = n.allowLocalStorageWithoutConsentApi || n.debugBypassConsent,
                            c = new _.f(a, t.storageConfig, s, r),
                            u = new _.d(function() {
                                return c.localStorageGrant()
                            }, a, t.storageConfig, r),
                            l = _.l.createInstance(window, r, o, i),
                            f = new v.a(o, r),
                            d = new y.a(t, u, c, o, f, r, l),
                            h = Object(b.d)();
                        return l.on(_.b.CASCADE_NEEDED, this._doCascade(d)).on(_.b.USER_ID_READY, function(e, t) {
                            try {
                                var n = null != t && t.tags ? w({}, t.tags) : {};
                                null != t && t.timestamp && o.userIdNotificationDeliveryDelayTimer(n).record(Date.now() - t.timestamp), h.record(o.userIdProvisioningDelayTimer(e.isFromCache, w(w({}, n), {}, {
                                    isUpdate: d._userIdAvailable
                                })))
                            } catch (e) {
                                r.error("Failed to measure provisioning metrics", e)
                            }
                            d.setUserId(e.responseObj, e.isFromCache)
                        }).on(_.b.USER_ID_FETCH_CANCELED, function(e) {
                            return r.info("ID5 User ID fetch canceled:", e.reason)
                        }), this._gatherFetchIdData(d).then(function(e) {
                            var t;
                            return l.register({
                                source: O,
                                sourceVersion: g.a,
                                sourceConfiguration: {
                                    options: d.getOptions()
                                },
                                fetchIdData: e,
                                singletonMode: !0 === (null == n || null === (t = n.multiplexing) || void 0 === t ? void 0 : t._disabled),
                                canDoCascade: !n.applyCreativeRestrictions,
                                forceAllowLocalStorageGrant: s,
                                storageExpirationDays: n.storageExpirationDays
                            })
                        }), this._submitRefreshConsent(n, f, l, o, r).then(function(e) {
                            e && c.setConsentData(e)
                        }), r.info("ID5 initialized for partner ".concat(n.partnerId, " with referer ").concat(this._referer.referer, " and options"), e), d
                    } catch (e) {
                        r.error("Exception caught during init()", e)
                    }
                }
            }, {
                key: "_doCascade",
                value: function(o) {
                    return function(e) {
                        var t = o._logger,
                            n = o.config,
                            r = n.getOptions();
                        e.partnerId === r.partnerId && 0 <= r.maxCascades && !n.hasCreativeRestrictions() && (n = r.partnerUserId && 0 < r.partnerUserId.length, e = "".concat("https://id5-sync.com", "/").concat(n ? "s" : "i", "/").concat(r.partnerId, "/").concat(r.maxCascades, ".gif?id5id=").concat(e.userId, "&o=api&").concat(n ? "puid=" + r.partnerUserId + "&" : "", "gdpr_consent=").concat(e.consentString, "&gdpr=").concat(e.gdprApplies), t.info("Opportunities to cascade available", e), Object(p.d)(e))
                    }
                }
            }, {
                key: "_submitRefreshConsent",
                value: function(e, t, n, r, o) {
                    var i = Object(b.d)(),
                        a = e.debugBypassConsent ? "bypass" : e.cmpApi;
                    return t.refreshConsentData(e.debugBypassConsent, e.cmpApi, e.consentData).then(function(e) {
                        return i.record(r.consentRequestTimer(a, {
                            success: !0,
                            apiType: e.api
                        })), n.updateConsent(e), e
                    }).catch(function(e) {
                        o.error("Couldn't get consent data", e), i.record(r.consentRequestTimer(a, {
                            success: !1,
                            error: e.message
                        }))
                    })
                }
            }, {
                key: "refreshId",
                value: function(e) {
                    var t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
                        n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {};
                    if (!Object(p.i)(t)) throw new Error("Invalid signature for refreshId(): second parameter must be a boolean");
                    var r = e._logger;
                    try {
                        r.info("Invoking refreshId()", arguments), e.startRefresh(t), e.updateOptions(n);
                        var o = e.getOptions(),
                            i = e.instance,
                            a = o.allowLocalStorageWithoutConsentApi || o.debugBypassConsent;
                        this._gatherFetchIdData(e).then(function(e) {
                            i.updateFetchIdData(e), i.refreshUid({
                                resetConsent: !0,
                                forceAllowLocalStorageGrant: a,
                                forceFetch: t
                            })
                        }), this._submitRefreshConsent(o, e._consentDataProvider, i, e._metrics, e._logger)
                    } catch (e) {
                        r.error("Exception caught from refreshId()", e)
                    }
                    return e
                }
            }, {
                key: "_gatherFetchIdData",
                value: function(t) {
                    var n = this,
                        r = t.getOptions(),
                        e = t._logger;
                    return Object(p.f)(r.disableUaHints, e).then(function(e) {
                        return {
                            partnerId: r.partnerId,
                            refererInfo: n._referer,
                            origin: O,
                            originVersion: n._version,
                            isUsingCdn: n._isUsingCdn,
                            att: r.att,
                            uaHints: e,
                            abTesting: r.abTesting,
                            segments: r.segments,
                            invalidSegmentsCount: t.getInvalidSegments(),
                            provider: r.provider,
                            pd: r.pd,
                            partnerUserId: r.partnerUserId,
                            refreshInSeconds: r.refreshInSeconds,
                            providedRefreshInSeconds: t.getProvidedOptions().refreshInSeconds,
                            trace: Object(p.l)()
                        }
                    })
                }
            }, {
                key: "_configureDiagnostics",
                value: function(e, t, n) {
                    try {
                        var r, o = new b.a(O, g.a);
                        return o.addCommonTags(w(w({}, Object(b.c)(e)), {}, {
                            tml: this._referer.topmostLocation
                        })), null != t && t.publishingDisabled || (r = Object(b.b)(t.publishingSampleRatio), null != t && t.publishAfterLoadInMsec && 0 < t.publishAfterLoadInMsec && o.schedulePublishAfterMsec(t.publishAfterLoadInMsec, r), null != t && t.publishBeforeWindowUnload && o.schedulePublishBeforeUnload(r)), o
                    } catch (e) {
                        return void n.error("Failed to configure diagnostics", e)
                    }
                }
            }]) && a(t.prototype, n), r && a(t, r), Object.defineProperty(t, "prototype", {
                writable: !1
            }), e
        }());
    t.a = n
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return E
    });
    var a = n(7),
        c = n(0),
        u = n(21),
        l = n(1),
        f = n(22),
        d = n(8),
        h = n(23),
        p = n(4),
        v = n(6),
        y = n(11),
        g = n(24),
        m = n(15),
        b = n(16);

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, s(r.key), r)
        }
    }

    function i(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function _(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function w(e, t, n) {
        return (t = s(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function s(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    var O = Object.freeze({
            UNKNOWN: "unknown",
            LEADER: "leader",
            FOLLOWER: "follower"
        }),
        S = Object.freeze({
            MULTIPLEXING: "multiplexing",
            SINGLETON: "singleton"
        }),
        C = Object.freeze({
            AWAITING_SCHEDULE: "awaiting_schedule",
            SKIPPED: "skipped",
            SCHEDULED: "scheduled",
            COMPLETED: "completed",
            CANCELED: "canceled"
        }),
        j = function() {
            function r(e, t, n) {
                _(this, r), w(this, "properties", void 0), w(this, "knownState", void 0), w(this, "_joinTime", void 0), w(this, "_window", void 0), this.properties = e, this.knownState = t, this._window = n, this._joinTime = performance.now()
            }
            return i(r, [{
                key: "getId",
                value: function() {
                    return this.properties.id
                }
            }, {
                key: "isMultiplexingPartyAllowed",
                value: function() {
                    var e;
                    return (null === (e = this.knownState) || void 0 === e ? void 0 : e.operatingMode) === S.MULTIPLEXING
                }
            }, {
                key: "getInstanceMultiplexingLeader",
                value: function() {
                    var e, t;
                    if ((null === (e = this.knownState) || void 0 === e ? void 0 : e.operatingMode) === S.MULTIPLEXING) return null === (e = this.knownState) || void 0 === e || null === (t = e.multiplexing) || void 0 === t ? void 0 : t.leader
                }
            }, {
                key: "getWindow",
                value: function() {
                    return this._window
                }
            }]), r
        }(),
        I = function() {
            function t(e) {
                _(this, t), w(this, "_knownValues", []), w(this, "_counter", void 0), this._counter = e
            }
            return i(t, [{
                key: "add",
                value: function(e) {
                    e && -1 === this._knownValues.indexOf(e) && (this._counter.inc(), this._knownValues.push(e))
                }
            }]), t
        }(),
        k = function() {
            function r(e, t) {
                _(this, r), w(this, "_instancesCounter", void 0), w(this, "_domainsCounter", void 0), w(this, "_windowsCounter", void 0), w(this, "_partnersCounter", void 0);
                var n = t.id;
                this._instancesCounter = e.instanceCounter(t.id), this._windowsCounter = new I(e.instanceUniqWindowsCounter(n)), this._partnersCounter = new I(e.instanceUniqPartnersCounter(n)), this._domainsCounter = new I(e.instanceUniqueDomainsCounter(n))
            }
            return i(r, [{
                key: "addInstance",
                value: function(e) {
                    var t, n, r;
                    this._instancesCounter.inc(), this._partnersCounter.add((null == e || null === (t = e.fetchIdData) || void 0 === t ? void 0 : t.partnerId) | (null == e || null === (n = e.sourceConfiguration) || void 0 === n || null === (r = n.options) || void 0 === r ? void 0 : r.partnerId)), this._domainsCounter.add(null == e ? void 0 : e.domain), this._windowsCounter.add(null == e ? void 0 : e.href)
                }
            }]), r
        }();
    var P = function() {
            function t(e) {
                _(this, t), w(this, "_scheduleTime", void 0), w(this, "_closeTime", void 0), w(this, "_timeoutId", void 0), w(this, "_state", C.AWAITING_SCHEDULE), w(this, "_delayMs", void 0), w(this, "_instance", void 0), this._instance = e
            }
            return i(t, [{
                key: "schedule",
                value: function(e) {
                    var t = this;
                    t._delayMs = e, this._timeoutId = setTimeout(function() {
                        t._timeoutId && (t._timeoutId = void 0, t._instance._doElection(), t._closeWithState(C.COMPLETED))
                    }, t._delayMs), t._state = C.SCHEDULED, t._scheduleTime = performance.now()
                }
            }, {
                key: "skip",
                value: function() {
                    this._closeWithState(C.SKIPPED)
                }
            }, {
                key: "cancel",
                value: function() {
                    this._timeoutId && (clearTimeout(this._timeoutId), this._timeoutId = void 0), this._closeWithState(C.CANCELED)
                }
            }, {
                key: "_closeWithState",
                value: function(e) {
                    this._state = e, this._closeTime = performance.now()
                }
            }]), t
        }(),
        E = function() {
            function s(e, t, n, r) {
                var o, i = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : l.c;
                _(this, s), w(this, "properties", void 0), w(this, "_messenger", void 0), w(this, "_knownInstances", new Map), w(this, "_lastJoinedInstance", void 0), w(this, "role", void 0), w(this, "_leader", void 0), w(this, "_mode", void 0), w(this, "_metrics", void 0), w(this, "_logger", void 0), w(this, "_instanceCounters", void 0), w(this, "_election", void 0), w(this, "_window", void 0), w(this, "_storage", void 0);
                var a = c.generateId();
                this.properties = Object.assign({
                    id: a,
                    version: u.a,
                    href: null === (o = e.location) || void 0 === o ? void 0 : o.href,
                    domain: null === (o = e.location) || void 0 === o ? void 0 : o.hostname
                }, t), this.role = O.UNKNOWN, this._metrics = r, this._instanceCounters = new k(r, this.properties), this._loadTime = performance.now(), this._logger = void 0 !== i ? new l.b("Instance(id=".concat(a, ")"), i) : l.c, this._window = e, this._dispatcher = new d.b(this._logger), this._leader = new f.b, this._followerRole = new h.a(this._window, this.properties, this._dispatcher, this._logger), this._election = new P(this), this._storage = n
            }
            return i(s, [{
                key: "updateConfig",
                value: function(e) {
                    Object.assign(this.properties, e)
                }
            }, {
                key: "init",
                value: function() {
                    var n, r, e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 1e3,
                        o = this,
                        i = o._window;
                    o._mode = !0 === o.properties.singletonMode ? S.SINGLETON : S.MULTIPLEXING, o._instanceCounters.addInstance(o.properties), r = (n = o)._metrics, [100, 200, 500, 1e3, 2e3, 3e3, 5e3].forEach(function(t) {
                        setTimeout(function() {
                            var e = ((null === (e = n._knownInstances) || void 0 === e ? void 0 : e.size) || 0) + 1;
                            r.summary("instance.partySize", {
                                after: t,
                                electionState: n._election._state
                            }).record(e)
                        }, t)
                    }), o._messenger = new a.a(o.properties.id, i, o._logger), o._messenger.onAnyMessage(function(e, t) {
                        var n = Date.now() - e.timestamp | 0;
                        o._metrics.instanceMsgDeliveryTimer({
                            messageType: e.type,
                            sameWindow: i === t
                        }).record(n), o._logger.debug("Message received", e), o._doFireEvent(d.c.ID5_MESSAGE_RECEIVED, e)
                    }).onMessage(a.c.TYPE, function(e, t) {
                        var n = Object.assign(new a.c, e.payload);
                        void 0 === n.isResponse && (n.isResponse = e.dst !== a.b), o._handleHelloMessage(n, e, t)
                    }).onProxyMethodCall(new a.d(this._logger).registerTarget(a.e.LEADER, o._leader).registerTarget(a.e.FOLLOWER, o._followerRole).registerTarget(a.e.STORAGE, o._storage)), o._mode === S.SINGLETON ? (o._election.skip(), o._onLeaderElected(o.properties)) : o._mode === S.MULTIPLEXING && o._election.schedule(e), o._messenger.broadcastMessage(o._createHelloMessage(!1), a.c.TYPE), void 0 === i.__id5_instances && (i.__id5_instances = []), i.__id5_instances.push(o)
                }
            }, {
                key: "register",
                value: function(e) {
                    try {
                        this.updateConfig(e), this.init()
                    } catch (e) {
                        this._logger.error("Failed to register integration instance", e)
                    }
                    return this
                }
            }, {
                key: "_handleHelloMessage",
                value: function(e, t, n) {
                    this._joinInstance(e, t, n)
                }
            }, {
                key: "deregister",
                value: function() {
                    var e = this._window.__id5_instances;
                    void 0 !== e && e.splice(e.indexOf(this), 1), this._messenger && this._messenger.deregister()
                }
            }, {
                key: "on",
                value: function(e, t) {
                    return this._dispatcher.on(e, t), this
                }
            }, {
                key: "_joinInstance",
                value: function(e, t, n) {
                    var r = e.isResponse,
                        n = new j(e.instance, e.instanceState, n);
                    this._knownInstances.get(n.getId()) ? this._logger.debug("Instance already known", n.getId()) : (this._knownInstances.set(n.getId(), n), this._lastJoinedInstance = n, this._instanceCounters.addInstance(n.properties), this._metrics.instanceJoinDelayTimer({
                        election: this._election._state
                    }).record(performance.now() - this._loadTime | 0), r ? (r = n.getInstanceMultiplexingLeader(), this._mode === S.MULTIPLEXING && this.role === O.UNKNOWN && void 0 !== r && (this._logger.info("Joined late, elected leader is", r), this._election.cancel(), this._onLeaderElected(r))) : (this._messenger.sendResponseMessage(t, this._createHelloMessage(!0), a.c.TYPE), this._mode === S.MULTIPLEXING && this.role !== O.UNKNOWN && this._handleLateJoiner(n)), this._logger.debug("Instance joined", n.getId()), this._doFireEvent(d.c.ID5_INSTANCE_JOINED, n.properties))
                }
            }, {
                key: "_createHelloMessage",
                value: function() {
                    var e, t = 0 < arguments.length && void 0 !== arguments[0] && arguments[0],
                        n = {
                            operatingMode: this._mode,
                            knownInstances: Array.from(this._knownInstances.values()).map(function(e) {
                                return e.properties
                            })
                        };
                    return this._mode === S.MULTIPLEXING && (n.multiplexing = {
                        role: this.role,
                        electionState: null === (e = this._election) || void 0 === e ? void 0 : e._state,
                        leader: this._leader.getProperties()
                    }), new a.c(this.properties, t, n)
                }
            }, {
                key: "_handleLateJoiner",
                value: function(e) {
                    this._logger.info("Late joiner detected", e.properties);
                    var t = this._metrics.instanceLateJoinCounter(this.properties.id, {
                        scope: "party"
                    }).inc();
                    this._metrics.instanceLateJoinDelayTimer({
                        election: this._election._state,
                        isFirst: 1 === t
                    }).record(performance.now() - this._election._closeTime), !e.isMultiplexingPartyAllowed() || this.role !== O.LEADER || !0 === (null == (e = this._leader.addFollower(new h.b(e, this._messenger, this._logger))) ? void 0 : e.lateJoiner) && this._metrics.instanceLateJoinCounter(this.properties.id, {
                        scope: "leader",
                        unique: !0 === (null == e ? void 0 : e.uniqueLateJoiner)
                    }).inc()
                }
            }, {
                key: "_doFireEvent",
                value: function(e) {
                    for (var t, n = arguments.length, r = new Array(1 < n ? n - 1 : 0), o = 1; o < n; o++) r[o - 1] = arguments[o];
                    (t = this._dispatcher).emit.apply(t, [e].concat(r))
                }
            }, {
                key: "_actAsLeader",
                value: function() {
                    var t = this,
                        e = this.properties,
                        n = this._logger,
                        r = this._metrics,
                        o = new p.c(this._storage),
                        i = new p.a(o),
                        a = new v.a(e.storageExpirationDays),
                        s = new y.a(i, a, e.forceAllowLocalStorageGrant, n),
                        a = new g.a(s, new v.b(new m.a(function() {
                            return s.localStorageGrant()
                        }, i, a, n)), r, n, b.a.createExtensions(r, n)),
                        c = new f.a(this._window, a, e, o, s, r, n);
                    c.addFollower(this._followerRole), this._leader.assignLeader(c), this._mode === S.MULTIPLEXING && Array.from(this._knownInstances.values()).filter(function(e) {
                        return e.isMultiplexingPartyAllowed()
                    }).map(function(e) {
                        return c.addFollower(new h.b(e, t._messenger, n))
                    }), c.start()
                }
            }, {
                key: "_followRemoteLeader",
                value: function(e) {
                    this._leader.assignLeader(new f.c(this._messenger, e)), this._logger.info("Following remote leader ", e)
                }
            }, {
                key: "updateConsent",
                value: function(e) {
                    this._leader.updateConsent(e)
                }
            }, {
                key: "updateFetchIdData",
                value: function(e) {
                    Object.assign(this.properties.fetchIdData, e), this._leader.updateFetchIdData(this.properties.id, this.properties.fetchIdData)
                }
            }, {
                key: "refreshUid",
                value: function(e) {
                    this._leader.refreshUid(e)
                }
            }, {
                key: "_doElection",
                value: function() {
                    var e = this._election,
                        t = this._knownInstances,
                        t = Array.from(t.values()).filter(function(e) {
                            return e.isMultiplexingPartyAllowed()
                        }).map(function(e) {
                            return e.properties
                        });
                    t.push(this.properties), this._onLeaderElected((t = t) && 0 !== t.length ? t.sort(function(e, t) {
                        var n = -c.semanticVersionCompare(e.version, t.version);
                        return n = 0 === n && 0 === (n = 0 === (n = e.source.localeCompare(t.source)) ? -c.semanticVersionCompare(e.sourceVersion, t.sourceVersion) : n) ? e.id.localeCompare(t.id) : n
                    })[0] : void 0);
                    t = this._lastJoinedInstance;
                    t && this._metrics.instanceLastJoinDelayTimer().record(Math.max(t._joinTime - e._scheduleTime, 0))
                }
            }, {
                key: "_onLeaderElected",
                value: function(e) {
                    var t = this;
                    t.role = e.id === t.properties.id ? O.LEADER : O.FOLLOWER, t.role === O.LEADER ? t._actAsLeader() : t.role === O.FOLLOWER && t._followRemoteLeader(e), t._logger.debug("Leader elected", e.id, "my role", t.role), t._doFireEvent(d.c.ID5_LEADER_ELECTED, t.role, t._leader.getProperties())
                }
            }]), s
        }()
}, function(e, t) {
    var n = function() {
        return this
    }();
    try {
        n = n || Function("return this")() || (0, eval)("this")
    } catch (e) {
        "object" == typeof window && (n = window)
    }
    e.exports = n
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return r
    });
    var r = "1.0.16"
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return j
    }), n.d(t, "c", function() {
        return I
    }), n.d(t, "b", function() {
        return k
    });
    var l = n(1),
        i = n(7),
        r = n(3);

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function a(e) {
        return function(e) {
            if (Array.isArray(e)) return u(e)
        }(e) || function(e) {
            if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
        }(e) || c(e) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function s(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function f(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? arguments[e] : {};
            e % 2 ? s(Object(n), !0).forEach(function(e) {
                w(t, e, n[e])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
            })
        }
        return t
    }

    function d(e, t) {
        var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
        if (!n) {
            if (Array.isArray(e) || (n = c(e)) || t && e && "number" == typeof e.length) {
                n && (e = n);
                var r = 0,
                    t = function() {};
                return {
                    s: t,
                    n: function() {
                        return r >= e.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: e[r++]
                        }
                    },
                    e: function(e) {
                        throw e
                    },
                    f: t
                }
            }
            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }
        var o, i = !0,
            a = !1;
        return {
            s: function() {
                n = n.call(e)
            },
            n: function() {
                var e = n.next();
                return i = e.done, e
            },
            e: function(e) {
                a = !0, o = e
            },
            f: function() {
                try {
                    i || null == n.return || n.return()
                } finally {
                    if (a) throw o
                }
            }
        }
    }

    function c(e, t) {
        if (e) {
            if ("string" == typeof e) return u(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? u(e, t) : void 0
        }
    }

    function u(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function h(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                writable: !0,
                configurable: !0
            }
        }), Object.defineProperty(e, "prototype", {
            writable: !1
        }), t && p(e, t)
    }

    function p(e, t) {
        return (p = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function v(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = g(n);
            return function(e, t) {
                {
                    if (t && ("object" === o(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return y(e)
            }(this, r ? (e = g(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function y(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }

    function g(e) {
        return (g = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function m(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, O(r.key), r)
        }
    }

    function b(e, t, n) {
        return t && m(e.prototype, t), n && m(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function _(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function w(e, t, n) {
        return (t = O(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function O(e) {
        e = function(e, t) {
            if ("object" !== o(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== o(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === o(e) ? e : String(e)
    }

    function S() {
        var e = 0 < arguments.length && void 0 !== arguments[0] && arguments[0],
            t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
        _(this, S), w(this, "lateJoiner", !1), w(this, "uniqueLateJoiner", !1), this.lateJoiner = e, this.uniqueLateJoiner = t
    }
    var C = function() {
            function e() {
                _(this, e)
            }
            return b(e, [{
                key: "updateConsent",
                value: function(e) {}
            }, {
                key: "updateFetchIdData",
                value: function(e, t) {}
            }, {
                key: "refreshUid",
                value: function(e) {}
            }, {
                key: "addFollower",
                value: function(e) {}
            }, {
                key: "getProperties",
                value: function() {}
            }]), e
        }(),
        j = function() {
            h(u, C);
            var c = v(u);

            function u(e, t, n, r, o, i) {
                var a, s = 6 < arguments.length && void 0 !== arguments[6] ? arguments[6] : l.c;
                return _(this, u), w(y(a = c.call(this)), "_followers", void 0), w(y(a), "_followersRequests", {}), w(y(a), "_fetcher", void 0), w(y(a), "_log", void 0), w(y(a), "_consentManager", void 0), w(y(a), "_cachedResponse", void 0), w(y(a), "_inProgressFetch", void 0), w(y(a), "_queuedRefreshOptions", void 0), w(y(a), "_lastConsentDataSet", void 0), w(y(a), "_metrics", void 0), w(y(a), "_leaderStorage", void 0), a._followers = [], a._fetcher = t, a._properties = n, a._consentManager = o, a._metrics = i, a._window = e, a._leaderStorage = r, a._log = s, a
            }
            return b(u, [{
                key: "_handleRefreshResult",
                value: function(e) {
                    var t = e.refreshedResponse;
                    if (void 0 !== t) {
                        var n, r = [],
                            o = d(this._followers);
                        try {
                            for (o.s(); !(n = o.n()).done;) {
                                var i = n.value,
                                    a = t.getResponseFor(i.getId());
                                void 0 !== a && (this._log.debug("Notify uid ready.", "Follower:", i.getId(), "Uid:", a), this._notifyUidReady(i, {
                                    timestamp: t.timestamp,
                                    responseObj: a,
                                    isFromCache: !1
                                }), !0 === a.cascade_needed && r.push(i.getId()))
                            }
                        } catch (e) {
                            o.e(e)
                        } finally {
                            o.f()
                        }
                        e = e.consentData;
                        void 0 !== e && 0 < r.length && this._consentManager.localStorageGrant().isDefinitivelyAllowed() && this._handleCascade(r, t, e), this._cachedResponse = {
                            timestamp: t.timestamp,
                            responseObj: t.getGenericResponse(),
                            isFromCache: !1
                        }
                    }
                }
            }, {
                key: "_handleCachedResponse",
                value: function(e) {
                    var t, n = {
                            timestamp: e.timestamp,
                            responseObj: e.response,
                            isFromCache: !0
                        },
                        r = d(this._followers);
                    try {
                        for (r.s(); !(t = r.n()).done;) {
                            var o = t.value;
                            this._log.debug("Notify uid ready.", "Follower:", o.getId(), "Uid:", n), this._notifyUidReady(o, n)
                        }
                    } catch (e) {
                        r.e(e)
                    } finally {
                        r.f()
                    }
                    this._cachedResponse = n
                }
            }, {
                key: "_notifyUidReady",
                value: function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
                        n = {
                            timestamp: Date.now(),
                            tags: {
                                lateJoiner: n,
                                callType: e.callType
                            }
                        };
                    e.notifyUidReady(t, n)
                }
            }, {
                key: "_handleCascade",
                value: function(e, t, n) {
                    var r = this._followers.filter(function(t) {
                        return void 0 !== e.find(function(e) {
                            return t.getId() === e
                        }) && t.canDoCascade()
                    }).sort(function(e, t) {
                        function n(e) {
                            var t;
                            return (null === (e = e.getFetchIdData().refererInfo) || void 0 === e || null === (t = e.stack) || void 0 === t ? void 0 : t.length) || Number.MAX_SAFE_INTEGER
                        }
                        return n(e) - n(t)
                    });
                    0 < r.length ? (r = r[0]).notifyCascadeNeeded({
                        partnerId: r.getFetchIdData().partnerId,
                        userId: t.getResponseFor(r.getId()).universal_uid,
                        gdprApplies: n.gdprApplies,
                        consentString: n.consentString
                    }) : this._log.error("Couldn't find cascade eligible follower")
                }
            }, {
                key: "_handleCancel",
                value: function(e) {
                    var t, n = d(this._followers);
                    try {
                        for (n.s(); !(t = n.n()).done;) t.value.notifyFetchUidCanceled({
                            reason: e
                        })
                    } catch (e) {
                        n.e(e)
                    } finally {
                        n.f()
                    }
                }
            }, {
                key: "_getId",
                value: function() {
                    var o = this,
                        e = 0 < arguments.length && void 0 !== arguments[0] && arguments[0],
                        t = this._followers.map(function(e) {
                            var t = e.getId(),
                                n = o._followersRequests[t] = (o._followersRequests[t] || 0) + 1,
                                r = o._properties.id;
                            return f(f({}, e.getFetchIdData()), {}, {
                                integrationId: t,
                                requestCount: n,
                                role: r === e.getId() ? "leader" : "follower"
                            })
                        });
                    this._inProgressFetch = !0;
                    e = this._fetcher.getId(t, e);
                    e.cachedResponse && this._handleCachedResponse(e.cachedResponse), e.refreshResult.then(function(e) {
                        e.refreshedResponse && o._handleRefreshResult(e), o._handleFetchCompleted()
                    }).catch(function(e) {
                        e instanceof r.f ? o._handleCancel(e.message) : o._handleFailed(e), o._handleFetchCompleted()
                    })
                }
            }, {
                key: "start",
                value: function() {
                    !0 !== this._started && (this._getId(!1), this._started = !0)
                }
            }, {
                key: "refreshUid",
                value: function() {
                    var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                    this._inProgressFetch ? this._queuedRefreshOptions = e : (!0 === e.resetConsent && this._consentManager.resetConsentData(!0 === e.forceAllowLocalStorageGrant), this._getId(!0 === e.forceFetch))
                }
            }, {
                key: "updateConsent",
                value: function(e) {
                    var t, n, r = this._lastConsentDataSet;
                    r && (t = (null == e ? void 0 : e.api) !== r.api, n = (null == e ? void 0 : e.consentString) !== r.consentString, r = (null == e ? void 0 : e.ccpaString) !== r.ccpaString, (t || n || r) && this._metrics.consentChangeCounter({
                        apiChanged: t,
                        consentStringChanged: n,
                        usPrivacyChanged: r
                    }).inc()), this._consentManager.setConsentData(e), this._lastConsentDataSet = e
                }
            }, {
                key: "updateFetchIdData",
                value: function(t, e) {
                    this._followers.find(function(e) {
                        return e.getId() === t
                    }).updateFetchIdData(e)
                }
            }, {
                key: "addFollower",
                value: function(t) {
                    var n = t.getId(),
                        e = this._cachedResponse,
                        r = this._log;
                    this._followers.push(t), this._window !== t.getWindow() && (o = t.getStorage(), r.info("Adding follower's", t.getId(), "storage as replica"), this._leaderStorage.addReplica(o)), r.debug("Added follower", n, "last uid", e);
                    var o = new S;
                    return (e || this._inProgressFetch) && (o.lateJoiner = !0, e && this._notifyUidReady(t, f(f({}, e), {}, {
                        isFromCache: !0
                    }), !0), this._followers.filter(function(e) {
                        return e.getId() !== n
                    }).some(function(e) {
                        return t.isSimilarTo(e)
                    }) || (r.debug("Will refresh uid for new joiner", n), this.refreshUid({
                        forceFetch: !0
                    }), o.uniqueLateJoiner = !0)), o
                }
            }, {
                key: "getProperties",
                value: function() {
                    return this._properties
                }
            }, {
                key: "_handleFetchCompleted",
                value: function() {
                    this._inProgressFetch = void 0, this._queuedRefreshOptions && (this.refreshUid(this._queuedRefreshOptions), this._queuedRefreshOptions = void 0)
                }
            }, {
                key: "_handleFailed",
                value: function(e) {
                    this._log.error("Fetch id failed", e);
                    var t, n = d(this._followers);
                    try {
                        for (n.s(); !(t = n.n()).done;) t.value.notifyFetchUidCanceled({
                            reason: "error"
                        })
                    } catch (e) {
                        n.e(e)
                    } finally {
                        n.f()
                    }
                }
            }]), u
        }(),
        I = function() {
            h(o, C);
            var r = v(o);

            function o(e, t) {
                var n;
                return _(this, o), w(y(n = r.call(this)), "_messenger", void 0), w(y(n), "_leaderInstanceProperties", void 0), n._messenger = e, n._leaderInstanceProperties = t, n
            }
            return b(o, [{
                key: "_sendToLeader",
                value: function(e, t) {
                    this._messenger.callProxyMethod(this._leaderInstanceProperties.id, i.e.LEADER, e, t)
                }
            }, {
                key: "updateConsent",
                value: function(e) {
                    this._sendToLeader("updateConsent", [e])
                }
            }, {
                key: "refreshUid",
                value: function(e) {
                    this._sendToLeader("refreshUid", [e])
                }
            }, {
                key: "updateFetchIdData",
                value: function(e, t) {
                    this._sendToLeader("updateFetchIdData", [e, t])
                }
            }, {
                key: "getProperties",
                value: function() {
                    return this._leaderInstanceProperties
                }
            }]), o
        }(),
        k = function() {
            h(i, C);
            var o = v(i);

            function i() {
                var e;
                _(this, i);
                for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                return w(y(e = o.call.apply(o, [this].concat(n))), "_callsQueue", []), w(y(e), "_assignedLeader", void 0), e
            }
            return b(i, [{
                key: "updateConsent",
                value: function(e) {
                    this._callOrBuffer("updateConsent", [e])
                }
            }, {
                key: "updateFetchIdData",
                value: function(e, t) {
                    this._callOrBuffer("updateFetchIdData", [e, t])
                }
            }, {
                key: "refreshUid",
                value: function(e) {
                    this._callOrBuffer("refreshUid", [e])
                }
            }, {
                key: "addFollower",
                value: function(e) {
                    return this._callOrBuffer("addFollower", [e])
                }
            }, {
                key: "getProperties",
                value: function() {
                    if (this._assignedLeader) return this._assignedLeader.getProperties()
                }
            }, {
                key: "assignLeader",
                value: function(e) {
                    this._assignedLeader = e;
                    var t, n = d(this._callsQueue);
                    try {
                        for (n.s(); !(t = n.n()).done;) {
                            var r = t.value;
                            this._callAssignedLeader(r.name, r.args)
                        }
                    } catch (e) {
                        n.e(e)
                    } finally {
                        n.f()
                    }
                    this._callsQueue = []
                }
            }, {
                key: "_callOrBuffer",
                value: function(e, t) {
                    if (this._assignedLeader) return this._callAssignedLeader(e, t);
                    this._callsQueue.push({
                        name: e,
                        args: t
                    })
                }
            }, {
                key: "_callAssignedLeader",
                value: function(e, t) {
                    var n;
                    return (n = this._assignedLeader)[e].apply(n, a(t))
                }
            }]), i
        }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return _
    }), n.d(t, "b", function() {
        return O
    });
    var r = n(8),
        i = n(7),
        a = n(1),
        s = n(4);

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function c(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                writable: !0,
                configurable: !0
            }
        }), Object.defineProperty(e, "prototype", {
            writable: !1
        }), t && u(e, t)
    }

    function u(e, t) {
        return (u = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function l(n) {
        var r = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (e) {
                return !1
            }
        }();
        return function() {
            var e, t = d(n);
            return function(e, t) {
                {
                    if (t && ("object" === o(t) || "function" == typeof t)) return t;
                    if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined")
                }
                return f(e)
            }(this, r ? (e = d(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments))
        }
    }

    function f(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }

    function d(e) {
        return (d = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function h(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function p(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, g(r.key), r)
        }
    }

    function v(e, t, n) {
        return t && p(e.prototype, t), n && p(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function y(e, t, n) {
        return (t = g(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function g(e) {
        e = function(e, t) {
            if ("object" !== o(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== o(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === o(e) ? e : String(e)
    }
    var m = Object.freeze({
            DIRECT_METHOD: "direct_method",
            POST_MESSAGE: "post_message"
        }),
        b = function() {
            function o(e, t, n) {
                var r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : a.c;
                h(this, o), y(this, "_instanceProperties", void 0), y(this, "_log", void 0), y(this, "callType", void 0), y(this, "_instanceWindow", void 0), this._instanceWindow = t, this._instanceProperties = n, this._log = r, this.callType = e
            }
            return v(o, [{
                key: "getId",
                value: function() {
                    return this._instanceProperties.id
                }
            }, {
                key: "getFetchIdData",
                value: function() {
                    return this._instanceProperties.fetchIdData
                }
            }, {
                key: "updateFetchIdData",
                value: function(e) {
                    Object.assign(this._instanceProperties.fetchIdData, e)
                }
            }, {
                key: "isSimilarTo",
                value: function(e) {
                    var t = e._instanceProperties.fetchIdData,
                        n = this._instanceProperties.fetchIdData,
                        r = t.partnerId === n.partnerId,
                        o = t.att === n.att,
                        i = t.pd === n.pd,
                        a = t.provider === n.provider,
                        s = JSON.stringify(t.abTesting) === JSON.stringify(n.abTesting),
                        c = JSON.stringify(t.segments) === JSON.stringify(n.segments),
                        n = t.providedRefreshInSeconds === n.providedRefreshInSeconds,
                        s = r && o && i && a && s && c && n;
                    return this._log.debug("Comparing followers this:", this.getId(), "other:", e.getId(), "areSimilar:", s, "reason:", {
                        samePartner: r,
                        sameAtt: o,
                        samePd: i,
                        sameProvider: a,
                        sameSegments: c,
                        sameProvidedRefresh: n
                    }), s
                }
            }, {
                key: "notifyUidReady",
                value: function(e, t) {}
            }, {
                key: "notifyFetchUidCanceled",
                value: function(e) {}
            }, {
                key: "notifyCascadeNeeded",
                value: function(e) {}
            }, {
                key: "canDoCascade",
                value: function() {
                    return !0 === this._instanceProperties.canDoCascade
                }
            }, {
                key: "getStorage",
                value: function() {
                    return s.b
                }
            }, {
                key: "getWindow",
                value: function() {
                    return this._instanceWindow
                }
            }]), o
        }(),
        _ = function() {
            c(i, b);
            var o = l(i);

            function i(e, t, n) {
                var r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : a.c;
                return h(this, i), y(f(r = o.call(this, m.DIRECT_METHOD, e, t, r)), "_dispatcher", void 0), r._dispatcher = n, r
            }
            return v(i, [{
                key: "notifyUidReady",
                value: function(e, t) {
                    this._dispatcher.emit(r.a.USER_ID_READY, e, t)
                }
            }, {
                key: "notifyFetchUidCanceled",
                value: function(e) {
                    this._dispatcher.emit(r.a.USER_ID_FETCH_CANCELED, e)
                }
            }, {
                key: "notifyCascadeNeeded",
                value: function(e) {
                    this._dispatcher.emit(r.a.CASCADE_NEEDED, e)
                }
            }]), i
        }(),
        w = function() {
            c(o, s["d"]);
            var r = l(o);

            function o(e, t) {
                var n;
                return h(this, o), y(f(n = r.call(this)), "_messenger", void 0), y(f(n), "_destinationId", void 0), n._messanger = e, n._destinationId = t, n
            }
            return v(o, [{
                key: "getItem",
                value: function(e) {}
            }, {
                key: "removeItem",
                value: function(e) {
                    this._remoteCall("removeItem", [e])
                }
            }, {
                key: "setItem",
                value: function(e, t) {
                    this._remoteCall("setItem", [e, t])
                }
            }, {
                key: "_remoteCall",
                value: function(e, t) {
                    this._messanger.callProxyMethod(this._destinationId, i.e.STORAGE, e, t)
                }
            }]), o
        }(),
        O = function() {
            c(o, b);
            var r = l(o);

            function o(e, t) {
                var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : a.c;
                return h(this, o), y(f(n = r.call(this, m.POST_MESSAGE, e.getWindow(), e.properties, n)), "_messenger", void 0), n._messenger = t, n
            }
            return v(o, [{
                key: "_callProxy",
                value: function(e, t) {
                    this._messenger.callProxyMethod(this.getId(), i.e.FOLLOWER, e, t)
                }
            }, {
                key: "notifyUidReady",
                value: function(e, t) {
                    this._callProxy("notifyUidReady", [e, t])
                }
            }, {
                key: "notifyFetchUidCanceled",
                value: function(e) {
                    this._callProxy("notifyFetchUidCanceled", [e])
                }
            }, {
                key: "notifyCascadeNeeded",
                value: function(e) {
                    this._callProxy("notifyCascadeNeeded", [e])
                }
            }, {
                key: "getStorage",
                value: function() {
                    return new w(this._messenger, this.getId())
                }
            }]), o
        }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return g
    });
    var d = n(0),
        m = n(3),
        h = n(10),
        b = (n(6), n(4));

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function l(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null != n) {
                var r, o, i, a, s = [],
                    c = !0,
                    u = !1;
                try {
                    if (i = (n = n.call(e)).next, 0 === t) {
                        if (Object(n) !== n) return;
                        c = !1
                    } else
                        for (; !(c = (r = i.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
                } catch (e) {
                    u = !0, o = e
                } finally {
                    try {
                        if (!c && null != n.return && (a = n.return(), Object(a) !== a)) return
                    } finally {
                        if (u) throw o
                    }
                }
                return s
            }
        }(e, t) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return o(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? o(e, t) : void 0
            }
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function o(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function i(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function a(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? arguments[e] : {};
            e % 2 ? i(Object(n), !0).forEach(function(e) {
                f(t, e, n[e])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
            })
        }
        return t
    }

    function s(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, p(r.key), r)
        }
    }

    function c(e, t, n) {
        return t && s(e.prototype, t), n && s(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function u(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function f(e, t, n) {
        return (t = p(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function p(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }

    function _(e) {
        var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : Date.now();
        u(this, _), f(this, "timestamp", void 0), f(this, "response", void 0), this.response = e, this.timestamp = t
    }

    function w(e) {
        var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
        u(this, w), f(this, "consentData", void 0), f(this, "refreshedResponse", void 0), this.consentData = e, this.refreshedResponse = t
    }

    function O() {
        u(this, O), f(this, "cachedResponse", void 0), f(this, "refreshResult", void 0)
    }
    var v = function() {
            function n(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : Date.now();
                u(this, n), f(this, "timestamp", void 0), f(this, "response", void 0), this.response = e, this.timestamp = t
            }
            return c(n, [{
                key: "getGenericResponse",
                value: function() {
                    return this.response.generic
                }
            }, {
                key: "getResponseFor",
                value: function(e) {
                    if (this.response.responses[e]) return a(a({}, this.response.generic), this.response.responses[e])
                }
            }]), n
        }(),
        y = function() {
            function r(e, t, n) {
                u(this, r), f(this, "_extensionsProvider", void 0), f(this, "_metrics", void 0), f(this, "_log", void 0), this._extensionsProvider = e, this._metrics = t, this._log = n
            }
            return c(r, [{
                key: "refreshUid",
                value: function(e, n, r, c, u, l) {
                    var f = this;
                    return this._extensionsProvider.gather(e).then(function(t) {
                        var o = e.map(function(e) {
                                return f._createRequest(n, e, c, r, u, t, l)
                            }),
                            i = f._log,
                            a = f._metrics,
                            s = f;
                        return new Promise(function(t, n) {
                            var r = Object(h.d)(),
                                e = "".concat("https://id5-sync.com").concat("/gm/v3");
                            i.info("Fetching ID5 ID from:", e, o), Object(d.ajax)(e, {
                                success: function(e) {
                                    r.record(null == a ? void 0 : a.fetchSuccessfulCallTimer());
                                    try {
                                        t(s._validateResponse(e))
                                    } catch (e) {
                                        n(e)
                                    }
                                },
                                error: function(e) {
                                    r.record(null == a ? void 0 : a.fetchFailureCallTimer()), n(e)
                                }
                            }, JSON.stringify({
                                requests: o
                            }), {
                                method: "POST",
                                withCredentials: !0
                            }, i)
                        })
                    })
                }
            }, {
                key: "_validateResponse",
                value: function(e) {
                    if (!e || !Object(d.isStr)(e) || e.length < 1) throw new Error('Empty fetch response from ID5 servers: "'.concat(e, '"'));
                    var t = JSON.parse(e);
                    if (!Object(d.isPlainObject)(t.generic)) throw new Error("Server response failed to validate: ".concat(e));
                    return this._log.info("Valid json response from ID5 received", t), t
                }
            }, {
                key: "_createRequest",
                value: function(e, n, t, r, o, i, a) {
                    var s;
                    this._log.info("Create request data for", {
                        fetchIdData: n,
                        consentData: e,
                        signature: t,
                        nbs: r,
                        refreshInSecondUsed: o,
                        extensions: i
                    });
                    var c = n.partnerId,
                        u = {
                            requestId: n.integrationId,
                            requestCount: n.requestCount,
                            role: n.role,
                            partner: c,
                            v: n.originVersion,
                            o: n.origin,
                            tml: null === (s = n.refererInfo) || void 0 === s ? void 0 : s.topmostLocation,
                            ref: null === (s = n.refererInfo) || void 0 === s ? void 0 : s.ref,
                            cu: null === (s = n.refererInfo) || void 0 === s ? void 0 : s.canonicalUrl,
                            u: (null === (s = n.refererInfo) || void 0 === s ? void 0 : s.stack[0]) || window.location.href,
                            top: null !== (s = n.refererInfo) && void 0 !== s && s.reachedTop ? 1 : 0,
                            localStorage: !0 === a ? 1 : 0,
                            nbPage: r[c],
                            id5cdn: n.isUsingCdn,
                            ua: window.navigator.userAgent,
                            att: n.att
                        },
                        c = e.gdprApplies;
                    Object(d.isDefined)(c) && (u.gdpr = c ? 1 : 0);
                    c = e.consentString;
                    Object(d.isDefined)(c) && (u.gdpr_consent = c), Object(d.isDefined)(e.allowedVendors) && (u.allowed_vendors = e.allowedVendors), Object(d.isDefined)(t) && (u.s = t);
                    t = n.uaHints;
                    Object(d.isDefined)(t) && (u.ua_hints = t), e.hasCcpaString && (u.us_privacy = e.ccpaString), Object(d.objectEntries)({
                        pd: "pd",
                        partnerUserId: "puid",
                        provider: "provider",
                        segments: "segments"
                    }).forEach(function(e) {
                        var t = l(e, 2),
                            e = t[0],
                            t = t[1];
                        Object(d.isDefined)(n[e]) && (u[t] = n[e])
                    });
                    e = n.abTesting;
                    e && !0 === e.enabled && (u.ab_testing = {
                        enabled: !0,
                        control_group_pct: e.controlGroupPct
                    });
                    e = n.invalidSegmentsCount;
                    return e && 0 < e && (u._invalid_segments = e), n.trace && (u._trace = !0), u.provided_options = {
                        refresh_in_seconds: n.providedRefreshInSeconds
                    }, u.used_refresh_in_seconds = o, u.extensions = i, u
                }
            }]), r
        }(),
        g = function() {
            function i(e, t, n, r, o) {
                o = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : new y(o, n, r);
                u(this, i), f(this, "_store", void 0), f(this, "_consentManager", void 0), f(this, "_uidRefresher", void 0), f(this, "_metrics", void 0), f(this, "_log", void 0), this._store = t, this._consentManager = e, this._metrics = n, this._log = r, this._uidRefresher = o
            }
            return c(i, [{
                key: "getId",
                value: function(u) {
                    var l = this,
                        f = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
                        e = new O,
                        d = this._log;
                    d.info("Get id", u);
                    var h, p = this._store,
                        v = this._consentManager,
                        t = this._metrics,
                        n = v.localStorageGrant(),
                        y = !1;
                    n.isDefinitivelyAllowed() && (d.info("Using local storage for cached ID", n), h = p.getStoredDataState(u)), !h || !h.hasValidUid() || h.pdHasChanged || h.segmentsHaveChanged || h.isStoredIdStale() ? d.info("No ID5 User ID available from cache", h) : (d.info("ID5 User ID available from cache:", h), e.cachedResponse = new _(h.storedResponse, h.storedDateTime), p.incNbs(u, h), y = !0), d.info("Waiting for consent");
                    var g = t.timer("fetch.consent.wait.time", {
                        cachedResponseUsed: y
                    });
                    return e.refreshResult = v.getConsentData().then(function(t) {
                        d.info("Consent received", t), g && g.recordNow();
                        var e = v.localStorageGrant();
                        if (d.info("Local storage grant", e), !e.allowed) throw d.info("No legal basis to use ID5", t), new m.f(t, "No legal basis to use ID5");
                        var n = b.e.checkIfAccessible(),
                            r = (h = p.getStoredDataState(u, t)).consentHasChanged;
                        e.isDefinitivelyAllowed() && p.storeRequestData(t, u);
                        var o = !h.isResponseComplete(),
                            i = h.refreshInSecondsHasElapsed(),
                            a = h.pdHasChanged,
                            e = h.segmentsHaveChanged;
                        if (o || i || r || a || e || f || !y) {
                            d.info("Decided to fetch a fresh ID5 ID", {
                                missingStoredData: o,
                                refreshInSecondsHasElapsed: i,
                                consentHasChanged: r,
                                pdHasChanged: a,
                                segmentsHaveChanged: e,
                                forceFetch: f,
                                cachedResponseUsed: y
                            });
                            var a = null === h || void 0 === h ? void 0 : h.nb,
                                e = null === h || void 0 === h || null === (s = h.storedResponse) || void 0 === s ? void 0 : s.signature,
                                s = null === h || void 0 === h ? void 0 : h.refreshInSeconds,
                                c = l;
                            return d.info("Fetching ID5 ID (forceFetch:".concat(f, ")")), l._uidRefresher.refreshUid(u, t, a, e, s, n).then(function(e) {
                                return c.handleSuccessfulFetchResponse(e, u, y, t)
                            })
                        }
                        return new w(t)
                    }), e
                }
            }, {
                key: "handleSuccessfulFetchResponse",
                value: function(e, t, n, r) {
                    var o = this._log,
                        i = this._consentManager,
                        a = this._store;
                    i.setStoredPrivacy(e.generic.privacy);
                    i = i.localStorageGrant();
                    return i.isDefinitivelyAllowed() ? (o.info("Storing ID and request hashes in cache"), a.storeRequestData(r, t), a.storeResponse(t, e.generic, n)) : (o.info("Cannot use local storage to cache ID", i), a.clearAll(t)), new w(r, new v(e))
                }
            }]), i
        }()
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function o(r) {
        for (var e = 1; e < arguments.length; e++) {
            var o = null != arguments[e] ? arguments[e] : {};
            e % 2 ? i(Object(o), !0).forEach(function(e) {
                var t, n;
                t = r, e = o[n = e], (n = s(n)) in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(o)) : i(Object(o)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(o, e))
            })
        }
        return r
    }

    function a(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, s(r.key), r)
        }
    }

    function s(e) {
        e = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== r(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === r(e) ? e : String(e)
    }
    n.d(t, "a", function() {
        return u
    }), n.d(t, "b", function() {
        return l
    });
    var c = "https://diagnostics.id5-sync.com/measurements",
        u = "undefined" != typeof Promise && "undefined" != typeof fetch,
        l = function() {
            function n(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, n), this.url = e || c, this._metadata = t
            }
            var e, t, r;
            return e = n, (t = [{
                key: "publish",
                value: function(e) {
                    var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                    return e && 0 < e.length ? (e.forEach(function(e) {
                        var n;
                        n = e.tags, Object.keys(n).forEach(function(e) {
                            var t = n[e];
                            t && (t instanceof Object ? n[e] = JSON.stringify(t) : n[e] = "".concat(t))
                        })
                    }), fetch(this.url, {
                        method: "POST",
                        headers: {
                            "Content-Type": "text/plain"
                        },
                        mode: "no-cors",
                        body: JSON.stringify({
                            metadata: o(o({}, this._metadata), t),
                            measurements: e
                        })
                    })) : Promise.resolve()
                }
            }]) && a(e.prototype, t), r && a(e, r), Object.defineProperty(e, "prototype", {
                writable: !1
            }), n
        }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return y
    });
    var r = n(13),
        o = n(14);

    function i(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function a(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? arguments[e] : {};
            e % 2 ? i(Object(n), !0).forEach(function(e) {
                s(t, e, n[e])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
            })
        }
        return t
    }

    function s(e, t, n) {
        return (t = p(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function c(e) {
        return (c = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function u(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null != n) {
                var r, o, i, a, s = [],
                    c = !0,
                    u = !1;
                try {
                    if (i = (n = n.call(e)).next, 0 === t) {
                        if (Object(n) !== n) return;
                        c = !1
                    } else
                        for (; !(c = (r = i.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
                } catch (e) {
                    u = !0, o = e
                } finally {
                    try {
                        if (!c && null != n.return && (a = n.return(), Object(a) !== a)) return
                    } finally {
                        if (u) throw o
                    }
                }
                return s
            }
        }(e, t) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return l(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Map" === (n = "Object" === n && e.constructor ? e.constructor.name : n) || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(e, t) : void 0
            }
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function l(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function f(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function d(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, p(r.key), r)
        }
    }

    function h(e, t, n) {
        return t && d(e.prototype, t), n && d(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e
    }

    function p(e) {
        e = function(e, t) {
            if ("object" !== c(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== c(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === c(e) ? e : String(e)
    }
    var v = function() {
            function e() {
                f(this, e)
            }
            return h(e, [{
                key: "has",
                value: function(e) {
                    return void 0 !== this[e]
                }
            }, {
                key: "set",
                value: function(e, t) {
                    return this[e] = t, this
                }
            }, {
                key: "get",
                value: function(e) {
                    return this[e]
                }
            }, {
                key: "values",
                value: function() {
                    return Object.entries(this).map(function(e) {
                        e = u(e, 2), e[0];
                        return e[1]
                    })
                }
            }]), e
        }(),
        y = function() {
            function n() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0,
                    t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                f(this, n), s(this, "_registry", void 0), s(this, "commonTags", void 0), s(this, "_scheduled", void 0), this._registry = new v, this.commonTags = o.a.from(e), this.commonPrefix = t
            }
            return h(n, [{
                key: "getOrCreate",
                value: function(e, t, n) {
                    var r = a(a({}, t), this.commonTags),
                        t = this.commonPrefix ? this.commonPrefix + "." + e : e,
                        e = "".concat(t, "[").concat(o.a.toString(r), "]");
                    return this._registry.has(e) || this._registry.set(e, n(t, r)), this._registry.get(e)
                }
            }, {
                key: "getAllMeasurements",
                value: function() {
                    return this._registry.values().map(function(e) {
                        return {
                            name: e.name,
                            type: e.type,
                            tags: e.tags,
                            values: e.values
                        }
                    }).filter(function(e) {
                        return e.values && 0 < e.values.length
                    })
                }
            }, {
                key: "reset",
                value: function() {
                    Array.from(this._registry.values()).forEach(function(e) {
                        return e.reset()
                    })
                }
            }, {
                key: "addCommonTags",
                value: function(e) {
                    this.commonTags = a(a({}, this.commonTags), o.a.from(e))
                }
            }, {
                key: "timer",
                value: function(e) {
                    return this.getOrCreate(e, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, function(e, t) {
                        return new r.d(e, t)
                    })
                }
            }, {
                key: "counter",
                value: function(e) {
                    return this.getOrCreate(e, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, function(e, t) {
                        return new r.a(e, t)
                    })
                }
            }, {
                key: "summary",
                value: function(e) {
                    return this.getOrCreate(e, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, function(e, t) {
                        return new r.b(e, t)
                    })
                }
            }, {
                key: "publish",
                value: function() {
                    var t = this,
                        n = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : function(e) {
                            return e
                        },
                        r = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
                    return Promise.resolve(this.getAllMeasurements()).then(function(e) {
                        return n(e, r)
                    }).then(function(e) {
                        return t.reset()
                    })
                }
            }, {
                key: "schedulePublishAfterMsec",
                value: function(e, t) {
                    var n;
                    return this._scheduled || (n = this, setTimeout(function() {
                        return n._scheduled = !1, n.publish(t, {
                            trigger: "fixed-time",
                            fixed_time_msec: e
                        })
                    }, e), this._scheduled = !0), this
                }
            }, {
                key: "schedulePublishBeforeUnload",
                value: function(e) {
                    var t = this;
                    return addEventListener("beforeunload", function() {
                        return t.publish(e, {
                            trigger: "beforeunload"
                        })
                    }), this
                }
            }]), n
        }()
}, function(e, t, n) {
    "use strict";

    function o() {
        return (o = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n, r = arguments[t];
                for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }).apply(this, arguments)
    }
    n.d(t, "a", function() {
        return r
    });
    var a, r = (a = window, function() {
        try {
            var e, t, n = s(),
                r = n.length - 1,
                o = null !== n[r].location || 0 < r && null !== n[r - 1].referrer,
                i = function(e) {
                    for (var t, n = [], r = null, o = null, i = null, a = null, s = null, c = e.length - 1; 0 <= c; c--) {
                        try {
                            o = e[c].location
                        } catch (e) {}
                        if (o) n.push(o), s = s || o;
                        else if (0 !== c) {
                            t = e[c - 1];
                            try {
                                i = t.referrer, a = t.ancestor
                            } catch (e) {}
                            i ? (n.push(i), s = s || i) : a ? (n.push(a), s = s || a) : n.push(r)
                        } else n.push(r)
                    }
                    return {
                        stack: n,
                        detectedRefererUrl: s
                    }
                }(n);
            n[n.length - 1].canonicalUrl && (e = n[n.length - 1].canonicalUrl);
            try {
                t = a.top.document.referrer
            } catch (e) {}
            return {
                topmostLocation: i.detectedRefererUrl,
                ref: t || null,
                reachedTop: o,
                numIframes: r,
                stack: i.stack,
                canonicalUrl: e
            }
        } catch (e) {}
    });

    function s() {
        var e = function() {
                var t, n = [];
                do {
                    try {
                        t = t ? t.parent : a;
                        try {
                            var e = t === a.top,
                                r = {
                                    referrer: t.document.referrer || null,
                                    location: t.location.href || null,
                                    isTop: e
                                };
                            e && (r = o(r, {
                                canonicalUrl: function(e) {
                                    try {
                                        var t = e.querySelector("link[rel='canonical']");
                                        if (null !== t) return t.href
                                    } catch (e) {}
                                    return null
                                }(t.document)
                            })), n.push(r)
                        } catch (e) {
                            n.push({
                                referrer: null,
                                location: null,
                                isTop: t === a.top
                            })
                        }
                    } catch (e) {
                        return n.push({
                            referrer: null,
                            location: null,
                            isTop: !1
                        }), n
                    }
                } while (t !== a.top);
                return n
            }(),
            t = function() {
                try {
                    return a.location.ancestorOrigins ? a.location.ancestorOrigins : void 0
                } catch (e) {}
            }();
        if (t)
            for (var n = 0, r = t.length; n < r; n++) e[n].ancestor = t[n];
        return e
    }
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return c
    });
    var d = n(5),
        r = n(29),
        h = n(2);

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function p() {
        return (p = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n, r = arguments[t];
                for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }).apply(this, arguments)
    }

    function i(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, s(r.key), r)
        }
    }

    function a(e, t, n) {
        return (t = s(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function s(e) {
        e = function(e, t) {
            if ("object" !== o(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== o(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === o(e) ? e : String(e)
    }
    var l = Object.freeze({
            tcfv1: {
                objName: "__cmpCall",
                objKeys: ["command", "parameter"],
                returnObjName: "__cmpReturn"
            },
            tcfv2: {
                objName: "__tcfapiCall",
                objKeys: ["command", "version"],
                returnObjName: "__tcfapiReturn"
            },
            uspv1: {
                objName: "__uspapiCall",
                objKeys: ["command", "version"],
                returnObjName: "__uspapiReturn"
            },
            gppv1: {
                objName: "__gppCall",
                objKeys: ["command", "parameter"],
                returnObjName: "__gppReturn"
            }
        }),
        v = Object.freeze({
            TCF: 0,
            USP: 1
        }),
        c = function() {
            function f(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : h.i;
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, f), a(this, "_lookupInProgress", void 0), a(this, "_log", void 0), a(this, "_metrics", void 0), this._metrics = e, this._log = t
            }
            var e, t, n;
            return e = f, n = [{
                key: "_buildCmpSurrogate",
                value: function(s, c) {
                    var u = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : function(e) {
                        return !0
                    };
                    return function(e, t, n) {
                        var r = Math.random() + "",
                            o = l[s],
                            i = {},
                            a = {};
                        a[o.objKeys[0]] = e, a[o.objKeys[1]] = t, a.callId = r, i[o.objName] = a;
                        a = function e(t) {
                            t = Object(d.e)(t, "data.".concat(o.returnObjName));
                            t && t.callId === r && (n(t.returnValue, t.success), u(t.returnValue) && window.removeEventListener("message", e))
                        };
                        window.addEventListener("message", a, !1), c.postMessage(i, "*")
                    }
                }
            }, {
                key: "_isValidV1ConsentObject",
                value: function(e) {
                    var t = Object(d.e)(e, "getConsentData.gdprApplies");
                    return !!Object(d.i)(t) && (!1 === t || Object(d.o)(e.getConsentData.consentData) && Object(d.n)(e.getVendorConsents) && 1 < Object.keys(e.getVendorConsents).length)
                }
            }, {
                key: "_isValidV2ConsentObject",
                value: function(e) {
                    var t = e && e.gdprApplies,
                        e = e && e.tcString;
                    return !1 === t || Object(d.o)(e)
                }
            }, {
                key: "_normalizeV1Data",
                value: function(e) {
                    return {
                        consentString: e.getConsentData.consentData,
                        localStoragePurposeConsent: Object(d.e)(e, "getVendorConsents.purposeConsents.1"),
                        gdprApplies: e.getConsentData.gdprApplies,
                        api: h.a.TCF_V1
                    }
                }
            }, {
                key: "_normalizeV2Data",
                value: function(e) {
                    var t = Object(d.e)(e, "purpose.consents.1");
                    return Object(d.i)(t) || (t = Object(r.a)(e.tcString, 1)), {
                        consentString: e.tcString,
                        localStoragePurposeConsent: t,
                        gdprApplies: e.gdprApplies,
                        api: h.a.TCF_V2
                    }
                }
            }, {
                key: "_parseGppData",
                value: function(e) {
                    return {
                        version: null == e ? void 0 : e.gppVersion,
                        cmpStatus: null == e ? void 0 : e.cmpStatus,
                        supportedAPIs: null == e ? void 0 : e.supportedAPIs,
                        applicableSections: null == e ? void 0 : e.applicableSections,
                        gppString: null == e ? void 0 : e.gppString
                    }
                }
            }, {
                key: "_findTCF",
                value: function() {
                    for (var e, t, n = 0, r = window; !e;) {
                        try {
                            if ("function" == typeof r.__tcfapi || "function" == typeof r.__cmp) {
                                t = "function" == typeof r.__tcfapi ? (n = 2, r.__tcfapi) : (n = 1, r.__cmp), e = r;
                                break
                            }
                        } catch (e) {}
                        try {
                            if (r.frames.__tcfapiLocator) {
                                n = 2, e = r;
                                break
                            }
                        } catch (e) {}
                        try {
                            if (r.frames.__cmpLocator) {
                                n = 1, e = r;
                                break
                            }
                        } catch (e) {}
                        if (r === window.top) break;
                        r = r.parent
                    }
                    return {
                        cmpVersion: n,
                        cmpFrame: e,
                        cmpFunction: t
                    }
                }
            }, {
                key: "_findCmpApi",
                value: function(e) {
                    for (var t, n, r = window; !t;) {
                        try {
                            if ("function" == typeof r[e]) {
                                n = r[e], t = r;
                                break
                            }
                        } catch (e) {}
                        try {
                            if (r.frames["".concat(e, "Locator")]) {
                                t = r;
                                break
                            }
                        } catch (e) {}
                        if (r === window.top) break;
                        r = r.parent
                    }
                    return {
                        cmpApiFrame: t,
                        cmpApiFunction: n
                    }
                }
            }], (t = [{
                key: "refreshConsentData",
                value: function(e, t, n) {
                    var r = this;
                    return r._lookupInProgress || (r._lookupInProgress = !0, r._consentDataPromise = this._lookupConsentData(e, t, n).finally(function() {
                        r._lookupInProgress = !1
                    })), this._consentDataPromise
                }
            }, {
                key: "_lookupConsentData",
                value: function(e, t, n) {
                    var r = this;
                    if (e) {
                        this._log.warn("cmpApi: ID5 is operating in forced consent mode and will not retrieve any consent signals from the CMP");
                        e = new h.e;
                        return e.forcedGrantByConfig = !0, Promise.resolve(e)
                    }
                    switch (t) {
                        case "static":
                            return new Promise(function(e, t) {
                                r._parseStaticConsentData(n, e)
                            });
                        case "iab":
                            return new Promise(function(e, t) {
                                r._lookupIabConsent(e)
                            });
                        default:
                            return this._log.error("cmpApi: Unknown consent API: ".concat(t)), Promise.reject(new Error("Unknown consent API: ".concat(t)))
                    }
                }
            }, {
                key: "_parseStaticConsentData",
                value: function(e, t) {
                    e = e || {};
                    var n = new h.e,
                        r = {};
                    Object(d.n)(e.getConsentData) ? r = this._parseTcfData(e, 1) : Object(d.n)(e.getTCData) ? r = this._parseTcfData(e.getTCData, 2) : Object(d.h)(e.allowedVendors) ? r = {
                        api: h.a.ID5_ALLOWED_VENDORS,
                        allowedVendors: e.allowedVendors.map(function(e) {
                            return String(e)
                        }),
                        gdprApplies: !0
                    } : Object(d.n)(e.getUSPData) ? r = this._parseUspData(e.getUSPData) : this._log.warn("cmpApi: No static consent data detected! Using defaults."), p(n, r), this._log.info("cmpApi: Detected API '".concat(n.api, "' from static consent data"), e), t(n)
                }
            }, {
                key: "_lookupIabConsent",
                value: function(n) {
                    var r = [],
                        o = new h.e,
                        e = function(t) {
                            return r[t] = 0,
                                function(e) {
                                    r[t] || (r[t] = Date.now(), e && p(o, e), r.every(function(e) {
                                        return 0 < e
                                    }) && n(o))
                                }
                        },
                        t = e(v.TCF),
                        e = e(v.USP);
                    this._lookupGpp(o, r), this._lookupTcf(t), this._lookupUsp(e)
                }
            }, {
                key: "_lookupUsp",
                value: function(n) {
                    var r = this,
                        e = f._findCmpApi("__uspapi"),
                        t = e.cmpApiFrame,
                        e = e.cmpApiFunction;
                    if (!t) return this._log.warn("cmpApi: USP not found! Using defaults for CCPA."), void n();
                    (Object(d.j)(e) ? (this._log.info("cmpApi: Detected USP is directly accessible, calling it now."), e) : (this._log.info("cmpApi: Detected USP is outside the current iframe. Using message passing."), f._buildCmpSurrogate("uspv1", t)))("getUSPData", 1, function(e, t) {
                        t ? n(r._parseUspData(e)) : (r._log.error("cmpApi: USP callback not successful. Using defaults for CCPA."), n())
                    })
                }
            }, {
                key: "_lookupGpp",
                value: function(i, a) {
                    var s, n, c = this,
                        e = f._findCmpApi("__gpp"),
                        t = e.cmpApiFrame,
                        e = e.cmpApiFunction,
                        u = Date.now(),
                        l = !1;
                    t ? (s = function(e) {
                        return "cmpStatus" === (null == e ? void 0 : e.eventName) || "sectionChange" === (null == e ? void 0 : e.eventName)
                    }, (Object(d.j)(e) ? (l = !0, this._log.info("cmpApi: Detected GPP is directly accessible, calling it now."), e) : (this._log.info("cmpApi: Detected GPP is outside the current iframe. Using message passing."), n = f._buildCmpSurrogate("gppv1", t, s), function(e, t) {
                        n(e, null, t)
                    }))("addEventListener", function(e) {
                        var t, n = Date.now(),
                            r = f._parseGppData(e.pingData),
                            o = {
                                gppEventName: e.eventName,
                                gppVersion: r.version,
                                directCmp: l
                            };
                        s(e) ? (c._metrics.timer("gpp.delay", p({}, o, r)).record(n - u), (!(r = a[v.TCF]) || i.api !== h.a.TCF_V1 && i.api !== h.a.TCF_V2) && r || (t = r ? n - r : 0, c._metrics.timer("gpp.otherCmp.delay", p({}, o, {
                            apiType: i.api
                        })).record(t)), ((t = a[v.USP]) && i.api === h.a.USP_V1 || !t) && (t = t ? n - t : 0, c._metrics.timer("gpp.otherCmp.delay", p({}, o, {
                            apiType: i.api
                        })).record(t))) : (c._metrics.counter("gpp.events", o).inc(1), c._log.error("cmpApi: GPP callback not successful. Using defaults."))
                    })) : this._log.warn("cmpApi: GPP not found! Using defaults.")
                }
            }, {
                key: "_lookupTcf",
                value: function(e) {
                    var t = f._findTCF(),
                        n = t.cmpVersion,
                        r = t.cmpFrame,
                        t = t.cmpFunction;
                    if (!r) return this._log.warn("cmpApi: TCF not found! Using defaults for GDPR."), void e();
                    Object(d.j)(t) ? this._lookupDirectTcf(n, t, e) : (this._log.info("cmpApi: Detected TCF is outside the current iframe. Using message passing."), this._lookupMessageTcf(n, r, e))
                }
            }, {
                key: "_lookupMessageTcf",
                value: function(e, t, n) {
                    t = f._buildCmpSurrogate(1 === e ? "tcfv1" : "tcfv2", t);
                    this._lookupDirectTcf(e, t, n)
                }
            }, {
                key: "_lookupDirectTcf",
                value: function(e, t, r) {
                    function o(e, t, n) {
                        s.info("cmpApi: TCFv".concat(e, " - Received a call back: ").concat(t), n)
                    }

                    function i(e, t) {
                        s.error("cmpApi: TCFv".concat(e, " - Received insuccess: ").concat(t, ". Please check your CMP setup. Using defaults for GDPR."))
                    }
                    var n, a = this,
                        s = this._log,
                        c = {},
                        u = {},
                        l = function(n) {
                            return u[n] = !1,
                                function(e, t) {
                                    u[n] = !0, t ? (o(1, n, e), c[n] = e) : i(1, n), Object.values(u).every(function(e) {
                                        return e
                                    }) && r(a._parseTcfData(c, 1))
                                }
                        };
                    1 === e ? (n = l("getConsentData"), l = l("getVendorConsents"), t("getConsentData", null, n), t("getVendorConsents", null, l)) : 2 === e && t("addEventListener", e, function(e, t) {
                        if (o(2, "event", e), !t) return i(2, "addEventListener"), void r();
                        !e || !1 !== e.gdprApplies && "tcloaded" !== e.eventStatus && "useractioncomplete" !== e.eventStatus || r(a._parseTcfData(e, 2))
                    })
                }
            }, {
                key: "_parseUspData",
                value: function(e) {
                    if (Object(d.n)(e) && Object(d.o)(e.uspString)) return {
                        api: h.a.USP_V1,
                        hasCcpaString: !0,
                        ccpaString: e.uspString
                    };
                    this._log.error("cmpApi: No or malformed USP data. Using defaults for CCPA.")
                }
            }, {
                key: "_parseTcfData",
                value: function(e, t) {
                    var n, r, o = this._log;
                    if (1 === t) n = f._isValidV1ConsentObject, r = f._normalizeV1Data;
                    else {
                        if (2 !== t) return void o.error("cmpApi: No or malformed CMP data. Using defaults for GDPR.");
                        n = f._isValidV2ConsentObject, r = f._normalizeV2Data
                    }
                    if (n(e)) return r(e);
                    o.error("cmpApi: Invalid CMP data. Using defaults for GDPR.", e)
                }
            }]) && i(e.prototype, t), n && i(e, n), Object.defineProperty(e, "prototype", {
                writable: !1
            }), f
        }()
}, function(e, t, n) {
    "use strict";
    t.a = function(e, t) {
        var n = 152 + t - 1,
            t = ~~(n / o);
        if (!e || "C" !== e.charAt(0) || e.length <= t) return;
        t = e.charAt(t), t = r[t];
        return void 0 !== t ? 0 != (t & 1 << o - n % o - 1) : void 0
    };
    var r = {
            A: 0,
            B: 1,
            C: 2,
            D: 3,
            E: 4,
            F: 5,
            G: 6,
            H: 7,
            I: 8,
            J: 9,
            K: 10,
            L: 11,
            M: 12,
            N: 13,
            O: 14,
            P: 15,
            Q: 16,
            R: 17,
            S: 18,
            T: 19,
            U: 20,
            V: 21,
            W: 22,
            X: 23,
            Y: 24,
            Z: 25,
            a: 26,
            b: 27,
            c: 28,
            d: 29,
            e: 30,
            f: 31,
            g: 32,
            h: 33,
            i: 34,
            j: 35,
            k: 36,
            l: 37,
            m: 38,
            n: 39,
            o: 40,
            p: 41,
            q: 42,
            r: 43,
            s: 44,
            t: 45,
            u: 46,
            v: 47,
            w: 48,
            x: 49,
            y: 50,
            z: 51,
            0: 52,
            1: 53,
            2: 54,
            3: 55,
            4: 56,
            5: 57,
            6: 58,
            7: 59,
            8: 60,
            9: 61,
            "-": 62,
            _: 63,
            "+": 62,
            "/": 63
        },
        o = 6
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return f
    });
    var i = n(5),
        r = n(2);

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function a() {
        return (a = Object.assign ? Object.assign.bind() : function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n, r = arguments[t];
                for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
            }
            return e
        }).apply(this, arguments)
    }

    function s(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, c(r.key), r)
        }
    }

    function u(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function l(e, t, n) {
        return (t = c(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function c(e) {
        e = function(e, t) {
            if ("object" !== o(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== o(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === o(e) ? e : String(e)
    }
    var f = function() {
        function c(e, t, n, r, o, i, a) {
            var s = this;
            u(this, c), l(this, "_availableCallbackTimerId", void 0), l(this, "_availableCallbackFired", !1), l(this, "_availableCallback", void 0), l(this, "_updateCallback", void 0), l(this, "_refreshCallbackTimerId", void 0), l(this, "_refreshCallbackFired", !1), l(this, "_refreshCallback", void 0), l(this, "_isExposed", void 0), l(this, "_fromCache", void 0), l(this, "_isRefreshing", !1), l(this, "_isRefreshingWithFetch", !1), l(this, "_userId", void 0), l(this, "_ext", void 0), l(this, "_userIdAvailable", !1), l(this, "_userIdAvailablePromise", void 0), l(this, "_userIdAvailablePromiseResolver", void 0), l(this, "invocationId", void 0), l(this, "config", void 0), l(this, "clientStore", void 0), l(this, "consentManagement", void 0), l(this, "_consentDataProvider", void 0), l(this, "_metrics", void 0), l(this, "_logger", void 0), this.config = e, this.clientStore = t, this.consentManagement = n, this._metrics = r, this._consentDataProvider = o, this._logger = i, this.instance = a, this._userIdAvailablePromise = new Promise(function(e) {
                s._userIdAvailablePromiseResolver = e
            })
        }
        var e, t, n;
        return e = c, n = [{
            key: "doFireOnAvailableCallBack",
            value: function(e) {
                e.info("Id5Status.doFireOnAvailableCallBack"), e._availableCallbackFired = !0, e._availableCallbackTimerId = void 0, e._availableCallback(e)
            }
        }, {
            key: "doFireOnUpdateCallBack",
            value: function(e) {
                e.info("Id5Status.doFireOnUpdateCallBack"), e._updateCallback(e)
            }
        }, {
            key: "doFireOnRefreshCallBack",
            value: function(e) {
                e.info("Id5Status.doFireOnRefreshCallBack"), e._refreshCallbackFired = !0, e._refreshCallbackTimerId = void 0, e._isRefreshing = !1, e._isRefreshingWithFetch = !1, e._refreshCallback(e)
            }
        }], (t = [{
            key: "getOptions",
            value: function() {
                return this.config.getOptions()
            }
        }, {
            key: "getProvidedOptions",
            value: function() {
                return this.config.getProvidedOptions()
            }
        }, {
            key: "getInvalidSegments",
            value: function() {
                return this.config.getInvalidSegments()
            }
        }, {
            key: "updateOptions",
            value: function(e) {
                return this.config.updOptions(e)
            }
        }, {
            key: "startRefresh",
            value: function(e) {
                this._isRefreshing = !0, this._isRefreshingWithFetch = e
            }
        }, {
            key: "setUserId",
            value: function(e, t) {
                var n = this,
                    r = e.universal_uid;
                if (this._isExposed = !0, Object(i.n)(e.ab_testing)) switch (e.ab_testing.result) {
                    case "normal":
                        break;
                    default:
                    case "error":
                        this._logger.error("Id5Status: There was an error with A/B Testing. Make sure controlGroupRatio is a number >= 0 and <= 1");
                        break;
                    case "control":
                        this._isExposed = !1, this.info("User is in control group!")
                }
                var o = this._userId !== r || !1 === Object(i.c)(this._ext, e.ext);
                this._userIdAvailable = !0, this._userId = r, this._userIdAvailablePromiseResolver(r), this._ext = e.ext, this._fromCache = t, this.info("User id updated, hasChanged: ".concat(o, ", fromCache: ").concat(t)), Object(i.j)(this._availableCallback) && !1 === this._availableCallbackFired && (this._availableCallbackTimerId && (this.info("Cancelling pending onAvailableCallback watchdog"), clearTimeout(this._availableCallbackTimerId), this._availableCallbackTimerId = void 0), this._availableCallbackTimerId = setTimeout(function() {
                    return c.doFireOnAvailableCallBack(n)
                }, 0)), this._isRefreshing && Object(i.j)(this._refreshCallback) && !1 === this._refreshCallbackFired && (!1 !== t && !1 !== this._isRefreshingWithFetch || (this._refreshCallbackTimerId && (this.info("Cancelling pending onRefreshCallback watchdog"), clearTimeout(this._refreshCallbackTimerId), this._refreshCallbackTimerId = void 0), this._refreshCallbackTimerId = setTimeout(function() {
                    return c.doFireOnRefreshCallBack(n)
                }, 0))), o && Object(i.j)(this._updateCallback) && setTimeout(function() {
                    return c.doFireOnUpdateCallBack(n)
                }, 0)
            }
        }, {
            key: "getUserId",
            value: function() {
                return !1 === this._isExposed ? "0" : this._userId
            }
        }, {
            key: "getLinkType",
            value: function() {
                return !1 === this._isExposed ? 0 : this.getExt().linkType
            }
        }, {
            key: "getExt",
            value: function() {
                var e = !1 === this._isExposed ? {} : this._ext;
                return a({
                    abTestingControlGroup: !this.exposeUserId()
                }, e)
            }
        }, {
            key: "isFromCache",
            value: function() {
                return this._fromCache
            }
        }, {
            key: "exposeUserId",
            value: function() {
                return this._isExposed
            }
        }, {
            key: "getUserIdAsEid",
            value: function() {
                return {
                    source: r.c.ID5_EIDS_SOURCE,
                    uids: [{
                        atype: 1,
                        id: this.getUserId(),
                        ext: this.getExt()
                    }]
                }
            }
        }, {
            key: "onAvailable",
            value: function(e, t) {
                if (!Object(i.j)(e)) throw new Error("onAvailable expect a function");
                var n;
                return Object(i.j)(this._availableCallback) ? this.info("onAvailable was already called, ignoring") : (this._availableCallback = e, (n = this)._userIdAvailable ? (this.info("User id already available firing callback immediately"), this._availableCallbackTimerId = setTimeout(function() {
                    return c.doFireOnAvailableCallBack(n)
                }, 0)) : 0 < t && (this._availableCallbackTimerId = setTimeout(function() {
                    return c.doFireOnAvailableCallBack(n)
                }, t))), this
            }
        }, {
            key: "onUpdate",
            value: function(e) {
                if (!Object(i.j)(e)) throw new Error("onUpdate expect a function");
                this._updateCallback = e;
                var t = this;
                return this._userIdAvailable && setTimeout(function() {
                    return c.doFireOnUpdateCallBack(t)
                }, 0), this
            }
        }, {
            key: "onRefresh",
            value: function(e, t) {
                if (!Object(i.j)(e)) throw new Error("onRefresh expect a function");
                this._refreshCallbackTimerId && (clearTimeout(this._refreshCallbackTimerId), this._refreshCallbackTimerId = void 0), this._refreshCallback = e;
                var n = this;
                return !0 === this._isRefreshing && !1 === this._isRefreshingWithFetch && this._userIdAvailable ? this._refreshCallbackTimerId = setTimeout(function() {
                    return c.doFireOnRefreshCallBack(n)
                }, 0) : 0 < t && (this._refreshCallbackTimerId = setTimeout(function() {
                    return c.doFireOnRefreshCallBack(n)
                }, t)), this
            }
        }, {
            key: "localStorageGrant",
            value: function() {
                return this.clientStore.localStorageGrant()
            }
        }, {
            key: "info",
            value: function(e) {
                this._logger.info("Id5Status: " + e)
            }
        }, {
            key: "collectEvent",
            value: function(t, n) {
                function e(e) {
                    return e = new Request("https://id5-sync.com/event", {
                        method: "POST",
                        mode: "no-cors",
                        body: JSON.stringify({
                            partnerId: r.config.getOptions().partnerId,
                            id5id: e,
                            eventType: t,
                            metadata: n
                        })
                    }), r.info("Sending event", e), fetch(e).catch(function(e) {
                        return r._logger.error("Error while sending event to ID5 of type " + t, e)
                    })
                }
                var r = this;
                return this._userIdAvailable ? e(this._userId) : this._userIdAvailablePromise.then(e)
            }
        }]) && s(e.prototype, t), n && s(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), c
    }()
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return r
    });
    var r = "1.0.54"
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return a
    });
    var h = n(0),
        p = n(5),
        r = n(2);

    function v(e) {
        return (v = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function y(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, i(r.key), r)
        }
    }

    function g(e, t, n) {
        return (t = i(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function i(e) {
        e = function(e, t) {
            if ("object" !== v(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === t ? String : Number)(e);
            t = n.call(e, t || "default");
            if ("object" !== v(t)) return t;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(e, "string");
        return "symbol" === v(e) ? e : String(e)
    }
    var a = function() {
        function d(e) {
            var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : r.i;
            if (! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, d), g(this, "invocationId", void 0), g(this, "options", void 0), g(this, "providedOptions", void 0), g(this, "invalidSegments", void 0), this._log = t, this.options = {
                    debugBypassConsent: !1,
                    allowLocalStorageWithoutConsentApi: !1,
                    cmpApi: "iab",
                    consentData: {
                        getConsentData: {
                            consentData: void 0,
                            gdprApplies: void 0
                        },
                        getVendorConsents: {}
                    },
                    refreshInSeconds: 7200,
                    partnerId: void 0,
                    partnerUserId: void 0,
                    callbackOnAvailable: void 0,
                    callbackOnUpdates: void 0,
                    callbackTimeoutInMs: void 0,
                    pd: void 0,
                    abTesting: {
                        enabled: !1,
                        controlGroupPct: 0
                    },
                    provider: void 0,
                    maxCascades: 8,
                    applyCreativeRestrictions: !1,
                    acr: !1,
                    segments: void 0,
                    disableUaHints: !1,
                    storageExpirationDays: void 0,
                    att: void 0,
                    diagnostics: {
                        publishingDisabled: !1,
                        publishAfterLoadInMsec: 3e4,
                        publishBeforeWindowUnload: !0,
                        publishingSampleRatio: .01
                    },
                    multiplexing: {
                        _disabled: !1
                    }
                }, this.providedOptions = {}, !Object(p.m)(e.partnerId) && !Object(p.o)(e.partnerId)) throw new Error("partnerId is required and must be a number or a string");
            this.invalidSegments = 0, this.updOptions(e), this.storageConfig = new r.j(e.storageExpirationDays)
        }
        var e, t, n;
        return e = d, (t = [{
            key: "getOptions",
            value: function() {
                return this.options
            }
        }, {
            key: "getProvidedOptions",
            value: function() {
                return this.providedOptions
            }
        }, {
            key: "getInvalidSegments",
            value: function() {
                return this.invalidSegments
            }
        }, {
            key: "hasCreativeRestrictions",
            value: function() {
                return this.options.applyCreativeRestrictions || this.options.acr
            }
        }, {
            key: "updOptions",
            value: function(s) {
                var c, u = this,
                    l = this,
                    f = l._log;
                Object(p.n)(s) ? (this.setPartnerId(s.partnerId), c = function(e, t) {
                    u.options[e] = t, u.providedOptions[e] = t
                }, Object.keys(s).forEach(function(e) {
                    var n, t, r, o, i, a;
                    "segments" === e ? (a = s[e], n = [], Object(h.isDefined)(a) && (Object(p.h)(a) ? (a.forEach(function(e, t) {
                        t = "segments[".concat(t, "]");
                        return Object(p.h)(e.ids) && Object(p.b)(e.ids, p.o) ? e.ids.length < 1 ? (f.error("Config option ".concat(t, ".ids should contain at least one segment ID")), void(l.invalidSegments += 1)) : Object(p.o)(e.destination) ? void n.push(e) : (m(f, "".concat(t, ".destination"), "String", e.destination), void(l.invalidSegments += 1)) : (m(f, "".concat(t, ".ids"), "Array of String", e.ids), void(l.invalidSegments += 1))
                    }), c(e, n)) : m(f, e, "Array", a))) : "diagnostics" === e ? (t = u.options.diagnostics, r = s.diagnostics, Object(p.g)(r, d.configTypes.diagnostics) && (o = function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = null != arguments[e] ? arguments[e] : {};
                            e % 2 ? y(Object(n), !0).forEach(function(e) {
                                g(t, e, n[e])
                            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : y(Object(n)).forEach(function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                            })
                        }
                        return t
                    }({}, t), Object.keys(r).forEach(function(e) {
                        void 0 !== t[e] && v(t[e]) === v(r[e]) && (o[e] = r[e])
                    }), u.options[e] = o), u.providedOptions[e] = s[e]) : "partnerId" !== e && (i = d.configTypes[e], a = s[e], Object(h.isDefined)(a) && (Object(p.g)(a, i) ? c(e, a) : m(f, e, i, a)))
                })) : f.error("Config options must be an object")
            }
        }, {
            key: "setPartnerId",
            value: function(e) {
                var t;
                if (Object(p.o)(e)) {
                    if (t = parseInt(e), isNaN(t) || t < 0) throw new Error("partnerId is required and must parse to a positive integer")
                } else Object(p.m)(e) && (t = e);
                if (Object(p.m)(t)) {
                    if (Object(p.m)(this.options.partnerId) && t !== this.options.partnerId) throw new Error("Cannot update config with a different partnerId");
                    this.options.partnerId = t, this.providedOptions.partnerId = e
                }
            }
        }]) && o(e.prototype, t), n && o(e, n), Object.defineProperty(e, "prototype", {
            writable: !1
        }), d
    }();

    function m(e, t, n, r) {
        e.error("Config option ".concat(t, " must be of type ").concat(n, " but was ").concat(toString.call(r), ". Ignoring..."))
    }
    g(a, "configTypes", {
        debugBypassConsent: "Boolean",
        allowLocalStorageWithoutConsentApi: "Boolean",
        cmpApi: "String",
        consentData: "Object",
        refreshInSeconds: "Number",
        partnerUserId: "String",
        callbackOnAvailable: "Function",
        callbackOnUpdates: "Function",
        callbackTimeoutInMs: "Number",
        pd: "String",
        abTesting: "Object",
        provider: "String",
        maxCascades: "Number",
        applyCreativeRestrictions: "Boolean",
        acr: "Boolean",
        disableUaHints: "Boolean",
        storageExpirationDays: "Number",
        att: "Number",
        diagnostics: "Object",
        multiplexing: "Object",
        dynamicConfig: "Object"
    })
}, function(t, e, n) {
    t = function(a) {
        "use strict";
        var c, e = Object.prototype,
            u = e.hasOwnProperty,
            l = Object.defineProperty || function(e, t, n) {
                e[t] = n.value
            },
            t = "function" == typeof Symbol ? Symbol : {},
            r = t.iterator || "@@iterator",
            n = t.asyncIterator || "@@asyncIterator",
            o = t.toStringTag || "@@toStringTag";

        function i(e, t, n) {
            return Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }), e[t]
        }
        try {
            i({}, "")
        } catch (e) {
            i = function(e, t, n) {
                return e[t] = n
            }
        }

        function s(e, t, n, r) {
            var o, i, a, s, t = t && t.prototype instanceof g ? t : g,
                t = Object.create(t.prototype),
                r = new I(r || []);
            return l(t, "_invoke", {
                value: (o = e, i = n, a = r, s = d, function(e, t) {
                    if (s === p) throw new Error("Generator is already running");
                    if (s === v) {
                        if ("throw" === e) throw t;
                        return P()
                    }
                    for (a.method = e, a.arg = t;;) {
                        var n = a.delegate;
                        if (n) {
                            var r = function e(t, n) {
                                var r = n.method;
                                var o = t.iterator[r];
                                if (o === c) return n.delegate = null, "throw" === r && t.iterator.return && (n.method = "return", n.arg = c, e(t, n), "throw" === n.method) || "return" !== r && (n.method = "throw", n.arg = new TypeError("The iterator does not provide a '" + r + "' method")), y;
                                var o = f(o, t.iterator, n.arg);
                                if ("throw" === o.type) return n.method = "throw", n.arg = o.arg, n.delegate = null, y;
                                o = o.arg;
                                if (!o) return n.method = "throw", n.arg = new TypeError("iterator result is not an object"), n.delegate = null, y; {
                                    if (!o.done) return o;
                                    n[t.resultName] = o.value, n.next = t.nextLoc, "return" !== n.method && (n.method = "next", n.arg = c)
                                }
                                n.delegate = null;
                                return y
                            }(n, a);
                            if (r) {
                                if (r === y) continue;
                                return r
                            }
                        }
                        if ("next" === a.method) a.sent = a._sent = a.arg;
                        else if ("throw" === a.method) {
                            if (s === d) throw s = v, a.arg;
                            a.dispatchException(a.arg)
                        } else "return" === a.method && a.abrupt("return", a.arg);
                        s = p;
                        r = f(o, i, a);
                        if ("normal" === r.type) {
                            if (s = a.done ? v : h, r.arg !== y) return {
                                value: r.arg,
                                done: a.done
                            }
                        } else "throw" === r.type && (s = v, a.method = "throw", a.arg = r.arg)
                    }
                })
            }), t
        }

        function f(e, t, n) {
            try {
                return {
                    type: "normal",
                    arg: e.call(t, n)
                }
            } catch (e) {
                return {
                    type: "throw",
                    arg: e
                }
            }
        }
        a.wrap = s;
        var d = "suspendedStart",
            h = "suspendedYield",
            p = "executing",
            v = "completed",
            y = {};

        function g() {}

        function m() {}

        function b() {}
        var _ = {};
        i(_, r, function() {
            return this
        });
        t = Object.getPrototypeOf, t = t && t(t(k([])));
        t && t !== e && u.call(t, r) && (_ = t);
        var w = b.prototype = g.prototype = Object.create(_);

        function O(e) {
            ["next", "throw", "return"].forEach(function(t) {
                i(e, t, function(e) {
                    return this._invoke(t, e)
                })
            })
        }

        function S(a, s) {
            var t;
            l(this, "_invoke", {
                value: function(n, r) {
                    function e() {
                        return new s(function(e, t) {
                            ! function t(e, n, r, o) {
                                e = f(a[e], a, n);
                                if ("throw" !== e.type) {
                                    var i = e.arg;
                                    return (n = i.value) && "object" == typeof n && u.call(n, "__await") ? s.resolve(n.__await).then(function(e) {
                                        t("next", e, r, o)
                                    }, function(e) {
                                        t("throw", e, r, o)
                                    }) : s.resolve(n).then(function(e) {
                                        i.value = e, r(i)
                                    }, function(e) {
                                        return t("throw", e, r, o)
                                    })
                                }
                                o(e.arg)
                            }(n, r, e, t)
                        })
                    }
                    return t = t ? t.then(e, e) : e()
                }
            })
        }

        function C(e) {
            var t = {
                tryLoc: e[0]
            };
            1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
        }

        function j(e) {
            var t = e.completion || {};
            t.type = "normal", delete t.arg, e.completion = t
        }

        function I(e) {
            this.tryEntries = [{
                tryLoc: "root"
            }], e.forEach(C, this), this.reset(!0)
        }

        function k(t) {
            if (t) {
                var e = t[r];
                if (e) return e.call(t);
                if ("function" == typeof t.next) return t;
                if (!isNaN(t.length)) {
                    var n = -1,
                        e = function e() {
                            for (; ++n < t.length;)
                                if (u.call(t, n)) return e.value = t[n], e.done = !1, e;
                            return e.value = c, e.done = !0, e
                        };
                    return e.next = e
                }
            }
            return {
                next: P
            }
        }

        function P() {
            return {
                value: c,
                done: !0
            }
        }
        return l(w, "constructor", {
            value: m.prototype = b,
            configurable: !0
        }), l(b, "constructor", {
            value: m,
            configurable: !0
        }), m.displayName = i(b, o, "GeneratorFunction"), a.isGeneratorFunction = function(e) {
            e = "function" == typeof e && e.constructor;
            return !!e && (e === m || "GeneratorFunction" === (e.displayName || e.name))
        }, a.mark = function(e) {
            return Object.setPrototypeOf ? Object.setPrototypeOf(e, b) : (e.__proto__ = b, i(e, o, "GeneratorFunction")), e.prototype = Object.create(w), e
        }, a.awrap = function(e) {
            return {
                __await: e
            }
        }, O(S.prototype), i(S.prototype, n, function() {
            return this
        }), a.AsyncIterator = S, a.async = function(e, t, n, r, o) {
            void 0 === o && (o = Promise);
            var i = new S(s(e, t, n, r), o);
            return a.isGeneratorFunction(t) ? i : i.next().then(function(e) {
                return e.done ? e.value : i.next()
            })
        }, O(w), i(w, o, "Generator"), i(w, r, function() {
            return this
        }), i(w, "toString", function() {
            return "[object Generator]"
        }), a.keys = function(e) {
            var t, n = Object(e),
                r = [];
            for (t in n) r.push(t);
            return r.reverse(),
                function e() {
                    for (; r.length;) {
                        var t = r.pop();
                        if (t in n) return e.value = t, e.done = !1, e
                    }
                    return e.done = !0, e
                }
        }, a.values = k, I.prototype = {
            constructor: I,
            reset: function(e) {
                if (this.prev = 0, this.next = 0, this.sent = this._sent = c, this.done = !1, this.delegate = null, this.method = "next", this.arg = c, this.tryEntries.forEach(j), !e)
                    for (var t in this) "t" === t.charAt(0) && u.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = c)
            },
            stop: function() {
                this.done = !0;
                var e = this.tryEntries[0].completion;
                if ("throw" === e.type) throw e.arg;
                return this.rval
            },
            dispatchException: function(n) {
                if (this.done) throw n;
                var r = this;

                function e(e, t) {
                    return i.type = "throw", i.arg = n, r.next = e, t && (r.method = "next", r.arg = c), !!t
                }
                for (var t = this.tryEntries.length - 1; 0 <= t; --t) {
                    var o = this.tryEntries[t],
                        i = o.completion;
                    if ("root" === o.tryLoc) return e("end");
                    if (o.tryLoc <= this.prev) {
                        var a = u.call(o, "catchLoc"),
                            s = u.call(o, "finallyLoc");
                        if (a && s) {
                            if (this.prev < o.catchLoc) return e(o.catchLoc, !0);
                            if (this.prev < o.finallyLoc) return e(o.finallyLoc)
                        } else if (a) {
                            if (this.prev < o.catchLoc) return e(o.catchLoc, !0)
                        } else {
                            if (!s) throw new Error("try statement without catch or finally");
                            if (this.prev < o.finallyLoc) return e(o.finallyLoc)
                        }
                    }
                }
            },
            abrupt: function(e, t) {
                for (var n = this.tryEntries.length - 1; 0 <= n; --n) {
                    var r = this.tryEntries[n];
                    if (r.tryLoc <= this.prev && u.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                        var o = r;
                        break
                    }
                }
                var i = (o = o && ("break" === e || "continue" === e) && o.tryLoc <= t && t <= o.finallyLoc ? null : o) ? o.completion : {};
                return i.type = e, i.arg = t, o ? (this.method = "next", this.next = o.finallyLoc, y) : this.complete(i)
            },
            complete: function(e, t) {
                if ("throw" === e.type) throw e.arg;
                return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), y
            },
            finish: function(e) {
                for (var t = this.tryEntries.length - 1; 0 <= t; --t) {
                    var n = this.tryEntries[t];
                    if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), j(n), y
                }
            },
            catch: function(e) {
                for (var t = this.tryEntries.length - 1; 0 <= t; --t) {
                    var n = this.tryEntries[t];
                    if (n.tryLoc === e) {
                        var r, o = n.completion;
                        return "throw" === o.type && (r = o.arg, j(n)), r
                    }
                }
                throw new Error("illegal catch attempt")
            },
            delegateYield: function(e, t, n) {
                return this.delegate = {
                    iterator: k(e),
                    resultName: t,
                    nextLoc: n
                }, "next" === this.method && (this.arg = c), y
            }
        }, a
    }(t.exports);
    try {
        regeneratorRuntime = t
    } catch (e) {
        "object" == typeof globalThis ? globalThis.regeneratorRuntime = t : Function("r", "regeneratorRuntime = r")(t)
    }
}]);