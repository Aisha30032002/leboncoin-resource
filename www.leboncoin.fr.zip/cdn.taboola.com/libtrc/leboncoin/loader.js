(function() {
    var __webpack_modules__ = {
            6337: function() {
                ! function() {
                    "use strict";
                    if ("object" == typeof window)
                        if ("IntersectionObserver" in window && "IntersectionObserverEntry" in window && "intersectionRatio" in window.IntersectionObserverEntry.prototype) "isIntersecting" in window.IntersectionObserverEntry.prototype || Object.defineProperty(window.IntersectionObserverEntry.prototype, "isIntersecting", {
                            get: function() {
                                return this.intersectionRatio > 0
                            }
                        });
                        else {
                            var e = function(e) {
                                    for (var t = window.document, n = i(t); n;) n = i(t = n.ownerDocument);
                                    return t
                                }(),
                                t = [],
                                n = null,
                                r = null;
                            a.prototype.THROTTLE_TIMEOUT = 100, a.prototype.POLL_INTERVAL = null, a.prototype.USE_MUTATION_OBSERVER = !0, a._setupCrossOriginUpdater = function() {
                                return n || (n = function(e, n) {
                                    r = e && n ? d(e, n) : {
                                        top: 0,
                                        bottom: 0,
                                        left: 0,
                                        right: 0,
                                        width: 0,
                                        height: 0
                                    }, t.forEach((function(e) {
                                        e._checkForIntersections()
                                    }))
                                }), n
                            }, a._resetCrossOriginUpdater = function() {
                                n = null, r = null
                            }, a.prototype.observe = function(e) {
                                if (!this._observationTargets.some((function(t) {
                                        return t.element == e
                                    }))) {
                                    if (!e || 1 != e.nodeType) throw new Error("target must be an Element");
                                    this._registerInstance(), this._observationTargets.push({
                                        element: e,
                                        entry: null
                                    }), this._monitorIntersections(e.ownerDocument), this._checkForIntersections()
                                }
                            }, a.prototype.unobserve = function(e) {
                                this._observationTargets = this._observationTargets.filter((function(t) {
                                    return t.element != e
                                })), this._unmonitorIntersections(e.ownerDocument), 0 == this._observationTargets.length && this._unregisterInstance()
                            }, a.prototype.disconnect = function() {
                                this._observationTargets = [], this._unmonitorAllIntersections(), this._unregisterInstance()
                            }, a.prototype.takeRecords = function() {
                                var e = this._queuedEntries.slice();
                                return this._queuedEntries = [], e
                            }, a.prototype._initThresholds = function(e) {
                                var t = e || [0];
                                return Array.isArray(t) || (t = [t]), t.sort().filter((function(e, t, n) {
                                    if ("number" != typeof e || isNaN(e) || e < 0 || e > 1) throw new Error("threshold must be a number between 0 and 1 inclusively");
                                    return e !== n[t - 1]
                                }))
                            }, a.prototype._parseRootMargin = function(e) {
                                var t = (e || "0px").split(/\s+/).map((function(e) {
                                    var t = /^(-?\d*\.?\d+)(px|%)$/.exec(e);
                                    if (!t) throw new Error("rootMargin must be specified in pixels or percent");
                                    return {
                                        value: parseFloat(t[1]),
                                        unit: t[2]
                                    }
                                }));
                                return t[1] = t[1] || t[0], t[2] = t[2] || t[0], t[3] = t[3] || t[1], t
                            }, a.prototype._monitorIntersections = function(t) {
                                var n = t.defaultView;
                                if (n && -1 == this._monitoringDocuments.indexOf(t)) {
                                    var r = this._checkForIntersections,
                                        o = null,
                                        a = null;
                                    this.POLL_INTERVAL ? o = n.setInterval(r, this.POLL_INTERVAL) : (u(n, "resize", r, !0), u(t, "scroll", r, !0), this.USE_MUTATION_OBSERVER && "MutationObserver" in n && (a = new n.MutationObserver(r)).observe(t, {
                                        attributes: !0,
                                        childList: !0,
                                        characterData: !0,
                                        subtree: !0
                                    })), this._monitoringDocuments.push(t), this._monitoringUnsubscribes.push((function() {
                                        var e = t.defaultView;
                                        e && (o && e.clearInterval(o), c(e, "resize", r, !0)), c(t, "scroll", r, !0), a && a.disconnect()
                                    }));
                                    var s = this.root && (this.root.ownerDocument || this.root) || e;
                                    if (t != s) {
                                        var l = i(t);
                                        l && this._monitorIntersections(l.ownerDocument)
                                    }
                                }
                            }, a.prototype._unmonitorIntersections = function(t) {
                                var n = this._monitoringDocuments.indexOf(t);
                                if (-1 != n) {
                                    var r = this.root && (this.root.ownerDocument || this.root) || e,
                                        o = this._observationTargets.some((function(e) {
                                            var n = e.element.ownerDocument;
                                            if (n == t) return !0;
                                            for (; n && n != r;) {
                                                var o = i(n);
                                                if ((n = o && o.ownerDocument) == t) return !0
                                            }
                                            return !1
                                        }));
                                    if (!o) {
                                        var a = this._monitoringUnsubscribes[n];
                                        if (this._monitoringDocuments.splice(n, 1), this._monitoringUnsubscribes.splice(n, 1), a(), t != r) {
                                            var u = i(t);
                                            u && this._unmonitorIntersections(u.ownerDocument)
                                        }
                                    }
                                }
                            }, a.prototype._unmonitorAllIntersections = function() {
                                var e = this._monitoringUnsubscribes.slice(0);
                                this._monitoringDocuments.length = 0, this._monitoringUnsubscribes.length = 0;
                                for (var t = 0; t < e.length; t++) e[t]()
                            }, a.prototype._checkForIntersections = function() {
                                if (this.root || !n || r) {
                                    var e = this._rootIsInDom(),
                                        t = e ? this._getRootRect() : {
                                            top: 0,
                                            bottom: 0,
                                            left: 0,
                                            right: 0,
                                            width: 0,
                                            height: 0
                                        };
                                    this._observationTargets.forEach((function(r) {
                                        var i = r.element,
                                            a = s(i),
                                            u = this._rootContainsTarget(i),
                                            c = r.entry,
                                            l = e && u && this._computeTargetAndRootIntersection(i, a, t),
                                            d = null;
                                        this._rootContainsTarget(i) ? n && !this.root || (d = t) : d = {
                                            top: 0,
                                            bottom: 0,
                                            left: 0,
                                            right: 0,
                                            width: 0,
                                            height: 0
                                        };
                                        var p = r.entry = new o({
                                            time: window.performance && performance.now && performance.now(),
                                            target: i,
                                            boundingClientRect: a,
                                            rootBounds: d,
                                            intersectionRect: l
                                        });
                                        c ? e && u ? this._hasCrossedThreshold(c, p) && this._queuedEntries.push(p) : c && c.isIntersecting && this._queuedEntries.push(p) : this._queuedEntries.push(p)
                                    }), this), this._queuedEntries.length && this._callback(this.takeRecords(), this)
                                }
                            }, a.prototype._computeTargetAndRootIntersection = function(t, i, o) {
                                if ("none" != window.getComputedStyle(t).display) {
                                    for (var a, u, c, l, p, m, v, h, g = i, b = f(t), _ = !1; !_ && b;) {
                                        var y = null,
                                            w = 1 == b.nodeType ? window.getComputedStyle(b) : {};
                                        if ("none" == w.display) return null;
                                        if (b == this.root || 9 == b.nodeType)
                                            if (_ = !0, b == this.root || b == e) n && !this.root ? !r || 0 == r.width && 0 == r.height ? (b = null, y = null, g = null) : y = r : y = o;
                                            else {
                                                var x = f(b),
                                                    E = x && s(x),
                                                    T = x && this._computeTargetAndRootIntersection(x, E, o);
                                                E && T ? (b = x, y = d(E, T)) : (b = null, g = null)
                                            }
                                        else {
                                            var C = b.ownerDocument;
                                            b != C.body && b != C.documentElement && "visible" != w.overflow && (y = s(b))
                                        }
                                        if (y && (a = y, u = g, void 0, void 0, void 0, void 0, void 0, void 0, c = Math.max(a.top, u.top), l = Math.min(a.bottom, u.bottom), p = Math.max(a.left, u.left), h = l - c, g = (v = (m = Math.min(a.right, u.right)) - p) >= 0 && h >= 0 && {
                                                top: c,
                                                bottom: l,
                                                left: p,
                                                right: m,
                                                width: v,
                                                height: h
                                            } || null), !g) break;
                                        b = b && f(b)
                                    }
                                    return g
                                }
                            }, a.prototype._getRootRect = function() {
                                var t;
                                if (this.root && !m(this.root)) t = s(this.root);
                                else {
                                    var n = m(this.root) ? this.root : e,
                                        r = n.documentElement,
                                        i = n.body;
                                    t = {
                                        top: 0,
                                        left: 0,
                                        right: r.clientWidth || i.clientWidth,
                                        width: r.clientWidth || i.clientWidth,
                                        bottom: r.clientHeight || i.clientHeight,
                                        height: r.clientHeight || i.clientHeight
                                    }
                                }
                                return this._expandRectByRootMargin(t)
                            }, a.prototype._expandRectByRootMargin = function(e) {
                                var t = this._rootMarginValues.map((function(t, n) {
                                        return "px" == t.unit ? t.value : t.value * (n % 2 ? e.width : e.height) / 100
                                    })),
                                    n = {
                                        top: e.top - t[0],
                                        right: e.right + t[1],
                                        bottom: e.bottom + t[2],
                                        left: e.left - t[3]
                                    };
                                return n.width = n.right - n.left, n.height = n.bottom - n.top, n
                            }, a.prototype._hasCrossedThreshold = function(e, t) {
                                var n = e && e.isIntersecting ? e.intersectionRatio || 0 : -1,
                                    r = t.isIntersecting ? t.intersectionRatio || 0 : -1;
                                if (n !== r)
                                    for (var i = 0; i < this.thresholds.length; i++) {
                                        var o = this.thresholds[i];
                                        if (o == n || o == r || o < n != o < r) return !0
                                    }
                            }, a.prototype._rootIsInDom = function() {
                                return !this.root || p(e, this.root)
                            }, a.prototype._rootContainsTarget = function(t) {
                                var n = this.root && (this.root.ownerDocument || this.root) || e;
                                return p(n, t) && (!this.root || n == t.ownerDocument)
                            }, a.prototype._registerInstance = function() {
                                t.indexOf(this) < 0 && t.push(this)
                            }, a.prototype._unregisterInstance = function() {
                                var e = t.indexOf(this); - 1 != e && t.splice(e, 1)
                            }, window.IntersectionObserver = a, window.IntersectionObserverEntry = o
                        }
                    function i(e) {
                        try {
                            return e.defaultView && e.defaultView.frameElement || null
                        } catch (e) {
                            return null
                        }
                    }

                    function o(e) {
                        this.time = e.time, this.target = e.target, this.rootBounds = l(e.rootBounds), this.boundingClientRect = l(e.boundingClientRect), this.intersectionRect = l(e.intersectionRect || {
                            top: 0,
                            bottom: 0,
                            left: 0,
                            right: 0,
                            width: 0,
                            height: 0
                        }), this.isIntersecting = !!e.intersectionRect;
                        var t = this.boundingClientRect,
                            n = t.width * t.height,
                            r = this.intersectionRect,
                            i = r.width * r.height;
                        this.intersectionRatio = n ? Number((i / n).toFixed(4)) : this.isIntersecting ? 1 : 0
                    }

                    function a(e, t) {
                        var n, r, i, o = t || {};
                        if ("function" != typeof e) throw new Error("callback must be a function");
                        if (o.root && 1 != o.root.nodeType && 9 != o.root.nodeType) throw new Error("root must be a Document or Element");
                        this._checkForIntersections = (n = this._checkForIntersections.bind(this), r = this.THROTTLE_TIMEOUT, i = null, function() {
                            i || (i = setTimeout((function() {
                                n(), i = null
                            }), r))
                        }), this._callback = e, this._observationTargets = [], this._queuedEntries = [], this._rootMarginValues = this._parseRootMargin(o.rootMargin), this.thresholds = this._initThresholds(o.threshold), this.root = o.root || null, this.rootMargin = this._rootMarginValues.map((function(e) {
                            return e.value + e.unit
                        })).join(" "), this._monitoringDocuments = [], this._monitoringUnsubscribes = []
                    }

                    function u(e, t, n, r) {
                        "function" == typeof e.addEventListener ? e.addEventListener(t, n, r || !1) : "function" == typeof e.attachEvent && e.attachEvent("on" + t, n)
                    }

                    function c(e, t, n, r) {
                        "function" == typeof e.removeEventListener ? e.removeEventListener(t, n, r || !1) : "function" == typeof e.detachEvent && e.detachEvent("on" + t, n)
                    }

                    function s(e) {
                        var t;
                        try {
                            t = e.getBoundingClientRect()
                        } catch (e) {}
                        return t ? (t.width && t.height || (t = {
                            top: t.top,
                            right: t.right,
                            bottom: t.bottom,
                            left: t.left,
                            width: t.right - t.left,
                            height: t.bottom - t.top
                        }), t) : {
                            top: 0,
                            bottom: 0,
                            left: 0,
                            right: 0,
                            width: 0,
                            height: 0
                        }
                    }

                    function l(e) {
                        return !e || "x" in e ? e : {
                            top: e.top,
                            y: e.top,
                            bottom: e.bottom,
                            left: e.left,
                            x: e.left,
                            right: e.right,
                            width: e.width,
                            height: e.height
                        }
                    }

                    function d(e, t) {
                        var n = t.top - e.top,
                            r = t.left - e.left;
                        return {
                            top: n,
                            left: r,
                            height: t.height,
                            width: t.width,
                            bottom: n + t.height,
                            right: r + t.width
                        }
                    }

                    function p(e, t) {
                        for (var n = t; n;) {
                            if (n == e) return !0;
                            n = f(n)
                        }
                        return !1
                    }

                    function f(t) {
                        var n = t.parentNode;
                        return 9 == t.nodeType && t != e ? i(t) : (n && n.assignedSlot && (n = n.assignedSlot.parentNode), n && 11 == n.nodeType && n.host ? n.host : n)
                    }

                    function m(e) {
                        return e && 9 === e.nodeType
                    }
                }()
            },
            780: function(e) {
                "use strict";

                function t(e) {
                    if (!(this instanceof t)) throw new TypeError("Constructor Promise requires `new`");
                    if (!d(e)) throw new TypeError("Must pass resolver function");
                    this._state = o, this._value = [], this._isChainEnd = !0, v(this, c(this, r), c(this, i), {
                        then: e
                    })
                }
                t.prototype.then = function(e, t) {
                    return e = d(e) ? e : void 0, t = d(t) ? t : void 0, (e || t) && (this._isChainEnd = !1), this._state(this._value, e, t)
                }, t.prototype.catch = function(e) {
                    return this.then(void 0, e)
                }, t.resolve = function(e) {
                    return p(e) && e instanceof this ? e : new this((function(t) {
                        t(e)
                    }))
                }, t.reject = function(e) {
                    return new this((function(t, n) {
                        n(e)
                    }))
                }, t.all = function(e) {
                    var t = this;
                    return new t((function(n, r) {
                        var i = e.length,
                            o = new Array(i);
                        if (0 === i) return n(o);
                        ! function(e, t) {
                            for (var n = 0; n < e.length; n++) t(e[n], n)
                        }(e, (function(e, a) {
                            t.resolve(e).then((function(e) {
                                o[a] = e, 0 == --i && n(o)
                            }), r)
                        }))
                    }))
                }, t.race = function(e) {
                    var t = this;
                    return new t((function(n, r) {
                        for (var i = 0; i < e.length; i++) t.resolve(e[i]).then(n, r)
                    }))
                };
                var n = function(e, t) {
                    throw e
                };

                function r(e, t, n, i) {
                    return t ? (i || (i = new a(this.constructor)), m(f(i, t, e)), i.promise) : (s(i, r, e), this)
                }

                function i(e, t, n, r) {
                    return n ? (r || (r = new a(this.constructor)), m(f(r, n, e)), r.promise) : (s(r, i, e), this)
                }

                function o(e, t, n, r) {
                    if (!r) {
                        if (!t && !n) return this;
                        r = new a(this.constructor)
                    }
                    return e.push({
                        deferred: r,
                        onFulfilled: t || r.resolve,
                        onRejected: n || r.reject
                    }), r.promise
                }

                function a(e) {
                    var t = this;
                    return this.promise = new e((function(e, n) {
                        t.resolve = e, t.reject = n
                    })), t
                }

                function u(e, t, r, a) {
                    var u = e._value;
                    e._state = t, e._value = r, a && t === o && a._state(r, void 0, void 0, {
                        promise: e,
                        resolve: void 0,
                        reject: void 0
                    });
                    for (var c = 0; c < u.length; c++) {
                        var s = u[c];
                        e._state(r, s.onFulfilled, s.onRejected, s.deferred)
                    }
                    u.length = 0, a && (a._isChainEnd = !1), t === i && e._isChainEnd && setTimeout((function() {
                        e._isChainEnd && n(r, e)
                    }), 0)
                }

                function c(e, t) {
                    return function(n) {
                        u(e, t, n)
                    }
                }

                function s(e, t, n) {
                    if (e) {
                        var r = e.promise;
                        r._state = t, r._value = n
                    }
                }

                function l() {}

                function d(e) {
                    return "function" == typeof e
                }

                function p(e) {
                    return e === Object(e)
                }

                function f(e, t, n) {
                    var r = e.promise,
                        i = e.resolve,
                        o = e.reject;
                    return function() {
                        try {
                            var e = t(n);
                            v(r, i, o, e, e)
                        } catch (e) {
                            o(e)
                        }
                    }
                }
                t._overrideUnhandledExceptionHandler = function(e) {
                    n = e
                };
                var m = function() {
                    var e;
                    "undefined" != typeof window && window.postMessage ? (window.addEventListener("message", r), e = function() {
                        window.postMessage("macro-task", "*")
                    }) : e = function() {
                        setTimeout(r, 0)
                    };
                    var t = new Array(16),
                        n = 0;

                    function r() {
                        for (var e = 0; e < n; e++) {
                            var r = t[e];
                            t[e] = null, r()
                        }
                        n = 0
                    }
                    return function(r) {
                        0 === n && e(), t[n++] = r
                    }
                }();

                function v(e, t, n, r, i) {
                    var o, a, c = n;
                    try {
                        if (r === e) throw new TypeError("Cannot fulfill promise with itself");
                        var s = p(r);
                        s && r instanceof e.constructor ? u(e, r._state, r._value, r) : s && (o = r.then) && d(o) ? (a = function(r) {
                            a = c = l, v(e, t, n, r, r)
                        }, c = function(e) {
                            a = c = l, n(e)
                        }, o.call(i, (function(e) {
                            a(e)
                        }), (function(e) {
                            c(e)
                        }))) : t(r)
                    } catch (e) {
                        c(e)
                    }
                }
                e.exports = t
            },
            1178: function(e, t, n) {
                "use strict";
                n.d(t, {
                    L: function() {
                        return o
                    },
                    s: function() {
                        return i
                    }
                });
                var r = n(9839);

                function i(e, t) {
                    return e === t || e.modeName === t.modeName
                }

                function o(e) {
                    var t, n = r.L5.optionsSummary.placements;
                    if (2 === (null === (t = e.parent) || void 0 === t ? void 0 : t.entityType)) {
                        var o = e.parent.fpl;
                        return n.filter((function(e) {
                            return e.placementName === o
                        }))[0]
                    }
                    var a = e.mode;
                    return a ? n.filter((function(e) {
                        return i(e, a)
                    }))[0] : null
                }
            },
            3229: function(e, t, n) {
                "use strict";
                n.d(t, {
                    F0: function() {
                        return l
                    },
                    Qh: function() {
                        return s
                    },
                    R9: function() {
                        return d
                    }
                });
                var r = n(3887),
                    i = n(8404),
                    o = n(4555),
                    a = n(5949);

                function u(e) {
                    return e instanceof Array ? e.filter(u).length > 0 : !!e.mode && "amp" === e.framework
                }
                var c = 0;

                function s() {
                    var e;
                    if (0 !== c) return 2 === c;
                    var t = u((0, a.cV)());
                    return t || (t = o.mb.location.host.indexOf(".ampproject.net") > -1 && !!(null === (e = o.tp.context) || void 0 === e ? void 0 : e.canonicalUrl)) ? (c = 2, !0) : (c = 1, t)
                }

                function l() {
                    var e, t, n = null === (t = null === (e = o.tp.context) || void 0 === e ? void 0 : e.data) || void 0 === t ? void 0 : t.feedContainerNum;
                    return {
                        isSplitFeed: !!n,
                        feedContainerNum: n ? parseInt(n) : 0
                    }
                }

                function d() {
                    return new i.e((function(e) {
                        var t = (0, r.Cd)("max-wait-for-cmp"),
                            n = {
                                gdpr: {
                                    cmpStatus: 5
                                }
                            };
                        if (t > 0 && window.setTimeout((function() {
                                n.gdpr.wasTimeout = !0, e(n)
                            }), t), o.tp.context) {
                            var i = o.tp.context.initialConsentValue;
                            if (i) return function(e, t) {
                                /\d[YN-]{3}$/.test(e) ? (t.ccpa = {
                                    privacyString: e
                                }, t.gdpr.gdprApplies = !1, t.gdpr.tcString = void 0) : (t.ccpa = {
                                    privacyString: e
                                }, t.gdpr.gdprApplies = !0)
                            }(i, n), void e(n);
                            if (o.tp.context.getConsentState) return o.tp.context.getConsentState((function(t) {
                                1 === t.consentState ? n.gdpr.cex = "true" : 2 === t.consentState && (n.gdpr.cex = "false"), e(n)
                            }));
                            e(n)
                        } else e(n)
                    }))
                }
            },
            1688: function(e, t, n) {
                "use strict";
                n.d(t, {
                    u: function() {
                        return u
                    },
                    H: function() {
                        return a
                    }
                });
                var r, i = n(7582),
                    o = n(2271);

                function a(e) {
                    if (!r) {
                        var t, n, a, u, c, s, l = (r = e).global || {};
                        l = (0, i.pi)((0, i.pi)({}, l), (t = l, n = "gr__", a = new RegExp("^".concat(n)), u = Object.keys(t).filter((function(e) {
                            return a.test(e)
                        })), c = [], s = {}, u.forEach((function(e) {
                            var r = e.split(n)[1],
                                i = t[e];
                            if (i && (0, o.lp)(i)) {
                                var a = !(0, o.r8)(i.v);
                                a && (0, o.l7)(i.p) ? 100 * Math.random() <= i.p && (s[r] = i.v) : a && (0, o.cb)(i.d) && t[n + i.d] && (i.dependOn = i.d, i.key = r, c.push(i))
                            }
                        })), c.forEach((function(e) {
                            e.d in s && (s[e.key] = e.v)
                        })), s)), r.global = l
                    }
                }

                function u() {
                    return r
                }
            },
            3150: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Is: function() {
                        return i
                    },
                    YB: function() {
                        return c
                    },
                    Yi: function() {
                        return p
                    },
                    _v: function() {
                        return o
                    },
                    fs: function() {
                        return u
                    },
                    mv: function() {
                        return f
                    },
                    ne: function() {
                        return d
                    },
                    vn: function() {
                        return a
                    },
                    yt: function() {
                        return s
                    }
                });
                var r = n(7582),
                    i = -1,
                    o = "__common__";

                function a(e) {
                    return e.instances.filter((function(e) {
                        var t = e.status,
                            n = e.batchIndex;
                        return 0 === t && n === i
                    })).length > 0
                }

                function u(e) {
                    return e.map((function(e) {
                        return (0, r.pi)((0, r.pi)({}, e), {
                            status: 2
                        })
                    }))
                }

                function c(e, t) {
                    var n = !1;
                    return e.map((function(e) {
                        return 0 !== e.status || n ? e : (n = !0, (0, r.pi)((0, r.pi)({}, e), {
                            status: 1,
                            batchIndex: t
                        }))
                    }))
                }

                function s(e) {
                    return {
                        containerId: e,
                        status: 0,
                        isParsed: !1,
                        batchIndex: i
                    }
                }

                function l(e) {
                    return 2 === e.status || 3 === e.status
                }

                function d(e) {
                    var t = !1;
                    return e.map((function(e) {
                        return e.isParsed || t || l(e) ? e : (t = !0, (0, r.pi)((0, r.pi)({}, e), {
                            isParsed: !0
                        }))
                    }))
                }

                function p(e) {
                    for (var t = e.instances, n = 0, r = t; n < r.length; n++) {
                        var i = r[n];
                        if (!i.isParsed && !l(i)) return i.containerId
                    }
                    return t[t.length - 1].containerId
                }

                function f(e, t) {
                    return t.filter((function(t) {
                        return t.placementName === e.placementName
                    }))[0]
                }
            },
            878: function(e, t, n) {
                "use strict";
                n.d(t, {
                    EU: function() {
                        return u
                    },
                    Ll: function() {
                        return l
                    },
                    Q6: function() {
                        return d
                    },
                    jS: function() {
                        return c
                    }
                });
                var r = n(3887),
                    i = n(6972),
                    o = n(3265),
                    a = n(3150),
                    u = "rbox-tracking";

                function c(e, t) {
                    0 !== t.length && (s(e.modeName) ? e.instances = (0, a.fs)(e.instances) : t.forEach((function(t) {
                        s(t.modeName) && (t.instances = (0, a.fs)(e.instances))
                    })))
                }

                function s(e) {
                    return e === u
                }

                function l(e) {
                    if ((0, r.Mv)("enable-always-track")) {
                        var t = u,
                            n = "".concat(t, "-div");
                        if (!document.getElementById(n)) {
                            var a = (0, o.U)("div", {
                                attrList: [
                                    ["id", n]
                                ]
                            });
                            a.style.display = "none", document.body.appendChild(a), (0, i.aR)({
                                placement: t,
                                mode: t,
                                container: n
                            }, e)
                        }
                    }
                }

                function d(e) {
                    return e.modeName
                }
            },
            5949: function(e, t, n) {
                "use strict";
                n.d(t, {
                    KP: function() {
                        return a
                    },
                    cV: function() {
                        return o
                    },
                    fR: function() {
                        return i
                    }
                });
                var r = n(4555),
                    i = "_taboola";

                function o() {
                    return a(), r.mb[i]
                }

                function a() {
                    r.mb[i] || (r.mb[i] = [])
                }
            },
            6972: function(e, t, n) {
                "use strict";
                n.d(t, {
                    aR: function() {
                        return L
                    },
                    hw: function() {
                        return S
                    },
                    qn: function() {
                        return f
                    },
                    AF: function() {
                        return R
                    },
                    Cu: function() {
                        return k
                    },
                    oy: function() {
                        return N
                    },
                    in: function() {
                        return h
                    },
                    M1: function() {
                        return b
                    },
                    yM: function() {
                        return I
                    },
                    ur: function() {
                        return y
                    },
                    Iu: function() {
                        return w
                    },
                    $q: function() {
                        return x
                    },
                    H: function() {
                        return C
                    }
                });
                var r = n(7582),
                    i = n(1553),
                    o = n(8312),
                    a = n(9839),
                    u = n(2271),
                    c = n(1591),
                    s = n(1178),
                    l = n(3150),
                    d = n(878),
                    p = n(1602);

                function f() {
                    return {
                        events: [],
                        socials: [],
                        placements: [],
                        isFlush: !1,
                        userOptOut: !1,
                        itemSourceType: "_default_",
                        itemSourceValue: "",
                        trackingCodes: {},
                        __preProcessedOptions__: [],
                        __overrideGlobal__: {}
                    }
                }

                function m(e) {
                    return JSON.stringify(e, (function(e, t) {
                        return "__preProcessedOptions__" === e || "__overrideGlobal__" === e ? "" : t
                    }))
                }
                var v = m({
                    events: [],
                    socials: [],
                    placements: [],
                    isFlush: !1,
                    userOptOut: !1,
                    itemSourceType: "_default_",
                    itemSourceValue: "",
                    trackingCodes: {},
                    __preProcessedOptions__: [],
                    __overrideGlobal__: {}
                });

                function h(e) {
                    return m(e) === v
                }

                function g(e, t) {
                    var n = [],
                        i = [];
                    return e.forEach((function(e) {
                        var o = (0, l.mv)(e, t);
                        o ? (i.push(e.placementName), n.push((0, r.pi)((0, r.pi)({}, e), {
                            instances: (0, r.ev)((0, r.ev)([], e.instances, !0), o.instances, !0)
                        }))) : n.push(e)
                    })), t.forEach((function(e) {
                        i.indexOf(e.placementName) > -1 || n.push(e)
                    })), n
                }

                function b(e, t) {
                    var n = !(0, u.r8)(t.itemSourceType) && "_default_" !== t.itemSourceType,
                        i = e.placements || [],
                        o = t.placements || [];
                    return {
                        publisherName: t.publisherName || e.publisherName,
                        gdpr: t.gdpr ? (0, r.pi)((0, r.pi)({}, e.gdpr || {}), t.gdpr) : e.gdpr,
                        ccpa: t.ccpa ? (0, r.pi)((0, r.pi)({}, e.ccpa || {}), t.ccpa) : e.ccpa,
                        realTimeUserId: t.realTimeUserId || e.realTimeUserId || void 0,
                        placements: g(i, o),
                        additionalData: t.additionalData || e.additionalData,
                        deviceId: t.deviceId || e.deviceId,
                        unifiedId: t.unifiedId || e.unifiedId,
                        framework: t.framework || e.framework,
                        events: (0, r.ev)((0, r.ev)([], e.events, !0), t.events || [], !0),
                        socials: (0, r.ev)((0, r.ev)([], e.socials, !0), t.socials || [], !0),
                        itemSourceType: n ? t.itemSourceType : e.itemSourceType,
                        itemSourceValue: n ? t.itemSourceValue : e.itemSourceValue,
                        userOptOut: (0, u.r8)(t.userOptOut) ? e.userOptOut : t.userOptOut,
                        pageUrl: t.pageUrl || e.pageUrl || void 0,
                        networkMapUrl: t.networkMapUrl || e.networkMapUrl || void 0,
                        isFlush: (0, u.r8)(t.isFlush) ? e.isFlush : t.isFlush,
                        excludePubs: (0, u.r8)(t.excludePubs) ? e.excludePubs : t.excludePubs,
                        trackingCodes: (0, r.pi)((0, r.pi)({}, e.trackingCodes), t.trackingCodes || {}) || {},
                        cex: (0, u.r8)(t.cex) ? e.cex : t.cex,
                        customSegment: t.customSegment || e.customSegment,
                        scod: t.scod ? (0, r.pi)((0, r.pi)({}, e.scod || {}), t.scod) : e.scod,
                        referrerUrl: t.referrerUrl || e.referrerUrl,
                        __preProcessedOptions__: (0, r.ev)((0, r.ev)([], t.__preProcessedOptions__ || [], !0), e.__preProcessedOptions__, !0),
                        __overrideGlobal__: (0, r.pi)((0, r.pi)({}, e.__overrideGlobal__), t.__overrideGlobal__),
                        pageTemplate: t.pageTemplate || e.pageTemplate,
                        advertorialSource: t.advertorialSource || e.advertorialSource,
                        externalPageView: t.externalPageView || e.externalPageView,
                        userType: t.userType || e.userType,
                        premium: (0, u.r8)(t.premium) ? e.premium : t.premium,
                        paywall: (0, u.r8)(t.paywall) ? e.paywall : t.paywall,
                        tracking: t.tracking || e.tracking,
                        linkTarget: t.linkTarget || e.linkTarget,
                        excludedRecs: (0, r.ev)((0, r.ev)([], t.excludedRecs || [], !0), e.excludedRecs || [], !0),
                        pubExperiment: e.pubExperiment || t.pubExperiment
                    }
                }
                var _ = l.Is;

                function y(e, t) {
                    return (0, r.pi)((0, r.pi)({}, e), {
                        placements: e.placements.map((function(e) {
                            return t.indexOf(e.placementName) > -1 ? (0, r.pi)((0, r.pi)({}, e), {
                                instances: (0, l.ne)(e.instances)
                            }) : e
                        }))
                    })
                }

                function w(e, t) {
                    return _++, (0, r.pi)((0, r.pi)({}, e), {
                        placements: e.placements.map((function(e) {
                            var n = t.filter((function(t) {
                                    return n = t, r = e, (0, s.s)(n, r) && n.placementName === r.placementName;
                                    var n, r
                                })).length > 0 && (0, l.vn)(e),
                                i = e.instances;
                            return n && (i = (0, l.YB)(i, _)), (0, r.pi)((0, r.pi)({}, e), {
                                instances: i
                            })
                        }))
                    })
                }

                function x(e, t) {
                    var n = {},
                        i = t.placements;
                    return t.placements = [], i.forEach((function(i) {
                        var o = i.placementName,
                            a = i.instances[0];
                        (0, p.LO)(a, "new placement pushed should have one instance exactly");
                        var u = (0, l.mv)(i, e);
                        u && E(a, u) && T(o, a);
                        var c = n[o];
                        if (!c) return t.placements.push(i), void(n[o] = i);
                        3 !== a.status && E(a, c) && T(o, a), c.instances = (0, r.ev)((0, r.ev)([], c.instances, !0), [a], !1)
                    })), t
                }

                function E(e, t) {
                    return t.instances.some((function(t) {
                        return t.containerId === e.containerId
                    }))
                }

                function T(e, t) {
                    (0, i.yN)("Placement duplication found: ".concat(JSON.stringify(e), ", ").concat(t.containerId)), t.status = 3
                }

                function C(e, t) {
                    return t.placements.forEach((function(t) {
                        (0, d.jS)(t, e)
                    })), t
                }

                function S(e) {
                    return b(e, {})
                }

                function R(e) {
                    return (null == e ? void 0 : e.placements.filter((function(e) {
                        return (0, l.vn)(e)
                    }))) || []
                }

                function k(e) {
                    var t;
                    return ((null === (t = R(e)) || void 0 === t ? void 0 : t.length) || 0) > 0
                }

                function I(e) {
                    if ((0, u.h0)(e)) {
                        var t;
                        e.forEach(I);
                        var n = "%tt%",
                            r = [],
                            i = function(e) {
                                var i;
                                (e.placement || e.mode || e.target_type) && (e.mode ? (e.placement || (e.placement = e.mode), e.target_type || (e.target_type = n), i = e) : e.target_type && (t = e.target_type, delete e.target_type), (null == i ? void 0 : i.target_type) === n && r.push(i))
                            };
                        e.forEach((function(e) {
                            if ((0, u.h0)(e)) return e.forEach(i), void(0, c.sU)(e);
                            i(e)
                        })), r.forEach((function(e) {
                            t ? e.target_type = t : delete e.target_type
                        })), (0, c.sU)(e)
                    }
                }

                function L(e, t) {
                    if (e.container && e.mode) {
                        var n, r, u = a.L5.config.publisher.modes[e.mode],
                            s = (null == u ? void 0 : u["visibility-constraints"]) || {},
                            d = s.minWidth,
                            p = s.maxWidth;
                        ! function(e, t) {
                            if (e = e || Number.NEGATIVE_INFINITY, t = t || Number.POSITIVE_INFINITY, e === Number.NEGATIVE_INFINITY && t === Number.POSITIVE_INFINITY) return !0;
                            var n = window.innerWidth;
                            return !(n < e) && !(n > t)
                        }(d, p) ? (0, i.o7)("page", "info", "Mode '".concat(e.mode, "' will not be displayed due to visibility constraints minWidth: ").concat(d, ", maxWidth: ").concat(p)) : t.placements.push({
                            rboxResponsesIndex: 0,
                            modeName: (0, c.Jg)(e.mode),
                            instances: [(0, l.yt)(M(e.container))],
                            placementName: e.placement,
                            targetType: (n = e.target_type, r = "video", n ? o.W[n] ? n : ((0, i.yN)('Target Type has no valid value, got value "'.concat(n, '".')), r) : r),
                            category: e.category,
                            dfp: e.dfp,
                            exclude: O(e.exclude),
                            tracking: e.tracking,
                            linkTarget: e.link_target,
                            frameId: e.frameId,
                            priority: e.priority,
                            groupName: e.groupName,
                            constraint: e.constraint,
                            byPublisher: !0
                        })
                    }
                }

                function O(e) {
                    if (e) {
                        if ((0, u.cb)(e)) return [e];
                        if ((0, u.h0)(e)) return e.filter((function(e) {
                            return !!e
                        }))
                    }
                }

                function M(e) {
                    if ((0, u.cb)(e)) return e;
                    if (e.id) return e.id;
                    var t = (0, c.D1)({
                        prefix: "trc_cont_"
                    });
                    return e.id = t, t
                }

                function N(e) {
                    return "newPageLoad" === e.notify
                }
            },
            8261: function(e, t, n) {
                "use strict";
                n.d(t, {
                    G$: function() {
                        return m
                    },
                    HF: function() {
                        return l
                    },
                    Th: function() {
                        return h
                    },
                    Tt: function() {
                        return d
                    },
                    fM: function() {
                        return b
                    }
                });
                var r = n(7582),
                    i = n(2057),
                    o = n(2271),
                    a = n(1553),
                    u = n(8404),
                    c = n(5962),
                    s = {},
                    l = !1;

                function d(e) {
                    for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                    var a = s[e];
                    switch (e) {
                        case "e2":
                        case "e1":
                            var d = function(e) {
                                var t;
                                return null === (t = s[e]) || void 0 === t ? void 0 : t.map((function(t) {
                                    var n;
                                    try {
                                        return (null === (n = t[e]) || void 0 === n ? void 0 : n.call(t)) || []
                                    } catch (n) {
                                        p(t, e, n)
                                    }
                                    return []
                                })).reduce((function(e, t) {
                                    return e.concat(t)
                                }), [])
                            }(e);
                            return d;
                        case "e3":
                            null == a || a.forEach((function(t) {
                                var n;
                                try {
                                    var r = null === (n = t[e]) || void 0 === n ? void 0 : n.call(t);
                                    r && (0, c.J)(r)
                                } catch (n) {
                                    p(t, e, n)
                                }
                            }));
                            break;
                        case "e4":
                            null == a || a.forEach((function(t) {
                                var n;
                                try {
                                    null === (n = t[e]) || void 0 === n || n.call(t)
                                } catch (n) {
                                    p(t, e, n)
                                }
                            }));
                            break;
                        case "e5":
                            null == a || a.forEach((function(t) {
                                var n;
                                try {
                                    null === (n = t[e]) || void 0 === n || n.call(t)
                                } catch (n) {
                                    p(t, e, n)
                                }
                            }));
                            break;
                        case "e6":
                            l = !0, null == a || a.forEach((function(n) {
                                var r;
                                try {
                                    null === (r = n[e]) || void 0 === r || r.apply(n, t)
                                } catch (t) {
                                    p(n, e, t)
                                }
                            }));
                            break;
                        case "e7":
                            var f = t[0];
                            return null == a || a.forEach((function(t) {
                                var n;
                                try {
                                    f = (null === (n = t[e]) || void 0 === n ? void 0 : n.call(t, f)) || f
                                } catch (n) {
                                    p(t, e, n)
                                }
                            })), f;
                        case "e8":
                            return function() {
                                var e, t, n = s.e8;
                                if (null == n ? void 0 : n.length) {
                                    for (var r = void 0, i = 0, a = n; i < a.length; i++) {
                                        var u = a[i];
                                        if (!0 !== (r = null !== (t = null === (e = u.e8) || void 0 === e ? void 0 : e.call(u)) && void 0 !== t ? t : r) && !(0, o.r8)(r)) return r
                                    }
                                    return r
                                }
                            }();
                        case "e9":
                            var m = function(e) {
                                var t, n = "e9",
                                    r = e,
                                    o = void 0,
                                    a = [];
                                null === (t = s[n]) || void 0 === t || t.forEach((function(e) {
                                    var t;
                                    try {
                                        var u = null === (t = e[n]) || void 0 === t ? void 0 : t.call(e, r);
                                        if (!u) return;
                                        r = u.payload, u.response && (o = (0, i.$)(o || {}, u.response)), u.responsePromise && a.push(u.responsePromise)
                                    } catch (t) {
                                        p(e, n, t)
                                    }
                                }));
                                var c = void 0;
                                if (a.length > 0 && (c = u.e.allSettled(a).then((function(e) {
                                        return e.filter((function(e) {
                                            return "fulfilled" === e.status
                                        })).map((function(e) {
                                            return e.value
                                        })).reduce((function(e, t) {
                                            return (0, i.$)(e, t)
                                        }), {})
                                    }))), e !== r || o || c) return {
                                    payload: r,
                                    response: o,
                                    responsePromise: c
                                }
                            }(t[0]);
                            return m;
                        case "e10":
                        case "e11":
                            var v = t[0];
                            return v = function(e, t) {
                                var n;
                                return null === (n = s[e]) || void 0 === n || n.forEach((function(n) {
                                    var r;
                                    try {
                                        t = (null === (r = n[e]) || void 0 === r ? void 0 : r.call(n, t)) || t
                                    } catch (t) {
                                        p(n, e, t)
                                    }
                                })), t
                            }(e, v), v;
                        case "e12":
                            var h = t[0],
                                g = void 0;
                            return null == a || a.forEach((function(t) {
                                var n;
                                try {
                                    !1 !== g && (g = null === (n = t[e]) || void 0 === n ? void 0 : n.call(t, h))
                                } catch (n) {
                                    p(t, e, n)
                                }
                            })), !1 !== g;
                        case "e13":
                            var b = t[0],
                                _ = b;
                            if (null == a || a.forEach((function(t) {
                                    var n;
                                    try {
                                        _ = (null === (n = t[e]) || void 0 === n ? void 0 : n.call(t, _)) || _
                                    } catch (n) {
                                        p(t, e, n)
                                    }
                                })), b !== _) return _;
                            break;
                        case "e14":
                            var y = t[0],
                                w = void 0;
                            return null == a || a.forEach((function(t) {
                                var n;
                                try {
                                    w || (w = null === (n = t[e]) || void 0 === n ? void 0 : n.call(t, y))
                                } catch (n) {
                                    p(t, e, n)
                                }
                            })), w;
                        case "e15":
                        case "e17":
                        case "e18":
                        case "e19":
                        case "e20":
                        case "e21":
                            var x = t[0];
                            null == a || a.forEach((function(t) {
                                var n;
                                try {
                                    null === (n = t[e]) || void 0 === n || n.call(t, x)
                                } catch (n) {
                                    p(t, e, n)
                                }
                            }));
                            break;
                        case "e16":
                            var E = t[0],
                                T = void 0;
                            return null == a || a.forEach((function(t) {
                                var n;
                                try {
                                    !1 !== T && (T = null === (n = t[e]) || void 0 === n ? void 0 : n.call(t, E))
                                } catch (n) {
                                    p(t, e, n)
                                }
                            })), T;
                        case "e22":
                            null == a || a.forEach((function(t) {
                                var n;
                                try {
                                    null === (n = t[e]) || void 0 === n || n.call(t)
                                } catch (n) {
                                    p(t, e, n)
                                }
                            }));
                            break;
                        case "e23":
                            var C = t,
                                S = function(e, t) {
                                    var n, i = "e23",
                                        o = {
                                            payload: {}
                                        };
                                    return null === (n = s[i]) || void 0 === n || n.forEach((function(n) {
                                        var a, u;
                                        try {
                                            var c = null === (a = n[i]) || void 0 === a ? void 0 : a.call(n, e, t);
                                            if (!c) return;
                                            if (!c.payload || !o) return void(o = null);
                                            c.payload.url && (o.payload.url = (0, r.pi)((0, r.pi)({}, o.payload.url || {}), c.payload.url)), c.payload.body && (o.payload.body = (0, r.pi)((0, r.pi)({}, o.payload.body || {}), c.payload.body)), (u = o.payload).domain || (u.domain = c.payload.domain)
                                        } catch (e) {
                                            p(n, i, e)
                                        }
                                    })), o || {}
                                }(C[0], C[1]);
                            return S
                    }
                }

                function p(e, t, n) {
                    (0, a.H)('Extension "'.concat(e.getName(), '" had error on action "').concat(t, '":'), n)
                }
                var f = ["e1", "e2", "e3", "e4", "e5", "e6", "e7", "e8", "e9", "e10", "e11", "e12", "e13", "e14", "e15", "e16", "e17", "e18", "e19", "e20", "e21", "e22", "e23"];

                function m(e) {
                    f.forEach((function(t) {
                        if (e[t]) {
                            s[t] || (s[t] = []), s[t].push(e);
                            var n = function(e) {
                                    var t = [],
                                        n = [],
                                        r = e.map((function(e) {
                                            var r = v(e);
                                            return 1 === r ? t.push(e) : 2 === r && n.push(e), e
                                        })).filter((function(e) {
                                            return v(e) >= 10
                                        })).sort((function(e, t) {
                                            var n = v(e),
                                                r = v(t);
                                            return n > r ? 1 : n < r ? -1 : 0
                                        }));
                                    return {
                                        wrapperExtensions: t,
                                        wrapperEachExtensions: n,
                                        nonWrapperExtensionList: r
                                    }
                                }(s[t]),
                                r = n.wrapperExtensions,
                                i = n.wrapperEachExtensions,
                                o = n.nonWrapperExtensionList;
                            s[t] = function(e, t, n) {
                                var r = n.length;
                                if (0 === r) return e;
                                var i = [];
                                return n.forEach((function(n, o) {
                                    0 === o && (i = i.concat(e)), i = (i = i.concat(t)).concat(n), o === r - 1 && (i = (i = i.concat(t)).concat(e))
                                })), i
                            }(r, i, o)
                        }
                    }))
                }

                function v(e) {
                    var t;
                    return (null === (t = e.getRunOrder) || void 0 === t ? void 0 : t.call(e)) || 11
                }

                function h(e) {
                    return !!s[e]
                }
                var g = null;

                function b(e, t) {
                    if (null === g && (g = h("e23")), !g) return t;
                    var n = d("e23", e, t);
                    if (!n) return t;
                    var i = n.payload;
                    return i ? {
                        url: (0, r.pi)((0, r.pi)({}, t.url), i.url || {}),
                        body: (0, r.pi)((0, r.pi)({}, t.body || {}), i.body || {}),
                        domain: i.domain
                    } : void 0
                }
            },
            5962: function(e, t, n) {
                "use strict";
                n.d(t, {
                    J: function() {
                        return _
                    },
                    N: function() {
                        return y
                    }
                });
                var r = n(7582),
                    i = n(6736),
                    o = n(5187),
                    a = n(7983),
                    u = n(9839),
                    c = n(3887),
                    s = n(5281),
                    l = n(1553),
                    d = n(7529),
                    p = n(2939),
                    f = n(3239),
                    m = n(1312),
                    v = n(4583),
                    h = n(7329),
                    g = n(8261),
                    b = {};

                function _(e) {
                    b = (0, r.pi)((0, r.pi)({}, b), e)
                }

                function y() {
                    var e;
                    return (e = {}).bdetect = b.bdetect || v.c, e.recoLoadNext = b.recoLoadNext || o.k, e.log = b.log || {
                        debug: l.o7,
                        info: l.PN,
                        warn: l.yN,
                        error: l.H
                    }, e.extEvent = b.extEvent || f.F, e.callExtensionAction = b.callExtensionAction || g.Tt, e.eventBus = b.eventBus || s.Y, e.srg = b.srg || {
                        read: m.Qf,
                        write: m.RY,
                        writeNonPrivate: m.Lh,
                        remove: m.KR
                    }, e.isbm = b.isbm || a.q, e.TABOOLA_STORE = b.TABOOLA_STORE || {
                        access: u.L5,
                        update: u.Un,
                        getGlobalBool: c.Mv,
                        getGlobalItem: c.Cd,
                        getModeClientProperty: c.tt
                    }, e.PERFORMANCE = b.PERFORMANCE || {
                        sendReport: i.vH,
                        startMeasurement: d.Xq,
                        getAllEntries: d.$q,
                        isEnabled: p.iH
                    }, e["rtb-win-pixel"] = b["rtb-win-pixel"] || i.pS, e["pubs-generic"] = b["pubs-generic"] || i.E6, e["get-engine-version"] = b["get-engine-version"] || h.X, e
                }
            },
            3595: function(e, t, n) {
                "use strict";
                n.d(t, {
                    bv: function() {
                        return s
                    },
                    lY: function() {
                        return f
                    },
                    rR: function() {
                        return d
                    },
                    xh: function() {
                        return l
                    }
                });
                var r = n(3887),
                    i = n(1553),
                    o = n(6265),
                    a = n(8404),
                    u = n(4583),
                    c = n(5217);

                function s(e, t) {
                    return void 0 === t && (t = {}), new a.e((function(n, r) {
                        var i = new XMLHttpRequest;
                        i.open(t.method || "POST", e, !0), "_" !== t.contentType && i.setRequestHeader("Content-Type", t.contentType || "text/plain"), i.withCredentials = !0, i.addEventListener("readystatechange", (function() {
                            4 === i.readyState && (i.status >= 200 && i.status < 300 ? n(i.responseText) : r({
                                reason: "statusCode",
                                data: i.status
                            }))
                        })), i.addEventListener("error", (function() {
                            r({
                                reason: "networkFailed"
                            })
                        })), i.addEventListener("timeout", (function() {
                            r({
                                reason: "networkTimeout"
                            })
                        })), i.send(t.body || "")
                    }))
                }

                function l(e, t) {
                    return void 0 === t && (t = {}), (0, r.Mv)("send-event-as-post") ? f(e, "application/x-www-form-urlencoded", t) : d(e)
                }

                function d(e) {
                    return s("".concat(e.url).concat(e.body ? (0, c.GO)(e.url) + e.body : ""), {
                        method: "GET",
                        contentType: "_"
                    })
                }

                function p(e, t) {
                    return t ? (0, o.s)(e) : new a.e((function() {
                        return e()
                    }))
                }

                function f(e, t, n) {
                    var o, c;
                    if (void 0 === t && (t = "text/plain"), void 0 === n && (n = {
                            sendByBeacon: !0,
                            useFader: !0
                        }), !(0, r.Mv)("send-event-as-post")) return a.e.reject("Can't report post");
                    var l = a.e.resolve(!1),
                        d = null === (o = n.useFader) || void 0 === o || o,
                        f = null === (c = n.sendByBeacon) || void 0 === c || c;
                    return null === m && (m = (0, r.Mv)("send-event-as-post") && (0, r.Mv)("send-event-by-beacon") && (0, u.c)("send-beacon")), m && f && (l = p((function() {
                        try {
                            var n = e.body || "";
                            return "_" !== t && (n = new Blob([e.body || ""], {
                                type: t
                            })), navigator.sendBeacon(e.url, n), !0
                        } catch (e) {
                            m = !1, (0, i.yN)("sendBeacon is not supported using custom ContentType.")
                        }
                        return !1
                    }), d)), l.then((function(n) {
                        return n ? "" : p((function() {
                            return s(e.url, {
                                body: e.body,
                                contentType: t
                            })
                        }), d).then((function(e) {
                            return e
                        }))
                    }))
                }
                var m = null
            },
            8951: function(e, t, n) {
                "use strict";
                n.d(t, {
                    _: function() {
                        return h
                    }
                });
                var r = n(7582),
                    i = n(9839),
                    o = n(1602),
                    a = n(8404),
                    u = n(5346),
                    c = n(3595),
                    s = n(5217),
                    l = n(7341),
                    d = n(3887),
                    p = n(983),
                    f = {},
                    m = null,
                    v = null;

                function h(e, t, n) {
                    var i = g(e);
                    f[e] = i, t && i.events.push({
                        type: t.type,
                        timestamp: (0, p.X)(),
                        data: t.body
                    });
                    var h = null != n ? n : (0, d.Cd)("bulk-events-delay");
                    return window.setTimeout((function() {
                        ! function(e) {
                            var t, n;
                            (0, o.LO)(v, "resolveReport is empty"), (0, o.LO)(f, "bulkContent is empty");
                            var i = (0, l.CA)(e),
                                a = g(e);
                            if (!i || 0 === a.events.length) return f[e] = void 0, void v("");
                            i.url = (0, s.mq)(i.url, ((t = {}).bulkSize = a.events.length, t)), i.body = (0, u.G6)((0, r.pi)((0, r.pi)({}, a), ((n = {}).events = JSON.stringify(a.events), n))), (0, c.lY)(i, "application/x-www-form-urlencoded"), f[e] = void 0, v("")
                        }(e)
                    }), h), m || (m = new a.e((function(e) {
                        v = e
                    }))), m
                }

                function g(e) {
                    var t;
                    return f && f[e] ? f[e] : ((t = {}).sd = i.L5.userData.sessionData, t.ui = i.L5.userData.userId, t.events = [], t)
                }
            },
            7341: function(e, t, n) {
                "use strict";
                n.d(t, {
                    ec: function() {
                        return V
                    },
                    ee: function() {
                        return D
                    },
                    CA: function() {
                        return A
                    },
                    tW: function() {
                        return P
                    },
                    Q5: function() {
                        return q
                    },
                    Pl: function() {
                        return B
                    },
                    g5: function() {
                        return F
                    },
                    qv: function() {
                        return H
                    },
                    NY: function() {
                        return G
                    },
                    ED: function() {
                        return z
                    },
                    Q1: function() {
                        return W
                    },
                    cF: function() {
                        return j
                    },
                    wo: function() {
                        return Y
                    },
                    YE: function() {
                        return U
                    }
                });
                var r, i = n(7582),
                    o = n(1178),
                    a = n(8261),
                    u = n(9839),
                    c = n(3887),
                    s = n(1602),
                    l = n(983),
                    d = n(1553),
                    p = n(4555),
                    f = n(1591),
                    m = n(7329),
                    v = n(4400),
                    h = n(253),
                    g = n(7900),
                    b = n(7072),
                    _ = n(5346),
                    y = n(5217),
                    w = ["tvi2", "tvi6", "tvi48", "tvi50"],
                    x = n(7969),
                    E = ((r = {}).available = {
                        url: (0, i.ev)((0, i.ev)(["route", "lti"], w, !0), ["cv"], !1),
                        body: ["ri", "sd", "ui", "pi", "wi", "pt", "vi", "li", "lt", "ppb", "cpb", "tim", "id", "llvl", "cv", "fil", "utm"]
                    }, r.metrics = {
                        url: ["route", "lti"],
                        body: ["ri", "sd", "ui", "pi", "wi", "pt", "vi", "dimensions", "tim", "id", "llvl", "cv"]
                    }, r.SupplyFeature = {
                        url: ["lti", "ri", "sd", "ui", "pi", "wi", "pt", "vi", "tim", "id", "llvl", "cv"]
                    }, r.bulk = {
                        url: (0, i.ev)((0, i.ev)(["route", "lti"], w, !0), ["cv"], !1)
                    }, r["bulk-metrics"] = {
                        url: (0, i.ev)((0, i.ev)(["route", "lti"], w, !0), ["cv"], !1)
                    }, r.visible = {
                        url: (0, i.ev)((0, i.ev)(["route", "lti"], w, !0), ["cv"], !1),
                        body: ["ri", "sd", "ui", "pi", "wi", "pt", "vi", "li", "lt", "il", "ilt", "sil", "silt", "siltp", "navil", "navilt", "naviltp", "ntil", "ntilt", "niltp", "tp", "spatialData", "ppb", "cpb", "tim", "fil", "vl", "fve", "id", "llvl", "cv", "bad", "sw", "sh", "bw", "bh", "dw", "dh", "sde", "cd", "mw"]
                    }, r.click = {
                        url: (0, i.ev)((0, i.ev)(["pi", "ri", "sd", "ui", "ii", "it", "pt", "li", "sig", "vi", "p", "lti", "r"], w, !0), ["ppb", "cpb", "cv", "prt", "route", "pc"], !1)
                    }, r.abtests = {
                        url: (0, i.ev)((0, i.ev)(["route", "lti"], w, !0), ["ri", "sd", "ui", "pi", "wi", "pt", "vi", "tim", "id", "llvl", "cv"], !1)
                    }, r["external-revenue"] = {
                        url: ["route", "lti", "ri", "sd", "ui", "pi", "wi", "pt", "vi", "tim", "id", "llvl", "cv"]
                    }, r["rtb-win"] = {
                        url: (0, i.ev)((0, i.ev)([], w, !0), ["route", "lti"], !1),
                        body: ["id", "ri", "sd", "ui", "pi", "wi", "pt", "vi", "li", "lt", "ppb", "cpb", "tim", "llvl", "cv"]
                    }, r.debug = {
                        url: (0, i.ev)((0, i.ev)(["lt"], w, !0), ["tim", "id", "cv", "llvl"], !1)
                    }, r.social = {
                        url: ["lti", "ri", "sd", "ui", "pi", "wi", "pt", "vi"]
                    }, r.perf = {
                        url: (0, i.ev)((0, i.ev)([], w, !0), ["route", "lti"], !1),
                        body: ["id", "ri", "sd", "ui", "pi", "wi", "pt", "vi", "cv", "lt", "tim", "llvl"]
                    }, r.json = {
                        url: []
                    }, r["pubs-generic"] = {
                        url: ["route", "lti", "ri", "sd", "ui", "pi", "wi", "pt", "vi", "tim", "id", "llvl", "cv"]
                    }, r["swap-data"] = {
                        url: ["route", "lti", "ri", "sd", "ui", "pi", "wi", "pt", "vi", "tim", "id", "llvl", "cv"]
                    }, r),
                    T = ["fil", "spatialData"],
                    C = null;

                function S(e) {
                    var t, n;
                    null === C && (C = (0, c.Mv)("send-event-as-post"));
                    var r = e.field,
                        i = e.itemData,
                        a = e.placement,
                        l = e.eventType;
                    if (C || !(T.indexOf(r) > -1)) {
                        var d = u.L5.config.publisher,
                            y = u.L5.userData,
                            w = u.L5.optionsSummary,
                            E = u.L5.responseSummary.testAndExperiment;
                        switch (r) {
                            case "debugName":
                                return a.uip;
                            case "pi":
                                return (0, g.k)(u.L5.pageItemId, d["prenormalize-item-id"]);
                            case "ri":
                                return a.ri || (null === (t = u.L5.responseSummary.events) || void 0 === t ? void 0 : t.requestId);
                            case "sd":
                                return y.sessionData;
                            case "ui":
                                return y.userId;
                            case "ii":
                                return i.taboolaId;
                            case "route":
                                return y.dataCenterRoute;
                            case "it":
                                return i.sourceType;
                            case "pt":
                                return (0, v.r)(w.itemSourceType);
                            case "li":
                                var S = (0, o.L)(a);
                                return (0, h.Z)(w.itemSourceType, S);
                            case "sig":
                                return i.signature;
                            case "vi":
                                return u.L5.viewId;
                            case "p":
                                return i.advertiser;
                            case "lti":
                            case "lt":
                                return d.systemFlags.loaderType;
                            case "r":
                                return 1e3 * Math.random() | 0;
                            case "tvi2":
                            case "tvi6":
                            case "tvi48":
                            case "tvi50":
                                return (null === (n = E.testVariantsMap) || void 0 === n ? void 0 : n[r]) || void 0;
                            case "ppb":
                                return a.ppb;
                            case "cpb":
                                return y.cpb;
                            case "prt":
                                return function(e) {
                                    return e.isNetwork ? "nt" : e.isNative ? "nav" : void 0
                                }(i);
                            case "wi":
                                return a.wi || y.wi;
                            case "il":
                                return I(a).il;
                            case "ilt":
                                return I(a).ilt;
                            case "sil":
                                return I(a).sil;
                            case "silt":
                                return I(a).silt;
                            case "siltp":
                                return I(a).siltp;
                            case "navil":
                                return I(a).navil;
                            case "navilt":
                                return I(a).navilt;
                            case "naviltp":
                                return I(a).naviltp;
                            case "ntil":
                                return I(a).ntil;
                            case "ntilt":
                                return I(a).ntilt;
                            case "niltp":
                                return I(a).niltp;
                            case "tp":
                                return (0, c.tt)(a.m, "thumbnail-position");
                            case "spatialData":
                                return function(e) {
                                    var t = (0, f.zJ)(),
                                        n = (0, f.gT)();
                                    return e.items.map((function(e) {
                                        var r, i, o, a = u.L5.getEntityCustomData(e);
                                        if ((0, s.LO)(a, "itemCustomData is null"), !a.element.parentElement) return function(e) {
                                            var t, n, r;
                                            return (t = {}).id = e.taboolaId, t.sgd = ((n = {}).w = "-1", n.h = "-1", n.x = "-1", n.y = "-1", n), t.ssd = ((r = {}).fsi = "", r.fst = "", r.fn = "", r.cbg = "", r.dbg = L, r), t
                                        }(e);
                                        var c = a.element.getBoundingClientRect(),
                                            l = window.getComputedStyle(a.element);
                                        return L || (L = window.getComputedStyle(document.body).getPropertyValue("background-color")), (r = {}).id = e.taboolaId, r.sgd = ((i = {}).w = c.width.toFixed(2), i.h = c.height.toFixed(2), i.x = (c.x + t).toFixed(2), i.y = (c.y + n).toFixed(2), i), r.ssd = ((o = {}).fsi = l.getPropertyValue("font-size"), o.fst = l.getPropertyValue("font-style"), o.fn = l.getPropertyValue("font-family"), o.cbg = l.getPropertyValue("background-color"), o.dbg = L, o), r
                                    }))
                                }(a);
                            case "tim":
                                return (0, _.el)();
                            case "id":
                                return (0, f.D1)();
                            case "llvl":
                                return (0, x.$F)().llvl;
                            case "cv":
                                return (0, m.X)();
                            case "fil":
                                return function(e, t) {
                                    return e.items.map((function(n) {
                                        var r;
                                        return (r = {}).tii = n.taboolaId, r.tipt = function(e) {
                                            return e.isNetwork ? "NT" : e.isNative ? "NAV" : e.isSponsored ? "SP" : "RC"
                                        }(n), r.tit = (0, v.G)(n.sourceType), r.tids = function(e, t, n) {
                                            switch (n) {
                                                case "available":
                                                    return "a";
                                                case "visible":
                                                    return function(e, t) {
                                                        if (!e.isItemVisible(t)) return "nvp";
                                                        var n = u.L5.responseSummary.isItemLevelVisible && !t.visibleEventSent ? "newvp" : "vp";
                                                        return t.setItemAsVisible(), n
                                                    }(e, t)
                                            }
                                            throw new Error("Not supported event type")
                                        }(e, n, t), r
                                    }))
                                }(a, l);
                            case "vl":
                                return u.L5.responseSummary.isItemLevelVisible ? "i" : "p";
                            case "fve":
                                return function(e) {
                                    return 1 === e.eventSent.visible
                                }(a);
                            case "bad":
                                return -1;
                            case "sw":
                                return window.screen.availWidth;
                            case "sh":
                                return window.screen.availHeight;
                            case "bw":
                                return window.innerWidth;
                            case "bh":
                                return window.innerHeight;
                            case "dw":
                                return (0, b.nX)();
                            case "dh":
                                return (0, b.Yt)();
                            case "sde":
                                return (0, b.i9)();
                            case "cd":
                                return function(e) {
                                    var t, n = null === (t = u.L5.getEntityCustomData(e)) || void 0 === t ? void 0 : t.element;
                                    return (0, s.LO)(n, "Placement element missing in Store"), n.getBoundingClientRect().top + (0, f.gT)()
                                }(a);
                            case "mw":
                                return function(e) {
                                    var t, n = null === (t = u.L5.getEntityCustomData(e)) || void 0 === t ? void 0 : t.element;
                                    return (0, s.LO)(n, "Placement element missing in Store"), n.getBoundingClientRect().width
                                }(a);
                            case "utm":
                            case "mgo":
                            case "df":
                            case "supply-feature":
                            case "data":
                                return;
                            case "dimensions":
                                return function() {
                                    var e = "normal";
                                    p.mb.taboolaMobile && (e = "SDK"), u.L5.config.runtime.isAMP && (e = "AMP");
                                    var t = {
                                        publisher: u.L5.config.publisher.publisherName,
                                        "integration-type": e
                                    };
                                    return (0, f.lY)(t)
                                }();
                            case "pc":
                                return i.productClick
                        }
                        throw new Error("Field '".concat(r, "' was not handled"))
                    }
                }
                var R, k = "";

                function I(e) {
                    var t;
                    if (k === e.uip) return R;
                    var n = e.items,
                        r = n.filter((function(e) {
                            return e.isOrganic
                        })),
                        i = n.filter((function(e) {
                            return e.isSponsored
                        })),
                        o = n.filter((function(e) {
                            return e.isNative
                        })),
                        a = n.filter((function(e) {
                            return e.isNetwork
                        }));
                    return k = e.uip, (t = {}).il = r.map((function(e) {
                        return e.taboolaId
                    })).join(","), t.ilt = r.map((function(e) {
                        return (0, v.G)(e.sourceType)
                    })).join(","), t.sil = i.map((function(e) {
                        return e.taboolaId
                    })).join(","), t.silt = i.map((function(e) {
                        return (0, v.G)(e.sourceType)
                    })).join(","), t.siltp = i.map((function(e) {
                        return e.advertiser
                    })).join(","), t.navil = o.map((function(e) {
                        return e.taboolaId
                    })).join(","), t.navilt = o.map((function(e) {
                        return (0, v.G)(e.sourceType)
                    })).join(","), t.naviltp = o.map((function(e) {
                        return e.advertiser
                    })).join(","), t.ntil = a.map((function(e) {
                        return e.taboolaId
                    })).join(","), t.ntilt = a.map((function(e) {
                        return (0, v.G)(e.sourceType)
                    })).join(","), t.niltp = a.map((function(e) {
                        return e.advertiser
                    })).join(","), R = t
                }
                var L = "",
                    O = {},
                    M = {};

                function N(e, t, n) {
                    var r;
                    (0, s.LO)(t.placement || n, "placement must have a value");
                    var o, a = {};
                    return E[e].url.forEach((function(r) {
                        a[r] = S({
                            field: r,
                            itemData: t,
                            placement: n || t.placement,
                            eventType: e
                        })
                    })), a = (0, i.pi)((0, i.pi)({}, a), (0, x.Qw)()), E[e].body && (o = {}, null === (r = E[e].body) || void 0 === r || r.forEach((function(r) {
                        o[r] = S({
                            field: r,
                            itemData: t,
                            placement: n || t.placement,
                            eventType: e
                        })
                    }))), {
                        url: a,
                        body: o || void 0
                    }
                }

                function P(e) {
                    var t = N("click", e),
                        n = e.IsSyndicated ? "redir" : "url";
                    t.url[n] = e.clickUrl;
                    var r = (0, a.fM)("click", t);
                    return r ? (0, y.Vj)("click", r) : ((0, d.H)("Click event was canceled"), "")
                }

                function D(e) {
                    var t = N("available", O, e),
                        n = (0, a.fM)("available", t);
                    return n ? {
                        type: "available",
                        url: (0, y.Vj)("available", n),
                        body: n.body ? (0, _.G6)(n.body) : void 0
                    } : null
                }

                function A(e) {
                    var t = N(e, O, M),
                        n = (0, a.fM)(e, t);
                    return n ? {
                        type: e,
                        url: (0, y.Vj)(e, n),
                        body: n.body ? (0, _.G6)(n.body) : void 0
                    } : null
                }

                function U(e) {
                    var t = N("visible", O, e),
                        n = (0, a.fM)("visible", t);
                    return n ? {
                        type: "visible",
                        url: (0, y.Vj)("visible", n),
                        body: n.body ? (0, _.G6)(n.body) : void 0
                    } : null
                }

                function F(e) {
                    var t = N("metrics", O, M);
                    t.body && (t.body.metricName = e.metricName, t.body.type = e.type, t.body.value = e.value);
                    var n = (0, a.fM)("metrics", t);
                    return n ? {
                        type: "metrics",
                        url: (0, y.Vj)("metrics", n),
                        body: n.body ? (0, _.G6)(n.body) : void 0
                    } : null
                }

                function q(e) {
                    for (var t, n = [], r = 1; r < arguments.length; r++) n[r - 1] = arguments[r];
                    if (!u.L5) {
                        var o = n[0];
                        return (0, s.DI)("error" === e),
                            function(e) {
                                var t, n = {
                                    url: (0, i.pi)((t = {}, t.type = "error", t.msg = e.message, t.lt = "trecs", t.tim = (0, _.el)(), t.id = (0, f.D1)(), t.cv = (0, m.X)(), t.llvl = x.RR, t.fatal = !0, t), e.extraData)
                                };
                                return {
                                    type: "debug",
                                    url: (0, y.Vj)("debug", n),
                                    isFatal: !0
                                }
                            }(o)
                    }
                    var c = N("debug", O, M),
                        l = (0, a.fM)("debug", c);
                    if (!l) return null;
                    var d = n[0],
                        p = n[1];
                    return "error" === e ? function(e, t) {
                        var n, r = {
                            url: (0, i.pi)((0, i.pi)((n = {}, n.type = "error", n.msg = e.message, n), t.url), e.extraData)
                        };
                        return {
                            type: "debug",
                            url: (0, y.Vj)("debug", r)
                        }
                    }(d, l) : (l = (0, i.pi)((0, i.pi)({}, l), {
                        url: (0, i.pi)((0, i.pi)((t = {}, t.type = e, t.msg = d, t), l.url), p)
                    }), {
                        type: "debug",
                        url: (0, y.Vj)("debug", l)
                    })
                }

                function V(e, t) {
                    var n, r = N("abtests", O, M),
                        o = (0, a.fM)("abtests", r);
                    return o ? (o = (0, i.pi)((0, i.pi)({}, o), {
                        url: (0, i.pi)((0, i.pi)({}, o.url), (n = {}, n.d = {
                            abTestsEventType: "simple",
                            name: e,
                            type: t,
                            eventTime: (0, l.X)()
                        }, n))
                    }), {
                        type: "abtests",
                        url: (0, y.Vj)("abtests", o)
                    }) : null
                }

                function B(e, t) {
                    var n, r = N("external-revenue", O, M),
                        o = (0, a.fM)("external-revenue", r);
                    return o ? (o = (0, i.pi)((0, i.pi)({}, o), {
                        url: (0, i.pi)((0, i.pi)({}, o.url), (n = {}, n.d = {
                            name: e,
                            payload: t,
                            eventTime: (0, l.X)()
                        }, n))
                    }), {
                        type: "external-revenue",
                        url: (0, y.Vj)("external-revenue", o)
                    }) : null
                }

                function j(e) {
                    var t, n = N("SupplyFeature", O, M),
                        r = (0, a.fM)("SupplyFeature", n);
                    return r ? (r = (0, i.pi)((0, i.pi)({}, r), {
                        url: (0, i.pi)((0, i.pi)({}, r.url), (t = {}, t.d = (0, i.pi)({}, e), t))
                    }), {
                        type: "SupplyFeature",
                        url: (0, y.Vj)("SupplyFeature", r)
                    }) : null
                }

                function H(e) {
                    var t, n = N("perf", O, M),
                        r = (0, a.fM)("perf", {
                            url: n.url,
                            body: (0, i.pi)((0, i.pi)({}, n.body), (t = {}, t.data = {
                                measurements: JSON.stringify(e.measurements),
                                dict: JSON.stringify(e.dict)
                            }, t))
                        });
                    return r ? {
                        type: "perf",
                        url: (0, y.Vj)("perf", r),
                        body: r.body ? (0, _.G6)(r.body) : void 0
                    } : null
                }

                function z(e, t) {
                    var n = N("rtb-win", O, t),
                        r = (0, a.fM)("rtb-win", {
                            url: n.url,
                            body: (0, i.pi)((0, i.pi)({}, n.body), e)
                        });
                    return r ? {
                        type: "rtb-win",
                        url: (0, y.Vj)("rtb-win", r),
                        body: r.body ? (0, _.G6)(r.body) : void 0
                    } : null
                }

                function W(e) {
                    var t, n = N("social", O, M),
                        r = (0, a.fM)("social", n);
                    return r ? (r = (0, i.pi)((0, i.pi)({}, r), {
                        url: (0, i.pi)((0, i.pi)({}, r.url), (t = {}, t.st = e.name, t.d = {
                            data: e.data
                        }, t))
                    }), {
                        type: "social",
                        url: (0, y.Vj)("social", r)
                    }) : null
                }

                function G(e, t) {
                    var n, r = N("pubs-generic", O, t || M),
                        o = (0, a.fM)("pubs-generic", r);
                    if (!o) return null;
                    var u = JSON.stringify(e.data || ""),
                        c = JSON.stringify((0, i.pi)((0, i.pi)({}, e), {
                            data: u
                        }));
                    return o = (0, i.pi)((0, i.pi)({}, o), {
                        url: (0, i.pi)((0, i.pi)({}, o.url), (n = {}, n.d = c, n))
                    }), {
                        type: "pubs-generic",
                        url: (0, y.Vj)("pubs-generic", o)
                    }
                }

                function Y(e) {
                    var t, n = N("swap-data", O, M),
                        r = (0, a.fM)("swap-data", n);
                    if (!r) return null;
                    var o = JSON.stringify(e.data || ""),
                        u = JSON.stringify((0, i.pi)((0, i.pi)({}, e), {
                            data: o
                        }));
                    return r = (0, i.pi)((0, i.pi)({}, r), {
                        url: (0, i.pi)((0, i.pi)({}, r.url), (t = {}, t.d = u, t))
                    }), {
                        type: "swap-data",
                        url: (0, y.Vj)("swap-data", r)
                    }
                }
            },
            6736: function(e, t, n) {
                "use strict";
                n.d(t, {
                    $q: function() {
                        return h
                    },
                    Al: function() {
                        return g
                    },
                    B$: function() {
                        return v
                    },
                    E6: function() {
                        return w
                    },
                    Sn: function() {
                        return E
                    },
                    W3: function() {
                        return x
                    },
                    pS: function() {
                        return y
                    },
                    vH: function() {
                        return _
                    }
                });
                var r, i = n(7582),
                    o = n(9839),
                    a = n(3887),
                    u = n(1602),
                    c = n(5281),
                    s = n(8404),
                    l = n(3595),
                    d = n(7341),
                    p = !1,
                    f = ((r = {}).debug = [], r.abtests = [], r["external-revenue"] = [], r.SupplyFeature = [], r.perf = [], r["pubs-generic"] = [], r);

                function m() {
                    f && (f.debug.forEach((function(e) {
                        var t = e[0],
                            n = e[1];
                        v.apply(void 0, (0, i.ev)([t], n, !1))
                    })), f.abtests.forEach((function(e) {
                        h.apply(null, e)
                    })), f["external-revenue"].forEach((function(e) {
                        g.apply(null, e)
                    })), f.SupplyFeature.forEach((function(e) {
                        b.apply(null, e)
                    })), f.perf.forEach((function(e) {
                        _.apply(null, e)
                    })), f["pubs-generic"].forEach((function(e) {
                        w.apply(null, e)
                    })), f = null)
                }

                function v(e) {
                    for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                    if (f && "error" !== e && !p) return f.debug.push([e, t]), s.e.resolve("");
                    var r = d.Q5.apply(void 0, (0, i.ev)([e], t, !1));
                    return r ? r.isFatal ? (0, l.rR)(r) : (0, l.xh)(r) : s.e.resolve("")
                }

                function h(e, t) {
                    if (f && !p) return f.abtests.push([e, t]), s.e.resolve("");
                    (0, u.DI)(!!o.L5);
                    var n = (0, d.ec)(e, t);
                    return n ? (0, l.xh)(n) : s.e.resolve("")
                }

                function g(e, t) {
                    if (f && !p) return f["external-revenue"].push([e, t]), s.e.resolve("");
                    (0, u.DI)(!!o.L5);
                    var n = (0, d.Pl)(e, t);
                    return n ? (0, l.xh)(n) : s.e.resolve("")
                }

                function b(e) {
                    if (f && !p) return f.SupplyFeature.push([e]), s.e.resolve("");
                    (0, u.DI)(!!o.L5);
                    var t = (0, d.cF)(e);
                    return t ? (0, l.xh)(t) : s.e.resolve("")
                }

                function _(e, t) {
                    if (f && !p) return f.perf.push([e, t]), s.e.resolve("");
                    var n = (0, d.qv)(e);
                    return n ? (0, l.xh)(n, t) : s.e.resolve("")
                }

                function y(e, t) {
                    if (!o.L5) return s.e.resolve("");
                    var n = (0, d.ED)(e, t);
                    return n ? (0, l.xh)(n) : s.e.resolve("")
                }

                function w(e, t) {
                    if (f && !p) return f["pubs-generic"].push([e]), s.e.resolve("");
                    (0, u.DI)(!!o.L5);
                    var n = (0, d.NY)(e, t);
                    return n ? (0, l.xh)(n) : s.e.resolve("")
                }

                function x(e, t) {
                    (0, a.Mv)("rbox-usage-logging") && v("usage", e, t)
                }

                function E(e) {
                    (0, u.DI)(!!o.L5);
                    var t = (0, d.wo)(e);
                    return t ? (0, l.xh)(t) : s.e.resolve("")
                }
                c.Y.once("storeReady", (function() {
                    o.L5.onResponseSummaryUpdateOnce((function() {
                        p = !0, m()
                    }))
                }))
            },
            1869: function(e, t, n) {
                "use strict";
                n.d(t, {
                    m: function() {
                        return d
                    }
                });
                var r = n(9839),
                    i = n(3887),
                    o = n(5281),
                    a = n(6265),
                    u = n(8404),
                    c = n(3595),
                    s = n(8951),
                    l = n(7341);

                function d(e, t) {
                    return (0, a.s)((function() {
                        var n = {
                                metricName: e,
                                value: f(e, t || 1),
                                type: "counter"
                            },
                            r = (0, l.g5)(n);
                        if (!r) return u.e.resolve("");
                        if (function() {
                                if (null === m) {
                                    var e = Math.random() <= (0, i.Cd)("rbox-metrics-enabled"),
                                        t = "disable" !== (0, i.Cd)("bulk-metrics-events-strategy"),
                                        n = (0, i.Mv)("send-event-as-post");
                                    m = e && t && n
                                }
                                return m
                            }()) {
                            var o = (0, i.Cd)("bulk-metrics-events-delay");
                            return (0, s._)("bulk-metrics", r, o)
                        }
                        return (0, c.xh)(r)
                    })).then((function(e) {
                        return e
                    }))
                }
                var p = {};

                function f(e, t) {
                    var n = p[e] || 0;
                    return n += t, p[e] = n, n
                }
                var m = null;

                function v() {
                    d("LoadRequestSent")
                }
                o.Y.once("storeReady", (function() {
                    r.L5.onResponseSummaryUpdate(v)
                }))
            },
            7969: function(e, t, n) {
                "use strict";
                n.d(t, {
                    $F: function() {
                        return s
                    },
                    Qw: function() {
                        return l
                    },
                    RR: function() {
                        return c
                    }
                });
                var r, i = n(7582),
                    o = n(4555),
                    a = n(9839),
                    u = n(6379),
                    c = 2;

                function s() {
                    var e;
                    if (r) return r;
                    var t = o.mb.trc_debug_level || c,
                        n = a.L5.config.runtime.trcForce,
                        s = a.L5.config.runtime.debugQueryParams || {},
                        d = s["taboola-debug"];
                    d && (t = parseInt(d) || t);
                    var p = {};
                    return (0, u.mt)(s, (function(e, t) {
                        0 === e.indexOf("trc_") && (p[e] = t)
                    })), r = (0, i.pi)((0, i.pi)((0, i.pi)(((e = {}).llvl = t > 1 ? t : void 0, e), n), p), l())
                }

                function l() {
                    var e = a.L5.config.publisher.systemFlags.eventExternal || {},
                        t = {};
                    return (0, u.mt)(e, (function(e, n) {
                        t["ex_".concat(e)] = n
                    })), t
                }
            },
            5187: function(e, t, n) {
                "use strict";
                n.d(t, {
                    k: function() {
                        return me
                    }
                });
                var r = n(9839),
                    i = n(5281),
                    o = n(7807),
                    a = n(1085),
                    u = "item",
                    c = function() {
                        function e() {
                            this._emitter = new o.v
                        }
                        return e.prototype.set = function(e) {
                            this._item = e, this._emitter.emit(u, e)
                        }, e.prototype.remove = function() {
                            this._item = (0, a.F)()
                        }, e.prototype.get = function() {
                            return this._item
                        }, e.prototype.cleanUp = function() {
                            this.remove(), this._emitter.removeAll(), this._emitter = (0, a.F)()
                        }, e.prototype.on = function(e) {
                            return this._emitter.on(u, e)
                        }, e.prototype.once = function(e) {
                            var t = this._emitter.once(u, e);
                            return this._item && (e(this._item), t()), t
                        }, e
                    }(),
                    s = n(7582),
                    l = n(6972),
                    d = n(1602),
                    p = n(8404),
                    f = n(3887),
                    m = n(1312);

                function v() {
                    var e = function() {
                        if ((0, f.Mv)("send-id-providers-data")) return (0, f.Cd)("rbox:rtb:real-time-user-sync:intent-iq:external-partners-ids")
                    }();
                    if (e && 0 !== e.length) {
                        var t = function() {
                            var e = (0, m.Qf)("localStorage", "idproviders");
                            if (e) return JSON.parse(e).INTENT_IQ.c2c
                        }();
                        if (t && 0 !== t.length) return function(e, t) {
                            var n = {};
                            if (e.forEach((function(e) {
                                    var r = e.pid;
                                    t.indexOf(r) > -1 && (n[r] = e.uid)
                                })), 0 !== Object.keys(n).length) return {
                                INTENT_IQ: n
                            }
                        }(t, e)
                    }
                }
                var h = n(8261),
                    g = n(1553),
                    b = n(6379),
                    _ = n(1591),
                    y = n(2057);

                function w(e, t) {
                    if (!(0, h.Th)(t)) return e;
                    var n = (0, y.$)(e, {}),
                        r = !1;
                    if (n.hasFeeds && (0, b.mt)(n.feeds, (function(e, n) {
                            var i = n.batchList[n.batchList.length - 1];
                            i.placements = i.placements.filter((function(e) {
                                var n = (0, h.Tt)(t, {
                                    placement: e
                                });
                                return r || (r = !1 === n), n
                            })), i.placements.forEach((function(e) {
                                var n = e.items.filter((function(e) {
                                    var n = (0, h.Tt)(t, {
                                        itemData: e
                                    });
                                    return r || (r = !1 === n), n
                                }));
                                (0, b.Io)(e, "items", n)
                            })), 0 === i.placements.length && (0, g.yN)('Placement filter action "'.concat(t, '" filtered all feed "').concat(e, '" batch'))
                        })), n.hasWidgets) {
                        var i = {};
                        (0, b.mt)(n.widgets, (function(e, n) {
                            (0, h.Tt)(t, {
                                widget: n
                            }) ? i[e] = n: r = !0
                        })), n.widgets = i, (0, _.it)(i) || (0, g.yN)('Placement filter action "'.concat(t, '" filtered widget'))
                    }
                    return r ? n : e
                }
                var x = n(4583),
                    E = {};

                function T(e, t, n) {
                    E[e] || ((0, x.c)("iframe") && !t || n) && (E[e] = !0)
                }
                var C = n(2271),
                    S = n(2939),
                    R = !1;
                var k, I, L = n(6265),
                    O = n(7863),
                    M = n(4555),
                    N = n(4794),
                    P = n(7329),
                    D = n(7969),
                    A = n(3595),
                    U = n(5217),
                    F = n(4400),
                    q = n(253),
                    V = n(7900),
                    B = n(7072),
                    j = n(5346),
                    H = n(8203),
                    z = n(734),
                    W = n(6624);

                function G() {
                    return k || (k = (0, x.c)("browsing-topics") && (0, f.Mv)("topics-enabled") ? document.browsingTopics().then((function(e) {
                        return function(e) {
                            if (!(null == e ? void 0 : e.length)) {
                                var t = (n = (0, m.Qf)("localStorage", "top")) ? (0, _.Cy)(n) : n;
                                return (null == t ? void 0 : t.length) ? (Y(t), t) : void 0
                            }
                            var n, r = e.map((function(e) {
                                var t;
                                return (t = {}).i = e.topic, t.v = e.taxonomyVersion, t
                            }));
                            return (0, m.RY)("localStorage", "top", (0, _.lY)(r)), Y(r), r
                        }(e)
                    })).catch((function() {
                        (0, g.yN)("Error - Unable to get Browsing Topics")
                    })) : p.e.resolve(void 0))
                }

                function Y(e) {
                    r.Un.appendRuntimeConfig({
                        topics: e
                    })
                }

                function Q() {
                    if ((0, f.Mv)("protected-audience-enabled")) return null != I || (I = (0, x.c)("protected-audience")), I
                }
                i.Y.once("storeCreated", G);
                var K = n(3150),
                    J = function() {
                        function e(e, t) {
                            var n = this;
                            this._allExecutions = [], this._nextPayload = {}, this._responseSummary = {}, this._isRunning = !1, this._lastFailedReason = null, this.handleLoadNextError = function(e) {
                                var t, i, o = (0, h.Tt)("e14", e);
                                switch (e.reason) {
                                    case "disallowedByExtension":
                                        return void(0, g.o7)("Extension disallowed TRC Request");
                                    case "stillRunning":
                                        return void(n._lastFailedReason = null)
                                }
                                if (!o) return r.Un.appendResponseSummary(z.y7), p.e.reject(e);
                                null === (t = o.responseSummary) || void 0 === t || t.then((function(e) {
                                    r.Un.appendResponseSummary(e), n._responseSummary = (0, y.$)(n._responseSummary, e)
                                })), null === (i = o.optionsSummary) || void 0 === i || i.then((function(e) {
                                    r.Un.appendOptionsSummary(e)
                                }))
                            }, this._loadNext = function() {
                                return (0, s.mG)(n, void 0, void 0, (function() {
                                    var e, t, n, i, o, a, u, c, m, v = this;
                                    return (0, s.Jh)(this, (function(s) {
                                        switch (s.label) {
                                            case 0:
                                                return e = this._optionsSummary, t = function(t, n) {
                                                    "stillRunning" !== t && (v._isRunning = !1), v._lastFailedReason = t;
                                                    var r = {
                                                        reason: t,
                                                        optionsSummary: e,
                                                        parsedTrcResponse: n
                                                    };
                                                    return p.e.reject(r)
                                                }, this._isRunning ? [2, t("stillRunning")] : (this._isRunning = !0, !1 !== this._responseSummary.hasNextBatch || this.shouldWidgetLoadNext() ? (0, l.Cu)(e) ? [4, this.generateTrcCallPayload()] : [2, t("noUnusedPlacementFound")] : [2, t("noNextBatchLoad")]);
                                            case 1:
                                                return n = s.sent(), (i = (0, h.Tt)("e9", n)) && (n = i.payload, o = i.response, a = i.responsePromise), o && (o = w(o, "e12"), o = (0, h.Tt)("e13", o) || o, r.Un.appendResponseSummary(o), this._responseSummary = (0, y.$)(this._responseSummary, o)), null == a || a.then((function(e) {
                                                    r.Un.appendResponseSummary(e), v._responseSummary = (0, y.$)(v._responseSummary, e)
                                                })), n ? (u = (0, h.fM)("json", {
                                                    url: n
                                                }), (0, d.LO)(u), c = (0, U.Vj)("json", u), m = function(e) {
                                                    if (!window.performance) return function() {
                                                        return new p.e((function(e, t) {}))
                                                    };
                                                    var t, n = (0, S.Tj)();
                                                    !R && (null === (t = window.performance) || void 0 === t ? void 0 : t.setResourceTimingBufferSize) && (R = !0, window.performance.setResourceTimingBufferSize(window.performance.getEntries().length + 1e3));
                                                    var r = 1e5 * Math.random() | 0,
                                                        i = "".concat(e, "_").concat(r),
                                                        o = "".concat(i, "_end"),
                                                        a = "".concat(i, "_measure");
                                                    return n.mark(i),
                                                        function() {
                                                            return new p.e((function(e) {
                                                                n.mark(o), n.measure(a, i, o);
                                                                var t = 0;
                                                                window.requestAnimationFrame((function r() {
                                                                    var i = n.getEntriesByName(a),
                                                                        o = i.length > 0 ? i[0].duration : -1;
                                                                    o > 0 ? e(o) : t > 60 ? e(-1) : (t += 1, window.requestAnimationFrame(r))
                                                                }))
                                                            }))
                                                        }
                                                }("TrcCall"), this._lastExecution = (0, A.bv)(c, {
                                                    method: (0, f.Mv)("send-event-as-post") ? "POST" : "GET"
                                                }).then((function(e) {
                                                    return m().then((function(e) {
                                                        (0, g.o7)("TRC call duration: ".concat(e))
                                                    })), v.handleLoadResponse(e, undefined)
                                                })).catch((function(e) {
                                                    v._isRunning = !1, (0, O.Wt)("firstTrcCallFailed", "json: ".concat((0, _.lY)({}))), (0, g.H)("Failed TRC JSON:", e);
                                                    var t = (0, z.eo)();
                                                    return t.hasContent = !1, "networkTimeout" === e.reason ? t.noContentReason = "TIMEOUT" : t.noContentReason = "ERROR", t
                                                })).then((function(e) {
                                                    return e.noContentReason ? t("noContent", e) : (v._isRunning = !1, e)
                                                })), r.Un.signUnusedPlacementsAsUsed(e.placements), this._allExecutions.push(this._lastExecution), [2, this._lastExecution]) : (this._isRunning = !1, r.Un.signUnusedPlacementsAsUsed(e.placements), [2, p.e.resolve(o || {})])
                                        }
                                    }))
                                }))
                            }, this._optionsSummary = e || r.L5.optionsSummary, this._responseSummary = t || {}
                        }
                        return e.prototype.optionSummaryPlacementsCount = function() {
                            return this._optionsSummary.placements.length
                        }, e.prototype.removeOptionSummaryPlacement = function(e) {
                            var t = this._optionsSummary.placements;
                            this._optionsSummary = (0, s.pi)((0, s.pi)({}, this._optionsSummary), {
                                placements: t.filter((function(t) {
                                    return t.placementName !== e
                                }))
                            })
                        }, e.prototype.updateOptionSummaryPlacements = function(e) {
                            this._optionsSummary = (0, s.pi)((0, s.pi)({}, this._optionsSummary), {
                                placements: e
                            })
                        }, e.prototype.canLoadNext = function() {
                            return !this._isRunning && ((0, d.DI)("stillRunning" !== this._lastFailedReason), !this._responseSummary.originalResponse && !this._lastFailedReason || !this._lastFailedReason && (this.shouldFeedLoadNext() || this.shouldExploreMoreLoadNext() || this.shouldWidgetLoadNext()))
                        }, e.prototype.shouldWidgetLoadNext = function() {
                            var e = this._optionsSummary.placements;
                            if (e.length > 1 || !ie(e[0])) return !1;
                            var t = r.L5.optionsSummary.placements,
                                n = (0, K.mv)(e[0], t);
                            return !(0, C.r8)(n) && (0, K.vn)(n)
                        }, e.prototype.shouldFeedLoadNext = function() {
                            var e = this,
                                t = this._responseSummary;
                            if (!t.hasFeeds) return !1;
                            var n = !0;
                            return (0, b.mt)(t.feeds, (function(t, r) {
                                e._optionsSummary.placements.filter((function(e) {
                                    return e.placementName === t
                                })).length > 0 && !r.hasFeedEnded && (n = !1)
                            })), !n
                        }, e.prototype.shouldExploreMoreLoadNext = function() {
                            var e, t = null === (e = this._responseSummary.exploreMore) || void 0 === e ? void 0 : e.entity;
                            return !(!t || 2 !== t.entityType) && this._optionsSummary.placements.filter((function(e) {
                                return e.placementName === t._ID
                            })).length > 0 && !t.hasFeedEnded
                        }, e.prototype.isPlacementOwner = function(e) {
                            return !(e.length > 0 && 0 === this._optionsSummary.placements.filter((function(t) {
                                return e.some((function(e) {
                                    return e.placementName === t.placementName
                                }))
                            })).length)
                        }, e.prototype.loadNext = function() {
                            var e = this;
                            return this.isAllowRequest().then((function() {
                                return (0, L.s)(e._loadNext)
                            })).then((function(e) {
                                return e
                            })).catch(this.handleLoadNextError)
                        }, e.prototype.isAllowRequest = function() {
                            return new p.e((function(e, t) {
                                var n = (0, h.Tt)("e8");
                                !1 !== n ? (0, C.r8)(n) || !0 === n ? e() : n.then((function(n) {
                                    n ? e() : t({
                                        reason: "disallowedByExtension"
                                    })
                                })) : t({
                                    reason: "disallowedByExtension"
                                })
                            }))
                        }, e.prototype.handleLoadResponse = function(e, t) {
                            t = (0, C.cb)(e) ? (0, H.aK)(e) : (0, H.f7)(e), t = (0, h.Tt)("e10", t) || t, t = (0, h.Tt)("e11", t) || t;
                            var n = (0, z.W3)(t);
                            return n = w(n, "e12"), (n = (0, h.Tt)("e13", n) || n).hasFeeds && this.fillNextPayload(n), r.Un.appendResponseSummary(n), this._responseSummary = (0, y.$)(this._responseSummary, n), n
                        }, e.prototype.generateTrcCallPayload = function() {
                            var t, n, i, o, a, u, c;
                            return (0, s.mG)(this, void 0, void 0, (function() {
                                var l, d, p, m, h, g, b, y, w, C, S, R, k;
                                return (0, s.Jh)(this, (function(I) {
                                    switch (I.label) {
                                        case 0:
                                            return l = r.L5.config, d = l.publisher, p = this._optionsSummary, m = (0, j.x3)(p), h = (0, F.r)(p.itemSourceType), g = (0, q.C)(p, this._responseSummary), b = [(0, s.pi)((0, s.pi)({}, this._nextPayload), (0, D.$F)())], (R = {}).tim = (0, j.el)(), R.lti = d.systemFlags.loaderType, R.pubit = l.runtime.networkPublisher ? "n" : "i", R["user.opt_out"] = p.userOptOut ? "true" : void 0, R.t = 1, y = "data", w = [(0, s.pi)((0, s.pi)({}, this._nextPayload.data || {}), (0, j.I_)(p.gdpr))], (k = {}).id = (0, _.D1)(), k.sd = r.L5.sessionData || "", k.ui = r.L5.userId || "", k.ii = m, k.it = h, k.vi = r.L5.viewId, k.tmpl = r.L5.optionsSummary.pageTemplate, k.cv = (0, P.X)(), k.uiv = "default", k.u = (0, V.k)(l.runtime.pageUrl.href, d["prenormalize-item-url"]), k.qs = l.runtime.pageUrl.search, k.bv = j.Ed ? "1" : "0", k.btv = "0", k.ul = (0, B.uq)(), k.ccpa_dns = (null === (t = p.ccpa) || void 0 === t ? void 0 : t.CDNS) || void 0, k.ccpa_ps = (null === (n = p.ccpa) || void 0 === n ? void 0 : n.privacyString) || void 0, k.cos = (null === (o = null === (i = M.mb.navigator) || void 0 === i ? void 0 : i.connection) || void 0 === o ? void 0 : o.effectiveType) || void 0, k.con = (null === (u = null === (a = M.mb.navigator) || void 0 === a ? void 0 : a.connection) || void 0 === u ? void 0 : u.type) || void 0, k.ad = p.additionalData, k.e = l.runtime.referrerURL || void 0, k.bu = (0, B.t$)(), k.vpi = (0, j.nx)(d["prenormalize-item-id"]), k.bad = -1, k.sw = M.mb.screen.availWidth, k.sh = M.mb.screen.availHeight, k.bw = M.mb.innerWidth, k.bh = M.mb.innerHeight, k.dw = (0, B.nX)(), k.dh = (0, B.Yt)(), k.sde = (0, B.i9)(), k.lt = d.systemFlags.loaderType, k.nsid = l.runtime.networkPublisher, k.did = p.deviceId || (null === (c = l.runtime.dcData) || void 0 === c ? void 0 : c.deviceId) || void 0, k.unuid = p.unifiedId || void 0, k.r = g, k.exp = p.excludePubs || void 0, k.pp = (0, N.nZ)(p.trackingCodes) || void 0, k.pev = (0, j.ts)(p), k.rtui = p.realTimeUserId || void 0, k.plf = function() {
                                                if (T("stop_".concat("tslt"), (0, f.Mv)("enable-tslt-inside-iframe"), (0, _.it)(r.L5.responseSummary.translations)), T("ack_".concat("exm"), (0, f.Mv)("enable-exm-inside-iframe"), r.L5.responseSummary.hasExploreMore), (0, _.it)(E)) return E
                                            }(), C = "uad", [4, (0, j.N6)()];
                                        case 1:
                                            return k[C] = I.sent(), k.cacheKey = (0, j.$N)({
                                                itemSourceType: h,
                                                itemId: m,
                                                placementsList: g
                                            }), k.advrtsrc = p.advertorialSource || void 0, k.extpvid = p.externalPageView || void 0, k.usrtyp = p.userType || void 0, k.prem = p.premium || void 0, S = "top", [4, G()];
                                        case 2:
                                            return [2, s.pi.apply(void 0, b.concat([(R[y] = s.pi.apply(void 0, w.concat([(k[S] = I.sent(), k.cb = void 0, k._cn = "tions_".concat(++e._callNumber), k.lbt = (0, f.Cd)("bakeTime"), k.uifp = (0, W.Lg)(r.L5.userId || void 0), k.wc = (0, x.c)("web-components"), k.idpd = v(), k.bl = (0, f.Cd)("blocker-list"), k.psb = Q(), k)])), R)]))]
                                    }
                                }))
                            }))
                        }, e.prototype.fillNextPayload = function(e) {
                            var t, n;
                            if (!this._nextPayload) {
                                var r = e.originalResponse[0];
                                this._nextPayload = (0, s.pi)((0, s.pi)({}, (0, W.L_)(r)), ((t = {}).route = r.route || void 0, t.data = ((n = {}).sd = r.sd, n.ui = r.ui, n.uifp = (0, W.Lg)(r.ui), n), t))
                            }
                        }, e.prototype.getAllExecutions = function() {
                            return this._allExecutions
                        }, e.prototype.cleanUp = function() {
                            this._optionsSummary = (0, a.F)(), this._responseSummary = (0, a.F)()
                        }, e._callNumber = 0, e
                    }();

                function $(e, t) {
                    var n = e.priority || 0,
                        r = t.priority || 0;
                    return n > r ? -1 : n < r ? 1 : 0
                }
                var X, Z = [],
                    ee = [],
                    te = [];

                function ne(e, t) {
                    var n = new J(e, t);
                    return ee.push(n), n
                }

                function re(e) {
                    e.forEach((function(e) {
                        -1 === te.indexOf(e) && te.push(e)
                    }))
                }

                function ie(e) {
                    return e.instances.length > 1
                }

                function oe(e) {
                    var t = ee.filter((function(t) {
                        return t.isPlacementOwner([e])
                    }))[0];
                    if (t) return ie(e) ? 1 === t.optionSummaryPlacementsCount() ? (t.updateOptionSummaryPlacements([e]), t) : (t.removeOptionSummaryPlacement(e.placementName), ae([e])) : t
                }

                function ae(e) {
                    var t = function(e) {
                        var t = (0, l.hw)(r.L5.optionsSummary);
                        return t.placements = e, t
                    }(e);
                    return ne(t)
                }

                function ue() {
                    X = void 0, te.splice(0, 1)
                }

                function ce() {
                    0 === te.length && function() {
                        if (0 !== Z.length) {
                            var e = Z.filter((function(e) {
                                return 0 === e.status
                            }))[0];
                            e && (re(function(e) {
                                var t = [],
                                    n = [];
                                if (e.list.forEach((function(e) {
                                        var r = oe(e);
                                        r ? t.push(r) : n.push(e)
                                    })), n.length > 0) {
                                    var r = ae(n);
                                    t.push(r)
                                }
                                return t
                            }(e)), e.status = 1)
                        }
                    }();
                    var e = te[0];
                    if (e && e !== X) return e.canLoadNext() ? new p.e((function(t) {
                        X = e, t({
                            response: e.loadNext().then((function(e) {
                                return ue(), (0, z.F_)(e) ? void 0 : e
                            })).catch((function(e) {
                                ue()
                            }))
                        })
                    })) : (ue(), ce())
                }
                i.Y.once("storeReady", (function() {
                    r.L5.onOptionsSummaryUpdated((function(e) {
                        var t;
                        (0, l.Cu)(e) && (t = (0, l.AF)(r.L5.optionsSummary), Z = function(e) {
                            var t = {},
                                n = [];
                            return e.forEach((function(e) {
                                var r = -1;
                                e.instances.forEach((function(i) {
                                    if (0 === i.status) {
                                        r++;
                                        var o = "".concat(e.groupName || "default", "_").concat(r),
                                            a = e.priority || 0,
                                            u = "".concat(o, "_").concat(a);
                                        t[u] || (t[u] = {
                                            priority: a,
                                            groupName: o,
                                            list: [],
                                            status: 0
                                        }, n.push(t[u])), t[u].list.push(e)
                                    }
                                }))
                            })), n.sort($), n
                        }(t))
                    })), r.L5.onReset((function() {
                        ee.forEach((function(e) {
                            return e.cleanUp()
                        })), ee = []
                    }))
                }));
                var se = !1;

                function le(e) {
                    if (e.exploreMore && !se) {
                        se = !0;
                        var t = function(e) {
                            var t = (0, l.qn)(),
                                n = e.exploreMore;
                            (0, d.LO)(n);
                            var i = {
                                modeName: Object.keys(r.L5.config.publisher.modes)[0] || "",
                                rboxResponsesIndex: 0,
                                instances: [(0, K.yt)(n.exploreMoreOptions.container)],
                                placementName: n._ID,
                                targetType: "mix",
                                byPublisher: !1
                            };
                            return t.placements.push(i), ne(t, e), i
                        }(e);
                        t && function(e) {
                            var t = (0, l.qn)();
                            t.placements.push((0, s.pi)((0, s.pi)({}, e), {
                                instances: (0, K.YB)(e.instances, 0)
                            })), r.Un.appendOptionsSummary(t)
                        }(t)
                    }
                }
                i.Y.once("storeReady", (function() {
                    r.L5.onResponseSummaryUpdate(le)
                }));
                var de = new c,
                    pe = !1;

                function fe(e) {
                    e.response.then((function() {
                        pe = !1, de.remove(), me()
                    })), de.set(e.response)
                }

                function me(e) {
                    if (void 0 === e && (e = []), function(e) {
                            var t, n;
                            e.length > 0 && (t = function(e) {
                                return e.filter((function(e) {
                                    return !(te.filter((function(t) {
                                        return t.isPlacementOwner([e])
                                    })).length > 0)
                                }))
                            }(e), n = [], t.forEach((function(e) {
                                var t = oe(e);
                                t && n.push(t)
                            })), re(n))
                        }(e), pe) return de;
                    var t = ce();
                    return t ? (pe = !0, t.then(fe)) : pe = !1, de
                }
            },
            5898: function(e, t, n) {
                "use strict";
                n.d(t, {
                    tb: function() {
                        return o
                    },
                    wo: function() {
                        return c
                    },
                    ws: function() {
                        return s
                    }
                });
                var r = n(3887),
                    i = n(3265),
                    o = ["banner_ad", "sponsored_ad"],
                    a = 0,
                    u = !1;

                function c() {
                    return !!(0, r.Mv)("abp-detection-enabled") || (a = -2, !1)
                }

                function s() {
                    return u || ((0, r.Cd)("abp-detection-class-names").some(l), u = !0), a
                }

                function l(e) {
                    var t = (0, i.U)("div", {
                        classList: [e],
                        content: "."
                    });
                    t.style.fontSize = "12px", t.style.lineHeight = "1", document.body.appendChild(t);
                    var n = !t.offsetHeight;
                    return document.body.removeChild(t), !!n && (a = 1, !0)
                }
            },
            4400: function(e, t, n) {
                "use strict";
                n.d(t, {
                    G: function() {
                        return i
                    },
                    r: function() {
                        return o
                    }
                });
                var r = n(4866);

                function i(e) {
                    return "_default_" !== e ? e : "article"
                }

                function o(e) {
                    switch (r.V[i(e)]) {
                        case r.V.home:
                            return "home";
                        case r.V.category:
                            return "category";
                        case r.V.text:
                            return "text";
                        case r.V.search:
                            return "search";
                        case r.V.photo:
                            return "photo";
                        case r.V.other:
                            return "other";
                        case r.V.content_hub:
                            return "content_hub";
                        case r.V.video:
                        default:
                            return "video"
                    }
                }
            },
            253: function(e, t, n) {
                "use strict";
                n.d(t, {
                    C: function() {
                        return x
                    },
                    Z: function() {
                        return w
                    }
                });
                var r = n(7582),
                    i = n(4362),
                    o = n(878),
                    a = n(6972),
                    u = n(3265),
                    c = n(9839),
                    s = n(3887),
                    l = n(9685),
                    d = n(1553),
                    p = n(4555),
                    f = n(1591),
                    m = n(5898),
                    v = n(4866),
                    h = n(8312),
                    g = n(4400),
                    b = n(2379),
                    _ = n(3150),
                    y = "rbox-invisible-widget";

                function w(e, t) {
                    var n = null == t ? void 0 : t.modeName;
                    if (n) {
                        if (n === i.xM) return y;
                        if (n === o.EU) return (0, o.Q6)(t)
                    }
                    var r = (null == t ? void 0 : t.targetType) || "video",
                        a = h.W[r],
                        u = v.V[(0, g.G)(e)];
                    return ["rbox-", u === v.V.video && a === h.W.video ? "blended" : [u, "2", a].join("")].join("")
                }

                function x(e, t) {
                    var n = [],
                        i = c.L5.config.publisher,
                        o = (0, g.G)(e.itemSourceType),
                        v = (null == t ? void 0 : t.feeds) || {},
                        h = Object.keys(v).length > 0 || !!t.exploreMore;
                    return (0, a.AF)(e).forEach((function(e) {
                        var a, g, y, x = e.modeName,
                            E = e.placementName,
                            T = (0, _.Yi)(e);
                        i.modes[x] || (0, d.yN)('Taboola Push Option modes "'.concat(x, '" not present in Publisher Config modes.'));
                        var C, S, R = !e.containerIgnored;
                        if (R) {
                            if (C = function(e, t) {
                                    var n = t ? (0, l.Qi)(t) : p.mb.document,
                                        r = n.querySelector("#".concat(e));
                                    return !r && c.L5.config.runtime.isAMP && (r = n.querySelector("[id^=".concat(e, "-split-num-]"))), r
                                }(T, e.frameId), !C) return void(0, d.yN)('Placement ("'.concat(E, '") container element ("').concat(T, "\") doesn't exist on the page."));
                            S = C.getBoundingClientRect()
                        }
                        var k = t.exploreMore,
                            I = (null == k ? void 0 : k.exploreMoreOptions.placement) === E ? k : void 0,
                            L = v[E] || (null == I ? void 0 : I.entity);
                        if (L || !h) {
                            var O = ((a = {}).li = w(o, e), a.uip = E, a.orig_uip = E, a.s = (0, b.u)(x), a.uim = function(e) {
                                var t = c.L5.config.runtime,
                                    n = t.networkPublisher ? ":pub=".concat(t.networkPublisher) : "",
                                    r = (0, m.wo)() && (0, s.Cd)("use-abp-uim") ? ":abp=".concat((0, m.ws)()) : "";
                                return "".concat(e).concat(n).concat(r)
                            }(x), a);
                            if (R && (O = (0, r.pi)((0, r.pi)((0, r.pi)({}, O), ((g = {}).cd = (0, f.yA)(S.top, 2), g.mw = (0, f.yA)(S.width, 2), g)), function(e, t) {
                                    var n, r = {};
                                    0 === e.getBoundingClientRect().width && (0, s.Mv)("send-alternate-container-width") && (r.amw = function(e) {
                                        var t = (0, u.U)("div");
                                        t.style.visibility = "hidden", t.style.height = "0px", t.innerHTML = function(e) {
                                            for (var t = new Array(100), n = 0; n < t.length; n++) t[n] = ".";
                                            return t.join(" ")
                                        }(), e.appendChild(t);
                                        var n = e.getBoundingClientRect().width;
                                        return e.removeChild(t), n
                                    }(e));
                                    var i = (0, s.tt)(t.modeName, "required-attributes");
                                    return i && "none" !== i && (r.ra = i), t.category && (r.ac = t.category), t.exclude && (r.ex = t.exclude), (null === (n = t.dfp) || void 0 === n ? void 0 : n.campaign_id) && (r.nvcid = t.dfp.campaign_id), r
                                }(C, e))), L) {
                                var M = L.batchList.reduce((function(e, t) {
                                    return e + t.placements.length
                                }), 1);
                                O = (0, r.pi)((0, r.pi)({}, O), ((y = {}).fb = L.nb, y.fi = M, y.fti = L.fti, y))
                            }
                            n.push(O)
                        }
                    })), n
                }
            },
            7900: function(e, t, n) {
                "use strict";
                n.d(t, {
                    k: function() {
                        return u
                    }
                });
                var r = n(2271),
                    i = n(6379),
                    o = n(4794),
                    a = n(4676);

                function u(e, t) {
                    if (!t) return e;
                    var n = t;
                    ! function(e, t) {
                        if (!t) return e;
                        for (var n = 0; n < t.length; n++) {
                            var r = e.search(t[n]);
                            if (r > -1) return e.substring(0, r)
                        }
                    }(e, n["truncate-at"]);
                    var u = (0, a.W)(e);
                    return u ? (function(e, t) {
                        t && delete e.host
                    }(u, n.host), function(e, t) {
                        if (t) {
                            var n = e.pathname;
                            if ("/" !== n) {
                                for (;
                                    "/" === n.substring(n.length - 1);) n = n.substring(0, n.length - 1);
                                e.pathname = n
                            }
                        }
                    }(u, n["trailing-dirsep"]), function(e, t) {
                        if (t && e.search) {
                            var n, a, u = {},
                                c = (0, o.jH)(e.search);
                            (0, r.cb)(t) ? a = new RegExp(t): n = t, (0, i.mt)(c, (function(e, t) {
                                (n && (null == n ? void 0 : n.indexOf(e)) > -1 || (null == a ? void 0 : a.test(e))) && (u[e] = t)
                            }));
                            var s = (0, o.nZ)(u);
                            s && (s = "?".concat(s)), e.search = s
                        }
                    }(u, n.query), function(e, t) {
                        if (t && e.hash)
                            if ("#" !== e.hash) {
                                var n = e.hash.substring(1);
                                (0, r.h0)(t) && t.filter((function(e) {
                                    return n.search(e) > -1
                                })).length > 0 || (0, r.cb)(t) && n.search(new RegExp(t)) > -1 || (e.hash = "")
                            } else e.hash = ""
                    }(u, n.fragment), u.toString()) : e
                }
            },
            7072: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Js: function() {
                        return s
                    },
                    Yt: function() {
                        return d
                    },
                    i9: function() {
                        return p
                    },
                    nX: function() {
                        return l
                    },
                    t$: function() {
                        return c
                    },
                    uq: function() {
                        return u
                    }
                });
                var r, i = n(4555),
                    o = n(3887),
                    a = n(9839);

                function u() {
                    if (r) return r;
                    var e = i.mb.navigator,
                        t = e.language ? [e.language] : [];
                    return r = e.languages || t
                }

                function c() {
                    if ((0, o.Mv)("pass-browser-url")) return s()
                }

                function s() {
                    return (a.L5.config.runtime.isAMP ? i.tp.context.location : i.mb.location).href
                }

                function l() {
                    var e = i.mb.document;
                    return Math.max(Math.max(e.body.scrollWidth, e.documentElement.scrollWidth), Math.max(e.body.offsetWidth, e.documentElement.offsetWidth), Math.max(e.body.clientWidth, e.documentElement.clientWidth))
                }

                function d() {
                    var e = i.mb.document;
                    return Math.max(Math.max(e.body.scrollHeight, e.documentElement.scrollHeight), Math.max(e.body.offsetHeight, e.documentElement.offsetHeight), Math.max(e.body.clientHeight, e.documentElement.clientHeight))
                }

                function p() {
                    return i.mb.hasOwnProperty("devicePixelRatio") ? i.mb.devicePixelRatio.toFixed(3) : -1
                }
            },
            5346: function(e, t, n) {
                "use strict";
                n.d(t, {
                    $N: function() {
                        return _
                    },
                    Ed: function() {
                        return p
                    },
                    G6: function() {
                        return h
                    },
                    I_: function() {
                        return f
                    },
                    N6: function() {
                        return b
                    },
                    el: function() {
                        return g
                    },
                    nx: function() {
                        return m
                    },
                    ts: function() {
                        return y
                    },
                    x3: function() {
                        return v
                    }
                });
                var r = n(7582),
                    i = n(9839),
                    o = n(3887),
                    a = n(6379),
                    u = n(862),
                    c = n(4866),
                    s = n(4400),
                    l = n(7900),
                    d = n(7072),
                    p = Math.random() <= .01;

                function f(e) {
                    var t, n, r;
                    if (!e) return {};
                    var i = e.cmpStatus;
                    return 3 === i ? ((t = {}).cex = e.cex, t) : 0 === i ? ((n = {}).cmps = i, n.ga = e.gdprApplies, n.cdb = e.consentDaisyBit || void 0, n.tcs = e.tcString || void 0, n.gwto = e.wasTimeout || void 0, n) : ((r = {}).cmps = i, r.cex = e.cex, r)
                }

                function m(e) {
                    if ((0, o.Mv)("pass-browser-url")) return (0, l.k)((0, d.Js)(), e).split(/[?#]/)[0]
                }

                function v(e) {
                    if (c.V[(0, s.G)(e.itemSourceType)] === c.V.home) return "_homepage_";
                    var t = e.itemSourceValue || i.L5.pageItemId;
                    return (0, l.k)(t, i.L5.config.publisher["prenormalize-item-id"])
                }

                function h(e) {
                    var t = "";
                    return (0, a.mt)(e, (function(n, r) {
                        var i = typeof r,
                            o = t ? "&" : "",
                            a = encodeURIComponent(n);
                        switch (i) {
                            case "string":
                            case "number":
                            case "boolean":
                                t += "".concat(o).concat(a, "=").concat(encodeURIComponent(e[n]));
                                break;
                            case "object":
                                t += "".concat(o).concat(a, "=").concat(encodeURIComponent(JSON.stringify(e[n])))
                        }
                    })), t
                }

                function g() {
                    var e = new Date,
                        t = e.getHours(),
                        n = e.getMinutes(),
                        r = e.getSeconds() + e.getMilliseconds() / 1e3;
                    return "".concat(t < 10 ? "0" : "").concat(t, ":").concat(n < 10 ? "0" : "").concat(n, ":").concat(r < 10 ? "0" : "").concat(r.toFixed(3))
                }

                function b() {
                    return (0, r.mG)(this, void 0, void 0, (function() {
                        var e;
                        return (0, r.Jh)(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return (0, o.Mv)("load-user-agent-data") ? [4, (0, u.k)()] : [2];
                                case 1:
                                    return (e = t.sent()) ? [2, {
                                        mobile: e.mobile,
                                        model: e.model,
                                        platform: e.platform,
                                        platformVersion: e.platformVersion,
                                        uaFullVersion: e.uaFullVersion
                                    }] : [2]
                            }
                        }))
                    }))
                }

                function _(e) {
                    var t = e.itemSourceType,
                        n = e.itemId,
                        r = e.placementsList,
                        i = "".concat(t, "=").concat(n, ","),
                        o = r.map((function(e) {
                            return "".concat(e.uip, "=").concat(e.uim)
                        }));
                    return o.sort(), i + o.join()
                }

                function y(e) {
                    var t = i.L5.config.publisher,
                        n = (0, r.ev)([], t.systemFlags.experimentID, !0),
                        a = e.pubExperiment,
                        u = (0, o.Cd)("publisher-experiments"),
                        c = a && u ? u[a] : null;
                    return c && n.push(c), n.join(",") || void 0
                }
            },
            4866: function(e, t, n) {
                "use strict";
                var r;
                n.d(t, {
                        V: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e._default_ = "", e.home = "h", e.homepage = "h", e.category = "c", e.article = "t", e.text = "t", e.search = "s", e.photo = "p", e.other = "o", e.content_hub = "z", e.video = "v"
                    }(r || (r = {}))
            },
            8312: function(e, t, n) {
                "use strict";
                var r;
                n.d(t, {
                        W: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e.video = "v", e.photo = "p", e.text = "t", e.mix = "m"
                    }(r || (r = {}))
            },
            8203: function(e, t, n) {
                "use strict";
                n.d(t, {
                    _T: function() {
                        return a
                    },
                    aK: function() {
                        return i
                    },
                    f7: function() {
                        return o
                    }
                });
                var r = /^[^{]*((?:[^]*)})[\s\)]*$/;

                function i(e) {
                    var t;
                    if (e.indexOf("TRC.callbacks.mute()") > -1) return (t = {}).isMuted = !0, t.vl = [], t;
                    var n = e.match(r);
                    if (!n) throw new Error("Can't validate TRC response.");
                    try {
                        return o(JSON.parse(n[1]))
                    } catch (e) {
                        throw new Error("TRC response not a valid JSON.parse")
                    }
                }

                function o(e) {
                    return e.trc
                }

                function a(e, t) {
                    if (e) {
                        var n = e.split(":")[1].toLocaleLowerCase();
                        return t.replace("<dc>", n)
                    }
                }
            },
            7660: function(e, t, n) {
                "use strict";
                n.d(t, {
                    D: function() {
                        return o
                    },
                    d: function() {
                        return a
                    }
                });
                var r = n(6379),
                    i = n(1591);

                function o(e) {
                    var t;
                    e.features = ((t = {}).feed = (0, i.it)(e.feeds), t.widget = (0, i.it)(e.widgets), t.exploreMore = !!e.exploreMore, t.videoSM = function(e) {
                        var t = !1;
                        return (0, r.mt)(e.feeds, (function(e, n) {
                            t || (t = n.vsm)
                        })), t
                    }(e), t.videoTag = function(e) {
                        var t = e.originalResponse[0].vl;
                        return (null == t ? void 0 : t.filter((function(e) {
                            return !!e.vtag
                        })).length) > 0
                    }(e), t.nextUp = (0, i.it)(e.nextUp), t.vignette = (0, i.it)(e.vignette), t.videoReel = (0, i.it)(e.videoReel), t.hp4u = (0, i.it)(e.organicPersonalization), t.protectedAudience = !!e.protectedAudience, t)
                }

                function a(e, t) {
                    if (!(0, i.it)(e)) return t || {};
                    var n = {};
                    return (0, r.mt)(e, (function(e, r) {
                        n[e] = t[e] || r || !1
                    })), n
                }
            },
            734: function(e, t, n) {
                "use strict";
                n.d(t, {
                    y7: function() {
                        return T
                    },
                    W3: function() {
                        return C
                    },
                    eo: function() {
                        return I
                    },
                    F_: function() {
                        return k
                    }
                });
                var r = n(9790),
                    i = n(9319),
                    o = n(9707),
                    a = n(2188),
                    u = n(8824),
                    c = n(3887),
                    s = n(2271),
                    l = n(5281),
                    d = n(6379),
                    p = n(1591),
                    f = n(7582),
                    m = {
                        markup: "CCPA Notice",
                        href: "https://ccparequest.taboola.com",
                        enableScrolling: "yes",
                        classList: ["tbl-ccpa"],
                        style: "",
                        inlineStyle: "",
                        location: "beforeend",
                        renderOnce: !0,
                        placement: ""
                    };

                function v(e) {
                    return (0, p.td)(e.voil, !1) || (0, c.Mv)("visible-on-item-level", !1)
                }
                var h = n(8203),
                    g = n(7660),
                    b = n(6624),
                    _ = n(9725),
                    y = n(891),
                    w = n(5344),
                    x = n(2143),
                    E = {
                        filterResponse: function(e, t) {
                            return t
                        },
                        mergeResponseSummary: function(e, t) {
                            var n = e.protectedAudience,
                                r = t.protectedAudience;
                            return n && r ? (0, f.pi)((0, f.pi)({}, n), r) : n || r
                        },
                        parseResponse: function(e) {
                            var t = e.pac || {};
                            return (0, w.Z)((0, f.pi)((0, f.pi)({}, t), {
                                _ID: "protectedAudience",
                                entityType: 10
                            }))
                        },
                        updateCache: function(e, t) {
                            (0, x.eL)(e.protectedAudience, t)
                        },
                        updateRootResponseCache: function() {}
                    },
                    T = {
                        hasContent: !1,
                        hasFeeds: !1
                    };

                function C(e) {
                    var t, n, s, w = (0, d.I8)(e);
                    e.vpl && l.Y.emit("vp_l", {
                        list: e.vpl
                    });
                    var x = r.h.parseResponse(w),
                        T = y.W.parseResponse(w),
                        C = i.f.parseResponse(w),
                        k = o.m.parseResponse(w),
                        I = a.s.parseResponse(w),
                        L = _.q.parseResponse(w),
                        O = u.$.parseResponse(w),
                        M = function(e) {
                            if (e) return (0, f.pi)((0, f.pi)({}, m), e)
                        }(function(e, t) {
                            var n;
                            return null === (n = e.cga) || void 0 === n ? void 0 : n.ccpa
                        }(e)),
                        N = E.parseResponse(w),
                        P = (0, p.it)(C),
                        D = !!x,
                        A = (0, p.it)(O),
                        U = function(e) {
                            var t = e.vl;
                            return null == t ? void 0 : t.some((function(e) {
                                var t;
                                return null === (t = e.v) || void 0 === t ? void 0 : t.length
                            }))
                        }(e),
                        F = {
                            originalResponse: [e],
                            hasResponseLoaded: !0,
                            publisherId: e.pi,
                            events: R(e),
                            userData: (t = {
                                sessionId: e.si || "",
                                sessionData: e.sd || "",
                                userId: e.ui || "",
                                platform: e.plc || "OTHR",
                                countryCode: e.cc,
                                dataCenterRoute: e.route,
                                trcEventDomain: (0, h._T)(e.route, (0, c.Cd)("trc-event-route-template"))
                            }, t.wi = e.wi || void 0, t.lspb = e.lspb || void 0, t.cpb = e.cpb || void 0, t.stp = (null === (n = e.stp) || void 0 === n ? void 0 : n.map((function(e) {
                                return {
                                    url: e
                                }
                            }))) || [], t.jst = (null === (s = e.jst) || void 0 === s ? void 0 : s.map((function(e) {
                                return {
                                    url: e
                                }
                            }))) || [], t.consentApproved = !(0, p.td)(e.cm, !1), t.ccpa = M, t),
                            testAndExperiment: {
                                hasVariantPerPlacementFlag: (0, p.td)(e.uvpw),
                                testVariant: e.t || "",
                                testData: e.td || "",
                                experimentVariants: e.evh || "",
                                testVariantsMap: (0, b.L_)(e)
                            },
                            eventRouteOut: e.el2r || [],
                            translations: e.tslt,
                            hasCacheBuster: (0, p.td)(e.lfr, !1),
                            hasContent: U,
                            noContentReason: S(e, U),
                            isItemLevelVisible: v(e),
                            features: {},
                            feeds: C,
                            exploreMore: x,
                            widgets: O,
                            organicPersonalization: T,
                            nextUp: k,
                            vignette: I,
                            hasFeeds: P,
                            hasExploreMore: D,
                            hasWidgets: A,
                            hasNextBatch: P || D,
                            videoReel: L,
                            protectedAudience: N
                        };
                    return (0, g.D)(F), F
                }

                function S(e, t) {
                    return function(e) {
                        return !!e.isMuted
                    }(e) ? "MUTE" : e.vl ? t ? "" : "NO_ITEMS" : "ERROR"
                }

                function R(e) {
                    var t, n, r = {},
                        i = (null === (n = null === (t = e.vl) || void 0 === t ? void 0 : t[0]) || void 0 === n ? void 0 : n.ri) || void 0;
                    return i && (r.requestId = i), r
                }

                function k(e) {
                    return (0, s.r8)(null == e ? void 0 : e.userData.userId)
                }

                function I() {
                    return {
                        userData: {},
                        testAndExperiment: {}
                    }
                }
            },
            2057: function(e, t, n) {
                "use strict";
                n.d(t, {
                    $: function() {
                        return p
                    }
                });
                var r = n(7582),
                    i = n(8824),
                    o = n(9319),
                    a = n(9790),
                    u = n(9707),
                    c = n(2188),
                    s = n(9725),
                    l = n(891),
                    d = n(7660);

                function p(e, t) {
                    var n, p = i.$.mergeResponseSummary(e, t),
                        m = o.f.mergeResponseSummary(e, t),
                        v = a.h.mergeResponseSummary(e, t),
                        h = u.m.mergeResponseSummary(e, t),
                        g = c.s.mergeResponseSummary(e, t),
                        b = s.q.mergeResponseSummary(e, t),
                        _ = l.W.mergeResponseSummary(e, t),
                        y = e.userData,
                        w = t.userData;
                    return (0, r.pi)((0, r.pi)((0, r.pi)({}, e), t), {
                        originalResponse: (0, r.ev)((0, r.ev)([], e.originalResponse || [], !0), t.originalResponse || [], !0),
                        events: (0, r.pi)((0, r.pi)({}, e.events), t.events),
                        userData: (0, r.pi)((0, r.pi)((0, r.pi)({}, y), w), (n = {}, n.stp = f((null == y ? void 0 : y.stp) || [], (null == w ? void 0 : w.stp) || []), n.jst = f((null == y ? void 0 : y.jst) || [], (null == w ? void 0 : w.jst) || []), n)),
                        testAndExperiment: (0, r.pi)((0, r.pi)({}, e.testAndExperiment), t.testAndExperiment),
                        widgets: p,
                        hasFeeds: Object.keys(m).length > 0,
                        feeds: m,
                        nextUp: h,
                        vignette: g,
                        videoReel: b,
                        hasWidgets: Object.keys(p).length > 0,
                        hasExploreMore: !!v,
                        exploreMore: v,
                        hasContent: e.hasContent || t.hasContent,
                        hasCacheBuster: e.hasCacheBuster || t.hasCacheBuster,
                        isItemLevelVisible: e.isItemLevelVisible || t.isItemLevelVisible,
                        hasNextBatch: e.hasNextBatch || t.hasNextBatch,
                        organicPersonalization: _,
                        features: (0, d.d)(e.features || {}, t.features)
                    })
                }

                function f(e, t) {
                    if (e.length > 0 && 0 === t.length) return e;
                    var n = {};
                    return (0, r.ev)((0, r.ev)([], e, !0), t, !0).forEach((function(e) {
                        var t;
                        n[t = e.url] || (n[t] = e.used)
                    })), Object.keys(n).map((function(e) {
                        return {
                            url: e,
                            used: n[e]
                        }
                    }))
                }
            },
            6624: function(e, t, n) {
                "use strict";
                n.d(t, {
                    L_: function() {
                        return u
                    },
                    Lg: function() {
                        return c
                    },
                    m_: function() {
                        return d
                    },
                    vd: function() {
                        return s
                    }
                });
                var r = n(7582),
                    i = n(3887),
                    o = n(1283),
                    a = n(6379);

                function u(e) {
                    if (!(0, i.Cd)("enable-experiments-variant-id-event")) return {};
                    var t = e.evi || {},
                        n = {};
                    return (0, a.mt)(o.S, (function(e, r) {
                        t[r] && (n[d(r)] = t[r].split("|")[1])
                    })), n
                }

                function c(e) {
                    if (e && (0, i.Cd)("store-userid-first-party-cookie")) return e
                }

                function s(e) {
                    var t;
                    return (0, r.pi)((0, r.pi)({}, e), {
                        userData: (0, r.pi)((0, r.pi)({}, e.userData), (t = {}, t.stp = l(e.userData.stp), t.jst = l(e.userData.jst), t))
                    })
                }

                function l(e) {
                    return e.map((function(e) {
                        return {
                            url: e.url,
                            used: !0
                        }
                    }))
                }

                function d(e) {
                    return "tvi".concat(e)
                }
            },
            1283: function(e, t, n) {
                "use strict";
                var r, i;
                n.d(t, {
                        S: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e.L2 = "2", e.L6 = "6", e.L48 = "48", e.L50 = "50"
                    }(r || (r = {})),
                    function(e) {
                        e.L2 = "tvi2", e.L6 = "tvi6", e.L48 = "tvi48", e.L50 = "tvi50"
                    }(i || (i = {}))
            },
            2992: function(e, t, n) {
                "use strict";
                n.d(t, {
                    h: function() {
                        return Y
                    },
                    X: function() {
                        return K
                    }
                });
                var r = n(4362),
                    i = n(9839),
                    o = n(3887),
                    a = n(2271),
                    u = n(5344),
                    c = n(5281),
                    s = n(1553),
                    l = n(8404),
                    d = n(1591),
                    p = n(1869);
                var f = n(3239),
                    m = n(7863),
                    v = n(3595),
                    h = n(7341),
                    g = n(8951);
                var b = null;
                var _, y = n(9685),
                    w = n(1602),
                    x = n(983),
                    E = n(6379),
                    T = n(4794),
                    C = n(5217),
                    S = (0, T.me)("//cdn.taboola.com/libtrc/static/thumbnails/759bc49732394dde468c8d65a464e1a4.png"),
                    R = 300,
                    k = "tb_expo_img",
                    I = [
                        [1, 2],
                        [1, 1.9],
                        [1, 1.8],
                        [9, 16],
                        [1, 1.7],
                        [1, 1.6],
                        [1, 1.5],
                        [1, 1.4],
                        [3, 4],
                        [1, 1.3],
                        [1, 1.2],
                        [1, 1.1],
                        [1, 1],
                        [1, .9],
                        [6, 5],
                        [1, .8],
                        [4, 3],
                        [1, .7],
                        [3, 2],
                        [1, .6],
                        [16, 9],
                        [2, 1]
                    ].map((function(e) {
                        return e[0] / e[1]
                    })).sort(),
                    L = 2.5,
                    O = ((_ = {}).auto = "f_auto", _.jpg = "f_jpg", _.lossy = "fl_lossy", _.png = "f_png", _.gif = "fl_lossy%2Cf_gif", _);

                function M(e) {
                    return O[e] || O.auto
                }
                var N = null,
                    P = "",
                    D = "",
                    A = "";

                function U(e) {
                    var t = e.replace("{domain}", (0, o.Cd)("image-url-domain")).replace("{q}", (0, o.Cd)("image-quality").toString()).replace("{type}", M((0, o.Cd)("image-url-type")));
                    return (0, T.me)(t)
                }

                function F(e) {
                    var t = e.placement.getModeClientProperty("image-url-prefix") || (0, o.Cd)("image-url-prefix");
                    return P || (P = U(t)), P
                }

                function q(e) {
                    var t = e.placement.getModeClientProperty("rtb-image-url-prefix") || (0, o.Cd)("rtb-image-url-prefix");
                    return D || (D = U(t)), D
                }

                function V(e) {
                    var t = e.placement.getModeClientProperty("gif-url-prefix") || (0, o.Cd)("gif-url-prefix");
                    return A || (A = U(t)), A
                }

                function B(e, t) {
                    var n = (0, o.Cd)("custom-image-size-round-value"),
                        r = function(e) {
                            var t = F;
                            return e.isRTB ? t = q : e.isGifImage && (t = V), t(e)
                        }(e),
                        a = e.placement.getModeClientProperty("images-radius");
                    a && (r = function(e, t, n) {
                        return e ? function(e, t) {
                            return e.replace("f_gif", "f_gif%2Cr_".concat(t))
                        }(t, n) : function(e, t) {
                            var n = M((0, o.Cd)("image-url-type"));
                            return e.replace("".concat(n, "%2C"), "").replace(/fetch\//, "fetch/f_png%2Cr_".concat(t, "%2C"))
                        }(t, n)
                    }(e.isGifImage, r, a)), e.bannerAsNative && (r = function(e, t) {
                        return "".concat(e, "e_blur:").concat(t, "/")
                    }(r = function(e) {
                        return e.replace("/t_tbl-cnd", "")
                    }(r), R));
                    var u = function(e) {
                            var t = e.placement.getModeClientProperty("image-size-factor");
                            return (0, d.td)(e.placement.getModeClientProperty("use-dpr-images")) && i.L5.config.runtime.isHighDensity && (t = e.placement.getModeClientProperty("image-dpr-factor") || t), t
                        }(e),
                        c = function(e) {
                            var t = e.placement.getModeClientProperty;
                            return [t("image-min-width"), t("image-max-width")]
                        }(e),
                        s = c[0],
                        l = c[1],
                        p = function(e, t) {
                            var n = t.height / t.width,
                                r = e.placement.getModeClientProperty("image-allowed-ratio-diff"),
                                i = Math.abs(n - r),
                                o = 0;
                            return I.some((function(e) {
                                return e >= i && (o = e, !0)
                            })), o || I[0]
                        }(e, t),
                        f = Math.min(Math.ceil(Math.max(t.width * u, s) / n) * n, l),
                        m = Math.max(Math.min(p, L), 1 / L),
                        v = Math.ceil(f * m);
                    return r = r.replace("{w}", f.toString()).replace("{h}", v.toString()), r += function(e) {
                        for (var t = 0, n = 0, r = "", i = 0, o = "".concat(e), a = o.length; i < a;) {
                            var u = o.charCodeAt(i),
                                c = null;
                            u < 128 ? n++ : c = u > 127 && u < 2048 ? String.fromCharCode(u >> 6 | 192, 63 & u | 128) : String.fromCharCode(u >> 12 | 224, u >> 6 & 63 | 128, 63 & u | 128), null !== c && (n > t && (r += o.slice(t, n)), r += c, t = n = i + 1), i++
                        }
                        return n > t && (r += o.slice(t, a)), escape(r)
                    }(e.imageUrl), {
                        taboolaUrl: r = (0, C.mq)(r, function() {
                            if (N) return N;
                            N = {};
                            var e = i.L5.config.publisher.systemFlags,
                                t = e.imageExternal;
                            t && (N[k] = t);
                            var n = e.imageExternals;
                            return n && (0, E.mt)(n, (function(e, t) {
                                N["".concat(k, "_").concat(e)] = t
                            })), N
                        }()),
                        publisherUrl: (0, T.me)(e.imageUrl),
                        defaultUrl: S
                    }
                }
                var j = n(5705);

                function H(e, t) {
                    var n = (0, d.td)(t["is-syndicated"], !1),
                        r = (0, d.td)(t["is-native"], !1),
                        i = (0, d.td)(t["is-in-network"], !1),
                        o = (0, d.td)(t["is-dc"], !1),
                        a = n || r || i,
                        c = {
                            entityType: 5,
                            _ID: t["item-id"]
                        },
                        s = (0, u.Z)(c);
                    return s.originalCard = t, s.originalCard.placement = e.uuip, s.placement = e, s.taboolaId = t["item-id"], s.organicId = a ? "" : t.id, s.imageUrl = t.thumbnail, s.isGifImage = (0, d.td)(t["is-gift"], !1), s.imageSize = function(e) {
                        if (!e) return {
                            width: 0,
                            height: 0
                        };
                        var t = e.split("x"),
                            n = t[0],
                            r = t[1];
                        return {
                            width: parseInt(n),
                            height: parseInt(r)
                        }
                    }(t["thumb-size"]), s.clickUrl = t.url, s.title = (0, y._R)(t.title), s.sourceType = t.type, s.logoURL = t.logo || "", s.logoType = t["logo-type"] || "square", s.publishedData = (0, x.Y)(t["published-date"]), s.brandingName = t["branding-text"] || "", s.signature = t.sig, s.IsSyndicated = n, s.isSponsored = a, s.isNative = r, s.isNetwork = i, s.isOrganic = !a && !i && !r, s.isEditorial = o, s.isNoFollow = !0, s.isRTB = (0, d.td)(t["is-rtb"], !1), s.bannerAsNative = (0, d.td)(t.rban, !1), s.advertiser = t.publisher, s.category = t.category || "", s.description = (0, y._R)(t.description), s.pixelsTracking = t.itp || [], s.viewabilityTags = t["viewability-tags"] || [], s.visibleEventSent = !1, s.getEventClick = h.tW.bind(null, s), s.getImageUrls = B.bind(null, s), s.motionAdURL = t["pvideo-url"], s.ctaText = t["cta-text"], s.auctionEstimate = (0, d.tl)(t.aes), s.isAppInstall = (0, d.td)(t["is-app-install"], !1), s.starRating = (0, d.tl)(t["stars-rating"]) || 0, s.brandingUrl = t["branding-url"], s.reportTracking = function(e) {
                        ! function(e, t) {
                            e.pixelsTracking.filter((function(e) {
                                return e.t === t && !e.used
                            })).forEach((function(e) {
                                e.used = !0, (0, j.hz)(e.u)
                            }))
                        }(s, e)
                    }, s.setItemAsVisible = function() {
                        s.visibleEventSent = !0
                    }, t.plink && (s.adChoice = {
                        link: t.plink,
                        type: t["adc-type"] || "HOVER"
                    }), s
                }
                var z = n(2379),
                    W = n(253),
                    G = n(1178);

                function Y(e, t) {
                    var n = e.m,
                        r = e.fpl || e.uip;
                    if (n || r) {
                        var o = function(e, t) {
                            var n = e.uvpw;
                            return !(0, a.r8)(n) && (0, d.td)(n) ? t : e.t
                        }(t, e.t);
                        if (n) return Q(n, o);
                        var u = i.L5.optionsSummary.placements.filter((function(e) {
                            return e.placementName === r
                        }))[0];
                        return u ? Q(u.modeName, o) : void 0
                    }
                }

                function Q(e, t) {
                    if (!t) return e;
                    var n = "ab_".concat(e, "_").concat(t);
                    return i.L5.config.publisher.modes[n] ? n : e
                }

                function K(e, t) {
                    var n, _, x;
                    e.uip || (0, s.yN)("Invalid placement in server response ".concat(e));
                    var T = Y(e, t),
                        C = function(e) {
                            if (e) return e === r.xM ? {
                                modeName: r.xM
                            } : i.L5.config.publisher.modes[e]
                        }(T);
                    C || e.js || (0, s.yN)("Placement doesn't have Publisher Mode Config: ".concat(T));
                    var S = e.vtag,
                        R = {},
                        k = {
                            _ID: e.uip + (0, d.D1)({
                                prefix: "_"
                            }),
                            entityType: 3,
                            mode: C
                        };
                    if (e.cs) {
                        var I = e.uuip || e.uip;
                        c.Y.emit("vp_cs", {
                            data: e.cs,
                            placementName: I
                        })
                    }
                    var L, O = (0, u.Z)(k);
                    O.ri = e.ri, O.uuip = e.uuip, O.uip = e.uip, O.m = T || "", O.ppb = e.ppb, O.fb = e.fb ? parseInt(e.fb) : -1, O.wi = t.wi, O.po = (L = e.po, (0, a.cb)(L) ? (/^\s*\{.*\}\s*$/.test(L) || (L = "{".concat(L, "}")), L.indexOf("function") > -1 ? (0, d.hX)("(".concat(L, ")")) : (0, d.Cy)(L)) : L), O.pcp = e.pcp, O.hpl = e.hpl, O.hps = (null === (_ = e.hps) || void 0 === _ ? void 0 : _.split(",")) || [], O.listId = (0, W.Z)(null === (x = i.L5.optionsSummary) || void 0 === x ? void 0 : x.itemSourceType, (0, G.L)(O)), O.thirdPartyCard = function(e) {
                        if ((0, d.td)(e.ifr, !1)) return {
                            isFriendly: (0, d.td)(e.fifr, !1),
                            url: e.url,
                            configuration: e.config,
                            dimensions: e.cd
                        }
                    }(e), S && (O.vtag = S), O.eventSent = ((n = {}).available = !1, n.visible = 0, n), O.modeGroupsData = function(e, t) {
                        var n, r, i, o = e.v,
                            a = t.m,
                            c = {
                                _ID: t._ID + (0, d.D1)(),
                                modeName: a,
                                placementData: t,
                                entityType: 4
                            },
                            s = (0, u.Z)(c);
                        s.items = (o || []).map((function(e) {
                            return H(t, e)
                        })), s.contentType = (n = s.items, r = !1, i = !1, n.forEach((function(e) {
                            e.isSponsored || e.IsSyndicated || e.isNative || e.isNetwork ? r = !0 : e.isOrganic && (i = !0)
                        })), r && i ? "hybrid" : r ? "sponsored" : "organic"), s.modeGroupsList = [];
                        var l = e.multiWidget;
                        return l && (s.modeGroupsList = J(l, t, o), s.flexDirection = l.orientation, s.gap = l.gap, s.flexSize = l.flexSize), s
                    }(e, O);
                    var M = $(O.modeGroupsData);
                    return (0, E.Io)(O, "items", M), O.sendEventAvailable = function() {
                            return O.eventSent.available ? l.e.resolve("") : (O.eventSent.available = !0, (0, p.m)("UiItemsRendered", O.items.length), function(e) {
                                (0, m.Wt)("firstAvailable");
                                var t = (0, h.ee)(e);
                                if (!t) return l.e.resolve("");
                                if (null === b && (b = "disable" !== (0, o.Cd)("bulk-available-events-strategy") && (0, o.Mv)("send-event-as-post")), b) {
                                    var n = (0, o.Cd)("bulk-available-events-delay");
                                    return (0, g._)("bulk", t, n)
                                }
                                return (0, v.xh)(t)
                            }(O))
                        }, O.sendEventVisible = function() {
                            return function(e) {
                                var t;
                                return i.L5.responseSummary.isItemLevelVisible ? !(null === (t = e.items) || void 0 === t ? void 0 : t.every((function(t) {
                                    return e.isItemVisible(t._ID)
                                }))) : 0 === e.eventSent.visible
                            }(O) ? (O.eventSent.visible++, function(e) {
                                var t = function(e) {
                                    var t, n;
                                    return {
                                        variant: i.L5.responseSummary.testAndExperiment.testVariant || null,
                                        container: null === (t = i.L5.getEntityCustomData(e)) || void 0 === t ? void 0 : t.element,
                                        placement: e.uip,
                                        baseMode: e.m,
                                        mode: e.m,
                                        itemCount: e.items.length,
                                        items: (n = e.items, n.map((function(e, t) {
                                            return {
                                                slot: t,
                                                id: e._ID,
                                                url: e.clickUrl,
                                                title: e.title,
                                                type: (n = e, n.IsSyndicated ? "sponsored" : n.isNetwork ? "exchange" : n.isNative ? "native" : "organic")
                                            };
                                            var n
                                        })))
                                    }
                                }(e);
                                (0, f.F)("visible", t), (0, m.Wt)("firstVisible");
                                var n = (0, h.YE)(e);
                                return n ? (0, v.xh)(n, {
                                    sendByBeacon: !1
                                }) : l.e.resolve("")
                            }(O)) : l.e.resolve("")
                        }, O.getModeClientProperty = function(e) {
                            var t, n, r;
                            return null !== (r = null !== (n = null === (t = O.po) || void 0 === t ? void 0 : t[e]) && void 0 !== n ? n : (0, o.tt)(O.m, e)) && void 0 !== r ? r : void 0
                        }, O.setItemAsVisible = function(e) {
                            R[e._ID] = !0
                        }, O.isItemVisible = function(e) {
                            return R[e._ID] || !1
                        },
                        function(e, t) {
                            var n;
                            if (t.js) return e.type = 4, void
                            function(e, t) {
                                var n = t.js;
                                (0, w.LO)(n, "jsContent is undefined"), e.decodedJS = (0, y._R)(n), e.width = t.w, e.height = t.h
                            }(e, t);
                            var r = t.es;
                            if (r) return e.type = 5, void
                            function(e, t) {
                                e.containerSelector = t
                            }(e, r);
                            if (null === (n = t.pcp) || void 0 === n ? void 0 : n.tps) e.type = 3;
                            else if (t.hpl) e.type = 6;
                            else {
                                var i = t.v,
                                    o = t.multiWidget;
                                i ? i.length > 0 || o ? e.type = 1 : e.type = 2 : e.type = 0
                            }
                        }(O, e), O.psbc = function(e) {
                            return e.psbc
                        }(e), O
                }

                function J(e, t, n) {
                    var r = [];
                    return e.children.forEach((function(i) {
                        var o = i.name,
                            a = {
                                _ID: t._ID + (0, d.D1)(),
                                modeName: o,
                                placementData: t,
                                entityType: 4
                            },
                            c = (0, u.Z)(a);
                        c.items = function(e, t, n) {
                            var r = (0, z.u)(e);
                            return t.splice(0, r).map((function(e) {
                                return H(n, e)
                            }))
                        }(o, n || [], t), c.modeGroupsList = [], c.gap = e.gap, c.flexDirection = e.orientation, c.flexSize = i.flexSize, i.children && (c.modeGroupsList = J(i, t, n), c.flexDirection = i.orientation), r.push(c)
                    })), r
                }

                function $(e) {
                    return e.items ? e.items : e.modeGroupsList.reduce((function(e, t) {
                        return t.modeGroupsList.length > 0 && e.push.apply(e, $(t)), e.push.apply(e, t.items), e
                    }), [])
                }
            },
            2379: function(e, t, n) {
                "use strict";
                n.d(t, {
                    u: function() {
                        return c
                    }
                });
                var r = n(4362),
                    i = n(878),
                    o = n(4555),
                    a = n(3887),
                    u = n(2271);

                function c(e) {
                    if (e === r.xM || e === i.EU) return 0;
                    var t = o.mb.innerWidth,
                        n = (0, a.tt)(e, "mode-is-responsive"),
                        c = (0, a.tt)(e, "auto-size"),
                        s = (0, a.tt)(e, "rows") || 1;
                    if (n) {
                        var l = (0, a.tt)(e, "responsive-rules");
                        if (null == l ? void 0 : l.length) {
                            var d = function(e, t) {
                                var n = 0;
                                return e.forEach((function(e) {
                                    var r = (e.rows || 1) * (e.cells || 1);
                                    (t >= e.minWidth || function(e) {
                                        var t = e.maxWidth ? " and (max-width: ".concat(e.maxWidth, "px)") : "",
                                            n = "(min-width: ".concat(e.minWidth, "px)").concat(t);
                                        if (window.matchMedia(n).matches) return !0;
                                        if ((0, u.r8)(e.minWidth)) return !1;
                                        var r = e.maxWidth ? " and (max-height: ".concat(e.maxWidth, "px)") : "",
                                            i = "screen and (min-height: ".concat(e.minWidth, "px)").concat(r, " and (orientation: portrait)");
                                        return !!window.matchMedia(i).matches
                                    }(e)) && r > n && (n = (e.rows || 1) * (e.cells || 1))
                                })), n
                            }(l, t);
                            if (!(0, u.r8)(d)) return d
                        }
                    }
                    var p = 0,
                        f = (0, a.tt)(e, "responsive-extra-columns");
                    return f && (p = f * s), c && 0 !== t ? function(e, t, n, r) {
                        var i, o = (0, a.tt)(e, "auto-size-rules");
                        if (!o) return 0;
                        for (var u = o.length - 1; u >= 0; u--) {
                            var c = o[u],
                                s = parseInt(c.minWc),
                                l = parseInt(c.maxWc);
                            if (s <= t && t <= l) {
                                i = c;
                                break
                            }
                        }
                        return i ? n <= 1 ? i.n + r : i.n * n + r : 0
                    }(e, t, s, p) : ((0, a.tt)(e, "list-size") || 0) + p
                }
            },
            5217: function(e, t, n) {
                "use strict";
                n.d(t, {
                    GO: function() {
                        return l
                    },
                    Vj: function() {
                        return s
                    },
                    mq: function() {
                        return d
                    }
                });
                var r = n(9839),
                    i = n(3887),
                    o = n(1602),
                    a = n(2630),
                    u = n(4794),
                    c = n(5346);

                function s(e, t) {
                    var n = (null === r.L5 || void 0 === r.L5 ? void 0 : r.L5.config.publisher.publisherName) || (0, a.J)();
                    return (0, u.me)("//".concat(function(e, t) {
                        return t || (r.L5 ? r.L5.eventsRouteOut.indexOf(e) > -1 ? r.L5.userData.trcEventDomain || (0, i.Cd)("default-event-route") : (0, i.Cd)("requests-domain") : ((0, o.DI)("debug" === e), "trc-events.taboola.com"))
                    }(e, t.domain), "/").concat(n, "/").concat(function(e) {
                        switch (e) {
                            case "json":
                                return "trc/3/json";
                            case "available":
                                return "log/3/available";
                            case "bulk":
                                return "log/3/bulk";
                            case "visible":
                                return "log/3/visible";
                            case "click":
                                return "log/3/click";
                            case "abtests":
                                return "log/3/abtests";
                            case "debug":
                                return "log/2/debug";
                            case "perf":
                                return "log/3/perf";
                            case "social":
                                return "log/3/social";
                            case "SupplyFeature":
                                return "log/3/supply-feature";
                            case "rtb-win":
                                return "log/3/rtb-win";
                            case "metrics":
                                return "log/3/metrics";
                            case "bulk-metrics":
                                return "log/3/bulk-metrics";
                            case "external-revenue":
                                return "log/3/external-revenue";
                            case "pubs-generic":
                                return "log/3/pubs-generic";
                            case "swap-data":
                                return "log/3/swap-data"
                        }
                        throw new Error("Type not exist")
                    }(e), "?").concat((0, c.G6)(t.url)))
                }

                function l(e) {
                    return -1 === e.indexOf("?") ? "?" : "&"
                }

                function d(e, t) {
                    var n = l(e),
                        r = (0, c.G6)(t);
                    return r ? e + n + r : e
                }
            },
            9790: function(e, t, n) {
                "use strict";
                n.d(t, {
                    h: function() {
                        return w
                    }
                });
                var r = n(7582),
                    i = n(9839),
                    o = n(6379),
                    a = n(3854),
                    u = n(3265),
                    c = n(7429),
                    s = n(1602),
                    l = n(3887),
                    d = n(4583),
                    p = n(1085),
                    f = "",
                    m = "",
                    v = "#0279f5",
                    h = "header",
                    g = "85%",
                    b = !0,
                    _ = !0;
                var y = n(2963),
                    w = {
                        updateCache: function(e, t) {
                            var n = e.hasExploreMore,
                                r = e.exploreMore;
                            if (n && r) {
                                var i = r.entity.fpl;
                                (0, c.Bs)(i, t)
                            }
                        },
                        updateRootResponseCache: function(e, t, n) {
                            E(n) && t.f && (0, c.$z)(e, t.r, n)
                        },
                        filterResponse: function(e, t) {
                            var n, r = e.features.exploreMore,
                                a = i.L5.config.runtime.supportedFeatures.exploreMore;
                            if (!r || !a) return t;
                            var u = t.f,
                                c = null === (n = e.exploreMore) || void 0 === n ? void 0 : n._ID;
                            return c && (delete u[c], t.vl = (0, y.yh)(c, t.vl)), (0, o.z)(u) && (0, y.UD)(t), t
                        },
                        parseResponse: function(e) {
                            var t = e.f || {};
                            if (!(0, o.z)(t)) {
                                var n = (0, o.lw)(t, (function(e, t) {
                                        return !!t.exm || E(e)
                                    })),
                                    r = n.validItems,
                                    c = n.invalidItems;
                                if (!(0, o.z)(r)) {
                                    var s = Object.keys(r)[0],
                                        y = r[s],
                                        w = y.exm,
                                        x = !!w,
                                        T = (0, a.$x)(e, s, y),
                                        C = w && function(e) {
                                            try {
                                                return function(e) {
                                                    var t = e.extraData,
                                                        n = e.feedData;
                                                    return {
                                                        publisherId: e.publisherId,
                                                        title: t.title || f,
                                                        css: n.css || m,
                                                        backgroundColor: t.backgroundColor || v,
                                                        headerSelector: t.headerSelector || h,
                                                        feedContainerWidth: t.feedContainerWidth || g,
                                                        enableHideHeader: ((0, l.Mv)("explore-more-enable-hide-all-but-header") || b) && !(0, d.c)("desktop"),
                                                        enablePositionCorrection: ((0, l.Mv)("explore-more-enable-position-correction") || _) && !(0, d.c)("desktop"),
                                                        placement: t.placement,
                                                        container: t.container
                                                    }
                                                }(e)
                                            } catch (e) {
                                                return console.error("error at parsing explore more data", e), (0, p.F)()
                                            }
                                        }({
                                            feedData: T,
                                            extraData: w,
                                            publisherId: e.pi
                                        }),
                                        S = {
                                            _ID: s,
                                            entityType: 6,
                                            entity: T,
                                            exploreMoreOptions: C
                                        };
                                    return x && function(e, t) {
                                        var n = function(e) {
                                            var t = (0, u.U)("div");
                                            return t.id = e.container, t
                                        }(t);
                                        i.Un.appendEntityCustomData({
                                            entity: e,
                                            element: n
                                        })
                                    }(S, w), e.f = c, e.vl = e.vl.filter((function(e) {
                                        var t = e.fpl;
                                        return t !== s || !t
                                    })), S
                                }
                            }
                        },
                        mergeResponseSummary: function(e, t) {
                            var n = e.exploreMore,
                                i = t.exploreMore;
                            if (!n || !i) return n || i;
                            (0, s.DI)(2 === n.entity.entityType, "Explore More is not Feed type");
                            var o = (0, a.VC)(n.entity, i.entity);
                            return (0, r.pi)((0, r.pi)({}, n), {
                                entity: o,
                                exploreMoreOptions: n.exploreMoreOptions || i.exploreMoreOptions
                            })
                        }
                    },
                    x = "Explore More";

                function E(e) {
                    return e === x
                }
            },
            9319: function(e, t, n) {
                "use strict";
                n.d(t, {
                    f: function() {
                        return d
                    }
                });
                var r = n(9839),
                    i = n(1602),
                    o = n(5344),
                    a = n(6379),
                    u = n(7429),
                    c = n(3854),
                    s = n(2963),
                    l = n(3150),
                    d = {
                        updateCache: function(e, t) {
                            (0, a.mt)(e.feeds, (function(e) {
                                (0, u.Bs)(e, t)
                            }))
                        },
                        updateRootResponseCache: function() {},
                        filterResponse: function(e, t) {
                            var n = e.features.feed,
                                i = r.L5.config.runtime.supportedFeatures.feed;
                            if (!n || !i) return t;
                            var o = t.f;
                            return (0, a.mt)(e.feeds, (function(e) {
                                t.trecsFiltered = !0, delete o[e], t.vl = (0, s.yh)(e, t.vl)
                            })), (0, a.z)(o) && (0, s.UD)(t), t
                        },
                        parseResponse: function(e) {
                            var t = {},
                                n = e.f || {};
                            return (0, a.mt)(n, (function(n, a) {
                                var u = (0, c.$x)(e, n, a);
                                t[n] = (0, o.Z)(u);
                                var d = r.L5.optionsSummary.placements.filter((function(e) {
                                    return e.placementName === n
                                }))[0] || void 0;
                                (0, i.LO)(d, "Feed doesn't exist in store");
                                var p = (0, l.Yi)(d),
                                    f = window.document.querySelector("#".concat(p));
                                r.Un.appendEntityCustomData({
                                    entity: u,
                                    element: f
                                }), e.vl = (0, s.yh)(n, e.vl)
                            })), (0, s.UD)(e), t
                        },
                        mergeResponseSummary: function(e, t) {
                            return (0, c.Am)(e.feeds || {}, t.feeds || {})
                        }
                    }
            },
            7429: function(e, t, n) {
                "use strict";
                n.d(t, {
                    $z: function() {
                        return a
                    },
                    Bs: function() {
                        return u
                    },
                    oQ: function() {
                        return o
                    }
                });
                var r = n(7582),
                    i = n(2143);

                function o(e, t, n) {
                    var r = e.uip,
                        o = n.d,
                        u = o.r;
                    if (o.f && u) {
                        a(t, u, r);
                        var c = function(e) {
                            var t = e.nb;
                            return e.pl.filter((function(e) {
                                return e.fb === t.toString()
                            }))
                        }(n);
                        return 0 === c.length ? (t.requestList.push(e), !0) : (n.increaseNextBatchNumber(), (0, i.K7)(c, t), !0)
                    }
                    return !1
                }

                function a(e, t, n) {
                    var i, o, a;
                    a = ((i = {})[n] = t, i), (o = e.genericResponse).f = (0, r.pi)((0, r.pi)({}, o.f || {}), a)
                }

                function u(e, t) {
                    if (!(0, i.RG)(e, 6)) {
                        var n = t.vl,
                            r = t.f[e],
                            o = function(e, t) {
                                return function(e, t) {
                                    if (t.fti) return e.d.f = !0, void e.setRequestData(t);
                                    var n = t.nb,
                                        r = e.d.r;
                                    r.nb = n ? parseInt(n) : 0, e.setRequestData(r)
                                }(e, t), e
                            }((0, i.Xq)(e), r),
                            a = (0, i.Tt)(e, n);
                        (0, i.jO)(a, o)
                    }
                }
            },
            3854: function(e, t, n) {
                "use strict";
                n.d(t, {
                    $x: function() {
                        return l
                    },
                    Am: function() {
                        return d
                    },
                    VC: function() {
                        return p
                    }
                });
                var r = n(7582),
                    i = n(1553),
                    o = n(6379),
                    a = n(1591),
                    u = n(2992),
                    c = n(5344),
                    s = {
                        exactVisibleDistanceThresholdFromTop: 200,
                        numPlaceholderItems: 3,
                        ManualLoadNextBatch: !0,
                        rootSelectorScrollElement: "",
                        feedObserverLoadNextBatch: !0,
                        firstBatchDistanceThresholdFromTop: !0,
                        enableHistory: !0,
                        disableLoadingCardsPlaceholder: !1,
                        videoDisclosurePosition: void 0
                    };

                function l(e, t, n) {
                    var c, l, d = (e.vl || []).filter((function(e) {
                            return !!e.fpl
                        })).filter((function(e) {
                            return e.fpl === t
                        })).map((function(t) {
                            return (0, u.X)(t, e)
                        })).filter((function(e) {
                            return 0 !== e.type || ((0, i.yN)("Type of placement ".concat(e.uip, " is unknown")), !1)
                        })),
                        p = d.length > 0 ? d[0].fb : -1,
                        f = e.sca,
                        m = (0, a.BV)(n.nbdt) || 2e3,
                        v = !!d.filter((function(e) {
                            return !!e.items.length
                        })).length,
                        h = (0, r.pi)((0, r.pi)({
                            _ID: t,
                            entityType: 2
                        }, n), ((c = {
                            batchList: [(l = {}, l.fb = p, l.placements = d, l)]
                        }).fpl = t, c.drp = function(e) {
                            if (!e) return s;
                            var t = {};
                            return (0, o.mt)(s, (function(n) {
                                var r;
                                t[n] = null !== (r = e[n]) && void 0 !== r ? r : s[n]
                            })), t
                        }(n.drp), c.currentBatch = p, c.nbdt = m, c.hasNewContent = v, c.hasFeedEnded = (0, a.td)(n.eof, !1), c.sca = f, c));
                    return h.batchList[0].placements.forEach((function(e) {
                        e.parent = h
                    })), h
                }

                function d(e, t) {
                    var n = {};
                    return (0, a.fZ)((0, r.ev)((0, r.ev)([], Object.keys(e), !0), Object.keys(t), !0)).forEach((function(r) {
                        var i = p(e[r] || {}, t[r] || {});
                        n[r] = (0, c.Z)(i)
                    })), n
                }

                function p(e, t) {
                    return (0, r.pi)((0, r.pi)((0, r.pi)({}, e), t), {
                        batchList: (0, r.ev)((0, r.ev)([], e.batchList || [], !0), t.batchList || [], !0)
                    })
                }
            },
            2963: function(e, t, n) {
                "use strict";

                function r(e, t) {
                    return t.filter((function(t) {
                        var n = t.fpl;
                        return n !== e || !n
                    }))
                }

                function i(e) {
                    e.f = void 0
                }
                n.d(t, {
                    UD: function() {
                        return i
                    },
                    yh: function() {
                        return r
                    }
                }), n(1591), n(3265), n(9685), n(6736)
            },
            891: function(e, t, n) {
                "use strict";
                n.d(t, {
                    W: function() {
                        return s
                    }
                });
                var r = n(7582),
                    i = n(5344),
                    o = n(2992),
                    a = n(6379),
                    u = n(2143),
                    c = n(9839),
                    s = {
                        filterResponse: function(e, t) {
                            return c.L5.config.runtime.supportedFeatures.hp4u && t.vl ? (t.vl = t.vl.filter((function(e) {
                                var n = !!e.hpl;
                                return n && (t.trecsFiltered = !0), !n
                            })), t) : t
                        },
                        mergeResponseSummary: function(e, t) {
                            var n = e.organicPersonalization,
                                i = t.organicPersonalization;
                            return n && i ? (0, r.pi)((0, r.pi)((0, r.pi)({}, n), i), {
                                regions: (0, r.ev)((0, r.ev)([], (null == n ? void 0 : n.hp4uRegions) || [], !0), (null == i ? void 0 : i.hp4uRegions) || [], !0)
                            }) : n || i
                        },
                        parseResponse: function(e) {
                            var t, n = e.op || {},
                                u = e.vl || [];
                            if (0 !== (u = u.filter((function(e) {
                                    return e.hpl
                                }))).length) {
                                var c = (0, i.Z)((0, r.pi)((0, r.pi)({}, n), {
                                    _ID: "hp4u",
                                    entityType: 7
                                }));
                                n && (null !== (t = c.ks) && void 0 !== t || (c.ks = !1), c.reg || (c.reg = []), c.snz || (c.snz = []), c.hp4uRegions || (c.hp4uRegions = []));
                                for (var s = {}, l = 0, d = u; l < d.length; l++) {
                                    var p = d[l],
                                        f = p.hpl;
                                    s[f] || (s[f] = []), s[f].push((0, o.X)(p, e))
                                }
                                return (0, a.mt)(s, (function(e) {
                                    c.hp4uRegions.push({
                                        name: e,
                                        placements: s[e]
                                    })
                                })), e.vl = e.vl.filter((function(e) {
                                    return !e.hpl
                                })), c
                            }
                        },
                        updateCache: function(e, t) {
                            (0, u.eL)(e.organicPersonalization, t)
                        },
                        updateRootResponseCache: function() {}
                    }
            },
            9707: function(e, t, n) {
                "use strict";
                n.d(t, {
                    m: function() {
                        return u
                    }
                });
                var r = n(7582),
                    i = n(2143),
                    o = n(2992),
                    a = n(6379),
                    u = {
                        updateCache: function(e, t) {
                            (0, i.eL)(e.nextUp, t)
                        },
                        updateRootResponseCache: function() {},
                        filterResponse: function(e, t) {
                            return t
                        },
                        parseResponse: function(e) {
                            var t = function(e) {
                                var t;
                                return (e.vl || []).some((function(e) {
                                    if (e.nup) return t = e, !0
                                })), t
                            }(e);
                            if (t) return function(e, t) {
                                e.vl = e.vl.filter((function(e) {
                                    return e.uip !== t
                                }))
                            }(e, t.uip), (0, r.pi)((0, r.pi)({}, (0, o.X)(t, e)), {
                                nextUpData: t.nup,
                                _ID: t.uip,
                                entityType: 8
                            })
                        },
                        mergeResponseSummary: function(e, t) {
                            return (0, a.PM)(e.nextUp, t.nextUp)
                        }
                    }
            },
            9725: function(e, t, n) {
                "use strict";
                n.d(t, {
                    q: function() {
                        return p
                    }
                });
                var r = n(7582),
                    i = n(2143),
                    o = n(2992),
                    a = n(9839),
                    u = n(1553),
                    c = n(6379),
                    s = n(4555),
                    l = n(1591),
                    d = n(3150),
                    p = {
                        updateCache: function(e, t) {
                            (0, i.eL)(e.videoReel, t)
                        },
                        updateRootResponseCache: function() {},
                        filterResponse: function(e, t) {
                            var n;
                            if (!t.vl) return t;
                            var i = t.vl.filter((function(e) {
                                var n = !!e.evr;
                                return n && (t.trecsFiltered = !0), !n
                            }));
                            return (0, r.pi)((0, r.pi)({}, t), ((n = {}).vl = i, n))
                        },
                        parseResponse: function(e) {
                            var t = e.vl || [],
                                n = t.filter((function(e) {
                                    return !!e.evr
                                }))[0];
                            if (n) {
                                var r = (0, o.X)(n, e),
                                    i = n.uuip || n.uip,
                                    c = a.L5.optionsSummary.placements.filter((function(e) {
                                        return e.placementName === i
                                    }))[0] || void 0;
                                if (c) {
                                    var p = n.evr.customModules["video-reel"],
                                        f = p.advnc || {},
                                        m = (0, l.td)(f.adx, !1),
                                        v = {
                                            controlPlacementName: p.placementName || n.uip,
                                            videoReelPlacementName: p.videoReelPlacement || n.uip,
                                            videoReelItemWrapperSelector: p.videoReelItemWrap || p.itw,
                                            isAdx: m,
                                            toggleByViewport: (0, l.td)(f.toggleByViewport, !1),
                                            isWithLoadingScreen: (0, l.td)(f.loaderScreen, !1) || m,
                                            scriptId: p.scriptId,
                                            moduleType: p.moduleInstance || p.ins || "videoReel",
                                            customCss: p.ccss,
                                            controlItemWrapperSelector: p.itemWrapper || p.itw,
                                            placementCardSelector: p.controlSelector || p.slc,
                                            embedId: p.videoReelEmbedId || p.eid,
                                            embedName: p.videoReelEmbedName || p.enid,
                                            scItemLocation: p.loc || 3,
                                            scDuration: p.dur || 7e3,
                                            modeName: n.m,
                                            cssOverrides: n.csso,
                                            isSc: !!n.v && n.v.length > 0,
                                            scMode: r.m,
                                            placement: r,
                                            isDemandFirst: (0, l.td)(f.isDemandFirst, !1)
                                        },
                                        h = (0, d.Yi)(c),
                                        g = s.mb.document.querySelector("#".concat(h));
                                    return a.Un.appendEntityCustomData({
                                        entity: r,
                                        element: g
                                    }), e.vl = t.filter((function(e) {
                                        return !e.evr
                                    })), v
                                }(0, u.o7)("Placement '".concat(i, "' doesn't exist in OptionSummary input."))
                            }
                        },
                        mergeResponseSummary: function(e, t) {
                            return (0, c.PM)(e.videoReel, t.videoReel)
                        }
                    }
            },
            2188: function(e, t, n) {
                "use strict";
                n.d(t, {
                    s: function() {
                        return c
                    }
                });
                var r = n(7582),
                    i = n(2143),
                    o = n(2992),
                    a = n(1553),
                    u = n(6379),
                    c = {
                        updateCache: function(e, t) {
                            var n = e.vignette;
                            (0, i.eL)(n, t, (function(e) {
                                var n, r = null === (n = t.prods) || void 0 === n ? void 0 : n.vig;
                                r && e.setRequestData(r)
                            }))
                        },
                        updateRootResponseCache: function(e, t, n) {
                            if (function(e) {
                                    return e === s
                                }(n)) {
                                var i = t.r;
                                e.genericResponse.prods || (e.genericResponse.prods = {}), e.genericResponse.prods.vig = (0, r.pi)((0, r.pi)({}, e.genericResponse.prods.vig), i)
                            }
                        },
                        filterResponse: function(e, t) {
                            return t
                        },
                        parseResponse: function(e) {
                            var t, n = null === (t = e.prods) || void 0 === t ? void 0 : t.vig;
                            if (n) {
                                var i = n.plc,
                                    c = function(e, t) {
                                        var n;
                                        return (e.vl || []).some((function(e) {
                                            if (e.uip === t) return n = e, !0
                                        })), n
                                    }(e, i);
                                if (c) {
                                    var s = (0, r.pi)((0, r.pi)({}, (0, o.X)(c, e)), {
                                        entityType: 9,
                                        frequencyCapping: parseInt(n.frequencyCapping),
                                        metaData: n.metaData
                                    });
                                    return function(e, t) {
                                        (function(e) {
                                            var t = e.prods || {};
                                            1 === (0, u.kE)(t) && t.vig ? e.prods = void 0 : t.vig = void 0
                                        })(e), e.vl = e.vl.filter((function(e) {
                                            return e.uip !== t
                                        }))
                                    }(e, i), s
                                }(0, a.yN)("Vignette configuration found but vignette placement isn't")
                            }
                        },
                        mergeResponseSummary: function(e, t) {
                            return (0, u.PM)(e.vignette, t.vignette)
                        }
                    },
                    s = "taboola-vignette"
            },
            8824: function(e, t, n) {
                "use strict";
                n.d(t, {
                    $: function() {
                        return p
                    }
                });
                var r = n(7582),
                    i = n(6379),
                    o = n(2143),
                    a = n(9839),
                    u = n(2992),
                    c = n(1553),
                    s = n(5344),
                    l = n(4555),
                    d = n(3150),
                    p = {
                        updateCache: function(e, t) {
                            (0, i.mt)(e.widgets, (function(e, n) {
                                (0, o.eL)(n, t)
                            }))
                        },
                        updateRootResponseCache: function() {},
                        filterResponse: function(e, t) {
                            return a.L5.config.runtime.supportedFeatures.widget ? ((0, i.mt)(e.widgets, (function(e, n) {
                                t.vl = f(n.name, t)
                            })), t) : t
                        },
                        parseResponse: function(e) {
                            var t = {},
                                n = e.vl || [];
                            return (n = n.filter((function(e) {
                                return !e.fpl
                            }))).forEach((function(n) {
                                var o = (0, u.X)(n, e);
                                o.mode || (0, c.yN)("Mode '".concat(o.m, "' for Placement '").concat(o.uip, "' doesn't exist in configuration ").concat(a.L5.config.runtime.pageUrl));
                                var p = n.uip,
                                    m = a.L5.optionsSummary.placements.filter((function(e) {
                                        return e.placementName === p
                                    }))[0] || void 0;
                                if (m) {
                                    if (o) {
                                        var v = (0, r.pi)((0, r.pi)({}, o), {
                                                name: p,
                                                entityType: 1
                                            }),
                                            h = (0, s.Z)(v);
                                        (0, i.Io)(h, "items", o.items), t[o._ID] = h
                                    }
                                    var g = (0, d.Yi)(m),
                                        b = l.mb.document.querySelector("#".concat(g));
                                    a.Un.appendEntityCustomData({
                                        entity: o,
                                        element: b
                                    }), e.vl = f(p, e)
                                } else(0, c.o7)("Placement '".concat(p, "' doesn't exist in OptionSummary input."))
                            })), t
                        },
                        mergeResponseSummary: function(e, t) {
                            return (0, i.PM)(e.widgets, t.widgets)
                        }
                    };

                function f(e, t) {
                    return t.vl.filter((function(n) {
                        var r = n.uip === e;
                        return r && (t.trecsFiltered = !0), !r
                    }))
                }
            },
            3265: function(e, t, n) {
                "use strict";
                n.d(t, {
                    U: function() {
                        return a
                    }
                });
                var r = n(7582),
                    i = n(9685),
                    o = n(7253);

                function a(e, t) {
                    var n, a, u = document.createElement(e);
                    return t ? (null === (n = t.attrList) || void 0 === n || n.forEach((function(e) {
                        var t = e[0],
                            n = e[1],
                            r = void 0 === n ? "" : n;
                        u.setAttribute(t, r)
                    })), null === (a = t.datasetList) || void 0 === a || a.forEach((function(e) {
                        var t = e[0],
                            n = e[1];
                        u.dataset[t] = n
                    })), t.classList && o.bf.apply(void 0, (0, r.ev)([u], t.classList, !1)), (0, i.k)(u, t.content), u) : u
                }
            },
            7983: function(e, t, n) {
                "use strict";
                n.d(t, {
                    q: function() {
                        return b
                    },
                    h: function() {
                        return _
                    }
                });
                var r = n(3150),
                    i = n(9839),
                    o = n(3887),
                    a = n(1553),
                    u = n(6379),
                    c = n(7158),
                    s = n(1591),
                    l = -1;

                function d(e) {
                    return e !== l
                }
                var p = "__gen__",
                    f = "tblStyle_",
                    m = "__keys__",
                    v = {},
                    h = 0,
                    g = "";

                function b(e) {
                    var t = function() {
                        if (v[p]) return "";
                        v[p] = !0;
                        var e = (0, o.Cd)("style");
                        return g += ' .trc_rbox_container { direction: ltr; text-align: left; } /*override bootstrap default css */ .trc_rbox_container [class*=span] { float: none; margin-left: 0; } /*------------- Multi-widget -------------*/ .trc_multi_widget_container { display: -ms-flexbox; display: flex; -ms-flex-pack: justify; justify-content: space-between; } .trc_multi_widget_container .trc_rbox_div { margin: 0; } /*----------------------------------------*/ .trc_rbox_header { border: 0 solid; overflow: hidden; vertical-align: middle; } .trc_rbox_container .trc_img { display: inline-block !important; } .trc_rbox_header_icon_div { display: table-cell; vertical-align: baseline; } .trc_rbox_header .trc_rbox_header_icon_div .trc_rbox_header_icon_img { vertical-align: middle; width: auto; } .trc_rbox_header_icon_span { display: inline-table; } .in_trc_header { position: relative !important; float: right; margin: 0; } #trc_rbox_css_loaded { overflow: hidden; width: 0; height: 0; } .trc_rbox { margin-top: 0; } .trc_rbox_div { margin: 0 0 3px; direction: ltr; padding: 0; box-sizing: border-box; -moz-box-sizing: border-box; -ms-box-sizing: border-box; -webkit-box-sizing: border-box; overflow: auto; position: relative; width: auto; border: solid #CCC 1px; } .loading-animation span { display: block; } .videoCube { zoom: 1; cursor: pointer; float: none; overflow: hidden; box-sizing: border-box; -moz-box-sizing: border-box; -ms-box-sizing: border-box; -webkit-box-sizing: border-box; } div.videoCube:hover, .videoCube_hover { cursor: pointer; } .videoCube span.video-title:hover, .videoCube_hover span.video-title { text-decoration: underline; } .videoCube a { text-decoration: none; border: 0; color: black; cursor: pointer; } .videoCube a:hover, .videoCube_hover a, .videoCube a:link, .videoCube a { text-decoration: none !important; outline: none; } .videoCube a .thumbBlock { float: left; display: block; overflow: hidden !important; } .videoCube a img, .videoCube img { border: 0; display: block; margin: 0; height: auto; width: auto; } .videoCube .video-label { display: block; overflow: hidden; } .videoCube .video-label { width: auto !important; white-space: pre-wrap; /* css-3 */ white-space: -moz-pre-wrap; /* Mozilla, since 1999 */ white-space: -o-pre-wrap; /* Opera 7 */ word-wrap: break-word; /* Internet Explorer 5.5+ */ } .videoCube .video-label-box.label-box-with-title-icon { display: table; } .video-icon-container { float: left; display: table-cell; vertical-align: baseline; } .video-icon-img { vertical-align: middle; } .videoCube .video-duration { height: 0; float: left; position: relative; color: white; font-size: 11px; } .videoCube .video-duration dt { border-radius: 4px; -moz-border-radius: 4px; -webkit-border-radius: 4px; background-color: black; opacity: 0.6; filter: alpha(opacity=60); } /* browser native line-clamp */ .videoCube span.video-label.trc_ellipsis { position: relative; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; } .videoCube span.video-label.trc-smart-ellipsis { position: relative; overflow: hidden; } .videoCube span.video-label.trc-smart-ellipsis ins { display: inline-block; text-decoration: inherit; } .videoCube span.video-label.trc-smart-ellipsis.tbl-ltr-label { direction: ltr; } .videoCube span.video-label.trc-smart-ellipsis.tbl-ltr-label ins { float: left; margin-right: 5px; direction: ltr; } .videoCube span.video-label.trc-smart-ellipsis.tbl-rtl-label { float: right; direction: rtl; width: 100% !important; } .videoCube span.video-label.trc-smart-ellipsis.tbl-rtl-label ins { float: right; margin-left: 5px; direction: rtl; } .videoCube span.video-label.trc-smart-ellipsis ins.lastLineEllipsis { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; word-wrap: normal; width: 100%; } .video-duration.video-duration-detail div { color: white; } .trc_rbox .sponsored { position: relative; display: block; overflow: visible; height: auto; width: auto; padding-right: 0; text-align: right; font-size: 9px; } /* Configuration defaults */ .trc_rbox_div { height: 410px; } .videoCube { direction: ltr; font-size: 11px; margin: 0; color: black; border-width: 0; } .videoCube.vertical:first-child { border-top: 0; margin-top: 0; } .videoCube.horizontal:first-child { border-left: 0; margin-left: 0; } div.videoCube:hover, .videoCube_hover { background-color: #EBF0FF; color: black; } .videoCube .thumbBlock { margin: 0; border-style: solid; } .videoCube a img, .videoCube img { border-color: #ececec; } .videoCube .video-label-box { margin-left: 81px; } .videoCube .video-label dt { font-weight: bold; } .videoCube .video-title { height: auto; margin-bottom: 3px; white-space: normal; } .videoCube .trc_inline_detail_spacer { display: inline-block; white-space: pre; } .loading-animation { font-family: sans; font-size: 1.5em; text-align: center; color: gray; height: 100%; } .trc_rbox_header { font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; text-decoration: none; color: black; } .trc_header_right_part { position: absolute; left: 50%; top: 0; } .branding_div { overflow: visible; float: right; } .branding_div img { height: 20px; } .videoCube .branding .logoDiv { font-size: inherit; line-height: inherit; background: none; margin: 0; padding: 0; } .videoCube .branding .logoDiv a { vertical-align: inherit; color: inherit; line-height: inherit; } .videoCube .branding .logoDiv a span { vertical-align: inherit; } .trc_related_container .videoCube .branding .attribution-disclosure-link-sponsored { display: inline-block; float: none; } .trc_related_container .videoCube .branding .attribution-disclosure-link-sponsored.align-disclosure-right { float: right; margin-left: auto; padding-left: 2px; } .videoCube .video-label-box .branding.composite-branding { display: -webkit-box; display: -ms-flexbox; display: flex; } .branding.composite-branding > * { display: inline-block; vertical-align: bottom; } .branding .branding-separator { margin: 0 2px; font-weight: normal; } .branding .branding-inner { text-overflow: ellipsis; overflow: hidden; white-space: nowrap; } .video-label-box span.branding.inline-branding { display: inline-block; } /* Support for Horizontal mode */ .trc_related_container div.horizontal { float: left; box-sizing: border-box; -moz-box-sizing: border-box; -ms-box-sizing: border-box; -webkit-box-sizing: border-box; } /* Support for thumbnail position */ .trc_related_container DIV.videoCube.thumbnail_top .thumbBlock, .trc_related_container DIV.videoCube.thumbnail_bottom .thumbBlock { float: none; } /* SEO blocks should be hidden once R-Box loads */ .vidiscovery-note { display: none; } .videoCube .thumbBlock .trc_sponsored_overlay_base { display: block; width: auto; margin-left: 0; position: absolute; color: white !important; } .videoCube .thumbBlock .trc_sponsored_overlay { filter: alpha(opacity=60); opacity: 0.6; display: block; position: absolute; } .videoCube .thumbBlock .trc_sponsored_overlay_base .sponsored { position: relative; display: block; overflow: visible; width: auto; text-align: center; padding: 0 5px; margin-top: 0; } .videoCube .thumbBlock .trc_sponsored_overlay_base.round .trc_sponsored_overlay { border-radius: 4px; -moz-border-radius: 4px; -webkit-border-radius: 4px; } .videoCube .thumbBlock .trc_sponsored_overlay_base.round { margin-left: 4px; } .thumbnail-emblem, .videoCube .thumbnail-overlay, .videoCube:hover .thumbnail-overlay, .videoCube_hover .thumbnail-overlay { position: absolute; background: transparent no-repeat; background-size: contain; z-index: 50; } .thumbnail_bottom { padding-bottom: 8px; } .trc_related_container .logoDiv { font-family: Arial, Helvetica, sans-serif; white-space: nowrap; font-size: 9px; } .trc_related_container .logoDiv a { font-size: 9px; text-decoration: none !important; color: black; margin-right: 1px; /* don\'t allow focus line to cause overflow */ vertical-align: text-bottom; } .logoDiv a span:hover { text-decoration: underline; } .trc_rbox_header .logoDiv { font-size: 1em; } /* text-link widgets*/ .trc_tl .trc_rbox_header .logoDiv { position: relative; z-index: 1; } .trc_tl .trc_rbox_header_span .trc_header_right_column { position: absolute; width: 48%; left: 52%; top: 0; } .trc_tl .trc_rbox_div .videoCube.horizontal { clear: left; } .trc_tl .trc_rbox_div .videoCube.trc_tl_right_col { float: none; clear: right; margin-left: auto; } .trc_tl .videoCube .video-title .branding { line-height: 1.3em; } .trc_tl .videoCube:hover span.branding, .trc_tl .videoCube_hover span.branding { text-decoration: none; } .trc_tl .trc_rbox_div .videoCube.thumbnail_none a{ vertical-align: top; overflow: visible; } .trc_tl .videoCube .video-label-box { display: inline-block; vertical-align: top; width: 100%; } /* text-link widgets - end*/ .trc_rbox_container.trc_expandable { overflow: hidden; max-height: 0; transition-property: max-height; -webkit-transition-property: max-height; -moz-transition-property: max-height; -o-transition-property: max-height; -webkit-transform: translateZ(0); -moz-transform: translateZ(0); -ms-transform: translateZ(0); -o-transform: translateZ(0); transform: translateZ(0); } .trc_related_container .videoCube .thumbBlock .branding { position: absolute; bottom: 0; z-index: 1; width: 100%; margin: 0; padding: 5px 0; text-align: center; } .syndicatedItem .branding { margin: 0; } .trc-inplayer-rbox { background: #333; background: rgba(30, 30, 30, 0.9); bottom: 0; position: absolute; height: 300px; text-align: center; } .trc-inplayer-rbox .trc_rbox_container { margin: 50px auto 0; width: 640px } .trc_rbox.trc-auto-size { width: 100%; height: 100%; } .videoCube.thumbnail_under .video-title { min-height: 2.58em; } .videoCube.thumbnail_under .tbl-text-over-container { width: 100%; position: absolute; z-index: 1; left: 0; bottom: 0; min-height: 66%; max-height: 66%; padding-top: 2px; padding-bottom: 2px; line-height: 1.25em; } .videoCube.thumbnail_under .tbl-text-over-container .tbl-text-over { height: 100%; width: 100%; position: absolute; background: linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.8) 100%); filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#00000000, endColorstr=#CC000000, GradientType=0); } .videoCube.thumbnail_under .tbl-text-over-container span.video-title, .videoCube.thumbnail_under .tbl-text-over-container span.video-description, .videoCube.thumbnail_under .tbl-text-over-container span.branding { position: relative; z-index: 1; padding: 0 8px; margin: 0; } .videoCube.thumbnail_under .tbl-text-over-container span.video-title { margin-bottom: 6px; min-height: auto; } .videoCube.thumbnail_under .tbl-text-over-container .video-label-box { position: absolute; bottom: 0; left: 0; width: 100%; padding: 0 8px 6px 8px; min-height: auto; } .trc-auto-size .trc_rbox_outer .trc_rbox_div { height: auto; width: auto; } .trc-auto-size .trc_rbox_div .videoCube { height: auto; } .trc-auto-size .trc_rbox_div .videoCube.trc-first-recommendation { margin-top: 0; } .trc_rbox .trc_rbox_outer .trc_rbox_div .videoCube.trc-first-in-row { margin-left: 0; } .trc_elastic .trc_rbox { width: auto; } .trc_elastic .videoCube { overflow: hidden; } .trc_elastic .videoCube .thumbBlock { background: transparent no-repeat center center; background-size: cover; position: absolute; display: inline-block; top: 0; right: 0; bottom: 0; left: 0; margin-left: 0; margin-right: 0; } .trc_elastic .thumbBlock_holder { position: relative; width: 100%; } .trc_elastic .thumbnail_start .thumbBlock_holder { float: left; margin-right: 10px; } .trc_elastic .thumbnail_start.item-has-pre-label .thumbBlock_holder { margin-right: 0; } .trc_elastic .videoCube_aspect { width: 1px; } .trc_elastic .trc_rbox .trc_rbox_div { height: auto; } .trc_elastic .thumbnail_start .trc-pre-label { float: left; padding-right: 10px; } .trc_elastic .thumbnail_start.trc-split-label .trc-main-label { float: left; padding-left: 10px; } .trc_elastic .video-label-box { display: block; } .trc_elastic .thumbnail_start .video-label-box { box-sizing: border-box; } /** USER Ad-Choice **/ .trc_user_adChoice_btn { background: url("//cdn.taboola.com/static/c5/c5ef96bc-30ab-456a-b3d5-a84f367c6a46.svg") no-repeat scroll 0 0 rgba(255, 255, 255, 1); border-radius: 0 0 0 5px; width: 16px; height: 16px; position: absolute; right: 0; top: 0; z-index: 9000; cursor: pointer; border-width: 2px 0 2px 4px; border-style: solid; border-color: #fff; opacity: 0.7; background-size: contain; visibility: hidden; } .videoCube:hover .trc_user_adChoice_btn, .videoCube_hover .trc_user_adChoice_btn { visibility: visible; } .videoCube .trc_user_adChoice_btn_static { visibility: visible; } .p-video-overlay-container { position: absolute; width: 100%; height: 100%; top: 0; left: 0; background-color: transparent; } .p-video-overlay.p-video-overlay-show { display: flex; } .p-video-overlay { display: none; background-color: #000; opacity: 0.7; width: 100%; height: 100%; flex-direction: column; } .p-video-overlay-action { color: #fff; width: 100%; direction: ltr; text-align: center; display: flex; justify-content: center; flex-direction: column; } .p-video-overlay-action.p-video-back-action { height: 34%; } .p-video-back-action-label { font-family: Helvetica Neue, serif; font-size: 14px; font-weight: 200; letter-spacing: 1px } .p-video-overlay-action.p-video-goto-action { height: 66%; } .p-video-goto-action-url { font-family: Helvetica Neue, serif; font-size: 24px; font-weight: 400; text-decoration: underline; margin-top: 5px; } .p-video-goto-action-label { font-family: Helvetica Neue, serif; font-size: 14px; font-weight: 100; letter-spacing: 1px; } .trc_related_container .trc_clearer { clear: both; height: 0; overflow: hidden; font-size: 0; line-height: 0; visibility: hidden; } /* Ad Choices */ .link-adc { float: right !important; } .trc-widget-footer .logoDiv { line-height: normal; padding-bottom: 5px; } .trc-widget-footer .link-adc a .trc_adc_wrapper, .trc_header_ext .link-adc a .trc_adc_wrapper { height: 12px; width: 18px; display: inline-block; padding-left: 1px; margin-bottom: 2px; } .trc-widget-footer .link-adc a .trc_adc_s_logo, .trc_header_ext .link-adc a .trc_adc_s_logo, .trc-widget-footer .link-adc a .trc_adc_b_logo, .trc_header_ext .link-adc a .trc_adc_b_logo { vertical-align: middle; height: 15px; display: inline-block; margin-top: -1px; /**fix v align of adc logo - compensate for link underline */ } .trc-widget-footer .link-adc a .trc_adc_s_logo, .trc_header_ext .link-adc a .trc_adc_s_logo { width: 12px; height: 14px; background: url("//cdn.taboola.com/static/c5/c5ef96bc-30ab-456a-b3d5-a84f367c6a46.svg") no-repeat; background-size: contain; vertical-align: middle; } .trc-widget-footer .link-adc a .trc_adc_b_logo, .trc_header_ext .link-adc a .trc_adc_b_logo { width: 77px; background: #ffffff url("//cdn.taboola.com/libtrc/static/thumbnails/0781f9c5a8637d1e162874f157460048.png") no-repeat !important; right: -1px; display: none; position: absolute; } /* Attribution och Disclosure */ .logoDiv .trc_mobile_disclosure_link, .logoDiv .trc_mobile_attribution_link, .logoDiv .trc_mobile_adc_link { display: none; } .logoDiv .trc_desktop_disclosure_link, .logoDiv .trc_desktop_attribution_link, .logoDiv .trc_desktop_adc_link { display: inline; } @media screen and (max-width: 767px) { .logoDiv .trc_mobile_disclosure_link { display: inline; } .logoDiv .trc_mobile_attribution_link { display: inline; } .logoDiv .trc_mobile_adc_link { display: inline; } .logoDiv .trc_desktop_disclosure_link { display: none; } .logoDiv .trc_desktop_attribution_link { display: none; } .logoDiv .trc_desktop_adc_link { display: none; } } .trc_in_iframe .logoDiv .trc_mobile_attribution_link, .trc_in_iframe .logoDiv .trc_mobile_disclosure_link { display: inline; } .trc_in_iframe .logoDiv .trc_desktop_attribution_link, .trc_in_iframe .logoDiv .trc_desktop_disclosure_link { display: none; } .trc_related_container .logoDiv, .trc_related_container .trc_header_ext .logoDiv { float: right; } .trc_related_container .logoDiv + .logoDiv { margin-right: 2px; } .trc_related_container .attribution-disclosure-link-sponsored, .trc_related_container .attribution-disclosure-link-hybrid { display: none; } .trc_related_container .trc-content-sponsored .attribution-disclosure-link-sponsored, .trc-w2f.trc-content-sponsored .attribution-disclosure-link-sponsored { display: block; } .trc_related_container .trc-content-hybrid .attribution-disclosure-link-hybrid, .trc-w2f.trc-content-hybrid .attribution-disclosure-link-hybrid { display: block; } .trc_related_container .trc-widget-footer:hover a span, .trc_related_container .trc_header_ext:hover a span { text-decoration: underline !important; } /* this span makes sure that all logos (attribution + adc + disclosure) are vertically aligned - especially when the attribution font-size is smaller than the adc logo height (15px) */ .logoDiv a span.trc_logos_v_align { display: inline-block !important; font-size: 15px !important; line-height: 1em !important; width: 0 !important; } .trc_related_container .trc_header_ext:hover a span.trc_logos_v_align, .trc_related_container .trc_header_ext:hover a span.trc_adc_wrapper, .trc_related_container .trc-widget-footer:hover a span.trc_logos_v_align, .trc_related_container .trc-widget-footer:hover a span.trc_adc_wrapper { text-decoration: none !important; } .trc_related_container .trc_rbox_header_span .trc_header_right_column { display: none; } .trc_related_container img { max-width: none; } .trc_related_container { clear: both; } .tbl-loading-spinner { width: 100%; height: 40px; background: url(//cdn.taboola.com/static/91/91a25024-792d-4b52-84e6-ad1478c3f552.gif) center center no-repeat; background-size: 40px; } .tbl-hidden { display: none !important; } .tbl-invisible { opacity: 0; pointer-events: none; } .tbl-batch-anchor { width: 100%; height: 1px; } .videoCube .video-logo + .branding.composite-branding { display: inline-block; vertical-align: middle; } .videoCube .video-logo { margin-right: 4px; } .videoCube .video-logo .branding { margin: auto auto auto 25px; } .videoCube .video-logo img { padding: 0; max-height: 14px; width: auto; max-width: 100px; display: inline-block; } /* Support for integrated widget frame */ .iw_video_frame .trc_rbox_div { overflow: hidden; } .trc-w2f .trc_rbox .trc_rbox_header, .trc-w2f .trc_rbox .trc-widget-footer { display: none !important; } ', g += e.rtl || "", g += e.custom || "", g += y("trc_rbox", (0, o.tt)(r._v, "__style__") || {})
                    }();
                    e.forEach((function(e) {
                        if (!v[e])
                            if (v[e] = !0, i.L5.config.publisher.modes[e]) {
                                var n = (0, o.Cd)("style");
                                t += y(e, (0, o.tt)(e, "__style__") || {}), t += function(e, t) {
                                    var n;
                                    if (!t) return "";
                                    var r = new RegExp("\\/\\*\\ss-split-".concat(e, "\\s\\*\\/[^]*\\*\\se-split-").concat(e, "\\s\\*\\/"), "g");
                                    return (null === (n = t.match(r)) || void 0 === n ? void 0 : n[0]) || ""
                                }(e, n.mode_custom || ""), t += function(e) {
                                    var t = (0, o.tt)(e, "responsive-rules"),
                                        n = "";
                                    return null == t || t.forEach((function(t) {
                                        var r, a, u = null !== (r = t.minWidth) && void 0 !== r ? r : l,
                                            c = null !== (a = t.maxWidth) && void 0 !== a ? a : l;
                                        if (d(u) || d(c)) {
                                            var s = d(u) ? "(min-width:".concat(u, "px)") : "",
                                                p = d(c) ? "(max-width:".concat(c, "px) ") : "",
                                                f = "@media screen and ".concat(s).concat(d(c) ? " and " : " ").concat(p, "{\n            ").concat(function(e, t) {
                                                    var n = "trc_elastic_" + e,
                                                        r = "";
                                                    return r += "autowidget-template-text-links" === (0, o.tt)(e, "widget-creator-layout") ? function(e, t) {
                                                        var n = "rtl" === i.L5.config.publisher.direction,
                                                            r = n ? "right" : "left",
                                                            o = n ? "left" : "right",
                                                            a = ".".concat(t, " .trc_rbox_div .videoCube {width: ").concat(1 === e.cells ? "100" : "48", "%;}"),
                                                            u = ".".concat(t, " .trc_header_left_column {width: ").concat(1 === e.cells ? "100" : "48", "%;}"),
                                                            c = ".".concat(t, " .trc_header_right_column {display: ").concat(1 === e.cells ? "none" : "inline", ";}"),
                                                            s = ".".concat(t, " .trc_rbox_div div.videoCube:nth-of-type(-n+").concat(e.rows, "){float:").concat(r, ";clear:").concat(r, ";}"),
                                                            l = "";
                                                        return l += ".".concat(t, " .trc_rbox_div div.videoCube:nth-of-type(n+").concat(e.rows + 1, "){float:none;clear:").concat(o, ";margin-").concat(r, ":auto;}"), l += s, l += a, (l += u) + c
                                                    }(t, n) : function(e, t, n) {
                                                        var r = "",
                                                            a = "scrolling" === (0, o.tt)(e, "navigation-type"),
                                                            u = 1 === t.cells ? "video-label-box" : "trc-main-label",
                                                            c = ".".concat(n, " .").concat("trc_rbox_outer", " .videoCube .").concat(u, " {height:auto;}"),
                                                            s = ".".concat(n, " .").concat("trc_rbox_outer", " .videoCube {margin-bottom:10px;}"),
                                                            l = "rtl" === i.L5.config.publisher.direction ? "right" : "left",
                                                            d = t.margin.h,
                                                            p = (0, o.tt)(e, "carousel-min-items"),
                                                            f = a ? d * t.cells / p : d,
                                                            m = a ? "trc_rbox_div" : "trc_rbox_outer",
                                                            v = ".".concat(n, " .").concat(m, "{margin-").concat(l, ":-").concat(f, "%;}"),
                                                            h = (99.99 - t.cells * d) / t.cells,
                                                            g = 100 * t.ratio,
                                                            b = ".".concat(n, " .videoCube_aspect{padding-bottom:").concat(g, "%; width: 100%;}"),
                                                            _ = ".".concat(n, " .videoCube{width: ").concat(h, "%; position: relative; float: ").concat(l, "; margin: 0 0 ").concat(d, "% 0; margin-").concat(l, ": ").concat(d, "%;}");
                                                        return 1 !== t.cells && 1 !== t.rows || (r += c + s), r += v, r += b, r += _, a && (r += function(e, t, n) {
                                                            var r = e.cells / n * 100;
                                                            return ".".concat(t, " .").concat("trc_rbox_div", " { width: ").concat(r, "%; }") + ".".concat(t, " .").concat("trc_rbox_outer", " { overflow-x: scroll; -webkit-overflow-scrolling: touch; }")
                                                        }(t, n, p)), r
                                                    }(e, t, n), r += function(e, t) {
                                                        var n = [],
                                                            r = e.rows * e.cells,
                                                            i = ".".concat(t, " div.videoCube:nth-of-type(-n+").concat(r, "){display:block;visibility:visible;}"),
                                                            o = ".".concat(t, " div.videoCube:nth-of-type(n+").concat(r + 1, "){display:none;visibility:hidden;}");
                                                        return n.push(i), n.push(o), n.join("")
                                                    }(t, n), r
                                                }(e, t), "\n         }");
                                            n += f
                                        }
                                    })), n
                                }(e)
                            } else(0, a.yN)("Mode '".concat(e, "' not exist in publisher config."))
                    })), t && (t = (0, s.NO)(t), (0, c.Q)(t, {
                        id: f + h
                    }), h++)
                }

                function _() {
                    return !!h
                }

                function y(e, t) {
                    var n = "";
                    return (0, u.mt)(t, (function(r) {
                        if (r !== m) {
                            var i = t[r],
                                o = "";
                            r.split(",").forEach((function(t) {
                                o += "".concat(o ? "," : "", ".").concat(e, " ").concat(t)
                            })), n += "".concat(o, "{").concat(i, "}")
                        }
                    })), n
                }
            },
            9437: function(e, t, n) {
                "use strict";
                n.d(t, {
                    E4: function() {
                        return a
                    },
                    E9: function() {
                        return u
                    },
                    EK: function() {
                        return p
                    },
                    GK: function() {
                        return l
                    },
                    JK: function() {
                        return c
                    },
                    MY: function() {
                        return d
                    }
                });
                var r = n(1591),
                    i = n(9839),
                    o = "";

                function a(e) {
                    o = o || e
                }
                var u = "taboola global";

                function c(e, t) {
                    return void 0 === t && (t = o), "".concat(t, ":").concat(e)
                }
                var s = "unknown-site-on";

                function l(e) {
                    return e.indexOf(s) > -1
                }

                function d(e) {
                    var t = i.L5.config.publisher,
                        n = i.L5.config.runtime,
                        o = t["trc-network-mapping"];
                    if (!o) return t.publisherName;
                    var a = e || n.networkMapUrl,
                        u = a.host.toLowerCase(),
                        c = a.href.toLowerCase(),
                        l = "".concat(s, "-").concat(t.publisherName);
                    if (o[u]) return o[u];
                    for (var d = (0, r.JJ)(o).map((function(e) {
                            var t = e[0],
                                n = e[1];
                            return [t.toLowerCase(), n]
                        })).sort((function(e, t) {
                            var n = e[0],
                                r = (e[1], t[0]);
                            return t[1], n.length > r.length ? -1 : n.length < r.length ? 1 : 0
                        })), p = 0; p < d.length; p++) {
                        var f = d[p],
                            m = f[0],
                            v = f[1];
                        if (m.indexOf("/") > 0) {
                            if (c === m || c.match(m)) return v;
                            if (m.indexOf("www.") > -1 && c.match(m.replace("www.", ""))) return v
                        } else if (u.match(m)) return v
                    }
                    var h = "www.";
                    if (u.indexOf(h) > -1) return l;
                    for (var g = 0, b = ["m", "mobile", "www2", "www3"]; g < b.length; g++) {
                        var _ = new RegExp("$(https?://)".concat(b[g], ".")),
                            y = u.replace(_, h);
                        if (o[y]) return o[y]
                    }
                    return o[h + u] ? o[h + u] : l
                }

                function p(e, t) {
                    void 0 === t && (t = !1);
                    var n = i.L5.config.runtime.debugQueryParams[e];
                    return (0, r.td)(n, t)
                }
            },
            9839: function(e, t, n) {
                "use strict";
                n.d(t, {
                    _b: function() {
                        return Z
                    },
                    L5: function() {
                        return k
                    },
                    Un: function() {
                        return I
                    }
                });
                var r = n(7582),
                    i = n(1688),
                    o = n(5898),
                    a = n(9437),
                    u = n(1602),
                    c = n(2271),
                    s = n(1553),
                    l = n(6379),
                    d = n(4555),
                    p = n(1085),
                    f = n(1591),
                    m = n(2414),
                    v = n(3229),
                    h = ["publisher-start", "get-user", "get-creator", "get-rating", "get-tags", "get-views", "publisher-end", "normalize-request-param", "normalize-log-param", "detect-item-from-same-host", "after-card-created", "before-video-load", "mode-before-video-load", "normalize-item-id", "normalize-item-url", "prenormalize-item-id", "prenormalize-item-url", "mode-pub-start"];

                function g(e) {
                    return e || (e = 1), e > 1 ? e : 1
                }

                function b(e, t) {
                    if (t.virtualThumbHeight && t.virtualThumbWidth) return t.virtualThumbHeight / t.virtualThumbWidth;
                    var n = (0, f.BV)(e["thumbnail-width"]),
                        r = (0, f.BV)(e["thumbnail-height"]);
                    return n && r ? r / n : .8
                }

                function _(e) {
                    if (!(0, c.r8)(e) && !(0, c.QC)(e)) return "" === e ? [] : Array.isArray(e) ? e : e.split(",")
                }
                var y = ["testmode", "domains", "sponsored-link-text", "sponsored-video-text", "branding-url", "configuration-version", "external-credentials", "brightcove-list-id", "logo-image", "has_valid_rss", "actionscript_version", "brightcove-uses-reference", "ie-logo-image", "attribution", "notify-loaded", "read-paused-bcplayer", "timeout", "loader-impl", "trc-skip-failover", "backstage-domain-url", "adc-config", "small-ios-device", "read-more-debug", "read-more-devices", "attribution-disclosure-direction", "feed-view-devices", "feed-view-enable"];

                function w(e, t) {
                    var n;
                    if ((null === (n = t.global) || void 0 === n ? void 0 : n.publisherName) && !e.publisherName && (e.publisherName = t.global.publisherName, (0, a.E4)(t.global.publisherName)), (0, u.LO)(e.publisherName, "'publisherName' must be defined"), (0, f.it)(t["trc-network-mapping"]) && (e["trc-network-mapping"] = (0, r.pi)({}, t["trc-network-mapping"])), (0, f.it)(t["network-pubs-global"]) && (e["network-pubs-global"] = (0, r.pi)({}, t["network-pubs-global"])), t.global && (e.global = function(e) {
                            var t, n, r, i, o, a, u;
                            return null !== (t = e["enable-responsive-css-reuse"]) && void 0 !== t || (e["enable-responsive-css-reuse"] = !(0, f.td)(e["disable-responsive-css-reuse"], !1)), null !== (n = e["enable-sponsored-for-links"]) && void 0 !== n || (e["enable-sponsored-for-links"] = !(0, f.td)(e["disable-sponsored-for-links"], !1)), null !== (r = e["enable-noopener-for-links"]) && void 0 !== r || (e["enable-noopener-for-links"] = !(0, f.td)(e["disable-noopener-for-links"], !1)), null !== (i = e["override-amp-url"]) && void 0 !== i || (e["override-amp-url"] = !(0, f.td)(e["disable-amp-url-override"], !1)), null !== (o = e["rbox-usage-logging"]) && void 0 !== o || (e["rbox-usage-logging"] = !(0, f.td)(e["disable-rbox-usage-logging"], !1)), null !== (a = e["rbox-usage-logging"]) && void 0 !== a || (e["rbox-usage-logging"] = !(0, f.td)(e["disable-rbox-usage-logging"], !1)), null !== (u = e["enable-stop-propagation"]) && void 0 !== u || (e["enable-stop-propagation"] = !(0, f.td)(e["disable-stop-propagation"], !1)), e["trcinfo-sample-rate"] = (0, m.W)(e["trcinfo-sample-rate"]), e["rbox-error-stack-reporting-pct"] = (0, m.W)(e["rbox-error-stack-reporting-pct"]), e["enable-warn-tbt"] = (0, m.W)(e["enable-warn-tbt"]), e["enable-loaf"] = (0, m.W)(e["enable-loaf"]), e["blocker-list"] = function(e) {
                                if (e) {
                                    if (e === E) return E;
                                    if ((0, c.cb)(e)) {
                                        var t = e;
                                        if (t.toLowerCase() === L) return E = O;
                                        var n = t.split(",").map((function(e) {
                                            return parseInt(e)
                                        })).filter((function(e) {
                                            return !isNaN(e)
                                        }));
                                        if (n.length) return E = n;
                                        (0, s.H)("".concat("blocker-list", " config is invalid"))
                                    } else(0, s.H)("".concat("blocker-list", " config should be type string"))
                                }
                            }(e["blocker-list"]), e
                        }((0, r.pi)((0, r.pi)({}, e.global), t.global))), t.systemFlags && function(e, t) {
                            var n, i = e.systemFlags.experimentID,
                                o = null === (n = t.systemFlags) || void 0 === n ? void 0 : n.experimentID;
                            o && i.push(o), e.systemFlags = (0, r.pi)((0, r.pi)({}, e.systemFlags), t.systemFlags), "deflated" === e.systemFlags.loaderType && (e.systemFlags.loaderType = "trecs"), e.systemFlags.experimentID = i
                        }(e, t), t.modes) {
                        d.mb.TRC.rboxBridgeEnabled && (e.rboxModes = x(e.rboxModes || {}, (0, l.I8)(t.modes)));
                        var i = {};
                        (0, l.mt)(t.modes, (function(e, t) {
                            i[e] = function(e, t) {
                                var n, i;
                                return (0, r.pi)((0, r.pi)({}, t), ((n = {
                                    modeName: e
                                })["thumbnail-position"] = t["thumbnail-position"], n["responsive-rules"] = function(e) {
                                    var t = e["responsive-rules"];
                                    return (0, c.QC)(t) ? [{
                                        rows: g(e.rows) || (0, p.F)(),
                                        cells: g(e["responsive-extra-columns"]) || (0, p.F)(),
                                        ratio: (0, p.F)(),
                                        margin: (0, p.F)()
                                    }] : null == t ? void 0 : t.map((function(t) {
                                        return {
                                            minWidth: t.minWidth || 0,
                                            maxWidth: t.maxWidth || void 0,
                                            rows: g(t.rows),
                                            cells: g(t.cells),
                                            virtualThumbWidth: t.virtualThumbWidth || void 0,
                                            virtualThumbHeight: t.virtualThumbHeight || void 0,
                                            margin: t.margin || {
                                                v: 0,
                                                h: 0
                                            },
                                            ratio: b(e, t)
                                        }
                                    }))
                                }(t), n["before-detail-order"] = _(t["before-detail-order"]), n["before-detail-order-syndicated"] = _(t["before-detail-order-syndicated"]), n["detail-order"] = _(t["detail-order"]), n["detail-order-syndicated"] = _(t["detail-order-syndicated"]), n["thumbnail-width"] = (0, f.BV)(t["thumbnail-width"]), n["thumbnail-height"] = (0, f.BV)(t["thumbnail-height"]), n["carousel-min-items"] = t["carousel-min-items"], n["format-x-days-ago"] = (0, f.td)(t["format-x-days-ago"], (0, p.F)()), n.ctaWidget = (0, f.td)(t.ctaWidget), n["disclosure-position"] = t["disclosure-position"], n["disclosure-alignment"] = t["disclosure-alignment"], n["branding-separator"] = t["branding-separator"], n["disclosure-link-text-sponsored"] = t["disclosure-link-text-sponsored"], n["popup-custom-url"] = t["popup-custom-url"], n["images-radius"] = function(e) {
                                    if (e && "0" !== e) return e.toString()
                                }(t["images-radius"]), n["visibility-constraints"] = {
                                    minWidth: (null == (i = t["visibility-constraints"]) ? void 0 : i.minWidth) || 0,
                                    maxWidth: (null == i ? void 0 : i.maxWidth) || 0
                                }, n))
                            }(e, t)
                        })), e.modes = x(e.modes, i)
                    }
                    d.mb.TRC.rboxBridgeEnabled && function(e, t) {
                        t["publisher-logo"] && (e["publisher-logo"] = t["publisher-logo"]), t["default-thumbnail"] && (e["default-thumbnail"] = t["default-thumbnail"]), t["publisher-branding"] && (e["publisher-branding"] = t["publisher-branding"]), (0, c.r8)(t.metafields) || (e.metafields = t.metafields),
                            function(e, t) {
                                y.forEach((function(n) {
                                    e[n] || (e[n] = t[n])
                                }))
                            }(e, t)
                    }(e, t), h.forEach((function(n) {
                        e[n] = t[n] || e[n]
                    })), ["language", "publisher-branding", "engineScriptUrlParts", "link-target-conf", "direction"].forEach((function(n) {
                        t[n] && (e[n] = t[n])
                    }))
                }

                function x(e, t) {
                    if (!(0, f.it)(e)) return (0, r.pi)({}, t);
                    var n = {};
                    return (0, l.mt)(e, (function(e, r) {
                        var i = n[e] = r;
                        t[e] && (0, l.mt)(t[e], (function(e, t) {
                            (0, c.r8)(t) || (i[e] = t)
                        }))
                    })), n
                }
                var E, T, C, S, R, k, I, L = "all",
                    O = [],
                    M = n(6972),
                    N = n(2057),
                    P = n(6624),
                    D = n(983),
                    A = n(5281),
                    U = n(7807),
                    F = n(6265),
                    q = n(1312),
                    V = n(3887),
                    B = n(4676),
                    j = n(8261),
                    H = n(734),
                    z = n(7952),
                    W = [],
                    G = (0, M.qn)(),
                    Y = (0, H.eo)(),
                    Q = {},
                    K = {},
                    J = {},
                    $ = !1,
                    X = function() {
                        function e() {
                            var e, t, n, r, i = this;
                            this._eventEmitter = new U.v, this.updatePropertyForSpecificModes = function(e) {
                                var t = J.publisher.modes;
                                i._updateModesInList(e, t);
                                var n = (0, V.IB)(e);
                                if (n) {
                                    var r = n.data,
                                        o = n.rboxModesList;
                                    i._updateModesInList(r, o)
                                }
                            }, this.updatePropertyForAllModes = function(e) {
                                var t = e.field,
                                    n = e.value,
                                    r = J.publisher.modes,
                                    o = Object.keys(r || {});
                                if (o) {
                                    i._updateModesInList({
                                        field: t,
                                        value: n,
                                        modeNameList: o
                                    }, r);
                                    var a = (0, V.IB)({
                                        field: t,
                                        value: n
                                    });
                                    if (a) {
                                        var u = a.data,
                                            c = a.rboxModesList;
                                        i._updateModesInList(u, c)
                                    }
                                }
                            }, this._updateModesInList = function(e, t) {
                                var n = e.field,
                                    r = e.value,
                                    i = e.modeNameList;
                                i && t && i.forEach((function(e) {
                                    t[e] && (t[e][n] = r)
                                }))
                            }, J.publisher = ((e = {
                                publisherName: "",
                                global: (t = {}, t.publisherName = "", t["block-video-prob"] = 1, t["rbox-detect-device-id"] = !0, t["ccpa-cdns-enable"] = !0, t["ccpa-ps-enable"] = !0, t["cex-enable"] = !0, t["enable-consent"] = !0, t["enable-real-time-user-sync"] = !0, t["enable-real-time-user-sync-for-all-browsers"] = !0, t["max-wait-for-cmp"] = 5e3, t["image-url-domain"] = "images.taboola.com", t["image-url-type"] = "auto", t["image-quality"] = 80, t["image-url-prefix"] = "https://".concat("{domain}", "/taboola/image/fetch/").concat("{type}", "%2Cq_").concat("{q}", "%2Ch_").concat("{h}", "%2Cw_").concat("{w}", "%2Cc_fill%2Cg_faces:auto%2Ce_sharpen/"), t["gif-url-prefix"] = "https://".concat("{domain}", "/taboola/image/fetch/fl_lossy%2Cf_gif%2Ch_").concat("{h}", "%2Cw_").concat("{w}", "%2Cc_fill%2Cg_faces:auto%2Ce_sharpen/"), t["rtb-image-url-prefix"] = "https://".concat("{domain}", "/taboola/image/fetch/$pw_").concat("{w}", "%2C$ph_").concat("{h}", "/t_tbl-cnd/"), t["store-userid-first-party-cookie"] = !0, t["preconnect-domains"] = ["trc.taboola.com", "images.taboola.com"], t["enable-resource-hints"] = !1, t["requests-domain"] = "trc.taboola.com", t["enable-experiments-variant-id-event"] = !0, t["custom-image-size-round-value"] = 20, t["allow-nofollow-for-exchange"] = !0, t["abp-detection-enabled"] = !0, t["use-abp-uim"] = !0, t["event-types-to-route"] = ["debug", "perf", "social"], t["default-event-route"] = "trc-events.taboola.com", t["trc-event-route-template"] = "<dc>-".concat("trc-events.taboola.com"), t["visible-on-item-level"] = !1, t["send-event-as-post"] = !0, t["send-event-by-beacon"] = !0, t["enable-full-overlay-check"] = !1, t["trc-request-delay"] = 500, t["pref-story-percent"] = 1, t["kr-event"] = "rboxCore", t["kr-index"] = "mbox", t["bulk-available-events-strategy"] = "delay", t["br-event"] = !0, t["url-extract-order"] = ["paramUrl", "meta", "canonical", "og", "location"], t["keep-referrer-in-session"] = !0, t.dy_ext_ptrn = "https://cdn.taboola.com/libtrc/".concat("{pub_name}", "/extensions/dynamic/").concat("{name}", ".js"), t["store-first-party-cookie-in-subdomain"] = !1, t["enable-mode-injection"] = !0, t.style = {}, t["timeago-string-dates"] = !1, t["enable-provider-logo"] = !1, t["link-target-conf"] = (n = {}, n.NT = "_blank", n.NAV = "_self", n.SP = "_blank", n), t["ios-sc-link-target"] = {}, t["yield-render-index"] = -1, t["enable-analytics"] = !1, t["abp-detection-class-names"] = o.tb, t["enable-tslt-inside-iframe"] = !0, t["enable-exm-inside-iframe"] = !1, t["adchoice-item-types"] = (r = {}, r["is-organic"] = !1, r["is-in-network"] = !1, r["is-syndicated"] = !0, r["is-native"] = !0, r), t["has-adchoice"] = !0, t["rbox-perf-el-interval"] = 1e3, t["rbox-perf-el-report-interval"] = 5e3, t["trcinfo-sample-rate"] = .1, t["rbox-error-stack-reporting-pct"] = .01, t["rbox-error-fullUrl"] = .01, t["enable-warn-tbt"] = 0, t["enable-loaf"] = 0, t["enable-shift-cdn-domains"] = !1, t["use-loader-host"] = !1, t["inject-taboolax"] = !1, t["enable-social-events"] = !0, t["enable-browser-data"] = !0, t["disable-rbox-usage-logging"] = !1, t["rbox-usage-logging"] = !0, t["rbox-metrics-enabled"] = .1, t["bulk-metrics-events-strategy"] = "delay", t["bulk-events-delay"] = 1e3, t["enable-always-track"] = !1, t["feed-comments-url-getter"] = function() {
                                    return k.config.runtime.pageUrl.href
                                }, t["load-user-agent-data"] = !1, t["video-gdpr-applies-use-requires-consent"] = !1, t["disable-stop-propagation"] = !1, t["enable-stop-propagation"] = !0, t["video-disclosure-position"] = "above", t["use-unit-fetcher-response-instead-of-tb"] = !0, t["enable-ios-back-fix"] = !0, t["use-ios-safari-override-timeout-config"] = 10, t["use-ios-safari-override"] = !1, t["prior-impl-trecs-net"] = !1, t["send-alternate-container-width"] = !1, t.bakeTime = 0, t["pass-browser-url"] = !0, t["enable-cache-buster"] = !0, t["send-id-providers-data"] = !0, t["enable-crossorigin-anonymous-attribute"] = !1, t["enable-report-trc-use"] = !1, t["browser-benchmark"] = 20, t["loaf-threshold"] = 50, t["topics-enabled"] = !0, t["motion-ads-viewport-lazy-load-margin"] = 0, t["enable-ios-back-fix"] = !0, t["enable-exm-inside-iframe"] = !1, t["enable-cta-component"] = !0, t["inherit-title-color"] = !0, t["title-color"] = !0, t["web-component-app-install-version"] = "1", t["protected-audience-enabled"] = !1, t)
                            })["prenormalize-item-id"] = !1, e["prenormalize-item-url"] = !1, e["publisher-start"] = function() {}, e["normalize-request-param"] = function(e, t, n) {
                                return n
                            }, e["normalize-item-id"] = function() {}, e["normalize-item-url"] = function() {}, e["mode-pub-start"] = function() {}, e["item-data-filter"] = function() {}, e["item-renderer"] = function() {}, e["list-suffix"] = function() {}, e.systemFlags = {
                                loaderType: "trecs",
                                experimentID: []
                            }, e.modes = {}, e["trc-network-mapping"] = {}, e["link-target-conf"] = {}, e.language = "en", e.defaults = {
                                style: ""
                            }, e.engineScriptUrlParts = (0, p.F)(), e.trcForce = (0, p.F)(), e), J.runtime = function() {
                                return {
                                    isAMP: (0, v.Qh)(),
                                    ampData: (0, v.F0)(),
                                    referrerURL: (0, p.F)(),
                                    pageUrl: (0, p.F)(),
                                    networkMapUrl: (0, p.F)(),
                                    debugQueryParams: (0, p.F)(),
                                    trcForce: (0, p.F)(),
                                    supportedFeatures: {},
                                    isHighDensity: (t = 1.3, n = ["only screen and (min-resolution: 124dpi), only screen and (min-resolution: ".concat(t, "dppx), only screen and (min-resolution: 48.8dpcm)"), "only screen and (-webkit-min-device-pixel-ratio: ".concat(t, "), only screen and (-o-min-device-pixel-ratio: ").concat(t, "), only screen and (min--moz-device-pixel-ratio: ").concat(t, "), only screen and (min-device-pixel-ratio:").concat(t, ")")], !!((null === (e = window.matchMedia) || void 0 === e ? void 0 : e.call(window, n[0]).matches) || window.matchMedia(n[1]).matches || window.devicePixelRatio && window.devicePixelRatio > t)),
                                    urlSelectionStrategy: (0, p.F)()
                                };
                                var e, t, n
                            }()
                        }
                        return e.prototype.setupConfig = function() {
                            this.appendPublisherConfig((0, i.u)()), T = (0, q.Qf)("localStorage", (0, a.JK)("user-id", a.E9)) || "", C = (0, q.Qf)("localStorage", (0, a.JK)("session-data", J.publisher.publisherName)) || ""
                        }, Object.defineProperty(e.prototype, "viewId", {
                            get: function() {
                                return d.mb.taboola_view_id || this.changeViewId(), d.mb.taboola_view_id
                            },
                            enumerable: !1,
                            configurable: !0
                        }), e.prototype.changeViewId = function(e) {
                            d.mb.taboola_view_id = e || (0, D.X)()
                        }, Object.defineProperty(e.prototype, "userData", {
                            get: function() {
                                return Y.userData
                            },
                            enumerable: !1,
                            configurable: !0
                        }), e._saveConstData = function() {
                            var e = Y.userData.sessionData;
                            C !== e && (C = e, (0, q.RY)("localStorage", (0, a.JK)("session-data"), e));
                            var t = Y.userData.userId;
                            T !== t && (T = t, (0, q.RY)("localStorage", (0, a.JK)("user-id", a.E9), t))
                        }, Object.defineProperty(e.prototype, "sessionData", {
                            get: function() {
                                return C
                            },
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "userId", {
                            get: function() {
                                return T
                            },
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "pageItemId", {
                            get: function() {
                                return S
                            },
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "eventsRouteOut", {
                            get: function() {
                                var e;
                                return (null === (e = Y.eventRouteOut) || void 0 === e ? void 0 : e.length) > 0 ? Y.eventRouteOut : J.publisher.global["event-types-to-route"]
                            },
                            enumerable: !1,
                            configurable: !0
                        }), e.prototype.signTrackingReportUsed = function() {
                            Y = (0, P.vd)(Y)
                        }, e.prototype.appendTranslationSectionDefaults = function(e, t) {
                            K[e] = t
                        }, e.prototype.setPageId = function(e, t) {
                            S = t || e.pathname || ""
                        }, e.prototype.resetConfigValue = function(e, t) {
                            var n = J.publisher[e];
                            return n && t && (J.publisher[e] = t), n
                        }, e.prototype.resetConfigValueOnModeLevel = function(e, t, n) {
                            var r, i = null === (r = J.publisher.modes[n]) || void 0 === r ? void 0 : r[e];
                            return i && this.updatePropertyForSpecificModes({
                                field: e,
                                value: t,
                                modeNameList: [n]
                            }), i
                        }, e.prototype.fetchTranslationLabel = function(e, t, n) {
                            var r, i, o = Y.translations,
                                a = (null === (r = null == o ? void 0 : o[e]) || void 0 === r ? void 0 : r[t]) || (null === (i = K[e]) || void 0 === i ? void 0 : i[t]);
                            return (0, u.LO)(a, "Translation section '".concat(e, "' label '").concat(t, "' does not exist")), n && 0 !== n.length ? (0, f.mz)(a, n) : a
                        }, e.prototype.onOptionsSummaryUpdated = function(e) {
                            return this._eventEmitter.on("optionsSummary", e)
                        }, e.prototype.onOptionsSummaryUpdatedOnce = function(e) {
                            return this._eventEmitter.once("optionsSummary", e)
                        }, e.prototype.appendOptionsSummary = function(e) {
                            if (!(0, M.in)(e)) {
                                e = (0, M.$q)(G.placements, e), e = (0, M.H)(G.placements, e), e = (0, j.Tt)("e7", e) || e, W.push((0, M.hw)(e)), G = (0, M.M1)(G, e),
                                    function() {
                                        var e, t = J.publisher;
                                        if (!$ && t["trc-network-mapping"] && ($ = !0, (0, f.it)(t["trc-network-mapping"]))) {
                                            J.runtime.networkPublisher = t.publisherName;
                                            var n = t.publisherName = (0, a.MY)(),
                                                i = k.optionsSummary.pageUrl;
                                            i && (0, a.GK)(n) && (n = t.publisherName = (0, a.MY)((0, B.u)(i)));
                                            var o = null === (e = t["network-pubs-global"]) || void 0 === e ? void 0 : e[n];
                                            o && (t.global = (0, r.pi)((0, r.pi)({}, t.global), o))
                                        }
                                    }();
                                try {
                                    this._eventEmitter.emit("optionsSummary", e)
                                } catch (e) {
                                    (0, s.H)("Store appendOptionsSummary listener error", e)
                                }
                            }
                        }, e.prototype.signParsedPlacementsAsParsed = function(e) {
                            var t = e.vl;
                            if (t) {
                                var n = t.map((function(e) {
                                    return (0, z.o)(e)
                                }));
                                G = (0, M.ur)(G, n), W.push(G)
                            }
                        }, e.prototype.signUnusedPlacementsAsUsed = function(e) {
                            G = (0, M.Iu)(G, e), W.push(G)
                        }, e.prototype.updateRboxResponsePlacementIndex = function(e) {
                            0 !== e.length && (G = (0, r.pi)((0, r.pi)({}, G), {
                                placements: G.placements.map((function(t) {
                                    var n = t.rboxResponsesIndex,
                                        i = t.placementName;
                                    return (0, r.pi)((0, r.pi)({}, t), {
                                        rboxResponsesIndex: e.indexOf(i) > -1 ? n + 1 : n
                                    })
                                }))
                            }), W.push(G))
                        }, Object.defineProperty(e.prototype, "optionsSummary", {
                            get: function() {
                                return G
                            },
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "optionsSummaryHistory", {
                            get: function() {
                                return W
                            },
                            enumerable: !1,
                            configurable: !0
                        }), e.prototype.appendPublisherConfig = function(e) {
                            w(J.publisher, e)
                        }, e.prototype.updatePublisherConfig = function(e) {
                            J.publisher = (0, r.pi)((0, r.pi)({}, J.publisher), e)
                        }, e.prototype.appendRuntimeConfig = function(e) {
                            var t, n, i;
                            t = J.runtime, (n = e).pageUrl && (t.pageUrl = n.pageUrl, t.debugQueryParams = (0, r.pi)((0, r.pi)((0, r.pi)({}, t.debugQueryParams), (0, f.BC)(n.pageUrl.search)), n.debugQueryParams), t.urlSelectionStrategy = n.urlSelectionStrategy), n.networkMapUrl && (t.networkMapUrl = n.networkMapUrl), n.trcForce && (t.trcForce = (0, r.pi)((0, r.pi)({}, t.trcForce), n.trcForce)), n.referrerURL && (t.referrerURL = n.referrerURL), n.dcData && (t.dcData = n.dcData), null !== (i = t.userAgentData) && void 0 !== i || (t.userAgentData = n.userAgentData), n.supportedFeatures && (t.supportedFeatures = (0, r.pi)((0, r.pi)({}, t.supportedFeatures), n.supportedFeatures))
                        }, Object.defineProperty(e.prototype, "config", {
                            get: function() {
                                return J
                            },
                            enumerable: !1,
                            configurable: !0
                        }), e.prototype.onResponseSummaryUpdate = function(e) {
                            return this._eventEmitter.on("recommendations", e)
                        }, e.prototype.onReset = function(e) {
                            return this._eventEmitter.on("reset", e)
                        }, e.prototype.onResponseSummaryUpdateOnce = function(e) {
                            return this._eventEmitter.once("recommendations", e)
                        }, e.prototype.appendResponseSummary = function(t) {
                            this.signParsedPlacementsAsParsed(t.originalResponse[0]), Y = (0, N.$)(Y, t), e._saveConstData();
                            try {
                                this._eventEmitter.emit("recommendations", Y)
                            } catch (e) {
                                (0, s.H)("Store appendResponseSummary listener error", e)
                            }
                        }, e.prototype.reset = function() {
                            this._eventEmitter.emit("reset"), G = (0, r.pi)((0, r.pi)({}, (0, M.qn)()), {
                                publisherName: G.publisherName,
                                gdpr: G.gdpr,
                                ccpa: G.ccpa,
                                cex: G.cex
                            }), this.changeViewId(), Y = (0, H.eo)(), Q = {}
                        }, Object.defineProperty(e.prototype, "responseSummary", {
                            get: function() {
                                return Y
                            },
                            enumerable: !1,
                            configurable: !0
                        }), e.prototype.getEntityCustomData = function(e) {
                            return Q[e._ID] || null
                        }, e.prototype.appendEntityCustomData = function(e) {
                            var t = this.getEntityCustomData(e.entity);
                            Q[e.entity._ID] = (0, r.pi)((0, r.pi)({}, t || {}), e)
                        }, e
                    }();

                function Z() {
                    if (R) throw new Error("Store already created");
                    return (0, F.s)((function() {
                        R = new X
                    })).then((function() {
                        return (0, F.s)((function() {
                            R.setupConfig(), k = R, I = R
                        }))
                    })).then((function() {
                        return (0, F.s)((function() {
                            A.Y.emit("storeCreated")
                        }))
                    })).then((function() {
                        return (0, F.s)((function() {
                            A.Y.emit("storeReady")
                        }))
                    }))
                }
            },
            3887: function(e, t, n) {
                "use strict";
                n.d(t, {
                    uL: function() {
                        return b
                    },
                    tt: function() {
                        return f
                    },
                    _X: function() {
                        return h
                    },
                    IB: function() {
                        return _
                    },
                    Mv: function() {
                        return m
                    },
                    Cd: function() {
                        return v
                    }
                });
                var r, i, o = n(3150),
                    a = ((r = {})["thumbnail-position"] = "start", r["carousel-min-items"] = 1.33, r["format-x-days-ago"] = !1, r["disclosure-position"] = "top", r["disclosure-alignment"] = "left", r["attribution-position"] = "bottom", r["image-allowed-ratio-diff"] = .01, r["image-size-factor"] = 1.2, r["image-min-width"] = 110, r["image-max-width"] = 1500, r),
                    u = n(1602),
                    c = n(5281),
                    s = n(6379),
                    l = n(4555),
                    d = n(1591),
                    p = n(9839);

                function f(e, t) {
                    var n, r, i, u = p.L5.config.publisher.modes;
                    return u[e] && null !== (i = null !== (n = u[e][t]) && void 0 !== n ? n : null === (r = u[o._v]) || void 0 === r ? void 0 : r[t]) && void 0 !== i ? i : a[t]
                }

                function m(e, t) {
                    return void 0 === t && (t = !0), (0, d.td)(p.L5.config.publisher.global[e], t)
                }

                function v(e) {
                    return (0, u.DI)(!!p.L5, "can't get global item because taboolaStore isn't defined yet"), p.L5.config.publisher.global[e]
                }

                function h() {
                    return i
                }

                function g() {
                    i = (0, s.I8)(p.L5.optionsSummary)
                }

                function b(e) {
                    var t = {
                        found: [],
                        notFound: []
                    };
                    return e.forEach((function(e) {
                        var n, r = p.L5.optionsSummary.placements.filter((function(t) {
                            return t.placementName === e
                        }));
                        r.length > 0 ? (n = t.found).push.apply(n, r) : t.notFound.push(e)
                    })), t
                }

                function _(e) {
                    var t = e.field,
                        n = e.value,
                        r = e.modeNameList,
                        i = p.L5.config.publisher.rboxModes,
                        o = i ? Object.keys(i) : [];
                    if (l.mb.TRC.rboxBridgeEnabled && o.length && i) return {
                        data: {
                            field: t,
                            value: n,
                            modeNameList: r || o
                        },
                        rboxModesList: i
                    }
                }
                c.Y.once("storeReady", (function() {
                    p.L5.onOptionsSummaryUpdated(g)
                }))
            },
            1602: function(e, t, n) {
                "use strict";

                function r(e, t) {
                    if (null == e) throw new Error(t || "Must have a value")
                }

                function i(e, t) {
                    if (!e) throw new Error(t || "Must be true")
                }
                n.d(t, {
                    DI: function() {
                        return i
                    },
                    LO: function() {
                        return r
                    }
                })
            },
            2146: function(e, t, n) {
                "use strict";

                function r(e) {
                    return (null == e ? void 0 : e.toString().indexOf("[native code]")) > -1
                }
                n.d(t, {
                    Q: function() {
                        return r
                    }
                })
            },
            2271: function(e, t, n) {
                "use strict";

                function r(e) {
                    return "function" == typeof e
                }

                function i(e) {
                    return Array.isArray(e)
                }

                function o(e) {
                    return "string" == typeof e
                }

                function a(e) {
                    return "number" == typeof e
                }

                function u(e) {
                    return !s(e) && "object" == typeof e
                }

                function c(e) {
                    return void 0 === e
                }

                function s(e) {
                    return null === e
                }
                n.d(t, {
                    QC: function() {
                        return s
                    },
                    cb: function() {
                        return o
                    },
                    h0: function() {
                        return i
                    },
                    hR: function() {
                        return r
                    },
                    l7: function() {
                        return a
                    },
                    lp: function() {
                        return u
                    },
                    r8: function() {
                        return c
                    }
                })
            },
            983: function(e, t, n) {
                "use strict";

                function r() {
                    return (new Date).getTime()
                }

                function i(e) {
                    return new Date(1e3 * parseInt(e, 10))
                }
                n.d(t, {
                    X: function() {
                        return r
                    },
                    Y: function() {
                        return i
                    }
                })
            },
            5344: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Z: function() {
                        return a
                    }
                });
                var r = n(6379),
                    i = !1,
                    o = [function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}];

                function a(e) {
                    if (!i) return e;
                    var t, n = (t = e.entityType, Object.create(function(e) {
                        return new e
                    }(o[t])));
                    return (0, r.mt)(e, (function(e, t) {
                        n[e] = t
                    })), n
                }
            },
            5281: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Y: function() {
                        return r
                    }
                });
                var r = new(n(7807).v)
            },
            7807: function(e, t, n) {
                "use strict";
                n.d(t, {
                    v: function() {
                        return i
                    }
                });
                var r = n(6379),
                    i = function() {
                        function e() {
                            this.handlers = {}
                        }
                        return e.prototype.remove = function(e) {
                            var t = this;
                            e instanceof Array ? e.forEach((function(e) {
                                return t.remove(e)
                            })) : "function" == typeof e ? (0, r.mt)(this.handlers, (function(n) {
                                t.off(n, e)
                            })) : this.handlers[e] = []
                        }, e.prototype.removeAll = function() {
                            this.handlers = {}
                        }, e.prototype.detach = function(e, t) {
                            var n = this;
                            if (Array.isArray(t)) t.forEach((function(e) {
                                return n.remove(e)
                            }));
                            else if ("function" == typeof t)(0, r.mt)(this.handlers, (function(e, n) {
                                n.filter((function(e) {
                                    return e.callback === t
                                })).forEach((function(e) {
                                    return n.splice(n.indexOf(e), 1)
                                }))
                            }));
                            else if ("string" == typeof t) {
                                var i = this.handlers[t];
                                i.filter((function(t) {
                                    return t.attachedTo === e
                                })).forEach((function(e) {
                                    return i.splice(i.indexOf(e), 1)
                                }))
                            } else(0, r.mt)(this.handlers, (function(t, n) {
                                n.filter((function(t) {
                                    return t.attachedTo === e
                                })).forEach((function(e) {
                                    return n.splice(n.indexOf(e), 1)
                                }))
                            }))
                        }, e.prototype.attach = function(e, t, n, r) {
                            var i, o = this;
                            i = Array.isArray(t) ? t : [t];
                            var a = [];
                            return i.forEach((function(t) {
                                    o.handlers[t] || (o.handlers[t] = []), o.handlers[t].push({
                                        attachedTo: e,
                                        callback: n,
                                        isOnce: !!r
                                    }), a.push((function() {
                                        o.remove(n)
                                    }))
                                })),
                                function() {
                                    return a.forEach((function(e) {
                                        e()
                                    }))
                                }
                        }, e.prototype.on = function(e, t) {
                            return this.attach(void 0, e, t, !1)
                        }, e.prototype.once = function(e, t) {
                            return this.attach(void 0, e, t, !0)
                        }, e.prototype.off = function(e, t) {
                            var n = this.handlers[e];
                            n.filter((function(e) {
                                return e.callback === t
                            })).forEach((function(e) {
                                return n.splice(n.indexOf(e), 1)
                            }))
                        }, e.prototype.dispatchWithEvent = function(e, t) {
                            this.emit(e, {
                                type: e,
                                data: t
                            })
                        }, e.prototype.emit = function(e, t) {
                            var n = this;
                            (e instanceof Array ? e : [e]).forEach((function(e) {
                                if (n.handlers[e]) {
                                    var r = [];
                                    n.handlers[e].forEach((function(e) {
                                        e.callback(t), e.isOnce && r.push(e)
                                    })), r.forEach((function(e) {
                                        return n.remove(e.callback)
                                    }))
                                }
                            }))
                        }, e.prototype.has = function(e) {
                            var t = this.handlers[e];
                            return !!(null == t ? void 0 : t.length)
                        }, e
                    }()
            },
            2630: function(e, t, n) {
                "use strict";
                n.d(t, {
                    J: function() {
                        return d
                    }
                });
                var r, i = n(5281),
                    o = n(9839),
                    a = n(7253),
                    u = n(4676),
                    c = /^.*\/libtrc\/(.+)\/(?:loader|engine).*\.js(?:\?(.*))?$/;

                function s() {
                    var e;
                    return (null === (e = document.currentScript) || void 0 === e ? void 0 : e.src) || ""
                }

                function l() {
                    var e = "",
                        t = document.getElementsByTagName("script");
                    return (0, a.C2)(t).some((function(t) {
                        return !! function(e) {
                            return !!e.src.match(c)
                        }(t) && (e = t.src, !0)
                    })), e
                }

                function d() {
                    var e;
                    if (r) return r;
                    var t = s() || l();
                    return r = null === (e = t.match(c)) || void 0 === e ? void 0 : e[1]
                }
                i.Y.once("storeCreated", (function() {
                    var e;
                    o.Un.appendPublisherConfig({
                        engineScriptUrlParts: (e = s() || l(), (0, u.u)(e))
                    })
                }))
            },
            1553: function(e, t, n) {
                "use strict";
                n.d(t, {
                    H: function() {
                        return h
                    },
                    Hi: function() {
                        return g
                    },
                    PN: function() {
                        return m
                    },
                    o7: function() {
                        return f
                    },
                    yN: function() {
                        return v
                    }
                });
                var r = n(7582),
                    i = n(1591),
                    o = n(8924),
                    a = n(2414),
                    u = n(6736),
                    c = 2,
                    s = !1,
                    l = "(Ignore This Log)",
                    d = 250;

                function p(e) {
                    return !(e < c) && (2 !== e || (0, a.KB)(o.H.INFO_REPORTING))
                }

                function f() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    p(1) && console.info.apply(console, e)
                }

                function m() {
                    for (var e, t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                    p(2) && (s && t.push(l), (0, u.B$)("info", (0, i.CL)(t), ((e = {}).pct = (0, a.yZ)(o.H.INFO_REPORTING), e)), console.info.apply(console, t))
                }

                function v() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    if (p(3)) {
                        var n = s ? (0, r.ev)([l], e, !0) : e;
                        (0, u.B$)("warn", (0, i.CL)(n)), console.warn.apply(console, e)
                    }
                }

                function h(e, t) {
                    if (void 0 === t && (t = {}), p(4)) {
                        var n = function(e, t) {
                            var n = {
                                message: e,
                                extraData: t
                            };
                            if (!(t instanceof Error)) return n;
                            n.message += t.message || "";
                            var r, i = (r = t.stack) && (0, a.KB)(o.H.ERROR_STACK_REPORTING) ? r.substring(0, d) : "",
                                u = (0, a.KB)(o.H.FULL_URL_REPORTING) ? location.href.substring(0, d) : "";
                            return i && (n.extraData.errStack = i), u && (n.extraData.fullUrl = u), n
                        }(e, t);
                        (0, u.B$)("error", n), console.error(n)
                    }
                }

                function g(e) {
                    e.__trcDebug = f, e.__trcError = h, e.__trcInfo = m, e.__trcWarn = v
                }
            },
            6379: function(e, t, n) {
                "use strict";
                n.d(t, {
                    I8: function() {
                        return p
                    },
                    Io: function() {
                        return v
                    },
                    PM: function() {
                        return d
                    },
                    U: function() {
                        return f
                    },
                    ad: function() {
                        return a
                    },
                    kE: function() {
                        return l
                    },
                    lw: function() {
                        return u
                    },
                    mt: function() {
                        return o
                    },
                    o8: function() {
                        return m
                    },
                    qP: function() {
                        return s
                    },
                    z: function() {
                        return c
                    }
                });
                var r = n(7582),
                    i = n(2271);

                function o(e, t) {
                    Object.keys(e).forEach((function(n) {
                        t(n, e[n])
                    }))
                }

                function a(e) {
                    Object.keys(e).forEach((function(t) {
                        delete e[t]
                    }))
                }

                function u(e, t) {
                    var n = {},
                        r = {};
                    return o(e, (function(e, i) {
                        t(e, i) ? n[e] = i : r[e] = i
                    })), {
                        validItems: n,
                        invalidItems: r
                    }
                }

                function c(e) {
                    return 0 === Object.keys(e).length
                }

                function s(e) {
                    return Object.entries ? Object.entries(e) : Object.keys(e).map((function(t) {
                        return [t, e[t]]
                    }))
                }

                function l(e) {
                    return Object.keys(e).length
                }

                function d(e, t) {
                    return (0, r.pi)((0, r.pi)({}, e || {}), t || {})
                }

                function p(e) {
                    if ("object" != typeof e || null === e) return e;
                    if (Array.isArray(e)) return e.map(p);
                    var t = {};
                    return o(e, (function(e, n) {
                        t[e] = p(n)
                    })), t
                }

                function f(e, t) {
                    for (var n = [], a = 2; a < arguments.length; a++) n[a - 2] = arguments[a];
                    return (0, r.ev)([e, t], n, !0).reduce((function(e, t) {
                        return o(t, (function(t, n) {
                            var o = e[t];
                            o ? (0, i.h0)(o) && (0, i.h0)(n) ? e[t] = (0, r.ev)((0, r.ev)([], o, !0), n, !0) : (0, i.lp)(n) ? e[t] = f(o, n) : e[t] = n : e[t] = p(n)
                        })), e
                    }), {})
                }

                function m(e, t) {
                    return Object.prototype.hasOwnProperty.call(e, t)
                }

                function v(e, t, n) {
                    Object.defineProperty(e, t, {
                        get: function() {
                            return (0, i.hR)(n) ? n() : n
                        }
                    })
                }
            },
            7158: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Q: function() {
                        return o
                    }
                });
                var r, i = n(4794);

                function o(e, t) {
                    var n;
                    return (0, i.Wr)(e) ? ((n = document.createElement("link")).rel = "stylesheet", n.href = e) : (n = document.createElement("style")).innerText = e, (null == t ? void 0 : t.id) && (n.id = t.id), r ? r.insertAdjacentElement("afterend", n) : document.head.insertAdjacentElement("afterbegin", n), r = n, n
                }
            },
            7952: function(e, t, n) {
                "use strict";

                function r(e) {
                    return e.hpl || e.stpl || e.fpl || e.uip
                }
                n.d(t, {
                    o: function() {
                        return r
                    }
                })
            },
            4555: function(e, t, n) {
                "use strict";
                n.d(t, {
                    tp: function() {
                        return b
                    },
                    mb: function() {
                        return g
                    }
                });
                var r, i = n(7807),
                    o = n(5949),
                    a = n(7582),
                    u = n(3887),
                    c = n(5281),
                    s = n(9839),
                    l = n(6736),
                    d = n(1591),
                    p = n(6379),
                    f = 0;

                function m(e, t) {
                    var n = c.Y.on(e, t);
                    return {
                        id: f++,
                        eventName: e,
                        handler: t,
                        remove: n
                    }
                }

                function v(e, t) {
                    c.Y.emit(e, t)
                }

                function h(e) {
                    return c.Y.has(e)
                }
                c.Y.once("storeReady", (function() {
                    var e;
                    (e = g.TRCImpl).global || (e.global = s.L5.config.publisher.global), g.TRC.TRECS = {
                        updateAllModes: s.Un.updatePropertyForAllModes,
                        updateSpecificModes: s.Un.updatePropertyForSpecificModes,
                        merge: p.U
                    }, s.L5.onOptionsSummaryUpdated((function(e) {
                        g.TRC._taboolaClone = (0, a.ev)((0, a.ev)([], g.TRC._taboolaClone, !0), e.__preProcessedOptions__, !0)
                    })), s.L5.onResponseSummaryUpdate((function(e) {
                        g.TRC.events_ri = e.events.requestId || g.TRC.events_ri || ""
                    })), s.L5.onReset((function() {
                        g.TRC._taboolaClone = []
                    }))
                }));
                var g = window,
                    b = window,
                    _ = new i.v;
                (0, o.KP)(), g.taboolaEvents || (g.taboolaEvents = _), g._tblConsole || (g._tblConsole = []), null !== (r = g.trc_debug_level) && void 0 !== r || (g.trc_debug_level = 0),
                    function() {
                        var e, t, n, r, i = g.TRC || (g.TRC = {});
                        i._trecsInit || (i._trecsInit = !0, g.TRCImpl || (g.TRCImpl = {}), (e = g.TRCImpl).sendAbTestEvent || (e.sendAbTestEvent = l.$q), (t = g.TRCImpl).sendExternalRevenueEvent || (t.sendExternalRevenueEvent = l.Al), (n = g.TRCImpl).globaleRequestId || (n.globaleRequestId = ""), i.utm || (i.utm = []), i.preProcessedPushedOptions || (i.preProcessedPushedOptions = []), i.getOptionsSummaryClone || (i.getOptionsSummaryClone = u._X), i.RBoxUsage || (i.RBoxUsage = {}), (r = i.RBoxUsage).logUsage || (r.logUsage = l.W3), i._taboolaClone = [], i.trecsGetQueryParams = d.BC, function() {
                            var e = g.TRC || (g.TRC = {});
                            e.listen || (e.listen = m), e.dispatch || (e.dispatch = v), e.hasEvent || (e.hasEvent = h)
                        }())
                    }()
            },
            4676: function(e, t, n) {
                "use strict";
                n.d(t, {
                    W: function() {
                        return c
                    },
                    u: function() {
                        return o
                    }
                });
                var r, i = n(4583);

                function o(e) {
                    r || (r = document.createElement("a")), r.href = e;
                    var t, n = r.href;
                    return {
                        hash: r.hash,
                        host: r.host,
                        hostname: r.hostname,
                        href: n,
                        origin: r.origin,
                        pathname: (t = r.pathname, (0, i.c)("ie") ? t.length <= 1 ? "/" : "/" !== t[0] ? "/".concat(t) : t : t),
                        port: r.port,
                        protocol: r.protocol,
                        search: r.search,
                        toString: function() {
                            return n
                        }
                    }
                }
                var a = /^((?:https?|file):)?\/\/([^:/$]+)(?::(\d+))?(?:($|\/(?:[^?#]*))?((?:\?(?:[^#]+))?)?(?:(#(?:.*)?)?|$))$/,
                    u = /^(?:($|\/(?:[^?#]*))?((?:\?(?:[^#]+))?)?(?:(#(?:.*)?)?|$))$/;

                function c(e) {
                    var t = e.match(a);
                    if (t) {
                        t[0];
                        var n = t[1],
                            r = t[2],
                            i = t[3],
                            o = t[4],
                            c = t[5],
                            s = {
                                hash: t[6],
                                host: "".concat(r).concat(i ? ":".concat(i) : ""),
                                hostname: r,
                                href: e,
                                origin: "".concat(n, "//").concat(r),
                                pathname: o || "",
                                port: i,
                                protocol: n || "",
                                search: c || "",
                                toString: function() {
                                    var e = "";
                                    if (s.host) {
                                        var t = s.port ? ":".concat(s.port) : "";
                                        e = "".concat(s.protocol || "", "//").concat(s.host).concat(t)
                                    }
                                    return e + "".concat("" === s.pathname ? "/" : s.pathname).concat(s.search || "").concat(s.hash || "")
                                }
                            };
                        return s
                    }
                    var l = e.match(u);
                    if (l) {
                        l[0], o = l[1], c = l[2];
                        var d = {
                            href: e,
                            pathname: o || "",
                            hash: l[3] || "",
                            search: c || "",
                            host: "",
                            hostname: "",
                            origin: "",
                            port: "",
                            protocol: "",
                            toString: function() {
                                return "".concat(d.pathname).concat(d.search || "").concat(d.hash || "")
                            }
                        };
                        return d
                    }
                    return null
                }
            },
            4794: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Kw: function() {
                        return u
                    },
                    O4: function() {
                        return p
                    },
                    Wr: function() {
                        return s
                    },
                    jH: function() {
                        return d
                    },
                    me: function() {
                        return a
                    },
                    nZ: function() {
                        return l
                    }
                });
                var r, i, o = n(2271);

                function a(e) {
                    return r || (r = window.location.protocol), null != i || (i = 0 === r.indexOf("http")), i ? e.replace(/^(?:https?:)?(.*)$/, "".concat(r, "$1")) : 0 === e.indexOf("//") ? "https:".concat(e) : e.replace(new RegExp("^".concat(r, "(.*)$")), "https:$1")
                }

                function u(e) {
                    return /^((?:https?:)?\/\/).*/.test(e) ? e : "//".concat(e)
                }
                var c = /^(https?:)?\/\/([\w\-]+\.)+([a-zA-Z]{2,})[?\/]?.*$/;

                function s(e) {
                    return (0, o.cb)(e) && c.test(e)
                }

                function l(e) {
                    return Object.keys(e).map((function(t) {
                        return "".concat(t, "=").concat(e[t])
                    })).join("&")
                }

                function d(e) {
                    var t = {},
                        n = e.split("?")[1];
                    return n ? (n.split("#")[0].split("&").forEach((function(e) {
                        var n = e.split("=");
                        t[n[0]] = decodeURIComponent(n[1])
                    })), t) : t
                }

                function p(e) {
                    try {
                        return decodeURIComponent(e)
                    } catch (t) {
                        return unescape(e)
                    }
                }
            },
            1591: function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                "use strict";
                __webpack_require__.d(__webpack_exports__, {
                    BC: function() {
                        return extractUrlParams
                    },
                    BV: function() {
                        return parseStringToInt
                    },
                    CL: function() {
                        return convertListToSingleString
                    },
                    Cy: function() {
                        return tryJsonParse
                    },
                    D1: function() {
                        return generateRandomId
                    },
                    JJ: function() {
                        return objectToArray
                    },
                    Jg: function() {
                        return removeWhiteSpaces
                    },
                    NO: function() {
                        return removeAllNewline
                    },
                    Wu: function() {
                        return hashString
                    },
                    fZ: function() {
                        return getArrayUniques
                    },
                    gT: function() {
                        return getPageVerticalScroll
                    },
                    h3: function() {
                        return generateHexID
                    },
                    hX: function() {
                        return tryEval
                    },
                    it: function() {
                        return hasObjectKeys
                    },
                    kB: function() {
                        return mergeArrayTypes
                    },
                    lY: function() {
                        return tryStringify
                    },
                    m9: function() {
                        return callAtNextFrame
                    },
                    mz: function() {
                        return formatStringCurlyPlaceholders
                    },
                    sU: function() {
                        return removeEmptyObjectsFromArray
                    },
                    td: function() {
                        return parseBoolValue
                    },
                    tl: function() {
                        return parseStringToFloat
                    },
                    ug: function() {
                        return isHtmlContent
                    },
                    yA: function() {
                        return roundDecimalNumber
                    },
                    yL: function() {
                        return throttleUtil
                    },
                    zJ: function() {
                        return getPageHorizontalScroll
                    }
                });
                var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7582),
                    _CheckTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2271),
                    _Logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1553),
                    _UrlPartsUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4676);

                function extractUrlParams(e) {
                    if (!e) return {};
                    var t, n;
                    t = 0 === e.indexOf("?") ? e : (0, _UrlPartsUtils__WEBPACK_IMPORTED_MODULE_1__.u)(e).search;
                    for (var r = /\??&?([^=]+)=([^&]+)/gi, i = {}; n = r.exec(t);) {
                        var o = decodeURIComponent(n[1]),
                            a = decodeURIComponent(n[2]);
                        0 === a.indexOf("https") || 0 === a.indexOf("http") ? i[o] = n[2] : i[o] = a
                    }
                    return i
                }

                function extractSubstring(e, t, n) {
                    var r = e.match(new RegExp("".concat(t, "(.*)").concat(n)));
                    return null == r ? void 0 : r[1]
                }

                function parseBoolValue(e, t) {
                    return void 0 === t && (t = !0), "true" === e || !0 === e || "1" === e || 1 === e || "yes" === e || "false" !== e && !1 !== e && "0" !== e && 0 !== e && "no" !== e && ((0, _CheckTypes__WEBPACK_IMPORTED_MODULE_2__.r8)(e) || (0, _Logger__WEBPACK_IMPORTED_MODULE_0__.PN)("parseBoolValue isn't defined properly values is: \"".concat(e, '"')), t)
                }

                function throttleUtil(e, t) {
                    var n = !1,
                        r = null;
                    return function() {
                        for (var i = [], o = 0; o < arguments.length; o++) i[o] = arguments[o];
                        r = (0, tslib__WEBPACK_IMPORTED_MODULE_3__.ev)([], i, !0), n || (e.apply(void 0, r), r = null, n = !0, window.setTimeout((function() {
                            r && e.apply(void 0, r), n = !1
                        }), t))
                    }
                }

                function hasObjectKeys(e) {
                    return void 0 === e && (e = {}), Object.keys(e).length > 0
                }

                function getArrayUniques(e) {
                    return e.filter((function(e, t, n) {
                        return n.indexOf(e) === t
                    }))
                }

                function removeEmptyObjectsFromArray(e) {
                    for (var t = e.length - 1; t >= 0; t--) hasObjectKeys(e[t]) || e.splice(t, 1)
                }

                function getPageVerticalScroll() {
                    return window.pageYOffset || document.body.scrollTop
                }

                function getPageHorizontalScroll() {
                    return window.pageXOffset || document.body.scrollLeft
                }

                function convertListToSingleString(e) {
                    return e.reduce((function(e, t) {
                        var n = (null == t ? void 0 : t.toString()) || "";
                        return e ? "".concat(e, ", ").concat(n) : n
                    }))
                }

                function objectToArray(e) {
                    return Object.keys(e).map((function(t) {
                        return [t, e[t]]
                    }))
                }

                function generateUniqueID() {
                    var e = (new Date).getTime();
                    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(t) {
                        var n = (e + 16 * Math.random()) % 16 | 0;
                        return e = Math.floor(e / 16), ("x" === t ? n : 3 & n | 8).toString(16)
                    }))
                }
                var debugInstanceUniqueID = generateUniqueID();

                function generateRandomId(e) {
                    return "".concat((null == e ? void 0 : e.prefix) || "").concat(1e5 * Math.random() | 0).concat((null == e ? void 0 : e.suffix) || "")
                }

                function roundDecimalNumber(e, t) {
                    void 0 === t && (t = 0);
                    var n = Math.pow(10, t);
                    return Math.round(e * n) / n
                }

                function callAtNextFrame(e, t) {
                    void 0 === t && (t = 2);
                    var n = 0;
                    requestAnimationFrame((function r() {
                        (n += 1) === t ? e() : requestAnimationFrame(r)
                    }))
                }

                function generateHexID() {
                    return [Math.random(), Math.random(), Math.random()].map((function(e) {
                        return e.toString(36).substr(2)
                    })).join("")
                }

                function tryStringify(e) {
                    try {
                        return JSON.stringify(e)
                    } catch (e) {
                        return "Failed to stringify"
                    }
                }

                function tryJsonParse(e) {
                    try {
                        return JSON.parse(e)
                    } catch (e) {
                        return
                    }
                }

                function tryEval(data) {
                    try {
                        return eval(data)
                    } catch (e) {
                        return
                    }
                }

                function removeAllNewline(e) {
                    return e.replace(/\r?\n|\r/g, "")
                }

                function formatStringCurlyPlaceholders(e, t) {
                    return 0 === t.length ? e : e.replace(/\{(\d+)\}/g, (function(e, n) {
                        var r, i = n[0];
                        return null !== (r = t[i]) && void 0 !== r ? r : e
                    }))
                }

                function parseStringToInt(e) {
                    if ((0, _CheckTypes__WEBPACK_IMPORTED_MODULE_2__.cb)(e)) {
                        var t = parseInt(e, 10);
                        return isNaN(t) ? void 0 : t
                    }
                    return null != e ? e : void 0
                }

                function parseStringToFloat(e) {
                    if ((0, _CheckTypes__WEBPACK_IMPORTED_MODULE_2__.cb)(e)) {
                        var t = parseFloat(e);
                        return isNaN(t) ? void 0 : t
                    }
                    return null != e ? e : void 0
                }
                var REGEX_RTL = /[\u0591-\u07FF\uFB1D-\uFDFF\uFE70-\uFEFC]{2,}/,
                    _isTextRtlCache = {};

                function isTextRTL(e) {
                    if (!e) return !1;
                    var t = _isTextRtlCache[e];
                    return (0, _CheckTypes__WEBPACK_IMPORTED_MODULE_2__.r8)(t) && (_isTextRtlCache[e] = t = !!e.match(REGEX_RTL)), t
                }

                function isHtmlContent(e) {
                    return /(%3C|[<>&])/.test(e)
                }

                function hashString(e) {
                    for (var t = 0, n = 0; n < e.length; n++) t = (t << 5) - t + e.charCodeAt(n), t &= t;
                    return t.toString()
                }

                function mergeArrayTypes(e, t, n) {
                    return void 0 === n && (n = []), (0, tslib__WEBPACK_IMPORTED_MODULE_3__.ev)([e, t], n, !0).reduce((function(e, t) {
                        return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.ev)((0, tslib__WEBPACK_IMPORTED_MODULE_3__.ev)([], e, !0), t, !0)
                    }))
                }

                function convertHyphensToCamelCase(e) {
                    var t = e.split("-").map((function(e) {
                        return e.charAt(0).toUpperCase() + e.substring(1)
                    })).join("");
                    return t.charAt(0).toLowerCase() + t.substring(1)
                }

                function removeWhiteSpaces(e) {
                    return (null == e ? void 0 : e.replace(/\s+/g, "")) || ""
                }
            },
            7253: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Au: function() {
                        return s
                    },
                    C2: function() {
                        return c
                    },
                    bf: function() {
                        return u
                    }
                });
                var r, i = n(7582),
                    o = n(4583),
                    a = n(2271);

                function u(e) {
                    for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];

                    function u(e) {
                        for (var t, n = [], i = 1; i < arguments.length; i++) n[i - 1] = arguments[i];
                        null != r || (r = (0, o.c)("ie")), r ? n.forEach((function(t) {
                            e.classList.add(t)
                        })) : (t = e.classList).add.apply(t, n)
                    }(0, a.h0)(e) ? e.forEach((function(e) {
                        u.apply(void 0, (0, i.ev)([e], t, !1))
                    })): u.apply(void 0, (0, i.ev)([e], t, !1))
                }

                function c(e) {
                    return Array.prototype.slice.call(e)
                }

                function s(e) {
                    return Array.prototype.slice.call(e)
                }
            },
            9685: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Ds: function() {
                        return w
                    },
                    Gc: function() {
                        return _
                    },
                    Qi: function() {
                        return b
                    },
                    _R: function() {
                        return v
                    },
                    _W: function() {
                        return h
                    },
                    k: function() {
                        return g
                    }
                });
                var r, i, o = n(2271),
                    a = n(8404),
                    u = n(1591),
                    c = n(4583),
                    s = n(1553),
                    l = n(3265),
                    d = {
                        amp: "&",
                        apos: "'",
                        "#x27": "'",
                        "#x2F": "/",
                        "#39": "'",
                        "#47": "/",
                        lt: "<",
                        gt: ">",
                        nbsp: " ",
                        quot: '"'
                    },
                    p = /&(#(?:x[0-9a-f]+|\d+)|[a-z]+);?/gi,
                    f = "cdn.taboola.com";

                function m(e, t) {
                    var n;
                    return "#" === t[0] ? String.fromCharCode("x" === t[1].toLowerCase() ? parseInt(t.substr(2), 16) : parseInt(t.substr(1), 10)) : null !== (n = d[t]) && void 0 !== n ? n : e
                }

                function v(e) {
                    return (null == e ? void 0 : e.replace(p, m)) || ""
                }

                function h(e, t) {
                    return void 0 === t && (t = {}), new a.e((function(n, i) {
                        var o = document.createElement("script");
                        o.type = "text/javascript", o.src = e, !(0, c.c)("ie") && e.indexOf(f) > -1 && o.setAttribute("crossorigin", "anonymous"), t.defer && o.setAttribute("defer", "defer"), t.async && o.setAttribute("async", "async"), t.id && o.setAttribute("id", t.id), t.attrName && t.attrVal && o.setAttribute(t.attrName, t.attrVal), (null == r ? void 0 : r.parentElement) || (r = document.getElementsByTagName("script")[0]), (null == r ? void 0 : r.parentElement) ? (r.parentElement.insertBefore(o, r), o.addEventListener("load", (function() {
                            return n()
                        })), o.addEventListener("error", (function() {
                            return i({
                                reason: "script: ".concat(o.src),
                                isInfo: !0
                            })
                        }))) : i("can not add script")
                    })).catch((function(t) {
                        ((null == t ? void 0 : t.isInfo) ? s.PN : s.H)("TRECS error in createAndInjectScriptElement()- ".concat((null == t ? void 0 : t.reason) ? null == t ? void 0 : t.reason : JSON.stringify({
                            error: t,
                            url: e
                        })))
                    }))
                }

                function g(e, t) {
                    t && ((0, o.cb)(t) ? ((0, u.ug)(t) && (i || (i = (0, l.U)("textarea")), i.innerHTML = t, t = i.value), e.innerText = t) : e.appendChild(t))
                }

                function b(e) {
                    var t, n, r = null === (t = window.top) || void 0 === t ? void 0 : t.document.querySelector("#".concat(e));
                    if (r) try {
                        return (null === (n = r.contentWindow) || void 0 === n ? void 0 : n.document) || window.document
                    } catch (e) {
                        (0, s.yN)("Error accessing iframe document:", e)
                    } else(0, s.yN)("No iframe found with the specified ID:", e);
                    return window.document
                }

                function _(e, t) {
                    if (!e) return null;
                    if (e.closest) return e.closest(t);
                    if ("undefined" == typeof Element) return null;
                    for (var n = e; !y(n, t);)
                        if (!(n = n.parentElement)) return null;
                    return n
                }

                function y(e, t) {
                    return e.matches ? e.matches(t) : (Element.prototype.msMatchesSelector || Element.oMatchesSelector || Element.mozMatchesSelector || Element.prototype.webkitMatchesSelector).call(e, t)
                }

                function w(e, t, n, r) {
                    void 0 === n && (n = !1), void 0 === r && (r = null);
                    var i = 0;
                    return function() {
                        for (var o = [], a = 0; a < arguments.length; a++) o[a] = arguments[a];
                        var u = n && 0 === i;
                        clearTimeout(i), i = window.setTimeout((function() {
                            i = 0, n || e.apply(r, o)
                        }), t), u && e.apply(r, o)
                    }
                }
            },
            7529: function(e, t, n) {
                "use strict";
                n.d(t, {
                    $q: function() {
                        return a
                    },
                    Xq: function() {
                        return c
                    },
                    sx: function() {
                        return l
                    },
                    z2: function() {
                        return u
                    }
                });
                var r = n(9839),
                    i = n(2939),
                    o = {};

                function a() {
                    return o
                }

                function u() {
                    o = {}
                }

                function c(e) {
                    var t = (0, i.wD)(e),
                        n = t.markerId,
                        a = t.markerHash,
                        u = "".concat(n, "_").concat("s"),
                        c = "".concat(n, "_").concat("e"),
                        s = e.measureLevel || "generalMeasure";
                    return !r.L5 || (0, i.iH)() ? ((0, i.BJ)(u), o[n] = {
                        measuredType: e.measuredType,
                        startMark: u,
                        markerHash: a,
                        measureLevel: s
                    }, function() {
                        (0, i.BJ)(c), o[n] && (o[n].endMark = c)
                    }) : function() {}
                }
                var s = {};

                function l(e) {
                    return s[e.measuredType] ? function() {} : (s[e.measuredType] = !0, c(e))
                }
            },
            2939: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Aj: function() {
                        return m
                    },
                    BJ: function() {
                        return v
                    },
                    Eb: function() {
                        return _
                    },
                    Tj: function() {
                        return w
                    },
                    a: function() {
                        return y
                    },
                    iH: function() {
                        return g
                    },
                    lS: function() {
                        return d
                    },
                    nj: function() {
                        return b
                    },
                    tE: function() {
                        return f
                    },
                    wD: function() {
                        return p
                    }
                });
                var r = n(9839),
                    i = n(3887),
                    o = n(2271),
                    a = n(4555),
                    u = n(1591),
                    c = "~~@~~",
                    s = {},
                    l = "tbl_perf_",
                    d = l + "pageLoadMeasure";

                function p(e) {
                    var t = e.modeName || "",
                        n = e.placement || "",
                        r = t || n ? (0, u.Wu)(t + n) : "",
                        i = l + e.measuredType + (r ? "_".concat(r) : "");
                    return r && (s[r] = t + c + n), {
                        markerId: i,
                        markerHash: r
                    }
                }

                function f() {
                    return s
                }

                function m() {
                    s = {}
                }

                function v(e) {
                    var t, n;
                    window.performance && (null === (n = (t = window.performance).mark) || void 0 === n || n.call(t, e))
                }
                var h = null;

                function g() {
                    return (0, o.QC)(h) ? window.performance ? h = !!r.L5.config.runtime.debugQueryParams["taboola-force-perf"] || function() {
                        if ((0, i.Mv)("enable-analytics", !1)) {
                            var e = _();
                            return !!(null == e ? void 0 : e.measureEnable) && e.traffic >= 100 * Math.random()
                        }
                        return !1
                    }() : (h = !1, !1) : h
                }

                function b() {
                    var e, t;
                    0 === (null === (t = (e = window.performance).getEntriesByName) || void 0 === t ? void 0 : t.call(e, d).length) && (function() {
                        var e, t = w();
                        t && (null === (e = t.setResourceTimingBufferSize) || void 0 === e || e.call(t, t.getEntries().length + 100))
                    }(), v(d))
                }

                function _() {
                    var e;
                    return (null === (e = a.mb.TRC) || void 0 === e ? void 0 : e.perfConfOverride) || (0, i.Cd)("config-analytics")
                }

                function y() {
                    return window.performance ? 0 | performance.now() : 0
                }

                function w() {
                    return window.performance
                }
            },
            6265: function(e, t, n) {
                "use strict";
                n.d(t, {
                    s: function() {
                        return l
                    }
                });
                var r, i, o = n(1688),
                    a = n(8404),
                    u = n(4555),
                    c = n(1591),
                    s = n(4583);

                function l(e, t) {
                    var n;
                    return void 0 === t && (t = !0), r || (r = u.mb.TRC.__optFad || (0, o.u)().global.perf_opt_fader || "tbt"), null != i || (i = null !== (n = u.mb.TRC.__optFadPo) && void 0 !== n ? n : (0, c.td)((0, o.u)().global.enable_opt_fader_poly, !1)), "tbt" === r || "inp" === r && (0, s.c)("input-pend") && navigator.scheduling.isInputPending() ? function(e, t) {
                        if (void 0 === t && (t = !0), (0, s.c)("post-task")) {
                            var n = t ? "user-blocking" : "background";
                            return window.scheduler.postTask(e, {
                                priority: n
                            })
                        }
                        return i ? new a.e((function(t) {
                            window.setTimeout((function() {
                                t(e())
                            }), 0)
                        })) : d(e)
                    }(e, t) : d(e)
                }

                function d(e) {
                    return new a.e((function(t) {
                        t(e())
                    }))
                }
            },
            8404: function(e, t, n) {
                "use strict";
                n.d(t, {
                    e: function() {
                        return r
                    }
                });
                var r = window.Promise;
                r || (r = n(780)), window.Promise || (window.Promise = r), r.allSettled || (r.allSettled = function(e) {
                    var t = e.map((function(e) {
                        return e.then((function(e) {
                            return {
                                status: "fulfilled",
                                value: e
                            }
                        })).catch((function(e) {
                            return {
                                status: "rejected",
                                reason: e
                            }
                        }))
                    }));
                    return r.all(t)
                })
            },
            3239: function(e, t, n) {
                "use strict";
                n.d(t, {
                    F: function() {
                        return a
                    }
                });
                var r = n(9839),
                    i = n(1553),
                    o = "api::";

                function a(e, t) {
                    void 0 === t && (t = void 0), r.L5.optionsSummary.events.filter((function(t) {
                        return t.name === e
                    })).forEach((function(n) {
                        try {
                            n.handler(new CustomEvent(o + e, {
                                detail: t
                            }))
                        } catch (t) {
                            (0, i.yN)('error while sending event "'.concat(e, '"'), (null == t ? void 0 : t.message) || "")
                        }
                    }))
                }
            },
            7863: function(e, t, n) {
                "use strict";
                n.d(t, {
                    uP: function() {
                        return x
                    },
                    Rt: function() {
                        return T
                    },
                    Wt: function() {
                        return E
                    }
                });
                var r, i = n(7582),
                    o = n(3595),
                    a = n(9839),
                    u = n(3887),
                    c = n(1602),
                    s = n(1553),
                    l = n(1591),
                    d = n(7329),
                    p = ["click"],
                    f = n(5705),
                    m = n(2939);
                var v, h = "updateCounter",
                    g = "storyTimeline",
                    b = ((r = {}).coreLoaded = {
                        index: 1,
                        time: (0, f.dl)()
                    }, r),
                    _ = "";
                var y = {};

                function w() {
                    (0, l.it)(y) && (function(e) {
                        var t, n;
                        ! function() {
                            var e;
                            if (!v) {
                                var t = a.L5.config.publisher;
                                (e = {
                                    _id: (0, l.h3)().substr(0, 20),
                                    coreVersion: (0, d.X)(),
                                    publisherName: t.publisherName,
                                    event: (0, u.Cd)("kr-event")
                                })[g] = b, v = e
                            }
                        }(), _ || (_ = (0, u.Cd)("kr-index"));
                        var r, c = v.hasOwnProperty(h) ? v[h] + 1 : 0;
                        e[g] && (e[g] = (r = {}, Object.keys(b).map((function(e) {
                            var t, n = b[e];
                            return {
                                stepName: e,
                                time: 0 | ((null === (t = n.content) || void 0 === t ? void 0 : t.startTime) || n.time),
                                content: n.content
                            }
                        })).sort((function(e, t) {
                            return e.time < t.time ? -1 : e.time > t.time ? 1 : 0
                        })).forEach((function(e, t) {
                            r[e.stepName] = {
                                index: t + 1,
                                time: e.time,
                                content: e.content
                            }
                        })), r));
                        var p = (0, i.pi)((0, i.pi)((0, i.pi)((0, i.pi)({}, v), {
                            userId: (null === (n = a.L5.userData) || void 0 === n ? void 0 : n.userId) || "",
                            timestamp: (new Date).toISOString()
                        }), e), ((t = {})[h] = c, t));
                        v = p, (0, s.o7)("Report Kibana:", p), (0, o.lY)({
                            url: "https://vidanalytics.taboola.com/putes/".concat(_),
                            body: JSON.stringify(p)
                        }).catch((function() {
                            (0, s.o7)("Trying to send might failed if not allowed by configuration")
                        }))
                    }(y), y = {}, -1 !== S && (window.clearTimeout(S), S = -1))
                }

                function x(e, t) {
                    var n;
                    void 0 === t && (t = null), (0, f.MQ)() && (y = (0, i.pi)((0, i.pi)({}, y), ((n = {})[e] = t || (0, m.a)() || "empty", n)), k())
                }

                function E(e, t) {
                    void 0 === t && (t = void 0), (0, f.MQ)() && ((0, c.DI)("error" !== e, "Report error by 'kibanaReportStoryErrorStep' function"), b[e] || (b[e] = C(t), y[g] = b, p.indexOf(e) > -1 ? w() : k()))
                }

                function T(e) {
                    if ((0, f.MQ)()) {
                        var t = b.error || C(e);
                        t.content !== e && (t.content += " \n ".concat(e)), b.error = t, y[g] = b, k()
                    }
                }

                function C(e) {
                    return void 0 === e && (e = void 0), {
                        index: Object.keys(b).length + 1,
                        time: (0, f.dl)(),
                        content: e
                    }
                }
                document.addEventListener("visibilitychange", w);
                var S = -1,
                    R = 5e3;

                function k() {
                    -1 === S && (S = window.setTimeout((function() {
                        S = -1, w()
                    }), R))
                }
            },
            5705: function(e, t, n) {
                "use strict";
                n.d(t, {
                    MQ: function() {
                        return s
                    },
                    dl: function() {
                        return d
                    },
                    hz: function() {
                        return u
                    }
                });
                var r = n(3887),
                    i = n(983),
                    o = n(9839),
                    a = n(2939);

                function u(e) {
                    (new Image).src = e
                }
                var c = null;

                function s() {
                    if (null !== c) return c;
                    if (!o.L5) return !1;
                    var e = (0, r.Cd)("pref-story-percent");
                    return c = Math.round(Math.random()) <= e
                }
                var l = (0, i.X)();

                function d() {
                    return (0, a.a)() || (0, i.X)() - l
                }
            },
            5087: function(e, t, n) {
                "use strict";
                n.d(t, {
                    $0: function() {
                        return v
                    },
                    XT: function() {
                        return h
                    }
                });
                var r, i = n(3229),
                    o = n(9839),
                    a = n(3887),
                    u = n(2271),
                    c = n(6379),
                    s = n(4583),
                    l = (n(2600), n(983)),
                    d = n(4794),
                    p = {},
                    f = {},
                    m = 4096;

                function v(e) {
                    return w(), f[e] || void 0
                }

                function h() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    w(), e.forEach((function(e) {
                            return delete p[e]
                        })),
                        function() {
                            if (_()) {
                                var e = (0, c.qP)(p).map((function(e) {
                                    var t = e[0],
                                        n = e[1];
                                    return "".concat(encodeURIComponent(t), "=").concat(encodeURIComponent(n))
                                })).join("|");
                                if (!(e.length >= m)) {
                                    var t = !!e,
                                        n = new Date((0, l.X)() + (t ? E : -1));
                                    document.cookie = "".concat(b, "=").concat(encodeURIComponent(e), ";domain=").concat(function() {
                                        if ((0, u.cb)(x)) return x;
                                        if (x = "", !(0, a.Mv)("store-first-party-cookie-in-subdomain")) return x;
                                        var e = o.L5.config.runtime.pageUrl.hostname;
                                        if (!e) return x;
                                        var t = e.split(".").reverse();
                                        return x = ".".concat(t[1], ".").concat(t[0]), t.length >= 3 && t[1].match(/^(com|edu|gov|net|mil|org|nom|co|name|info|biz)$/i) && (x = ".".concat(t[2], ".").concat(t[1], ".").concat(t[0])), x
                                    }(), ";path=/;expires=").concat(n.toUTCString())
                                }
                            }
                        }()
                }
                var g, b = "trc_cookie_storage";

                function _() {
                    return null != g || (g = (0, s.c)("cookies") && !(0, i.Qh)()), g
                }

                function y(e, t) {
                    if (!e) return {};
                    var n = {};
                    return e.split(t).map((function(e) {
                        return e.split("=")
                    })).forEach((function(e) {
                        var t = e[0],
                            r = e[1];
                        n[t] = (0, d.O4)(r)
                    })), n
                }

                function w() {
                    var e;
                    _() && r !== document.cookie && (r = document.cookie, e = (f = y(r, /;\s*/))[b], p = y(e, "|"))
                }
                var x, E = 31536e6
            },
            2600: function(e, t, n) {
                "use strict";
                n.d(t, {
                    R: function() {
                        return v
                    }
                });
                var r = n(7582),
                    i = n(9839),
                    o = n(5281),
                    a = n(6379),
                    u = n(5087),
                    c = n(1312),
                    s = !0,
                    l = {},
                    d = {},
                    p = {},
                    f = function() {
                        function e() {}
                        return e.prototype.isConsentApproved = function() {
                            return s
                        }, e.prototype.addStorageKey = function(e, t) {
                            l[t] || (l[t] = {}), l[t][e] = !0
                        }, e.prototype.addCookiesKey = function(e) {
                            d[e] = !0
                        }, e.prototype.save = function(e, t) {
                            p[e] = t
                        }, e.prototype.read = function(e) {
                            return p[e]
                        }, e
                    }();

                function m() {
                    var e = i.L5.userData.consentApproved;
                    s && !e ? (s = !1, (0, a.mt)(l, (function(e, t) {
                        c.KR.apply(void 0, (0, r.ev)([e], Object.keys(t), !1))
                    })), u.XT.apply(void 0, Object.keys(d))) : !s && e && (s = !0)
                }
                o.Y.once("storeReady", (function() {
                    i.L5.onResponseSummaryUpdate(m)
                }));
                var v = new f
            },
            1312: function(e, t, n) {
                "use strict";
                n.d(t, {
                    KR: function() {
                        return v
                    },
                    Lh: function() {
                        return l
                    },
                    Qf: function() {
                        return m
                    },
                    RY: function() {
                        return s
                    }
                });
                var r, i = n(1553),
                    o = n(4583),
                    a = n(2600),
                    u = n(983),
                    c = ((r = {}).localStorage = (0, o.c)("local-storage"), r.sessionStorage = (0, o.c)("session-storage"), r);

                function s(e, t, n, r) {
                    if (void 0 === r && (r = 0), r > 0 && (n = p(n, r)), a.R.isConsentApproved())
                        if (c[e]) try {
                            window[e].setItem(t, n), a.R.addStorageKey(t, e)
                        } catch (r) {
                            (0, i.PN)('Storage "'.concat(e, '" exceeded')), c[e] = !1, a.R.save(t, n)
                        } else a.R.save(t, n);
                        else a.R.save(t, n)
                }

                function l(e, t, n, r) {
                    if (void 0 === r && (r = 0), r > 0 && (n = p(n, r)), c[e]) try {
                        window[e].setItem(t, n)
                    } catch (r) {
                        c[e] = !1, a.R.save(t, n)
                    } else a.R.save(t, n)
                }
                var d = "__s__";

                function p(e, t) {
                    var n = 1e3 * t,
                        r = (0, u.X)() + n;
                    return e + d + r
                }
                var f = "__expired__";

                function m(e, t) {
                    var n;
                    if (n = c[e] ? window[e].getItem(t) || a.R.read(t) || "" : a.R.read(t)) {
                        var r = function(e) {
                            var t = e.split(d),
                                n = t[0],
                                r = t[1];
                            return r && (0, u.X)() > parseInt(r) ? f : n
                        }(n);
                        if (r !== f) return r;
                        v(e, t)
                    }
                }

                function v(e) {
                    for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                    c[e] && t.forEach((function(t) {
                        return window[e].removeItem(t)
                    }))
                }
            },
            1085: function(e, t, n) {
                "use strict";

                function r() {}
                n.d(t, {
                    F: function() {
                        return r
                    }
                })
            },
            4583: function(e, t, n) {
                "use strict";
                n.d(t, {
                    m: function() {
                        return j
                    },
                    c: function() {
                        return B
                    }
                });
                var r = n(2146),
                    i = n(7582);
                var o, a, u, c, s, l, d, p, f, m, v, h, g, b, _, y, w, x, E, T, C, S, R, k, I, L, O, M, N, P, D, A, U = navigator.userAgent,
                    F = navigator.platform,
                    q = "__tcigc__",
                    V = (p = ["iPhone Simulator", "iPod Simulator", "iPhone", "iPod"].indexOf(F) > -1 && !window.MSStream && /iphone(?:.+?os (\d+))?/i.test(U), m = (f = ["iPad Simulator", "iPad"].indexOf(F) > -1 || navigator.userAgent.indexOf("Mac") > -1 && "ontouchend" in document) || /ip[honead]{2,4}(?:.*os\s(\w+)\slike\smac|;\sopera)/i.test(U), v = /(mac\sos\sx)\s?([\w\s\.]*)/i.test(U), h = /mobile/i.test(U), b = (g = /android/i.test(U)) && !h, _ = g && h, y = /win/i.test(F), w = /phone/i.test(U), x = y && !w && /touch/i.test(U), E = /blackberry/i.test(U) || /bb10/i.test(U), T = function() {
                        try {
                            window.localStorage.setItem(q, "c"), window.localStorage.removeItem(q)
                        } catch (e) {
                            return !1
                        }
                        return !0
                    }(), C = function() {
                        try {
                            window.sessionStorage.setItem(q, "c"), window.sessionStorage.removeItem(q)
                        } catch (e) {
                            return !1
                        }
                        return !0
                    }(), S = parseFloat((null === (a = U.match(/version\/([\w\.]+).+?(mobile\s?safari|safari)/i)) || void 0 === a ? void 0 : a[1]) || "0"), R = /(trident).+rv[:\s]([\w\.]+).+like\sgecko/i.test(U), k = /(?:firefox|fxios)\/(\d+)/i.test(U), I = /(edge|edgios|edga|edg)\/((\d+)?[\w\.]+)/i.test(U), L = /(?:^opera.+?version|opr)\/(\d+)/i.test(U), O = /opera mini\/(\d+)/i.test(U), M = /bot|google|baidu|bing|msn|duckduckgo|teoma|slurp|yandex/i.test(U), N = /ֿ\[FB(?:\_|[A-Z]+)+/i.test(U), D = (P = /macintosh/i.test(U)) || p || f || m || v, A = /webkit/i.test(U), (o = {}).iphone = p, o.ipad = f, o.ios = m, o.mac = !f && v, o.safari = !!S, o["android-mobile"] = _, o["android-tablet"] = b, o.android = g, o.blackberry = E, o.opera = L, o["opera-mini"] = O, o.ie = R, o.edge = I, o["cr-ios"] = (m || f) && U.indexOf("CriOS") > -1, o.ff = k, o["uc-browser"] = /((?:[\s\/])uc?\s?browser|(?:juc.+)ucweb)[\/\s]?([\w\.]+)/i.test(U), o.samsung = /android.+(sch-i[89]0\d|shw-m380s|gt-p\d{4}|gt-n\d+|sgh-t8[56]9|nexus 10)/i.test(U) || /(SM-T\w+)/i.test(U) || /SAMSUNG|Samsung|SGH-[I|N|T]|GT-[I|N]|SM-[J|G|A|N|P|T|Z]|SHV-E|SCH-[I|J|R|S]|SPH-L/.test(U), o.chrome = !(!(null === (u = window.chrome) || void 0 === u ? void 0 : u.webstore) && !(null === (c = window.chrome) || void 0 === c ? void 0 : c.runtime)) || !k && !I && !L && !O && !S && /(chrome)\/\d+/i.test(U), o.bot = M, o.window = y, o["window-phone"] = y && w, o["window-tablet"] = x, o.desktop = !p && !f && !g, o.tablet = f || g && !h || x, o.mobile = p || _ || y && w || E, o.webview = U.indexOf("; wv") > -1 || m && !window.navigator.standalone && !/safari/i.test(U), o["ios-standalone"] = m && !!window.navigator.standalone, o.iframe = window.top !== window.self, o.twin = window.top === window.self, o["local-storage"] = T, o["session-storage"] = C, o.storage = C && T, o.cookies = function() {
                        if (!navigator.cookieEnabled) return !1;
                        try {
                            document.cookie
                        } catch (e) {
                            return !1
                        }
                        return !0
                    }(), o.apple = D, o.webkit = A, o.macintosh = P, o.safari16 = 16 === S, o["send-beacon"] = !R && !!window.navigator.sendBeacon && !!window.Blob && (!S || S >= 13), o["new-regex"] = function() {
                        try {
                            new RegExp("(?<={)(?<x>abc)")
                        } catch (e) {
                            return !1
                        }
                        return !0
                    }(), o.Unknown = !1, o.facebook = N, o["web-components"] = !R && function() {
                        return !(!window.HTMLElement || !window.customElements) && (!!(0, r.Q)(null === (e = window.customElements) || void 0 === e ? void 0 : e.define) || function() {
                            var e = "tbl-cet";
                            try {
                                var t = function(e) {
                                    function t() {
                                        return null !== e && e.apply(this, arguments) || this
                                    }
                                    return (0, i.ZT)(t, e), t
                                }(HTMLElement);
                                if (! function(e, t) {
                                        var n = !1;
                                        try {
                                            window.customElements.get(e) || window.customElements.define(e, t), n = function(e, t) {
                                                try {
                                                    return new t, document.createElement(e) instanceof t
                                                } catch (e) {}
                                                return !1
                                            }(e, t)
                                        } catch (e) {}
                                        return n
                                    }(e, t)) return !1;
                                var n = document.createElement(e);
                                return n.attachShadow({
                                    mode: "open"
                                }), !!n.shadowRoot
                            } catch (e) {
                                return !1
                            }
                        }());
                        var e
                    }(), o["post-task"] = (0, r.Q)(window.Scheduler) && !!(null === (s = window.scheduler) || void 0 === s ? void 0 : s.postTask), o["input-pend"] = (0, r.Q)(window.Scheduling) && !!(null === (l = navigator.scheduling) || void 0 === l ? void 0 : l.isInputPending), o["touch-device"] = f || p || b || _ || x || y && w || E, o["browsing-topics"] = !!document.browsingTopics, o["protected-audience"] = !!navigator.runAdAuction && !!(null === (d = document.featurePolicy) || void 0 === d ? void 0 : d.allowsFeature("run-ad-auction")), o);

                function B(e) {
                    return V[e]
                }

                function j(e, t) {
                    return (!(n = e) || 0 === n.length || 0 !== n.map((function(e) {
                        return V[e]
                    })).filter((function(e) {
                        return e
                    })).length) && function(e) {
                        return !e || 0 === e.length || !(e.map((function(e) {
                            return V[e]
                        })).filter((function(e) {
                            return e
                        })).length > 0)
                    }(t);
                    var n
                }
            },
            2414: function(e, t, n) {
                "use strict";
                n.d(t, {
                    KB: function() {
                        return s
                    },
                    W: function() {
                        return l
                    },
                    yZ: function() {
                        return c
                    }
                });
                var r = n(1591),
                    i = n(3887),
                    o = n(9839),
                    a = n(8924),
                    u = {};

                function c(e) {
                    if (!o.L5) return function(e) {
                        if (e === a.H.ERROR_STACK_REPORTING) return .01;
                        if (e === a.H.INFO_REPORTING) return .1;
                        if (e === a.H.FULL_URL_REPORTING) return .01;
                        if (e === a.H.TBT_REPORTING) return 0;
                        throw new Error("Sample Type not Supported")
                    }(e);
                    switch (e) {
                        case a.H.ERROR_STACK_REPORTING:
                            return (0, i.Cd)("rbox-error-stack-reporting-pct");
                        case a.H.INFO_REPORTING:
                            return (0, i.Cd)("trcinfo-sample-rate");
                        case a.H.FULL_URL_REPORTING:
                            return (0, i.Cd)("rbox-error-fullUrl");
                        case a.H.TBT_REPORTING:
                            return (0, i.Cd)("enable-warn-tbt");
                        case a.H.LOAF_REPORTING:
                            return (0, i.Cd)("enable-loaf")
                    }
                }

                function s(e) {
                    if (!u.hasOwnProperty(e)) {
                        var t = Math.random();
                        u[e] = t <= c(e)
                    }
                    return u[e]
                }

                function l(e) {
                    return "true" === e ? 1 : (0, r.tl)(e) || 0
                }
            },
            862: function(e, t, n) {
                "use strict";
                n.d(t, {
                    k: function() {
                        return d
                    }
                });
                var r, i, o = n(9839),
                    a = n(5281),
                    u = n(8404),
                    c = n(1312),
                    s = "user-agent-data",
                    l = ["platformVersion", "mobile", "model", "platform", "platformVersion", "uaFullVersion"];

                function d() {
                    if (i) return i;
                    var e, t, n, o = (e = (0, c.Qf)("localStorage", s)) ? JSON.parse(e) : e;
                    return o ? (r = o, i = u.e.resolve(r)) : i = (t = l, (null === navigator || void 0 === navigator ? void 0 : navigator.userAgentData) ? null === (n = navigator.userAgentData) || void 0 === n ? void 0 : n.getHighEntropyValues(t) : u.e.resolve(void 0)).then((function(e) {
                        if (e) return r = e, p(), (0, c.RY)("localStorage", s, JSON.stringify(r), 604800), r
                    })).catch((function() {}))
                }

                function p() {
                    r && !o.L5.config.runtime.userAgentData && o.Un.appendRuntimeConfig({
                        userAgentData: r
                    })
                }
                a.Y.once("storeCreated", (function() {
                    d(), p()
                }))
            },
            8924: function(e, t, n) {
                "use strict";
                var r;
                n.d(t, {
                        H: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e[e.ERROR_STACK_REPORTING = 1] = "ERROR_STACK_REPORTING", e[e.INFO_REPORTING = 2] = "INFO_REPORTING", e[e.FULL_URL_REPORTING = 3] = "FULL_URL_REPORTING", e[e.TBT_REPORTING = 4] = "TBT_REPORTING", e[e.LOAF_REPORTING = 5] = "LOAF_REPORTING"
                    }(r || (r = {}))
            },
            7329: function(e, t, n) {
                "use strict";
                n.d(t, {
                    X: function() {
                        return i
                    },
                    w: function() {
                        return o
                    }
                });
                var r = "";

                function i() {
                    return r
                }

                function o(e) {
                    r = e
                }
            },
            2143: function(e, t, n) {
                "use strict";
                n.d(t, {
                    jO: function() {
                        return Z
                    },
                    eL: function() {
                        return W
                    },
                    se: function() {
                        return z
                    },
                    Xq: function() {
                        return re
                    },
                    Tt: function() {
                        return Y
                    },
                    T3: function() {
                        return j
                    },
                    Ub: function() {
                        return q
                    },
                    K7: function() {
                        return K
                    },
                    RG: function() {
                        return G
                    },
                    lQ: function() {
                        return H
                    },
                    hE: function() {
                        return V
                    },
                    CT: function() {
                        return B
                    }
                });
                var r, i, o, a, u, c, s, l, d, p = n(7582),
                    f = n(734),
                    m = n(4400),
                    v = n(9839),
                    h = n(3887),
                    g = n(2271),
                    b = n(6379),
                    _ = n(1312),
                    y = n(1085),
                    w = n(1591),
                    x = n(4583),
                    E = ((r = {}).pl = [], r.sii = [], r.pe = [], r),
                    T = ((i = {}).ttl = 3e5, i.cacheName = "trc_cache", i.disableFeedCache = !1, i.cacheSize = 5, i.storageType = "session", i.trecsConfExcl = E, i),
                    C = ((o = {}).text = "c", o.home = "c", o.video = "d", o.search = "d", o.category = "d", o.photo = "d", o.other = "d", o.content_hub = "d", o),
                    S = n(7429),
                    R = n(9319),
                    k = n(8824),
                    I = n(9790),
                    L = n(9707),
                    O = n(1602),
                    M = n(2188),
                    N = n(9725),
                    P = "tbl_disable_cache",
                    D = {},
                    A = Date.now(),
                    U = 0,
                    F = ["f"];

                function q() {
                    var e, t, n, r, i, o, a, u, c, s, f, g, b, y, S, R, k, I, L, O, M, N, D = v.L5.pageItemId,
                        A = v.L5.config.runtime;
                    return !(A.ampData.isSplitFeed || A.debugQueryParams[P] || (e = (0, h.Cd)("trc-cache-it"), t = (0, m.r)(v.L5.optionsSummary.itemSourceType), "c" !== function(e) {
                        return (0, p.pi)((0, p.pi)({}, C), e || {})
                    }(e)[t] || (n = {
                        userOptOut: v.L5.optionsSummary.userOptOut,
                        cacheConfig: (0, h.Cd)("trc-cache-conf"),
                        pageItemId: D
                    }, L = n.cacheConfig, s = (0, p.pi)((0, p.pi)({}, T), L || {}), f = "".concat(s.cacheName, "_").concat(n.pageItemId), g = "".concat(s.cacheName, "_dict"), b = ne(E.pl), y = ne(null === (o = null === (i = n.cacheConfig) || void 0 === i ? void 0 : i.trecsConfExcl) || void 0 === o ? void 0 : o.pl), S = ne(E.pe), R = ne(null === (u = null === (a = n.cacheConfig) || void 0 === a ? void 0 : a.trecsConfExcl) || void 0 === u ? void 0 : u.pe), k = ne(E.sii), I = ne(null === (c = null == s ? void 0 : s.trecsConfExcl) || void 0 === c ? void 0 : c.sii), (r = {})[6] = (0, w.kB)(y, b), r[7] = (0, w.kB)(R, S), r[8] = (0, w.kB)(I, k), r[5] = "session" === s.storageType ? "sessionStorage" : "localStorage", r[4] = s.cacheSize, r[3] = s.disableFeedCache, r[2] = g, r[9] = n.userOptOut, r[0] = s.ttl, r[1] = f, O = "localStorage" === (l = r)[5] ? "local-storage" : "session-storage", !(0, x.c)(O) || X(D, l[8]) || (M = l[2], N = (0, _.Qf)(l[5], M), d = N ? JSON.parse(N) : [], !$() && d.length === l[4]))))
                }

                function V(e) {
                    var t, n = null == s ? void 0 : s.ct;
                    if (!n || !te(n)) {
                        ! function(e) {
                            var t = (0, b.I8)(e),
                                n = (0, f.W3)(t);
                            (0, w.td)(l[3]) || (R.f.updateCache(n, t), I.h.updateCache(n, t)), L.m.updateCache(n, t), M.s.updateCache(n, t), N.q.updateCache(n, t), k.$.updateCache(n, t)
                        }(e), v.L5.optionsSummary.placements.forEach((function(e) {
                            var t = D[e.placementName];
                            t && (t.d.pp = !0)
                        }));
                        var r = function(e) {
                            var t = (0, b.I8)(e);
                            return delete t.vl, F.forEach((function(e) {
                                delete t[e]
                            })), l[9] && l[7].forEach((function(e) {
                                delete t[e]
                            })), t
                        }(e);
                        U || (U = parseInt(v.L5.viewId)), (t = {}).cvi = U, t.gr = r, t.prdl = D, t.ct = n || A, s = t, v.L5.config.runtime.isAMP && J()
                    }
                }

                function B() {
                    return !!(s || function() {
                        var e, t, n = l[5],
                            r = (0, _.Qf)(n, l[1]);
                        if (r && !te((s = JSON.parse(r)).ct)) return t = s.prdl, (0, b.mt)(t, (function(e, t) {
                            var n = D[e] = new ie;
                            n.addPlacements(t.pl), n.setProductData(t.d)
                        })), e = s.cvi, v.Un.changeViewId(e), s
                    }()) && !te(s.ct)
                }

                function j() {
                    document.addEventListener("visibilitychange", (function() {
                        var e, t, n;
                        "hidden" === document.visibilityState && (J(), e = function() {
                            if (!s) return d;
                            if (!$()) {
                                var e = l[1];
                                d.push([e, s.ct])
                            }
                            return d
                        }().filter((function(e) {
                            var t = e[0];
                            return !te(e[1]) || ((0, _.KR)(l[5], t), !1)
                        })), t = l[5], n = l[2], 0 !== e.length ? (0, _.RY)(t, n, JSON.stringify(e)) : (0, _.KR)(t, n))
                    }))
                }

                function H() {
                    s = (0, y.F)(), l = (0, y.F)(), D = {}, A = Date.now()
                }

                function z(e) {
                    var t = e.data,
                        n = (0, b.I8)(s.gr),
                        r = [],
                        i = [],
                        o = [],
                        a = {
                            requestList: i,
                            genericResponse: n,
                            placementListToRender: r,
                            servingCachedRequestIds: o
                        };
                    if (function(e, t) {
                            e.forEach((function(e) {
                                ee(e.uip) ? function(e, t) {
                                    var n = re(e.uip);
                                    (0, S.oQ)(e, t, n) || Q(n, t)
                                }(e, t) : t.requestList.push(e)
                            })), (0, b.mt)(D, (function(e, n) {
                                var r, i;
                                if (ee(e)) {
                                    var o = n.d;
                                    o && !o.pp && (null === (r = I.h.updateRootResponseCache) || void 0 === r || r.call(I.h, t, o, e), null === (i = M.s.updateRootResponseCache) || void 0 === i || i.call(M.s, t, o, e), Q(n, t))
                                }
                            }))
                        }(t.r, a), t.r = i, 0 === r.length) return {
                        payload: e
                    };
                    n.vl = r;
                    var u = (0, f.W3)(n);
                    return u.cachedViewId = s.cvi, {
                        servingReqIdList: o,
                        response: u,
                        payload: 0 === i.length ? void 0 : e
                    }
                }

                function W(e, t, n) {
                    if (function(e) {
                            return !!e && !G(e.uip, 6)
                        }(e)) {
                        (0, O.LO)(e);
                        var r = e.uip,
                            i = t.vl,
                            o = re(r);
                        null == n || n(o),
                            function(e, t, n) {
                                Z(Y(e, n), t)
                            }(r, o, i)
                    }
                }

                function G(e, t) {
                    return X(e, l[t])
                }

                function Y(e, t) {
                    return t.filter((function(n, r) {
                        var i = (n.fpl || n.uip) === e;
                        return i && delete t[r], i
                    }))
                }

                function Q(e, t) {
                    K(e.pl, t)
                }

                function K(e, t) {
                    var n, r, i = t.placementListToRender;
                    n = e, r = t.servingCachedRequestIds, n.forEach((function(e) {
                        r.push(e.ri)
                    })), i.push.apply(i, e)
                }

                function J() {
                    if (s && !te(s.ct)) {
                        var e = l[5],
                            t = l[1];
                        (0, _.RY)(e, t, JSON.stringify(s))
                    }
                }

                function $() {
                    return d.some((function(e) {
                        var t = e[0];
                        return l[1] === t
                    }))
                }

                function X(e, t) {
                    return t.some((function(t) {
                        return -1 !== e.indexOf(t)
                    }))
                }

                function Z(e, t) {
                    null == t || t.addPlacements(e)
                }

                function ee(e) {
                    var t = D[e],
                        n = X(e, l[6]);
                    return t && !n
                }

                function te(e) {
                    return Date.now() > e + l[0]
                }

                function ne(e) {
                    return (0, g.h0)(e) ? e : (0, g.cb)(e) ? [e] : (0, g.l7)(e) ? [e.toString()] : []
                }

                function re(e) {
                    var t = D[e];
                    return t || (t = D[e] = new ie), t
                }
                var ie = function() {
                    function e() {
                        var e;
                        this[a] = [], this[u] = (0, y.F)(), this[c] = 1, this.d = ((e = {}).r = {}, e)
                    }
                    return e.prototype.increaseNextBatchNumber = function() {
                        this.nb++
                    }, e.prototype.addPlacements = function(e) {
                        this.pl = (0, p.ev)((0, p.ev)([], this.pl, !0), e, !0)
                    }, e.prototype.setProductData = function(e) {
                        this.d = e
                    }, e.prototype.setRequestData = function(e) {
                        this.d.r = e
                    }, e
                }();
                a = "pl", u = "d", c = "nb"
            },
            4362: function(e, t, n) {
                "use strict";
                n.d(t, {
                    xM: function() {
                        return r
                    }
                });
                var r = "rbox-only-video"
            },
            7582: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Jh: function() {
                        return u
                    },
                    ZT: function() {
                        return i
                    },
                    ev: function() {
                        return c
                    },
                    mG: function() {
                        return a
                    },
                    pi: function() {
                        return o
                    }
                });
                var r = function(e, t) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    }, r(e, t)
                };

                function i(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    r(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }
                var o = function() {
                    return o = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                        return e
                    }, o.apply(this, arguments)
                };

                function a(e, t, n, r) {
                    return new(n || (n = Promise))((function(i, o) {
                        function a(e) {
                            try {
                                c(r.next(e))
                            } catch (e) {
                                o(e)
                            }
                        }

                        function u(e) {
                            try {
                                c(r.throw(e))
                            } catch (e) {
                                o(e)
                            }
                        }

                        function c(e) {
                            var t;
                            e.done ? i(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                                e(t)
                            }))).then(a, u)
                        }
                        c((r = r.apply(e, t || [])).next())
                    }))
                }

                function u(e, t) {
                    var n, r, i, o, a = {
                        label: 0,
                        sent: function() {
                            if (1 & i[0]) throw i[1];
                            return i[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return o = {
                        next: u(0),
                        throw: u(1),
                        return: u(2)
                    }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                        return this
                    }), o;

                    function u(u) {
                        return function(c) {
                            return function(u) {
                                if (n) throw new TypeError("Generator is already executing.");
                                for (; o && (o = 0, u[0] && (a = 0)), a;) try {
                                    if (n = 1, r && (i = 2 & u[0] ? r.return : u[0] ? r.throw || ((i = r.return) && i.call(r), 0) : r.next) && !(i = i.call(r, u[1])).done) return i;
                                    switch (r = 0, i && (u = [2 & u[0], i.value]), u[0]) {
                                        case 0:
                                        case 1:
                                            i = u;
                                            break;
                                        case 4:
                                            return a.label++, {
                                                value: u[1],
                                                done: !1
                                            };
                                        case 5:
                                            a.label++, r = u[1], u = [0];
                                            continue;
                                        case 7:
                                            u = a.ops.pop(), a.trys.pop();
                                            continue;
                                        default:
                                            if (!((i = (i = a.trys).length > 0 && i[i.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                                a = 0;
                                                continue
                                            }
                                            if (3 === u[0] && (!i || u[1] > i[0] && u[1] < i[3])) {
                                                a.label = u[1];
                                                break
                                            }
                                            if (6 === u[0] && a.label < i[1]) {
                                                a.label = i[1], i = u;
                                                break
                                            }
                                            if (i && a.label < i[2]) {
                                                a.label = i[2], a.ops.push(u);
                                                break
                                            }
                                            i[2] && a.ops.pop(), a.trys.pop();
                                            continue
                                    }
                                    u = t.call(e, a)
                                } catch (e) {
                                    u = [6, e], r = 0
                                } finally {
                                    n = i = 0
                                }
                                if (5 & u[0]) throw u[1];
                                return {
                                    value: u[0] ? u[1] : void 0,
                                    done: !0
                                }
                            }([u, c])
                        }
                    }
                }

                function c(e, t, n) {
                    if (n || 2 === arguments.length)
                        for (var r, i = 0, o = t.length; i < o; i++) !r && i in t || (r || (r = Array.prototype.slice.call(t, 0, i)), r[i] = t[i]);
                    return e.concat(r || Array.prototype.slice.call(t))
                }
                Object.create, Object.create, "function" == typeof SuppressedError && SuppressedError
            }
        },
        __webpack_module_cache__ = {};

    function __webpack_require__(e) {
        var t = __webpack_module_cache__[e];
        if (void 0 !== t) return t.exports;
        var n = __webpack_module_cache__[e] = {
            exports: {}
        };
        return __webpack_modules__[e](n, n.exports, __webpack_require__), n.exports
    }
    __webpack_require__.d = function(e, t) {
        for (var n in t) __webpack_require__.o(t, n) && !__webpack_require__.o(e, n) && Object.defineProperty(e, n, {
            enumerable: !0,
            get: t[n]
        })
    }, __webpack_require__.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    };
    var __webpack_exports__ = {};
    ! function() {
        "use strict";
        var e = __webpack_require__(9839),
            t = __webpack_require__(3887),
            n = __webpack_require__(5281),
            r = __webpack_require__(1591),
            i = __webpack_require__(1553),
            o = __webpack_require__(1312),
            a = __webpack_require__(4555),
            u = __webpack_require__(3229);

        function c(e, t) {
            return [].slice.apply(document.head.getElementsByTagName(e)).filter(t)[0] || null
        }
        var s = __webpack_require__(4676);
        var l = "tbl-sesn-ref";

        function d() {
            if ((0, u.Qh)()) return a.tp.context.referrer;
            if (window.self === window.top) return a.mb.document.referrer;
            try {
                var e = a.mb.top.window.document.referrer;
                return e && !/https?:\/\/(\w+)\.taboola(syndication)?\.com/.test(e) ? e.substr(0, 400) : e.split("?")[0]
            } catch (e) {
                (0, i.yN)("Rendering in cross domain iframe")
            }
            return ""
        }
        n.Y.once("storeCreated", (function() {
            e.Un.appendRuntimeConfig({
                referrerURL: function() {
                    var e;
                    return (null === (e = c("link", (function(e) {
                        return "referrer" === e.rel
                    }))) || void 0 === e ? void 0 : e.href) || null
                }() || d() || function() {
                    if (!(0, t.Mv)("keep-referrer-in-session")) return "";
                    var e = (0, o.Qf)("sessionStorage", l);
                    return (0, o.RY)("sessionStorage", l, location.href), e && location.hostname === (0, s.u)(e).host ? e : ""
                }() || ""
            }), e.L5.onOptionsSummaryUpdatedOnce((function(t) {
                (null == t ? void 0 : t.referrerUrl) && e.Un.appendRuntimeConfig({
                    referrerURL: t.referrerUrl
                })
            }))
        })), n.Y.once("storeCreated", (function() {
            if ((0, t.Mv)("rbox-detect-device-id")) {
                var n = function(e) {
                    var t = (0, r.BC)(e),
                        n = t.redir ? (0, r.BC)(t.redir) : {},
                        i = t.dc_data || n.dc_data;
                    if (i && t.ui) return {
                        deviceId: t.ui,
                        content: i
                    }
                }(d());
                n && e.Un.appendRuntimeConfig({
                    dcData: n
                })
            }
        }));
        var p, f = __webpack_require__(1688),
            m = __webpack_require__(5949),
            v = __webpack_require__(7582),
            h = __webpack_require__(1602),
            g = __webpack_require__(2271),
            b = __webpack_require__(6265),
            _ = __webpack_require__(8404),
            y = __webpack_require__(1085),
            w = __webpack_require__(5087),
            x = -1,
            E = 50;

        function T() {
            var e = (0, w.$0)("usprivacy");
            if (e) return {
                uspString: e,
                version: (0, y.F)()
            }
        }

        function C(e) {
            return p || (p = new _.e((function(e) {
                var t = x,
                    n = a.mb.__uspapi;
                if ((0, g.hR)(n)) try {
                    n("getUSPData", 1, (function(n, r) {
                        t !== x && clearTimeout(t), e(r ? n : T())
                    })), t = window.setTimeout((function() {
                        e()
                    }), E)
                } catch (t) {
                    (0, i.H)("__uspapi failed:", t), e(T())
                } else e(T())
            })).then((function(t) {
                return (null == t ? void 0 : t.uspString) || e
            }))), p
        }

        function S() {
            var e = {
                cmpStatus: 3
            };
            return new _.e((function(n) {
                var r = (0, t.Cd)("max-wait-for-cmp"),
                    i = 0;
                r > 0 && (i = window.setTimeout((function() {
                    e.wasTimeout = !0, n(e)
                }), r)), new _.e((function(e, t) {
                    a.mb.__tcfapi ? (a.mb.__tcfapi("addEventListener", 2, (function(n, r) {
                        n.eventStatus && (r ? "tcloaded" === n.eventStatus || "useractioncomplete" === n.eventStatus ? (a.mb.__tcfapi("removeEventListener", 2, (function() {}), n.listenerId), e({
                            cmpStatus: 0,
                            gdprApplies: !0 === n.gdprApplies || "true" === n.gdprApplies,
                            tcString: n.tcString,
                            wasTimeout: !1
                        })) : t("GDPR v2 consent data not ready") : t("GDPR v2 failed consent"))
                    })), a.mb.__tcfapi("getTCData", 2, (function(n, r) {
                        r ? e({
                            cmpStatus: 0,
                            gdprApplies: !0 === n.gdprApplies || "true" === n.gdprApplies,
                            tcString: n.tcString,
                            wasTimeout: !1
                        }) : t("GDPR v2 failed consent")
                    }))) : t("GDPR v2 not exist")
                })).then((function(e) {
                    n(e)
                })).catch((function() {
                    return new _.e((function(e, t) {
                        a.mb.__cmp ? a.mb.__cmp("getConsentData", null, (function(t) {
                            e({
                                cmpStatus: 0,
                                gdprApplies: !0 === t.gdprApplies || "true" === t.gdprApplies,
                                consentDaisyBit: t.consentData,
                                wasTimeout: !1
                            })
                        })) : t("GDPR v1 not exist")
                    })).then((function(e) {
                        return n(e)
                    }))
                })).catch((function() {
                    i && window.clearTimeout(i), e.cmpStatus = 2, n(e)
                }))
            }))
        }
        var R = __webpack_require__(9685),
            k = __webpack_require__(7529),
            I = __webpack_require__(4583),
            L = __webpack_require__(6972),
            O = "tbl_rtus_id",
            M = 2,
            N = 42,
            P = 91,
            D = "RealTimeUserSyncCallback";

        function A(t) {
            return function(e) {
                return e ? (F("ccpaPushTriggerRtus"), "Y" === (t = e).charAt(2) ? (q(), _.e.resolve((0, y.F)())) : U("&us_privacy=".concat(t, "&gdpr=0&gdpr_consent=&gdpr_pd="))) : (0, g.hR)(a.mb.__tcfapi) ? new _.e((function(e, t) {
                    var n;
                    try {
                        null === (n = a.mb.__tcfapi) || void 0 === n || n.call(a.mb, "getTCData", M, (function(n, r) {
                            r ? function(e) {
                                return function(e) {
                                    return !e.gdprApplies
                                }(e) || function(e) {
                                    var t, n = null === (t = null == e ? void 0 : e.vendor) || void 0 === t ? void 0 : t.consents;
                                    return n && n.hasOwnProperty(N) && n.hasOwnProperty(P)
                                }(e)
                            }(n) ? (F("gdprV2triggerRtus"), e(function(e) {
                                return U("&us_privacy=&gdpr=".concat(e.gdprApplies ? 1 : 0, "&gdpr_consent=").concat(e.tcString, "&gdpr_pd=0"))
                            }(n))) : t("gdprV2notTriggerRtus") : t("gdprV2fail")
                        }), [N, P])
                    } catch (e) {
                        t(e.toString())
                    }
                })) : (0, g.hR)(a.mb.__cmp) ? _.e.reject("gdprV1") : (F("default"), U(""));
                var t
            }(t).then((function(t) {
                return t && (e.Un.appendOptionsSummary((0, v.pi)((0, v.pi)({}, (0, L.qn)()), {
                    realTimeUserId: t
                })), a.mb.TRC.rtbRealTimeUserId = t), t
            })).catch((function(e) {
                return F(e), (0, o.Qf)("localStorage", O)
            }))
        }

        function U(e) {
            return new _.e((function(t) {
                var n = (0, k.Xq)({
                        measuredType: "rtus",
                        modeName: D
                    }),
                    r = "//gum.criteo.com/sync?c=72&r=2&j=TRC.getRTUS".concat(e),
                    u = a.mb.TRC;
                try {
                    (0, R._W)(r), (0, i.PN)("page", "info", "injected RTUS service")
                } catch (e) {
                    (0, i.yN)("Error during RTUS loading asset file: ", e)
                }
                u.getRTUS = function(e) {
                    n();
                    var r = e || {},
                        i = r.status,
                        a = r.userid;
                    "OK" === i ? ((0, o.RY)("localStorage", O, a), u.rtbRealTimeUserId = a, t(a)) : (q(), t((0, y.F)()))
                }
            }))
        }

        function F(e) {
            (0, i.o7)("rtus", {
                file: "rtus.js",
                method: "injectRtus",
                message: e
            })
        }

        function q() {
            (0, o.KR)("localStorage", O)
        }

        function V(e, t, n) {
            var r = document.createElement("script");
            return r.type = "text/javascript", r.async = !0, r.src = e, t && (r.onload = t), n && (r.onerror = n), document.getElementsByTagName("head")[0].insertAdjacentElement("afterbegin", r), r
        }
        var B = __webpack_require__(7072),
            j = "//pm-widget.taboola.com",
            H = {
                prod: j,
                sb: "//pm-widget-sandbox.taboola.com"
            },
            z = !1;

        function W() {
            z = !1
        }

        function G(n) {
            if (!z && !(0, I.c)("bot")) {
                var i = n.itemSourceType;
                if (a.mb.pm_pgtp !== i) {
                    var o = (0, r.BC)((0, B.Js)())["taboolax-load"],
                        u = function(e, n) {
                            return !("_default_" === e) && ((0, t.Mv)("inject-taboolax") || !!n)
                        }(i, o);
                    u && (z = !0, function(t, n) {
                        var r = H[n] || j,
                            i = e.L5.config.publisher.publisherName,
                            o = e.L5.config.runtime.networkPublisher;
                        a.mb.pm_pgtp = t, V("".concat(r, "/").concat(o || i, "/load.js"))
                    }(i, o))
                }
            }
        }
        var Y, Q, K, J = null;

        function $() {
            if ((0, u.Qh)() && (0, t.Cd)("override-amp-url")) {
                var e = a.tp.context,
                    n = e.canonicalUrl,
                    r = e.location;
                return n.indexOf("?") > -1 ? n + r.search.replace("?", "&") : n + r.search
            }
        }

        function X() {
            if (Q) return Q;
            var e = $() || a.mb.location.href;
            return (0, s.u)(e)
        }

        function Z() {
            var e, t = (null === (e = c("meta", (function(e) {
                return "item-url" === e.name
            }))) || void 0 === e ? void 0 : e.content) || null;
            return t ? (0, s.u)(t) : null
        }

        function ee() {
            var e, t = (null === (e = c("meta", (function(e) {
                return "og:url" === e.getAttribute("property")
            }))) || void 0 === e ? void 0 : e.content) || null;
            return t ? (0, s.u)(t) : null
        }

        function te() {
            var e, t = (null === (e = c("link", (function(e) {
                return "canonical" === e.rel
            }))) || void 0 === e ? void 0 : e.href) || null;
            return t ? (0, s.u)(t) : null
        }

        function ne() {
            for (var e = 0, n = (0, t.Cd)("url-extract-order"); e < n.length; e++) {
                var r = n[e];
                switch (r) {
                    case "location":
                        J = X();
                        break;
                    case "meta":
                        J = Z();
                        break;
                    case "og":
                        J = ee();
                        break;
                    case "canonical":
                        J = te();
                        break;
                    case "paramUrl":
                        J = Y
                }
                if (J) {
                    K = r;
                    break
                }
            }
            return (0, h.LO)(J, "pageURL must have value"), J
        }

        function re(e) {
            Q = (0, s.u)(e)
        }

        function ie() {
            var t;
            e.Un.appendRuntimeConfig({
                pageUrl: ne(),
                networkMapUrl: X(),
                debugQueryParams: (t = X().search, t ? (0, r.BC)(t) : {}),
                urlSelectionStrategy: K
            })
        }
        n.Y.once("storeCreated", ie), n.Y.on("storeReady", (function() {
            e.L5.onReset(ie)
        }));
        var oe = __webpack_require__(4794),
            ae = __webpack_require__(5962),
            ue = __webpack_require__(8261),
            ce = [],
            se = [];

        function le(n) {
            if (ce.push(n), (0, g.cb)(n)) {
                var r = (0, oe.Wr)(n) ? n : (a = n, de || (de = (0, t.Cd)("dy_ext_ptrn").replace("{pub_name}", e.L5.config.publisher.publisherName)), de.replace("{name}", a));
                return (o = r, new _.e((function(e, t) {
                    var n = V(o, (function() {
                        e(n)
                    }), t)
                })).catch((function(e) {
                    (0, i.H)("TRECS error in loadScriptPromise():  ", e)
                }))).then((function() {
                    (0, i.o7)('Dynamic extension "'.concat(n, '" loaded from URL: ').concat(r))
                })).catch((function() {
                    (0, i.H)('Dynamic extension "'.concat(n, '" failed to load from URL: ').concat(r))
                }))
            }
            var o, a, u = _.e.resolve();
            if (!(0, g.hR)(n)) return pe(n), fe(n), u;
            try {
                return pe(c = n()), fe(c), u
            } catch (e) {}
            try {
                var c;
                return pe(c = new n), fe(c), u
            } catch (e) {}
            return (0, i.H)("Extension type not supported"), u
        }
        var de = "";

        function pe(t) {
            (function(t) {
                var n, r, o = null === (n = t.getName) || void 0 === n ? void 0 : n.call(t);
                if (!(0, g.cb)(o)) return (0, i.H)('Invalid extension: "getName" function'), !1;
                var a = 0 === se.filter((function(e) {
                    return e.getName() === o
                })).length;
                if (!a) return (0, i.H)('Invalid extension: Name "'.concat(o, '" already exist')), !1;
                var u = null === (r = t.getSupportedFeatures) || void 0 === r ? void 0 : r.call(t);
                return !! function(t) {
                    if (!(null == t ? void 0 : t.length)) return !0;
                    var n = e.L5.config.runtime.supportedFeatures;
                    for (var r in t)
                        if (n[r]) return !1;
                    return !0
                }(u) || ((0, i.H)('Invalid extension: Features "'.concat(u, '" already supported by another extension')), !1)
            })(t) && (se.push(t), (0, ue.G$)(t), function(t) {
                var n, r = null === (n = t.getSupportedFeatures) || void 0 === n ? void 0 : n.call(t);
                if (r && 0 !== r.length) {
                    var i = {};
                    r.forEach((function(e) {
                        i[e] = !0
                    })), e.Un.appendRuntimeConfig({
                        supportedFeatures: i
                    })
                }
            }(t))
        }

        function fe(e) {
            var t, n;
            if (ue.HF) {
                var r = null === (n = null === (t = e.e1) || void 0 === t ? void 0 : t.call(e)) || void 0 === n ? void 0 : n.map(le);
                (r ? _.e.all(r) : _.e.resolve()).then((function() {
                    var t, n;
                    null === (n = null === (t = e.e2) || void 0 === t ? void 0 : t.call(e)) || void 0 === n || n.map(le)
                })).then((function() {
                    var t;
                    null === (t = e.e6) || void 0 === t || t.call(e, (0, ae.N)())
                }))
            }
        }
        var me = __webpack_require__(4866);

        function ve(t, n) {
            if (Array.isArray(t)) t.forEach((function(e) {
                ve(e, n)
            }));
            else {
                var r = t.overrideConfig;
                r && (r.global && (n.__overrideGlobal__ = (0, v.pi)((0, v.pi)({}, n.__overrideGlobal__), r.global)), r.trcForce && (e.Un.appendRuntimeConfig({
                    trcForce: (0, v.pi)({}, r.trcForce)
                }), r.trcForce = (0, y.F)()), e.Un.appendPublisherConfig(r))
            }
        }

        function he(n, i) {
            if ((0, g.h0)(n)) {
                for (; n.length > 0;) he(n.shift(), i);
                n.forEach((function(e) {
                    he(e, i)
                }))
            } else i.__preProcessedOptions__.push(n),
                function(e, t) {
                    e.rec && (t.scod || (t.scod = {}), t.scod.trcResponse = e.rec.trc), e["rtb-win"] && (t.scod || (t.scod = {}), t.scod.rtbWin = e["rtb-win"])
                }(n, i), n.framework && (i.framework = n.framework), (0, r.td)(n.flush, !1) && (i.isFlush = !0), n.mode ? (0, L.aR)(n, i) : function(n, i) {
                    (function(e, t) {
                        var n, r = "";
                        Object.keys(me.V).filter((function(t) {
                            var n = e[t];
                            return !!n && "unknown" !== n || "" === n
                        })).forEach((function(t) {
                            null != n || (n = t);
                            var i = e[t];
                            r || (r = "auto" === i ? "" : i)
                        })), n && (t.itemSourceType = n, t.itemSourceValue = r)
                    })(n, i), n.device && (i.deviceId = n.device), n.unified_id && (i.unifiedId = n.unified_id), n.cex && (0, t.Mv)("cex-enable") && (i.gdpr = i.gdpr || {
                            cmpStatus: 3
                        }, 0 !== i.gdpr.cmpStatus && (i.gdpr.cex = n.cex)), n.cseg && (i.customSegment = n.cseg), n.ccpaPs && (0, t.Mv)("ccpa-ps-enable") && (i.ccpa || (i.ccpa = {}), i.ccpa.privacyString = n.ccpaPs), n.cdns && (0, t.Mv)("ccpa-cdns-enable") && (i.ccpa || (i.ccpa = {}), i.ccpa.CDNS = n.cdns), n.listenTo && n.handler && i.events.push({
                            name: n.listenTo,
                            handler: n.handler
                        }), n.name,
                        function(e, t) {
                            ge("social-available", e, t), ge("social-visible", e, t), ge("social-share", e, t), ge("social-like", e, t)
                        }(n, i), n.url && (i.pageUrl = (0, oe.Kw)(n.url)), n.mapUrl && (i.networkMapUrl = (0, oe.Kw)(n.mapUrl)), n.referrer && (i.referrerUrl = n.referrer), n.additional_data && (i.additionalData = n.additional_data), n.extension && le(n.extension), (0, r.td)(n.user_opt_out, !1) && (i.userOptOut = !0), n.exp && (i.excludePubs = n.exp), n.tracking_codes && (i.trackingCodes = n.tracking_codes), (0, L.oy)(n) && e.Un.reset(), n.template && (i.pageTemplate = n.template), n.advertorial_source && (i.advertorialSource = n.advertorial_source), n.external_page_view && (i.externalPageView = n.external_page_view), n.user_type && (i.userType = function(e) {
                            switch (e) {
                                case "guest":
                                case "subscriber":
                                case "registered":
                                    return e;
                                default:
                                    return "other"
                            }
                        }(n.user_type)), (0, r.td)(n.paywall, !1) && (i.paywall = !0), (0, r.td)(n.premium, !1) && (i.premium = !0), n.link_target && (i.linkTarget = n.link_target), n.tracking && (i.tracking = n.tracking), n.exclude_recommendations && (i.excludedRecs = n.exclude_recommendations), n.pubExperiment && (i.pubExperiment = n.pubExperiment)
                }(n, i)
        }

        function ge(e, t, n) {
            var r = t[e];
            r && n.socials.push({
                name: e,
                data: r
            })
        }
        var be = __webpack_require__(878),
            _e = function() {
                function t(t) {
                    var n = this;
                    this._messages = [], this._promise = null, this._results = (0, L.qn)(), this._flushWait = !1, this._processPushMessage = function() {
                        for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                        if (0 === t.length) return n._messages.length;
                        var i = t[0];
                        return !(0, g.h0)(i) && i.rects && i.placement ? n._messages.length : (n._promise || (n._promise = _.e.resolve(), n._results = (0, L.qn)(), n._promise.then(n.processAllMessages)), n._flushWait ? (t.forEach((function(e) {
                            ye(e) && (n._results = (0, L.qn)()), he(e, n._results)
                        })), n._messages.length) : (e = n._messages).push.apply(e, t))
                    }, this.processAllMessages = function() {
                        var t = -1;
                        n._messages.forEach((function(e, n) {
                            ye(e) && (t = n)
                        })), t > 0 && n._messages.splice(t - 1, t), (0, L.yM)(n._messages), n._messages.forEach((function(e) {
                            he(e, n._results)
                        })), n._messages = [], n._flushWait = !0, we(n._results).then((function() {
                            n._flushWait = !1, n._promise = null, e.Un.appendOptionsSummary(n._results)
                        }))
                    }, t.push = this._processPushMessage
                }
                return t.override = function(e) {
                    new t(e)
                }, t
            }();

        function ye(e) {
            var t = !1;
            return (0, g.h0)(e) ? t = e.filter((function(e) {
                return (0, L.oy)(e)
            })).length > 0 : (0, L.oy)(e) && (t = !0), t
        }

        function we(e) {
            var n = e.placements.length > 0;
            if (e.isFlush || !n) return _.e.resolve(!0);
            var r = (0, t.Cd)("trc-request-delay");
            return r <= 5 ? (e.isFlush = !0, _.e.resolve(!0)) : new _.e((function(t) {
                window.setTimeout((function() {
                    (0, i.o7)("Append 'flush' after '".concat(r, "ms'")), e.isFlush = !0, t(!0)
                }), r)
            }))
        }
        var xe = !1;

        function Ee() {
            (0, h.DI)(!xe, "TaboolaObject must be Pre Process only once"), xe = !0;
            var n, r, o = [],
                a = (0, L.qn)();
            if (a.publisherName = e.L5.config.publisher.publisherName, ve((0, m.cV)(), a), (0, L.yM)((0, m.cV)()), he((0, m.cV)(), a), (0, be.Ll)(a), o.push.apply(o, function(e) {
                    var n, r = [];
                    if ((0, u.Qh)()) return r.push((0, u.R9)().then((function(t) {
                        t.ccpa && (e.ccpa = t.ccpa), t.gdpr && (e.gdpr = t.gdpr)
                    }))), r;
                    if ((0, t.Mv)("enable-consent")) {
                        var i = (0, b.s)(S).then((function(e) {
                            return e
                        })).then((function(t) {
                            e.gdpr = (0, v.pi)((0, v.pi)({}, e.gdpr), t)
                        }));
                        r.push(i)
                    }
                    var o = null === (n = e.ccpa) || void 0 === n ? void 0 : n.privacyString;
                    return (0, t.Mv)("ccpa-ps-enable") && r.push(C(o).then((function(t) {
                        t && (e.ccpa = e.ccpa || {}, e.ccpa.privacyString = t)
                    }))), (0, t.Mv)("enable-real-time-user-sync") && ((0, t.Mv)("enable-real-time-user-sync-for-all-browsers") || (0, I.m)(["ff", "edge", "safari"])) && (0, b.s)((function() {
                        C(o).then(A)
                    })), r
                }(a)), e.L5.onOptionsSummaryUpdated(G), e.L5.onReset(W), a.pageUrl) {
                n = a.pageUrl, r = $() || n, Y = (0, s.u)(r), re(a.pageUrl);
                var c = ne();
                e.Un.appendRuntimeConfig({
                    pageUrl: c,
                    networkMapUrl: c
                })
            }
            return a.networkMapUrl && (re(a.networkMapUrl), e.Un.appendRuntimeConfig({
                networkMapUrl: X()
            })), e.Un.setPageId(e.L5.config.runtime.pageUrl, e.L5.config.runtime.itemId), o.push(we(a)), _e.override((0, m.cV)()), _.e.all(o).then((function() {
                return e.Un.appendOptionsSummary(a), (0, i.o7)(a), e.L5.optionsSummary
            }))
        }
        var Te, Ce = "registerExtension";

        function Se(e) {
            n.Y.once(Ce, (function() {
                window[m.fR].push({
                    extension: e
                })
            }))
        }

        function Re(e) {
            Te || (Te = e)
        }

        function ke(e) {
            return (0, h.LO)(Te, "modulesAccessData must have a value"), Te[e]
        }
        var Ie = __webpack_require__(2146);

        function Le(n) {
            var r = (0, t.Mv)("enable-cache-buster");
            n.hasCacheBuster && r && ((0, Ie.Q)(window.fetch) && (0, Ie.Q)(window.Request) ? function() {
                var t = e.L5.config.publisher,
                    n = t.engineScriptUrlParts;
                if ("trecs" === t.systemFlags.loaderType) {
                    var r = n.href,
                        o = new Request(r, {
                            cache: "reload",
                            mode: "no-cors"
                        });
                    fetch(o).catch((function(e) {
                        (0, i.H)("failed to run cache busting on this browser on: ".concat(r), e)
                    }))
                }
            }() : (0, i.o7)("Cache Bust not supported"))
        }
        n.Y.once("storeReady", (function() {
            e.L5.onResponseSummaryUpdateOnce(Le)
        }));
        var Oe = __webpack_require__(6379),
            Me = __webpack_require__(3265),
            Ne = __webpack_require__(3150);

        function Pe(t) {
            var n = t.uiPlacement;
            if (!(e.L5.optionsSummary.placements.filter((function(e) {
                    return e.placementName === n
                })).length > 0)) {
                var i = document.querySelector(t.container);
                if (i) {
                    var o = (0, r.td)(t.shouldCreateContainer, !1),
                        a = "vpl_".concat(1e5 * Math.random() | 0);
                    if (o) {
                        var u = (0, Me.U)("div");
                        u.id = a, i.insertAdjacentElement(function(e) {
                            switch (e) {
                                case "after":
                                    return "afterend";
                                case "before":
                                    return "beforebegin";
                                case "last":
                                    return "beforeend";
                                case "first":
                                    return "afterbegin"
                            }
                            return "afterend"
                        }(t.location), u)
                    } else i.id ? a = i.id : i.id = a;
                    return {
                        placementName: n,
                        rboxResponsesIndex: 0,
                        instances: [(0, v.pi)((0, v.pi)({}, (0, Ne.yt)(a)), {
                            status: 1
                        })],
                        modeName: "virtual_placement",
                        targetType: "mix",
                        byPublisher: !1
                    }
                }
            }
        }

        function De(t) {
            var n = (0, L.qn)();
            n.placements = t, e.Un.appendOptionsSummary(n)
        }
        n.Y.on("vp_l", (function(e) {
            if (!(0, Oe.z)(e.list)) {
                var t = e.list,
                    n = [];
                (0, Oe.mt)(t, (function(e, t) {
                    var r = Pe(t);
                    r && n.push(r)
                })), n.length > 0 && De(n)
            }
        })), n.Y.on("vp_cs", (function e(t) {
            var n = t.data,
                o = t.placementName;
            if ((0, g.cb)(n))(0, i.yN)("virtual placement is not an object: ".concat((0, r.lY)(n)));
            else if ((0, g.h0)(n)) n.forEach((function(t) {
                return e({
                    data: t,
                    placementName: o
                })
            }));
            else {
                var a = Pe((0, v.pi)({
                    uiPlacement: o
                }, n));
                a && De([a])
            }
        }));
        var Ae = __webpack_require__(3239),
            Ue = __webpack_require__(1869);

        function Fe() {
            var t, n = e.L5.responseSummary.noContentReason;
            n && (t = n, (0, Ae.F)("nocontent", {
                reason: t,
                isFeedCard: e.L5.responseSummary.hasFeeds
            }), (0, Ue.m)("EmptyResponse"), (0, i.yN)("response is missing recommendation on all placements: ".concat((0, r.lY)(n))))
        }
        n.Y.once("storeReady", (function() {
            e.L5.onResponseSummaryUpdateOnce(Fe)
        }));
        var qe = __webpack_require__(3595),
            Ve = __webpack_require__(7341);

        function Be() {
            e.L5.optionsSummary.socials.forEach((function(e) {
                var t = (0, Ve.Q1)(e);
                t && (0, qe.xh)(t)
            }))
        }

        function je(e) {
            var t = (0, oe.me)("//".concat(e)),
                n = (0, Me.U)("link");
            n.rel = "preconnect", n.href = t, document.head.appendChild(n)
        }
        n.Y.once("storeReady", (function() {
            e.L5.onResponseSummaryUpdateOnce(Be)
        })), __webpack_require__(2630);
        var He = __webpack_require__(7863);

        function ze(e) {
            return /^https?:\/\/(?:\w+\.)?taboola(syndication)?\.com/.test(e)
        }
        var We, Ge = navigator.userAgent,
            Ye = 0;

        function Qe() {
            return We || (We = (0, I.c)("bot") ? "bot" : Ke() || /Mac OS X 10_\d+.+Gecko\)$/.test(Ge) || /Mac+.+Version+.+Safari/.test(Ge) ? "safari" : (0, I.c)("ff") ? "ff" : (0, I.c)("opera-mini") ? "opera-mini" : (0, I.c)("opera") ? "opera" : (0, I.c)("edge") ? "edge" : (0, I.c)("ie") ? "ie" : (0, I.c)("chrome") ? "chrome" : "Unknown")
        }

        function Ke() {
            return /(?:iPhone|iPad|iPod)/.test(Ge)
        }

        function Je() {
            switch (Qe()) {
                case "safari":
                    return Ke() ? $e(/\s(?:Version|OS)(?:\/|\s)(\d{1,3})/) : function() {
                        var e;
                        return /Mac+.+Version+.+Safari/.test(Ge) ? $e(/\s(?:Version)(?:\/|\s)(\d{1,3})/) : "15" === (null === (e = Ge.match(/(?:Mac OS X 10_)(\d{2})/)) || void 0 === e ? void 0 : e[1]) ? 14 : 10
                    }();
                case "chrome":
                    return $e(/(?:\sChrome)(?:\/)(\d{1,3})/);
                case "ff":
                    return $e(/(?:\sFirefox)(?:\/)(\d{1,3})/);
                case "edge":
                    return $e(/\s(?:Edge|EdgA|Edg)(?:\/)(\d{1,3})/);
                case "opera":
                    return $e(/\s(?:^Opera.+?Version|OPR)(?:\/)(\d{1,3})/)
            }
            return Ye
        }

        function $e(e) {
            var t, n = null === (t = Ge.match(e)) || void 0 === t ? void 0 : t[1];
            return n ? parseInt(n) : Ye
        }

        function Xe(e) {
            return e >= 85 ? "ES2021" : e >= 80 ? "ES2020" : e >= 73 ? "ES2019" : e >= 63 ? "ES2018" : e >= 57 ? "ES2017" : e >= 52 ? "ES2016" : e >= 51 ? "ES2015" : "ES5"
        }
        var Ze = __webpack_require__(6736);

        function et() {
            (0, t.Mv)("enable-browser-data") && (0, b.s)((function() {
                (0, Ze.$q)("brsd", function() {
                    var e;
                    return (e = {}).esv = function() {
                        var e, t, n, r, i = Qe(),
                            o = Je(),
                            a = o === Ye;
                        switch (i) {
                            case "safari":
                                return a && Ge.indexOf(" Chrome") > -1 ? (We = "chrome", Xe(Je())) : (r = o) >= 15 ? "ES2021" : r >= 14 ? "ES2020" : r >= 13 ? "ES2019" : r >= 12 ? "ES2018" : r >= 11 ? "ES2017" : r >= 10 ? "ES2015" : "ES5";
                            case "chrome":
                                return Xe(o);
                            case "ff":
                                return (n = o) >= 79 ? "ES2021" : n >= 64 ? "ES2019" : n >= 52 ? "ES2017" : "ES5";
                            case "edge":
                                return (t = o) >= 85 ? "ES2021" : t >= 80 ? "ES2020" : t >= 79 ? "ES2019" : t >= 15 ? "ES2017" : t >= 14 ? "ES2016" : "ES5";
                            case "opera":
                                return (e = o) >= 71 ? "ES2021" : e >= 67 ? "ES2020" : e >= 60 ? "ES2019" : e >= 51 ? "ES2018" : e >= 44 ? "ES2017" : e >= 39 ? "ES2016" : e >= 38 ? "ES2015" : "ES5"
                        }
                        return "ES5"
                    }(), e.c = (0, I.c)("cookies"), e.ss = (0, I.c)("session-storage"), e.ls = (0, I.c)("local-storage"), e
                }())
            }))
        }
        n.Y.once("storeReady", (function() {
            e.L5.onResponseSummaryUpdateOnce(et)
        }));
        var tt = __webpack_require__(7969),
            nt = __webpack_require__(5346),
            rt = __webpack_require__(5705);

        function it(n, r) {
            var i, o;
            if (void 0 === n && (n = {}), void 0 === r && (r = !1), r || (0, rt.MQ)()) {
                var a = e.L5.config.publisher,
                    u = (0, oe.me)("//beacon.taboola.com/?".concat((0, nt.G6)((0, v.pi)((0, v.pi)(((i = {}).ab = a.systemFlags.loaderType, i.pub = a.publisherName, i.ui = (null === (o = e.L5.userData) || void 0 === o ? void 0 : o.userId) || void 0, i), (0, tt.Qw)()), n))));
                (0, t.Mv)("send-event-as-post") ? (0, qe.lY)({
                    url: u
                }, "text/plain") : (0, rt.hz)(u)
            }
        }
        var ot = null,
            at = -1;
        n.Y.once("storeReady", (function() {
            var n, r;
            (0, rt.MQ)() && ((null === (n = window.performance) || void 0 === n ? void 0 : n.setResourceTimingBufferSize) && window.performance.setResourceTimingBufferSize(window.performance.getEntries().length + 500), function() {
                var e;
                null === (e = document.body) || void 0 === e || e.addEventListener("click", (function(e) {
                    var n = function(e) {
                        for (var t, n = e; n && "A" !== n.tagName;) n = n.parentElement;
                        return n && (null === (t = n.href) || void 0 === t ? void 0 : t.indexOf("log/3/click")) > -1 ? n : null
                    }(e.target);
                    n && (function(e, n) {
                        var r;
                        void 0 === n && (n = {}), null === ot && (ot = (0, rt.MQ)() && (0, t.Mv)("br-event")), ot && it((0, v.pi)(((r = {}).eventType = "click", r), n))
                    }(), (0, He.Wt)("click", n.href))
                }), {
                    capture: !0
                })
            }(), pt(), yt(), e.L5.onResponseSummaryUpdate(ft), e.L5.onOptionsSummaryUpdated(gt), document.addEventListener("visibilitychange", ht), window.scrollY > 0 ? bt() : document.addEventListener("scroll", bt, {
                passive: !0,
                capture: !0
            }), (r = e.L5.config.publisher.systemFlags.experimentID) && (0, He.uP)("experimentId", r))
        }));
        var ut, ct, st = 2e3,
            lt = 30,
            dt = 0;

        function pt() {
            window.setTimeout((function() {
                dt !== lt && (dt += 1, function() {
                    if (!window.performance || !window.performance.getEntries) return !1;
                    var e = window.performance.getEntriesByType("resource").filter((function(e) {
                        return e.name.indexOf(".taboola.com") > -1
                    }));
                    if (!e || 0 === e.length) return !1;

                    function n(t) {
                        return e.filter((function(e) {
                            return e.name.indexOf(t) > -1
                        })).map((function(e) {
                            return {
                                url: e.name,
                                startTime: e.startTime,
                                duration: e.responseEnd - e.startTime
                            }
                        }))[0] || void 0
                    }
                    return ut || (ut = n("trc/3/json")), ct || (ct = n((0, t.Cd)("image-url-domain"))), !!ut || !!ct
                }() ? (ut && (0, He.Wt)("firstTrcCall", ut), ct && (0, He.Wt)("firstImage", ct), ut && ct || pt()) : pt())
            }), st)
        }

        function ft() {
            var t = {
                ec: 0,
                sc: 0,
                nav: 0,
                oc: 0,
                rtb: 0,
                net: 0
            };

            function n(e) {
                e.items.forEach((function(e) {
                    e.isRTB ? t.rtb += 1 : e.isSponsored && !e.isEditorial ? t.sc += 1 : e.isNative ? t.nav += 1 : e.isOrganic ? t.oc += 1 : e.isNetwork ? t.net += 1 : t.ec += 1
                }))
            }
            var r = e.L5.responseSummary;
            if (r.hasWidgets) {
                var i = r.widgets;
                (0, Oe.mt)(i, (function(e, t) {
                    n(t)
                }))
            }
            if (r.hasFeeds) {
                var o = r.feeds;
                (0, Oe.mt)(o, (function(e, t) {
                    t.batchList.forEach((function(e) {
                        e.placements.forEach(n)
                    }))
                }))
            }(0, He.uP)("totalItems", t)
        }
        var mt = (0, rt.dl)(),
            vt = 0;

        function ht() {
            var e = "visible" === document.visibilityState,
                t = (0, rt.dl)();
            e || (vt += t - mt, (0, He.uP)("timeOnPage", vt)), mt = t
        }

        function gt() {
            (0, He.uP)("optionsSummary", e.L5.optionsSummary)
        }

        function bt() {
            0 !== window.scrollY && (document.removeEventListener("scroll", bt, {
                capture: !0
            }), (0, He.Wt)("userScroll"))
        }
        var _t = {
            domContentLoaded: at,
            domInteractive: at,
            domComplete: at,
            loadEvent: at
        };

        function yt() {
            window.setTimeout((function() {
                var e = window.performance.getEntriesByType("navigation");
                if (0 !== e.length) {
                    var t = e[0];
                    t.domContentLoadedEventEnd > 0 && _t.domContentLoaded === at && (_t.domContentLoaded = 0 | t.domContentLoadedEventEnd), t.domComplete > 0 && _t.domComplete === at && (_t.domComplete = 0 | t.domComplete), t.domInteractive > 0 && _t.domInteractive === at && (_t.domInteractive = 0 | t.domInteractive), t.loadEventEnd > 0 && _t.loadEvent === at && (_t.loadEvent = 0 | t.loadEventEnd), 0 === Object.keys(_t).filter((function(e) {
                        return _t[e] === at
                    })).length ? (0, He.uP)("pageLoadTiming", _t) : yt()
                }
            }), st)
        }

        function wt() {
            (0, k.Xq)({
                measuredType: "heavyAdIntervention",
                modeName: "heavyAdIntervention"
            })(), ke("eventBus").emit("perfImmediate")
        }

        function xt() {
            var t = Et(e.L5.userData.stp),
                n = Et(e.L5.userData.jst),
                o = !1;
            t.length > 0 && ((0, r.m9)((function() {
                var e;
                e = "", t.forEach((function(t) {
                        e += '<img width="0" height="0" src="'.concat(t, '" alt="">')
                    })),
                    function(e) {
                        var t, n = document.createElement("iframe"),
                            r = "trc-pixel-iframe-".concat(1e4 * Math.random() | 0);
                        n.id = r, n.name = r, n.width = "0px", n.height = "0px", n.style.display = "none", n.classList.add("trc-hidden"), document.body.appendChild(n);
                        try {
                            var o = n.contentDocument || (null === (t = n.contentWindow) || void 0 === t ? void 0 : t.document);
                            (0, h.LO)(o, "frameDocument is undefined"), o.body.innerHTML = e, o.close()
                        } catch (e) {
                            return (0, i.H)("Failed to report tracking by iFrame"), !1
                        }
                        return !0
                    }(e) || function(e) {
                        document.createElement("span").innerHTML = e
                    }(e)
            })), o = !0), n.length > 0 && (n.forEach((function(e) {
                (0, R._W)(e, {
                    async: !0
                })
            })), o = !0), o && e.Un.signTrackingReportUsed()
        }

        function Et(e) {
            return e.filter((function(e) {
                return !e.used
            })).map((function(e) {
                return e.url
            }))
        }
        n.Y.once("storeReady", (function() {
            (0, Ie.Q)(window.ReportingObserver) && new(0, window.ReportingObserver)(wt, {
                types: ["intervention"],
                buffered: !1
            }).observe()
        })), n.Y.once("storeReady", (function() {
            e.L5.onResponseSummaryUpdate(xt)
        }));
        var Tt = __webpack_require__(862),
            Ct = __webpack_require__(7329);

        function St() {
            var n;
            (0, i.Hi)(a.mb), void 0 === n && (n = window), n.addEventListener("error", (function(e) {
                var t;
                try {
                    if (ze(e.filename)) {
                        var n = "".concat(e.lineno).concat(e.colno ? ":".concat(e.colno) : "", "@").concat(e.filename);
                        (0, He.Rt)("Message: ".concat(e.message, ", Location: ").concat(n, ", Callstack: ").concat((null === (t = e.error) || void 0 === t ? void 0 : t.stack) || "")), (0, i.H)("unhandledError::".concat(n, "::"), e.error)
                    }
                } catch (e) {}
            }), !0), n.addEventListener("unhandledrejection", (function(e) {
                var t = e.reason;
                t && ze((0, r.lY)(t.stack)) && t.message && (0, i.PN)("Promise reject: ", t)
            })), (0, k.Xq)({
                measuredType: "coreLoaded"
            }), (0, e._b)().then((function() {
                return (0, b.s)((function() {
                    (0, t.Mv)("enable-resource-hints") && (0, t.Cd)("preconnect-domains").forEach(je), (0, m.cV)().forEach((function(e) {
                        e.extension && (le(e.extension), e.extension = void 0)
                    }))
                }))
            })).then((function() {
                var e = (0, ue.Tt)("e1"),
                    t = (null == e ? void 0 : e.map(le)) || [_.e.resolve()];
                return (0, ue.Tt)("e3"), (0, ue.Tt)("e5"), (0, ue.Tt)("e4"), _.e.all(t)
            })).then((function() {
                var e;
                return null === (e = (0, ue.Tt)("e2")) || void 0 === e || e.map(le), (0, b.s)(Ee)
            })).then((function(e) {
                var t = (0, ae.N)();
                return Re(t), (0, ue.Tt)("e6", t), e
            })).catch((function(e) {
                (0, i.H)("TRECS error in startEngine(): ", e)
            }))
        }
        a.mb.__startEngine = function(e, t) {
            a.mb.__startEngine = (0, y.F)(), a.mb.__tblTrecsInit || (a.mb.__tblTrecsInit = !0, n.Y.emit(Ce), (0, Ct.w)(t), (0, f.H)(e), St())
        };
        var Rt, kt, It, Lt = __webpack_require__(8924),
            Ot = __webpack_require__(2414);
        ! function(e) {
            e.USER_CALLBACK = "user-callback", e.EVENT_LISTENER = "event-listener", e.RESOLVE_PROMISE = "resolve-promise", e["REJECT-PROMISE"] = "reject-promise", e["CLASSIC-SCRIPT"] = "classic-script", e["MODULE-SCRIPT"] = "module-script"
        }(Rt || (Rt = {})),
        function(e) {
            e.LONG_TASK = "longtask", e.LONG_ANIMATION_FRAME = "long-animation-frame"
        }(kt || (kt = {})),
        function(e) {
            e.SELF = "self", e.DESCENDANT = "descendant", e.ANCESTOR = "ancestor", e["SAME-PAGE"] = "same-page", e.OTHER = "other"
        }(It || (It = {}));
        var Mt = __webpack_require__(2939),
            Nt = 0,
            Pt = 0,
            Dt = 0,
            At = 0,
            Ut = Number.NEGATIVE_INFINITY,
            Ft = Number.NEGATIVE_INFINITY,
            qt = [],
            Vt = 0,
            Bt = "taboola.com",
            jt = {
                count: 0,
                countwithinteraction: 0,
                duration: 0,
                majorcountwithinteraction: 0,
                majorcount: 0,
                durationwithinteraction: 0,
                majorduration: 0,
                majordurationwithinteraction: 0
            },
            Ht = {
                taboola: {
                    domains: {},
                    total: (0, v.pi)({}, jt)
                },
                withtaboola: {
                    total: (0, v.pi)({}, jt)
                },
                global: (0, v.pi)((0, v.pi)({}, jt), {
                    inpBlockingDuration: 0,
                    taboolaInpBlockingDuration: 0
                })
            },
            zt = {},
            Wt = 50,
            Gt = !1,
            Yt = "total";

        function Qt(e) {
            var t;
            if (e === kt.LONG_ANIMATION_FRAME) return !!window.PerformanceLongAnimationFrameTiming;
            var n = null === (t = window.PerformanceObserver) || void 0 === t ? void 0 : t.supportedEntryTypes;
            return n && -1 !== n.indexOf(e)
        }

        function Kt() {
            return !!(0, Ot.KB)(Lt.H.LOAF_REPORTING) && Qt(kt.LONG_ANIMATION_FRAME)
        }

        function Jt(e, t) {
            if (window.PerformanceObserver && Qt(t)) try {
                ! function(e, t) {
                    var n = new window.PerformanceObserver((function(t) {
                        t.getEntries().forEach(e)
                    }));
                    n.observe(t), qt.push(n)
                }(e, {
                    type: t,
                    buffered: !0
                })
            } catch (e) {
                (0, ke("log").warn)("Buffered performance observation is not supported. ", t, e)
            }
        }

        function $t() {
            return (0, t.Cd)("loaf-culprits-regex")
        }

        function Xt(e) {
            var n = $t();
            n && function(e, t) {
                e.scripts.forEach((function(e) {
                    var n = e.sourceLocation;
                    if (n && new RegExp(t).test(n)) {
                        var r = n.match(/(\w+@)?(http.:\/\/)?(\w+\.\w+\.\w+)\/(.+)/);
                        if (r) {
                            var i = r[4],
                                o = r[3],
                                a = r[2],
                                u = r[1];
                            i || (i = n);
                            var c = e.name;
                            c && (c = c.replace(a + o, ""));
                            var s = zt[i];
                            s ? (s.count++, s.totalDuration += e.duration) : s = zt[i] = {
                                count: 1,
                                funcName: u,
                                name: c,
                                totalDuration: e.duration
                            }
                        }
                    }
                }))
            }(e, n), (0, Ot.KB)(Lt.H.LOAF_REPORTING) && function(e) {
                if (0 !== e.blockingDuration) {
                    var n = "no_scripts",
                        r = {},
                        i = e.firstUIEventTimestamp > 0,
                        o = {},
                        a = {},
                        u = !1;
                    if (e.scripts.forEach((function(i, c) {
                            var s = function(e, n, r) {
                                var i = (0, t.Cd)("loaf-threshold"),
                                    o = Math.max(e.duration - i, 0),
                                    a = e.sourceLocation;
                                if (!a) return "no_sourcelocation";
                                var u, c = null == (u = a.match(/http.*?\.js/)) ? void 0 : u[0];
                                if (!c) return "no_sourceurl";
                                var s = new URL(c),
                                    l = s.hostname;
                                if (!l) return "no_hostname";
                                return -1 !== l.indexOf("taboola") ? function() {
                                    var e, t = s.pathname.split("/").pop();
                                    t && (n[l] || (n[l] = ((e = {})[t] = (0, v.pi)({}, jt), e)), Zt({
                                        parentEntity: n[l],
                                        entityId: t,
                                        effectiveBlockingTimeDelta: o,
                                        count: 1
                                    }))
                                }() : Zt({
                                    count: 1,
                                    parentEntity: r,
                                    entityId: l,
                                    effectiveBlockingTimeDelta: o
                                }), l
                            }(i, a, o);
                            r[s] || (r[s] = 0), r[s] += i.duration, (0 === c || r[s] > r[n]) && (n = s),
                                function(e, t, n) {
                                    if (!(!!t.sourceLocation && t.sourceLocation.indexOf(Bt) > -1)) return !1;
                                    var r = t.duration > Wt,
                                        i = e[Bt] > n / 2;
                                    return r || i
                                }(r, i, e.duration) && (u = !0)
                        })), Object.keys(a).length && (Object.keys(o).length && function(e, t) {
                            var n = 0;
                            (0, Oe.mt)(e, (function(r) {
                                n += e[r].duration, e[r] && Zt({
                                    parentEntity: Ht.withtaboola,
                                    entityId: r,
                                    count: e[r].count,
                                    effectiveBlockingTimeDelta: e[r].duration,
                                    hasInteraction: t
                                })
                            })), Zt({
                                parentEntity: Ht.withtaboola,
                                entityId: Yt,
                                count: 1,
                                effectiveBlockingTimeDelta: n,
                                hasInteraction: t
                            })
                        }(o, i), function(e, t, n) {
                            var r = 0;
                            (0, Oe.mt)(e, (function(i) {
                                var o = 0;
                                (0, Oe.mt)(e[i], (function(a) {
                                    var u, c;
                                    r += e[i][a].duration, o += e[i][a].duration, null !== (u = (c = Ht.taboola.domains)[i]) && void 0 !== u || (c[i] = {}), Zt({
                                        parentEntity: Ht.taboola.domains[i],
                                        entityId: a,
                                        count: e[i][a].count,
                                        effectiveBlockingTimeDelta: e[i][a].duration,
                                        hasInteraction: t,
                                        taboolaIsMajor: n
                                    })
                                })), Zt({
                                    parentEntity: Ht.taboola.domains[i],
                                    entityId: Yt,
                                    count: 1,
                                    effectiveBlockingTimeDelta: o,
                                    hasInteraction: t,
                                    taboolaIsMajor: n
                                })
                            })), Zt({
                                parentEntity: Ht.taboola,
                                entityId: Yt,
                                count: 1,
                                effectiveBlockingTimeDelta: r,
                                hasInteraction: t,
                                taboolaIsMajor: n
                            })
                        }(a, i, u)), Zt({
                            parentEntity: Ht,
                            entityId: "global",
                            effectiveBlockingTimeDelta: e.blockingDuration,
                            count: 1,
                            hasInteraction: i,
                            taboolaIsMajor: u
                        }), i) {
                        var c = Ht.global;
                        e.blockingDuration > c.inpBlockingDuration && (c.inpBlockingDuration = e.blockingDuration, c.inpOrigin = n), u && (c.taboolaInpBlockingDuration = Math.max(c.taboolaInpBlockingDuration, e.blockingDuration))
                    }
                }
            }(e)
        }

        function Zt(e) {
            var t, n = e.parentEntity,
                r = e.entityId,
                i = e.effectiveBlockingTimeDelta,
                o = e.count,
                a = null !== (t = n[r]) && void 0 !== t ? t : n[r] = (0, v.pi)({}, jt);
            a.duration += i, a.count += o, e.hasInteraction && (a.countwithinteraction += o, a.durationwithinteraction += i), e.taboolaIsMajor && (a.majorcount += o, a.majorduration += i, e.hasInteraction && (a.majorcountwithinteraction += o, a.majordurationwithinteraction += i))
        }

        function en(e) {
            if (!e.hadRecentInput) {
                var t = e.startTime - Ut > 5e3,
                    n = e.startTime - Ft > 1e3;
                (t || n) && (Ut = e.startTime, Dt = 0), Dt += e.value, At = Math.max(At, Dt), Nt += e.value, Pt = At, Ft = e.startTime, ke("eventBus").emit("onCls", e)
            }
        }

        function tn(e) {
            Vt += e.duration - Wt
        }

        function nn(e) {
            var t = e.startTime,
                n = e.processingStart - t;
            wn({
                name: "".concat("generalMeasure", "_firstInputDelay"),
                entryType: "measure",
                startTime: t,
                duration: n
            })
        }
        n.Y.once("storeReady", (function() {
            (function() {
                for (var e = window.performance, t = e.now(), n = 0; n < 1e6; n++);
                return e.now() - t
            })() > (0, t.Cd)("browser-benchmark") || e.L5.onOptionsSummaryUpdatedOnce((function() {
                ((0, Ot.KB)(Lt.H.TBT_REPORTING) || (0, Mt.iH)()) && Jt(tn, kt.LONG_TASK), ((0, Ot.KB)(Lt.H.LOAF_REPORTING) || $t()) && (function() {
                    var e = (0, t.Cd)("loaf-token");
                    if ((0, g.cb)(e)) {
                        var n = (0, Me.U)("meta");
                        n.httpEquiv = "origin-trial", n.content = e, document.head.appendChild(n)
                    }
                }(), (0, i.yN)("loafSupported:".concat(Qt(kt.LONG_ANIMATION_FRAME))), Kt() && Jt(Xt, kt.LONG_ANIMATION_FRAME))
            }))
        }));
        var rn = !1;

        function on() {
            an() || document.addEventListener("readystatechange", (function() {
                    an() && wn({
                        name: "".concat("generalMeasure", "_documentReady"),
                        entryType: "measure",
                        startTime: (0, Mt.a)(),
                        duration: 0
                    })
                })),
                function() {
                    var t = {
                            hidden: "visibilitychange",
                            webkitHidden: "webkitvisibilitychange",
                            mozHidden: "mozvisibilitychange",
                            msHidden: "msvisibilitychange"
                        },
                        n = 0,
                        o = "",
                        a = "";
                    for (var u in t)
                        if (u in document) {
                            a = t[o = u];
                            break
                        }
                    document.addEventListener(a, (function() {
                        var t, a, u = document[o] ? {
                            measuredType: "inactiveTab",
                            modeName: "inactive",
                            placement: n.toString()
                        } : {
                            measuredType: "activeTab",
                            modeName: "active",
                            placement: n.toString()
                        };
                        (0, k.Xq)(u)(), "inactive" === u.modeName && (a = (0, Mt.a)(), Gt || (Gt = !0, wn({
                            name: "".concat("generalMeasure", "_TBT"),
                            entryType: "measure",
                            startTime: a,
                            duration: Vt
                        }), Kt() && (0, i.yN)("loaf:".concat((0, r.lY)(Ht))), !!$t() && Qt(kt.LONG_ANIMATION_FRAME) && (0, i.yN)("loafCulprits:".concat((0, r.lY)(zt))), (0, Ot.KB)(Lt.H.TBT_REPORTING) && (0, i.yN)("TBT=".concat(Vt).concat((t = [], (0, Oe.mt)(e.L5.responseSummary.testAndExperiment.testVariantsMap, (function(e, n) {
                            t.push("".concat(e, "=").concat(n))
                        })), t.join("&")))), (0, Mt.iH)() && ke("eventBus").emit("perfImmediate"))), n++
                    }))
                }()
        }

        function an() {
            return "complete" === document.readyState
        }
        var un, cn = [],
            sn = 20,
            ln = [],
            dn = 1;

        function pn() {
            var e = (0, Mt.a)();
            setTimeout((function() {
                ln.push((0, Mt.a)() - e)
            }), 0)
        }

        function fn() {
            var e = dn > sn;
            if (!(ln.length < 1 || e)) {
                var t = function() {
                        for (var e = 0, t = 0, n = 0; n < ln.length; n++) e = Math.max(e, ln[n]), t += ln[n];
                        return {
                            maximum: e,
                            average: t / ln.length
                        }
                    }(),
                    n = t.maximum,
                    r = t.average,
                    i = (0, Mt.a)();
                wn({
                    name: "".concat("generalMeasure", "_ELAVG_").concat(dn),
                    entryType: "measure",
                    startTime: i,
                    duration: r
                }), wn({
                    name: "".concat("generalMeasure", "_ELMAX_").concat(dn),
                    entryType: "measure",
                    startTime: i,
                    duration: n
                }), ln = [], dn++
            }
        }
        var mn, vn = [],
            hn = !1,
            gn = !1,
            bn = 30;

        function _n(e) {
            if (void 0 === e && (e = {
                    useFader: !0
                }), !((0, Mt.a)() / 1e3 / 60 > bn)) {
                (0, Mt.nj)();
                var t = function() {
                    (function() {
                        if (!rn) {
                            var e = window.performance.getEntriesByType("navigation");
                            if (0 !== e.length) {
                                var t = e[0];
                                ["domComplete", "domContentLoadedEventEnd", "loadEventEnd", "domInteractive"].forEach((function(e) {
                                    t[e] && wn({
                                        name: "".concat("generalMeasure", "_").concat(e),
                                        entryType: "measure",
                                        startTime: t[e],
                                        duration: 0
                                    })
                                })), rn = !0
                            }
                        }
                    })(),
                    function() {
                        var e = function() {
                            var e = window.navigator;
                            if (null == e ? void 0 : e.connection) return e.connection
                        }();
                        if (!gn && e) {
                            if (e.downlink && wn({
                                    name: "".concat("generalMeasure", "_connectionDownlink"),
                                    entryType: "measure",
                                    startTime: (0, Mt.a)(),
                                    duration: e.downlink
                                }), e.rtt && wn({
                                    name: "".concat("generalMeasure", "_connectionRtt"),
                                    entryType: "measure",
                                    startTime: (0, Mt.a)(),
                                    duration: e.rtt
                                }), e.effectiveType) {
                                var t = function(e) {
                                    switch (e) {
                                        case "slow-2g":
                                            return 1;
                                        case "2g":
                                        case "3g":
                                        case "4g":
                                            return parseInt(e);
                                        default:
                                            return -1
                                    }
                                }(e.effectiveType);
                                wn({
                                    name: "".concat("generalMeasure", "_connectionEffectiveType"),
                                    entryType: "measure",
                                    startTime: (0, Mt.a)(),
                                    duration: t
                                })
                            }
                            gn = !0
                        }
                    }(),
                    function() {
                        if (0 !== Nt) {
                            var e = (0, Mt.a)();
                            wn({
                                name: "".concat("generalMeasure", "_clsAggAdjusted"),
                                entryType: "measure",
                                startTime: e,
                                duration: 100 * Nt
                            }), wn({
                                name: "".concat("generalMeasure", "_clsMaxAggAdjusted"),
                                entryType: "measure",
                                startTime: e,
                                duration: 100 * Pt
                            })
                        }
                    }();
                    var e = null == un ? void 0 : un.getAllEntries();
                    if ((0, Oe.mt)(e, yn), vn.length) {
                        var t = (0, Mt.tE)();
                        return {
                            measurements: vn,
                            dict: t
                        }
                    }
                }();
                t && (null == un || un.sendReport(t, e), (0, k.z2)(), vn = [])
            }
        }

        function yn(e, t) {
            var n, r = t.startMark;
            if (n = window.performance.measure(r, t.startMark, t.endMark || Mt.lS), hn && (n = window.performance.getEntriesByName(r)[0]), n) {
                var i = t.markerHash ? "_".concat(t.markerHash) : "";
                wn({
                    name: "".concat(t.measureLevel, "_").concat(t.measuredType).concat(i),
                    entryType: "measure",
                    startTime: n.startTime,
                    duration: n.duration
                })
            }
        }

        function wn(e) {
            vn.push(e)
        }
        Se(new(function() {
            function e() {}
            return e.prototype.getName = function() {
                return "PerfUtils"
            }, e.prototype.unregistered = function() {
                clearInterval(mn),
                    function() {
                        for (var e; e = cn.shift();) clearInterval(e)
                    }(),
                    function() {
                        var e;
                        for (Nt = 0, Pt = 0, Vt = 0; e = qt.shift();) e.disconnect()
                    }(), rn = !1, hn = !1, gn = !1, (0, Mt.Aj)()
            }, e.prototype.e6 = function(e) {
                Re(e),
                    function() {
                        if (un = ke("PERFORMANCE"), ((0, Ot.KB)(Lt.H.LOAF_REPORTING) || (0, Ot.KB)(Lt.H.TBT_REPORTING) || un.isEnabled()) && on(), un.isEnabled()) {
                            var e = (0, Mt.Eb)();
                            e && ((0, Mt.BJ)(Mt.lS), window.performance.measure(Mt.lS) || (hn = !0), (0, Mt.nj)(), window.PerformanceObserver && (Jt(nn, "first-input"), Jt(en, "layout-shift")), function() {
                                var e = ke("TABOOLA_STORE").getGlobalItem,
                                    t = e("rbox-perf-el-interval"),
                                    n = window.setInterval(pn, t);
                                cn.push(n);
                                var r = e("rbox-perf-el-report-interval"),
                                    i = window.setInterval(fn, r);
                                cn.push(i)
                            }(), window.setTimeout((function() {
                                if (_n(), e.measureInterval) {
                                    var t = Math.max(Number(e.measureInterval), 1e4);
                                    mn = window.setInterval(_n, t)
                                }
                            }), e.measureTimeToSend || 1e4), window.addEventListener("beforeunload", (function() {
                                _n()
                            })), n.Y.on("perfImmediate", (function() {
                                _n({
                                    useFader: !1
                                })
                            })))
                        }
                    }()
            }, e
        }()));
        var xn, En = __webpack_require__(4400),
            Tn = __webpack_require__(9437);

        function Cn() {
            return e = xn.fields, t = {}, (0, Oe.mt)(e, (function(n) {
                var r = Sn(e[n]);
                r && (t[n] = r)
            })), t;
            var e, t
        }

        function Sn(e) {
            var t, n, r = null,
                o = e.t,
                a = e.n;
            if ("json" === o && a ? r = function(e) {
                    for (var t = document.querySelectorAll('script[type="application/ld+json"]'), n = 0; n < t.length; n++) {
                        var r = t[n],
                            o = void 0;
                        try {
                            o = JSON.parse(r.innerText)
                        } catch (e) {
                            return (0, i.H)("Failed to parse json ld script: ".concat(e)), null
                        }
                        for (var a = Array.isArray(o) ? o : [o], u = 0; u < a.length; u++) {
                            var c = a[u];
                            if (c[e]) return c[e]
                        }
                    }
                    return null
                }(a) : "tag" === o && a && (t = a, r = (n = document.querySelector('head meta[property="'.concat(t, '"]'))) || (n = document.querySelector('head meta[name="'.concat(t, '"]'))) ? n.content : null), r) return r;
            var u = e.f;
            return u && (r = Sn(u)), r
        }
        Se(new(function() {
            function t() {}
            return t.prototype.getName = function() {
                return "Auto-ReCrawl"
            }, t.prototype.e6 = function() {
                var t, n;
                t = e.L5.config, n = "oc-recrawl-settings-".concat(t.publisher.publisherName), xn = t.publisher.global[n]
            }, t.prototype.e9 = function(t) {
                if ((null == t ? void 0 : t.data) && xn && xn.fields && xn.sampleRate && function() {
                        switch (me.V[(0, En.G)(e.L5.optionsSummary.itemSourceType)]) {
                            case me.V.homepage:
                            case me.V.home:
                            case me.V.category:
                                return !1;
                            default:
                                return !0
                        }
                    }() && ((0, Tn.EK)("force_auto_recrawl") || Math.random() <= xn.sampleRate)) {
                    var n = Cn();
                    if (n) return t.data.ar = n, {
                        payload: t
                    }
                }
            }, t
        }()));
        var Rn, kn, In, Ln = {
                name: "normalize-item-id",
                reset: function(e) {
                    return e
                },
                handler: function(t, n, r) {
                    var o = e.L5.optionsSummary.itemSourceType,
                        a = "location" === e.L5.config.runtime.urlSelectionStrategy;
                    try {
                        return n.call(t, r, o, !a)
                    } catch (e) {
                        return (0, i.H)("error on normalizeItemId hook", e), r
                    }
                }
            },
            On = {
                name: "normalize-item-url",
                reset: function(e) {
                    return e
                },
                handler: function(t, n, r) {
                    var o = e.L5.optionsSummary.itemSourceType,
                        a = "location" === e.L5.config.runtime.urlSelectionStrategy;
                    try {
                        return n.call(t, r, o, !a)
                    } catch (e) {
                        return (0, i.H)("error on normalizeItemUrl hook", e), r
                    }
                }
            },
            Mn = {
                name: "normalize-request-param",
                reset: function(e) {
                    return e
                },
                handler: function(t, n, r) {
                    var o = r;
                    try {
                        o = n.call(t, r)
                    } catch (e) {
                        (0, i.H)("error on normalizeRequestParam (publisher level) hook", e)
                    }
                    return o.r = o.r.map((function(t) {
                        try {
                            var r = e.L5.optionsSummary.placements.filter((function(e) {
                                return e.placementName === t.uip
                            }))[0];
                            return n(t, r.modeName)
                        } catch (e) {
                            return (0, i.H)("error on normalizeRequestParam (placements level) hook", e), t
                        }
                    })), o
                }
            },
            Nn = function() {},
            Pn = {
                name: "mode-pub-start",
                handler: function(e, t, n, r) {
                    try {
                        return t.call(e, n, r)
                    } catch (e) {
                        (0, i.H)("error on mode pub start hook", e)
                    }
                }
            },
            Dn = {
                name: "item-data-filter",
                reset: Nn,
                handler: function(e, t, n) {
                    try {
                        t.call(e, n)
                    } catch (e) {
                        (0, i.H)("error on itemDataFilter hook", e)
                    }
                },
                isModeLevel: !0
            },
            An = {
                name: "item-renderer",
                handler: function(e, t, n, r) {
                    try {
                        t.call(e, n, r)
                    } catch (e) {
                        (0, i.H)("error on itemRenderer hook", e)
                    }
                },
                isModeLevel: !0
            },
            Un = {
                name: "list-suffix",
                handler: function(e, t, n, r) {
                    try {
                        t.call(e, n, r)
                    } catch (e) {
                        (0, i.H)("error on listSuffix hook", e)
                    }
                },
                isModeLevel: !0
            },
            Fn = ((Rn = {})["publisher-start"] = {
                name: "publisher-start",
                reset: Nn,
                handler: function(e, t) {
                    try {
                        return t.call(e)
                    } catch (e) {
                        (0, i.H)("error on publisher start hook", e)
                    }
                }
            }, Rn["normalize-request-param"] = Mn, Rn["normalize-item-id"] = Ln, Rn["normalize-item-url"] = On, Rn["mode-pub-start"] = Pn, Rn["item-data-filter"] = Dn, Rn["item-renderer"] = An, Rn["list-suffix"] = Un, Rn);
        ! function(e) {
            e.PUBLISHER_ID = "publisherId"
        }(In || (In = {}));
        var qn, Vn, Bn, jn = ((kn = {})[In.PUBLISHER_ID] = {
            getValue: function() {
                return e.L5.config.publisher.publisherName
            },
            setValue: function(t) {
                e.Un.updatePublisherConfig({
                    publisherName: t
                })
            }
        }, kn);

        function Hn() {
            a.mb.TRC = qn
        }
        var zn, Wn = (0, Ie.Q)(window.Proxy),
            Gn = [];

        function Yn(t) {
            return Gn = [], zn = a.mb.TRCImpl || {
                isProxy: !0
            }, Bn = Bn || e.L5.config.publisher.publisherName, Wn && zn !== {} ? (Vn = zn, a.mb.TRCImpl = new Proxy(Vn, function(e) {
                return {
                    get: function(t, n) {
                        var r, o, a;
                        "hasOwnProperty" !== n && Qn(e, n);
                        var u = null !== (a = null !== (r = t[n]) && void 0 !== r ? r : null === (o = t.TRECS) || void 0 === o ? void 0 : o[n]) && void 0 !== a ? a : void 0;
                        return (0, g.r8)(u) && (0, i.PN)('property "'.concat(n, '" is undefined, inside hook: ').concat(e)), u
                    },
                    set: function(e, t, n) {
                        return e[t] = n, e.TRECS[t] = n, !0
                    }
                }
            }(t)), {
                TRCImplProxy: a.mb.TRCImpl,
                endTRCImplProxy: Kn
            }) : {
                TRCImplProxy: zn,
                endTRCImplProxy: function() {}
            }
        }
        var Qn = function(e, t) {
            var n = "publisher: ".concat(Bn, ' used get property "').concat(t, '", inside hook: ').concat(e);
            Gn.push(n)
        };

        function Kn() {
            return zn.hasOwnProperty("isProxy") || (a.mb.TRCImpl = Vn), Gn
        }
        var Jn = {},
            $n = {};

        function Xn(e, t, n) {
            for (var r, i = [], o = 3; o < arguments.length; o++) i[o - 3] = arguments[o];
            var a = null === (r = $n[e]) || void 0 === r ? void 0 : r[t];
            return a ? er.apply(void 0, (0, v.ev)([e, a, n], i, !1)) : n
        }

        function Zn(e, t) {
            for (var n = [], r = 2; r < arguments.length; r++) n[r - 2] = arguments[r];
            var i = Jn[e];
            return i ? er.apply(void 0, (0, v.ev)([e, i, t], n, !1)) : t
        }

        function er(e, n, r) {
            for (var i, o = [], u = 3; u < arguments.length; u++) o[u - 3] = arguments[u];
            var c = Yn(e),
                s = c.TRCImplProxy,
                l = c.endTRCImplProxy,
                d = function() {
                    if (!(0, Ie.Q)(window.Proxy)) return function() {};
                    qn = a.mb.TRC;
                    return a.mb.TRC = new Proxy(qn, {
                        get: function(e, t) {
                            var n, r, i;
                            return null !== (i = null !== (n = e[t]) && void 0 !== n ? n : null === (r = e.TRECS) || void 0 === r ? void 0 : r[t]) && void 0 !== i ? i : void 0
                        },
                        set: function(e, t, n) {
                            return e[t] = n, e.TRECS[t] = n, !0
                        }
                    }), Hn
                }(),
                p = (i = Fn[e]).handler.apply(i, (0, v.ev)([s, n, r], o, !1)),
                f = l(),
                m = (0, t.Mv)("enable-report-trc-use", !1);
            return (null == f ? void 0 : f.length) && m && it(f), d(), p
        }

        function tr(t) {
            var n = t.placement || t.widget;
            return n ? (0, v.pi)((0, v.pi)({}, n), {
                boxes: n.items.map((function(t) {
                    return (0, h.LO)(e.L5.getEntityCustomData(t), "Entity custom data is not defined"), e.L5.getEntityCustomData(t).element
                })),
                recommendationList: n.items,
                mode_name: n.m,
                outerBox: t.placementOuterBox
            }) : n
        }
        var nr = function() {
            function t() {}
            return t.prototype.getName = function() {
                return "HooksManager"
            }, t.prototype.unregistered = function() {}, t.prototype.e5 = function() {
                (0, Oe.mt)(jn, (function(e) {
                    Object.defineProperty(a.mb.TRC.TRECS, e, {
                        get: function() {
                            return jn[e].getValue()
                        },
                        set: function(t) {
                            jn[e].setValue(t)
                        },
                        enumerable: !0,
                        configurable: !0
                    })
                }))
            }, t.prototype.e4 = function() {
                (0, Oe.mt)(Fn, (function(t) {
                    var n = Fn[t],
                        r = e.L5.config.publisher[n.name];
                    n.isModeLevel ? function(t) {
                        var n = t.name,
                            r = t.reset;
                        $n[n] = {}, (0, Oe.mt)(e.L5.config.publisher.modes, (function(t) {
                            var i = e.L5.config.publisher.modes[t][n];
                            r && e.Un.resetConfigValueOnModeLevel(n, r, t), (0, g.hR)(i) && ($n[n][t] = i)
                        }))
                    }(n) : (n.reset && e.Un.resetConfigValue(n.name, n.reset), (0, g.hR)(r) && (Jn[n.name] = r))
                }))
            }, t.prototype.e6 = function() {
                Zn("publisher-start")
            }, t.prototype.e9 = function(e) {
                var t = e;
                if (t && t.data) return t.data = Zn("normalize-request-param", t.data), t.data.ii = Zn("normalize-item-id", t.data.ii), t.data.u = Zn("normalize-item-url", t.data.u), {
                    payload: t
                }
            }, t.prototype.e17 = function(e) {
                var t = e.placement,
                    n = e.widget,
                    r = e.container;
                (t || n) && Zn("mode-pub-start", tr(e), r)
            }, t.prototype.e10 = function(t) {
                var n;
                return null === (n = t.vl) || void 0 === n || n.forEach((function(t) {
                    var n, r = function(t) {
                        var n = t.m;
                        if (!n) {
                            var r = e.L5.optionsSummary.placements.filter((function(e) {
                                return e.placementName === t.uip
                            }))[0];
                            n = null == r ? void 0 : r.modeName
                        }
                        return n
                    }(t);
                    null === (n = t.v) || void 0 === n || n.forEach((function(e) {
                        Xn("item-data-filter", r, e)
                    }))
                })), t
            }, t.prototype.e18 = function(e) {
                var t = e.itemData,
                    n = e.container,
                    r = e.placementMainWrapper;
                if (t) {
                    var i = t.placement,
                        o = t.originalCard;
                    Xn("item-renderer", i.m, n, o)
                } else if (e.placement) {
                    var a = tr(e);
                    a && Xn("list-suffix", a.m, r, a)
                }
            }, t
        }();
        Se(new nr);
        var rr, ir, or, ar, ur, cr, sr, lr = __webpack_require__(734),
            dr = function() {
                function e(e) {
                    var t = this;
                    this[rr] = {}, this[ir] = 1, this[or] = !1, this[ar] = {}, this[ur] = function(e) {
                        var n = e.data;
                        if (null == n ? void 0 : n.tbp) {
                            var r = e.source;
                            switch (n.type) {
                                case "search":
                                    t.m3(n, r);
                                    break;
                                case "identify":
                                    t.m4(n, r);
                                    break;
                                case "runCom":
                                    t.m5(n, r)
                            }
                        }
                    }, this.d8 = e, this.m1(), this.d1 = window.location.origin, window.addEventListener("message", this.m2), this.m6("search")
                }
                return e.prototype.onSplitStart = function() {
                    return this.d5
                }, e.prototype.splitCompleted = function() {
                    this.d5 = _.e.resolve(!1), this.m8(), this.d3 === this.d8 && (this.d4 = !0, this.d3++)
                }, e.prototype.appendResponse = function(e) {
                    this.d7 = (0, Oe.U)(this.d7, e)
                }, e.prototype.getResponse = function() {
                    return this.d7
                }, e.prototype[(rr = "d2", ir = "d3", or = "d4", ar = "d7", "m1")] = function() {
                    var e = this;
                    this.d5 = new _.e((function(t) {
                        e.d6 = t
                    })), 1 === this.d8 && this.d6(!0)
                }, e.prototype[(ur = "m2", "m3")] = function(e, t) {
                    var n = e.splitNum,
                        r = this.d2;
                    if (!r[n]) {
                        r[n] = t;
                        var i = this.d8 + 1 === n;
                        this.d4 && i ? this.m8() : this.m7("identify", t)
                    }
                }, e.prototype.m4 = function(e, t) {
                    var n = e.splitNum,
                        r = this.d2;
                    if (!r[n]) {
                        r[n] = t;
                        var i = this.d8 + 1 === n;
                        this.d4 && i && (this.d3 = n, this.m8())
                    }
                }, e.prototype.m5 = function(e, t) {
                    var n = e.splitNum;
                    this.d2[n] = t, this.d3 = n + 1, this.d3 === this.d8 && ((0, h.LO)(e.trcResponse, "TRC response must be present"), this.d7 = e.trcResponse, this.d6(!0))
                }, e.prototype.m6 = function(e) {
                    for (var t = window.parent.frames, n = 0; n < t.length; n++) {
                        var r = t[n];
                        r !== window.self && this.m7(e, r)
                    }
                }, e.prototype.m7 = function(e, t, n) {
                    var r;
                    void 0 === n && (n = {});
                    var i = (0, v.pi)((0, v.pi)({}, n), ((r = {}).tbp = !0, r.type = e, r.splitNum = this.d8, r.complete = this.d4, r));
                    t.postMessage(i, this.d1)
                }, e.prototype.m8 = function() {
                    var e = this.d2[this.d8 + 1];
                    e && this.m7("runCom", e, {
                        trcResponse: this.d7
                    })
                }, e
            }();

        function pr() {
            return null != cr || (cr = e.L5.config.runtime.isAMP), cr
        }

        function fr(e) {
            var t;
            e.hasContent || null === (t = a.tp.context) || void 0 === t || t.noContentAvailable()
        }

        function mr() {
            var e;
            return {
                sdkd: {
                    os: "AMP",
                    osv: (null === (e = a.tp.AMP_MODE) || void 0 === e ? void 0 : e.version) || "1",
                    sdkt: "Taboola AMP Driver",
                    sdkv: "1"
                }
            }
        }
        var vr, hr, gr = !1,
            br = !1,
            _r = !1,
            yr = function() {
                function t() {}
                return t.prototype.getName = function() {
                    return "amp"
                }, t.prototype.e7 = function(e) {
                    if (null != sr || (sr = "amp" === e.framework || (0, u.Qh)()), sr && !gr) {
                        var t = e;
                        return t.additionalData = mr(), gr = !0, t
                    }
                }, t.prototype.e6 = function() {
                    if (sr) {
                        e.L5.onResponseSummaryUpdate(fr);
                        var t = e.L5.config.runtime.ampData;
                        br = t.isSplitFeed, vr = t.feedContainerNum, br && (hr = function(e) {
                            if ((0, I.c)("iframe")) return new dr(e)
                        }(vr))
                    }
                }, t.prototype.e8 = function() {
                    return null == hr ? void 0 : hr.onSplitStart()
                }, t.prototype.e9 = function(e) {
                    if (br) {
                        var t = function() {
                            if (!wr && hr) {
                                wr = !0;
                                var e = hr.getResponse();
                                if ((0, r.it)(e)) return (0, lr.W3)(e)
                            }
                        }();
                        return t ? {
                            response: t
                        } : _r ? {} : void 0
                    }
                }, t.prototype.e11 = function(e) {
                    hr && hr.appendResponse(e)
                }, t.prototype.e13 = function(e) {
                    var t, n, r;
                    if (br && hr && e.hasFeeds) {
                        var i = Object.keys(e.feeds)[0],
                            o = e.feeds[i];
                        (0, h.LO)(o, "Feed must be present in that point");
                        var a = o.batchList[0],
                            u = a.placements,
                            c = function(e) {
                                for (var t, n = [], r = !1, i = 0, o = e; i < o.length; i++) {
                                    var a = o[i],
                                        u = null === (t = a.pcp) || void 0 === t ? void 0 : t.tps;
                                    if (u) {
                                        var c = (s = void 0, (s = u.split("split-amp-")[1]) ? parseInt(s) : 0);
                                        if (c < vr) n = [];
                                        else if (c === vr) {
                                            n.push(a), r = !0;
                                            break
                                        }
                                    } else n.push(a)
                                }
                                var s;
                                return [n, r]
                            }(u),
                            s = c[0],
                            l = c[1];
                        _r = l, (0, h.DI)(s.length > 0, "Must find placements"), l && hr.splitCompleted();
                        var d = u.length === s.length;
                        if (l || !d) {
                            var p = function(e, t) {
                                var n, r = t.map((function(e) {
                                        return e.uip
                                    })),
                                    i = e.originalResponse[0],
                                    o = i.vl.filter((function(e) {
                                        return r.indexOf(e.uip) > -1
                                    }));
                                return (0, v.pi)((0, v.pi)({}, i), ((n = {}).vl = o, n))
                            }(e, s);
                            return (0, v.pi)((0, v.pi)({}, e), {
                                originalResponse: [p],
                                feeds: (t = {}, t[i] = (0, v.pi)((0, v.pi)({}, o), (n = {
                                    batchList: [(0, v.pi)((0, v.pi)({}, a), {
                                        placements: s
                                    })]
                                }, n.eof = null !== (r = o.eof) && void 0 !== r ? r : l, n)), t)
                            })
                        }
                    }
                }, t.prototype.e19 = function(e) {
                    sr && e.container && function(e, t) {
                        if (t)
                            if (2 !== t.entityType) {
                                var n = e.querySelector(".".concat("trc_rbox_container"));
                                n && Er(n.offsetHeight)
                            } else ! function(e) {
                                Er(e.offsetHeight + xr, "feed")
                            }(e)
                    }(e.container, e.feed || e.widget)
                }, t
            }(),
            wr = !1;
        Se(new yr);
        var xr = 100;

        function Er(e, t) {
            void 0 === t && (t = ""), a.tp.context.requestResize(void 0, e).catch((function(e) {
                (0, i.yN)("".concat(t, " - AMP resizing error: ").concat(e.toString()))
            }))
        }
        var Tr, Cr, Sr = __webpack_require__(2992),
            Rr = "-delta";

        function kr(e, t) {
            var n = e.children;
            return n && (e.children = n.map((function(e) {
                return kr(e, t)
            }))), Ir(e, t)
        }

        function Ir(e, t) {
            var n = (0, v.pi)({}, e),
                r = n.m;
            r || (r = (0, Sr.h)(n, t) || "");
            var i = n.name,
                o = r || i;
            if (!o) return n;
            if (function(e) {
                    return new RegExp("".concat(Rr, "$")).test(e)
                }(o)) return n;
            var a = o + Rr;
            return Cr[a] ? (r ? n.m = a : n.name = a, n) : n
        }
        Se(new(function() {
            function e() {}
            return e.prototype.getName = function() {
                return "DeltaModeAdapter"
            }, e.prototype.getRunOrder = function() {
                return 10
            }, e.prototype.e6 = function(e) {
                Tr = e.TABOOLA_STORE.access, Cr = Tr.config.publisher.modes
            }, e.prototype.e10 = function(e) {
                var t;
                if (e.vl) return e.vl.filter((function(e) {
                    return "1" === e.dlt
                })).length > 0 ? ((t = (0, Oe.I8)(e)).vl = t.vl.map((function(t) {
                    var n = t.multiWidget;
                    return n && n.children && (t.multiWidget = kr(n, e)), t.dlt ? Ir(t, e) : t
                })), t) : t
            }, e
        }()));
        var Lr, Or, Mr = __webpack_require__(7253);

        function Nr() {
            return null != Lr || (Lr = (0, Tn.EK)("swap_debug")), Lr
        }

        function Pr(e) {
            Nr() && (0, i.o7)("%c HP Swap - ".concat(e), "background: #222; color: #bada55")
        }

        function Dr(e) {
            var t = (0, s.u)(e),
                n = t.pathname,
                r = Hr().articleParam;
            if (!r || !t.search) return n;
            var i = r.split(",").map((function(e) {
                    return e.trim()
                })),
                o = (0, oe.jH)(e);
            return i.forEach((function(e) {
                t.search.indexOf("".concat(e, "=")) > -1 && (n += "?".concat(e, "=").concat(o[e]))
            })), n
        }

        function Ar(e, t) {
            return (0, Mr.Au)(e.querySelectorAll(t))
        }

        function Ur(e, t) {
            if (Nr()) {
                var n = t || "#2065b8",
                    r = document.createElement("style"),
                    i = ".tbl-swap-debug { outline: rgb(0, 114, 185) solid 4px !important; box-shadow: inset 0 0 20px ".concat(n, "; }");
                r.appendChild(document.createTextNode(i)), document.head.appendChild(r), e.classList.add("tbl-swap-debug")
            }
        }! function(e) {
            e.SWAP_DISABLED = "swapped was disabled due to force param", e.NO_REGIONS = "no regions were found"
        }(Or || (Or = {}));
        var Fr, qr, Vr = __webpack_require__(5898),
            Br = "organic-hp-swap-mode";

        function jr() {
            if (!Fr) return !1;
            if (1 === (0, Vr.ws)()) return !1;
            var t = (0, En.r)(e.L5.optionsSummary.itemSourceType);
            if ("home" !== t && "homepage" !== t) return !1;
            if ((0, Tn.EK)("swap_disabled")) return Pr(Or.SWAP_DISABLED), !1;
            var n = Fr.allowed_urls,
                r = e.L5.config.runtime.pageUrl,
                i = r.hostname + r.pathname;
            return 0 === n.length || n.indexOf(i) > -1
        }

        function Hr() {
            return Fr
        }
        var zr, Wr, Gr, Yr, Qr = ((qr = {}).r = "[data-tb-region-item]", qr.t = "[data-tb-title]", qr.l = "[data-tb-link]", qr.img = "[data-tb-thumbnail]", qr.c = "[data-tb-category]", qr.d = "[data-tb-date]", qr.a = "[data-tb-author]", qr.desc = "[data-tb-description]", qr.he = "[data-tb-hide]", qr);

        function Kr(e) {
            var t, n, r, i = null !== (r = null === (n = e.i) || void 0 === n ? void 0 : n[0].template) && void 0 !== r ? r : {},
                o = Hr().templates,
                a = (null == o ? void 0 : o[i]) || void 0;
            return a ? ((t = {}).r = a.r || Qr.r, t.t = a.t || Qr.t, t.l = a.l || Qr.l, t.img = a.img || Qr.img, t.c = a.c || Qr.c, t.d = a.d || Qr.d, t.a = a.a || Qr.a, t.desc = a.desc || Qr.desc, t.he = a.he || Qr.he, t) : (0, v.pi)({}, Qr)
        }
        var Jr, $r, Xr, Zr, ei, ti, ni = [],
            ri = 0;
        var ii = function() {
            function e(e) {
                this[$r] = !1, this[Xr] = !0, this[Zr] = {}, this[ei] = {}, this[ti] = !1, this._config = e, this.d5 = e.taboolaSelectorChecker, this.m1()
            }
            return e.prototype.cleanUp = function() {
                this._config = (0, y.F)(), this.d2 = !0, this.d4 = (0, y.F)(), this.d3 = (0, y.F)(), this.d1 = !1, this.m1(), this.d1 = !1
            }, e.prototype[($r = "d1", Xr = "d2", Zr = "d3", ei = "d4", ti = "d1", "m1")] = function() {
                var e = this;
                this.m4() || (0, i.H)("Region name must be a unique name"), this.m2(), this._config.regions.forEach((function(t) {
                    e.d4[t.n] = 0;
                    var n = document.querySelector(t.rs);
                    n ? (n.dataset.tblClickMutation || (e.m5(t, n), n.dataset.tblClickMutation = "true"), e.m6(t, n)) : (e.d3[t.n] = t, e.m3())
                }))
            }, e.prototype.m2 = function() {
                var e = this,
                    t = this._config.maxMutationTimeout;
                t && window.setTimeout((function() {
                    e.d2 = !1
                }), t)
            }, e.prototype.m3 = function() {
                var e = this;
                MutationObserver && !this.d1 && (new MutationObserver((function(t, n) {
                    e.d2 ? (0, Oe.mt)(e.d3, (function(t) {
                        var i = e.d3[t],
                            o = document.querySelector(i.rs);
                        o && (delete e.d3[t], e.m6(i, o), (0, r.it)(e.d3) || n.disconnect())
                    })) : n.disconnect()
                })).observe(document.body, {
                    childList: !0,
                    subtree: !0
                }), this.d1 = !0)
            }, e.prototype.m4 = function() {
                var e = this._config.regions;
                return e.every((function(t) {
                    return e.every((function(e) {
                        return t.n !== e.n || t === e
                    }))
                }))
            }, e.prototype.m5 = function(e, t) {
                var n = this;
                if (MutationObserver) {
                    var i = function(e, t) {
                        n.m6(e, t)
                    }.bind(null, e, t);
                    new MutationObserver((0, r.yL)(i, 100)).observe(t, {
                        childList: !0,
                        subtree: !0
                    })
                } else this.m6(e, t)
            }, e.prototype.m6 = function(e, t) {
                var n = "".concat(e.cs, ":not([data-tbl-listen-index])"),
                    r = (0, Mr.Au)(t.querySelectorAll(n));
                r && this.m7(r, e)
            }, e.prototype.m7 = function(e, t) {
                var n = this;
                e.forEach((function(r, i) {
                    if (r instanceof HTMLAnchorElement) {
                        var o = n.d4[t.n];
                        if (o > 0 && i > 0) {
                            var a = r,
                                u = e[i - 1];
                            a.href === u.href && o--
                        }
                        r.dataset.tblListen || (n.m8(r, t), r.dataset.tblListen = "true", r.dataset.tblListenIndex = o.toString()), n.d4[t.n] = o + 1
                    }
                }))
            }, e.prototype.m8 = function(e, t) {
                var n = this;
                e.addEventListener("click", (function(r) {
                    var i = r.target,
                        o = !1;
                    n.d5 && ((0, R.Gc)(i, n.d5) || i.hasAttribute(n.d5)) && (o = !0);
                    var a = {
                        region: t.n,
                        index: e.dataset.tblListenIndex || "0",
                        isTaboola: o,
                        engine: "trecs"
                    };
                    (0, Ze.$q)("fallbackClick", a)
                }), !0)
            }, e
        }();
        var oi = __webpack_require__(1283),
            ai = __webpack_require__(6624),
            ui = !1;

        function ci() {
            if (e.L5.responseSummary.testAndExperiment.hasVariantPerPlacementFlag) {
                var t = e.L5.responseSummary.testAndExperiment.testVariantsMap[(0, ai.m_)(oi.S.L2)],
                    n = Hr().ga;
                if (n && window.gtag) {
                    var r = {};
                    r[n.gtagNameId] = t, r.non_interaction = !0, window.gtag("event", n.gtagName, r), ui = !0
                }
                if (n && window.ga && window.ga.create) {
                    var i = {};
                    i[n.dimension_id] = t, i.nonInteraction = !0, window.ga("send", "event", n.name, t, i), ui = !0
                }
            }
        }

        function si(e, t, n) {
            void 0 === n && (n = ""), di({
                placementName: e,
                type: "ERROR",
                reason: t,
                message: n,
                date: Date.now()
            })
        }

        function li(e, t, n) {
            di({
                type: "WARNING",
                reason: e,
                message: t,
                extraData: n,
                date: Date.now()
            })
        }

        function di(e) {
            var t = {
                data: e,
                type: "fallback"
            };
            (0, Ze.E6)(t)
        }
        var pi = {};

        function fi(e) {
            var t = {
                data: e,
                type: "swapData"
            };
            (0, Ze.Sn)(t)
        }

        function mi(e, t, n) {
            try {
                return e.apply(void 0, t)
            } catch (e) {
                si(void 0, function(e) {
                    switch (e) {
                        case "ps":
                            return "preSwapFailure";
                        case "pc":
                            return "postScriptFailure";
                        case "pr":
                            return "preRegionFailure";
                        case "date":
                            return "dateScriptFailure";
                        default:
                            return "generalFailure"
                    }
                }(n), "failed to run script ".concat(e.message))
            }
        }

        function vi(t) {
            for (var n = [], r = 1; r < arguments.length; r++) n[r - 1] = arguments[r];
            var i, o, a, u = (i = t, o = e.L5.config, a = "hp4u-script-config-".concat(i, "-").concat(o.publisher.publisherName), o.publisher.global[a]);
            if (!u || !(0, g.hR)(u)) return !1;
            switch (t) {
                case "date":
                case "pc":
                    return function(e, t, n) {
                        (0, b.s)((function() {
                            mi(e, t, n)
                        }))
                    }(u, n, t), !0;
                case "pr":
                case "image":
                case "ps":
                    return mi(u, n, t);
                default:
                    throw new Error("Trying to run undocumented hook type. Add it to SwapHooksEnum")
            }
            return !1
        }
        var hi = __webpack_require__(5187),
            gi = "taboola_main_section_swap";

        function bi() {
            var e, t;
            return null === (t = null === (e = Hr()) || void 0 === e ? void 0 : e.regions) || void 0 === t ? void 0 : t.filter((function(e) {
                return !("en" in e)
            }))
        }
        var _i = -1,
            yi = 0;

        function wi(t) {
            for (var n = (0, L.qn)(), r = []; t.length > 0;) yi++, t.splice(0, _i).forEach((function(e) {
                r.push(xi(e))
            }));
            n.placements = r, e.Un.appendOptionsSummary(n), (0, hi.k)()
        }

        function xi(e) {
            return {
                rboxResponsesIndex: 0,
                placementName: e.p,
                modeName: Br,
                instances: [(0, Ne.yt)(gi)],
                targetType: "mix",
                containerIgnored: !0,
                byPublisher: !1,
                priority: 1,
                groupName: "hp4u_batch".concat(yi)
            }
        }
        var Ei, Ti = !1;

        function Ci(e) {
            var t = e[0];
            if (t) {
                var n = t.uip;
                return Hr().regions.some((function(e) {
                    return e.p === n
                }))
            }
        }
        var Si, Ri = __webpack_require__(7158),
            ki = void 0,
            Ii = !1,
            Li = !1;
        var Oi = {
            debug: !1,
            size: "10px",
            opacity: "0.2",
            timeout: 4
        };

        function Mi(e, t) {
            e && e.b && (0, b.s)((function() {
                (0, Mr.Au)(t.querySelectorAll(".tbl_blur")).forEach((function(e) {
                    e.classList.remove("tbl_blur")
                }))
            }))
        }

        function Ni() {
            Ii && (Si && clearTimeout(Si), Ii = !1, (0, b.s)((function() {
                (0, Mr.Au)(document.querySelectorAll(".tbl_blur")).forEach((function(e) {
                    e.classList.remove("tbl_blur")
                }))
            })))
        }

        function Pi() {
            return Li
        }

        function Di(e) {
            var t = null == ca ? void 0 : ca.find((function(t) {
                return decodeURIComponent(t.pl) === e
            }));
            return t ? t.s.map(Number) : []
        }
        var Ai, Ui, Fi, qi = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,
            Vi = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
            Bi = /[^-+\dA-Z]/g,
            ji = "en-US",
            Hi = {
                default: "ddd mmm dd yyyy HH:MM:ss",
                shortDate: "m/d/yy",
                mediumDate: "mmm d, yyyy",
                longDate: "mmmm d, yyyy",
                fullDate: "dddd, mmmm d, yyyy",
                shortTime: "h:MM TT",
                mediumTime: "h:MM:ss TT",
                longTime: "h:MM:ss TT Z",
                isoDate: "yyyy-mm-dd",
                isoTime: "HH:MM:ss",
                isoDateTime: "yyyy-mm-dd'T'HH:MM:ss",
                isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'"
            },
            zi = {
                dayNames: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                monthNames: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
            };

        function Wi(e) {
            return parseInt(e.toLocaleString(ji, {
                month: "numeric",
                timeZone: Ai
            }), 10)
        }

        function Gi(e, t) {
            return Zi(e.toLocaleString(ji, {
                month: t,
                timeZone: Ai
            }))
        }

        function Yi(e) {
            return parseInt(e.toLocaleString(ji, {
                day: "numeric",
                timeZone: Ai
            }), 10)
        }

        function Qi(e, t) {
            return Zi(e.toLocaleString(ji, {
                weekday: t,
                timeZone: Ai
            }))
        }

        function Ki(e) {
            return parseInt(e.toLocaleString(ji, {
                hour: "numeric",
                hour12: !1,
                timeZone: Ai
            }), 10)
        }

        function Ji(e) {
            return parseInt(e.toLocaleString(ji, {
                minute: "numeric",
                timeZone: Ai
            }), 10)
        }

        function $i(e) {
            return parseInt(e.toLocaleString(ji, {
                year: "numeric",
                timeZone: Ai
            }), 10)
        }

        function Xi(e, t) {
            void 0 === t && (t = 2);
            for (var n = e.toString(); n.length < t;) n = "0".concat(n);
            return n
        }

        function Zi(e) {
            return e.charAt(0).toUpperCase() + e.slice(1)
        }

        function eo(e) {
            if (e % 100 >= 11 && e % 100 <= 13) return "th";
            switch (e % 10) {
                case 1:
                    return "st";
                case 2:
                    return "nd";
                case 3:
                    return "rd";
                default:
                    return "th"
            }
        }

        function to(e) {
            var t = (e.toString().match(Vi) || [""]).pop();
            return (null == t ? void 0 : t.replace(Bi, "")) || ""
        }

        function no(e, t, n) {
            var r = t ? "getUTC" : "get";
            switch (e) {
                case "d":
                    return n["".concat(r, "Date")]().toString();
                case "dd":
                    return Xi(n["".concat(r, "Date")]());
                case "ddd":
                    var i = n["".concat(r, "Day")]();
                    return zi.dayNames[i];
                case "dddd":
                    return i = n["".concat(r, "Day")](), zi.dayNames[i + 7];
                case "m":
                    return ((o = n["".concat(r, "Month")]()) + 1).toString();
                case "mm":
                    return Xi((o = n["".concat(r, "Month")]()) + 1);
                case "mmm":
                    var o = n["".concat(r, "Month")]();
                    return zi.monthNames[o];
                case "mmmm":
                    return o = n["".concat(r, "Month")](), zi.monthNames[o + 12];
                case "yy":
                    return n["".concat(r, "FullYear")]().toString().slice(2);
                case "yyyy":
                    return n["".concat(r, "FullYear")]().toString();
                case "h":
                    return (n["".concat(r, "Hours")]() % 12 || 12).toString();
                case "hh":
                    return Xi(n["".concat(r, "Hours")]() % 12 || 12);
                case "H":
                    return n["".concat(r, "Hours")]().toString();
                case "HH":
                    return Xi(n["".concat(r, "Hours")]());
                case "M":
                    return n["".concat(r, "Minutes")]().toString();
                case "MM":
                    return Xi(n["".concat(r, "Minutes")]());
                case "o":
                    var a = t ? 0 : n.getTimezoneOffset();
                    return (a > 0 ? "-" : "+") + Xi(100 * Math.floor(Math.abs(a) / 60) + Math.abs(a) % 60, 4);
                case "t":
                    return n["".concat(r, "Hours")]() < 12 ? "a" : "p";
                case "tt":
                    return n["".concat(r, "Hours")]() < 12 ? "am" : "pm";
                case "T":
                    return n["".concat(r, "Hours")]() < 12 ? "A" : "P";
                case "TT":
                    return n["".concat(r, "Hours")]() < 12 ? "AM" : "PM";
                case "Z":
                    return t ? "UTC" : to(n);
                case "S":
                    return eo(n["".concat(r, "Date")]())
            }
            return e.slice(1, e.length - 1)
        }

        function ro(e, t, n) {
            switch (e) {
                case "d":
                    return Yi(n).toString();
                case "dd":
                    return Xi(Yi(n));
                case "ddd":
                    return Qi(n, "short");
                case "dddd":
                    return Qi(n, "long");
                case "m":
                    return Wi(n).toString();
                case "mm":
                    return Xi(Wi(n));
                case "mmm":
                    return Gi(n, "short");
                case "mmmm":
                    return Gi(n, "long");
                case "yy":
                    return $i(n).toString().slice(2);
                case "yyyy":
                    return $i(n).toString();
                case "h":
                    return (Ki(n) % 12 || 12).toString();
                case "hh":
                    return Xi(Ki(n) % 12 || 12);
                case "H":
                    return Ki(n).toString();
                case "HH":
                    return Xi(Ki(n));
                case "M":
                    return Ji(n).toString();
                case "MM":
                    return Xi(Ji(n));
                case "o":
                    var r = t ? 0 : n.getTimezoneOffset();
                    return (r > 0 ? "-" : "+") + Xi(100 * Math.floor(Math.abs(r) / 60) + Math.abs(r) % 60, 4);
                case "t":
                    return Ki(n) < 12 ? "a" : "p";
                case "tt":
                    return Ki(n) < 12 ? "am" : "pm";
                case "T":
                    return Ki(n) < 12 ? "A" : "P";
                case "TT":
                    return Ki(n) < 12 ? "AM" : "PM";
                case "Z":
                    return t ? "UTC" : to(n);
                case "S":
                    return eo(Yi(n))
            }
            return e.slice(1, e.length - 1)
        }

        function io(e, t) {
            if (!t) return !1;
            switch (e) {
                case "image":
                    var n = !!t.style.backgroundImage || !!t.dataset.bg;
                    return "IMG" === t.tagName || n;
                case "anchor":
                    return "A" === t.tagName;
                case "picture":
                    return "PICTURE" === t.tagName;
                default:
                    return !1
            }
        }

        function oo(e) {
            e.dataset.tblSwap = "true"
        }
        var ao, uo = __webpack_require__(7807),
            co = "_i",
            so = window.Symbol || "symbol";
        so.toStringTag || (so.toStringTag = "toStringTag"), so.iterator || (so.iterator = "iterator");
        var lo = function() {
            function e() {
                this[ao] = []
            }
            return Object.defineProperty(e.prototype, "size", {
                get: function() {
                    return this[co].length
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.clear = function() {
                this[co] = []
            }, e.prototype.delete = function(e) {
                for (var t = 0; t < this[co].length; t++)
                    if (this[co][t].key === e) return this[co].splice(t, 1), !0;
                return !1
            }, e.prototype.forEach = function(e, t) {
                var n = this;
                this[co].forEach((function(t) {
                    e(t.value, t.key, n)
                }))
            }, e.prototype._getItem = function(e) {
                return this[co].filter((function(t) {
                    return t.key === e
                }))[0]
            }, e.prototype.get = function(e) {
                var t;
                return (null === (t = this._getItem(e)) || void 0 === t ? void 0 : t.value) || void 0
            }, e.prototype.has = function(e) {
                return !!this._getItem(e)
            }, e.prototype.set = function(e, t) {
                var n = this._getItem(e);
                return n ? n.value = t : this[co].push({
                    key: e,
                    value: t
                }), this
            }, e
        }();
        ao = co;
        var po = __webpack_require__(983);
        __webpack_require__(6337);
        var fo, mo = window.Map ? new Map : new lo,
            vo = window.Map ? new Map : new lo,
            ho = (0, u.Qh)(),
            go = null,
            bo = !1,
            _o = {},
            yo = 1e-5,
            wo = [yo, .25, .5, .75, 1];

        function xo(e, t, n) {
            return function() {
                ! function(e, t, n) {
                    var r, i = Lo(e);
                    if (i) {
                        if (1 === i.callbacks.length) return null === (r = _o[n]) || void 0 === r || r.unobserve(e), void Oo(i).delete(e);
                        var o = i.callbacks.indexOf(t);
                        o > -1 && i.callbacks.splice(o, 1)
                    }
                }(e, t, n)
            }
        }

        function Eo(e) {
            return "px".concat(e)
        }

        function To(e) {
            var t = (0, po.X)();
            e.forEach((function(e) {
                var n = e.target,
                    r = Lo(n);
                (0, h.LO)(r, "elementData is undefined");
                var i = e.intersectionRatio >= r.visiblePercents;
                if (r.isCurrentVisible = i, r.lastIOPercent = e.intersectionRatio, !i && r.wasVisibleLastTime) return r.lastVisibleTime = 0, r.wasVisibleLastTime = !1, void Po(r, n, i);
                if (i && 0 === r.lastVisibleTime) {
                    r.lastVisibleTime = t;
                    var o = function() {
                        if (!(r.lastIOPercent < r.visiblePercents)) {
                            if (r.enableOverlayCheck) {
                                if (function(e, t, n) {
                                        var r, i = e.getBoundingClientRect(),
                                            o = (.5, .5, {
                                                targetElementCenterX: (r = i).left + Math.round(.5 * (r.right - r.left)),
                                                targetElementCenterY: r.top + Math.round(.5 * (r.bottom - r.top))
                                            }),
                                            a = o.targetElementCenterX,
                                            u = o.targetElementCenterY,
                                            c = document.elementFromPoint(a - 1, u - 1) || document.elementFromPoint(a + 1, u + 1);
                                        if (!c) return !1;
                                        if (e === c || e.contains(c)) return !1;
                                        if (n) {
                                            var s = i.top,
                                                l = i.top + i.height,
                                                d = Io(a, s, e),
                                                p = Io(a, l, e);
                                            if (!d && !p) return !1
                                        }
                                        return !t(c)
                                    }(n, r.overlayElementValidator, r.enableFullOverlayCheck)) return r.wasVisibleLastTime = !1, r.isCurrentVisible = !1, r.lastVisibleTime = 0, void
                                function(e) {
                                    Ro.indexOf(e) > -1 || (Ro.push(e), ko === Co && (ko = window.setInterval((function() {
                                        Ro.forEach((function(e) {
                                            e()
                                        }))
                                    }), So)))
                                }(o);
                                e = o, t = Ro.indexOf(e), Ro.splice(t, 1), 0 === Ro.length && (window.clearInterval(ko), ko = Co)
                            }
                            var e, t;
                            r.wasVisibleLastTime = !0, Po(r, n, i)
                        }
                    };
                    r.visibleTime > 0 ? window.setTimeout(o, r.visibleTime) : o()
                } else !i && r.lastVisibleTime > 0 && (r.lastVisibleTime = 0)
            }))
        }
        var Co = -1,
            So = 500,
            Ro = [],
            ko = Co;

        function Io(e, t, n) {
            var r = document.elementFromPoint(e, t);
            return !!r && !(n === r || n.contains(r))
        }

        function Lo(e) {
            return mo.get(e) || vo.get(e)
        }

        function Oo(e) {
            return Do(e) ? vo : mo
        }

        function Mo(e) {
            if (go) {
                var t = e || mo,
                    n = (0, po.X)();
                t.forEach((function(e, t) {
                    No(e, t, n)
                }))
            }
        }

        function No(e, t, n) {
            void 0 === n && (n = (0, po.X)());
            var r = function(e, t, n) {
                void 0 === n && (n = !0);
                var r = function(e, t) {
                    if (!go || !e) return null;
                    var n = go.nativeWindowRect,
                        r = go.webViewRect.y + (t ? e.top : 0);
                    return {
                        rootBounds: n,
                        boundingClientRect: {
                            top: r,
                            left: n.left + e.left,
                            width: e.width,
                            right: n.left + e.left + e.width,
                            height: e.height,
                            bottom: r + e.height,
                            x: n.left + e.left,
                            y: r
                        }
                    }
                }(t.getBoundingClientRect(), n);
                if (!r) return !1;
                var i = r.boundingClientRect,
                    o = r.rootBounds;
                if (!i || !o) return !1;
                var a, u = e.rootMargin;
                return u > 0 && (i = {
                    top: i.top - u,
                    left: i.left - u,
                    right: i.right + u,
                    width: i.width + 2 * u,
                    height: i.height + 2 * u,
                    bottom: i.bottom + u,
                    x: i.x - u,
                    y: i.y - u
                }), i.top > o.top && i.top < o.bottom ? (a = (a = (o.bottom - i.top) / i.height) > 1 ? 1 : a) >= e.visiblePercents : i.bottom > o.top && i.bottom < o.bottom ? (a = (a = (i.bottom - o.top) / i.height) > 1 ? 1 : a) >= e.visiblePercents : i.top <= o.top && i.bottom >= o.bottom
            }(e, t);
            if (e.isCurrentVisible = r, !e.wasVisibleLastTime) {
                if (!e.wasVisibleLastTime && r && 0 === e.lastVisibleTime) return e.lastVisibleTime = n, void window.setTimeout(No.bind(null, e, t), e.visibleTime);
                !e.wasVisibleLastTime && !r && e.lastVisibleTime > 0 ? e.lastVisibleTime = 0 : e.wasVisibleLastTime !== r && n - e.lastVisibleTime >= e.visibleTime && (e.wasVisibleLastTime = !0, Po(e, t, r))
            }
        }

        function Po(e, t, n) {
            (0, v.ev)([], e.callbacks, !0).forEach((function(r) {
                var i = xo(t, r, Eo(e.rootMargin));
                r(n, i)
            }))
        }

        function Do(e) {
            return ho && e.rootMargin > 0
        }
        ho && a.tp.context.observeIntersection((0, r.yL)((function(e) {
            var t = e[e.length - 1];
            go = {
                nativeWindowRect: t.rootBounds,
                webViewRect: t.boundingClientRect
            }, Mo(vo)
        }), 50));
        var Ao = __webpack_require__(5217),
            Uo = ["srcset", "data-srcset", "loading", "sizes"],
            Fo = function() {
                function e(e, t, n) {
                    this.eventEmitter = new uo.v, this.imageAlreadyFailed = !1, this._cloudinaryTimer = 0, this._domElement = e, this._regionConfig = t, this._itemData = n, this.cloudinaryDisabled = Hr().disable_cloudinary, this.cloudinaryTimeout = Hr().cloudinaryTimeout
                }
                return e.prototype.isTimedOutBlurItem = function() {
                    return this._regionConfig.b && Pi()
                }, e.prototype.imageLoaded = function(e, t) {
                    e.dataset.tblSwap || (this.resetCloudinaryTimer(), this.isTimedOutBlurItem() ? Pr("blur timed out: image request") : (t.isBackgroundImage ? function(e, t) {
                        e.style.backgroundImage = 'url("'.concat(t.src, '")'), e.dataset.bg = e.dataset.bg && t.src, e.alt = e.alt && t.alt, e.title = e.title && t.title
                    }(this._domElement, e) : function(e, t, n) {
                        Array.prototype.slice.call(e.attributes).forEach((function(e) {
                                (function(e) {
                                    var t = e.nodeName;
                                    if (t.match(/^(src|data-src|alt|title)$/)) return !1;
                                    if (-1 !== Uo.indexOf(t)) return !1;
                                    var n = Hr().remove_image_attributes;
                                    return !(n && -1 !== n.indexOf(t))
                                })(e) && t.setAttribute("id" === e.nodeName ? "data-id" : e.nodeName, e.nodeValue)
                            })), "original" === t.dataset.source && function(e, t) {
                                Hr().fix_ratio && (e.width / e.height > t.width / t.height ? t.style.width = "".concat(e.width, "px") : t.style.height = "".concat(e.height, "px"), t.style.objectFit = "cover")
                            }(n, t),
                            function(e) {
                                var t = Hr().lazy_images;
                                if (t) {
                                    var n = t.attr;
                                    null == n || n.forEach((function(t) {
                                        e.hasAttribute(t) && e.setAttribute(t, e.src)
                                    }))
                                }
                            }(t), e.parentNode && e.parentNode.replaceChild(t, e),
                            function(e) {
                                var t = e.parentElement;
                                null !== t && io("picture", t) && Array.prototype.slice.call(t.querySelectorAll("source")).forEach((function(e) {
                                    return t.removeChild(e)
                                }))
                            }(t)
                    }(this._domElement, e, t.dimensions), oo(e), this.eventEmitter.emit("image_loaded")))
                }, e.prototype.finalizeImageUrl = function(e) {
                    var t = this._itemData.imageUrl,
                        n = this.cloudinaryDisabled ? t : function(e, t) {
                            var n = e.getImageUrls({
                                width: t.width,
                                height: t.height
                            });
                            return n.taboolaUrl = (0, Ao.mq)(n.taboolaUrl, {
                                hp4u: 1
                            }), n
                        }(this._itemData, e).taboolaUrl,
                        r = vi("image", t, e, this._domElement, this._itemData.originalCard);
                    return r && (0, oe.Wr)(r) && (n = r), n
                }, e.prototype.executeImageSource = function() {
                    var e = this,
                        t = this._domElement,
                        n = t.tagName,
                        r = t.style,
                        i = t.dataset,
                        o = function(e) {
                            var t = Hr().image_dim_elem,
                                n = null;
                            t && (n = (0, R.Gc)(e, t));
                            var r = n || e,
                                i = qo(r),
                                o = i.width,
                                a = i.height;
                            if (0 === o || 0 === a) {
                                var u = function(e) {
                                    for (var t = !1, n = e; !t;) {
                                        var r = n.parentElement;
                                        if (!r) break;
                                        var i = qo(r),
                                            o = i.height,
                                            a = i.width;
                                        if (o > 0 && a > 0) return t = !0, {
                                            width: a,
                                            height: o
                                        };
                                        n = r
                                    }
                                    return {
                                        width: 0,
                                        height: 0
                                    }
                                }(r);
                                if (!u) return {
                                    width: 0,
                                    height: 0
                                };
                                o = u.width, a = u.height
                            }
                            return {
                                width: o,
                                height: a
                            }
                        }(this._domElement),
                        a = this.finalizeImageUrl(o),
                        u = !("IMG" === n || !r.backgroundImage && !i.bg),
                        c = this.getImageElement(u);
                    this.cloudinaryDisabled || (this._cloudinaryTimer = window.setTimeout((function() {
                        li("cloudinaryTimeout", "", a), e.imageFailed(c)
                    }), this.cloudinaryTimeout));
                    var s = {
                        isBackgroundImage: u,
                        dimensions: o
                    };
                    c.addEventListener("load", (function() {
                        e.imageLoaded(c, s)
                    }), !0), c.addEventListener("error", (function() {
                        e.imageFailed(c)
                    }), !0), this.setImageAttributes(c, a)
                }, e.prototype.resetCloudinaryTimer = function() {
                    this._cloudinaryTimer && (window.clearTimeout(this._cloudinaryTimer), this._cloudinaryTimer = 0)
                }, e.prototype.imageFailed = function(e) {
                    li("imageLoadingFailure", "", this._itemData.imageUrl), this.resetCloudinaryTimer(), this.isRetryAllowed(e) && (e.src = this._itemData.imageUrl, e.dataset.src = this._itemData.imageUrl, e.dataset.source = "original", this.imageAlreadyFailed = !0, e.onerror = null)
                }, e.prototype.isRetryAllowed = function(e) {
                    return !e.dataset.tblSwap && !this.imageAlreadyFailed && !this.cloudinaryDisabled
                }, e.prototype.cleanUp = function() {
                    this.eventEmitter.removeAll(), this.eventEmitter = (0, y.F)()
                }, e.prototype.setImageAttributes = function(e, t) {
                    e.src = t, this._domElement.getAttribute("alt") && (e.alt = this._itemData.title), this._domElement.title && (e.title = this._itemData.title), e.dataset.src = t,
                        function(e, t) {
                            e.dataset.src = t
                        }(e, t), e.dataset.source = this.cloudinaryDisabled ? "original" : "cloudinary", e.dataset.cloned = "true"
                }, e.prototype.getImageElement = function(e) {
                    if (0 === this._domElement.children.length || e) return (0, Me.U)("img");
                    var t = this._domElement.cloneNode(!0);
                    return function(e) {
                        Uo.forEach((function(t) {
                            return e.removeAttribute(t)
                        }));
                        var t = Hr().remove_image_attributes;
                        t && t.forEach((function(t) {
                            return e.removeAttribute(t)
                        }))
                    }(t), t
                }, e
            }();

        function qo(e) {
            var t, n;
            if (e.clientWidth && e.clientHeight) n = e.clientWidth, t = e.clientHeight;
            else {
                var r = e.getBoundingClientRect();
                n = r.width, t = r.height
            }
            return {
                width: n,
                height: t
            }
        }
        var Vo, Bo = [];
        var jo, Ho, zo = {},
            Wo = {},
            Go = !1,
            Yo = 0,
            Qo = /^HP\s*/,
            Ko = 1e4,
            Jo = 3e4,
            $o = 3;

        function Xo(e) {
            (0, Oe.mt)(zo, (function(t) {
                e(t)
            }))
        }

        function Zo(e) {
            return e.replace(Qo, "")
        }

        function ea(e, t) {
            zo[e].status = t
        }

        function ta(e) {
            ! function(e) {
                fi(zo[e].data)
            }(e), ea(e, "sent"), Yo++
        }

        function na() {
            var e;
            (0, Oe.z)(zo) || (Xo((function(e) {
                "ready" === zo[e].status && ta(e)
            })), e = Object.keys(zo).every((function(e) {
                var t = zo[e],
                    n = t.status,
                    r = t.data;
                return "sent" === n && 0 === r.numOfItemsNotOnPage
            })), e && (window.clearInterval(jo), Go = !0))
        }

        function ra(e, t, n) {
            var r;
            return (r = {}).region = Zo(e), r.template = "HP", r.numOfExpectedItems = t, r.numOfReturnedItems = n || 0, r.numOfSwappedItems = 0, r.numOfDupSkippedItems = 0, r.numOfItemsNotOnPage = 0, r.snoozedIndex = Di(e) || [], r.debugInfo = "loader_v: trecs", r.killSwitchEnabled = !1, r
        }

        function ia(e, t) {
            if (zo[e]) switch (t) {
                case "ready":
                    ! function(e) {
                        ea(e, "ready"), Wo[e] || (Wo[e] = "ready"), (Go || Yo % $o == 1) && ta(e)
                    }(e);
                    break;
                case "pending":
                    ea(e, "pending")
            }
        }

        function oa(e, t, n) {
            var r = function(e) {
                return e.replace(/\| Card \d+$/, "").trim()
            }(e);
            if ("killSwitchEnabled" !== t) {
                if (zo[r]) switch (t) {
                    case "numOfItemsNotOnPage":
                        ! function(e, t) {
                            var n = zo[e].data,
                                r = 0 === n.numOfItemsNotOnPage;
                            "sent" === zo[e].status && r || (n.numOfItemsNotOnPage = t, t > 0 && ia(e, "pending"))
                        }(r, n);
                        break;
                    case "numOfDupSkippedItems":
                        ! function(e, t) {
                            var n = zo[e].data;
                            t > 0 && (n.numOfDupSkippedItems += 1)
                        }(r, n);
                        break;
                    case "numOfSwappedItems":
                        ! function(e, t) {
                            var n = zo[e],
                                r = n.nonSwappedIndexes,
                                i = n.data;
                            r.map((function(e) {
                                return e !== t || (i.numOfSwappedItems += 1, !1)
                            }))
                        }(r, n), ia(r, "ready")
                }
            } else ! function(e) {
                var t = ra(e, 0, 0);
                t.killSwitchEnabled = !0, fi(t)
            }(r)
        }
        var aa = function() {
            function n(n, i, o, u) {
                var c, s = this;
                this.eventEmitter = new uo.v, this._actionsList = [], this._originalCard = {}, this._nonDefaultAttrSelectors = {}, this._itemMapping = (0, y.F)(), this._swapEnded = !1, this._errorMessages = [], this.executeSwap = function() {
                    if (! function(e) {
                            return !e.b || !Pi()
                        }(s._regionConfig)) return s._errorMessages.push("Card skipped due to blur timeout"), !1;
                    if (s._imageElement) {
                        var e = new Fo(s._imageElement, s._regionConfig, s.itemData);
                        e.eventEmitter.once("image_loaded", s.processSwapActions), e.executeImageSource()
                    } else s.processSwapActions();
                    return (0, k.sx)({
                        measuredType: "hp4uFirstCardSwapped",
                        measureLevel: "generalMeasure"
                    }), !0
                }, this.processSwapActions = function() {
                    s._actionsList.forEach((function(e) {
                        return e()
                    }))
                }, this.swapImage = function() {
                    var e = s.getMultipleHTMLElements("img"),
                        t = function(e) {
                            var t = "img",
                                n = Hr().ex_image_selector;
                            n && (t += "".concat(n));
                            var r = Ar(e, t),
                                i = Ar(e, "picture"),
                                o = r.filter((function(e) {
                                    return "svg" !== e.src.split(".")[1] && !(0, R.Gc)(e, "picture")
                                }));
                            return 0 === o.length ? 0 : o.length + i.length
                        }(s._domElement);
                    if (0 === e.length) return 0 === t || (s.handleImageError("Found images but no mapping was set", "missingImageMapping"), !1);
                    if (t > 1) return s.handleImageError("Found two images for swapping which is not supported", "multipleImages"), !1;
                    if (!s._originalCard.thumbnail) return s.handleImageError("Missing image in recommendation", "failedToRenderCard"), !1;
                    var n = e[0];
                    return io("image", n) ? (s._imageElement = n, !0) : (s.handleImageError("Found image mapping but it was mapped to incorrect image element", "incorrectImageMapping"), !1)
                }, this.swapTitle = function() {
                    return s.swapTextElement({
                        field: "t",
                        trcField: "title",
                        isMandatory: !0
                    })
                }, this.swapLink = function() {
                    var e = s.getMultipleHTMLElements("l");
                    return 0 === e.length ? (s._errorMessages.push("Missing link elements"), !1) : (e.forEach((function(e) {
                        io("anchor", e) && s._actionsList.push((function() {
                            ! function(e, n) {
                                n.href = e.clickUrl;
                                var r = function() {
                                    n.href = e.getEventClick()
                                };
                                n.addEventListener("mousedown", (function() {
                                    r()
                                })), n.addEventListener("touchstart", (function(e) {
                                    r(), (0, t.Mv)("enable-stop-propagation") && e.stopPropagation()
                                }))
                            }(s.itemData, e), e.getAttribute("title") && e.setAttribute("title", s._originalCard.title), oo(e)
                        }))
                    })), !0)
                }, this.swapCategory = function() {
                    var e = s.getHTMLElement("c");
                    if (!e) return !0;
                    var t = s._originalCard.category;
                    if (!t) return s._actionsList.push((function() {
                        e.setAttribute("style", "display: none !important;")
                    })), !0;
                    var n = t.split("//");
                    if (n.length > 0 && s._actionsList.push((function() {
                            ua(e, n[n.length - 1]), oo(e)
                        })), 1 === e.nodeType && "A" === e.nodeName) {
                        var r = "".concat(window.location.origin, "/").concat(t, "#tbla-swap");
                        s._actionsList.push((function() {
                            e.setAttribute("href", r), oo(e)
                        }))
                    }
                    return !0
                }, this.swapAuthor = function() {
                    return s.swapTextElement({
                        field: "a",
                        trcField: "author",
                        isMandatory: !1
                    })
                }, this.hideElement = function() {
                    var e = s._itemMapping.he;
                    return !e || (Ar(s._domElement, e).forEach((function(e) {
                        s._actionsList.push((function() {
                            e.setAttribute("style", "display: none !important;")
                        }))
                    })), !0)
                }, this.swapDate = function() {
                    var e = s.getHTMLElement("d");
                    return !e || (s._actionsList.push((function() {
                        if (vi("date", e, s._originalCard)) oo(e);
                        else {
                            var t = Hr().date_config;
                            if (!t) return s.setDefaultDate(e), void oo(e);
                            var n = function(e, t, n) {
                                    var r = (0, po.Y)(t);
                                    if (!e.useModified || !n) return [r, !1];
                                    var i = (0, po.Y)(n);
                                    if (!(0, g.l7)(e.minutesDiff)) return [i, !0];
                                    var o = i.getTime() - r.getTime();
                                    return Math.abs(o) > 6e4 * e.minutesDiff ? [i, !0] : [r, !1]
                                }(t, s._originalCard["published-date"], s._originalCard["last-modified"]),
                                r = n[0],
                                i = n[1],
                                o = function(e, t) {
                                    var n;
                                    ! function(e) {
                                        ji = e.locale || "en-US", Ai = e.timezone || void 0, null != Ui || (Ui = function() {
                                            var e = new Date;
                                            try {
                                                return e.toLocaleString("en-US", {
                                                    month: "numeric",
                                                    timeZone: "America/New_York"
                                                }), !0
                                            } catch (e) {
                                                return !1
                                            }
                                        }())
                                    }(t);
                                    var r = Hi.default;
                                    t.format && (r = Hi[t.format] || t.format), "UTC:" === r.slice(0, 4) && (r = r.slice(4), n = !0);
                                    var i = Ui ? ro : no;
                                    return r.replace(qi, (function(t) {
                                        return i(t, n, e)
                                    }))
                                }(r, t);
                            i && t.updatedLabel && (o = "".concat(t.updatedLabel, " ").concat(o)), ua(e, o), oo(e)
                        }
                    })), !0)
                }, this.swapDescription = function() {
                    return s.swapTextElement({
                        field: "desc",
                        trcField: "description",
                        isMandatory: !1
                    })
                }, this.swapAdditionalElements = function() {
                    return (0, Oe.mt)(s._nonDefaultAttrSelectors, (function(e) {
                        var t = e.replace(/^data-tb-/, ""),
                            n = s._nonDefaultAttrSelectors[e],
                            r = s._originalCard[t];
                        r && s._actionsList.push((function() {
                            n.forEach((function(e) {
                                ua(e, r), oo(e)
                            }))
                        }))
                    })), !0
                }, this.swapPostCard = function() {
                    return s._actionsList.push((function() {
                        vi("pc", s._domElement, s._originalCard)
                    })), !0
                }, this.swapEvents = function() {
                    return s._actionsList.push((function() {
                        var e = (0, t.Mv)("enable-full-overlay-check"),
                            n = function(e, t, n) {
                                var i = Lo(e);
                                if (i) return i.callbacks.push(t), {
                                    unsubscribe: xo(e, t, Eo((null == n ? void 0 : n.rootMargin) || 0)),
                                    isVisible: function() {
                                        return (null == i ? void 0 : i.isCurrentVisible) || !1
                                    }
                                };
                                Oo(i = (0, v.pi)({
                                    callbacks: [t],
                                    lastVisibleTime: 0,
                                    wasVisibleLastTime: !1,
                                    isCurrentVisible: !1,
                                    lastIOPercent: 0
                                }, function(e) {
                                    var t = .5;
                                    0 === (null == e ? void 0 : e.visiblePercents) && (t = yo);
                                    var n = 1e3;
                                    return 0 === (null == e ? void 0 : e.visibleTime) && (n = yo), {
                                        visiblePercents: t,
                                        visibleTime: n,
                                        rootMargin: (null == e ? void 0 : e.rootMargin) || 0,
                                        enableOverlayCheck: (null == e ? void 0 : e.enableOverlayCheck) || !1,
                                        enableFullOverlayCheck: (null == e ? void 0 : e.enableFullOverlayCheck) || !1,
                                        overlayElementValidator: (null == e ? void 0 : e.overlayElementValidator) || function() {
                                            return !1
                                        }
                                    }
                                }(n))).set(e, i);
                                var o = {
                                    unsubscribe: xo(e, t, Eo(i.rootMargin)),
                                    isVisible: function() {
                                        return (null == i ? void 0 : i.isCurrentVisible) || !1
                                    }
                                };
                                return Do(i) ? (No(i, e), o) : a.mb.taboolaMobile ? (go || (fo || (fo = (0, r.yL)((function() {
                                    Mo()
                                }), 50), document.addEventListener("scroll", fo, {
                                    passive: !0,
                                    capture: !0
                                })), function() {
                                    var e;
                                    !bo && a.mb.taboolaBridge && (bo = !0, a.mb.taboolaBridge.on("externalRectsUpdated", (function(e) {
                                        go = e, Mo()
                                    }))), go = (null === (e = a.mb.taboolaMobile) || void 0 === e ? void 0 : e.getNativeRects()) || null
                                }()), No(i, e), o) : (function(e, t) {
                                    var n = function(e) {
                                            var t = Eo(e);
                                            return _o[t]
                                        }(t) || new IntersectionObserver(To, {
                                            root: null,
                                            rootMargin: "".concat(t, "px"),
                                            threshold: wo
                                        }),
                                        r = Eo(t);
                                    _o[r] || (_o[r] = n), _o[r].observe(e)
                                }(e, i.rootMargin), o)
                            }(s._domElement, s.handleElementVisible, {
                                enableOverlayCheck: !0,
                                enableFullOverlayCheck: e
                            });
                        s._visibleUnsubscribe = n.unsubscribe, s._visibleCheck = n.isVisible, s._swapEnded = !0, s.eventEmitter.emit("card_swap_end"), oa(s._regionConfig.p, "numOfSwappedItems", s._index),
                            function(e, t) {
                                var n = e.dataset;
                                n.itemSwapped = "true", n.tblPlacement = t.placement.hpl, n.tblCategory = t.category, n.tblItemId = t.taboolaId, n.tblPublishDate = String(Math.floor(t.publishedData.getTime() / 1e3)), n.tblType = t.isSponsored ? "sponsored" : "organic", n.tblSwap = "true", n.tblEngine = "trecs", Ur(e)
                            }(s._domElement, s.itemData),
                            function(e) {
                                var t = Hr().seo_tag_id;
                                !va && t && (0, b.s)((function() {
                                    var n = document.createElement("span");
                                    n.style.display = "none", n.innerText = t, e.appendChild(n), va = !0
                                }))
                            }(s._domElement),
                            function(e, t, n) {
                                var r, i = function(e) {
                                        if (!e.r) return e.p;
                                        var t = /data-tb-region='([^']+)'/.exec(e.r);
                                        return t && t[1] ? t[1] : ""
                                    }(e),
                                    o = ((r = {}).iid = Number(t.taboolaId), r.is = t.IsSyndicated, r.it = t.sourceType, r.rid = i, r.rin = n, r.url = t.clickUrl, r.t = t.title, r.tn = t.imageUrl, r);
                                Bo.push(o)
                            }(s._regionConfig, s.itemData, s._index)
                    })), !0
                }, this.handleElementVisible = function(e, t) {
                    e && (t(), s.eventEmitter.emit("vis"), s.itemData.reportTracking("vi"))
                }, this.itemData = n, this._originalCard = (c = n.originalCard, ["title", "description", "category", "author"].forEach((function(e) {
                    var t = c[e];
                    t && (0, g.cb)(t) && (c[e] = (0, R._R)(t))
                })), c), this._regionConfig = i, this._index = u, this._domElement = o, e.Un.appendEntityCustomData({
                    entity: n,
                    element: o
                })
            }
            return n.prototype.cleanUp = function() {
                var e;
                this._actionsList = [], null === (e = this._visibleUnsubscribe) || void 0 === e || e.call(this), this._visibleUnsubscribe = void 0, this.eventEmitter.removeAll(), this.eventEmitter = (0, y.F)(), this._visibleCheck = void 0
            }, n.prototype.initCard = function(e) {
                this._itemMapping = e, this._nonDefaultAttrSelectors = this.findNonDefaultAdditionalTagElements(), (0, k.sx)({
                    measuredType: "hp4uFirstCardStartSwap",
                    measureLevel: "generalMeasure"
                })
            }, n.prototype.swapCard = function(e) {
                this.initCard(e);
                for (var t = !1, n = 0, r = [this.swapImage, this.swapTitle, this.swapLink, this.swapDate, this.swapCategory, this.swapAuthor, this.swapDescription, this.swapAdditionalElements, this.hideElement, this.swapPostCard, this.swapEvents, this.executeSwap]; n < r.length && (t = (0, r[n])()); n++);
                t || si(this._regionConfig.p, "failedToRenderCard", "failed to render card number ".concat(this._index, ": ").concat(this._errorMessages.join()))
            }, n.prototype.isVisible = function() {
                var e;
                return (null === (e = this._visibleCheck) || void 0 === e ? void 0 : e.call(this)) || !1
            }, n.prototype.isCardEnded = function() {
                return this._swapEnded
            }, n.prototype.handleImageError = function(e, t) {
                this._errorMessages.push(e), si(this._regionConfig.p, t, e)
            }, n.prototype.setDefaultDate = function(e) {
                var t, n, r, i, o, a, u = this.itemData.originalCard["last-modified"];
                ua(e, (t = u ? (0, po.Y)(u) : this.itemData.publishedData, n = t.getFullYear(), r = t.getMonth() + 1, i = t.getDate(), o = i < 10 ? "0".concat(JSON.stringify(i)) : i, a = r < 10 ? "0".concat(JSON.stringify(r)) : r, "".concat(n, "-").concat(a, "-").concat(o)))
            }, n.prototype.swapTextElement = function(e) {
                var t = this,
                    n = this.getHTMLElement(e.field);
                if (n && this._originalCard[e.trcField]) this._actionsList.push((function() {
                    ua(n, t._originalCard[e.trcField]), oo(n)
                }));
                else if (e.isMandatory) {
                    var r = "Missing ".concat(e.trcField, n ? " in recommendation," : " element,");
                    return this._errorMessages.push(r), !1
                }
                return !0
            }, n.prototype.findNonDefaultAdditionalTagElements = function() {
                var e = this,
                    t = {};
                return Hr().additional_tags.forEach((function(n) {
                    var r = Ar(e._domElement, "[".concat(n, "]"));
                    t[n] = r
                })), t
            }, n.prototype.getHTMLElement = function(e) {
                var t = this._itemMapping[e],
                    n = this._domElement.querySelector(t);
                if (n) return n;
                var r = t.replace(/\[|\]/g, "");
                return this._domElement.hasAttribute(r) ? this._domElement : null
            }, n.prototype.getMultipleHTMLElements = function(e) {
                var t = this._itemMapping[e],
                    n = Ar(this._domElement, t);
                if (n.length > 0) return n;
                var r = t.replace(/\[|\]/g, "");
                return this._domElement.hasAttribute(r) ? [this._domElement] : []
            }, n
        }();

        function ua(e, t) {
            if (e.childNodes.length <= 1)(0, R.k)(e, t);
            else {
                for (var n = !1, i = 0; i < e.childNodes.length; i++) {
                    var o = e.childNodes[i];
                    if (o.nodeType === Node.TEXT_NODE && o.textContent && "" !== o.textContent.trim()) {
                        (0, r.ug)(t) && ((Ho = (0, Me.U)("textarea")).innerHTML = t, t = Ho.value), o.textContent = t, n = !0;
                        break
                    }
                }
                n || (0, R.k)(e, t)
            }
        }
        var ca, sa = function() {
                function t(t) {
                    var n = this;
                    this.eventEmitter = new uo.v, this._cardRenderList = [], this._availableSent = !1, this._allCardsSwapped = !1, this.handleCardVisible = function() {
                        var t = e.L5.responseSummary.isItemLevelVisible;
                        n._cardRenderList.forEach((function(e) {
                            var r = !t;
                            e.isVisible() && (n._placement.setItemAsVisible(e.itemData), r = !0), r && e.eventEmitter.off("vis", n.handleCardVisible)
                        })), n._placement.sendEventVisible()
                    }, this._placement = t.placement, this._cardsForRender = (0, v.ev)([], t.placement.items, !0), this._regionConfig = t.regionConfig, this._domElement = t.domElement, this._defaultTemplate = t.template, e.Un.appendEntityCustomData({
                        entity: t.placement,
                        element: t.domElement
                    }), this.initEntityCustomData()
                }
                return t.prototype.cleanUp = function() {
                    this._cardRenderList.forEach((function(e) {
                        return e.cleanUp()
                    })), this._cardRenderList = [], this._visibilityUnsubscribe && (this._visibilityUnsubscribe(), this._visibilityUnsubscribe = void 0)
                }, t.prototype.getName = function() {
                    return this._placement.uip
                }, t.prototype.initEntityCustomData = function() {
                    this._placement.items.forEach((function(t) {
                        ! function(t) {
                            Fi || (Fi = document.createElement("div")), e.Un.appendEntityCustomData({
                                entity: t,
                                element: Fi
                            })
                        }(t)
                    }))
                }, t.prototype.hasCardsForRender = function() {
                    return this._cardsForRender.length > 0
                }, t.prototype.swapItem = function(e, t) {
                    var n = this._cardsForRender.shift();
                    if (n) {
                        var r = new aa(n, this._regionConfig, e, t);
                        this._cardRenderList.push(r), r.eventEmitter.once("vis", this.handleCardVisible), r.eventEmitter.on("card_swap_end", this.handleCardSwapEnd.bind(this)), r.swapCard(this._defaultTemplate), this._availableSent || (this._placement.sendEventAvailable(), this._availableSent = !0)
                    }
                }, t.prototype.handleCardSwapEnd = function() {
                    this._cardRenderList && (this._allCardsSwapped = this._cardRenderList.every((function(e) {
                        return e.isCardEnded()
                    })), this._allCardsSwapped && this.eventEmitter.emit("placement_rendered"), 0 === this._cardsForRender.length && this._allCardsSwapped && this._regionConfig.b && Mi(this._regionConfig, this._domElement))
                }, t.prototype.removeIfExist = function(e) {
                    for (var t = this._cardsForRender.length - 1; t >= 0; --t)
                        if (Dr(this._cardsForRender[t].clickUrl) === e) return this._cardsForRender.splice(t, 1), !0;
                    return !1
                }, t.prototype.checkIfAllCardsSwapped = function() {
                    return this._allCardsSwapped
                }, t
            }(),
            la = function() {
                function e(e, t) {
                    this._expectedSwappedCards = 0, this._placementRenderList = [], this._snoozedItems = [], this._cardIndexes = [], this._regionElements = [], this._totalCards = 0, this.name = e.p, this.selector = e.r;
                    var n = a.mb.document;
                    this._regionConfig = e, this._domElement = n.querySelector(this.selector), this._defaultTemplate = Kr(e), this._placements = t
                }
                return e.prototype.cleanUp = function() {
                    this._placementRenderList.forEach((function(e) {
                        return e.renderer.cleanUp()
                    })), this._placementRenderList = []
                }, e.prototype.createPlacement = function(e) {
                    var t, n = {
                        placement: e,
                        regionConfig: this._regionConfig,
                        domElement: this._domElement,
                        template: this._defaultTemplate
                    };
                    return {
                        renderer: new sa(n),
                        availableCards: e.items.length,
                        indexes: null === (t = e.hps) || void 0 === t ? void 0 : t.map(Number)
                    }
                }, e.prototype.initRegionSwap = function() {
                    var e = this;
                    this.initializeAndValidateRegion() && (this._domElement ? this.swapRegion() : (this.applyRegionObserver((function() {
                        return e.swapRegion()
                    })), oa(this._regionConfig.p, "numOfItemsNotOnPage", this._expectedSwappedCards)))
                }, e.prototype.initializeAndValidateRegion = function() {
                    var e, t;
                    return this._placements.some((function(e) {
                        return e.items.length > 0
                    })) ? (this.setCardsIndexes(), e = this._snoozedItems, t = this._cardIndexes, (null == e ? void 0 : e.length) > 0 && e.every((function(e) {
                        return t.indexOf(e) > -1
                    })) && (Mi(this._regionConfig, this._domElement), ia(this._regionConfig.p, "ready")), !0) : (si(this.name, "noItemsToRender"), Mi(this._regionConfig, this._domElement), ia(this._regionConfig.p, "ready"), !1)
                }, e.prototype.applyRegionObserver = function(e) {
                    var t = this;
                    if (MutationObserver) {
                        var n = this.selector,
                            r = this.name;
                        new MutationObserver((function(i, o) {
                            var u = a.mb.document.querySelector(n);
                            u && (t._domElement = u, setTimeout((function() {
                                Pr("Region loaded: ".concat(r)), e()
                            }), 0), o.disconnect())
                        })).observe(document.body, {
                            childList: !0,
                            subtree: !0
                        })
                    }
                }, e.prototype.swapRegion = function() {
                    var e = this;
                    vi("pr", this._domElement, this._regionConfig), this._placements.forEach((function(t) {
                        var n = e.createPlacement(t);
                        e._placementRenderList.push(n), n.renderer.eventEmitter.on("placement_rendered", e.placementRenderedEvent.bind(e))
                    })), this.initRegionItems()
                }, e.prototype.placementRenderedEvent = function() {
                    this._placementRenderList.every((function(e) {
                        return e.renderer.checkIfAllCardsSwapped()
                    })) && (this._domElement.dataset.regionSwapped = "true")
                }, e.prototype.subscribeChanges = function(e) {
                    if (MutationObserver) {
                        var t = this._domElement,
                            n = this.selector,
                            r = new MutationObserver((function(i, o) {
                                var a = Ar(t, "".concat(n, ":not([data-tbl-swap-started])"));
                                a.length > 0 && e(a), "true" === t.dataset.regionSwapped && r.disconnect()
                            }));
                        r.observe(t, {
                            childList: !0,
                            subtree: !0
                        })
                    }
                }, e.prototype.processRegionItems = function() {
                    var e = this;
                    this.removePotentialDup(), this._regionElements.forEach((function(t, n) {
                        if (t.index = n, !t.handled) {
                            if (t.element.dataset.tblSwapStarted = "true", -1 !== e._snoozedItems.indexOf(n)) return t.isSnoozed = !0, t.handled = !0, void Ur(t.element, "#FF1493");
                            if (-1 !== e._cardIndexes.indexOf(n)) {
                                var r = e.getNextPlacementToRender();
                                null == r || r.renderer.swapItem(t.element, n)
                            } else t.handled = !0
                        }
                    }))
                }, e.prototype.removePotentialDup = function() {
                    if (this._regionConfig.partial || this._regionElements.length !== this._totalCards || !this._snoozedItems.length)
                        for (var e, t = this.getPublisherUrls(), n = !0; n;) {
                            e = !1;
                            for (var r = 0, i = 0; i < t.length; i++) {
                                var o = t[i];
                                if (o)
                                    if (this.isItemShouldBeCurated(i)) this.removeIfExist(o) && (e = !0, this._expectedSwappedCards--, n = !1);
                                    else if (r++, this._totalCards < r && this.removeIfExist(o)) {
                                    e = !0, this._expectedSwappedCards--;
                                    break
                                }
                            }
                            if (!e) break;
                            oa(this._regionConfig.p, "numOfDupSkippedItems", 1)
                        }
                }, e.prototype.removeIfExist = function(e) {
                    var t = this._placementRenderList.some((function(t) {
                        return t.renderer.removeIfExist(e)
                    }));
                    return t && li("dupSkippedSwap", "Duplicated url [".concat(e, "] was found in region [").concat(this.name, "]")), t
                }, e.prototype.isItemShouldBeCurated = function(e) {
                    var t = this.isItemShouldBeSnoozed(e),
                        n = this._regionConfig.partial;
                    return n && 0 === n.filter((function(t) {
                        return t === e
                    })).length || t
                }, e.prototype.isItemShouldBeSnoozed = function(e) {
                    var t = this._snoozedItems.indexOf(e) > -1 || this._snoozedItems.indexOf(-1) > -1;
                    return this._snoozedItems.length > 0 && t
                }, e.prototype.getPublisherUrls = function() {
                    var e = this,
                        t = [];
                    return this._regionElements.forEach((function(n) {
                        var r = Ar(n.element, e._defaultTemplate.l);
                        r.length && r[0].href ? t.push(Dr(r[0].href)) : t.push("")
                    })), t
                }, e.prototype.getNextPlacementToRender = function() {
                    return this._placementRenderList.find((function(e) {
                        return e.renderer.hasCardsForRender()
                    }))
                }, e.prototype.setCardsIndexes = function() {
                    var e = this;
                    this._snoozedItems = Di(this.name), this._placements.forEach((function(t) {
                        var n, r = null === (n = t.hps) || void 0 === n ? void 0 : n.map(Number);
                        r && (e._cardIndexes = e._cardIndexes.concat(r))
                    })), this._totalCards = this._placements.reduce((function(e, t) {
                        return e + t.items.length
                    }), 0);
                    var t = this._cardIndexes.length - this._snoozedItems.length;
                    this._expectedSwappedCards = Math.min(t, this._totalCards)
                }, e.prototype.missingDomElements = function() {
                    var e = this,
                        t = this._cardIndexes.filter((function(t) {
                            return -1 === e._snoozedItems.indexOf(t)
                        })),
                        n = (t.length > 0 ? t[t.length - 1] : 0) + 1;
                    return Math.max(n - this._regionElements.length, 0)
                }, e.prototype.initRegionItems = function() {
                    var e = this,
                        t = (0, Mr.Au)(this._domElement.querySelectorAll(this._defaultTemplate.r));
                    this.addRegionItems(t);
                    var n = this.missingDomElements();
                    n > 0 && (oa(this._regionConfig.p, "numOfItemsNotOnPage", n), this.subscribeChanges((function(t) {
                        e.addRegionItems(t), e.processRegionItems(), oa(e._regionConfig.p, "numOfItemsNotOnPage", t.length)
                    }))), this.processRegionItems()
                }, e.prototype.addRegionItems = function(e) {
                    var t = this;
                    e.forEach((function(e) {
                        t.checkIfElementExist(e) || t._regionElements.push({
                            element: e,
                            handled: !1
                        })
                    }))
                }, e.prototype.checkIfElementExist = function(e) {
                    return this._regionElements.some((function(t) {
                        return t.element === e
                    }))
                }, e
            }(),
            da = {};

        function pa() {
            if (!document.getElementById("taboola_main_section_swap")) {
                var t = document.createElement("div");
                t.id = "taboola_main_section_swap", t.style.display = "none", document.body.appendChild(t)
            }
            var n, r;
            ! function() {
                var e;
                di(((e = {}).type = "SUCCESS", e.reason = "swapInitialized", e))
            }(), (0, k.Xq)({
                measuredType: "hp4uSwapStarted",
                measureLevel: "generalMeasure"
            }), vi("ps", Hr()), (r = bi()) ? function(e) {
                0 !== e.length && (_i = Hr().batchSize, wi((0, Oe.I8)(e)))
            }(r) : Pr(Or.NO_REGIONS), n = Hr().swap_data_event_interval || Ko, jo = window.setInterval((function() {
                return na()
            }), n), window.setTimeout((function() {
                window.clearInterval(jo), Go = !0, Xo((function(e) {
                    "sent" !== zo[e].status && ta(e)
                }))
            }), Jo), window.addEventListener("beforeunload", na), (0, b.s)((function() {
                var t;
                (function() {
                    var e, t;
                    (function() {
                        var e, t = null === (e = Hr()) || void 0 === e ? void 0 : e.blur;
                        t && (ki = (0, v.pi)((0, v.pi)({}, Oi), t))
                    })(), ki && (!ki.debug || (0, Tn.EK)("blur_debug")) && (function() {
                        (0, h.LO)(ki, "Blur must have value");
                        var e = ki.size,
                            t = ki.opacity,
                            n = ".tbl_blur {filter: blur(".concat(e, ");-webkit-filter:blur(").concat(e, ");opacity:").concat(t, ";}");
                        (0, Ri.Q)(n, {
                            id: "tblBlur"
                        })
                    }(), e = [], (null == (t = bi()) ? void 0 : t.length) && (t.forEach((function(t) {
                        if (t.b) {
                            var n = t.r,
                                r = Kr(t),
                                i = "".concat(n, " ").concat(r.r);
                            e = (0, Mr.Au)(document.querySelectorAll(i));
                            var o = t.partial;
                            if (o) {
                                var a = e.filter((function(e, t) {
                                    return o.indexOf(t) > -1
                                }));
                                e = e.concat(a)
                            }
                            e.forEach((function(e) {
                                e.classList.add("tbl_blur")
                            }))
                        }
                    })), Ii = !0), Si || ((0, h.LO)(ki, "Timer blur must have value"), Si = window.setTimeout((function() {
                        if (Li = !0, document.querySelectorAll(".tbl_blur").length > 0) {
                            Ni();
                            var e = "timed out before items were swapped";
                            si(void 0, "blurTimeoutBeforeSwap", e), Pr(e)
                        }
                    }), 1e3 * ki.timeout)))
                })(), t = Hr().nrTimeout, Vo = window.setTimeout((function() {
                    (0, i.o7)("Impression timeout"),
                    function() {
                        var t, n;
                        if (Bo.length > 0) {
                            window._newsroom = window._newsroom || [];
                            var r = {
                                sourceItemType: (0, En.r)(e.L5.optionsSummary.itemSourceType),
                                platform: null === (n = null === (t = null === e.L5 || void 0 === e.L5 ? void 0 : e.L5.responseSummary) || void 0 === t ? void 0 : t.userData) || void 0 === n ? void 0 : n.platform,
                                variant: e.L5.responseSummary.testAndExperiment.testVariantsMap[(0, ai.m_)(oi.S.L2)] || null,
                                hppItems: Bo
                            };
                            window._newsroom.push({
                                sendHppImpression: r
                            }), Bo = [], window.clearTimeout(Vo)
                        }
                    }()
                }), 1e3 * t)
            }))
        }

        function fa(e) {
            e.forEach((function(e) {
                if (!da[e.name]) {
                    var t = function(e) {
                        var t = function(e) {
                            var t = bi();
                            return null == t ? void 0 : t.find((function(t) {
                                return t.p === e
                            }))
                        }(e.name);
                        if (t) return new la(t, e.placements)
                    }(e);
                    t && (da[e.name] = t),
                        function(e) {
                            var t = e.name,
                                n = e.placements,
                                r = Zo(t);
                            if (!zo[r]) {
                                var i, o, a = n[0].hps || [],
                                    u = n.length > 1 ? function(e) {
                                        var t = e[0],
                                            n = t.hpl || t.uip,
                                            r = e.reduce((function(e, t) {
                                                var n, r;
                                                return e + (null !== (r = null === (n = t.hps) || void 0 === n ? void 0 : n.length) && void 0 !== r ? r : 0)
                                            }), 0);
                                        return ra(n, r, e.reduce((function(e, t) {
                                            return e + t.items.length
                                        }), 0))
                                    }(n) : function(e) {
                                        var t, n, r, i;
                                        return ra(e.hpl, null !== (n = null === (t = e.hps) || void 0 === t ? void 0 : t.length) && void 0 !== n ? n : 0, null !== (i = null === (r = e.items) || void 0 === r ? void 0 : r.length) && void 0 !== i ? i : 0)
                                    }(n[0]);
                                i = u, o = a, zo[t] = {
                                    status: "initialized",
                                    data: i,
                                    nonSwappedIndexes: null == o ? void 0 : o.map(Number)
                                }
                            }
                        }(e), (0, b.s)((function() {
                            da[e.name].initRegionSwap()
                        }))
                }
            }))
        }

        function ma(e) {
            var t, n;
            if (0 !== (null === (t = e.hp4uRegions) || void 0 === t ? void 0 : t.length)) {
                if ((0, k.sx)({
                        measuredType: "hp4uFirstResponse",
                        measureLevel: "generalMeasure"
                    }), function() {
                        try {
                            if (ui) return;
                            (0, b.s)(ci)
                        } catch (e) {
                            console.error("Error when sending google analytics event:".concat(e))
                        }
                    }(), n = e.ks, !(0, Tn.EK)("tbl_force_taboola") && n) return Ni(), void e.hp4uRegions.forEach((function(e) {
                    oa(e.name, "killSwitchEnabled", 1)
                }));
                var r, i;
                (0, b.s)((function() {
                    ! function(e) {
                        if (0 !== e.length && !Ti) {
                            var t = [];
                            e.forEach((function(e) {
                                var n = function(e) {
                                    var t, n = "HP ".concat(e.n),
                                        r = Hr().regions,
                                        i = r.find((function(e) {
                                            return n === e.p
                                        }));
                                    if (!i) {
                                        var o = ((t = {}).p = e.n, t.r = e.s, t);
                                        return r.push(o), o
                                    }
                                    if ((0, Oe.o8)(i, "en") && !i.en) return i.en = !0, i
                                }(e);
                                n && t.push(n)
                            })), t.length && (Ti = !0, wi((0, Oe.I8)(t)))
                        }
                    }(e.reg)
                })), ca = e.snz, i = {
                    is_swap: !0
                }, pi[r = "swapVariant"] || ((0, Ae.F)("hp4uEvents", i), pi[r] = !0), fa(e.hp4uRegions)
            }
        }
        var va = !1,
            ha = void 0,
            ga = [];

        function ba(e) {
            var t = ga.filter((function(t) {
                    return t.p === e.hpl
                })),
                n = 1 === t.length ? t[0].url_params : ha;
            e.items.forEach((function(e) {
                e.productClick = 1, n && function(e, t) {
                    if (!(e.clickUrl.indexOf("#") > -1)) {
                        var n = null == t ? void 0 : t.condition;
                        n && e.originalCard[n.trcField] !== n.value || (e.clickUrl = "".concat(e.clickUrl, "#").concat(t.name, "=").concat(t.value))
                    }
                }(e, n)
            }))
        }
        var _a = function() {
            function t() {}
            return t.prototype.getName = function() {
                return "HP4U"
            }, t.prototype.getSupportedFeatures = function() {
                return ["hp4u"]
            }, t.prototype.e6 = function() {
                var t;
                (t = function() {
                    var t = e.L5.config,
                        n = "".concat("hp4u-configuration-").concat(t.publisher.publisherName),
                        r = t.publisher.global[n];
                    if (r) return (0, Oe.I8)(r)
                }()) && (Fr = function(e) {
                    var t;
                    return (0, v.pi)(((t = {}).alternative_domain = !0, t.isSendHppImpression = !1, t.seo_tag_id = "", t.batchSize = 2, t.remove_image_attributes = [], t.cloudinaryTimeout = 500, t.disable_cloudinary = !1, t.fix_ratio = !1, t.additional_tags = [], t.allowed_urls = [], t.maxExItems = 30, t.maxExReq = 5, t.nrTimeout = 4, t), e)
                }(t)), jr() && (e.L5.onResponseSummaryUpdate(ya), pa(), function() {
                    var e = function() {
                        var e, t, n = Hr().ct_selector;
                        return {
                            regions: null === (t = null === (e = Hr()) || void 0 === e ? void 0 : e.regions) || void 0 === t ? void 0 : t.map((function(e) {
                                var t, r = Kr(e),
                                    i = r.r,
                                    o = r.l,
                                    a = "".concat(i, " ").concat(o, ", ").concat(i).concat(o);
                                return (t = {}).n = e.p.substring(2).trim(), t.rs = n || e.r, t.cs = a, t
                            })),
                            taboolaSelectorChecker: "[data-tbl-swap]"
                        }
                    }();
                    (0, Oe.z)(e) || 0 === e.regions.length || (0, b.s)((function() {
                        ! function(e) {
                            new ii(e)
                        }(e)
                    }))
                }())
            }, t.prototype.e9 = function(t) {
                if (jr() && (null == t ? void 0 : t.data)) {
                    var n = function(e) {
                        if (!Ei) return Ci(e.data.r) ? (Ei = !0, {
                            hp4uGetRegions: !0
                        }) : void 0
                    }(t);
                    n && (t.data.ad = (0, Oe.PM)(t.data.ad, n));
                    var r = function() {
                        if (zr || (zr = Hr().maxExItems), Wr || (Wr = Hr().maxExReq), ri !== Wr) return ri++, Hr().ex_preload_key ? (Jr || (Jr = function() {
                            var t, n = [];
                            return null === (t = e.L5.optionsSummary.excludedRecs) || void 0 === t || t.forEach((function(e) {
                                -1 === n.indexOf(e) && ni.length <= zr && n.push(e)
                            })), n
                        }()), Jr) : (Gr || (Gr = Hr().regions.filter((function(e) {
                            return e.ex
                        })).map((function(e) {
                            var t = Kr(e),
                                n = e.r,
                                r = t.r,
                                i = t.l;
                            return {
                                container: n,
                                linkSelector: "".concat(r, " ").concat(i, ", ").concat(r).concat(i),
                                includedIndexes: e.ex
                            }
                        }))), Yr || (Yr = Gr.filter((function(e) {
                            return e.includedIndexes
                        })).reduce((function(e, t) {
                            return e + t.includedIndexes.length
                        }), 0)), Yr === ni.length || Gr.forEach((function(e) {
                            var t = document.querySelector(e.container);
                            t && Array.prototype.slice.call(t.querySelectorAll(e.linkSelector)).reduce((function(e, t) {
                                var n = Dr(t.href);
                                return -1 === e.indexOf(n) && e.push(n), e
                            }), []).forEach((function(t, n) {
                                var r = e.includedIndexes.indexOf(n) > -1,
                                    i = Dr(t),
                                    o = ni.indexOf(i) > -1;
                                o && Yr--, r && !o && ni.length <= zr && ni.push(i)
                            }))
                        })), ni)
                    }();
                    if (r) return t.data.ex = r, {
                        payload: t
                    }
                }
            }, t.prototype.e13 = function(e) {
                var t = e;
                if (t.organicPersonalization) return function(e) {
                    var t, n = Hr();
                    return ha || (ha = n.url_params), ga || (ga = n.regions.filter((function(e) {
                        return e.url_params
                    }))), null === (t = e.organicPersonalization) || void 0 === t || t.hp4uRegions.forEach((function(e) {
                        e.placements.forEach(ba)
                    })), e
                }(t)
            }, t.prototype.e23 = function(t, n) {
                if (("json" === t || "click" === t) && jr()) {
                    var r = function(t, n) {
                        var r = e.L5.config.publisher.global["requests-domain-alternative"] || "hp.taboola.com";
                        if (r) {
                            var i = !1;
                            switch (t) {
                                case "json":
                                    Ci(n.url.data.r) && (i = !0);
                                    break;
                                case "click":
                                    1 === n.url.pc && (i = !0)
                            }
                            return i ? r : void 0
                        }
                    }(t, n);
                    if (r) return {
                        payload: (0, v.pi)((0, v.pi)({}, n), {
                            domain: r
                        })
                    }
                }
            }, t
        }();

        function ya() {
            var t = e.L5.responseSummary.organicPersonalization;
            t && (ma(t), function(e) {
                (0, b.s)((function() {
                    ! function(e) {
                        var t, n, r, i = function(e) {
                                var t = [];
                                return e.hp4uRegions.forEach((function(e) {
                                    e.placements.forEach((function(e) {
                                        e.items.forEach((function(e) {
                                            t.push({
                                                url: Dr(e.clickUrl),
                                                id: e.taboolaId
                                            })
                                        }))
                                    }))
                                })), t
                            }(e),
                            o = ni;
                        0 !== i.length && 0 !== o.length && (t = o, (n = i.reduce((function(e, n) {
                            return t.indexOf(n.url) > -1 && e.push(n), e
                        }), [])).length > 0 && (r = {
                            itemId: n.map((function(e) {
                                return e.id
                            })).join(),
                            type: "ERROR",
                            reason: "dupRate"
                        }, (0, Ze.E6)(r)))
                    }(e)
                }))
            }(t))
        }
        Se(new _a);
        var wa, xa, Ea = [];

        function Ta(e) {
            var t, n = null === (t = a.mb.TRC) || void 0 === t ? void 0 : t.EventsAPI;
            n ? n.listen(e.name, e.handler) : Ea.push(e)
        }! function(e) {
            e.START = "start", e.STOP = "stop", e.MARK = "mark", e.REQ_LEVEL_START = "startReq", e.REQ_LEVEL_STOP = "stopReq"
        }(wa || (wa = {})),
        function(e) {
            e.LOADER_LOADED = "2.0", e.IMPL_LOADED = "4.0"
        }(xa || (xa = {}));
        var Ca = "tbl_".concat(Date.now(), "_"),
            Sa = "",
            Ra = {};

        function ka(e) {
            if ((0, Mt.iH)()) {
                var t = e.now || (0, Mt.a)(),
                    n = e.markType === wa.REQ_LEVEL_START || e.markType === wa.REQ_LEVEL_STOP ? "reqMeasure" : "generalMeasure",
                    o = function(e, t) {
                        if (e || t) return (0, r.Wu)(e || "".concat(t))
                    }(e.modeName, e.placement),
                    a = function(e, t) {
                        return Ca + e + (t ? "_".concat(t) : "")
                    }(e.name, o);
                if (Sa = "".concat(Sa, ";").concat(e.name, "=").concat(t), (0, Mt.BJ)(a), function(e) {
                        e.name === xa.IMPL_LOADED && (e.eventType = "implLoaded", e.markType = wa.MARK)
                    }(e), !e.eventType) return a;
                var u = {
                    measuredType: e.eventType,
                    measureLevel: n,
                    modeName: e.modeName,
                    placement: e.placement,
                    customStartTime: Number(t)
                };
                switch (e.markType) {
                    case wa.REQ_LEVEL_START:
                    case wa.START:
                    case wa.MARK:
                        Ra[o + e.eventType] = (0, k.Xq)(u);
                        break;
                    case wa.STOP:
                    case wa.REQ_LEVEL_STOP:
                        Ra[o + e.eventType] ? Ra[o + e.eventType]() : (0, i.yN)("TRC.mark - trying to stop measurement that was not started ".concat(e.name));
                        break;
                    default:
                        (0, i.yN)("TRC.mark - unrecognized mark type ".concat(e.name))
                }
                return a
            }
        }
        var Ia, La = 0;

        function Oa() {
            null != Ia || (Ia = (0, t.Mv)("enable-social-events")), a.mb.trc && Ia && a.mb.TRC.eventDelegator.subscribe("user_id_ready", Ma)
        }

        function Ma() {
            for (var t, n, r = e.L5.optionsSummary.socials, i = La; i < r.length; i++) {
                var o = r[i];
                a.mb.trc.sendEvent("social", ((t = {}).st = o.name, t["unescape-d"] = encodeURIComponent(JSON.stringify(((n = {}).data = o.data, n))), t), null, !1, null, null)
            }
            La = r.length
        }
        var Na = __webpack_require__(9319),
            Pa = __webpack_require__(8824),
            Da = __webpack_require__(9725),
            Aa = __webpack_require__(891),
            Ua = __webpack_require__(9790),
            Fa = [Aa.W.filterResponse, Ua.h.filterResponse, Na.f.filterResponse, Pa.$.filterResponse, Da.q.filterResponse];

        function qa(e, t) {
            var n = (0, Oe.I8)(t);
            return Fa.forEach((function(t) {
                return t(e, n)
            })), n
        }
        var Va = __webpack_require__(7952);

        function Ba() {
            var n, r, o;

            function u(e) {
                if (e) {
                    var t = r.responseCallback;
                    (0, b.s)((function() {
                        ! function(e, t) {
                            var n = e.originalResponse,
                                r = Wa(n[n.length - 1]);
                            if (r.isMuted) return a.mb.TRC.callbacks.mute();
                            var i = qa(e, r),
                                o = e.cachedViewId;
                            Ha(t, {
                                trc: i,
                                cachedViewId: o,
                                cached: !!o
                            }, !!o)
                        }(e, t)
                    }))
                }
            }
            var c = !1;
            (n = a.mb.TRC).externalLoadRequest || (n.externalLoadRequest = function(n) {
                r = n;
                var s = n.responseCallback,
                    l = n.requestedPlacements,
                    d = (0, t.uL)(l),
                    p = d.found;
                if (d.notFound.forEach((function(e) {
                        return (0, i.yN)('requested placement "'.concat(e, '" from rbox not found in trecs store'))
                    })), 0 !== p.length) {
                    var f;
                    f = a.mb.TRCImpl.preloadRequest, Object.keys(f).forEach((function(e) {
                        var t;
                        ja.push(((t = {})[e] = f[e], t)), delete f[e]
                    }));
                    var m = function(t) {
                            if (za) return {
                                backlogResponseList: [],
                                hasAllPlacementsUsed: !1
                            };
                            za = !0;
                            var n = e.L5.responseSummary,
                                r = n.originalResponse || [];
                            if (0 === r.length) return {
                                backlogResponseList: [],
                                hasAllPlacementsUsed: !1
                            };
                            r = r.map((function(e) {
                                return qa(n, e)
                            }));
                            var i = n.cachedViewId,
                                o = {},
                                a = t.map((function(e) {
                                    var t = e.placementName;
                                    return o[t] = {
                                        responseCounter: -1,
                                        responseFound: !1,
                                        rboxResponseIndex: e.rboxResponsesIndex
                                    }, t
                                })),
                                u = r.filter((function(t) {
                                    var n;
                                    return ! function(e, t) {
                                        var n;
                                        return !!e.isMuted || (null === (n = e.vl) || void 0 === n ? void 0 : n.filter((function(e) {
                                            var n = e.uip,
                                                r = t[n];
                                            if (!r) return !1;
                                            r.responseCounter++;
                                            var i = r.responseCounter,
                                                o = r.rboxResponseIndex;
                                            i > o && za && (za = !1);
                                            var a = i !== o;
                                            return r.responseFound || a
                                        }))).length > 0
                                    }(t, o) && (null === (n = t.vl) || void 0 === n ? void 0 : n.filter((function(t) {
                                        return function(t) {
                                            var n, r = e.L5.optionsSummary.placements.filter((function(e) {
                                                return e.placementName === t
                                            }))[0] || void 0;
                                            return !r || !(!1 !== (null == r ? void 0 : r.byPublisher)) || !!t && a.indexOf(t) > -1 && ((n = o[t]).responseFound || (n.responseFound = !0), !0)
                                        }((0, Va.o)(t))
                                    })))
                                })).map((function(e) {
                                    return {
                                        trc: Wa(e),
                                        cachedViewId: i,
                                        cached: !!i
                                    }
                                })),
                                c = [],
                                s = 0 === Object.keys(o).filter((function(e) {
                                    return !o[e].responseFound || (c.push(e), !1)
                                })).length;
                            return e.Un.updateRboxResponsePlacementIndex(c), {
                                backlogResponseList: u,
                                hasAllPlacementsUsed: s
                            }
                        }(p),
                        v = m.backlogResponseList,
                        h = m.hasAllPlacementsUsed;
                    if (v.forEach((function(e) {
                            (0, b.s)((function() {
                                Ha(s, e, e.cached)
                            }))
                        })), null == o || o(), !h) {
                        a.mb.trc.clearPreloadRequestLoaderAndCallNext();
                        var g = (0, hi.k)(p),
                            _ = g.get();
                        !c && _ && (c = !0, _.then(u)), o = g.on((function(e) {
                            e.then((function(e) {
                                c = !0, u(e)
                            }))
                        }))
                    }
                } else(0, i.yN)('no placements found in the Store for requested placements: "'.concat(l.join(","), '"'))
            })
        }
        var ja = [];

        function Ha(t, n, r) {
            (function(t) {
                var n = [];
                t.trc.vl.forEach((function(e) {
                    var t = (0, Va.o)(e);
                    t && -1 === n.indexOf(t) && n.push(t)
                }));
                var r = {};
                n.forEach((function(e) {
                    var t = function(e) {
                        for (var t = 0; t < ja.length; t++) {
                            var n = ja[t];
                            if (n[e]) return ja.splice(t, 1), n
                        }
                    }(e);
                    t && (r[e] = t[e])
                })), a.mb.TRCImpl.preloadRequest = r, a.mb.TRCImpl.globaleRequestId = e.L5.responseSummary.events.requestId || a.mb.TRC.events_ri || ""
            })(n), t(n, r), (0, Oe.ad)(a.mb.TRCImpl.preloadRequest)
        }
        var za = !1;

        function Wa(e) {
            var t;
            return (0, v.pi)((0, v.pi)({}, e), ((t = {}).jst = [], t.stp = [], t))
        }
        var Ga = function() {
            function e() {
                this.COMMON = Ne._v, this.STYLE = "__style__"
            }
            return e.prototype.inflateObject = function(e, t) {
                return (0, v.pi)((0, v.pi)({}, e), t)
            }, e.prototype.inflateStyle = function(e, t) {
                var n = "";
                return (0, Oe.mt)(t, (function(r) {
                    var i = t[r],
                        o = "";
                    r.split(",").forEach((function(t) {
                        o += "".concat(o ? "," : "", ".").concat(e, " ").concat(t)
                    })), n += "".concat(o, "{").concat(i, "}")
                })), n
            }, e.prototype.inflateModes = function(e) {
                var t = this;
                if (!(0, r.it)(e.modes)) return _.e.resolve();
                var n = e.global,
                    i = e.modes,
                    o = i[Ne._v],
                    a = n.style || {};
                if (n.style = a, !o) return _.e.resolve();
                var u = (0, I.c)("ios"),
                    c = (0, r.td)(n["enable-mode-injection"], !0) && !u,
                    s = (0, k.Xq)({
                        measuredType: "tbl_inflate_start"
                    }),
                    l = {},
                    d = a.rtl || "",
                    p = Object.keys(i).filter((function(e) {
                        return e !== Ne._v
                    })).map((function(e) {
                        var n = i[e];
                        return function() {
                            var r = (0, v.pi)((0, v.pi)({}, o), n);
                            l[e] = r, c ? (r.__style__ = n.__style__ || {}, r.mode_custom = function(e, t) {
                                var n;
                                if (!t) return "";
                                var r = new RegExp("\\/\\*\\ss-split-".concat(e, "\\s\\*\\/[^]*\\*\\se-split-").concat(e, "\\s\\*\\/"), "g");
                                return (null === (n = null == t ? void 0 : t.match(r)) || void 0 === n ? void 0 : n[0]) || ""
                            }(e, a.mode_custom || "")) : d += t.inflateStyle(e, (0, v.pi)((0, v.pi)({}, o.__style__), n.__style__))
                        }
                    })),
                    f = function() {
                        if (0 === p.length) return _.e.resolve();
                        var e = p.splice(0, 10);
                        return (0, b.s)((function() {
                            e.forEach((function(e) {
                                return e()
                            }))
                        })).then(f)
                    };
                return f().then((function() {
                    l[Ne._v] = o, c || (d += a.custom || "", d += a.mode_custom || "", n.style = d), e.modes = l, s()
                }))
            }, e
        }();

        function Ya(e, n, r, i) {
            var o, u, c = a.mb.TRC,
                s = $a || "cdn.taboola.com",
                l = document.getElementsByTagName("script"),
                d = document.createElement("script");
            ! function(e) {
                (0, t.Mv)("enable-crossorigin-anonymous-attribute") && e.setAttribute("crossorigin", "anonymous")
            }(d), l.length && (null === (u = null === (o = l[0]) || void 0 === o ? void 0 : o.parentNode) || void 0 === u || u.insertBefore(d, l[0])), d.charset = "UTF-8", d.type = "text/javascript", n && d.setAttribute("async", "async");
            var p = Ja(r);
            p && d.addEventListener("load", p, !1);
            var f = Ja(i);
            f && d.addEventListener("error", f, !1);
            var m = "".concat(c.PROTOCOL, "//").concat(s, "/libtrc/").concat(e);
            return d.src = c.shiftDomain(m), d
        }

        function Qa(e, t, n) {
            var r = e.split(t),
                i = r.length >= n ? r.slice(n - 1).join(t) : [];
            return r.slice(0, n - 1).concat(i)
        }

        function Ka(e) {
            a.mb.TRC.dispatch("visible::".concat(a.tp.context.data.placement), e), a.mb.TRC.lastVisibleRects = e
        }

        function Ja(e) {
            return "function" == typeof e ? e : Array.isArray(e) ? function(t) {
                e.forEach((function(e) {
                    e(t)
                }))
            } : void 0
        }
        var $a, Xa, Za, eu = __webpack_require__(7983),
            tu = "taboola.com",
            nu = 400,
            ru = "api::trcImplAvailable";

        function iu(n) {
            return Ba(), (0, eu.h)() && (n.style = ""), (0, Tt.k)().then((function() {
                a.mb.TRC.userAgentDataObject = e.L5.config.runtime.userAgentData
            })).then((function() {
                return function(n) {
                    var r = function(e) {
                            var t, n, r = Za.runtime.networkPublisher;
                            r && (a.mb.TRC.publisherId = r);
                            var i = Za.publisher.systemFlags.experimentID.join(",") || void 0;
                            return (0, v.pi)((0, v.pi)({}, Za.publisher), ((t = {
                                global: (0, v.pi)((0, v.pi)((0, v.pi)({}, Za.publisher.global), cu()), (n = {}, n["blocker-list"] = void 0, n["enable-mode-injection"] = !0, n)),
                                systemFlags: (0, v.pi)((0, v.pi)({}, Za.publisher.systemFlags), {
                                    experimentID: i
                                })
                            }).defaults = e, t.modes = Za.publisher.rboxModes, t.rboxModes = (0, y.F)(), t.trcForce = Za.runtime.trcForce, t))
                        }(n),
                        i = function() {
                            var t, n, r, i = e.L5.optionsSummary,
                                o = i.itemSourceType,
                                a = i.itemSourceValue,
                                u = ((t = {
                                    publisher: Za.publisher.publisherName
                                })[o] = a || "auto", t);
                            return u.url || (u.url = Za.runtime.pageUrl.href, u.mapUrl = Za.runtime.networkMapUrl.href), i.deviceId && (u.device = i.deviceId), i.framework && (u.framework = i.framework), i.unifiedId && (u.unified_id = i.unifiedId), i.cex && (u.cex = i.cex), i.customSegment && (u.cseg = i.customSegment), (null === (n = i.ccpa) || void 0 === n ? void 0 : n.privacyString) && (u.ccpaPs = i.ccpa.privacyString), (null === (r = i.ccpa) || void 0 === r ? void 0 : r.CDNS) && (u.cdns = i.ccpa.CDNS), i.referrerUrl && (u.referrer = i.referrerUrl), i.userOptOut && (u.user_opt_out = i.userOptOut), i.excludePubs && (u.exp = i.excludePubs), (0, Oe.z)(i.trackingCodes) || (u.tracking_codes = i.trackingCodes), i.pageTemplate && (u.template = i.pageTemplate), pr() && (u.additional_data = mr()), i.additionalData && (u.additional_data = i.additionalData), i.advertorialSource && (u.advertorial_source = i.advertorialSource), i.externalPageView && (u.external_page_view = i.externalPageView), i.userType && (u.user_type = i.userType), i.paywall && (u.paywall = i.paywall), i.premium && (u.premium = i.premium), i.linkTarget && (u.link_target = i.linkTarget), i.tracking && (u.tracking = i.tracking), u
                        }();
                    ! function(e, t) {
                        var n;
                        e.version = a.mb.TRC.version, null !== (n = e.manualVisibilityTrigger) && void 0 !== n || (e.manualVisibilityTrigger = t.manualVisibilityTrigger)
                    }(r, i);
                    var o = a.mb.TRC;
                    return o.inflate.inflateModes(r).then((function() {
                        return (0, b.s)((function() {
                            (0, t.Mv)("force-reset-on-ready", !1) ? a.mb.TRCImpl = a.mb.trc = new o.Manager(r, i): a.mb.TRCImpl = a.mb.trc || (a.mb.trc = new o.Manager(r, i))
                        }))
                    }))
                }(n)
            })).then((function() {
                return (0, b.s)((function() {
                    var t;
                    Ea.forEach((function(e) {
                        a.mb.TRC.EventsAPI.listen(e.name, e.handler)
                    })), pr() && (50, a.tp.context.observeIntersection((0, r.yL)((function(e) {
                        Ka(e[e.length - 1])
                    }), 50)), (t = e.L5.optionsSummary.__preProcessedOptions__.filter((function(e) {
                        return !(!e.rects && !e.visible || !e.placement)
                    }))[0] || {}).rects && Ka(t.rects));
                    var n = a.mb.TRC;
                    n.trcImplAvailableDispatched || (n.dispatch(ru, {
                        details: void 0
                    }), n.trcImplAvailableDispatched = !0), !uu && a.mb.taboolaBridge && (uu = !0, a.mb.taboolaBridge.on("intersectionChanged", (function(e) {
                        a.mb.TRC.dispatch("visible::".concat(e.placement), e.rects)
                    }))), Oa(), xu()
                }))
            })).then((function() {
                return a.mb.__trcInfo(window.location.href), a.mb.trc
            }))
        }
        var ou, au, uu = !1;

        function cu() {
            var e;
            return (e = {})["enable-trc-cache"] = !1, e["trc-cache-conf"] = void 0, e
        }

        function su(e) {
            if (!Xa || !e || !(0, t.Mv)("enable-shift-cdn-domains")) return e;
            var n = (0, t.Cd)("exclude-subd-shift") || [],
                r = (0, s.u)(e).hostname,
                i = Qa(r, ".", 2),
                o = i[0],
                a = i[1] || o;
            if (a === Xa) return e;
            var u = n.indexOf(r) > -1;
            return a.indexOf(tu) > -1 && !u ? e.replace(a, Xa) : e
        }

        function lu(e, t, n, r, i) {
            a.mb._tblConsole.length > nu && (a.mb._tblConsole = []), a.mb._tblConsole.push({
                service: "RBox",
                tab: e,
                log: {
                    type: t,
                    title: n,
                    infoValue: r,
                    infoType: i || "string",
                    tstmp: (new Date).getTime()
                }
            })
        }

        function du() {
            return void 0 !== ou ? ou : ou = !!window.IntersectionObserver && (0, Ie.Q)(window.IntersectionObserver)
        }

        function pu(e) {
            return !(!(0, t.Cd)("feed-optim") || !(0, t.Cd)("feed-optim")[e])
        }
        var fu, mu, vu = [],
            hu = [],
            gu = 0,
            bu = !1,
            _u = function() {
                function n() {
                    (au = a.mb.TRC).rboxBridgeEnabled = !0
                }
                return n.prototype.getName = function() {
                    return "RboxBridge"
                }, n.prototype.e6 = function(n) {
                    var r, i, o, u, c;
                    Re(n), o = (Za = e.L5.config).publisher, u = o.engineScriptUrlParts, (c = a.mb.TRC).overrideGlobalConfig = e.L5.optionsSummary.__overrideGlobal__, r = u.hostname, ((0, t.Mv)("use-loader-host") || (0, t.Mv)("enable-shift-cdn-domains")) && r && (Xa = Qa($a = "dev.taboola.com" === r ? "cdn.taboola.com" : r, ".", 2).pop()), c.baseDomain = u.host, c.version = Za.runtime.debugQueryParams.tbl_rbox_version || a.mb.TRC.version || (0, Ct.X)(), c.hasES6Support = du, c.inflate = new Ga, c.loadTaboolaScript = Ya, c.shiftDomain = su, c.pConsole = lu, c.ready = iu, c.isOptim = pu, c.imageCounter = 0, c.useStorageDetection = !0, c.trcImplAvailableDispatched = !1, c.PROTOCOL = u.protocol || "https:", c.publisherId = o.publisherName, c.SYNDICATED_CLASS_NAME = "syndicatedItem", c.SPONSORED_CONTAINER_CLASS_NAME = "trc-content-sponsored", c.isAMP = Za.runtime.isAMP, c.PerfEvenType = wa, (i = Za.runtime.dcData) && (a.mb.TRC.taboolaNews = {
                            timeOn: {
                                deviceId: i.deviceId,
                                dc_data: i.content
                            }
                        }),
                        function() {
                            if ((0, Mt.iH)()) {
                                var e = a.mb.TRC;
                                e.performance = {
                                    mark: function(e, t, n, r, i, o) {
                                        return ka({
                                            name: e,
                                            markType: o,
                                            now: t,
                                            placement: r,
                                            eventType: i,
                                            modeName: n
                                        })
                                    },
                                    perfString: Sa
                                }, e.utm.start = (new Date).getTime()
                            }
                        }(), c.loaderUtils = {
                            isNativeFunction: Ie.Q
                        }, c.Fader = function() {
                            return b.s
                        }, c.dom = {
                            isDesktop: function() {
                                return (0, I.c)("desktop")
                            },
                            on: function(e, t, n) {
                                e.addEventListener(t, n)
                            }
                        }, c.util = {
                            debounce: R.Ds
                        }, a.mb.TRCImpl.global = o.global, a.mb.TRCImpl["publisher-logo"] = o["publisher-logo"], fu = n.TABOOLA_STORE.access;
                    var s = n.log;
                    mu = s.warn, pr() && Ta({
                        name: "nocontent",
                        handler: function(e) {
                            var t, n = document.querySelector(".".concat("trc_rbox_container", " .").concat("trc_rbox_div"));
                            ((null == n ? void 0 : n.offsetHeight) || 0) > 10 || e.detail.isFeedCard || null === (t = a.tp.context) || void 0 === t || t.noContentAvailable()
                        }
                    }), fu.onOptionsSummaryUpdated(Eu), fu.onReset(wu), _.e.resolve().then(Eu), ka({
                        name: xa.LOADER_LOADED,
                        now: null,
                        eventType: "loaderLoaded",
                        markType: wa.MARK
                    })
                }, n.prototype.e9 = function(e) {
                    var t, n = e;
                    if (null == n ? void 0 : n.data) {
                        var r = null === (t = au.pageManager) || void 0 === t ? void 0 : t.getValue("past-exclusions");
                        if (r) return n.data.px = r, {
                            payload: n
                        }
                    }
                }, n.prototype.e23 = function(e, t) {
                    var n;
                    if ("perf" === e) {
                        var r = a.mb.TRCImpl.getGlobalRequestId;
                        if (!r) {
                            var i = (0, Mt.Eb)();
                            return mu("rboxBridge: getGlobalRequestId not defined after ".concat(null == i ? void 0 : i.measureTimeToSend)), {
                                payload: void 0
                            }
                        }
                        return {
                            payload: {
                                body: (0, v.pi)((n = {}, n.ri = r(), n.sd = a.mb.TRCImpl.getSessionData(), n), yu())
                            }
                        }
                    }
                }, n
            }();

        function yu() {
            var e, t = null === (e = fu.responseSummary.originalResponse) || void 0 === e ? void 0 : e.evi;
            if (!t) return {};
            var n = {};
            return (0, Oe.mt)(oi.S, (function(e, r) {
                t[r] && (n[(0, ai.m_)(r)] = t[r])
            })), n
        }

        function wu() {
            var e, t, n, r;
            null === (e = au.Timeout) || void 0 === e || e.reset(), null === (t = au.Interval) || void 0 === t || t.reset(), null === (n = a.mb.trc) || void 0 === n || n.reset(), a.mb.TRCImpl = a.mb.trc = (0, y.F)(), null === (r = au.eventDelegator) || void 0 === r || r.resetEvents(), au.pageTemplate = (0, y.F)(), au.pushedRboxTracking = !1, La = 0, gu = 0, bu = !1, hu = []
        }

        function xu() {
            vu.length > 0 && function() {
                var e = a.mb.trc;
                if (e) {
                    var t = [],
                        n = [];
                    vu = vu.filter((function(e) {
                        var r = e.placement;
                        return !(!(0, g.r8)(r) && -1 === t.indexOf(r) && (n.push(e), t.push(r), 1))
                    })), e.loadRBox(n), xu()
                }
            }()
        }

        function Eu() {
            "_default_" !== fu.optionsSummary.itemSourceType && (0, b.s)((function() {
                Tu || (0, hi.k)(), Tu = !0, e.L5.optionsSummary.placements.forEach((function(e) {
                        var t = e.placementName.replace(/ /g, "_");
                        ka({
                            name: "tbl_push_start",
                            now: null,
                            modeName: t,
                            placement: "0",
                            eventType: "tblPush",
                            markType: wa.START
                        }), ka({
                            name: "tbl_push_stop",
                            now: null,
                            modeName: t,
                            placement: "0",
                            eventType: "tblPush",
                            markType: wa.STOP
                        })
                    })),
                    function() {
                        var e, t, n;
                        if (!bu) {
                            var r, i, o, u = fu.optionsSummary;
                            au.cexConsentData = null === (e = u.gdpr) || void 0 === e ? void 0 : e.cex, au.ccpaCdns = null === (t = u.ccpa) || void 0 === t ? void 0 : t.CDNS, au.ccpaPs = null === (n = u.ccpa) || void 0 === n ? void 0 : n.privacyString, au.exp = u.excludePubs, au.cseg = u.customSegment, au.pageTemplate = u.pageTemplate, bu = !0, i = (r = a.mb.TRC).hasES6Support() ? ".js" : ".es5.js", o = r.implCustomFile ? r.implCustomFile + i : "impl.".concat(r.version).concat(i), r.implLoaded ? r.trcReady() : r.loadTaboolaScript(o)
                        }
                    }(), Oa(),
                    function() {
                        for (var e = fu.optionsSummary.events, t = gu; t < e.length; t++) Ta(e[t]);
                        gu = e.length
                    }(), fu.optionsSummary.placements.filter(Ne.vn).forEach(Su), xu()
            }))
        }
        var Tu = !1;

        function Cu(e, t) {
            return t ? (t ? (0, R.Qi)(t) : window.document).querySelector("#".concat(e)) : e
        }

        function Su(e) {
            var n = e.placementName;
            e.instances.forEach((function(r) {
                var i = r.containerId;
                if (0 === r.status && ! function(e, t) {
                        for (var n = 0, r = hu; n < r.length; n++) {
                            var i = r[n];
                            if (i.placementName === e && i.containerId === t) return !0
                        }
                        return !1
                    }(n, i)) {
                    hu.push({
                            placementName: n,
                            containerId: i
                        }),
                        function(e, n) {
                            var r, i = null === (r = (0, t.Cd)("cls-plc-optim-config")) || void 0 === r ? void 0 : r[e];
                            if (i) {
                                var o = i.vhMulti || 1,
                                    a = document.getElementById(n);
                                a && (a.style.minHeight = "".concat(100 * o, "vh"))
                            }
                        }(n, i);
                    var o = function(e, t) {
                        return (0, v.pi)({
                            mode: e.modeName,
                            placement: e.placementName,
                            container: Cu(t, e.frameId),
                            target_type: e.targetType,
                            category: e.category,
                            dfp: e.dfp,
                            exclude: e.exclude,
                            tracking: e.tracking,
                            link_target: e.linkTarget
                        }, function() {
                            var e = fu.optionsSummary;
                            if (e.scod) return {
                                rec: {
                                    trc: e.scod.trcResponse
                                },
                                "rtb-win": e.scod.rtbWin
                            }
                        }())
                    }(e, i);
                    vu.push(o)
                }
            }))
        }
        Se(new _u);
        var Ru, ku, Iu = __webpack_require__(2143),
            Lu = !1,
            Ou = !1,
            Mu = [],
            Nu = function() {
                function t() {}
                return t.prototype.getName = function() {
                    return "RecommendationCacheExtension"
                }, t.prototype.getSupportedFeatures = function() {
                    return ["trcCache"]
                }, t.prototype.unregistered = function() {
                    (0, Iu.lQ)()
                }, t.prototype.e6 = function() {
                    e.L5.onReset(Pu), (Lu = (0, Iu.Ub)()) && (0, Iu.T3)()
                }, t.prototype.e9 = function(e) {
                    if (Lu && !Ou) {
                        if ((0, Iu.CT)()) {
                            var t = (0, Iu.se)(e);
                            return t.response ? (Mu.push.apply(Mu, t.servingReqIdList), {
                                response: t.response,
                                payload: t.payload
                            }) : (Ou = !0, {
                                payload: t.payload
                            })
                        }
                        Ou = !0
                    }
                }, t.prototype.e11 = function(e) {
                    Lu && (0, Iu.hE)(e)
                }, t.prototype.e23 = function(e, t) {
                    if (Lu && function(e) {
                            var t, n = null === (t = e.body) || void 0 === t ? void 0 : t.ri;
                            return Mu.some((function(e) {
                                return n === e
                            }))
                        }(t)) return "available" === e ? {
                        payload: void 0
                    } : "visible" === e ? function() {
                        var e;
                        return {
                            payload: {
                                body: (e = {}, e.cache = 1, e)
                            }
                        }
                    }() : void 0
                }, t
            }();

        function Pu() {
            Ou = !1
        }
        Se(new Nu);
        var Du = "videoreel_loader_script",
            Au = function() {
                function n() {}
                return n.prototype.getName = function() {
                    return "VideoReelMinutelyCrawler"
                }, n.prototype.e6 = function() {
                    (0, t.Mv)("enable-videoreel", !1) && (!(Ru = (0, t.Mv)("vrl-qa-url", !1)) || (0, Tn.EK)("vrl-qa", !0)) && (a.mb.TRC.videoReelContainer = "taboola-video-reel", ku = Ru ? "//qa3-apv.snackly.co" : "//apv-launcher.minute.ly", function() {
                        var t;
                        e.Un.appendPublisherConfig({
                            global: (t = {}, t["prevent-avail-for-removed-widget"] = !0, t)
                        })
                    }(), (0, t.Mv)("vrl-delay-load", !1) ? a.mb.TRC.delayedVrlLoader = Uu : Uu())
                }, n
            }();

        function Uu(e) {
            if (!document.getElementById(Du)) {
                var n = e || (0, t.Cd)("videoreel-script-id");
                if (n) {
                    var r = "".concat(ku, "/api/launcher/MIN-").concat(n, ".js");
                    (0, R._W)(r, {
                        async: !0,
                        id: Du
                    }).catch((function(e) {
                        (0, i.o7)("Failed to inject vrl script:", e)
                    }))
                } else(0, i.o7)("No vrl script id was provided")
            }
        }
        Se(new Au)
    }()
})();
window.__startEngine({
    "modes": {
        "thumbnails-text-under-new": {
            "thumbnail-position": "top",
            "attribution-text": "by Taboola",
            "widget-creator-layout": "autowidget-template-static",
            "responsive-rules": [{
                "minWidth": 0,
                "margin": {
                    "v": 2,
                    "h": 2
                },
                "rows": 1,
                "cells": 1,
                "virtualThumbWidth": 16,
                "virtualThumbHeight": 10
            }],
            "disclosure-link-text-hybrid": "Promoted Links",
            "disclosure-position": "none",
            "__style__": {
                ".video-title": "font-family:Arial, Helvetica, sans-serif;font-size:16.0px;line-height:22.0px;font-weight:600;max-height:88.0px;*height:88.0px;color:#333333;text-decoration:none;margin:0 0 0 0;",
                ".trc_rbox_div": "width:auto;_width:99%;height:410px;border-width:0;padding:0;",
                ".video-label,.sponsored,.sponsored-url": "font-family:'Open Sans', Helvetica, Verdana, sans-serif;",
                ".trc_rbox_header": "font-family:Arial, Helvetica, sans-serif;font-size:100%;font-weight:bold;text-decoration:none;color:#000000;border-width:0;background:transparent;border-style:none;border-color:#D6D5D3;padding:0px 0px 0px 0px;line-height:1.2em;display:block;margin:5px 0px 0px 0px;position:relative;background-color:transparent;box-sizing:initial;height:auto;width:auto;_width:auto;",
                ".videoCube": "width:auto;_width:auto;background-color:transparent;border-width:0px 0px 0px 0px;border-color:#E4E4E4;padding:0px 0px 0px 0px;height:auto;margin-left:0px;margin-top:0px;border-radius:unset;-moz-border-radius:unset;-webkit-border-radius:unset;border-style:SOLID;",
                ".video-label-box": "text-align:left;height:88px;margin:5px 0px 0px 0px;",
                "": "width:auto;_width:auto;border-width:0px 0px 0px 0px;border-style:solid solid solid solid;border-color:#DFDFDF;padding:0px 0px 0px 8px;border-radius:0;-moz-border-radius:0;-webkit-border-radius:0;box-shadow:none;",
                ".syndicatedItem .video-description": "max-height:2.2em;*height:2.2em;color:black;font-family:Arial, Helvetica, sans-serif;font-size:14px;font-weight:normal;line-height:19.0px;text-decoration:none;display:block;",
                ".syndicatedItem .video-title": "max-height:66.0px;*height:66.0px;color:#333333;font-family:'Open Sans', Helvetica, Verdana, sans-serif;font-size:16.0px;line-height:22.0px;font-weight:600 !important;text-decoration:none;padding:0;margin:35px 0px 0px 0px;",
                ".syndicatedItem .branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', Helvetica, Verdana, sans-serif;background-image:null;text-align:left;line-height:22.0px;",
                ".video-label-box.trc-pre-label": "height:0px;",
                ".syndicatedItem .video-label-box.trc-pre-label": "height:0px;",
                ".videoCube .video-label-box.trc-pre-label": "margin:0px 0px 5px 0px;",
                ".branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', Helvetica, Verdana, sans-serif;background-image:null;text-align:left;line-height:22.0px;",
                ".syndicatedItem .video-label-box": "height:88px;margin:5px 0px 0px 0px;",
                ".logoDiv a span": "font-size:12.0px;color:#000000;display:inline;font-weight:normal;",
                ".videoCube .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:underline;",
                ".videoCube:hover .video-label-box .video-description": "text-decoration:underline;",
                ".video-label-box .branding": "display:block;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".thumbBlock_holder": "width:100%;_width:100%;height:auto;margin:0px 0px 0px 0px;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".trc_header_left_column": "height:auto;background-color:transparent;",
                ".trc_header_right_part": "margin:0px 0px 0px 0px;"
            }
        },
        "thumbnails-stream-petite-2": {
            "pending-archive": true,
            "visibility-constraints": {
                "minWidth": null,
                "maxWidth": 767
            },
            "__style__": {
                ".video-title": "font-family:Arial, Helvetica, sans-serif;font-size:18.0px;line-height:24.0px;font-weight:bold;max-height:96.0px;*height:96.0px;color:#000000;text-decoration:none;margin:20px 0px 0px 0px !important;",
                ".videoCube .thumbBlock": "border-width:unset;border-color:#D3D3D3;border-radius:10px;-moz-border-radius:10px;-webkit-border-radius:10px;",
                ".videoCube.syndicatedItem .thumbBlock": "border-color:darkgray;border-width:20px 0px 20px 0px;",
                ".videoCube.thumbnail_start .thumbBlock_holder": "width:110px;_width:110px;height:137px;",
                ".syndicatedItem .video-label-box": "height:auto;margin:0px 0px 0px 0px;",
                ".logoDiv a span": "font-size:11.0px;color:#a8b4c0 !important;display:inline;font-weight:normal;",
                ".videoCube .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:underline;",
                ".videoCube:hover .video-label-box .video-description": "text-decoration:underline;",
                ".video-label-box .branding": "display:block;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".trc_header_left_column": "height:auto;background-color:transparent;",
                ".trc_header_right_part": "margin:0px 0px 0px 0px;"
            }
        },
        "thumbnails-stream-petite-1": {
            "pending-archive": true,
            "visibility-constraints": {
                "minWidth": 744,
                "maxWidth": null
            },
            "__style__": {
                ".syndicatedItem .video-title": "max-height:72.0px;*height:72.0px;color:#000000;font-family:'Open Sans', sans-serif, Arial;font-size:18.0px;line-height:24.0px;font-weight:bold;text-decoration:none;padding:0;margin:20px 0px 0px 0px;",
                ".videoCube.thumbnail_start .thumbBlock_holder": "width:170px;_width:170px;",
                ".branding .logoDiv a span": "color:inherit;font-size:inherit;position:unset;",
                ".syndicatedItem .video-label-box": "height:auto;margin:0px 0px 0px 0px;",
                ".logoDiv a span": "font-size:11.0px;color:#a8b4c0 !important;display:inline;font-weight:normal;",
                ".videoCube .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:underline;",
                ".videoCube:hover .video-label-box .video-description": "text-decoration:underline;",
                ".video-label-box .branding": "display:block;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".trc_header_left_column": "height:auto;background-color:transparent;",
                ".trc_header_right_part": "margin:0px 0px 0px 0px;"
            }
        },
        "thumbnails-stream-grande-1": {
            "visibility-constraints": {
                "minWidth": 500,
                "maxWidth": null
            },
            "__style__": {
                ".syndicatedItem .video-title": "max-height:72.0px;*height:72.0px;color:#000000;font-family:'Open Sans', sans-serif, Arial;font-size:18.0px;line-height:24.0px;font-weight:bold;text-decoration:none;padding:0;margin:30px 0px 0px 0px;",
                ".videoCube.thumbnail_start .thumbBlock_holder": "width:310px;_width:310px;",
                ".branding .logoDiv a span": "color:inherit;font-size:inherit;position:unset;",
                ".syndicatedItem .video-label-box": "height:auto;margin:0px 0px 0px 0px;",
                ".logoDiv a span": "font-size:11.0px;color:#a8b4c0 !important;display:inline;font-weight:normal;",
                ".videoCube .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:underline;",
                ".videoCube:hover .video-label-box .video-description": "text-decoration:underline;",
                ".video-label-box .branding": "display:block;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".trc_header_left_column": "height:auto;background-color:transparent;",
                ".trc_header_right_part": "margin:0px 0px 0px 0px;"
            }
        },
        "thumbnails-stream-d": {
            "detail-order": "title,description",
            "detail-order-syndicated": "title,description,branding",
            "disclosure-position": "none",
            "storyWidget-story-num-title-lines": 0,
            "recommendationReel-num-title-lines": 3,
            "__style__": {
                ".video-title": "font-family:Arial, Helvetica, sans-serif;font-size:16.0px;line-height:22.0px;font-weight:600 !important;max-height:88.0px;*height:88.0px;color:#000000;text-decoration:none;margin:0 0 0 0;",
                ".video-description": "font-family:Arial, Helvetica, sans-serif;font-size:14.0px;line-height:19.0px;font-weight:normal;max-height:38.0px;*height:38.0px;color:black;text-decoration:none;",
                ".trc_rbox_div": "width:auto;_width:99%;height:410px;border-width:0;padding:0;margin:0px 0px -29px 0px;",
                ".video-label,.sponsored,.sponsored-url": "font-family:'Open Sans', Helvetica, Verdana, sans-serif;",
                ".videoCube": "width:auto;_width:auto;background-color:transparent;border-width:0px 0px 0px 0px;border-color:#E4E4E4;padding:0px 0px 0px 0px;height:auto;margin-left:0px;margin-top:0px;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;border-style:SOLID;margin:0 0 10px 0;",
                ".videoCube .thumbBlock": "border-width:0px;border-color:darkgray;border-radius:5px;-moz-border-radius:5px;-webkit-border-radius:5px;",
                "": "width:300px;_width:300px;border-width:1px 1px 1px 1px;border-style:none;border-color:#DFDFDF;padding:0px 0px 0px 0px;border-radius:10px;-moz-border-radius:10px;-webkit-border-radius:10px;box-shadow:none;",
                ".syndicatedItem .video-description": "max-height:38.0px;*height:38.0px;color:black;font-family:Arial, Helvetica, sans-serif;font-size:14.0px;font-weight:normal;line-height:19.0px;text-decoration:none;",
                ".syndicatedItem .video-title": "max-height:52.0px;*height:52.0px;color:#000000;font-family:'Open Sans', Helvetica, Verdana, sans-serif;font-size:16.0px;line-height:26.0px;font-weight:bold;text-decoration:none;padding:0;",
                ".syndicatedItem .branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', Helvetica, Verdana, sans-serif;background-image:null;text-align:left;line-height:22.0px;",
                ".branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', Helvetica, Verdana, sans-serif;background-image:null;text-align:left;line-height:26.0px;",
                ".syndicatedItem .video-label-box": "height:auto;margin:0px 0px 0px 0px;",
                ".logoDiv a span": "font-size:11.0px;color:#a8b4c0 !important;display:inline;font-weight:normal;top:unset;",
                ".videoCube .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-description": "text-decoration:underline;",
                ".video-label-box .branding": "display:block;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".trc_rbox_header_span .trc_header_right_column": "background:transparent;height:auto;",
                ".trc_header_left_column": "height:auto;background-color:transparent;",
                ".trc_header_right_part": "margin:0px 0px 0px 0px;"
            }
        },
        "thumbnails-stream-bordure-2": {
            "visibility-constraints": {
                "minWidth": null,
                "maxWidth": 767
            },
            "__style__": {
                ".video-title": "font-family:Arial, Helvetica, sans-serif;font-size:18.0px;line-height:24.0px;font-weight:bold;max-height:96.0px;*height:96.0px;color:#000000;text-decoration:none;margin:30px 0px 0px 0px !important;",
                ".videoCube .thumbBlock": "border-width:unset;border-color:#D3D3D3;border-radius:10px;-moz-border-radius:10px;-webkit-border-radius:10px;",
                ".videoCube.syndicatedItem .thumbBlock": "border-color:darkgray;border-width:30px 0px 50px 0px;",
                ".videoCube.thumbnail_start .thumbBlock_holder": "width:240px;_width:240px;height:192px;",
                ".syndicatedItem .video-label-box": "height:auto;margin:0px 0px 0px 0px;",
                ".logoDiv a span": "font-size:11.0px;color:#a8b4c0 !important;display:inline;font-weight:normal;",
                ".videoCube .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:underline;",
                ".videoCube:hover .video-label-box .video-description": "text-decoration:underline;",
                ".video-label-box .branding": "display:block;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".trc_header_left_column": "height:auto;background-color:transparent;",
                ".trc_header_right_part": "margin:0px 0px 0px 0px;"
            }
        },
        "thumbnails-stream-bordure-1": {
            "visibility-constraints": {
                "minWidth": 600,
                "maxWidth": null
            },
            "__style__": {
                ".syndicatedItem .video-title": "max-height:72.0px;*height:72.0px;color:#000000;font-family:'Open Sans', sans-serif, Arial;font-size:18.0px;line-height:24.0px;font-weight:bold;text-decoration:none;padding:0;margin:35px 0px 0px 0px;",
                ".videoCube.thumbnail_start .thumbBlock_holder": "width:240px;_width:240px;",
                ".branding .logoDiv a span": "color:inherit;font-size:inherit;position:unset;",
                ".syndicatedItem .video-label-box": "height:auto;margin:0px 0px 0px 0px;",
                ".logoDiv a span": "font-size:11.0px;color:#a8b4c0 !important;display:inline;font-weight:normal;",
                ".videoCube .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:underline;",
                ".videoCube:hover .video-label-box .video-description": "text-decoration:underline;",
                ".video-label-box .branding": "display:block;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".trc_header_left_column": "height:auto;background-color:transparent;",
                ".trc_header_right_part": "margin:0px 0px 0px 0px;"
            }
        },
        "thumbnails-grande-2": {
            "thumbnail-position": "top",
            "widget-creator-layout": "autowidget-template-static",
            "responsive-rules": [{
                "minWidth": 0,
                "margin": {
                    "v": 2,
                    "h": 2
                },
                "rows": 1,
                "cells": 1,
                "virtualThumbWidth": 3,
                "virtualThumbHeight": 2
            }],
            "visibility-constraints": {
                "minWidth": null,
                "maxWidth": 768
            },
            "__style__": {
                ".video-title": "font-family:Arial, Helvetica, sans-serif;font-size:16.0px;line-height:22.0px;font-weight:bold;max-height:88.0px;*height:88.0px;color:#333333;text-decoration:none;margin:0 0 0 0;",
                ".trc_rbox_div": "width:auto;_width:99%;height:410px;border-width:0;padding:0;",
                ".videoCube .thumbBlock": "border-width:0px;border-color:darkgray;border-radius:10px;-moz-border-radius:10px;-webkit-border-radius:10px;height:auto;",
                ".video-label-box": "text-align:left;height:88px;margin:5px 0px 0px 0px;",
                ".syndicatedItem .video-title": "max-height:66.0px;*height:66.0px;color:#333333;font-family:'Open Sans', sans-serif, Arial;font-size:16.0px;line-height:22.0px;font-weight:bold;text-decoration:none;padding:0;margin:40px 0px 0px 0px;",
                ".syndicatedItem .branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', sans-serif, Arial;background-image:null;text-align:left;line-height:22.0px;",
                ".video-label-box.trc-pre-label": "height:0px;",
                ".syndicatedItem .video-label-box.trc-pre-label": "height:0px;",
                ".videoCube .video-label-box.trc-pre-label": "margin:0px 0px 5px 0px;",
                ".branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', sans-serif, Arial;background-image:null;text-align:left;line-height:22.0px;",
                ".syndicatedItem .video-label-box": "height:88px;margin:5px 0px 0px 0px;",
                ".logoDiv a span": "font-size:11.0px;color:#a8b4c0;display:inline;font-weight:normal;",
                ".videoCube .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:underline;",
                ".videoCube:hover .video-label-box .video-description": "text-decoration:underline;",
                ".video-label-box .branding": "display:block;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".thumbBlock_holder": "height:300px;",
                ".trc_header_left_column": "height:auto;background-color:transparent;",
                ".trc_header_right_part": "margin:0px 0px 0px 0px;"
            }
        },
        "thumbnails-f": {
            "header": "A Décovrir Aussi",
            "attribution-position": "top",
            "widget-creator-revision": "10672891",
            "responsive-rules": [{
                "minWidth": 0,
                "margin": {
                    "v": 2,
                    "h": 2
                },
                "rows": 1,
                "cells": 2,
                "virtualThumbWidth": 7,
                "virtualThumbHeight": 5
            }],
            "disclosure-link-text-sponsored": "Contenus sponsorisés",
            "disclosure-link-text-hybrid": "Promoted Links",
            "disclosure-position": "top",
            "read-more-mode-devices": "",
            "branding-separator": "|",
            "recommendationReel-num-title-lines": 3,
            "__style__": {
                ".video-title": "font-family:Arial, Helvetica, sans-serif;font-size:14.0px;line-height:19.0px;font-weight:bold;max-height:38.0px;*height:38.0px;color:#1D50B4;text-decoration:none;",
                ".video-description": "font-family:Arial, Helvetica, sans-serif;font-size:10px;line-height:11px;font-weight:normal;max-height:2.2em;*height:2.2em;color:black;text-decoration:none;",
                ".trc_rbox_div": "width:auto;_width:99%;height:410px;border-width:0;padding:0;margin:0 0 0 0;",
                ".video-label,.sponsored,.sponsored-url": "font-family:Arial, Helvetica, sans-serif;",
                ".trc_rbox_header": "font-family:Verdana, Geneva, sans-serif;font-size:15.0px;font-weight:bold;text-decoration:none;color:#F36C2A;border-width:0;background:transparent;border-style:none;border-color:#D6D5D3;padding:0 0 0 0;line-height:1.2em;display:inline-block;position:relative;height:auto;width:100%;_width:100%;",
                ".videoCube": "width:auto;_width:auto;background-color:transparent;border-width:1px;border-color:#D6D5D3;padding:0;height:auto;margin-left:0px;margin-top:0px;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;border-style:none;margin:0 0 10px 0;",
                ".videoCube .thumbBlock": "border-width:0px;border-color:darkgray;",
                ".video-label-box": "text-align:left;",
                ".videoCube.syndicatedItem": "background-color:transparent;border-color:#D6D5D3;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;border-width:1px;border-style:none;",
                ".videoCube.syndicatedItem .video-label-box": "margin-left:0px;",
                ".syndicatedItem .video-description": "max-height:2.2em;*height:2.2em;color:black;font-family:Arial, Helvetica, sans-serif;font-size:10px;font-weight:normal;line-height:11px;text-decoration:none;",
                ".syndicatedItem .video-title": "max-height:38.0px;*height:38.0px;color:#1D50B4;font-family:Arial, Helvetica, sans-serif;font-size:14.0px;line-height:19.0px;font-weight:bold;text-decoration:none;padding:0;",
                ".syndicatedItem .branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:Arial, Helvetica, sans-serif;background-image:null;text-align:left;line-height:19.0px;",
                ".videoCube .video-label-box.trc-pre-label": "margin:0;",
                ".branding": "color:black;font-size:10px;font-weight:normal;text-decoration:none;font-family:Arial, Helvetica, sans-serif;background-image:null;text-align:left;",
                ".logoDiv a span": "font-size:11.0px;color:#000000;display:inline;font-weight:normal;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:underline;",
                ".videoCube .video-label-box .video-title": "margin:0 0 0 0;",
                ".video-label-box .branding": "display:block;",
                ".trc_header_left_column": "width:48%;_width:48%;display:inline-block;height:auto;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0 0 0 0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".trc_rbox_header_span .trc_header_right_column": "height:auto;"
            }
        },
        "thumbnails-4": {
            "thumbnail-position": "top",
            "attribution-text": "by Taboola",
            "widget-creator-layout": "autowidget-template-static",
            "responsive-rules": [{
                "minWidth": 0,
                "margin": {
                    "v": 2,
                    "h": 2
                },
                "rows": 1,
                "cells": 1,
                "virtualThumbWidth": 3,
                "virtualThumbHeight": 2
            }],
            "disclosure-link-text-hybrid": "Promoted Links",
            "__style__": {
                ".video-title": "font-family:Arial, Helvetica, sans-serif;font-size:16.0px;line-height:22.0px;font-weight:600 !important;max-height:88.0px;*height:88.0px;color:#333333;text-decoration:none;margin:0 0 0 0;",
                ".trc_rbox_div": "width:auto;_width:99%;height:410px;border-width:0;padding:0;",
                ".video-label,.sponsored,.sponsored-url": "font-family:'Open Sans', Helvetica, Verdana, sans-serif;",
                ".trc_rbox_header": "font-family:Arial, Helvetica, sans-serif;font-size:100%;font-weight:bold;text-decoration:none;color:#000000;border-width:0;background:transparent;border-style:none;border-color:#D6D5D3;padding:0px 0px 0px 0px;line-height:1.2em;display:block;margin:5px 0px 0px 0px;position:relative;background-color:transparent;box-sizing:initial;height:auto;width:auto;_width:auto;",
                ".videoCube": "width:auto;_width:auto;background-color:transparent;border-width:0px 0px 0px 0px;border-color:#E4E4E4;padding:0px 0px 0px 0px;height:auto;margin-left:0px;margin-top:0px;border-radius:unset;-moz-border-radius:unset;-webkit-border-radius:unset;border-style:SOLID;",
                ".video-label-box": "text-align:left;height:88px;margin:5px 0px 0px 0px;",
                "": "width:auto;_width:auto;border-width:0px 0px 0px 0px;border-style:solid solid solid solid;border-color:#DFDFDF;padding:0px 0px 0px 0px;border-radius:0;-moz-border-radius:0;-webkit-border-radius:0;box-shadow:none;",
                ".syndicatedItem .video-title": "max-height:66.0px;*height:66.0px;color:#333333;font-family:'Open Sans', Helvetica, Verdana, sans-serif;font-size:16.0px;line-height:22.0px;font-weight:bold;text-decoration:none;padding:0;",
                ".syndicatedItem .branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', Helvetica, Verdana, sans-serif;background-image:null;text-align:left;line-height:22.0px;",
                ".videoCube.syndicatedItem .thumbBlock .branding": "text-align:left;background-color:transparent;display:block;left:0px;color:black;font-size:10px;font-weight:normal;text-decoration:none;font-family:Arial, Helvetica, sans-serif;background-image:null;",
                ".video-label-box.trc-pre-label": "height:0px;",
                ".syndicatedItem .video-label-box.trc-pre-label": "height:0px;",
                ".videoCube .video-label-box.trc-pre-label": "margin:0px 0px 5px 0px;",
                ".branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', Helvetica, Verdana, sans-serif;background-image:null;text-align:left;line-height:22.0px;",
                ".syndicatedItem .video-label-box": "height:88px;margin:5px 0px 0px 0px;",
                ".logoDiv a span": "font-size:12.0px;color:#a8b4c0 !important;display:inline;font-weight:normal;",
                ".videoCube .video-label-box .video-title": "text-decoration:none;",
                ".videoCube:hover .video-label-box .video-title": "text-decoration:underline;",
                ".videoCube:hover .video-label-box .video-description": "text-decoration:underline;",
                ".video-label-box .branding": "display:block;",
                ".trc_rbox_header .trc_header_ext": "position:relative;top:auto;right:auto;",
                ".thumbBlock_holder": "width:100%;_width:100%;height:166px;margin:30px 0px 0px 0px;",
                ".logoDiv a": "font-size:100%;",
                ".videoCube a": "padding:0;",
                ".trc_rbox_header .logoDiv": "line-height:normal;",
                ".trc_header_left_column": "height:auto;background-color:transparent;",
                ".trc_header_right_part": "margin:0px 0px 0px 0px;"
            }
        },
        "rbox-blended": {
            "header": "Videos",
            "orientation": "vertical",
            "navigation-type": "scrolling",
            "thumbnail-width": "75",
            "thumbnail-height": "55",
            "detail-order": "title,description",
            "attribution-text": "<span>by<span style=\"font-size:12px;\">Taboola</span></span>",
            "detail-order-syndicated": "branding,title",
            "syndicated-static-text": "Sponsored",
            "auto-size-rules": [{
                "minWc": 120,
                "maxWc": 249,
                "minWsRange": 8,
                "maxWsRange": 8,
                "n": 1
            }, {
                "minWc": 250,
                "maxWc": 379,
                "minWsRange": 8,
                "maxWsRange": 9,
                "n": 2
            }, {
                "minWc": 380,
                "maxWc": 609,
                "minWsRange": 8,
                "maxWsRange": 10,
                "n": 3
            }, {
                "minWc": 610,
                "maxWc": 749,
                "minWsRange": 8,
                "maxWsRange": 11,
                "n": 4
            }, {
                "minWc": 750,
                "maxWc": 1029,
                "minWsRange": 7,
                "maxWsRange": 11,
                "n": 5
            }, {
                "minWc": 1030,
                "maxWc": 1419,
                "minWsRange": 6,
                "maxWsRange": 11,
                "n": 6
            }, {
                "minWc": 1420,
                "maxWc": 1729,
                "minWsRange": 6,
                "maxWsRange": 12,
                "n": 7
            }, {
                "minWc": 1730,
                "maxWc": 1920,
                "minWsRange": 6,
                "maxWsRange": 13,
                "n": 8
            }],
            "rows": 1,
            "widget-creator-layout": "autowidget-template",
            "mode-is-responsive": false,
            "responsive-rules": null,
            "use-css-important": false,
            "disclosure-link-text-sponsored": "Sponsored Links",
            "disclosure-link-text-hybrid": "Promoted Links",
            "disclosure-position": "top",
            "read-more-mode-devices": "",
            "branding-separator": "|",
            "recommendationReel-num-title-lines": 3,
            "__style__": {
                ".video-title": "font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:17.5px;font-weight:bold;max-height:2.58em;*height:2.58em;color:black;text-decoration:none;",
                ".video-description": "font-family:Arial, Helvetica, sans-serif;font-size:10px;line-height:11px;font-weight:normal;max-height:2.2em;*height:2.2em;color:black;text-decoration:none;",
                ".trc_rbox_div": "width:auto;_width:99%;height:410px;border-width:1px;padding:0;",
                ".videoCube .video-duration": "left:36px;display:block;",
                ".videoCube .video-label-box": "margin-left:81px;margin-right:0px;",
                ".video-label,.sponsored,.sponsored-url": "font-family:Arial, Helvetica, sans-serif;",
                ".trc_rbox_header": "font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:bold;text-decoration:none;color:black;border-width:0;background:transparent;border-style:none none solid none;border-color:#D6D5D3;padding:0;",
                ".videoCube": "width:auto;_width:auto;background-color:transparent;border-width:1px;border-color:#D6D5D3;padding:3px;height:auto;margin-left:0px;margin-top:0px;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;border-style:none;",
                ".videoCube .thumbBlock": "border-width:0px;border-color:darkgray;",
                ".video-label-box": "text-align:left;",
                "": "width:300px;_width:300px;border-width:0px;border-style:solid solid solid solid;border-color:#000000;padding:0;border-radius:0;-moz-border-radius:0;-webkit-border-radius:0;box-shadow:none;",
                ".videoCube.horizontal": "border-style:none none none solid;",
                ".videoCube.syndicatedItem": "background-color:transparent;border-color:#D6D5D3;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;border-width:1px;border-style:none;",
                ".videoCube.syndicatedItem.horizontal": "border-style:none none none solid;",
                ".videoCube.syndicatedItem .video-duration": "display:block;left:36px;",
                ".videoCube.syndicatedItem .video-label-box": "margin-left:0px;",
                ".syndicatedItem .video-description": "max-height:2.2em;*height:2.2em;color:black;font-family:Arial, Helvetica, sans-serif;font-size:10px;font-weight:normal;line-height:11px;text-decoration:none;",
                ".syndicatedItem .video-title": "max-height:2.58em;*height:2.58em;color:black;font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:17.5px;font-weight:bold;text-decoration:none;padding:0;",
                ".syndicatedItem .branding": "color:black;font-size:10px;font-weight:normal;text-decoration:none;font-family:Arial, Helvetica, sans-serif;background-image:null;text-align:left;",
                ".videoCube.syndicatedItem .thumbBlock .branding": "text-align:left;background-color:transparent;display:block;left:0px;color:black;font-size:10px;font-weight:normal;text-decoration:none;font-family:Arial, Helvetica, sans-serif;background-image:null;",
                ".videoCube.syndicatedItem .thumbBlock .static-text": "text-align:left;background-color:black;display:block;color:white;font-size:10px;font-weight:normal;text-decoration:none;font-family:Arial, Helvetica, sans-serif;",
                ".videoCube .video-label-box.trc-pre-label": "margin:0;",
                ".branding": "color:black;font-size:10px;font-weight:normal;text-decoration:none;font-family:Arial, Helvetica, sans-serif;background-image:null;text-align:left;"
            }
        },
        "__common__": {
            "syndicated-attribution-tooltip": "",
            "expand-animation-duration": 1000,
            "loading-animation-url": "hide",
            "pager-style-active-image": "",
            "recommendationReel-is-min-adx": false,
            "vignette-openButtonFontFamily": "",
            "player-detail-order": "title,description",
            "slider-scroll-ref-element": function() {
                return window;
            },
            "slider-close-btn-color": "#FFF",
            "slider-slide-from": "bottom",
            "shade-scroll": false,
            "pager-button-inactive-image": "",
            "has-thumbs-image-lazy-load": false,
            "visibility-constraints": {},
            "responsive-rules": [{
                "minWidth": 0,
                "margin": {
                    "v": 2,
                    "h": 2
                },
                "rows": 1,
                "cells": 1,
                "virtualThumbWidth": 7,
                "virtualThumbHeight": 5
            }],
            "format-description": '%s',
            "vignette-xButtonSize": "",
            "format-x-days-ago": false,
            "gam-allow-trc-ads": false,
            "player-container-id": "trc_Embed_Container_Id",
            "image-min-width": 100,
            "organic-static-text-position": "bottom-left",
            "before-detail-order": "",
            "slider-close-btn-font-size": "30px",
            "read-more-box-selector": "",
            "widget-creator-layout": "autowidget-template-stream",
            "format-external-data": '%s',
            "player-thumbnail-height": "200",
            "emblem-position": "top-left",
            "header-right": "No Header",
            "gif-url-prefix": null,
            "slider-close-btn-size": "24px",
            "ctaWidget": true,
            "vignette-xButtonBackgroundColor": "",
            "recommendationReel-interval": 7,
            "vignette-openButtonText": "",
            "storyWidget-storyWidget-story-num-title-lines": 3,
            "branding-separator": "",
            "format-duration": '%s',
            "after-visible": function(data) {},
            "vignette-closeButtonBackgroundColor": "",
            "enable-prioritized-layout": false,
            "rtb-image-url-prefix": null,
            "header-icon": "NONE",
            "image-dpr-factor": 2,
            "vignette-closeButtonFontColor": "",
            "item-renderer": function(box, data) {
                if (typeof window.trc_itemRenderer == 'function') window.trc_itemRenderer(document.createElement('div'), data, false);
            },
            "read-more-minimized-size": 800,
            "use-browser-line-clamp": true,
            "slider": false,
            "item-data-filter": function(data) {},
            "vignette-openButtonBackgroundColor": "",
            "vignette-backgroundOpacity": 0.8,
            "auto-advance": "-1",
            "recommendationReel-wait-for-video-demand": false,
            "image-min-dimension": 100,
            "auto-scroll": "none",
            "recommendationReel-num-title-lines": 0,
            "format-category": '%s',
            "auto-advance-animation": "down",
            "format-syndicator": function(s) {
                return s;
            },
            "vignette-xButtonPosition": "",
            "slider-transition-delay": 200,
            "popup-custom-url": "",
            "mode-start": function(data) {},
            "storyWidget": false,
            "recommendationReel-slider-below-only": false,
            "adchoice-position": "none",
            "disclosure-link-text-sponsored": "Sponsorisé",
            "mode-has-userx": true,
            "slider-background-color": "#666",
            "image-size-round": 20,
            "detail-order-ad": "title",
            "style-template": "Light",
            "thumbnail-width": "6",
            "min-width-for-disclosure": 225,
            "detail-order": "title",
            "image-max-dimension": 1500,
            "format-published-date": function(d) {
                return this.dateFormatISO(d, false);
            },
            "mode-is-responsive": true,
            "expandable": false,
            "remove-url-playvideo-behavior": false,
            "expand-animation-max-height": 1000,
            "responsive-extra-columns": 1,
            "title": "Related Videos",
            "published-date-position": "standalone",
            "header-icon-url": "",
            "thumbnail-position-ad": "inherit",
            "format-title": '%s',
            "vignette-closeButtonFontSize": "",
            "widget-creator-revision": "-1",
            "hide-attribution-when-no-place": false,
            "pager-type-style": "numbers",
            "impl-class": "TRCRBox",
            "vignette-closeButtonText": "",
            "has-expand-animation": false,
            "disclosure-link-text-organic": "",
            "recommendationReel-slider-start-from-slider": false,
            "syndicated-attribution": "",
            "image-lazy-load-space": 200,
            "sponsored-location": "top",
            "recommendationReel-min-adx-cta-text": "To article &amp; full video",
            "organic-static-text": "MOST POPULAR",
            "icons": false,
            "thumbnail-position": "start",
            "format-views": function(n) {
                return 'Views: ' + this.formatNumber(n, false);
            },
            "read-more-mode-devices": "smart_phone",
            "storyWidget-story-num-title-lines": 3,
            "vignette-buttonsTopSpacing": "",
            "recommendationReel-slider-text-under-slide-in-only": true,
            "image-url-prefix": null,
            "read-more-cutoff-length-from-anchor-element": 30,
            "syndicated-static-text": "",
            "required-attributes": "none",
            "change-url": function(url) {
                return url;
            },
            "syndicated-static-text-position": "top-right",
            "pager-button-location": "pager",
            "nextUpWidget-static-ui": false,
            "recommendationReel-enable-text-under-slide-in": false,
            "recommendationReel-slide-below-first-item-only": false,
            "mode-adc-config": null,
            "details-inline-with-title": "",
            "thumbnail-height": "5",
            "vignette-xButtonColor": "",
            "auto-size": false,
            "vignette-screenBackgroundColor": "",
            "disclosure-alignment": "left",
            "adchoice-large": false,
            "layout-template": "Horizontal 4",
            "vignette-xButtonShow": true,
            "mode-enable-feed-view": false,
            "storyWidget-story-interval": 7,
            "ios-sc-link-target-mode": null,
            "read-more-config": null,
            "thumbs-image-lazy-load-margins": "600px 1500px",
            "recommendationReel-slider-navigation-text": "Read more",
            "read-more-caption": "",
            "template": "Default",
            "pager-position": "start",
            "format-uploader": 'User: %s',
            "vignette-closeButtonFontFamily": "",
            "disclosure-position": "after_branding",
            "image-size-factor": 1.2,
            "title-icon": "NONE",
            "lightbox-display-title": true,
            "has-image-lazy-load": false,
            "navigation-type": "none",
            "vignette-openButtonHoverColor": "",
            "cyclical-paging": false,
            "tokenize-strategy": "word",
            "adchoice-target-url": "",
            "vignette-backgroundColor": "#fff",
            "disclosure-link-text-hybrid": "Contenus Sélectionnés",
            "vignette-closeButtonPadding": "",
            "recommendationReel-slider-position": "bottom",
            "pager-button-active-image": "",
            "player-thumbnail-width": "75",
            "enable-category-card": false,
            "color-scheme": "White",
            "slider-z-index": 2500000,
            "slider-transition-duration": 600,
            "use-css-important": true,
            "smart-ellipsis": false,
            "storyWidget-storyWidget-story-interval": 7,
            "pager-button-hover-image": "",
            "vignette-openButtonPadding": "",
            "render-player-info": false,
            "recommendationReel-enable-slider": false,
            "mode-has-adchoice": true,
            "player-embed-code": function() {
                return '';
            },
            "image-allowed-ratio-diff": 0.029,
            "use-cdn-recommendations": false,
            "list-size": 10,
            "enable-read-more": false,
            "auto-size-rules": [{
                "minWc": 120,
                "maxWc": 349,
                "minWsRange": 8,
                "maxWsRange": 8,
                "n": 1
            }, {
                "minWc": 350,
                "maxWc": 499,
                "minWsRange": 8,
                "maxWsRange": 9,
                "n": 2
            }, {
                "minWc": 500,
                "maxWc": 749,
                "minWsRange": 8,
                "maxWsRange": 10,
                "n": 3
            }, {
                "minWc": 750,
                "maxWc": 999,
                "minWsRange": 8,
                "maxWsRange": 11,
                "n": 4
            }, {
                "minWc": 1000,
                "maxWc": 1249,
                "minWsRange": 7,
                "maxWsRange": 11,
                "n": 5
            }, {
                "minWc": 1250,
                "maxWc": 1499,
                "minWsRange": 6,
                "maxWsRange": 11,
                "n": 6
            }, {
                "minWc": 1500,
                "maxWc": 1749,
                "minWsRange": 6,
                "maxWsRange": 12,
                "n": 7
            }, {
                "minWc": 1750,
                "maxWc": 1920,
                "minWsRange": 6,
                "maxWsRange": 13,
                "n": 8
            }],
            "carousel-min-items": 1.33,
            "p-video-overlay": false,
            "attribution-text": "par Taboola",
            "storyWidget-recommendation-reel-enable-text-under-slide-in": false,
            "format": {
                'views': 'Views: %s',
                'uploader': 'By: %s',
                'duration': 'Duration: %s',
                'rating': 'Rating: %s'
            },
            "auto-syndicated-attribution": true,
            "pager-style-hover-image": "",
            "syndicated-attribution-position": "bottom-right",
            "attribution-position": "bottom",
            "pager-style-inactive-image": "",
            "min-width-for-attribution": 325,
            "header": "No Header",
            "read-more-cutoff-length-type": "BELOW",
            "tabbed": false,
            "read-more-threshold": 1100,
            "recommendationReel": false,
            "format-number": function(num) {
                var out = "",
                    m;
                while (num.length > 3 && (m = num.match(/\d{3}\s*$/))) {
                    out = m.toString().replace(/\s+/, "") + "," + out;
                    num = num.replace(/\d{3}\s*$/, "", false);
                }
                out = num + "," + out;
                return out.replace(/,$/, "");
            },
            "vignette-openButtonFontSize": "",
            "vignette-screenBackgroundOpacity": 0.8,
            "images-radius": "0",
            "recommendationReel-is-videoreel": false,
            "vignette-openButtonFontColor": "",
            "organic-show-static-text": false,
            "hide-disclosure-when-no-place": false,
            "pager-button-style": "<span class=\"pager-cont\">&laquo;</span>|<span class=\"pager-cont\">&raquo;</span>",
            "link-target": "normal",
            "organic-tracking-params": null,
            "component-id": "rbox-blended",
            "list-suffix": function(internalc, myorigin) {},
            "detail-order-syndicated": "title,branding",
            "title-icon-url": "",
            "read-more-cutoff-from-type": "ARTICLE",
            "orientation": "horizontal",
            "quantcast-label": "",
            "vignette-closeButtonHoverColor": "",
            "vignette-xButtonBGColor": "#000",
            "enable-title-icon-on-sc": false,
            "rows": 2,
            "format-rating": 'Rating: %s',
            "read-more-anchor-selector": "",
            "before-detail-order-syndicated": "",
            "slider-min-effective-scroll-size": 20,
            "recommendationReel-auto-pause": false,
            "use-dpr-images": true,
            "widget-theme-type": "DEFAULT",
            "__style__": {
                "": "width:300px;_width:300px;border-width:0px 0px 0px 0px;border-style:solid solid solid solid;border-color:#DFDFDF;padding:0px 0px 0px 0px;border-radius:0;-moz-border-radius:0;-webkit-border-radius:0;box-shadow:none;",
                "vignette": "xButtonColor:#fff;backgroundColor:#fff;backgroundOpacity:0.8;xButtonBGColor:#000;",
                ".playerCube .video-external-data": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".tbl-reco-reel-slider": "z-index:99999;margin:initial;top:50%;",
                ".trc_lightbox_overlay": "background-color:#000000;opacity:0.70;filter:alpha(opacity=70);",
                ".tbl-recommendation-reel .tbl-text-under-branding-background": "background-color:#EBEBEB;",
                "div.syndicatedItem:hover, div.syndicatedItem.videoCube_hover": "background-color:transparent;",
                ".playerCube div.videoCube:hover, div.videoCube_hover": "background-color:transparent;",
                ".trc_pager_prev:hover, .trc_pager_next:hover": "color:#6497ED;",
                ".trc_rbox_border_elm": "border-color:darkgray;",
                ".syndicatedItem .video-views": "color:black;font-size:10px;font-weight:normal;text-decoration:none;",
                ".syndicatedItem .video-category": "color:black;font-size:10px;font-weight:normal;text-decoration:none;",
                ".tbl-vignette-close-btn-wrp": "height:15;background:#000;",
                ".videoCube .video-label-box": "margin-left:0;margin-right:0px;",
                ".syndicatedItem .sponsored": "color:#9C9A9C;font-size:9px;font-weight:normal;text-decoration:none;",
                ".pager_disabled": "color:#7d898f;",
                ".playerCube .video-category": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".syndicatedItem .video-uploader": "color:black;font-size:10px;font-weight:normal;text-decoration:none;",
                ".videoCube.thumbnail_start .thumbBlock_holder": "width:40%;_width:40%;",
                ".playerCube .video-uploader": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".video-uploader": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".trc_sponsored_overlay": "background-color:black;",
                ".syndicatedItem .video-external-data": "color:black;font-size:10px;font-weight:normal;text-decoration:none;",
                ".trc_rbox_header": "font-family:Arial, Helvetica, sans-serif;font-size:100%;font-weight:bold;text-decoration:none;color:#000000;border-width:0;background:transparent;border-style:none;border-color:#D6D5D3;padding:0px 0px 0px 0px;line-height:1.2em;display:none;margin:0px 0px 0px 0px;position:relative;background-color:transparent;box-sizing:initial;height:auto;width:auto;_width:auto;",
                ".syndicatedItem .video-rating": "color:black;font-size:10px;font-weight:normal;text-decoration:none;",
                ".videoCube.vertical": "border-style:solid none none none;",
                ".trc_pager_unselected": "color:#7d898f;",
                ".video-rating": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".video-published-date": "font-size:10px;font-weight:normal;text-decoration:none;color:black;display:inherit;",
                ".syndicatedItem": "background-color:transparent;",
                ".syndicatedItem .video-duration-detail": "color:black;font-size:10px;font-weight:normal;text-decoration:none;",
                ".playerCube .videoCube.horizontal": "border-style:none none none none;",
                ".videoCube.syndicatedItem .thumbnail-overlay": "background-image:null;background-position:5% 5%;",
                ".videoCube.syndicatedItem.vertical": "border-style:solid none none none;",
                ".sponsored": "font-size:9px;font-weight:normal;text-decoration:none;color:#9C9A9C;",
                ".videoCube.syndicatedItem .thumbBlock": "border-color:darkgray;border-width:0px;",
                ".videoCube.syndicatedItem .thumbBlock .static-text": "text-align:left;background-color:black;display:none;color:white;font-size:10px;font-weight:normal;text-decoration:none;font-family:Arial, Helvetica, sans-serif;",
                ".videoCube.thumbnail_start.trc-split-label .trc-pre-label": "width:30%;_width:30%;",
                ".video-category": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".thumbnail-emblem": "background-position:5% 5%;width:35;_width:35;height:35;",
                ".tbl-vignette-background-screen": "background-color:#fff;opacity:0.8;filter:alpha(opacity=80);",
                ".syndicatedItem .video-description": "max-height:2.2em;*height:2.2em;color:black;font-family:Arial, Helvetica, sans-serif;font-size:14px;font-weight:normal;line-height:19.0px;text-decoration:none;",
                ".tbl-cta-style .cta-button:hover": "color:inherit;border-color:#999990;",
                ".playerCube .video-published-date": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".videoCube:hover .thumbnail-overlay, .videoCube_hover .thumbnail-overlay": "background-image:null;",
                ".video-label-box.trc-pre-label": "height:auto;",
                ".video-label,.sponsored,.sponsored-url": "font-family:'Open Sans', sans-serif, Arial;",
                ".videoCube.thumbnail_start .trc-pre-label": "width:60%;_width:60%;",
                ".syndicatedItem .video-title": "max-height:72.0px;*height:72.0px;color:#000000;font-family:'Open Sans', sans-serif, Arial;font-size:18.0px;line-height:24.0px;font-weight:bold;text-decoration:none;padding:0;",
                ".playerCube:hover .thumbnail-overlay, .playerCube_hover .thumbnail-overlay": "background-image:null;",
                ".videoCube.thumbnail_start.trc-split-label .trc-main-label": "width:30%;_width:30%;",
                ".videoCube": "width:auto;_width:auto;background-color:transparent;border-width:0px 0px 0px 0px;border-color:#E4E4E4;padding:0px 0px 0px 0px;height:auto;margin-left:0px;margin-top:0px;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;border-style:SOLID;",
                ".sponsored-default .video-description": "max-height:2.2em;*height:2.2em;",
                ".tbl-vignette-attribution": "color:#6B6666;font-size:15px;",
                ".playerCube .video-description": "font-family:Arial, Helvetica, sans-serif;font-size:10px;line-height:11px;font-weight:normal;text-decoration:none;max-height:2.2em;*height:2.2em;color:black;",
                ".playerCube .videoCube .video-label-box": "margin-left:81px;margin-right:0px;",
                ".videoCube.syndicatedItem .thumbBlock .branding": "text-align:left;background-color:transparent;display:none;left:0px;color:black;font-size:10px;font-weight:normal;text-decoration:none;font-family:Arial, Helvetica, sans-serif;background-image:null;",
                "div.videoCube:hover, div.videoCube_hover": "background-color:transparent;",
                ".videoCube .story-widget.story-widget-text-under .tbl-ui-line": "background-color:#333333;",
                ".videoCube .sponsored": "margin-top:-7px;",
                ".trc_pager_pages div": "font-size:12px;font-weight:normal;text-decoration:none;",
                ".sponsored-url": "font-size:9px;font-weight:bold;text-decoration:underline;color:green;",
                ".playerCube .video-title": "font-family:Arial, Helvetica, sans-serif;text-decoration:none;font-size:14px;line-height:17.5px;font-weight:bold;max-height:2.58em;*height:2.58em;color:black;",
                ".trc_rbox_header_icon_img": "margin:0px;height:18px;",
                ".tbl-recommendation-reel .tbl-text-under-title-background": "background-color:#EBEBEB;",
                ".tbl-recommendation-reel .tbl-ui-line": "background-color:#333333;",
                ".videoCube.syndicatedItem.horizontal": "border-style:none;",
                ".videoCube .thumbBlock .static-text": "font-weight:normal;font-family:Arial, Helvetica, sans-serif;text-decoration:none;font-size:11px;background-color:#a30202;display:block;color:#ffffff;text-align:left;",
                ".video-title": "font-family:Arial, Helvetica, sans-serif;font-size:18.0px;line-height:24.0px;font-weight:bold;max-height:96.0px;*height:96.0px;color:#000000;text-decoration:none;margin:0 0 0 0;",
                ".playerCube .video-rating": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".syndicatedItem .branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', sans-serif, Arial;background-image:null;text-align:left;line-height:24.0px;",
                ".trc_pager_selected": "color:#0056b3;",
                ".videoCube.syndicatedItem": "background-color:transparent;border-color:#E4E4E4;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;border-width:0px 0px 0px 0px;border-style:SOLID;",
                ".branding div.logoDiv": "font-family:inherit;",
                ".trc_rbox_div": "width:auto;_width:99%;height:410px;border-width:0;padding:0;margin:0px 0px -25px 0px;",
                ".playerCube .video-views": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".trc_pager div": "font-family:serif;",
                ".syndicatedItem .video-label-box.trc-pre-label": "height:auto;",
                "recommendationReel": "min-adx-line-color:#2abfd5;min-adx-progress-color:#FFF;",
                ".videoCube.horizontal": "border-style:none;",
                "div.trc_pager_pages div:hover": "color:#6497ED;",
                ".pager_enabled": "color:#0056b3;",
                ".playerCube .thumbnail-overlay": "background-image:null;background-position:5% 5%;",
                ".videoCube .thumbnail-overlay": "background-image:null;background-position:5% 5%;",
                ".playerCube .videoCube .video-duration": "display:block;left:36px;",
                ".syndicatedItem .video-published-date": "color:black;font-size:10px;font-weight:normal;text-decoration:none;display:inherit;",
                ".syndicatedItem .sponsored-url": "color:green;font-size:9px;font-weight:bold;text-decoration:underline;",
                ".playerCube .videoCube .thumbBlock": "border-width:0px;border-color:darkgray;",
                ".playerCube .video-label-box": "text-align:left;",
                "div.sponsored-default:hover, div.sponsored-default.videoCube_hover": "background-color:inherit;",
                ".videoCube .story-widget.story-widget-text-under .tbl-text-under-title-background": "background-color:#EBEBEB;",
                ".video-external-data": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".trc_pager_prev,.trc_pager_next": "font-size:12px;font-weight:normal;text-decoration:none;",
                ".videoCube .thumbBlock": "border-width:0px;border-color:darkgray;border-radius:10px;-moz-border-radius:10px;-webkit-border-radius:10px;",
                ".videoCube.syndicatedItem .video-duration": "display:none;left:36px;",
                ".sponsored-default .video-title": "max-height:2.58em;*height:2.58em;",
                ".branding": "color:#999999;font-size:11.0px;font-weight:bold;text-decoration:none;font-family:'Open Sans', sans-serif, Arial;background-image:null;text-align:left;line-height:24.0px;",
                ".sponsored-default": "background-color:#F7F6C6;",
                ".playerCube .videoCube": "background-color:transparent;border-color:#D6D5D3;border-width:1px;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;margin-left:0px;margin-top:0px;padding:3px;",
                ".branding .logoDiv a span": "color:inherit;font-size:inherit;",
                ".video-label-box": "text-align:left;height:auto;margin:0px 0px 0px 0px;",
                ".video-description": "font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:19.0px;font-weight:normal;max-height:2.2em;*height:2.2em;color:black;text-decoration:none;",
                ".videoCube .video-duration": "left:36px;display:none;",
                "div.syndicatedItem:hover .thumbBlock": "border-color:inherit;",
                ".trc_pager_counter": "color:#000000;",
                ".whatsThisSyndicated": "font-family:Arial, Verdana, sans-serif;font-size:9px;font-weight:normal;color:black;text-decoration:none;padding:0;",
                ".playerCube .video-duration-detail": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".video-duration-detail": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                "div.videoCube:hover .thumbBlock": "border-color:inherit;",
                ".video-icon-img": "margin:0px;height:18px;",
                ".video-views": "font-size:10px;font-weight:normal;text-decoration:none;color:black;",
                ".tbl-cta-style .cta-button": "font-family:Helvetica, Arial, sans-serif;background-color:transparent;border-color:#999990;color:#333333;"
            }
        }
    },
    "language": "fr",
    "testmode": false,
    "direction": "ltr",
    "default-thumbnail": "http://cdn.taboola.com/libtrc/static/thumbnails/759bc49732394dde468c8d65a464e1a4.png",
    "domains": "",
    "sponsored-link-text": "Sponsored Link",
    "sponsored-video-text": "Sponsored Video",
    "branding-url": {},
    "configuration-version": "0",
    "external-credentials": "",
    "brightcove-list-id": "",
    "publisher-start": function() {},
    "get-user": function() {
        return null;
    },
    "get-creator": function() {
        var m = document.getElementsByTagName('head')[0].getElementsByTagName('meta', false);
        for (var i = 0; i < m.length; i++) {
            if (m[i].name == 'uploader' || m[i].name == 'item-uploader') return m[i].content;
        }
    },
    "get-views": function() {
        var m = document.getElementsByTagName('head')[0].getElementsByTagName('meta', false);
        for (var i = 0; i < m.length; i++) {
            if (m[i].name == 'views' || m[i].name == 'item-views') return m[i].content;
        }
    },
    "get-rating": function() {
        var m = document.getElementsByTagName('head')[0].getElementsByTagName('meta', false);
        for (var i = 0; i < m.length; i++) {
            if (m[i].name == 'rating' || m[i].name == 'item-rating') {
                if (!isNaN(parseFloat(m[i].content))) return m[i].content;
            }
        }
    },
    "get-tags": function() {
        return [];
    },
    "logo-image": "http://cdn.taboolasyndication.com/taboola/powered-by.png",
    "has_valid_rss": false,
    "actionscript_version": "3",
    "brightcove-uses-reference": false,
    "publisher-end": function(id) {},
    "ie-logo-image": "http://cdn.taboolasyndication.com/taboola/powered-by-small.gif",
    "attribution": true,
    "notify-loaded": true,
    "metafields": "",
    "normalize-item-id": function(itemid, type, canon) {
        if (!canon && type == 'text' && typeof itemid == 'string' && itemid.search(new RegExp('^https?://')) == 0) itemid = itemid.replace(/\?.*/, '', false);
        return itemid.toLowerCase();
    },
    "normalize-item-url": function(itemurl, type, canon) {
        return itemurl;
    },
    "read-paused-bcplayer": false,
    "normalize-request-param": function(req, mode) {
        return req;
    },
    "normalize-log-param": function(name, value, mode) {
        return value;
    },
    "timeout": 8000,
    "prenormalize-item-id": {
        "host": true,
        "fragment": "^(/video/|!)",
        "query": ["p", "id"],
        "truncate-at": ["search.searchcompletion.com", "org.mozilla.javascript.undefined"],
        "trailing-dirsep": true
    },
    "prenormalize-item-url": false,
    "loader-impl": "",
    "trc-network-mapping": {},
    "trc-skip-failover": false,
    "backstage-domain-url": "",
    "adc-config": null,
    "link-target-conf": null,
    "ios-sc-link-target": {
        'NAV': '_self',
        'NT': '_self',
        'SP': '_self'
    },
    "small-ios-device": "iPhone|iPod",
    "read-more-debug": false,
    "read-more-devices": "smart_phone",
    "attribution-disclosure-direction": "ltr",
    "mode-pub-start": function() {},
    "before-video-load": function() {
        return true;
    },
    "publisher-logo": {},
    "detect-item-from-same-host": function(host, itemHost) {},
    "mode-before-video-load": function(rbox) {
        return true;
    },
    "after-card-created": function(placementData, publisherCardNum, feed) {},
    "publisher-branding": {},
    "feed-view-devices": "smart_phone",
    "feed-view-enable": false,
    "global": {
        "enable-events-api": true,
        "events-api-click-enabled": true,
        "enable-analytics": "true",
        "config-analytics": {
            logTimer: 50000,
            logLength: 5,
            traffic: 10,
            measureEnable: true,
            measureTimeToSend: 10000,
            disableRawDataSend: true
        },
        "enable-loader-cache-buster": true,
        "stop-channels-threshold": "0.8",
        "syndication-embed-code": function(box, recommendation, affiliate) {},
        "syndicator-affiliate-id": "",
        "explore-delay": 500,
        "visible-delay": 500,
        "css-isolation": false,
        "requests-domain": "trc.taboola.com",
        "inject-comscore": false,
        "has-userx": true,
        "disclosure-enabled": true,
        "trc-request-delay": 500,
        "publisher-onclick-nt-enabled": false,
        "touchstart-enabled": true,
        "use-storage-detection": true,
        "thumb-lazy-load-switch": false,
        "thumb-lazy-load-method": "PAGE_LOAD,PAGE_INTERACTIVE,RBOX_VISIBLE",
        "inject-mdotlabs": false,
        "use-calibration-uim": false,
        "inject-taboolax": false,
        "use-delay-image-load": true,
        "abp-detection-enabled": true,
        "switch-abp-class": false,
        "use-abp-uim": true,
        "send-event-as-post": true,
        "image-url-prefix": "https://images.taboola.com/taboola/image/fetch/f_jpg%2Cq_auto%2Ch_{h}%2Cw_{w}%2Cc_fill%2Cg_faces:auto%2Ce_sharpen/",
        "enable-social-events": true,
        "tmp-use-pb-params": true,
        "send-avail-as-post": true,
        "send-full-list": true,
        "enable-organic-redirect": true,
        "send-avail-as-get": false,
        "send-visible-as-get": false,
        "ios-sc-link-target": {
            "NAV": "_top",
            "NT": "_top",
            "SP": "_top"
        },
        "has-adchoice": true,
        "send-variant-warning": true,
        "enable-read-more": true,
        "enable-rbox-map": false,
        "enable-trc-cache": true,
        "trc-cache-it": {
            "text": "c",
            "home": "d",
            "video": "d",
            "search": "d",
            "category": "d",
            "photo": "d",
            "other": "d"
        },
        "enable-deferred-visible": true,
        "enable-manual-visible": true,
        "enable-deferred-available": true,
        "send-pb-in-click": true,
        "force-reset-on-ready": true,
        "show-rtb-ad-choices-icon": true,
        "send-item-query-string-in-req": true,
        "send-user-id-tag": true,
        "user-id-tag-macros": ["tags.bluekai.com/site/35702?id={taboolaID}"],
        "disable-yield": true,
        "smart-ellipsis": true,
        "rtb-image-url-prefix": "https://images.taboola.com/taboola/image/fetch/$pw_{w}%2C$ph_{h}/t_tbl-cnd/",
        "enable-ie-split-click-event": true,
        "enable-multi-pv3": true,
        "cloudinary-aspect-ratios-list": [
            [1, 4],
            [1, 3],
            [1, 2.5],
            [1, 2],
            [1, 1.9],
            [1, 1.8],
            [9, 16],
            [1, 1.7],
            [1, 1.6],
            [1, 1.5],
            [1, 1.4],
            [3, 4],
            [1, 1.3],
            [1, 1.2],
            [1, 1.1],
            [1, 1],
            [1, 0.9],
            [6, 5],
            [1, 0.8],
            [4, 3],
            [1, 0.7],
            [3, 2],
            [1, 0.6],
            [16, 9],
            [2, 1]
        ],
        "store-userid-first-party-cookie": true,
        "enable-detect-bots": true,
        "allow-nofollow-for-exchange": true,
        "visibility-intersection-api-delay": 1000,
        "rbox-ajax-post-events-full-rollout": true,
        "rbox-post-events-as-ajax": true,
        "prefer-response-session-data": true,
        "enable-visibility-intersection-api": true,
        "visibility-intersection-api-full-rollout": true,
        "has-mode-geometry": true,
        "feed-observer-load-next-batch": true,
        "rbox-enable-fix-user-id-event": "true",
        "use-native-json-stringify": true,
        "max-wait-for-cmp": 5000,
        "disable-unified-iframe-pixel-reporter": true,
        "consent-presets": {
            taboola_default: null
        },
        "p-video-overlay-send-events": true,
        "monitor-dup-items-traffic-pct": 5,
        "rbox-old-chrome-es6-fix": (function() {})(),
        "exclude-subd-shift": ["15.taboola.com", "trc.taboola.com", "authentication.taboola.com"],
        "send-next-up-click-abtest-event": false,
        "enable-organic-redirect-on-amp": true,
        "enable-trc-route": true,
        "amp_target": "_top",
        "disable-rbox-usage-logging": false,
        "cdn-taboola-path": "cdn.taboola.com",
        "ui-innovation-modules-path": "ui-ab-tests",
        "disable-scope-feed-css": false,
        "enable-experiments-variant-id-event": true,
        "enable-loader-type-event": true,
        "user-stop-retarget-campaign-after-click": "false",
        "rbox-trc-protocol": "https:",
        "enable-explore-more": true,
        "enable-item-override": true,
        "cloudinary-encoding-and-100-round-factor": {},
        "event-logger:publisher-enable-spatial-events": true,
        "spatial-slots-throttle-th": 1000,
        "feed-max-num-of-consecutive-failed-requests": "5",
        "enable-bulk-events": "true",
        "bulk-available-events-strategy": "delay",
        "enable-spatial-data-per-page": 1,
        "enable-consent": true,
        "read-more-events-enabled": "0.1",
        "GPT-refresh-control": true,
        "has-page-geometry": true,
        "has-page-geometry-extended": true,
        "has-slots-geometry": true,
        "has-slots-saliency": true,
        "bulk-available-events-delay": 1000,
        "disable-iframe-for-tracking-pixel": true,
        "use-dpr-images": true,
        "disable-explore-more-video-reset": true,
        "enable-explore-more-video": true,
        "enable-exm-inside-iframe": false,
        "enable-explore-more-state-check": true,
        "default-event-route": "trc-events.taboola.com",
        "trc-event-route-template": "<dc>-trc-events.taboola.com",
        "enable-real-time-user-sync": true,
        "disable-sponsored-for-links": false,
        "enable-mode-injection": true,
        "mw-display-none-on-no-items-to-render": true,
        "enable-text-over": "true",
        "cloudinary-encode": true,
        "rbox-error-stack-reporting-pct": 0.01,
        "thumbnail-transformation-per-item-is-enabled": "1",
        "image-optimization-url-per-item-is-enabled": "1",
        "keep-referrer-in-session": true,
        "amp-support-consent-string": "true",
        "video-gdpr-applies-use-requires-consent": "true",
        "event-types-to-route": ["debug", "perf", "metrics", "bulk-metrics", "abtests", "supply-feature"],
        "bulk-body-debug-sample-rate": 1.0E-4,
        "enable-custom-injection": true,
        "block-video-prob": 0.1,
        "enable-video-ajax": true,
        "cds:send-uad": true,
        "cds:send-dnid": true,
        "enable-real-time-user-sync-with-consent": true,
        "enable-bid-detection": 0,
        "defer-cookie-sync": 2000,
        "defer-userx-render": 1000,
        "defer-scripts-render": 500,
        "advanced-feed-view-telemetry-enabled": "0.01",
        "lazy-render-enbale": true,
        "enable-new-ellipsis-module": 1,
        "lazy-render": {
            enable: true,
            raKill: true
        },
        "lazy-render-enable": true,
        "flc-enabled": true,
        "tm-dynamic-load": "true",
        "explore-more-google-timer": 10,
        "new-logging-mechanism-on": 0.1,
        "thumbs-image-lazy-load-margins": "2500px 1500px 2500px 1500px",
        "enable-call-to-action-creative-component": false,
        "rbox:collect-eid-from-page": false,
        "default-stories-height": 135,
        "read-more-scroll-fast-enabled": true,
        "pass-browser-url": true,
        "user-mapping-enabled": true,
        "video-split-start-unit": true,
        "enable-cta-component": true,
        "trcinfo-sample-rate": 0.05,
        "view-tag-delay": 10000,
        "bulk-metrics-events-strategy": "delay",
        "rbox-metrics-enabled": 0.1,
        "view-tags-domains-url": {
            'adsafeprotected.com': 1,
            'cdn.doubleverify.com': 1
        },
        "read-more-click-delay": true,
        "cta-abtest-report-percent": -1,
        "cta-usage-report-percent": 0.02,
        "cta-render-report-percent": 0.05,
        "explore-more-enable-position-correction": true,
        "view-lazy-load-tags": {
            'z.moatads.com': 1,
            'cdn.doubleverify.com': 1,
            'adsafeprotected.com': 1,
            'googlesyndication.com': 1
        },
        "view-lazy-load-tags-margin": 20,
        "header-bidding-enabled": 0,
        "enable-ios-back-fix": true,
        "item-override-encode-fields": true,
        "cta-metric-report-percent": 0.1,
        "motion-ads-track-events": 0.001,
        "html-card-max-width": "800px",
        "motion-ads-load-old-version": 0,
        "use-unit-fetcher-response-instead-of-tb": true,
        "send-rv-avail-as-post": true,
        "send-rv-avail-as-get": false,
        "enable-rv-available": true,
        "encode-irregular-og:url": true,
        "explore-more-enable-hide-all-but-header": true,
        "html-track-events": 0.1,
        "high-entropy-values-arguments": ["platformVersion", "mobile", "model", "platform", "uaFullVersion"],
        "vignette-lazy-load": true,
        "enable-hai-report": true,
        "load-user-agent-data": true,
        "get-vignette-config-from-products": true,
        "display-ad-to-native": true,
        "rbox-error-fullUrl": 0.01,
        "remove-old-vignette-disclosure": true,
        "spa-detection-enabled": 0.01,
        "send-id-providers-data": true,
        "send-alternate-container-width": true,
        "enable-slice-url": "0",
        "unintentional-clicks-default-send-init-event": true,
        "enable-ampsplitfeedfix": true,
        "app-install-sanity-report-fraction": 0.1,
        "vignette-capture-page-click": true,
        "vignette-new-scanning-logic": true,
        "unintentional-clicks-ignore-demand-enablement": false,
        "enable-rbox-es-events": 0.003,
        "display-rv-visible-timeout": 0,
        "enable-item-measurements": true,
        "enable-only-full-visible-event": "1",
        "eid:rbox:common-eid-keywords": "help,support,contact,readme,test,info,reply,careers,spam,login,subscribe,feedback,reachus,customers,cookie,members",
        "enable-real-time-user-sync-for-all-browsers": true,
        "cloudinary-isi-ratios": true,
        "enable-isi-card": true,
        "test_for_fraud_from_tag_loader": true,
        "isi-metric-report": 1,
        "app-install-report": 0.1,
        "shift-redir-onclick": true,
        "motion-ads-retry-play-timeout": 2000,
        "external-visibility-by-items": true,
        "trc:blockers:WebComponentRBlockerQuery:blocker-web-component-passed-logger-for-creative-type:APP_INSTALL": "true",
        "trc:blockers:WebComponentRBlockerQuery:blocker-web-component-passed-logger-for-creative-type:ISI_CARD": "true",
        "adjust-banner-height": true,
        "explore-more-supply-feature-percent": true,
        "unintentional-clicks-default-enable": true,
        "unintentional-clicks-default-uicm": 0,
        "unintentional-clicks-default-uics": 0.5,
        "monitor-article-distance-from-feed-percentage": true,
        "image-cropping-report": 0.1,
        "image-cropping-ratios-list": [
            [16, 9],
            [4, 3],
            [6, 5],
            [2, 1]
        ],
        "image-cropping-active": 1,
        "share-button-detection-report-percentage": 0.1,
        "enable-local-dcl": true,
        "motion-ads-viewport-lazy-load": 1,
        "motion-ads-viewport-lazy-load-margin": 0.5,
        "article-and-feed-area-scanner-report-percentage": 0.15,
        "new-cta-enabled": true,
        "report-cta-metrics": 0.1,
        "explore-more-enable-missing-header-event": true,
        "motion-ads-preload-attribute": "",
        "enable-explore-more-header-z-index": false,
        "enable-warn-tbt": 0.05,
        "disclaimer-color-scheme": "",
        "disclaimer-color-scheme-mode": "",
        "enable-explore-more-history-hook": false,
        "disable-overlay-visibility-report-fix": 0,
        "enable-em-history-hook": true,
        "motion-ads-cloudinary-prefix": "q_auto:low",
        "enable-em-publisher-start-history-hook": true,
        "enable-warn-TBT": 0.05,
        "enable-trecs-net": true,
        "google-fonts": ["Poppins"],
        "intersection-should-throw-error-on-missing-attribute": 1,
        "intersection-should-not-throw-error-on-missing-attribute": 1,
        "cta-ignore-detail-order": true,
        "topics-enabled": true,
        "responsive-utils-report": 0.01,
        "enable-responsive-float-fix": true,
        "loaf-threshold": 50,
        "loaf-token": "A9irCqaHWp+prcT32cE7NQKUrKlHBR0STfIUHk2K4O2XW2IF8U8+hPEPzpUOF8cE3TNBsJCzKvw8mBjLpKiHawEAAACIeyJvcmlnaW4iOiJodHRwczovL2Nkbi50YWJvb2xhLmNvbTo0NDMiLCJmZWF0dXJlIjoiTG9uZ0FuaW1hdGlvbkZyYW1lVGltaW5nIiwiZXhwaXJ5IjoxNzA5NjgzMTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==",
        "enable-img-dim-fix": false,
        "enable-filler-block": true,
        "trecs-motion-ads-fade": 0,
        "trecs-motion-ads-pause-enabled": 0,
        "trecs-motion-ads-fade-enabled": 0,
        "header-bidding-wait-for-win-events-timeout": 2000,
        "header-bidding-is-add-placement": true,
        "bakeTime": 1701260133673,
        "maxRevision": 134451590,
        "publisherName": "leboncoin",
        "rbox:rtb:real-time-user-sync:intent-iq:external-partners-ids": [15042, 24, 15040, 10197, 15027, 15308, 53, 15175, 15251, 15151, 15355, 10262, 10141, 10086, 15176, 15038, 10144],
        "style": {
            "rtl": "",
            "custom": "@font-face{\n    font-family: 'OpenSans';\n    src: url(\"https://cdn.taboola.com/static/e8/e89c7816-ffc6-4cf1-bf3e-e13e90e4219d.ttf\");\n    font-weight:400;\n    font-style:normal;\n}\n@font-face{\n    font-family: 'OpenSansSemibold';\n    src: url(\"https://cdn.taboola.com/static/83/8389baf0-4c3d-42af-b4a6-44e7b91c5533.ttf\");\n    font-weight:600;\n    font-style:normal;\n    }\n@font-face{\n    font-family: 'OpenSansBold';\n    src: url(\"https://cdn.taboola.com/static/86/868cf910-e070-4241-99aa-00a9a36963a6.ttf\");\n    font-weight:700;\n    font-style:normal;\n    }\n#_cm-css-reset._cm-video {\n    left: 10px !important;\n}\n",
            "mode_custom": "/* s-split-thumbnails-text-under-new */\n.thumbnails-text-under-new .trc_header_right_column {\n\tbackground: transparent;\n\theight: auto;\n}\n\n.thumbnails-text-under-new .thumbBlock_holder::after {\n    content: 'Sponsorisé';\n    color: #a8b4c0;\n\t  font-family: 'Open Sans', Helvetica, Verdana, sans-serif;\n    border-radius: 5px;\n    border: 1px solid #a8b4c0;\n    padding: 3px 10px 3px 10px;\n    margin: 10px 0px 10px 0px;\n    font-size: 11px;\n    position: absolute;\n    left: 0;\n    font-weight: normal;\n}\n/* e-split-thumbnails-text-under-new *//* s-split-thumbnails-stream-petite-2 */\n.thumbnails-stream-petite-2 .trc_header_right_column {\n\tbackground: transparent;\n\theight: auto;\n}\n.thumbnails-stream-petite-2 .videoCube .branding .logoDiv{\n    top: 0;\n\t  position: absolute;\n    width: 56px;\n    height: 20px;\n    border-radius: 5px;\n    border: 1px solid #a8b4c0;\n    padding: 0px 8px 0px 8px;\n    margin: 0px;\n    font-size: 9px;\n    text-align: center;\n\t}\n/* e-split-thumbnails-stream-petite-2 *//* s-split-thumbnails-stream-petite-1 */\n.thumbnails-stream-petite-1 .trc_header_right_column {\n\tbackground: transparent;\n\theight: auto;\n}\n.thumbnails-stream-petite-1 .videoCube .branding .logoDiv{\n    top: 0;\n\t  position: absolute;\n    width: 56px;\n    height: 20px;\n    border-radius: 5px;\n    border: 1px solid #a8b4c0;\n    padding: 0px 8px 0px 8px;\n    margin: 0px;\n    font-size: 9px;\n    text-align: center;\n\n\t}\n/* e-split-thumbnails-stream-petite-1 *//* s-split-thumbnails-stream-grande-1 */\n.thumbnails-stream-grande-1 .trc_header_right_column {\n\tbackground: transparent;\n\theight: auto;\n}\n.thumbnails-stream-grande-1 .videoCube .branding .logoDiv{\n    top: 0;\n\t  position: absolute;\n    width: 56px;\n    height: 20px;\n    border-radius: 5px;\n    border: 1px solid #a8b4c0;\n    padding: 0px 8px 0px 8px;\n    margin: 0px;\n    font-size: 9px;\n    text-align: center;\n\n\t}\n/* e-split-thumbnails-stream-grande-1 *//* s-split-thumbnails-stream-d */.thumbnails-stream-d .syndicatedItem .video-title:before {\n\t\tcontent: 'Sponsorisé';\n    font-size: 12px;\n    display: block;\n    padding: 0 4px;\n\t  text-align: center;\n    border: 1px solid #a8b4c0;\n    color: #a8b4c0;\n    border-radius: 5px;\n    line-height: 1.7rem;\n    font-weight: 500;\n    width: 30% !important;\n    text-decoration: none;\n}/* e-split-thumbnails-stream-d *//* s-split-thumbnails-stream-bordure-2 */\n.thumbnails-stream-bordure-2 .trc_header_right_column {\n\tbackground: transparent;\n\theight: auto;\n}\n.thumbnails-stream-bordure-2 .videoCube .branding .logoDiv{\n    top: 0;\n\t  position: absolute;\n    width: 56px;\n    height: 20px;\n    border-radius: 5px;\n    border: 1px solid #a8b4c0;\n    padding: 0px 0px 4px 8px;\n    margin: 0px;\n    font-size: 9px;\n\t}\n\n@media screen and (max-width: 460px){\n\t.thumbnails-stream-bordure-2 .videoCube.thumbnail_start .thumbBlock_holder{\n\t\twidth: 125px;\n    height: 192px\n\t}\n}/* e-split-thumbnails-stream-bordure-2 *//* s-split-thumbnails-stream-bordure-1 */\n.thumbnails-stream-bordure-1 .trc_header_right_column {\n\tbackground: transparent;\n\theight: auto;\n}\n.thumbnails-stream-bordure-1 .videoCube .branding .logoDiv{\n    top: 8px;\n\t  position: absolute;\n    width: 56px;\n    height: 20px;\n    border-radius: 5px;\n    border: 1px solid #a8b4c0;\n    padding: 0px 8px 0px 8px;\n    margin: 0px;\n    font-size: 9px;\n\t  text-align: center;\n\t}\n\n.thumbnails-stream-bordure-1 .trc-widget-footer .logoDiv{\n\tmargin: -8px 10px 0px 0px;\n}\n/* e-split-thumbnails-stream-bordure-1 *//* s-split-thumbnails-grande-2 */\n.thumbnails-grande-2 .trc_header_right_column {\n\tbackground: transparent;\n\theight: auto;\n}\n.thumbnails-grande-2 .videoCube .branding .logoDiv{\n    bottom: 40px;\n\t  position: absolute;\n    width: 56px;\n    height: 20px;\n    border-radius: 5px;\n    border: 1px solid black;\n    padding: 0px 8px 0px 8px;\n    margin: 8px;\n    font-size: 9px;\n    text-align: center;\n   \n\t}\n\n@media screen and (max-width:552px){\n\t.thumbnails-grande-2 .videoCube .branding .logoDiv{\n\t  bottom: 60px;\n\t  position: absolute;\n    width: 56px;\n    height: 20px;\n    border-radius: 5px;\n    border: 1px solid #a8b4c0;\n    padding: 0px 0px 0px 3px;\n    margin: 8px;\n    font-size: 9px;\n}\n}/* e-split-thumbnails-grande-2 *//* s-split-thumbnails-f *//* override bootstrap default span definitions */\n.thumbnails-f [class*=span] {\n    float:none;\n    margin-left:0;\n}\n\n\n.thumbnails-f .trc_rbox_header_span .trc_header_right_column {\n\tbackground: transparent;\n}\n\n.thumbnails-f .trc_rbox_header .logoDiv {\n        font-size: inherit;\n}\n\n.trc_elastic .thumbnails-f .video-label-box {\n    height: 76.0px;\n}\n.thumbnails-f .trc_header_left_column {\n\tbackground: transparent;\n}\n\n.thumbnails-f .videoCube .video-label-box {\n\tmargin-top: 0px;\n}\n\ndiv[id*=trc_wrapper].thumbnails-f {\n    width: 728px;\n    height: 90px;\n    background: #E3E3E3;\n}\n\n.thumbnails-f div[data-item-id].videoCube .thumbBlock_holder {\n    width: 35%;\n    height: 64px;\n    margin-left: 10px;\n}\n\n.thumbnails-f div[data-item-id].videoCube.videoCube_2_child{\n    margin-left: 0px;\n}/* e-split-thumbnails-f *//* s-split-thumbnails-4 */\n.thumbnails-4 .trc_header_right_column {\n\tbackground: transparent;\n\theight: auto;\n}\n\t.thumbnails-4 .videoCube .branding .logoDiv{\n\t\tposition: absolute;\n    top: 0px;\n    width: 56px;\n    height: 20px;\n    border-radius: 5px;\n    border: 1px solid #a8b4c0;\n    padding: 0px 8px 0px 8px;\n    margin: 0px;\n    font-size: 9px;\n    text-align: center;\n\t}\n/* e-split-thumbnails-4 */"
        },
        "locale": null
    },
    "systemFlags": {
        "loaderType": "trecs"
    }
}, "20231129-9-RELEASE")