/*! 20231129-9-RELEASE */

(o => {
    const t = "top";

    function e() {
        try {
            if (!o.browsingTopics) return;
            return o.browsingTopics().then(o => {
                const e = [];
                for (let t = 0; t < o.length; t++)
                    if (o[t].topic && o[t].taxonomyVersion) {
                        const n = {
                            i: o[t].topic,
                            v: o[t].taxonomyVersion
                        };
                        e.push(n)
                    }
                e.length && TRC.pageManager.storeValue(t, JSON.stringify(e))
            }).catch(() => {})
        } catch (o) {}
    }

    function n() {
        let o, e;
        try {
            if ((e = (o = TRC.pageManager.getValue(t)) ? JSON.parse(o) : null) && e.length > 0) return e
        } catch (o) {}
    }
    e(), TRC.GoogleTopicsApi = {
        readGoogleTopicsApiFromLocalStorage: n
    }, window._trcIsUTactive && (TRC.GoogleTopicsApi.testHelpers = {
        saveGoogleTopicsApiInLocalStorage: e
    })
})(document);