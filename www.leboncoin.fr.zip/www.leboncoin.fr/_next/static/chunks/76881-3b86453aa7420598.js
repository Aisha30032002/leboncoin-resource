! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            r = Error().stack;
        r && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[r] = "67afbcb4-6556-4b38-8afe-d4f01a64b258", e._sentryDebugIdIdentifier = "sentry-dbid-67afbcb4-6556-4b38-8afe-d4f01a64b258")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [76881], {
        76881: function(e, r, t) {
            t.d(r, {
                E: function() {
                    return Z
                }
            });
            var a = t(67294),
                n = t.t(a, 2),
                l = t(87462);
            t(73935);
            let o = (0, a.forwardRef)((e, r) => {
                let {
                    children: t,
                    ...n
                } = e, o = a.Children.toArray(t), i = o.find(u);
                if (i) {
                    let e = i.props.children,
                        t = o.map(r => r !== i ? r : a.Children.count(e) > 1 ? a.Children.only(null) : (0, a.isValidElement)(e) ? e.props.children : null);
                    return (0, a.createElement)(s, (0, l.Z)({}, n, {
                        ref: r
                    }), (0, a.isValidElement)(e) ? (0, a.cloneElement)(e, void 0, t) : null)
                }
                return (0, a.createElement)(s, (0, l.Z)({}, n, {
                    ref: r
                }), t)
            });
            o.displayName = "Slot";
            let s = (0, a.forwardRef)((e, r) => {
                let {
                    children: t,
                    ...n
                } = e;
                return (0, a.isValidElement)(t) ? (0, a.cloneElement)(t, { ... function(e, r) {
                        let t = { ...r
                        };
                        for (let a in r) {
                            let n = e[a],
                                l = r[a],
                                o = /^on[A-Z]/.test(a);
                            o ? n && l ? t[a] = (...e) => {
                                l(...e), n(...e)
                            } : n && (t[a] = n) : "style" === a ? t[a] = { ...n,
                                ...l
                            } : "className" === a && (t[a] = [n, l].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...t
                        }
                    }(n, t.props),
                    ref: r ? function(...e) {
                        return r => e.forEach(e => {
                            var t;
                            "function" == typeof(t = e) ? t(r): null != t && (t.current = r)
                        })
                    }(r, t.ref) : t.ref
                }) : a.Children.count(t) > 1 ? a.Children.only(null) : null
            });
            s.displayName = "SlotClone";
            let i = ({
                children: e
            }) => (0, a.createElement)(a.Fragment, null, e);

            function u(e) {
                return (0, a.isValidElement)(e) && e.type === i
            }
            let d = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, r) => {
                    let t = (0, a.forwardRef)((e, t) => {
                        let {
                            asChild: n,
                            ...s
                        } = e, i = n ? o : r;
                        return (0, a.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, a.createElement)(i, (0, l.Z)({}, s, {
                            ref: t
                        }))
                    });
                    return t.displayName = `Primitive.${r}`, { ...e,
                        [r]: t
                    }
                }, {}),
                c = "Progress",
                [f, m] = function(e, r = []) {
                    let t = [],
                        n = () => {
                            let r = t.map(e => (0, a.createContext)(e));
                            return function(t) {
                                let n = (null == t ? void 0 : t[e]) || r;
                                return (0, a.useMemo)(() => ({
                                    [`__scope${e}`]: { ...t,
                                        [e]: n
                                    }
                                }), [t, n])
                            }
                        };
                    return n.scopeName = e, [function(r, n) {
                        let l = (0, a.createContext)(n),
                            o = t.length;

                        function s(r) {
                            let {
                                scope: t,
                                children: n,
                                ...s
                            } = r, i = (null == t ? void 0 : t[e][o]) || l, u = (0, a.useMemo)(() => s, Object.values(s));
                            return (0, a.createElement)(i.Provider, {
                                value: u
                            }, n)
                        }
                        return t = [...t, n], s.displayName = r + "Provider", [s, function(t, s) {
                            let i = (null == s ? void 0 : s[e][o]) || l,
                                u = (0, a.useContext)(i);
                            if (u) return u;
                            if (void 0 !== n) return n;
                            throw Error(`\`${t}\` must be used within \`${r}\``)
                        }]
                    }, function(...e) {
                        let r = e[0];
                        if (1 === e.length) return r;
                        let t = () => {
                            let t = e.map(e => ({
                                useScope: e(),
                                scopeName: e.scopeName
                            }));
                            return function(e) {
                                let n = t.reduce((r, {
                                    useScope: t,
                                    scopeName: a
                                }) => {
                                    let n = t(e),
                                        l = n[`__scope${a}`];
                                    return { ...r,
                                        ...l
                                    }
                                }, {});
                                return (0, a.useMemo)(() => ({
                                    [`__scope${r.scopeName}`]: n
                                }), [n])
                            }
                        };
                        return t.scopeName = r.scopeName, t
                    }(n, ...r)]
                }(c),
                [p, v] = f(c),
                b = (0, a.forwardRef)((e, r) => {
                    let {
                        __scopeProgress: t,
                        value: n,
                        max: o,
                        getValueLabel: s = h,
                        ...i
                    } = e, u = N(o) ? o : 100, c = x(n, u) ? n : null, f = E(c) ? s(c, u) : void 0;
                    return (0, a.createElement)(p, {
                        scope: t,
                        value: c,
                        max: u
                    }, (0, a.createElement)(d.div, (0, l.Z)({
                        "aria-valuemax": u,
                        "aria-valuemin": 0,
                        "aria-valuenow": E(c) ? c : void 0,
                        "aria-valuetext": f,
                        role: "progressbar",
                        "data-state": y(c, u),
                        "data-value": null != c ? c : void 0,
                        "data-max": u
                    }, i, {
                        ref: r
                    })))
                });
            b.propTypes = {
                max(e, r, t) {
                    let a = e[r],
                        n = String(a);
                    return a && !N(a) ? Error(`Invalid prop \`max\` of value \`${n}\` supplied to \`${t}\`. Only numbers greater than 0 are valid max values. Defaulting to \`100\`.`) : null
                },
                value(e, r, t) {
                    let a = e[r],
                        n = String(a),
                        l = N(e.max) ? e.max : 100;
                    return null == a || x(a, l) ? null : Error(`Invalid prop \`value\` of value \`${n}\` supplied to \`${t}\`. The \`value\` prop must be:
  - a positive number
  - less than the value passed to \`max\` (or 100 if no \`max\` prop is set)
  - \`null\` if the progress is indeterminate.

Defaulting to \`null\`.`)
                }
            };
            let g = (0, a.forwardRef)((e, r) => {
                var t;
                let {
                    __scopeProgress: n,
                    ...o
                } = e, s = v("ProgressIndicator", n);
                return (0, a.createElement)(d.div, (0, l.Z)({
                    "data-state": y(s.value, s.max),
                    "data-value": null !== (t = s.value) && void 0 !== t ? t : void 0,
                    "data-max": s.max
                }, o, {
                    ref: r
                }))
            });

            function h(e, r) {
                return `${Math.round(e/r*100)}%`
            }

            function y(e, r) {
                return null == e ? "indeterminate" : e === r ? "complete" : "loading"
            }

            function E(e) {
                return "number" == typeof e
            }

            function N(e) {
                return E(e) && !isNaN(e) && e > 0
            }

            function x(e, r) {
                return E(e) && !isNaN(e) && e <= r && e >= 0
            }
            var w = t(29107);
            let _ = (null == globalThis ? void 0 : globalThis.document) ? a.useLayoutEffect : () => {},
                I = n["useId".toString()] || (() => void 0),
                P = 0,
                C = (0, w.j)(["relative", "h-sz-4 w-full", "transform-gpu overflow-hidden", "bg-on-background/dim-4"], {
                    variants: {
                        shape: {
                            square: [],
                            rounded: ["rounded-sm"]
                        }
                    }
                }),
                $ = (0, a.createContext)(null),
                S = () => {
                    let e = (0, a.useContext)($);
                    if (!e) throw Error("useProgress must be used within a Progress provider");
                    return e
                },
                R = (0, w.j)(["h-full w-full", "transition-transform duration-400"], {
                    variants: {
                        intent: {
                            basic: ["bg-basic"],
                            main: ["bg-main"],
                            support: ["bg-support"],
                            accent: ["bg-accent"],
                            success: ["bg-success"],
                            alert: ["bg-alert"],
                            danger: ["bg-error"],
                            info: ["bg-info"],
                            neutral: ["bg-neutral"]
                        },
                        shape: {
                            square: [],
                            rounded: ["rounded-sm"]
                        },
                        isIndeterminate: {
                            true: ["absolute", "-translate-x-1/2", "animate-standalone-indeterminate-bar"],
                            false: []
                        }
                    }
                }),
                k = (0, a.forwardRef)(({
                    className: e,
                    style: r,
                    ...t
                }, n) => {
                    let {
                        value: l,
                        max: o,
                        intent: s,
                        shape: i,
                        isIndeterminate: u
                    } = S();
                    return a.createElement(g, {
                        className: R({
                            className: e,
                            intent: s,
                            shape: i,
                            isIndeterminate: u
                        }),
                        style: { ...r,
                            ...!u && {
                                transform: `translateX(-${(o-l)/o*100}%)`
                            }
                        },
                        ref: n,
                        ...t
                    })
                });
            k.displayName = "Progress.Indicator";
            let L = (0, a.forwardRef)(({
                className: e,
                children: r = a.createElement(k, null),
                ...t
            }, n) => {
                let {
                    shape: l
                } = S();
                return a.createElement("div", {
                    className: C({
                        className: e,
                        shape: l
                    }),
                    ref: n,
                    ...t
                }, r)
            });
            L.displayName = "Progress.Bar";
            let D = (0, a.forwardRef)(({
                className: e,
                value: r,
                max: t = 100,
                shape: n = "square",
                intent: l = "basic",
                isIndeterminate: o = !1,
                children: s = a.createElement(L, null),
                ...i
            }, u) => {
                let [d, c] = (0, a.useState)(), f = (0, a.useMemo)(() => ({
                    value: r ? ? 0,
                    max: t,
                    intent: l,
                    shape: n,
                    isIndeterminate: o,
                    onLabelId: c
                }), [t, r, l, n, o, c]);
                return a.createElement($.Provider, {
                    "data-spark-component": "progress",
                    value: f
                }, a.createElement(b, {
                    ref: u,
                    className: (0, w.cx)("flex flex-col gap-sm", e),
                    value: r,
                    "aria-labelledby": d,
                    max: t,
                    ...i
                }, s))
            });
            D.displayName = "Progress";
            let M = (0, a.forwardRef)(({
                id: e,
                children: r,
                ...t
            }, n) => {
                let l = function(e) {
                        let [r, t] = a.useState(I());
                        return _(() => {
                            e || t(e => null != e ? e : String(P++))
                        }, [e]), e || (r ? `radix-${r}` : "")
                    }(e),
                    {
                        onLabelId: o
                    } = S(),
                    s = (0, a.useCallback)(e => {
                        o(e ? l : void 0)
                    }, [l, o]),
                    i = function(...e) {
                        return (0, a.useMemo)(() => (function(...e) {
                            return r => {
                                e.forEach(e => (function(e, r) {
                                    if (null != e) {
                                        if ("function" != typeof e) try {
                                            e.current = r
                                        } catch {
                                            throw Error(`Cannot assign value '${r}' to ref '${e}'`)
                                        } else e(r)
                                    }
                                })(e, r))
                            }
                        })(...e), e)
                    }(n, s);
                return a.createElement("span", {
                    id: l,
                    className: "text-body-2 text-on-surface",
                    ref: i,
                    ...t
                }, r)
            });
            M.displayName = "Progress.Label";
            let Z = Object.assign(D, {
                Label: M,
                Bar: L,
                Indicator: k
            });
            Z.displayName = "Progress", L.displayName = "Progress.Bar", k.displayName = "Progress.Indicator", M.displayName = "Progress.Label"
        }
    }
]);