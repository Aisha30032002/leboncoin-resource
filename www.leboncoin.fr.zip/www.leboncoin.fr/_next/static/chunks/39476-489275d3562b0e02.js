! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "e710de95-827a-47ca-a418-3ecb0216325b", e._sentryDebugIdIdentifier = "sentry-dbid-e710de95-827a-47ca-a418-3ecb0216325b")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
}, (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [39476], {
        11869: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgHouse"
                }, r.createElement("path", {
                    d: "M23.47 10.85L13.43.61a2 2 0 00-2.86 0L.53 10.85a1.73 1.73 0 00-.43 1.87 1.66 1.66 0 001.48 1.06h1.06v7.88A2.24 2.24 0 004.76 24h3.7a2.24 2.24 0 002.11-2.34v-5.31h2.86v5.31A2.24 2.24 0 0015.54 24h3.6a2.39 2.39 0 002.22-2.22v-7.89h1.06a1.6 1.6 0 001.48-1.17 1.73 1.73 0 00-.43-1.87z"
                })))
            }
            s.displayName = "SvgHouse", s.defaultProps = {
                viewBox: "0 0 24 24"
            }
        },
        70541: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiBakery"
                }, r.createElement("g", {
                    fill: "#fff"
                }, r.createElement("path", {
                    stroke: "#1A1A1A",
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852h0l-13.269 21.69L3.823 24.94A15.052 15.052 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.514 15.514 0 0117 1.5z"
                }), r.createElement("g", {
                    fill: "#1A1A1A"
                }, r.createElement("path", {
                    d: "M15.749 16.547a13.79 13.79 0 00-1.634.222.52.52 0 00-.397.491v1.266a.812.812 0 01-1.624 0v-.763c0-.224-.17-.34-.375-.25-2.202.968-3.518 2.44-4.216 3.585-.36.59-.381 1.358-.02 1.897.363.539.998.809 1.66.809h15.646c.662 0 1.297-.27 1.659-.81.362-.538.341-1.305-.02-1.896-.697-1.144-2.013-2.617-4.216-3.585-.205-.09-.374.026-.374.25v.763a.812.812 0 01-1.624 0V17.26a.52.52 0 00-.397-.491 13.789 13.789 0 00-1.634-.222.375.375 0 00-.405.38v1.193a.812.812 0 01-1.624 0v-1.193a.375.375 0 00-.405-.38zM13.685 10a.812.812 0 00-.693.449c-.252.503-.352.984-.31 1.408.043.424.208.74.31.942.101.203.139.294.147.378.008.083.007.21-.147.52a.812.812 0 101.452.726c.252-.503.352-.984.31-1.408-.043-.425-.208-.74-.31-.942-.101-.203-.139-.295-.147-.378-.009-.083-.007-.21.147-.52a.812.812 0 00-.76-1.175zM16.932 10a.812.812 0 00-.693.449c-.25.503-.351.984-.309 1.408.043.424.208.74.31.942.101.203.139.294.147.378.008.083.007.21-.148.52a.812.812 0 101.453.726c.252-.503.352-.984.31-1.408-.043-.425-.208-.74-.31-.942-.101-.203-.14-.295-.147-.378-.009-.083-.007-.21.147-.52a.812.812 0 00-.76-1.175zM20.18 10a.812.812 0 00-.693.449c-.251.503-.351.984-.309 1.408.043.424.208.74.31.942.1.203.139.294.147.378.008.083.007.21-.148.52a.812.812 0 101.453.726c.251-.503.352-.984.31-1.408-.043-.425-.209-.74-.31-.942-.102-.203-.14-.295-.148-.378-.008-.083-.007-.21.148-.52A.812.812 0 0020.18 10z"
                })))))
            }
            s.displayName = "SvgPoiBakery", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        3315: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiBeach"
                }, r.createElement("g", {
                    fill: "#fff"
                }, r.createElement("path", {
                    stroke: "currentColor",
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852h0l-13.269 21.69L3.823 24.94A15.044 15.044 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.515 15.515 0 0117 1.5z"
                }), r.createElement("path", {
                    fill: "currentColor",
                    d: "M19.15 17.523l6.517 6.517a1.162 1.162 0 010 1.627 1.16 1.16 0 01-1.626 0l-6.516-6.518 1.625-1.626zM9.358 9.39c-1.479 4.47-.284 9.453 3.264 13.013l-1.444 1.445c-1.013 1.023-2.753.875-3.504-.353C4.98 19.07 5.536 13.224 9.358 9.39zm.022-.022c3.424-.433 7.836 1.33 11.397 4.89l-6.517 6.518c-3.56-3.572-5.322-7.973-4.89-11.397zm.012-.012c3.833-3.823 9.678-4.38 14.104-1.672 1.227.74 1.364 2.491.351 3.504l-1.444 1.444c-3.56-3.56-8.542-4.754-13.01-3.276z"
                }))))
            }
            s.displayName = "SvgPoiBeach", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        90642: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiCulture"
                }, r.createElement("g", {
                    fill: "#fff"
                }, r.createElement("path", {
                    stroke: "currentColor",
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852h0l-13.269 21.69L3.823 24.94A15.044 15.044 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.515 15.515 0 0117 1.5z"
                }), r.createElement("path", {
                    fill: "currentColor",
                    d: "M27 15v-2L17 6 7 13v2h2v9H7v2h20v-2h-2v-9h2zm-6 7h-2v-4l-2 3-2-3v4h-2v-7h2l2 3 2-3h2v7z"
                }))))
            }
            s.displayName = "SvgPoiCulture", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        94307: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiDefault"
                }, r.createElement("path", {
                    fill: "#fff",
                    stroke: "currentColor",
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852h0l-13.269 21.69L3.823 24.94A15.044 15.044 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.515 15.515 0 0117 1.5z"
                })))
            }
            s.displayName = "SvgPoiDefault", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        80925: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiEducation"
                }, r.createElement("g", {
                    fill: "#fff",
                    stroke: "#4183D7"
                }, r.createElement("path", {
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852l-13.269 21.69L3.823 24.94A15.052 15.052 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.514 15.514 0 0117 1.5z"
                }), r.createElement("path", {
                    d: "M16.924 10.032l.08.042 9.769 6.294.074.059a.52.52 0 01.057.668l-.063.072-.845.793L26 18v4a.5.5 0 01-.992.09L25 22v-3.104l-2 1.88v3.192C23 25.275 20.365 26 17 26c-3.27 0-5.849-.684-5.994-1.921L11 23.968v-3.072l-.038-.03-3.81-3.705-.06-.071a.52.52 0 01.054-.657l.072-.059 9.28-6.294.08-.044a.455.455 0 01.346-.004zM17 22.952l-.253.002c-2.598.038-4.747.65-4.747 1.014 0 .376 2.29 1.016 5 1.016s5-.64 5-1.016-2.29-1.016-5-1.016zm-4.944-3.319L12 19.67v3.086c1.004-.503 2.678-.786 4.63-.817l.37-.003.271.002c1.996.023 3.71.306 4.73.818L22 19.668l-.056-.036c-3.294-2.155-6.56-2.155-9.888.001zm4.706-8.543L8.25 16.865 11 19.54l.001-.156.004-.061.007-.04.013-.045a.464.464 0 01.015-.04l.02-.042a.508.508 0 01.161-.181c3.854-2.633 7.742-2.633 11.56 0 .11.077.184.192.21.322l.009.1v.037l2.73-2.565-8.968-5.779z",
                    strokeWidth: .5,
                    fill: "#4183D7",
                    mask: "url(#poi-education_svg__b)"
                }))))
            }
            s.displayName = "SvgPoiEducation", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        41194: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiGrocery"
                }, r.createElement("g", {
                    fill: "#fff"
                }, r.createElement("path", {
                    stroke: "#1A1A1A",
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852h0l-13.269 21.69L3.823 24.94A15.052 15.052 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.514 15.514 0 0117 1.5z"
                }), r.createElement("path", {
                    d: "M13.09 23c.99 0 1.8.81 1.8 1.8s-.81 1.8-1.8 1.8c-.988 0-1.79-.81-1.79-1.8s.802-1.8 1.79-1.8zm8.998 0c.989 0 1.799.81 1.799 1.8s-.81 1.8-1.8 1.8c-.989 0-1.79-.81-1.79-1.8s.801-1.8 1.79-1.8zM10.068 8.6c.342 0 .666.198.81.513l.603 1.287h13.315a.897.897 0 01.783 1.332l-3.222 5.841c-.306.558-.9.927-1.574.927H14.08l-.989 1.8h9.896c.495 0 .9.405.9.9s-.405.9-.9.9h-9.896c-1.368 0-2.231-1.467-1.574-2.673l1.214-2.196-3.24-6.83h-.898a.903.903 0 01-.9-.9c0-.496.405-.9.9-.9z",
                    fill: "#1A1A1A"
                }))))
            }
            s.displayName = "SvgPoiGrocery", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        67802: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiHobbies"
                }, r.createElement("g", {
                    fill: "#fff",
                    fillRule: "evenodd"
                }, r.createElement("path", {
                    stroke: "currentColor",
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852h0l-13.269 21.69L3.823 24.94A15.044 15.044 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.515 15.515 0 0117 1.5z"
                }), r.createElement("path", {
                    fill: "currentColor",
                    d: "M17.09 23.364c.783 0 1.446.49 1.7 1.172.5-.109.983-.263 1.446-.472l-1.6-3.773a3.53 3.53 0 01-1.545.345 3.538 3.538 0 01-1.546-.345l-1.6 3.773a7.28 7.28 0 001.446.472 1.813 1.813 0 011.7-1.172m5.682-1.128c-.228-.309-.4-.69-.4-1.145a1.83 1.83 0 011.818-1.818l.282.027c.227-.727.345-1.5.345-2.3a7.4 7.4 0 00-.345-2.273h-.282a1.811 1.811 0 01-1.818-1.818c0-.454.145-.827.4-1.145a7.697 7.697 0 00-3.982-2.3 1.814 1.814 0 01-1.7 1.172c-.782 0-1.446-.49-1.7-1.172a7.697 7.697 0 00-3.982 2.3c.255.318.41.718.41 1.145A1.818 1.818 0 0110 14.727h-.29A7.417 7.417 0 009.364 17c0 .81.127 1.582.354 2.318l.282-.045c1.01 0 1.818.836 1.818 1.818 0 .454-.145.845-.4 1.154.291.319.618.61.955.873l1.727-4.054a3.636 3.636 0 115.982 0l1.727 4.054c.346-.263.664-.563.964-.882M17.09 27c-.91 0-1.673-.673-1.818-1.555a8.643 8.643 0 01-1.682-.545L12.7 27h-1.973l1.282-3.018a7.848 7.848 0 01-1.318-1.191c-.218.09-.446.118-.691.118a1.818 1.818 0 01-1.818-1.818 1.8 1.8 0 01.7-1.41 8.62 8.62 0 01-.009-5.336A1.826 1.826 0 0110 11.091c.236 0 .464.054.664.136a8.542 8.542 0 014.609-2.672C15.418 7.673 16.182 7 17.09 7s1.673.673 1.818 1.555a8.557 8.557 0 014.6 2.663c.21-.082.436-.127.682-.127 1.004 0 1.818.814 1.818 1.818 0 .582-.282 1.1-.7 1.427a8.72 8.72 0 010 5.328c.418.336.7.854.7 1.427a1.806 1.806 0 01-1.818 1.818c-.246 0-.473-.036-.691-.127-.4.445-.845.845-1.327 1.2L23.455 27h-1.973l-.891-2.1a8.687 8.687 0 01-1.682.545A1.854 1.854 0 0117.091 27z"
                }))))
            }
            s.displayName = "SvgPoiHobbies", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        71462: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiNature"
                }, r.createElement("g", {
                    fill: "#fff"
                }, r.createElement("path", {
                    stroke: "currentColor",
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852h0l-13.269 21.69L3.823 24.94A15.044 15.044 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.515 15.515 0 0117 1.5z"
                }), r.createElement("path", {
                    fill: "currentColor",
                    d: "M18.2 10.405l-2.95 3.93 2.25 3c.33.44.24 1.07-.2 1.4a.994.994 0 01-1.4-.2c-1.05-1.4-2.31-3.07-3.1-4.14-.4-.53-1.2-.53-1.6 0l-4 5.33c-.49.67-.02 1.61.8 1.61h18c.82 0 1.29-.94.8-1.6l-7-9.33a.993.993 0 00-1.6 0z"
                }))))
            }
            s.displayName = "SvgPoiNature", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        26440: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiSkiLifts"
                }, r.createElement("g", {
                    fill: "#fff"
                }, r.createElement("path", {
                    stroke: "currentColor",
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852h0l-13.269 21.69L3.823 24.94A15.044 15.044 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.515 15.515 0 0117 1.5z"
                }), r.createElement("path", {
                    fill: "currentColor",
                    d: "M13.108 13.84l2.077 3.137h3.465c.344 0 .645.228.739.559l1.46 5.175 3.993-1.41.018-.009c.325-.168.57-.527.724-1.135l.02-.08a.767.767 0 111.495.347c-.25 1.077-.768 1.85-1.565 2.247l-.077.037-.032.015-11.985 4.233a.767.767 0 01-.553-1.431l.042-.016 6.396-2.26h-.093l-1.367-3.873-3.673.566a1.025 1.025 0 01-1.008-.445l-2.65-3.985a1.535 1.535 0 112.575-1.672zm-3.963 1.925l.025.034 3.244 4.81c.159.234.386.413.65.512.26.096.538.125.81.085l.075-.013 2.74-.532a.64.64 0 01.287 1.246l-.043.01-2.74.532a2.918 2.918 0 01-1.573-.13 2.623 2.623 0 01-1.21-.915l-.056-.08-3.244-4.81a.64.64 0 011.036-.749zM16.405 7c.425 0 .768.344.768.767v7.675h-1.535V7.767c0-.423.344-.767.768-.767zM10.01 8.79a1.79 1.79 0 110 3.58 1.79 1.79 0 010-3.579z"
                }))))
            }
            s.displayName = "SvgPoiSkiLifts", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        50932: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgPoiSkiStation"
                }, r.createElement("g", {
                    fill: "#fff"
                }, r.createElement("path", {
                    stroke: "currentColor",
                    strokeWidth: 3,
                    d: "M17 1.5c4.277 0 8.153 1.725 10.96 4.511 2.803 2.782 4.54 6.624 4.54 10.864 0 2.761-.745 5.498-2.188 7.852h0l-13.269 21.69L3.823 24.94A15.044 15.044 0 011.5 16.875c0-4.24 1.737-8.082 4.54-10.864A15.515 15.515 0 0117 1.5z"
                }), r.createElement("path", {
                    fill: "currentColor",
                    d: "M21.525 18.268a.708.708 0 01.485.874l-.005.018-1.26 4a.744.744 0 01-.916.493.707.707 0 01-.485-.874l.005-.018 1.26-4a.745.745 0 01.916-.493zm-.4-7.878c.898 0 1.696-.797 1.696-1.695A1.68 1.68 0 0021.126 7c-.898 0-1.695.798-1.695 1.695 0 .898.797 1.695 1.695 1.695m3.343 14.862c-.501.216-.917.348-1.25.396-.697.1-1.395.1-2.093-.1l-6.283-1.895 2.204-6.245a1 1 0 00-.174-.973l-2.13-2.554 2.893-1.596s1.096 2.892 1.196 3.191c.1.3.3.499.599.598l3.194.935a.918.918 0 001.14-.623l.003-.012a1.08 1.08 0 00-.602-1.276l-.046-.02.399-1.397a.726.726 0 00-.499-.897.703.703 0 00-.868.482l-.006.023-.322 1.29-1.197-.499-1.396-3.889a1.76 1.76 0 00-2.293-.798l-4.588 2.493c-.897.499-1.196 1.596-.698 2.394.1.199 2.992 3.19 2.992 3.19l-1.695 5.685-6.143-1.807a.626.626 0 00-.778.424l-.01.036a.707.707 0 00.489.837l14.22 4.2c1.008.296 2.465.17 4.372-.38a.605.605 0 00.365-.868.78.78 0 00-.995-.345z"
                }))))
            }
            s.displayName = "SvgPoiSkiStation", s.defaultProps = {
                viewBox: "0 0 34 48"
            }
        },
        37717: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return s
                }
            });
            var n, r = i(67294);

            function s(e) {
                return n || (n = r.createElement("symbol", {
                    id: "SvgSpotlight"
                }, r.createElement("path", {
                    d: "M18.43 0H5.57A2.63 2.63 0 003 2.67V24l9-4 9 4V2.67A2.63 2.63 0 0018.43 0z"
                })))
            }
            s.displayName = "SvgSpotlight", s.defaultProps = {
                viewBox: "0 0 24 24"
            }
        },
        24873: function() {
            (function() {
                "use strict";

                function e(t) {
                    return this instanceof e ? (this._canvas = t = "string" == typeof t ? document.getElementById(t) : t, this._ctx = t.getContext("2d"), this._width = t.width, this._height = t.height, this._max = 1, void this.clear()) : new e(t)
                }
                e.prototype = {
                    defaultRadius: 25,
                    defaultGradient: {
                        .4: "blue",
                        .6: "cyan",
                        .7: "lime",
                        .8: "yellow",
                        1: "red"
                    },
                    data: function(e, t) {
                        return this._data = e, this
                    },
                    max: function(e) {
                        return this._max = e, this
                    },
                    add: function(e) {
                        return this._data.push(e), this
                    },
                    clear: function() {
                        return this._data = [], this
                    },
                    radius: function(e, t) {
                        t = t || 15;
                        var i = this._circle = document.createElement("canvas"),
                            n = i.getContext("2d"),
                            r = this._r = e + t;
                        return i.width = i.height = 2 * r, n.shadowOffsetX = n.shadowOffsetY = 200, n.shadowBlur = t, n.shadowColor = "black", n.beginPath(), n.arc(r - 200, r - 200, e, 0, 2 * Math.PI, !0), n.closePath(), n.fill(), this
                    },
                    gradient: function(e) {
                        var t = document.createElement("canvas"),
                            i = t.getContext("2d"),
                            n = i.createLinearGradient(0, 0, 0, 256);
                        for (var r in t.width = 1, t.height = 256, e) n.addColorStop(r, e[r]);
                        return i.fillStyle = n, i.fillRect(0, 0, 1, 256), this._grad = i.getImageData(0, 0, 1, 256).data, this
                    },
                    draw: function(e) {
                        this._circle || this.radius(this.defaultRadius), this._grad || this.gradient(this.defaultGradient);
                        var t = this._ctx;
                        t.clearRect(0, 0, this._width, this._height);
                        for (var i, n = 0, r = this._data.length; r > n; n++) i = this._data[n], t.globalAlpha = Math.max(i[2] / this._max, e || .05), t.drawImage(this._circle, i[0] - this._r, i[1] - this._r);
                        var s = t.getImageData(0, 0, this._width, this._height);
                        return this._colorize(s.data, this._grad), t.putImageData(s, 0, 0), this
                    },
                    _colorize: function(e, t) {
                        for (var i, n = 3, r = e.length; r > n; n += 4)(i = 4 * e[n]) && (e[n - 3] = t[i], e[n - 2] = t[i + 1], e[n - 1] = t[i + 2])
                    }
                }, window.simpleheat = e
            })(), L.HeatLayer = (L.Layer ? L.Layer : L.Class).extend({
                initialize: function(e, t) {
                    this._latlngs = e, L.setOptions(this, t)
                },
                setLatLngs: function(e) {
                    return this._latlngs = e, this.redraw()
                },
                addLatLng: function(e) {
                    return this._latlngs.push(e), this.redraw()
                },
                setOptions: function(e) {
                    return L.setOptions(this, e), this._heat && this._updateOptions(), this.redraw()
                },
                redraw: function() {
                    return !this._heat || this._frame || this._map._animating || (this._frame = L.Util.requestAnimFrame(this._redraw, this)), this
                },
                onAdd: function(e) {
                    this._map = e, this._canvas || this._initCanvas(), e._panes.overlayPane.appendChild(this._canvas), e.on("moveend", this._reset, this), e.options.zoomAnimation && L.Browser.any3d && e.on("zoomanim", this._animateZoom, this), this._reset()
                },
                onRemove: function(e) {
                    e.getPanes().overlayPane.removeChild(this._canvas), e.off("moveend", this._reset, this), e.options.zoomAnimation && e.off("zoomanim", this._animateZoom, this)
                },
                addTo: function(e) {
                    return e.addLayer(this), this
                },
                _initCanvas: function() {
                    var e = this._canvas = L.DomUtil.create("canvas", "leaflet-heatmap-layer leaflet-layer"),
                        t = L.DomUtil.testProp(["transformOrigin", "WebkitTransformOrigin", "msTransformOrigin"]);
                    e.style[t] = "50% 50%";
                    var i = this._map.getSize();
                    e.width = i.x, e.height = i.y;
                    var n = this._map.options.zoomAnimation && L.Browser.any3d;
                    L.DomUtil.addClass(e, "leaflet-zoom-" + (n ? "animated" : "hide")), this._heat = simpleheat(e), this._updateOptions()
                },
                _updateOptions: function() {
                    this._heat.radius(this.options.radius || this._heat.defaultRadius, this.options.blur), this.options.gradient && this._heat.gradient(this.options.gradient), this.options.max && this._heat.max(this.options.max)
                },
                _reset: function() {
                    var e = this._map.containerPointToLayerPoint([0, 0]);
                    L.DomUtil.setPosition(this._canvas, e);
                    var t = this._map.getSize();
                    this._heat._width !== t.x && (this._canvas.width = this._heat._width = t.x), this._heat._height !== t.y && (this._canvas.height = this._heat._height = t.y), this._redraw()
                },
                _redraw: function() {
                    var e, t, i, n, r, s, o, a, l, h = [],
                        u = this._heat._r,
                        _ = this._map.getSize(),
                        c = new L.Bounds(L.point([-u, -u]), _.add([u, u])),
                        d = void 0 === this.options.max ? 1 : this.options.max,
                        p = 1 / Math.pow(2, Math.max(0, Math.min((void 0 === this.options.maxZoom ? this._map.getMaxZoom() : this.options.maxZoom) - this._map.getZoom(), 12))),
                        f = u / 2,
                        m = [],
                        g = this._map._getMapPanePos(),
                        v = g.x % f,
                        y = g.y % f;
                    for (e = 0, t = this._latlngs.length; t > e; e++) i = this._map.latLngToContainerPoint(this._latlngs[e]), c.contains(i) && (r = Math.floor((i.x - v) / f) + 2, s = Math.floor((i.y - y) / f) + 2, l = (void 0 !== this._latlngs[e].alt ? this._latlngs[e].alt : void 0 !== this._latlngs[e][2] ? +this._latlngs[e][2] : 1) * p, m[s] = m[s] || [], (n = m[s][r]) ? (n[0] = (n[0] * n[2] + i.x * l) / (n[2] + l), n[1] = (n[1] * n[2] + i.y * l) / (n[2] + l), n[2] += l) : m[s][r] = [i.x, i.y, l]);
                    for (e = 0, t = m.length; t > e; e++)
                        if (m[e])
                            for (o = 0, a = m[e].length; a > o; o++)(n = m[e][o]) && h.push([Math.round(n[0]), Math.round(n[1]), Math.min(n[2], d)]);
                    this._heat.data(h).draw(this.options.minOpacity), this._frame = null
                },
                _animateZoom: function(e) {
                    var t = this._map.getZoomScale(e.zoom),
                        i = this._map._getCenterOffset(e.center)._multiplyBy(-t).subtract(this._map._getMapPanePos());
                    L.DomUtil.setTransform ? L.DomUtil.setTransform(this._canvas, i, t) : this._canvas.style[L.DomUtil.TRANSFORM] = L.DomUtil.getTranslateString(i) + " scale(" + t + ")"
                }
            }), L.heatLayer = function(e, t) {
                return new L.HeatLayer(e, t)
            }
        },
        56959: function() {
            "use strict";
            L.MarkerClusterGroup.include({
                _noanimationUnspiderfy: function() {
                    this._spiderfied && this._spiderfied.unspiderfy()
                }
            }), L.MarkerCluster.include({
                spiderfy: function() {
                    var e = this._group,
                        t = e.options;
                    if (e._spiderfied !== this && !e._inZoomAnimation) {
                        var i = this.getAllChildMarkers(),
                            n = e._map.latLngToLayerPoint(this._latlng),
                            r = [];
                        if (t.spiderfiedClassName)
                            for (var s in i) {
                                var o = i[s];
                                if (o.getIcon) {
                                    var a = o.getIcon();
                                    a && (a.options.className ? a.options.className.includes(t.spiderfiedClassName) || (a.options.className += " " + t.spiderfiedClassName) : a.options.className = t.spiderfiedClassName)
                                } else if (i[s].setStyle) {
                                    var l = i[s].options.className;
                                    i[s].setStyle({
                                        className: l + " " + t.spiderfiedClassName
                                    })
                                }
                            }
                        switch (e._unspiderfy(), e._spiderfied = this, this._clockHelpingGeometries = [], t.elementsPlacementStrategy) {
                            case "default":
                                r = i.length >= this._circleSpiralSwitchover ? this._generatePointsSpiral(i.length, n) : this._generatePointsCircle(i.length, n);
                                break;
                            case "spiral":
                                r = this._generatePointsSpiral(i.length, n);
                                break;
                            case "one-circle":
                                r = this._generatePointsCircle(i.length, n);
                                break;
                            case "concentric":
                                r = this._generatePointsConcentricCircles(i.length, n);
                                break;
                            case "clock":
                                r = this._generatePointsClocksCircles(i.length, n, !1);
                                break;
                            case "clock-concentric":
                                r = this._generatePointsClocksCircles(i.length, n, !0);
                                break;
                            case "original-locations":
                                r = this._getOriginalLocations(i, e._map)
                        }
                        this._animationSpiderfy(i, r)
                    }
                },
                unspiderfy: function(e) {
                    this._removeClockHelpingCircles(), this._group._inZoomAnimation || (this._animationUnspiderfy(e), this._group._spiderfied = null)
                },
                _generatePointsCircle: function(e, t) {
                    var i, n, r = this._group.options.spiderfyDistanceMultiplier * this._circleFootSeparation * (2 + e) / this._2PI,
                        s = this._2PI / e,
                        o = [];
                    for (o.length = e, i = e - 1; i >= 0; i--) n = this._circleStartAngle + i * s, o[i] = new L.Point(t.x + r * Math.cos(n), t.y + r * Math.sin(n))._round();
                    return this._createHelpingCircle(t, r), o
                },
                _generatePointsSpiral: function(e, t) {
                    var i, n = this._group.options.spiderfyDistanceMultiplier,
                        r = n * this._spiralFootSeparation,
                        s = n * this._spiralLengthFactor * this._2PI,
                        o = [],
                        a = 0,
                        l = n * this._spiralLengthStart;
                    for (o.length = e, i = e - 1; i >= 0; i--) a += r / l + 5e-4 * i, o[i] = new L.Point(t.x + l * Math.cos(a), t.y + l * Math.sin(a))._round(), l += s / a;
                    return o
                },
                _regularPolygonVertexPlacement: function(e, t, i, n) {
                    var r = this._2PI / t * e;
                    return 2 !== t && (r -= 1.6), new L.Point(i.x + Math.cos(r) * n, i.y + Math.sin(r) * n)._round()
                },
                _generatePointsClocksCircles: function(e, t, i) {
                    var n = [],
                        r = this._group.options,
                        s = r.firstCircleElements,
                        o = 1.5 * this._circleFootSeparation,
                        a = r.spiderfyDistanceMultiplier,
                        l = r.spiderfyDistanceSurplus,
                        h = r.elementsMultiplier,
                        u = 1,
                        _ = s,
                        c = o,
                        d = 0;
                    this._createHelpingCircle(t, c);
                    for (var p = 1; p <= e; p++) {
                        var f = p - d;
                        f > _ && (u += 1, d += _, f = p - d, _ = Math.floor(_ * h), c = (l + c) * a, this._createHelpingCircle(t, c)), i && 1 === u ? n[p - 1] = this._regularPolygonVertexPlacement(f - 1, Math.min(s, e), t, c) : n[p - 1] = this._regularPolygonVertexPlacement(f - 1, _, t, c)
                    }
                    return n
                },
                _createHelpingCircle: function(e, t) {
                    var i = this._group,
                        n = i.options;
                    if (n.helpingCircles) {
                        var r = {
                            radius: t
                        };
                        n.clockHelpingCircleOptions.fill || (n.clockHelpingCircleOptions.fillColor = "none"), L.extend(r, n.clockHelpingCircleOptions);
                        var s = new L.CircleMarker(i._map.layerPointToLatLng(e), r);
                        i._featureGroup.addLayer(s), this._clockHelpingGeometries.push(s)
                    }
                },
                _generatePointsConcentricCircles: function(e, t) {
                    var i = this,
                        n = this._group.options,
                        r = [],
                        s = n.firstCircleElements,
                        o = 1.5 * this._circleFootSeparation,
                        a = n.spiderfyDistanceMultiplier,
                        l = n.elementsMultiplier,
                        h = n.spiderfyDistanceSurplus,
                        u = Math.round(s * l),
                        _ = [{
                            distance: o,
                            noElements: 0
                        }, {
                            distance: (h + o) * a,
                            noElements: 0
                        }, {
                            distance: (2 * h + o) * a * a,
                            noElements: 0
                        }, {
                            distance: (3 * h + o) * a * a * a,
                            noElements: 0
                        }];
                    e > s && (_[1].noElements = u, (s < e && e < 2 * s || s + u < e && e < 2 * s + u) && (_[1].noElements = s)), e > s + Math.round(s * l) && (_[2].noElements = Math.round(s * l)), e > s + 2 * Math.round(s * l) && (_[2].noElements = Math.round(s * l * l)), e > s + Math.round(s * l) + Math.round(s * l * l) && (_[2].noElements = Math.round(s * l)), e > s + 2 * Math.round(s * l) + Math.round(s * l * l) && (_[2].noElements = Math.round(s * l * l)), _[0].noElements = Math.min(e - _[1].noElements - _[2].noElements, s), _[3].noElements = Math.max(e - _[0].noElements - _[1].noElements - _[2].noElements, 0);
                    for (var c = 0, d = _[0], p = 1; p <= e; p++) _[1].noElements > 0 && (p > _[0].noElements && (d = _[1], c = _[0].noElements), p > _[0].noElements + _[1].noElements && _[2].noElements > 0 && (d = _[2], c = _[0].noElements + _[1].noElements), p > _[0].noElements + _[1].noElements + _[2].noElements && _[3].noElements > 0 && (d = _[3], c = _[0].noElements - _[1].noElements - _[2].noElements)), r[p - 1] = this._regularPolygonVertexPlacement(p - c, d.noElements, t, d.distance);
                    return _.filter(function(e) {
                        return e.noElements
                    }).map(function(e) {
                        return i._createHelpingCircle(t, e.distance)
                    }), r
                },
                _removeClockHelpingCircles: function(e) {
                    if (this._group.options.helpingCircles)
                        for (var t in this._clockHelpingGeometries) this._group._featureGroup.removeLayer(this._clockHelpingGeometries[t])
                },
                _getOriginalLocations: function(e, t) {
                    var i = [];
                    return e.forEach(function(e) {
                        i.push(t.latLngToLayerPoint(e.getLatLng()))
                    }), i
                }
            }), L.MarkerClusterGroup.include({
                options: {
                    maxClusterRadius: 80,
                    iconCreateFunction: null,
                    clusterPane: L.Marker.prototype.options.pane,
                    spiderfyOnMaxZoom: !0,
                    showCoverageOnHover: !0,
                    zoomToBoundsOnClick: !0,
                    singleMarkerMode: !1,
                    disableClusteringAtZoom: null,
                    spiderfiedClassName: !1,
                    removeOutsideVisibleBounds: !0,
                    elementsPlacementStrategy: "clock-concentric",
                    firstCircleElements: 10,
                    elementsMultiplier: 1.5,
                    spiderfyDistanceSurplus: 30,
                    helpingCircles: !0,
                    clockHelpingCircleOptions: {
                        color: "grey",
                        dashArray: "5",
                        fillOpacity: 0,
                        opacity: .5,
                        weight: 3
                    },
                    animate: !1,
                    animateAddingMarkers: !1,
                    spiderfyDistanceMultiplier: 1,
                    spiderLegPolylineOptions: {
                        weight: 1.5,
                        color: "#222",
                        opacity: .5
                    },
                    chunkedLoading: !1,
                    chunkInterval: 200,
                    chunkDelay: 50,
                    chunkProgress: null,
                    polygonOptions: {}
                }
            })
        },
        95732: function(e, t) {
            var i, n, r;
            i = t, n = L.MarkerClusterGroup = L.FeatureGroup.extend({
                options: {
                    maxClusterRadius: 80,
                    iconCreateFunction: null,
                    clusterPane: L.Marker.prototype.options.pane,
                    spiderfyOnEveryZoom: !1,
                    spiderfyOnMaxZoom: !0,
                    showCoverageOnHover: !0,
                    zoomToBoundsOnClick: !0,
                    singleMarkerMode: !1,
                    disableClusteringAtZoom: null,
                    removeOutsideVisibleBounds: !0,
                    animate: !0,
                    animateAddingMarkers: !1,
                    spiderfyShapePositions: null,
                    spiderfyDistanceMultiplier: 1,
                    spiderLegPolylineOptions: {
                        weight: 1.5,
                        color: "#222",
                        opacity: .5
                    },
                    chunkedLoading: !1,
                    chunkInterval: 200,
                    chunkDelay: 50,
                    chunkProgress: null,
                    polygonOptions: {}
                },
                initialize: function(e) {
                    L.Util.setOptions(this, e), this.options.iconCreateFunction || (this.options.iconCreateFunction = this._defaultIconCreateFunction), this._featureGroup = L.featureGroup(), this._featureGroup.addEventParent(this), this._nonPointGroup = L.featureGroup(), this._nonPointGroup.addEventParent(this), this._inZoomAnimation = 0, this._needsClustering = [], this._needsRemoving = [], this._currentShownBounds = null, this._queue = [], this._childMarkerEventHandlers = {
                        dragstart: this._childMarkerDragStart,
                        move: this._childMarkerMoved,
                        dragend: this._childMarkerDragEnd
                    };
                    var t = L.DomUtil.TRANSITION && this.options.animate;
                    L.extend(this, t ? this._withAnimation : this._noAnimation), this._markerCluster = t ? L.MarkerCluster : L.MarkerClusterNonAnimated
                },
                addLayer: function(e) {
                    if (e instanceof L.LayerGroup) return this.addLayers([e]);
                    if (!e.getLatLng) return this._nonPointGroup.addLayer(e), this.fire("layeradd", {
                        layer: e
                    }), this;
                    if (!this._map) return this._needsClustering.push(e), this.fire("layeradd", {
                        layer: e
                    }), this;
                    if (this.hasLayer(e)) return this;
                    this._unspiderfy && this._unspiderfy(), this._addLayer(e, this._maxZoom), this.fire("layeradd", {
                        layer: e
                    }), this._topClusterLevel._recalculateBounds(), this._refreshClustersIcons();
                    var t = e,
                        i = this._zoom;
                    if (e.__parent)
                        for (; t.__parent._zoom >= i;) t = t.__parent;
                    return this._currentShownBounds.contains(t.getLatLng()) && (this.options.animateAddingMarkers ? this._animationAddLayer(e, t) : this._animationAddLayerNonAnimated(e, t)), this
                },
                removeLayer: function(e) {
                    return e instanceof L.LayerGroup ? this.removeLayers([e]) : e.getLatLng ? this._map ? (e.__parent && (this._unspiderfy && (this._unspiderfy(), this._unspiderfyLayer(e)), this._removeLayer(e, !0), this.fire("layerremove", {
                        layer: e
                    }), this._topClusterLevel._recalculateBounds(), this._refreshClustersIcons(), e.off(this._childMarkerEventHandlers, this), this._featureGroup.hasLayer(e) && (this._featureGroup.removeLayer(e), e.clusterShow && e.clusterShow())), this) : (!this._arraySplice(this._needsClustering, e) && this.hasLayer(e) && this._needsRemoving.push({
                        layer: e,
                        latlng: e._latlng
                    }), this.fire("layerremove", {
                        layer: e
                    }), this) : (this._nonPointGroup.removeLayer(e), this.fire("layerremove", {
                        layer: e
                    }), this)
                },
                addLayers: function(e, t) {
                    if (!L.Util.isArray(e)) return this.addLayer(e);
                    var i, n = this._featureGroup,
                        r = this._nonPointGroup,
                        s = this.options.chunkedLoading,
                        o = this.options.chunkInterval,
                        a = this.options.chunkProgress,
                        l = e.length,
                        h = 0,
                        u = !0;
                    if (this._map) {
                        var _ = new Date().getTime(),
                            c = L.bind(function() {
                                var d = new Date().getTime();
                                for (this._map && this._unspiderfy && this._unspiderfy(); h < l && !(s && h % 200 == 0 && new Date().getTime() - d > o); h++) {
                                    if ((i = e[h]) instanceof L.LayerGroup) {
                                        u && (e = e.slice(), u = !1), this._extractNonGroupLayers(i, e), l = e.length;
                                        continue
                                    }
                                    if (!i.getLatLng) {
                                        r.addLayer(i), t || this.fire("layeradd", {
                                            layer: i
                                        });
                                        continue
                                    }
                                    if (!this.hasLayer(i) && (this._addLayer(i, this._maxZoom), t || this.fire("layeradd", {
                                            layer: i
                                        }), i.__parent && 2 === i.__parent.getChildCount())) {
                                        var p = i.__parent.getAllChildMarkers(),
                                            f = p[0] === i ? p[1] : p[0];
                                        n.removeLayer(f)
                                    }
                                }
                                a && a(h, l, new Date().getTime() - _), h === l ? (this._topClusterLevel._recalculateBounds(), this._refreshClustersIcons(), this._topClusterLevel._recursivelyAddChildrenToMap(null, this._zoom, this._currentShownBounds)) : setTimeout(c, this.options.chunkDelay)
                            }, this);
                        c()
                    } else
                        for (var d = this._needsClustering; h < l; h++) {
                            if ((i = e[h]) instanceof L.LayerGroup) {
                                u && (e = e.slice(), u = !1), this._extractNonGroupLayers(i, e), l = e.length;
                                continue
                            }
                            if (!i.getLatLng) {
                                r.addLayer(i);
                                continue
                            }
                            this.hasLayer(i) || d.push(i)
                        }
                    return this
                },
                removeLayers: function(e) {
                    var t, i, n = e.length,
                        r = this._featureGroup,
                        s = this._nonPointGroup,
                        o = !0;
                    if (!this._map) {
                        for (t = 0; t < n; t++) {
                            if ((i = e[t]) instanceof L.LayerGroup) {
                                o && (e = e.slice(), o = !1), this._extractNonGroupLayers(i, e), n = e.length;
                                continue
                            }
                            this._arraySplice(this._needsClustering, i), s.removeLayer(i), this.hasLayer(i) && this._needsRemoving.push({
                                layer: i,
                                latlng: i._latlng
                            }), this.fire("layerremove", {
                                layer: i
                            })
                        }
                        return this
                    }
                    if (this._unspiderfy) {
                        this._unspiderfy();
                        var a = e.slice(),
                            l = n;
                        for (t = 0; t < l; t++) {
                            if ((i = a[t]) instanceof L.LayerGroup) {
                                this._extractNonGroupLayers(i, a), l = a.length;
                                continue
                            }
                            this._unspiderfyLayer(i)
                        }
                    }
                    for (t = 0; t < n; t++) {
                        if ((i = e[t]) instanceof L.LayerGroup) {
                            o && (e = e.slice(), o = !1), this._extractNonGroupLayers(i, e), n = e.length;
                            continue
                        }
                        if (!i.__parent) {
                            s.removeLayer(i), this.fire("layerremove", {
                                layer: i
                            });
                            continue
                        }
                        this._removeLayer(i, !0, !0), this.fire("layerremove", {
                            layer: i
                        }), r.hasLayer(i) && (r.removeLayer(i), i.clusterShow && i.clusterShow())
                    }
                    return this._topClusterLevel._recalculateBounds(), this._refreshClustersIcons(), this._topClusterLevel._recursivelyAddChildrenToMap(null, this._zoom, this._currentShownBounds), this
                },
                clearLayers: function() {
                    return this._map || (this._needsClustering = [], this._needsRemoving = [], delete this._gridClusters, delete this._gridUnclustered), this._noanimationUnspiderfy && this._noanimationUnspiderfy(), this._featureGroup.clearLayers(), this._nonPointGroup.clearLayers(), this.eachLayer(function(e) {
                        e.off(this._childMarkerEventHandlers, this), delete e.__parent
                    }, this), this._map && this._generateInitialClusters(), this
                },
                getBounds: function() {
                    var e = new L.LatLngBounds;
                    this._topClusterLevel && e.extend(this._topClusterLevel._bounds);
                    for (var t = this._needsClustering.length - 1; t >= 0; t--) e.extend(this._needsClustering[t].getLatLng());
                    return e.extend(this._nonPointGroup.getBounds()), e
                },
                eachLayer: function(e, t) {
                    var i, n, r, s = this._needsClustering.slice(),
                        o = this._needsRemoving;
                    for (this._topClusterLevel && this._topClusterLevel.getAllChildMarkers(s), n = s.length - 1; n >= 0; n--) {
                        for (i = !0, r = o.length - 1; r >= 0; r--)
                            if (o[r].layer === s[n]) {
                                i = !1;
                                break
                            }
                        i && e.call(t, s[n])
                    }
                    this._nonPointGroup.eachLayer(e, t)
                },
                getLayers: function() {
                    var e = [];
                    return this.eachLayer(function(t) {
                        e.push(t)
                    }), e
                },
                getLayer: function(e) {
                    var t = null;
                    return e = parseInt(e, 10), this.eachLayer(function(i) {
                        L.stamp(i) === e && (t = i)
                    }), t
                },
                hasLayer: function(e) {
                    if (!e) return !1;
                    var t, i = this._needsClustering;
                    for (t = i.length - 1; t >= 0; t--)
                        if (i[t] === e) return !0;
                    for (t = (i = this._needsRemoving).length - 1; t >= 0; t--)
                        if (i[t].layer === e) return !1;
                    return !!(e.__parent && e.__parent._group === this) || this._nonPointGroup.hasLayer(e)
                },
                zoomToShowLayer: function(e, t) {
                    var i = this._map;
                    "function" != typeof t && (t = function() {});
                    var n = function() {
                        (i.hasLayer(e) || i.hasLayer(e.__parent)) && !this._inZoomAnimation && (this._map.off("moveend", n, this), this.off("animationend", n, this), i.hasLayer(e) ? t() : e.__parent._icon && (this.once("spiderfied", t, this), e.__parent.spiderfy()))
                    };
                    e._icon && this._map.getBounds().contains(e.getLatLng()) ? t() : e.__parent._zoom < Math.round(this._map._zoom) ? (this._map.on("moveend", n, this), this._map.panTo(e.getLatLng())) : (this._map.on("moveend", n, this), this.on("animationend", n, this), e.__parent.zoomToBounds())
                },
                onAdd: function(e) {
                    var t, i, n;
                    if (this._map = e, !isFinite(this._map.getMaxZoom())) throw "Map has no maxZoom specified";
                    for (this._featureGroup.addTo(e), this._nonPointGroup.addTo(e), this._gridClusters || this._generateInitialClusters(), this._maxLat = e.options.crs.projection.MAX_LATITUDE, t = 0, i = this._needsRemoving.length; t < i; t++)(n = this._needsRemoving[t]).newlatlng = n.layer._latlng, n.layer._latlng = n.latlng;
                    for (t = 0, i = this._needsRemoving.length; t < i; t++) n = this._needsRemoving[t], this._removeLayer(n.layer, !0), n.layer._latlng = n.newlatlng;
                    this._needsRemoving = [], this._zoom = Math.round(this._map._zoom), this._currentShownBounds = this._getExpandedVisibleBounds(), this._map.on("zoomend", this._zoomEnd, this), this._map.on("moveend", this._moveEnd, this), this._spiderfierOnAdd && this._spiderfierOnAdd(), this._bindEvents(), i = this._needsClustering, this._needsClustering = [], this.addLayers(i, !0)
                },
                onRemove: function(e) {
                    e.off("zoomend", this._zoomEnd, this), e.off("moveend", this._moveEnd, this), this._unbindEvents(), this._map._mapPane.className = this._map._mapPane.className.replace(" leaflet-cluster-anim", ""), this._spiderfierOnRemove && this._spiderfierOnRemove(), delete this._maxLat, this._hideCoverage(), this._featureGroup.remove(), this._nonPointGroup.remove(), this._featureGroup.clearLayers(), this._map = null
                },
                getVisibleParent: function(e) {
                    for (var t = e; t && !t._icon;) t = t.__parent;
                    return t || null
                },
                _arraySplice: function(e, t) {
                    for (var i = e.length - 1; i >= 0; i--)
                        if (e[i] === t) return e.splice(i, 1), !0
                },
                _removeFromGridUnclustered: function(e, t) {
                    for (var i = this._map, n = this._gridUnclustered, r = Math.floor(this._map.getMinZoom()); t >= r && n[t].removeObject(e, i.project(e.getLatLng(), t)); t--);
                },
                _childMarkerDragStart: function(e) {
                    e.target.__dragStart = e.target._latlng
                },
                _childMarkerMoved: function(e) {
                    if (!this._ignoreMove && !e.target.__dragStart) {
                        var t = e.target._popup && e.target._popup.isOpen();
                        this._moveChild(e.target, e.oldLatLng, e.latlng), t && e.target.openPopup()
                    }
                },
                _moveChild: function(e, t, i) {
                    e._latlng = t, this.removeLayer(e), e._latlng = i, this.addLayer(e)
                },
                _childMarkerDragEnd: function(e) {
                    var t = e.target.__dragStart;
                    delete e.target.__dragStart, t && this._moveChild(e.target, t, e.target._latlng)
                },
                _removeLayer: function(e, t, i) {
                    var n = this._gridClusters,
                        r = this._gridUnclustered,
                        s = this._featureGroup,
                        o = this._map,
                        a = Math.floor(this._map.getMinZoom());
                    t && this._removeFromGridUnclustered(e, this._maxZoom);
                    var l, h = e.__parent,
                        u = h._markers;
                    for (this._arraySplice(u, e); h && (h._childCount--, h._boundsNeedUpdate = !0, !(h._zoom < a));) t && h._childCount <= 1 ? (l = h._markers[0] === e ? h._markers[1] : h._markers[0], n[h._zoom].removeObject(h, o.project(h._cLatLng, h._zoom)), r[h._zoom].addObject(l, o.project(l.getLatLng(), h._zoom)), this._arraySplice(h.__parent._childClusters, h), h.__parent._markers.push(l), l.__parent = h.__parent, h._icon && (s.removeLayer(h), i || s.addLayer(l))) : h._iconNeedsUpdate = !0, h = h.__parent;
                    delete e.__parent
                },
                _isOrIsParent: function(e, t) {
                    for (; t;) {
                        if (e === t) return !0;
                        t = t.parentNode
                    }
                    return !1
                },
                fire: function(e, t, i) {
                    if (t && t.layer instanceof L.MarkerCluster) {
                        if (t.originalEvent && this._isOrIsParent(t.layer._icon, t.originalEvent.relatedTarget)) return;
                        e = "cluster" + e
                    }
                    L.FeatureGroup.prototype.fire.call(this, e, t, i)
                },
                listens: function(e, t) {
                    return L.FeatureGroup.prototype.listens.call(this, e, t) || L.FeatureGroup.prototype.listens.call(this, "cluster" + e, t)
                },
                _defaultIconCreateFunction: function(e) {
                    var t = e.getChildCount(),
                        i = " marker-cluster-";
                    return t < 10 ? i += "small" : t < 100 ? i += "medium" : i += "large", new L.DivIcon({
                        html: "<div><span>" + t + "</span></div>",
                        className: "marker-cluster" + i,
                        iconSize: new L.Point(40, 40)
                    })
                },
                _bindEvents: function() {
                    var e = this._map,
                        t = this.options.spiderfyOnMaxZoom,
                        i = this.options.showCoverageOnHover,
                        n = this.options.zoomToBoundsOnClick,
                        r = this.options.spiderfyOnEveryZoom;
                    (t || n || r) && this.on("clusterclick clusterkeypress", this._zoomOrSpiderfy, this), i && (this.on("clustermouseover", this._showCoverage, this), this.on("clustermouseout", this._hideCoverage, this), e.on("zoomend", this._hideCoverage, this))
                },
                _zoomOrSpiderfy: function(e) {
                    var t = e.layer,
                        i = t;
                    if ("clusterkeypress" !== e.type || !e.originalEvent || 13 === e.originalEvent.keyCode) {
                        for (; 1 === i._childClusters.length;) i = i._childClusters[0];
                        i._zoom === this._maxZoom && i._childCount === t._childCount && this.options.spiderfyOnMaxZoom ? t.spiderfy() : this.options.zoomToBoundsOnClick && t.zoomToBounds(), this.options.spiderfyOnEveryZoom && t.spiderfy(), e.originalEvent && 13 === e.originalEvent.keyCode && this._map._container.focus()
                    }
                },
                _showCoverage: function(e) {
                    var t = this._map;
                    !this._inZoomAnimation && (this._shownPolygon && t.removeLayer(this._shownPolygon), e.layer.getChildCount() > 2 && e.layer !== this._spiderfied && (this._shownPolygon = new L.Polygon(e.layer.getConvexHull(), this.options.polygonOptions), t.addLayer(this._shownPolygon)))
                },
                _hideCoverage: function() {
                    this._shownPolygon && (this._map.removeLayer(this._shownPolygon), this._shownPolygon = null)
                },
                _unbindEvents: function() {
                    var e = this.options.spiderfyOnMaxZoom,
                        t = this.options.showCoverageOnHover,
                        i = this.options.zoomToBoundsOnClick,
                        n = this.options.spiderfyOnEveryZoom,
                        r = this._map;
                    (e || i || n) && this.off("clusterclick clusterkeypress", this._zoomOrSpiderfy, this), t && (this.off("clustermouseover", this._showCoverage, this), this.off("clustermouseout", this._hideCoverage, this), r.off("zoomend", this._hideCoverage, this))
                },
                _zoomEnd: function() {
                    this._map && (this._mergeSplitClusters(), this._zoom = Math.round(this._map._zoom), this._currentShownBounds = this._getExpandedVisibleBounds())
                },
                _moveEnd: function() {
                    if (!this._inZoomAnimation) {
                        var e = this._getExpandedVisibleBounds();
                        this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), this._zoom, e), this._topClusterLevel._recursivelyAddChildrenToMap(null, Math.round(this._map._zoom), e), this._currentShownBounds = e
                    }
                },
                _generateInitialClusters: function() {
                    var e = Math.ceil(this._map.getMaxZoom()),
                        t = Math.floor(this._map.getMinZoom()),
                        i = this.options.maxClusterRadius,
                        n = i;
                    "function" != typeof i && (n = function() {
                        return i
                    }), null !== this.options.disableClusteringAtZoom && (e = this.options.disableClusteringAtZoom - 1), this._maxZoom = e, this._gridClusters = {}, this._gridUnclustered = {};
                    for (var r = e; r >= t; r--) this._gridClusters[r] = new L.DistanceGrid(n(r)), this._gridUnclustered[r] = new L.DistanceGrid(n(r));
                    this._topClusterLevel = new this._markerCluster(this, t - 1)
                },
                _addLayer: function(e, t) {
                    var i, n, r = this._gridClusters,
                        s = this._gridUnclustered,
                        o = Math.floor(this._map.getMinZoom());
                    for (this.options.singleMarkerMode && this._overrideMarkerIcon(e), e.on(this._childMarkerEventHandlers, this); t >= o; t--) {
                        i = this._map.project(e.getLatLng(), t);
                        var a = r[t].getNearObject(i);
                        if (a) {
                            a._addChild(e), e.__parent = a;
                            return
                        }
                        if (a = s[t].getNearObject(i)) {
                            var l = a.__parent;
                            l && this._removeLayer(a, !1);
                            var h = new this._markerCluster(this, t, a, e);
                            r[t].addObject(h, this._map.project(h._cLatLng, t)), a.__parent = h, e.__parent = h;
                            var u = h;
                            for (n = t - 1; n > l._zoom; n--) u = new this._markerCluster(this, n, u), r[n].addObject(u, this._map.project(a.getLatLng(), n));
                            l._addChild(u), this._removeFromGridUnclustered(a, t);
                            return
                        }
                        s[t].addObject(e, i)
                    }
                    this._topClusterLevel._addChild(e), e.__parent = this._topClusterLevel
                },
                _refreshClustersIcons: function() {
                    this._featureGroup.eachLayer(function(e) {
                        e instanceof L.MarkerCluster && e._iconNeedsUpdate && e._updateIcon()
                    })
                },
                _enqueue: function(e) {
                    this._queue.push(e), this._queueTimeout || (this._queueTimeout = setTimeout(L.bind(this._processQueue, this), 300))
                },
                _processQueue: function() {
                    for (var e = 0; e < this._queue.length; e++) this._queue[e].call(this);
                    this._queue.length = 0, clearTimeout(this._queueTimeout), this._queueTimeout = null
                },
                _mergeSplitClusters: function() {
                    var e = Math.round(this._map._zoom);
                    this._processQueue(), this._zoom < e && this._currentShownBounds.intersects(this._getExpandedVisibleBounds()) ? (this._animationStart(), this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), this._zoom, this._getExpandedVisibleBounds()), this._animationZoomIn(this._zoom, e)) : this._zoom > e ? (this._animationStart(), this._animationZoomOut(this._zoom, e)) : this._moveEnd()
                },
                _getExpandedVisibleBounds: function() {
                    return this.options.removeOutsideVisibleBounds ? L.Browser.mobile ? this._checkBoundsMaxLat(this._map.getBounds()) : this._checkBoundsMaxLat(this._map.getBounds().pad(1)) : this._mapBoundsInfinite
                },
                _checkBoundsMaxLat: function(e) {
                    var t = this._maxLat;
                    return void 0 !== t && (e.getNorth() >= t && (e._northEast.lat = 1 / 0), e.getSouth() <= -t && (e._southWest.lat = -1 / 0)), e
                },
                _animationAddLayerNonAnimated: function(e, t) {
                    if (t === e) this._featureGroup.addLayer(e);
                    else if (2 === t._childCount) {
                        t._addToMap();
                        var i = t.getAllChildMarkers();
                        this._featureGroup.removeLayer(i[0]), this._featureGroup.removeLayer(i[1])
                    } else t._updateIcon()
                },
                _extractNonGroupLayers: function(e, t) {
                    var i, n = e.getLayers(),
                        r = 0;
                    for (t = t || []; r < n.length; r++) {
                        if ((i = n[r]) instanceof L.LayerGroup) {
                            this._extractNonGroupLayers(i, t);
                            continue
                        }
                        t.push(i)
                    }
                    return t
                },
                _overrideMarkerIcon: function(e) {
                    return e.options.icon = this.options.iconCreateFunction({
                        getChildCount: function() {
                            return 1
                        },
                        getAllChildMarkers: function() {
                            return [e]
                        }
                    })
                }
            }), L.MarkerClusterGroup.include({
                _mapBoundsInfinite: new L.LatLngBounds(new L.LatLng(-1 / 0, -1 / 0), new L.LatLng(1 / 0, 1 / 0))
            }), L.MarkerClusterGroup.include({
                _noAnimation: {
                    _animationStart: function() {},
                    _animationZoomIn: function(e, t) {
                        this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), e), this._topClusterLevel._recursivelyAddChildrenToMap(null, t, this._getExpandedVisibleBounds()), this.fire("animationend")
                    },
                    _animationZoomOut: function(e, t) {
                        this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), e), this._topClusterLevel._recursivelyAddChildrenToMap(null, t, this._getExpandedVisibleBounds()), this.fire("animationend")
                    },
                    _animationAddLayer: function(e, t) {
                        this._animationAddLayerNonAnimated(e, t)
                    }
                },
                _withAnimation: {
                    _animationStart: function() {
                        this._map._mapPane.className += " leaflet-cluster-anim", this._inZoomAnimation++
                    },
                    _animationZoomIn: function(e, t) {
                        var i, n = this._getExpandedVisibleBounds(),
                            r = this._featureGroup,
                            s = Math.floor(this._map.getMinZoom());
                        this._ignoreMove = !0, this._topClusterLevel._recursively(n, e, s, function(s) {
                            var o, a = s._latlng,
                                l = s._markers;
                            for (n.contains(a) || (a = null), s._isSingleParent() && e + 1 === t ? (r.removeLayer(s), s._recursivelyAddChildrenToMap(null, t, n)) : (s.clusterHide(), s._recursivelyAddChildrenToMap(a, t, n)), i = l.length - 1; i >= 0; i--) o = l[i], n.contains(o._latlng) || r.removeLayer(o)
                        }), this._forceLayout(), this._topClusterLevel._recursivelyBecomeVisible(n, t), r.eachLayer(function(e) {
                            e instanceof L.MarkerCluster || !e._icon || e.clusterShow()
                        }), this._topClusterLevel._recursively(n, e, t, function(e) {
                            e._recursivelyRestoreChildPositions(t)
                        }), this._ignoreMove = !1, this._enqueue(function() {
                            this._topClusterLevel._recursively(n, e, s, function(e) {
                                r.removeLayer(e), e.clusterShow()
                            }), this._animationEnd()
                        })
                    },
                    _animationZoomOut: function(e, t) {
                        this._animationZoomOutSingle(this._topClusterLevel, e - 1, t), this._topClusterLevel._recursivelyAddChildrenToMap(null, t, this._getExpandedVisibleBounds()), this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), e, this._getExpandedVisibleBounds())
                    },
                    _animationAddLayer: function(e, t) {
                        var i = this,
                            n = this._featureGroup;
                        n.addLayer(e), t !== e && (t._childCount > 2 ? (t._updateIcon(), this._forceLayout(), this._animationStart(), e._setPos(this._map.latLngToLayerPoint(t.getLatLng())), e.clusterHide(), this._enqueue(function() {
                            n.removeLayer(e), e.clusterShow(), i._animationEnd()
                        })) : (this._forceLayout(), i._animationStart(), i._animationZoomOutSingle(t, this._map.getMaxZoom(), this._zoom)))
                    }
                },
                _animationZoomOutSingle: function(e, t, i) {
                    var n = this._getExpandedVisibleBounds(),
                        r = Math.floor(this._map.getMinZoom());
                    e._recursivelyAnimateChildrenInAndAddSelfToMap(n, r, t + 1, i);
                    var s = this;
                    this._forceLayout(), e._recursivelyBecomeVisible(n, i), this._enqueue(function() {
                        if (1 === e._childCount) {
                            var o = e._markers[0];
                            this._ignoreMove = !0, o.setLatLng(o.getLatLng()), this._ignoreMove = !1, o.clusterShow && o.clusterShow()
                        } else e._recursively(n, i, r, function(e) {
                            e._recursivelyRemoveChildrenFromMap(n, r, t + 1)
                        });
                        s._animationEnd()
                    })
                },
                _animationEnd: function() {
                    this._map && (this._map._mapPane.className = this._map._mapPane.className.replace(" leaflet-cluster-anim", "")), this._inZoomAnimation--, this.fire("animationend")
                },
                _forceLayout: function() {
                    L.Util.falseFn(document.body.offsetWidth)
                }
            }), L.markerClusterGroup = function(e) {
                return new L.MarkerClusterGroup(e)
            }, r = L.MarkerCluster = L.Marker.extend({
                options: L.Icon.prototype.options,
                initialize: function(e, t, i, n) {
                    L.Marker.prototype.initialize.call(this, i ? i._cLatLng || i.getLatLng() : new L.LatLng(0, 0), {
                        icon: this,
                        pane: e.options.clusterPane
                    }), this._group = e, this._zoom = t, this._markers = [], this._childClusters = [], this._childCount = 0, this._iconNeedsUpdate = !0, this._boundsNeedUpdate = !0, this._bounds = new L.LatLngBounds, i && this._addChild(i), n && this._addChild(n)
                },
                getAllChildMarkers: function(e, t) {
                    e = e || [];
                    for (var i = this._childClusters.length - 1; i >= 0; i--) this._childClusters[i].getAllChildMarkers(e, t);
                    for (var n = this._markers.length - 1; n >= 0; n--) t && this._markers[n].__dragStart || e.push(this._markers[n]);
                    return e
                },
                getChildCount: function() {
                    return this._childCount
                },
                zoomToBounds: function(e) {
                    for (var t, i = this._childClusters.slice(), n = this._group._map, r = n.getBoundsZoom(this._bounds), s = this._zoom + 1, o = n.getZoom(); i.length > 0 && r > s;) {
                        s++;
                        var a = [];
                        for (t = 0; t < i.length; t++) a = a.concat(i[t]._childClusters);
                        i = a
                    }
                    r > s ? this._group._map.setView(this._latlng, s) : r <= o ? this._group._map.setView(this._latlng, o + 1) : this._group._map.fitBounds(this._bounds, e)
                },
                getBounds: function() {
                    var e = new L.LatLngBounds;
                    return e.extend(this._bounds), e
                },
                _updateIcon: function() {
                    this._iconNeedsUpdate = !0, this._icon && this.setIcon(this)
                },
                createIcon: function() {
                    return this._iconNeedsUpdate && (this._iconObj = this._group.options.iconCreateFunction(this), this._iconNeedsUpdate = !1), this._iconObj.createIcon()
                },
                createShadow: function() {
                    return this._iconObj.createShadow()
                },
                _addChild: function(e, t) {
                    this._iconNeedsUpdate = !0, this._boundsNeedUpdate = !0, this._setClusterCenter(e), e instanceof L.MarkerCluster ? (t || (this._childClusters.push(e), e.__parent = this), this._childCount += e._childCount) : (t || this._markers.push(e), this._childCount++), this.__parent && this.__parent._addChild(e, !0)
                },
                _setClusterCenter: function(e) {
                    this._cLatLng || (this._cLatLng = e._cLatLng || e._latlng)
                },
                _resetBounds: function() {
                    var e = this._bounds;
                    e._southWest && (e._southWest.lat = 1 / 0, e._southWest.lng = 1 / 0), e._northEast && (e._northEast.lat = -1 / 0, e._northEast.lng = -1 / 0)
                },
                _recalculateBounds: function() {
                    var e, t, i, n, r = this._markers,
                        s = this._childClusters,
                        o = 0,
                        a = 0,
                        l = this._childCount;
                    if (0 !== l) {
                        for (this._resetBounds(), e = 0; e < r.length; e++) i = r[e]._latlng, this._bounds.extend(i), o += i.lat, a += i.lng;
                        for (e = 0; e < s.length; e++)(t = s[e])._boundsNeedUpdate && t._recalculateBounds(), this._bounds.extend(t._bounds), i = t._wLatLng, n = t._childCount, o += i.lat * n, a += i.lng * n;
                        this._latlng = this._wLatLng = new L.LatLng(o / l, a / l), this._boundsNeedUpdate = !1
                    }
                },
                _addToMap: function(e) {
                    e && (this._backupLatlng = this._latlng, this.setLatLng(e)), this._group._featureGroup.addLayer(this)
                },
                _recursivelyAnimateChildrenIn: function(e, t, i) {
                    this._recursively(e, this._group._map.getMinZoom(), i - 1, function(e) {
                        var i, n, r = e._markers;
                        for (i = r.length - 1; i >= 0; i--)(n = r[i])._icon && (n._setPos(t), n.clusterHide())
                    }, function(e) {
                        var i, n, r = e._childClusters;
                        for (i = r.length - 1; i >= 0; i--)(n = r[i])._icon && (n._setPos(t), n.clusterHide())
                    })
                },
                _recursivelyAnimateChildrenInAndAddSelfToMap: function(e, t, i, n) {
                    this._recursively(e, n, t, function(r) {
                        r._recursivelyAnimateChildrenIn(e, r._group._map.latLngToLayerPoint(r.getLatLng()).round(), i), r._isSingleParent() && i - 1 === n ? (r.clusterShow(), r._recursivelyRemoveChildrenFromMap(e, t, i)) : r.clusterHide(), r._addToMap()
                    })
                },
                _recursivelyBecomeVisible: function(e, t) {
                    this._recursively(e, this._group._map.getMinZoom(), t, null, function(e) {
                        e.clusterShow()
                    })
                },
                _recursivelyAddChildrenToMap: function(e, t, i) {
                    this._recursively(i, this._group._map.getMinZoom() - 1, t, function(n) {
                        if (t !== n._zoom)
                            for (var r = n._markers.length - 1; r >= 0; r--) {
                                var s = n._markers[r];
                                i.contains(s._latlng) && (e && (s._backupLatlng = s.getLatLng(), s.setLatLng(e), s.clusterHide && s.clusterHide()), n._group._featureGroup.addLayer(s))
                            }
                    }, function(t) {
                        t._addToMap(e)
                    })
                },
                _recursivelyRestoreChildPositions: function(e) {
                    for (var t = this._markers.length - 1; t >= 0; t--) {
                        var i = this._markers[t];
                        i._backupLatlng && (i.setLatLng(i._backupLatlng), delete i._backupLatlng)
                    }
                    if (e - 1 === this._zoom)
                        for (var n = this._childClusters.length - 1; n >= 0; n--) this._childClusters[n]._restorePosition();
                    else
                        for (var r = this._childClusters.length - 1; r >= 0; r--) this._childClusters[r]._recursivelyRestoreChildPositions(e)
                },
                _restorePosition: function() {
                    this._backupLatlng && (this.setLatLng(this._backupLatlng), delete this._backupLatlng)
                },
                _recursivelyRemoveChildrenFromMap: function(e, t, i, n) {
                    var r, s;
                    this._recursively(e, t - 1, i - 1, function(e) {
                        for (s = e._markers.length - 1; s >= 0; s--) r = e._markers[s], n && n.contains(r._latlng) || (e._group._featureGroup.removeLayer(r), r.clusterShow && r.clusterShow())
                    }, function(e) {
                        for (s = e._childClusters.length - 1; s >= 0; s--) r = e._childClusters[s], n && n.contains(r._latlng) || (e._group._featureGroup.removeLayer(r), r.clusterShow && r.clusterShow())
                    })
                },
                _recursively: function(e, t, i, n, r) {
                    var s, o, a = this._childClusters,
                        l = this._zoom;
                    if (t <= l && (n && n(this), r && l === i && r(this)), l < t || l < i)
                        for (s = a.length - 1; s >= 0; s--)(o = a[s])._boundsNeedUpdate && o._recalculateBounds(), e.intersects(o._bounds) && o._recursively(e, t, i, n, r)
                },
                _isSingleParent: function() {
                    return this._childClusters.length > 0 && this._childClusters[0]._childCount === this._childCount
                }
            }), L.Marker.include({
                clusterHide: function() {
                    var e = this.options.opacity;
                    return this.setOpacity(0), this.options.opacity = e, this
                },
                clusterShow: function() {
                    return this.setOpacity(this.options.opacity)
                }
            }), L.DistanceGrid = function(e) {
                this._cellSize = e, this._sqCellSize = e * e, this._grid = {}, this._objectPoint = {}
            }, L.DistanceGrid.prototype = {
                addObject: function(e, t) {
                    var i = this._getCoord(t.x),
                        n = this._getCoord(t.y),
                        r = this._grid,
                        s = r[n] = r[n] || {},
                        o = s[i] = s[i] || [],
                        a = L.Util.stamp(e);
                    this._objectPoint[a] = t, o.push(e)
                },
                updateObject: function(e, t) {
                    this.removeObject(e), this.addObject(e, t)
                },
                removeObject: function(e, t) {
                    var i, n, r = this._getCoord(t.x),
                        s = this._getCoord(t.y),
                        o = this._grid,
                        a = o[s] = o[s] || {},
                        l = a[r] = a[r] || [];
                    for (delete this._objectPoint[L.Util.stamp(e)], i = 0, n = l.length; i < n; i++)
                        if (l[i] === e) return l.splice(i, 1), 1 === n && delete a[r], !0
                },
                eachObject: function(e, t) {
                    var i, n, r, s, o, a, l = this._grid;
                    for (i in l)
                        for (n in o = l[i])
                            for (r = 0, s = (a = o[n]).length; r < s; r++) e.call(t, a[r]) && (r--, s--)
                },
                getNearObject: function(e) {
                    var t, i, n, r, s, o, a, l, h = this._getCoord(e.x),
                        u = this._getCoord(e.y),
                        _ = this._objectPoint,
                        c = this._sqCellSize,
                        d = null;
                    for (t = u - 1; t <= u + 1; t++)
                        if (r = this._grid[t]) {
                            for (i = h - 1; i <= h + 1; i++)
                                if (s = r[i])
                                    for (n = 0, o = s.length; n < o; n++) a = s[n], ((l = this._sqDist(_[L.Util.stamp(a)], e)) < c || l <= c && null === d) && (c = l, d = a)
                        }
                    return d
                },
                _getCoord: function(e) {
                    var t = Math.floor(e / this._cellSize);
                    return isFinite(t) ? t : e
                },
                _sqDist: function(e, t) {
                    var i = t.x - e.x,
                        n = t.y - e.y;
                    return i * i + n * n
                }
            }, L.QuickHull = {
                getDistant: function(e, t) {
                    var i = t[1].lat - t[0].lat;
                    return (t[0].lng - t[1].lng) * (e.lat - t[0].lat) + i * (e.lng - t[0].lng)
                },
                findMostDistantPointFromBaseLine: function(e, t) {
                    var i, n, r, s = 0,
                        o = null,
                        a = [];
                    for (i = t.length - 1; i >= 0; i--) n = t[i], (r = this.getDistant(n, e)) > 0 && (a.push(n), r > s && (s = r, o = n));
                    return {
                        maxPoint: o,
                        newPoints: a
                    }
                },
                buildConvexHull: function(e, t) {
                    var i = [],
                        n = this.findMostDistantPointFromBaseLine(e, t);
                    return n.maxPoint ? i = (i = i.concat(this.buildConvexHull([e[0], n.maxPoint], n.newPoints))).concat(this.buildConvexHull([n.maxPoint, e[1]], n.newPoints)) : [e[0]]
                },
                getConvexHull: function(e) {
                    var t, i = !1,
                        n = !1,
                        r = !1,
                        s = !1,
                        o = null,
                        a = null,
                        l = null,
                        h = null,
                        u = null,
                        _ = null;
                    for (t = e.length - 1; t >= 0; t--) {
                        var c = e[t];
                        (!1 === i || c.lat > i) && (o = c, i = c.lat), (!1 === n || c.lat < n) && (a = c, n = c.lat), (!1 === r || c.lng > r) && (l = c, r = c.lng), (!1 === s || c.lng < s) && (h = c, s = c.lng)
                    }
                    return n !== i ? (_ = a, u = o) : (_ = h, u = l), [].concat(this.buildConvexHull([_, u], e), this.buildConvexHull([u, _], e))
                }
            }, L.MarkerCluster.include({
                getConvexHull: function() {
                    var e, t, i = this.getAllChildMarkers(),
                        n = [];
                    for (t = i.length - 1; t >= 0; t--) e = i[t].getLatLng(), n.push(e);
                    return L.QuickHull.getConvexHull(n)
                }
            }), L.MarkerCluster.include({
                _2PI: 2 * Math.PI,
                _circleFootSeparation: 25,
                _circleStartAngle: 0,
                _spiralFootSeparation: 28,
                _spiralLengthStart: 11,
                _spiralLengthFactor: 5,
                _circleSpiralSwitchover: 9,
                spiderfy: function() {
                    if (this._group._spiderfied !== this && !this._group._inZoomAnimation) {
                        var e, t = this.getAllChildMarkers(null, !0),
                            i = this._group._map.latLngToLayerPoint(this._latlng);
                        this._group._unspiderfy(), this._group._spiderfied = this, this._group.options.spiderfyShapePositions ? e = this._group.options.spiderfyShapePositions(t.length, i) : t.length >= this._circleSpiralSwitchover ? e = this._generatePointsSpiral(t.length, i) : (i.y += 10, e = this._generatePointsCircle(t.length, i)), this._animationSpiderfy(t, e)
                    }
                },
                unspiderfy: function(e) {
                    this._group._inZoomAnimation || (this._animationUnspiderfy(e), this._group._spiderfied = null)
                },
                _generatePointsCircle: function(e, t) {
                    var i, n, r = this._group.options.spiderfyDistanceMultiplier * this._circleFootSeparation * (2 + e) / this._2PI,
                        s = this._2PI / e,
                        o = [];
                    for (i = 0, r = Math.max(r, 35), o.length = e; i < e; i++) n = this._circleStartAngle + i * s, o[i] = new L.Point(t.x + r * Math.cos(n), t.y + r * Math.sin(n))._round();
                    return o
                },
                _generatePointsSpiral: function(e, t) {
                    var i, n = this._group.options.spiderfyDistanceMultiplier,
                        r = n * this._spiralLengthStart,
                        s = n * this._spiralFootSeparation,
                        o = n * this._spiralLengthFactor * this._2PI,
                        a = 0,
                        l = [];
                    for (l.length = e, i = e; i >= 0; i--) i < e && (l[i] = new L.Point(t.x + r * Math.cos(a), t.y + r * Math.sin(a))._round()), a += s / r + 5e-4 * i, r += o / a;
                    return l
                },
                _noanimationUnspiderfy: function() {
                    var e, t, i = this._group,
                        n = i._map,
                        r = i._featureGroup,
                        s = this.getAllChildMarkers(null, !0);
                    for (i._ignoreMove = !0, this.setOpacity(1), t = s.length - 1; t >= 0; t--) e = s[t], r.removeLayer(e), e._preSpiderfyLatlng && (e.setLatLng(e._preSpiderfyLatlng), delete e._preSpiderfyLatlng), e.setZIndexOffset && e.setZIndexOffset(0), e._spiderLeg && (n.removeLayer(e._spiderLeg), delete e._spiderLeg);
                    i.fire("unspiderfied", {
                        cluster: this,
                        markers: s
                    }), i._ignoreMove = !1, i._spiderfied = null
                }
            }), L.MarkerClusterNonAnimated = L.MarkerCluster.extend({
                _animationSpiderfy: function(e, t) {
                    var i, n, r, s, o = this._group,
                        a = o._map,
                        l = o._featureGroup,
                        h = this._group.options.spiderLegPolylineOptions;
                    for (i = 0, o._ignoreMove = !0; i < e.length; i++) s = a.layerPointToLatLng(t[i]), n = e[i], r = new L.Polyline([this._latlng, s], h), a.addLayer(r), n._spiderLeg = r, n._preSpiderfyLatlng = n._latlng, n.setLatLng(s), n.setZIndexOffset && n.setZIndexOffset(1e6), l.addLayer(n);
                    this.setOpacity(.3), o._ignoreMove = !1, o.fire("spiderfied", {
                        cluster: this,
                        markers: e
                    })
                },
                _animationUnspiderfy: function() {
                    this._noanimationUnspiderfy()
                }
            }), L.MarkerCluster.include({
                _animationSpiderfy: function(e, t) {
                    var i, n, r, s, o, a, l = this,
                        h = this._group,
                        u = h._map,
                        _ = h._featureGroup,
                        c = this._latlng,
                        d = u.latLngToLayerPoint(c),
                        p = L.Path.SVG,
                        f = L.extend({}, this._group.options.spiderLegPolylineOptions),
                        m = f.opacity;
                    for (void 0 === m && (m = L.MarkerClusterGroup.prototype.options.spiderLegPolylineOptions.opacity), p ? (f.opacity = 0, f.className = (f.className || "") + " leaflet-cluster-spider-leg") : f.opacity = m, h._ignoreMove = !0, i = 0; i < e.length; i++) n = e[i], a = u.layerPointToLatLng(t[i]), r = new L.Polyline([c, a], f), u.addLayer(r), n._spiderLeg = r, p && (o = (s = r._path).getTotalLength() + .1, s.style.strokeDasharray = o, s.style.strokeDashoffset = o), n.setZIndexOffset && n.setZIndexOffset(1e6), n.clusterHide && n.clusterHide(), _.addLayer(n), n._setPos && n._setPos(d);
                    for (h._forceLayout(), h._animationStart(), i = e.length - 1; i >= 0; i--) a = u.layerPointToLatLng(t[i]), (n = e[i])._preSpiderfyLatlng = n._latlng, n.setLatLng(a), n.clusterShow && n.clusterShow(), p && ((s = (r = n._spiderLeg)._path).style.strokeDashoffset = 0, r.setStyle({
                        opacity: m
                    }));
                    this.setOpacity(.3), h._ignoreMove = !1, setTimeout(function() {
                        h._animationEnd(), h.fire("spiderfied", {
                            cluster: l,
                            markers: e
                        })
                    }, 200)
                },
                _animationUnspiderfy: function(e) {
                    var t, i, n, r, s, o, a = this,
                        l = this._group,
                        h = l._map,
                        u = l._featureGroup,
                        _ = e ? h._latLngToNewLayerPoint(this._latlng, e.zoom, e.center) : h.latLngToLayerPoint(this._latlng),
                        c = this.getAllChildMarkers(null, !0),
                        d = L.Path.SVG;
                    for (l._ignoreMove = !0, l._animationStart(), this.setOpacity(1), i = c.length - 1; i >= 0; i--)(t = c[i])._preSpiderfyLatlng && (t.closePopup(), t.setLatLng(t._preSpiderfyLatlng), delete t._preSpiderfyLatlng, o = !0, t._setPos && (t._setPos(_), o = !1), t.clusterHide && (t.clusterHide(), o = !1), o && u.removeLayer(t), d && (s = (r = (n = t._spiderLeg)._path).getTotalLength() + .1, r.style.strokeDashoffset = s, n.setStyle({
                        opacity: 0
                    })));
                    l._ignoreMove = !1, setTimeout(function() {
                        var e = 0;
                        for (i = c.length - 1; i >= 0; i--)(t = c[i])._spiderLeg && e++;
                        for (i = c.length - 1; i >= 0; i--)(t = c[i])._spiderLeg && (t.clusterShow && t.clusterShow(), t.setZIndexOffset && t.setZIndexOffset(0), e > 1 && u.removeLayer(t), h.removeLayer(t._spiderLeg), delete t._spiderLeg);
                        l._animationEnd(), l.fire("unspiderfied", {
                            cluster: a,
                            markers: c
                        })
                    }, 200)
                }
            }), L.MarkerClusterGroup.include({
                _spiderfied: null,
                unspiderfy: function() {
                    this._unspiderfy.apply(this, arguments)
                },
                _spiderfierOnAdd: function() {
                    this._map.on("click", this._unspiderfyWrapper, this), this._map.options.zoomAnimation && this._map.on("zoomstart", this._unspiderfyZoomStart, this), this._map.on("zoomend", this._noanimationUnspiderfy, this), L.Browser.touch || this._map.getRenderer(this)
                },
                _spiderfierOnRemove: function() {
                    this._map.off("click", this._unspiderfyWrapper, this), this._map.off("zoomstart", this._unspiderfyZoomStart, this), this._map.off("zoomanim", this._unspiderfyZoomAnim, this), this._map.off("zoomend", this._noanimationUnspiderfy, this), this._noanimationUnspiderfy()
                },
                _unspiderfyZoomStart: function() {
                    this._map && this._map.on("zoomanim", this._unspiderfyZoomAnim, this)
                },
                _unspiderfyZoomAnim: function(e) {
                    L.DomUtil.hasClass(this._map._mapPane, "leaflet-touching") || (this._map.off("zoomanim", this._unspiderfyZoomAnim, this), this._unspiderfy(e))
                },
                _unspiderfyWrapper: function() {
                    this._unspiderfy()
                },
                _unspiderfy: function(e) {
                    this._spiderfied && this._spiderfied.unspiderfy(e)
                },
                _noanimationUnspiderfy: function() {
                    this._spiderfied && this._spiderfied._noanimationUnspiderfy()
                },
                _unspiderfyLayer: function(e) {
                    e._spiderLeg && (this._featureGroup.removeLayer(e), e.clusterShow && e.clusterShow(), e.setZIndexOffset && e.setZIndexOffset(0), this._map.removeLayer(e._spiderLeg), delete e._spiderLeg)
                }
            }), L.MarkerClusterGroup.include({
                refreshClusters: function(e) {
                    return e ? e instanceof L.MarkerClusterGroup ? e = e._topClusterLevel.getAllChildMarkers() : e instanceof L.LayerGroup ? e = e._layers : e instanceof L.MarkerCluster ? e = e.getAllChildMarkers() : e instanceof L.Marker && (e = [e]) : e = this._topClusterLevel.getAllChildMarkers(), this._flagParentsIconsNeedUpdate(e), this._refreshClustersIcons(), this.options.singleMarkerMode && this._refreshSingleMarkerModeMarkers(e), this
                },
                _flagParentsIconsNeedUpdate: function(e) {
                    var t, i;
                    for (t in e)
                        for (i = e[t].__parent; i;) i._iconNeedsUpdate = !0, i = i.__parent
                },
                _refreshSingleMarkerModeMarkers: function(e) {
                    var t, i;
                    for (t in e) i = e[t], this.hasLayer(i) && i.setIcon(this._overrideMarkerIcon(i))
                }
            }), L.Marker.include({
                refreshIconOptions: function(e, t) {
                    var i = this.options.icon;
                    return L.setOptions(i, e), this.setIcon(i), t && this.__parent && this.__parent._group.refreshClusters(this), this
                }
            }), i.MarkerClusterGroup = n, i.MarkerCluster = r, Object.defineProperty(i, "__esModule", {
                value: !0
            })
        }
    }
]);