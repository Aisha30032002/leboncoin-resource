! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "4a412f5d-bf3f-415f-b69c-b27d3bcc7c44", e._sentryDebugIdIdentifier = "sentry-dbid-4a412f5d-bf3f-415f-b69c-b27d3bcc7c44")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [31981], {
        36771: function(e, t, A) {
            A.d(t, {
                Z: function() {
                    return i
                }
            });
            var a = A(19013),
                n = A(13882),
                r = A(92300);

            function i(e) {
                (0, n.Z)(1, arguments);
                var t = (0, a.Z)(e);
                return (0, r.Z)(t, function(e) {
                    (0, n.Z)(1, arguments);
                    var t = (0, a.Z)(e),
                        A = new Date(0);
                    return A.setFullYear(t.getFullYear(), 0, 1), A.setHours(0, 0, 0, 0), A
                }(t)) + 1
            }
        },
        43753: function(e, t, A) {
            A.r(t), A.d(t, {
                default: function() {
                    return E
                }
            });
            var a = A(72253),
                n = A(24043),
                r = A(85893),
                i = A(67294),
                s = A(11163),
                l = A(11956),
                d = A(39085),
                c = A(62938),
                o = A(36771),
                u = A(23378),
                f = A(57327),
                m = {
                    src: "/_next/static/media/apartmentIcon.676556f2.png",
                    height: 54,
                    width: 46,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAMAAAAC2hU0AAAAMFBMVEWZf7m6pdD06vlMaXGGaazs4PPy6Pj07fnDsNamjcHx5/eRdrSKbq/x5/eki8Dr4PKXtYPgAAAAC3RSTlP+/u4A/oiDBeC5qPUODwwAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAlSURBVAiZY2BnZuVnYOFhYGZm42fg4Wbg4uTgBdFMfIyEaW4GADQMAZ1NbBb4AAAAAElFTkSuQmCC",
                    blurWidth: 7,
                    blurHeight: 8
                },
                b = {
                    src: "/_next/static/media/calendarIcon-1.1b007007.png",
                    height: 40,
                    width: 46,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAOVBMVEX19/fz9fb09fb09vfm5+7b4OXi5ury9fXm7Pfo7O/x9PfGzdbHztfGzdbEzNTHztfy9Pba5evW2+HEcaUmAAAAEHRSTlP+5sOgHVuK+f78Oj19qIbhfRNo9QAAAAlwSFlzAAALEwAACxMBAJqcGAAAADVJREFUCJklxkkSgDAMwDADXRK2uvz/scyATqL0GZqFnQjIg6pIVppdmTfbl+di/TNYVHo7Xz8vAhzfpbm4AAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 7
                },
                g = {
                    src: "/_next/static/media/calendarIcon-2.0977fbca.png",
                    height: 40,
                    width: 56,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAJFBMVEX5+/z19/j09vfk6Ozz9ff09vfy9fbu8vTx8/T19/jl6e3P1t3Udc69AAAACXRSTlP+Af7+es44uRWtcZ6zAAAACXBIWXMAAAsTAAALEwEAmpwYAAAALElEQVQImT3IWw4AEAwF0fugtPa/X0Fivk4GqZQaidtHJ6GDDMJvTSxXlUdsCzUAiqZB8AsAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 6
                },
                h = {
                    src: "/_next/static/media/houseIcon.2d115b0b.png",
                    height: 49,
                    width: 76,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAANlBMVEWYhLeMbq97XKNrSpiWebZnRpaYe7apkMRlQ5Tl1u9oR5d/YKaAYKb/9P/n2PDl1u/o2fGUeLUIcvcuAAAAEHRSTlMB/f655TT7/v7yWM3+PtXt+miTTwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAC5JREFUCJkdyMkRACAIALFVUfCG/pt1xjzDVjOrwPGU8wS6awsBrmsKqX9WtDIeGNgBLOCfgk0AAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 5
                },
                p = {
                    src: "/_next/static/media/timeIcon.2073dd11.png",
                    height: 40,
                    width: 46,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAARVBMVEVMaXH1u63/y6Leqqn1taX0u675vq73vK32vK7nsa+4vOfI2//9///0vrOFluMcPM5acNjssaftzsrVrLf7tZq6r9ShvPxwjjO7AAAAEXRSTlMAszi6gijH/vd4+f35QeYRrHQCSR0AAAAJcEhZcwAACxMAAAsTAQCanBgAAAA4SURBVAiZJYpHDoAwEMSGtNmQXuD/T40WfLIsA61HKLG+j1NxM6dlAJQ97xG+ZAf5b4EUr+JFeB0zFgFy4+p4igAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 7
                },
                v = (0, f.i0)("realestate/estimation");

            function x(e) {
                var t = e.variant,
                    A = e.urlSearchParams,
                    a = "variant1" === t ? v("estimation.property-type-to-sell.text") : v("estimation.sell-date.text"),
                    n = "variant1" === t ? [{
                        src: h,
                        text: v("banner.asset-house.text"),
                        value: "house"
                    }, {
                        src: m,
                        text: v("banner.asset-apartment.text"),
                        value: "apartment"
                    }] : [{
                        src: p,
                        text: v("banner.asset-soon.text"),
                        value: "soon"
                    }, {
                        src: b,
                        text: v("banner.asset-semester.text"),
                        value: "semester"
                    }, {
                        src: g,
                        text: v("banner.asset-next-semester.text"),
                        value: "next_semester"
                    }],
                    i = (0, f.$G)("realestate/estimation").t;
                return (0, r.jsxs)("div", {
                    className: "flex w-full flex-col overflow-hidden px-lg py-lg md:flex-row",
                    children: [(0, r.jsx)("div", {
                        className: "mb-lg flex w-full items-center pr-2xl md:w-[55%]",
                        children: (0, r.jsx)("p", {
                            className: "text-subhead md:text-headline-2",
                            children: i("estimation.estimate-banner-content.title")
                        })
                    }), (0, r.jsxs)("div", {
                        className: "w-full md:w-[45%]",
                        children: [(0, r.jsx)("p", {
                            className: "mb-md",
                            children: a
                        }), (0, r.jsx)("div", {
                            className: "flex justify-center gap-lg",
                            children: n.map(function(e, t) {
                                var a = e.src,
                                    n = e.text,
                                    i = e.value;
                                return A.delete("ctaSelection"), A.append("ctaSelection", i), (0, r.jsx)(d.Z, {
                                    className: "w-full",
                                    to: "/immo/estimation?".concat(A),
                                    children: (0, r.jsxs)("div", {
                                        className: "flex h-full flex-col items-center justify-around rounded-md bg-surface p-lg shadow-md hover:bg-on-background/dim-4",
                                        children: [(0, r.jsx)("div", {
                                            className: "mb-sm",
                                            children: (0, r.jsx)(u.Z, {
                                                src: a,
                                                alt: n
                                            })
                                        }), (0, r.jsx)("div", {
                                            className: "flex items-center justify-center",
                                            children: (0, r.jsx)("span", {
                                                className: "text-center text-caption font-semi-bold",
                                                children: n
                                            })
                                        })]
                                    })
                                }, t)
                            })
                        })]
                    })]
                })
            }
            var w = A(76883);

            function y(e) {
                var t = e.storeId,
                    A = e.userId,
                    a = e.type,
                    n = e.variant,
                    r = e.entryPoint,
                    i = void 0 === r ? "ad_view" : r;
                w._q.sendUnlimitedPageLoad({
                    eventname: "mandats",
                    entry_point: i,
                    path: "pre_estimate",
                    step_name: "".concat(a, "_pre_estimate_").concat(i),
                    step_number: 0,
                    load: "false",
                    number_promote: 1,
                    type_promote: "banner",
                    position_promote: "middle",
                    name_promote: "variant1" === n ? "banner_a" : "banner_b",
                    store_id_historical: t,
                    store_id_new: A
                })
            }
            var E = function(e) {
                var t, A = e.id,
                    u = e.entryPoint,
                    f = void 0 === u ? l.YX.ad_view : u,
                    m = e.className,
                    b = (0, c.Z)().data,
                    g = null == b ? void 0 : b.storeId,
                    h = null == b ? void 0 : b.userId,
                    p = (t = new Date, "variant".concat(((0, o.Z)(t) + 1) % 2 + 1)),
                    v = (0, s.useRouter)().query;
                (0, i.useEffect)(function() {
                    y({
                        storeId: g,
                        userId: h,
                        type: "impression",
                        entryPoint: f,
                        variant: p
                    })
                }, [g, h, p]);
                var w = (0, a._)({
                        entryPoint: f,
                        listId: null == A ? void 0 : A.toString()
                    }, v),
                    E = new URLSearchParams;
                return Object.entries(w).forEach(function(e) {
                    var t = (0, n._)(e, 2),
                        A = t[0],
                        a = t[1];
                    "string" == typeof a && E.append(A, a)
                }), (0, r.jsx)("div", {
                    className: "rounded-lg bg-main-container bg-opacity-dim-2 ".concat(m),
                    children: (0, r.jsx)(d.Z, {
                        to: "/immo/estimation?".concat(E),
                        onClick: function() {
                            return y({
                                storeId: g,
                                userId: h,
                                type: "event",
                                entryPoint: f,
                                variant: p
                            })
                        },
                        "data-test-id": "banner-link",
                        children: (0, r.jsx)("div", {
                            className: "flex overflow-hidden",
                            children: (0, r.jsx)(x, {
                                variant: p,
                                urlSearchParams: E
                            })
                        })
                    })
                })
            }
        }
    }
]);