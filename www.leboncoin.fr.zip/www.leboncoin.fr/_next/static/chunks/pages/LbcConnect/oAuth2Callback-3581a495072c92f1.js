! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "e3750dfe-8ab4-452c-b9f5-bb6df32674df", e._sentryDebugIdIdentifier = "sentry-dbid-e3750dfe-8ab4-452c-b9f5-bb6df32674df")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
}, (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [86466], {
        47983: function(e, n, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/LbcConnect/oAuth2Callback", function() {
                return t(70606)
            }])
        },
        70606: function(e, n, t) {
            "use strict";
            t.r(n), t.d(n, {
                default: function() {
                    return b
                }
            });
            var o = t(11010),
                r = t(75766),
                i = t(70655),
                s = t(26541),
                c = t(17563),
                a = t(67294),
                d = t(74076),
                f = t(46958),
                u = t(97739),
                l = t(41054),
                w = t(81707);

            function b() {
                return (0, a.useEffect)(function() {
                    var e;
                    (e = (0, o._)(function() {
                        var e, n, t, o;
                        return (0, i.__generator)(this, function(i) {
                            switch (i.label) {
                                case 0:
                                    return [4, (0, l._Q)()];
                                case 1:
                                    return [4, (e = i.sent()).getTokenInfoFromCode(window.location)];
                                case 2:
                                    if (n = i.sent(), !(0, s.hv)(n)) return [3, 7];
                                    if (d.Uc.set((0, r._)({}, f.y$.access, n.accessToken)), window !== window.parent) return [3, 6];
                                    t = (0, u.S)(), i.label = 3;
                                case 3:
                                    return i.trys.push([3, 5, , 6]), [4, (0, w.Z)(t)];
                                case 4:
                                case 5:
                                    return i.sent(), [3, 6];
                                case 6:
                                    return window.parent.postMessage(JSON.stringify({
                                        lbcconnect: !0,
                                        success: {
                                            accessToken: n.accessToken
                                        }
                                    }), window.location.origin), e.redirectIfNeeded(window), [3, 8];
                                case 7:
                                    o = c.parse(location.search), window.parent.postMessage(JSON.stringify({
                                        lbcconnect: !0,
                                        error: {
                                            type: o.error,
                                            description: o.error_description
                                        }
                                    }), window.location.origin), window.location.href = window.location.origin, i.label = 8;
                                case 8:
                                    return [2]
                            }
                        })
                    }), function() {
                        return e.apply(this, arguments)
                    })()
                }, []), null
            }
        }
    },
    function(e) {
        e.O(0, [49774, 92888, 40179], function() {
            return e(e.s = 47983)
        }), _N_E = e.O()
    }
]);