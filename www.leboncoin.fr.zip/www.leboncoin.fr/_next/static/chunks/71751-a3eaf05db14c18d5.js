! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "f2b9db0f-65d5-4886-9890-95da4d5ad0a5", e._sentryDebugIdIdentifier = "sentry-dbid-f2b9db0f-65d5-4886-9890-95da4d5ad0a5")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
}, (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [71751], {
        71751: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return D
                }
            });
            var i, s = n(85893),
                r = n(31431);
            n(67294);
            var o = n(57327),
                a = n(26773),
                d = n(75766),
                l = n(41664),
                c = n.n(l),
                u = n(89271),
                x = n(72633),
                m = n(82729),
                p = n(16678),
                v = n(19181);

            function f() {
                var e = (0, m._)(["\n  list-style: initial;\n  ", "\n"]);
                return f = function() {
                    return e
                }, e
            }

            function g() {
                var e = (0, m._)(["\n    margin-left: ", ";\n    ", "\n  "]);
                return g = function() {
                    return e
                }, e
            }
            var h = (0, v.default)("ul").withConfig({
                    componentId: "sc-db459dee-0"
                })(f(), p.Dh),
                b = (0, v.default)("li").withConfig({
                    componentId: "sc-db459dee-1"
                })(function(e) {
                    var t = e.theme;
                    return (0, v.css)(g(), t.space.medium, p.Dh)
                }),
                j = (0, o.i0)(a.i),
                y = function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Dans le cadre de nos relations contractuelles, les donn\xe9es de ce formulaire sont trait\xe9es par LBC France pour cr\xe9er votre compte, en assurer la gestion et vous permettre l’utilisation de la messagerie int\xe9gr\xe9e. Nous traitons ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime \xe0 vous solliciter de nouveau pour des offres commerciales, \xe0 poursuivre des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur, et de lutte contre la fraude. Ces donn\xe9es sont accessibles aux prestataires de LBC France, dont Adevinta France (soci\xe9t\xe9-m\xe8re de LBC France) sur la base de son int\xe9r\xeat l\xe9gitime, qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s."
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Si vous acceptez que LBC France vous envoie des offres de ses partenaires, vos donn\xe9es ne seront pas transmises \xe0 nos partenaires par LBC France. Elles seront uniquement utilis\xe9es pour vous communiquer par email des offres susceptibles de vous int\xe9resser, vous redirigeant vers les sites web de nos partenaires."
                        })]
                    })
                },
                q = function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "En cliquant sur “Envoyer”, vous acceptez que les donn\xe9es de ce formulaire soient trait\xe9es par LBC France pour donner suite \xe0 votre demande de renseignements."
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Nous traitons ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime \xe0 vous solliciter pour des offres commerciales, \xe0 poursuivre des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur."
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Ces donn\xe9es sont accessibles aux prestataires de LBC France, dont Adevinta France (soci\xe9t\xe9 m\xe8re de LBC France) sur la base de son int\xe9r\xeat l\xe9gitime, qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s."
                        })]
                    })
                },
                B = (i = {
                    adview: function() {
                        return (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "En cliquant sur \xab Partager l’annonce \xbb, vous acceptez que ces informations soient trait\xe9es par LBC France pour donner suite \xe0 votre demande de recommandation aupr\xe8s de votre ami. Votre adresse email et celle de votre ami ne sont utilis\xe9es que pour l’envoi de cette recommandation, apr\xe8s quoi nous proc\xe9dons automatiquement \xe0 leur suppression."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Ces donn\xe9es sont accessibles aux prestataires de LBC France qui concourent administrativement et techniquement \xe0 r\xe9aliser les finalit\xe9s ci-dessus."
                            })]
                        })
                    },
                    adreply: function() {
                        return (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "En contactant l’annonceur, vous acceptez de lui transmettre votre pseudo, votre message et les donn\xe9es renseign\xe9es dans les \xe9ventuels champs compl\xe9mentaires du formulaire afin qu’il puisse donner suite \xe0 votre demande de contact."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Lorsque l’annonceur est un professionnel, vous acceptez de lui transmettre \xe9galement :"
                            }), (0, s.jsxs)(h, {
                                children: [(0, s.jsx)(b, {
                                    children: (0, s.jsx)(u.Z, {
                                        variant: "body",
                                        as: "p",
                                        marginBottom: "medium",
                                        children: "Vos nom, pr\xe9nom et adresse mail tels que renseign\xe9s dans votre compte. Vous pouvez les modifier dans la page “Param\xe8tres“ de votre compte."
                                    })
                                }), (0, s.jsx)(b, {
                                    children: (0, s.jsx)(u.Z, {
                                        variant: "body",
                                        as: "p",
                                        marginBottom: "medium",
                                        children: "Votre num\xe9ro de t\xe9l\xe9phone et le contenu de votre message, tels que renseign\xe9s dans le formulaire. Si vous ne souhaitez pas transmettre votre num\xe9ro de t\xe9l\xe9phone, vous avez la possibilit\xe9 de le retirer du formulaire."
                                    })
                                }), (0, s.jsx)(b, {
                                    children: (0, s.jsx)(u.Z, {
                                        variant: "body",
                                        as: "p",
                                        marginBottom: "medium",
                                        children: "Des donn\xe9es de contexte, par exemple vos crit\xe8res de recherche, votre temps moyen de r\xe9ponse ou encore, sous r\xe9serve de votre consentement, votre degr\xe9 d’int\xe9r\xeat (estim\xe9 automatiquement \xe0 partir de vos donn\xe9es de navigation et d’utilisation du service)."
                                    })
                                })]
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Cet annonceur professionnel agit en qualit\xe9 de responsable du traitement et vous pouvez en savoir plus sur le traitement de vos donn\xe9es qu’il effectue et exercer vos droits directement aupr\xe8s de lui."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Nous traitons \xe9galement ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime pour vous envoyer des communications en lien avec votre usage du service ainsi qu’\xe0 des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Enfin, nous traitons vos donn\xe9es de mani\xe8re automatis\xe9e \xe0 des fins de lutte contre la fraude. Ce traitement pourra donner lieu \xe0 un blocage automatique de vos messages au sein de la messagerie s\xe9curis\xe9e leboncoin."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Vos donn\xe9es sont accessibles aux prestataires de LBC France, dont Adevinta France (soci\xe9t\xe9-m\xe8re de LBC France) sur la base de son int\xe9r\xeat l\xe9gitime, qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s."
                            })]
                        })
                    },
                    jobsAdreply: function() {
                        return (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: j("cnil.jobs-adreply-privacy-policy-1.text")
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: j("cnil.jobs-adreply-privacy-policy-2.text")
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: j("cnil.jobs-adreply-privacy-policy-3.text")
                            })]
                        })
                    },
                    jobsDirectapply: function() {
                        return (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: j("cnil.jobs-direct-apply-privacy-policy-1.text")
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: j("cnil.jobs-direct-apply-privacy-policy-2.text")
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: j("cnil.jobs-direct-apply-privacy-policy-3.text")
                            })]
                        })
                    },
                    publicite: function() {
                        return (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: 'Ces informations sont indispensables \xe0 leboncoin pour donner suite \xe0 votre demande d’information. Ces informations sont trait\xe9es par la soci\xe9t\xe9 LBC France et les soci\xe9t\xe9s du groupe Adevinta France, dont fait partie LBC France (ensemble, le "Groupe") \xe0 des fins statistiques et de prospection, ainsi que pour vous informer des activit\xe9s de leboncoin et des soci\xe9t\xe9s du Groupe, ces informations \xe9tant par ailleurs accessibles, pour des raisons exclusivement techniques, aux prestataires assurant leur traitement technique ainsi que leur h\xe9bergement et le support technique.'
                        })
                    },
                    contact: function() {
                        return (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: 'Ces informations sont indispensables \xe0 leboncoin pour donner suite \xe0 votre demande de renseignements. Ces informations sont trait\xe9es par la soci\xe9t\xe9 LBC France et les soci\xe9t\xe9s du groupe Adevinta France, dont fait partie LBC France (ensemble, le "Groupe"), ces informations pouvant cependant \xeatre accessibles, pour des raisons exclusivement techniques, aux prestataires assurant leur traitement technique ainsi que leur h\xe9bergement et le support technique.'
                        })
                    },
                    propage_contact: function() {
                        return (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Lorsque vous remplissez ce formulaire, vous acceptez que les donn\xe9es qu’il contient soient transmises au professionnel d\xe9sign\xe9 pour qu’il puisse donner suite \xe0 votre demande de contact. Il agit en qualit\xe9 de responsable de traitement, vous pouvez en savoir plus sur le traitement de vos donn\xe9es et exercer vos droits directement aupr\xe8s de lui."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Nous traitons ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime \xe0 vous solliciter de nouveau pour des offres commerciales, \xe0 poursuivre des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Ces donn\xe9es sont accessibles aux prestataires de LBC France, dont Adevinta France (soci\xe9t\xe9 m\xe8re de LBC France) sur la base de son int\xe9r\xeat l\xe9gitime, qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s."
                            })]
                        })
                    },
                    propage_contact_jobs: function() {
                        return (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Lorsque vous remplissez ce formulaire, vous acceptez que les donn\xe9es qu’il contient, y compris votre CV, soient transmises au professionnel d\xe9sign\xe9 afin de traiter votre candidature. Il agit en qualit\xe9 de responsable de traitement, vous pouvez en savoir plus sur le traitement de vos donn\xe9es et exercer vos droits directement aupr\xe8s de lui."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Nous traitons ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime \xe0 vous solliciter de nouveau pour des offres commerciales, \xe0 poursuivre des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Ces donn\xe9es sont accessibles aux prestataires de LBC France, dont Adevinta France (soci\xe9t\xe9 m\xe8re de LBC France) sur la base de son int\xe9r\xeat l\xe9gitime, qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s."
                            })]
                        })
                    },
                    propage_expired: q,
                    propage_new_lead: q,
                    pro_immo: q,
                    pro_auto: q,
                    pro_multicat: q,
                    pro_jobs: q,
                    pro_pav: function() {
                        return (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "En cliquant sur “\xcatre rappel\xe9”, vous acceptez que les donn\xe9es de ce formulaire soient trait\xe9es par LBC France pour donner suite \xe0 votre demande de renseignements."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Nous traitons ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime \xe0 vous solliciter pour des offres commerciales, \xe0 poursuivre des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur."
                            }), (0, s.jsx)(u.Z, {
                                variant: "body",
                                as: "p",
                                marginBottom: "medium",
                                children: "Ces donn\xe9es sont accessibles aux prestataires de LBC France, dont Adevinta France (soci\xe9t\xe9 m\xe8re de LBC France) sur la base de son int\xe9r\xeat l\xe9gitime, qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s."
                            })]
                        })
                    },
                    compteperso: y,
                    comptepro: y,
                    "kyc-data": function() {
                        return (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Vos donn\xe9es sont trait\xe9es par notre partenaire de paiement Adyen qui les v\xe9rifie afin de s\xe9curiser les transactions entre utilisateurs, sur la base de son obligation l\xe9gale en mati\xe8re de lutte contre le blanchiment et le financement du terrorisme."
                        })
                    },
                    "kyc-gdpr": function() {
                        return (0, s.jsxs)(u.Z, {
                            as: "span",
                            variant: "body",
                            marginBottom: "medium",
                            children: ["Pour exercer vos droits d’acc\xe8s, de rectification, d’opposition, de suppression, de limitation, \xe0 la portabilit\xe9 concernant ces informations :", " ", (0, s.jsx)(u.Z, {
                                as: c(),
                                rel: "noopener noreferrer",
                                color: "blue",
                                colorHover: "blueDark",
                                target: "_blank",
                                href: "https://www.adyen.com/fr_FR/politiques-et-mentions-legales/privacy-policy",
                                children: "cliquez ici"
                            })]
                        })
                    }
                }, (0, d._)(i, x.fw.DEPOSIT_AD.name, function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Dans le cadre de nos relations contractuelles, les donn\xe9es de ce formulaire sont trait\xe9es par LBC France pour donner suite \xe0 votre d\xe9p\xf4t d’annonce. Nous traitons ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime \xe0 vous solliciter de nouveau pour des offres commerciales, \xe0 poursuivre des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur, et de lutte contre la fraude via une technologie d’analyse automatique du contenu des annonces.Nous pouvons \xe9galement vous envoyer des alertes, si vous souscrivez \xe0 notre service d’alerte \xe0 partir de votre Compte."
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Ces donn\xe9es sont accessibles aux prestataires de LBC France, dont Adevinta France (soci\xe9t\xe9-m\xe8re de LBC France) sur la base de son int\xe9r\xeat l\xe9gitime, qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s. Notre prestataire de localisation HERE, agissant en qualit\xe9 de responsable de traitement de vos donn\xe9es, collecte votre adresse postale et votre adresse IP."
                        })]
                    })
                }), (0, d._)(i, "partAccountEdit", function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsxs)(u.Z, {
                            marginTop: "medium",
                            marginBottom: "medium",
                            children: [j("cnil.part-accout-edit-1.text"), " ", (0, s.jsx)(u.Z, {
                                variant: "bodyImportant",
                                color: "blue",
                                colorHover: "blueDark",
                                as: c(),
                                rel: "noopener",
                                target: "_blank",
                                href: "/dc/cookies",
                                children: j("cnil.part-accout-edit.link")
                            })]
                        }), (0, s.jsxs)(u.Z, {
                            as: "ul",
                            children: [(0, s.jsx)(u.Z, {
                                as: "li",
                                paddingTop: "small",
                                paddingBottom: "small",
                                children: j("cnil.part-accout-edit-2.text")
                            }), (0, s.jsx)(u.Z, {
                                as: "li",
                                paddingTop: "small",
                                paddingBottom: "small",
                                children: j("cnil.part-accout-edit-3.text")
                            })]
                        })]
                    })
                }), (0, d._)(i, "realestateMandat", function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Nous traitons ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime pour enrichir nos produits et services \xe0 destination des professionnels de l’immobilier (seules les donn\xe9es relatives au bien immobilier sont r\xe9-utilis\xe9es, \xe0 l’exclusion des donn\xe9es d’identification et de contact), pour vous solliciter de nouveau pour des offres commerciales (et avec votre consentement celles de nos partenaires), et \xe0 des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur."
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Ces donn\xe9es sont accessibles aux prestataires de LBC France, dont Adevinta France (soci\xe9t\xe9 m\xe8re de LBC France), sur la base de son int\xe9r\xeat l\xe9gitime, qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s et sont susceptibles d’\xeatre transf\xe9r\xe9es hors de l’Union europ\xe9enne avec les garanties appropri\xe9es requises (protection \xe9quivalente du pays tiers, r\xe8gles internes contraignantes, contrat de transfert)."
                        })]
                    })
                }), (0, d._)(i, "realEstateRentalManagement", function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Dans le cadre de la cr\xe9ation et de la gestion de votre dossier locataire, nous collectons et traitons les donn\xe9es suivantes :"
                        }), (0, s.jsxs)(h, {
                            children: [(0, s.jsx)(b, {
                                children: (0, s.jsx)(u.Z, {
                                    variant: "body",
                                    as: "p",
                                    marginBottom: "medium",
                                    children: "Donn\xe9es d’identification et de profil : nom, pr\xe9nom, email, t\xe9l\xe9phone, photo, pr\xe9sentation ainsi qu’une preuve d’identit\xe9 et un justificatif de domicile pour vous et, le cas \xe9ch\xe9ant, pour les autres locataires et garants."
                                })
                            }), (0, s.jsx)(b, {
                                children: (0, s.jsx)(u.Z, {
                                    variant: "body",
                                    as: "p",
                                    marginBottom: "medium",
                                    children: "Donn\xe9es et justificatifs relatifs \xe0 votre situation professionnelle et financi\xe8re, ainsi que celle des autres locataires et des garants le cas \xe9ch\xe9ant, et notamment : revenus principaux et compl\xe9mentaires, type de garant, statut/type de contrat, profession/secteur d’activit\xe9, \xe9tablissement d’activit\xe9 (soci\xe9t\xe9 employeur ou \xe9tablissement scolaire par ex.) ou encore le niveau de formation (pour les \xe9tudiants uniquement)."
                                })
                            }), (0, s.jsx)(b, {
                                children: (0, s.jsx)(u.Z, {
                                    variant: "body",
                                    as: "p",
                                    marginBottom: "medium",
                                    children: "Donn\xe9es relatives \xe0 votre projet : nombre de locataires, date d’emm\xe9nagement souhait\xe9e, dur\xe9e de location souhait\xe9e, recommandations de pr\xe9c\xe9dents propri\xe9taires."
                                })
                            })]
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Le caract\xe8re obligatoire ou facultatif des donn\xe9es est indiqu\xe9 au niveau de chaque champ. A d\xe9faut de fournir les donn\xe9es obligatoires, vous ne pourrez pas finaliser la cr\xe9ation de votre profil locataire."
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Votre profil locataire et vos justificatifs seront partag\xe9s avec un propri\xe9taire annonceur uniquement sur instruction de votre part : vous avez la possibilit\xe9 de joindre ou non votre profil locataire et/ou vos justificatifs \xe0 chaque demande de contact. Depuis votre espace locataire, vous pouvez \xe9galement v\xe9rifier \xe0 tout moment la liste des annonceurs ayant acc\xe8s \xe0 votre profil locataire et vos justificatifs et retirer l’acc\xe8s \xe0 un annonceur donn\xe9."
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Votre profil locataire ainsi que vos justificatifs peuvent \xeatre consult\xe9s, modifi\xe9s et/ou supprim\xe9s \xe0 tout moment dans votre compte leboncoin (Section “Profils & Espaces”, puis “Acc\xe9der \xe0 mon dossier locataire”)"
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Nous traitons \xe9galement ces donn\xe9es \xe0 des fins statistiques et d’analyses dans le cadre de notre int\xe9r\xeat l\xe9gitime \xe0 am\xe9liorer notre service et votre exp\xe9rience utilisateur."
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Vos donn\xe9es sont trait\xe9es par LBC France et Adevinta France (soci\xe9t\xe9 m\xe8re de LBC France), ainsi que par les prestataires qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s."
                        })]
                    })
                }), (0, d._)(i, "realEstateRentalManagementAdreply", function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "En contactant le propri\xe9taire annonceur, vous acceptez de lui transmettre votre pseudo, votre message et, le cas \xe9ch\xe9ant, votre dossier locataire (avec ou sans les justificatifs) afin qu’il puisse donner suite \xe0 votre candidature \xe0 la location."
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Lorsque le propri\xe9taire est un professionnel, vous acceptez de lui transmettre \xe9galement :"
                        }), (0, s.jsxs)(h, {
                            children: [(0, s.jsx)(b, {
                                children: (0, s.jsx)(u.Z, {
                                    variant: "body",
                                    as: "p",
                                    marginBottom: "medium",
                                    children: "Vos coordonn\xe9es : nom/pr\xe9nom, adresse mail et num\xe9ro de t\xe9l\xe9phone, tels que d\xe9finis dans votre compte au moment de votre demande de contact. Ces donn\xe9es sont modifiables \xe0 tout moment depuis la page “Param\xe8tres” de votre compte."
                                })
                            }), (0, s.jsx)(b, {
                                children: (0, s.jsx)(u.Z, {
                                    variant: "body",
                                    as: "p",
                                    marginBottom: "medium",
                                    children: "Des donn\xe9es de contexte, par exemple vos crit\xe8res de recherche, votre temps moyen de r\xe9ponse ou encore, sous r\xe9serve de votre consentement, votre degr\xe9 d’int\xe9r\xeat (estim\xe9 automatiquement \xe0 partir de vos donn\xe9es de navigation et d’utilisation du service)."
                                })
                            })]
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Cet annonceur professionnel agit en qualit\xe9 de responsable du traitement et vous pouvez en savoir plus sur le traitement de vos donn\xe9es qu’il effectue et exercer vos droits directement aupr\xe8s de lui."
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Vous pouvez v\xe9rifier \xe0 tout moment, depuis votre espace locataire, la liste des propri\xe9taires annonceurs ayant acc\xe8s \xe0 votre profil locataire et vos justificatifs et retirer l’acc\xe8s \xe0 un annonceur donn\xe9."
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Nous traitons \xe9galement ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime pour vous envoyer des communications en lien avec votre usage du service ainsi qu’\xe0 des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur."
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Enfin, nous traitons vos donn\xe9es de mani\xe8re automatis\xe9e \xe0 des fins de lutte contre la fraude. Ce traitement pourra donner lieu \xe0 un blocage automatique de vos messages au sein de la messagerie s\xe9curis\xe9e leboncoin."
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: "Vos donn\xe9es sont trait\xe9es par LBC France et Adevinta France (soci\xe9t\xe9 m\xe8re de LBC France), ainsi que par les prestataires qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s."
                        })]
                    })
                }), (0, d._)(i, "newHousing", function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "En contactant l’annonceur, vous acceptez de lui transmettre votre pseudo, votre message et les donn\xe9es renseign\xe9es dans les \xe9ventuels champs compl\xe9mentaires du formulaire afin qu’il puisse donner suite \xe0 votre demande de contact."
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Lorsque l’annonceur est un professionnel, vous acceptez de lui transmettre \xe9galement :"
                        }), (0, s.jsxs)(h, {
                            children: [(0, s.jsx)(b, {
                                children: (0, s.jsx)(u.Z, {
                                    variant: "body",
                                    as: "p",
                                    marginBottom: "medium",
                                    children: "Vos coordonn\xe9es : nom/pr\xe9nom, adresse mail et num\xe9ro de t\xe9l\xe9phone, tels que renseign\xe9s dans votre compte. Les donn\xe9es transmises sont celles renseign\xe9es dans le formulaire et/ou d\xe9finies dans votre compte au moment de votre demande de contact. Vous pouvez les modifier dans la page “Param\xe8tres” de votre compte."
                                })
                            }), (0, s.jsx)(b, {
                                children: (0, s.jsx)(u.Z, {
                                    variant: "body",
                                    as: "p",
                                    marginBottom: "medium",
                                    children: "Des donn\xe9es de contexte, par exemple vos crit\xe8res de recherche, votre temps moyen de r\xe9ponse ou encore, sous r\xe9serve de votre consentement, votre degr\xe9 d’int\xe9r\xeat (estim\xe9 automatiquement \xe0 partir de vos donn\xe9es de navigation et d’utilisation du service)."
                                })
                            })]
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Cet annonceur professionnel agit en qualit\xe9 de responsable du traitement et vous pouvez en savoir plus sur le traitement de vos donn\xe9es qu’il effectue et exercer vos droits directement aupr\xe8s de lui."
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Nous traitons \xe9galement ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime pour vous envoyer des communications en lien avec votre usage du service ainsi qu’\xe0 des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur."
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Enfin, nous traitons vos donn\xe9es de mani\xe8re automatis\xe9e \xe0 des fins de lutte contre la fraude. Ce traitement pourra donner lieu \xe0 un blocage automatique de vos messages au sein de la messagerie s\xe9curis\xe9e leboncoin."
                        }), (0, s.jsx)(u.Z, {
                            as: "div",
                            paddingBottom: "small",
                            children: "Vos donn\xe9es sont trait\xe9es par LBC France et Adevinta France (soci\xe9t\xe9 m\xe8re de LBC France), ainsi que par les prestataires qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s."
                        })]
                    })
                }), (0, d._)(i, "vehiclesEstimation", function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            as: "p",
                            marginBottom: "medium",
                            children: "En sollicitant l’assistance des professionnels s\xe9lectionn\xe9s, vous acceptez que LBC France leur transmette :"
                        }), (0, s.jsxs)(h, {
                            marginBottom: "medium",
                            children: [(0, s.jsx)(b, {
                                marginBottom: "medium",
                                children: (0, s.jsx)(u.Z, {
                                    children: "Vos coordonn\xe9es : nom/pr\xe9nom ou pseudonyme, adresse mail et num\xe9ro de t\xe9l\xe9phone, tels que renseign\xe9s dans votre compte et/ou dans le formulaire."
                                })
                            }), (0, s.jsx)(b, {
                                marginBottom: "medium",
                                children: (0, s.jsx)(u.Z, {
                                    children: "L’annonce actuellement en ligne correspondant \xe0 votre v\xe9hicule."
                                })
                            }), (0, s.jsx)(b, {
                                children: (0, s.jsx)(u.Z, {
                                    children: "Des donn\xe9es de contexte sur le v\xe9hicule en question, par ex. les caract\xe9ristiques du v\xe9hicule, son kilom\xe9trage (si vous l’avez renseign\xe9), son num\xe9ro d’immatriculation (sauf si vous vous \xeates oppos\xe9 \xe0 son partage), ou encore le fait que vous ayez d\xe9pos\xe9 ou non une annonce sur notre site dans la cat\xe9gorie “V\xe9hicules”."
                                })
                            })]
                        }), (0, s.jsx)(u.Z, {
                            as: "p",
                            marginBottom: "medium",
                            children: "Les professionnels destinataires de vos donn\xe9es agissent en tant que responsables de traitement afin de r\xe9pondre \xe0 votre demande. Un email avec la liste des professionnels auxquels vos donn\xe9es ont \xe9t\xe9 adress\xe9es vous sera envoy\xe9 afin que vous puissiez exercer vos droits directement aupr\xe8s d’eux."
                        }), (0, s.jsx)(u.Z, {
                            as: "p",
                            marginBottom: "medium",
                            children: "Nous traitons \xe9galement ces donn\xe9es dans le cadre de notre int\xe9r\xeat l\xe9gitime \xe0 vous solliciter de nouveau pour des offres commerciales (et avec votre consentement celles de nos partenaires), \xe0 poursuivre des fins statistiques et d’am\xe9lioration de votre exp\xe9rience utilisateur."
                        }), (0, s.jsx)(u.Z, {
                            as: "p",
                            children: "Ces donn\xe9es sont accessibles aux prestataires de LBC France, dont Adevinta France (soci\xe9t\xe9 m\xe8re de LBC France), sur la base de son int\xe9r\xeat l\xe9gitime, qui concourent administrativement et techniquement \xe0 r\xe9aliser ces finalit\xe9s et sont susceptibles d’\xeatre transf\xe9r\xe9es hors de l’Union europ\xe9enne avec les garanties appropri\xe9es requises (protection \xe9quivalente du pays tiers, r\xe8gles internes contraignantes, contrat de transfert)."
                        })]
                    })
                }), (0, d._)(i, "jobsUploadCV", function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: j("cnil.jobs-upload-cv-privacy-policy-1.text")
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: j("cnil.jobs-upload-cv-privacy-policy-2.text")
                        }), (0, s.jsx)(u.Z, {
                            variant: "body",
                            as: "p",
                            marginBottom: "medium",
                            children: j("cnil.jobs-upload-cv-privacy-policy-3.text")
                        })]
                    })
                }), (0, d._)(i, "jobsCreateProfile", function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            as: "p",
                            marginBottom: "medium",
                            children: j("cnil.jobs-create-profile-privacy-policy-1.text")
                        }), (0, s.jsx)(u.Z, {
                            as: "p",
                            marginBottom: "medium",
                            children: j("cnil.jobs-create-profile-privacy-policy-2.text")
                        }), (0, s.jsx)(u.Z, {
                            as: "p",
                            marginBottom: "medium",
                            children: j("cnil.jobs-create-profile-privacy-policy-3.text")
                        })]
                    })
                }), (0, d._)(i, "referral", function() {
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(u.Z, {
                            as: "p",
                            marginBottom: "medium",
                            children: j("cnil.referral.text")
                        }), (0, s.jsx)(u.Z, {
                            as: "p",
                            marginBottom: "medium",
                            children: j("cnil.referral-following.text")
                        })]
                    })
                }), i),
                Z = n(16816),
                F = n(16928),
                k = n(722),
                C = n(154),
                L = n.n(C),
                _ = function(e) {
                    var t = e.page,
                        n = (0, o.$G)(a.i).t;
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("p", {
                            className: "mb-md text-body-2",
                            children: "adreply" === t || "newHousing" === t || "realEstateRentalManagement" === t ? (0, s.jsxs)("p", {
                                className: "text-body-2",
                                children: [n("cnil.cookie-info.text"), " ", (0, s.jsx)(Z.h.Link, {
                                    to: "".concat(F.R.baseUrl, "/dc/cookies"),
                                    rel: "noopener noreferrer",
                                    target: "_blank",
                                    title: n("cnil.cookie-info-link.title"),
                                    children: (0, s.jsxs)("span", {
                                        className: "text-body-2-link text-info hover:text-info-hovered",
                                        children: [n("cnil.cookie-info.link"), " "]
                                    })
                                }), n("cnil.cookie-info-2.text"), " "]
                            }) : n("cnil.read-more.label")
                        }), (0, s.jsxs)("ul", {
                            className: L().bulletList,
                            children: ["vehiclesEstimation" === t && (0, s.jsxs)("li", {
                                children: [(0, s.jsxs)(u.Z, {
                                    variant: "body",
                                    children: [n("cnil.vehicles-estimation-cookie-info.text"), " "]
                                }), (0, s.jsx)(u.Z, {
                                    as: Z.h.Link,
                                    rel: "noopener noreferrer",
                                    variant: "body",
                                    color: "blue",
                                    colorHover: "blueDark",
                                    target: "_blank",
                                    to: "".concat(F.R.baseUrl, "/dc/cookies#17b"),
                                    title: n("cnil.cookie-info-link.title"),
                                    children: n("cnil.cookie-info-button.link")
                                })]
                            }), (0, s.jsxs)("li", {
                                children: [(0, s.jsxs)(u.Z, {
                                    variant: "body",
                                    children: [n("cnil.cookie-info-3.text"), " "]
                                }), (0, s.jsx)(u.Z, {
                                    as: Z.h.Link,
                                    rel: "noopener noreferrer",
                                    variant: "body",
                                    color: "blue",
                                    colorHover: "blueDark",
                                    target: "_blank",
                                    to: "".concat(F.R.baseUrl, "/dc/cookies#17b"),
                                    title: n("cnil.cookie-info-link.title"),
                                    children: n("cnil.cookie-info-button.link")
                                })]
                            }), (0, s.jsxs)("li", {
                                children: [(0, s.jsxs)(u.Z, {
                                    variant: "body",
                                    children: [n("cnil.cookie-info-4.text"), " "]
                                }), (0, s.jsx)(u.Z, {
                                    as: Z.h.Link,
                                    rel: "noopener noreferrer",
                                    variant: "body",
                                    color: "blue",
                                    colorHover: "blueDark",
                                    target: "_blank",
                                    to: "".concat(F.R.baseUrl, "/dc/cookies#19"),
                                    title: n("cnil.cookie-info-link.title"),
                                    children: n("cnil.cookie-info-button.link")
                                })]
                            }), (0, s.jsxs)("li", {
                                children: ["vehiclesEstimation" === t || "jobsUploadCV" === t ? (0, s.jsxs)(u.Z, {
                                    variant: "body",
                                    children: [n("cnil.cookie-info-5.text"), " "]
                                }) : (0, s.jsxs)(u.Z, {
                                    variant: "body",
                                    children: [n("cnil.cookie-info-6.text"), " "]
                                }), (0, s.jsx)(u.Z, {
                                    as: Z.h.Link,
                                    rel: "noopener noreferrer",
                                    variant: "body",
                                    color: "blue",
                                    colorHover: "blueDark",
                                    target: "_blank",
                                    to: "".concat(F.R.baseUrl, "/dc/cookies#18"),
                                    title: n("cnil.cookie-info-link.title"),
                                    children: n("cnil.cookie-info-button.link")
                                })]
                            }), "partAccountEdit" === t && (0, s.jsxs)(u.Z, {
                                as: "li",
                                marginTop: "medium",
                                marginBottom: "medium",
                                children: [(0, s.jsx)(k.c, {
                                    translation: n("cnil.cookie-info-7.text")
                                }), " ", (0, s.jsx)(u.Z, {
                                    variant: "bodyImportant",
                                    color: "blue",
                                    colorHover: "blueDark",
                                    as: Z.h.Link,
                                    title: n("cnil.adyen-privacy-policy.text"),
                                    href: "https://www.adyen.com/fr_FR/politiques-et-mentions-legales/privacy-policy",
                                    target: "_blank",
                                    rel: "noopener",
                                    children: n("cnil.adyen-privacy-policy.link")
                                }), " ", n("cnil.cookie-info-8.text")]
                            })]
                        }), (t === x.fw.DEPOSIT_AD.name || t === x.fw.EDIT_AD.name) && (0, s.jsx)(s.Fragment, {
                            children: (0, s.jsxs)(u.Z, {
                                as: "span",
                                variant: "body",
                                marginBottom: "medium",
                                children: [n("cnil.right-provider.text"), " ", (0, s.jsx)(u.Z, {
                                    as: Z.h.Link,
                                    rel: "noopener",
                                    color: "blue",
                                    colorHover: "blueDark",
                                    target: "_blank",
                                    to: "https://legal.here.com/en-gb/privacy",
                                    title: n("cnil.right-provider.title"),
                                    children: n("cnil.cookie-info-button.link")
                                })]
                            })
                        })]
                    })
                },
                z = n(45535),
                E = n.n(z),
                D = function(e) {
                    var t, n = e.onClose,
                        i = e.page,
                        d = (0, o.$G)(a.i).t;
                    return (0, s.jsx)(r.Z, {
                        paddingTop: "xx-large",
                        paddingLeft: "xx-large",
                        paddingBottom: "xx-large",
                        paddingRight: "xx-large",
                        onClose: n,
                        children: (0, s.jsxs)("div", {
                            className: E().content,
                            children: [(0, s.jsx)("h2", {
                                className: "mb-md text-headline-1",
                                children: d("cnil.info.title")
                            }), null === (t = B[i]) || void 0 === t ? void 0 : t.call(B), (0, s.jsx)("h3", {
                                className: "mb-md mt-lg text-headline-2",
                                children: d("cnil.info-2.text")
                            }), (0, s.jsx)(_, {
                                page: i
                            })]
                        })
                    })
                }
        },
        26773: function(e, t, n) {
            "use strict";
            n.d(t, {
                i: function() {
                    return i
                }
            });
            var i = "components/cnil-modal"
        },
        154: function(e) {
            e.exports = {
                bulletList: "styles_bulletList__moX9J"
            }
        },
        45535: function(e) {
            e.exports = {
                content: "styles_content__cWfHB"
            }
        }
    }
]);