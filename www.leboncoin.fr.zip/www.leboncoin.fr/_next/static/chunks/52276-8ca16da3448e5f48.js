! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "40a4feed-57c9-422c-a4e6-1a6a7d83e32b", e._sentryDebugIdIdentifier = "sentry-dbid-40a4feed-57c9-422c-a4e6-1a6a7d83e32b")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [52276], {
        12587: function(e, n) {
            n.Z = {
                src: "/_next/static/media/no-picture.3d57f307.png",
                height: 80,
                width: 100,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAHlBMVEX////////////////////////////////////+/v56BqeyAAAACnRSTlOTAcPNo3N0cCsffYrXBgAAAAlwSFlzAAALEwAACxMBAJqcGAAAACpJREFUCJlNxrkNADAMA7Gz5CfZf+EArsKKiCUylv/UMWG4TimEpnqq/QAI6AB48Pl4pgAAAABJRU5ErkJggg==",
                blurWidth: 8,
                blurHeight: 6
            }
        },
        25972: function(e, n, t) {
            t.d(n, {
                z: function() {
                    return A
                },
                c: function() {
                    return w
                }
            });
            var o, r = t(11010),
                i = t(24043),
                a = t(248),
                c = t(70655),
                s = t(26072),
                u = t(43121),
                d = t(67294),
                l = t(16928),
                f = t(62780),
                h = t(16533),
                m = (o = (0, r._)(function() {
                    var e;
                    return (0, c.__generator)(this, function(n) {
                        var t;
                        return t = (0, r._)(function(e) {
                            var n;
                            return (0, c.__generator)(this, function(t) {
                                switch (t.label) {
                                    case 0:
                                        if (!e) return [2, new Set];
                                        t.label = 1;
                                    case 1:
                                        return t.trys.push([1, 3, , 4]), [4, (0, h.W)("".concat(l.R.apiBaseUrl, "/api/dejavu/ids"), {
                                            method: "GET",
                                            headers: {
                                                "Content-Type": "application/json",
                                                Accept: "application/json",
                                                Authorization: "Bearer ".concat(e)
                                            }
                                        })];
                                    case 2:
                                        return n = t.sent(), [2, new Set(n)];
                                    case 3:
                                        return t.sent(), [2, new Set];
                                    case 4:
                                        return [2]
                                }
                            })
                        }), e = function(e) {
                            return t.apply(this, arguments)
                        }, [2, (0, f.ZP)(e)]
                    })
                }), function() {
                    return o.apply(this, arguments)
                }),
                p = "consulted_ads_ids",
                _ = "store_consulted_ads",
                g = function() {
                    return new Set(u.W.getData(p) || [])
                },
                A = function(e) {
                    var n = g(),
                        t = (0, a._)(n);
                    e.forEach(function(e) {
                        n.has(e) || t.unshift(e)
                    });
                    var o = t.slice(0, 500);
                    u.W.storeData(p, o);
                    var r = new CustomEvent(_, {
                        detail: new Set(o)
                    });
                    document.dispatchEvent(r)
                };

            function y() {
                return (y = (0, r._)(function() {
                    var e;
                    return (0, c.__generator)(this, function(n) {
                        switch (n.label) {
                            case 0:
                                return [4, m()];
                            case 1:
                                return e = n.sent(), A((0, a._)(e)), window.consultedAdsIds = e, [2]
                        }
                    })
                })).apply(this, arguments)
            }

            function w() {
                var e = function(e) {
                        o(e.detail)
                    },
                    n = (0, i._)((0, d.useState)(new Set([])), 2),
                    t = n[0],
                    o = n[1];
                return (0, d.useEffect)(function() {
                    return (0, s.ML)() && (window.consultedAdsIds ? o(new Set((0, a._)(g()).concat((0, a._)(window.consultedAdsIds)))) : (window.consultedAdsIds = new Set, function() {
                            return y.apply(this, arguments)
                        }())), document.addEventListener(_, e, !1),
                        function() {
                            return document.removeEventListener(_, e)
                        }
                }, []), {
                    consultedAdsIds: t
                }
            }
        },
        40713: function(e, n, t) {
            t.d(n, {
                BW: function() {
                    return a
                },
                Eq: function() {
                    return c
                },
                TS: function() {
                    return u
                },
                d3: function() {
                    return s
                },
                h6: function() {
                    return r
                },
                lw: function() {
                    return o
                },
                s_: function() {
                    return i
                }
            });
            var o = {
                    _: {
                        imageWidth: "12rem"
                    },
                    tiny: {
                        imageWidth: "24rem"
                    }
                },
                r = {
                    _: {
                        imageWidth: "11rem",
                        imageHeight: "125%"
                    },
                    md: {
                        imageWidth: "17rem",
                        imageHeight: "125%",
                        adParams: "withLabels"
                    }
                },
                i = {
                    _: {
                        imageWidth: "10.1rem",
                        imageHeight: "125%"
                    },
                    md: {
                        imageWidth: "16.1rem",
                        imageHeight: "125%",
                        adParams: "withLabels"
                    }
                },
                a = {
                    direction: "column",
                    adParams: "light"
                },
                c = {
                    _: {
                        direction: "column",
                        imageType: "carousel",
                        adParams: "light"
                    },
                    md: {
                        direction: "column",
                        imageType: "mosaic",
                        adParams: "light"
                    }
                },
                s = {
                    _: {
                        direction: "column",
                        imageHeight: "20rem",
                        adParams: "light"
                    },
                    tiny: {
                        direction: "column",
                        imageHeight: "30rem",
                        adParams: "light"
                    },
                    md: {
                        direction: "row",
                        imageWidth: "31rem",
                        adParams: "light"
                    },
                    lg: {
                        direction: "row",
                        imageWidth: "31rem",
                        adParams: "withLabels"
                    }
                },
                u = {
                    _: {
                        direction: "column",
                        imageHeight: "20rem",
                        imageType: "carousel",
                        adParams: "light"
                    },
                    tiny: {
                        direction: "column",
                        imageHeight: "20rem",
                        imageType: "carousel",
                        adParams: "light"
                    },
                    md: {
                        direction: "column",
                        imageHeight: "30rem",
                        imageType: "mosaic",
                        adParams: "light"
                    },
                    lg: {
                        direction: "row",
                        imageWidth: "47.5rem",
                        imageType: "mosaic",
                        adParams: "withLabels"
                    }
                }
        },
        72122: function(e, n, t) {
            t.d(n, {
                n: function() {
                    return s
                },
                t: function() {
                    return c
                }
            });
            var o = t(35150),
                r = t(18797),
                i = t(36808),
                a = t(40713),
                c = function(e, n) {
                    var t = (0, r.W)(e),
                        c = (0, o.xkK)(t),
                        u = t === o.tl8 || t === o.GRG || t === o.qNt || t === o.Vl0 || t === o.a$n,
                        d = [(0, o.xkK)(o.daZ), (0, o.xkK)(o.Shm), (0, o.xkK)(o.xzz), (0, o.xkK)(o.oJo)].includes(c),
                        l = c === o.weE.ConsumerGoods && t !== o.Fmi;
                    switch (!0) {
                        case c === o.weE.Jobs:
                            return {
                                advertisingId: "jobs",
                                variant: "jobs",
                                showOwnerInfo: l,
                                layouts: {
                                    classified: a.lw,
                                    featured: a.lw,
                                    sponsored: a.lw
                                }
                            };
                        case t !== o.daZ && d || u:
                            return {
                                advertisingId: "bigPicture",
                                variant: "bigPicture",
                                showOwnerInfo: l,
                                layouts: {
                                    classified: a.d3,
                                    featured: a.TS,
                                    sponsored: a.d3
                                }
                            };
                        case (0, o.eZn)(o.lxN, t, n):
                            return {
                                advertisingId: "generic",
                                variant: "generic",
                                showOwnerInfo: l,
                                layouts: {
                                    classified: a.h6,
                                    featured: a.s_,
                                    sponsored: a.s_
                                }
                            };
                        case (0, i.f)(t, n):
                            return {
                                advertisingId: s(l),
                                variant: "generic",
                                showOwnerInfo: l,
                                layouts: {
                                    classified: a.BW,
                                    featured: a.Eq,
                                    sponsored: a.Eq
                                }
                            };
                        default:
                            return {
                                advertisingId: "outlined",
                                variant: "outlined",
                                showOwnerInfo: l,
                                layouts: {
                                    classified: a.lw,
                                    featured: a.lw,
                                    sponsored: a.lw
                                }
                            }
                    }
                },
                s = function(e) {
                    return e ? "mosaic_with_owner" : "mosaic_without_owner"
                }
        },
        26283: function(e, n, t) {
            t.d(n, {
                CN: function() {
                    return u
                },
                N7: function() {
                    return c
                },
                QG: function() {
                    return r
                },
                cj: function() {
                    return h
                },
                dD: function() {
                    return o
                },
                lP: function() {
                    return f
                },
                rZ: function() {
                    return s
                },
                vM: function() {
                    return d
                },
                w0: function() {
                    return a
                },
                x1: function() {
                    return l
                },
                zs: function() {
                    return i
                }
            });
            var o = 30,
                r = {
                    WAITING: "waiting_synchronization",
                    SYNCHRONIZED: "synchronized"
                },
                i = {
                    ABRITEL: "abritel",
                    AIRBNB: "airbnb",
                    GOOGLE: "google"
                },
                a = "onboardingListId",
                c = "holidays:host_calendar_tutorial",
                s = "import_calendar_to_see",
                u = "import_calendar_already_seen",
                d = "first_modification_done",
                l = "holidays:confirm_uptodate_card",
                f = "holidays:acceptance_rate_modal",
                h = {
                    Components: {
                        ACCEPTANCE_RATE: "holidays/components/acceptance-rate",
                        ACCEPTANCE_RATE_CHANGE: "holidays/components/acceptance-rate-change",
                        ACCEPTANCE_RATE_CURRENT: "holidays/components/acceptance-rate-current",
                        AVAILABILITIES_WORKFLOW: "holidays/components/availabilities-workflow",
                        BREADCRUMB: "holidays/components/breadcrumb",
                        HOST_BOOKING_ACCEPTANCE: "holidays/components/host-booking-acceptance",
                        HOST_BOOKING_REFUSAL: "holidays/components/host-booking-refusal",
                        MODAL_HOST_RECOMMENDED: "holidays/components/modal-host-recommended",
                        ONLINE_BOOKING: "holidays/components/online-booking",
                        PAYMENT: "holidays/components/payment",
                        PHONE: "holidays/components/phone",
                        UTILS: "holidays/components/utils",
                        DASHBOARD_PART_BANNER: "holidays/components/dashboard-part-banner",
                        TRIPPER_CALENDAR: "holidays/components/tripper-calendar",
                        TRIPPER_PROTECTION: "holidays/components/tripper-protection"
                    },
                    ACCOUNT_PORTAL: "holidays/account-portal",
                    BOOKING: "account/bookings",
                    COLLECTED_DATA: "holidays/collected-data",
                    COMMON: "holidays/common",
                    HOST_CALENDAR_ONBOARDING: "holidays/host-calendar-onboarding",
                    HOST_CALENDAR_PARAMETERS: "holidays/host-calendar-parameters",
                    HOST_CALENDAR: "holidays/host-calendar",
                    HOST_LANDING_PAGE: "holidays/host-landing-page",
                    HOST_RESERVATIONS: "holidays/host-reservations",
                    TRIPPER_BOOKING_FORM: "holidays/tripper-booking-form"
                }
        },
        47611: function(e, n, t) {
            t.d(n, {
                EF: function() {
                    return y
                },
                Fd: function() {
                    return _
                },
                K8: function() {
                    return b
                },
                LM: function() {
                    return l
                },
                SG: function() {
                    return m
                },
                YF: function() {
                    return g
                },
                hQ: function() {
                    return w
                },
                qi: function() {
                    return E
                },
                u9: function() {
                    return A
                },
                uq: function() {
                    return h
                },
                yq: function() {
                    return f
                },
                zg: function() {
                    return p
                }
            });
            var o = t(35150),
                r = t(4085),
                i = t(29726),
                a = t(57327),
                c = t(26283),
                s = t(10736),
                u = t(61045),
                d = (0, a.i0)("holidays/common"),
                l = function(e) {
                    return e ? "https://assistance.leboncoin.info/hc/fr/articles/360012783540-COVID-19-Quelles-sont-les-conditions-exceptionnelles-d-annulation-des-s%C3%A9jours-" : "https://assistance.leboncoin.info/hc/fr/articles/360000474999"
                },
                f = function(e) {
                    var n = e.category_id,
                        t = e.attributes;
                    return h({
                        categoryId: n,
                        isBookable: (0, i.Ck)(e),
                        acceptanceRateLevel: (0, i.Fr)(t)
                    })
                },
                h = function(e) {
                    var n = e.categoryId,
                        t = e.isBookable,
                        r = e.acceptanceRateLevel;
                    return (0, o.eWq)(o.weE.Holidays, n) && t && "high" === r
                },
                m = function(e) {
                    var n = e.nbAdults,
                        t = e.nbChildren,
                        o = void 0 === t ? 0 : t,
                        r = e.nbBabies,
                        i = void 0 === r ? 0 : r,
                        s = e.nbPets,
                        u = void 0 === s ? 0 : s,
                        d = (0, a.i0)(c.cj.Components.UTILS);
                    return [{
                        count: n,
                        label: d("people.adults.text", {
                            count: n
                        })
                    }, {
                        count: o,
                        label: d("people.children.text", {
                            count: o
                        })
                    }, {
                        count: i,
                        label: d("people.babies.text", {
                            count: i
                        })
                    }, {
                        count: u,
                        label: d("people.pets.text", {
                            count: u
                        })
                    }].filter(function(e) {
                        return e.count > 0
                    }).map(function(e) {
                        return e.count + "\xa0" + e.label
                    }).join(", ")
                },
                p = function(e) {
                    return (0, r.zk)(e) ? d("common.today.text") : (0, r.gO)(e) ? d("common.yesterday.text") : d("common.days-ago.text", {
                        days: (0, r.Zh)(e)
                    })
                },
                _ = function(e) {
                    var n, t = null === (n = e.find(function(e) {
                        return (null == e ? void 0 : e.key) === "calendar_confirmed_at"
                    })) || void 0 === n ? void 0 : n.value;
                    return t ? (0, r.Qc)(t, r.bd.RFC_3339) : null
                },
                g = function(e, n, t) {
                    return e && n && A(t)
                },
                A = function(e) {
                    var n = (0, r.ZU)((0, r.fw)(Date.now())).setHours(0, 0, 0);
                    return null === e || (0, r.eX)(n, (0, r.fw)(e).setHours(0, 0, 0)) > 30
                },
                y = function(e) {
                    switch (e) {
                        case "low":
                        case "insufficient_refused":
                            return {
                                iconColor: "error",
                                textColor: "text-error"
                            };
                        case "high":
                        case "insufficient_accepted":
                            return {
                                iconColor: "success",
                                textColor: "text-success"
                            };
                        default:
                            return {
                                iconColor: "current",
                                textColor: "text-current"
                            }
                    }
                },
                w = function(e) {
                    return 1 > (0, r.eX)((0, r.fw)(e), Date.now())
                },
                b = function(e, n) {
                    var t = (0, r.ZU)((0, r.fw)(Date.now())).setHours(0, 0, 0);
                    return n && e && 30 > (0, r.eX)(t, e.setHours(0, 0, 0))
                },
                E = function(e) {
                    return (0, s.Yq)(e, u.fY)
                }
        },
        30773: function(e, n, t) {
            t.d(n, {
                BP: function() {
                    return i
                },
                EG: function() {
                    return r
                },
                Jf: function() {
                    return a
                },
                Oh: function() {
                    return o
                },
                Ov: function() {
                    return c
                }
            });
            var o = {
                    intent: "true",
                    pagetype: "annonce_contacter",
                    clicknumero: "click"
                },
                r = {
                    intent: "true",
                    pagetype: "annonce_favori",
                    clicked_annonce_saved: "click"
                },
                i = {
                    intent: "true",
                    pagetype: "annonce_contacter",
                    clickmessage: "click"
                },
                a = {
                    intent: "true",
                    pagetype: "p2p",
                    clickachat: "click"
                },
                c = {
                    intent: "true",
                    pagetype: "p2p",
                    clickresa: "click"
                }
        },
        1718: function(e, n, t) {
            t.d(n, {
                Mh: function() {
                    return u
                }
            });
            var o = t(72253),
                r = t(24043),
                i = t(26072),
                a = t(13570),
                c = t(76883),
                s = t(2488),
                u = function(e) {
                    var n = e.payload,
                        t = e.user,
                        a = e.onLoad;
                    if ((0, i.ML)()) {
                        var u = Object.entries(n).reduce(function(e, n) {
                                var t = (0, r._)(n, 2),
                                    o = t[0],
                                    i = t[1];
                                return "search_filters" === o || i && (e[o] = i), e
                            }, {}),
                            f = (0, o._)({}, u, {
                                device: s.n.device(),
                                compte: l(t),
                                userid: s.n.userid({
                                    user: t
                                }),
                                user_id: s.n.user_id({
                                    user: t
                                }),
                                usidh: c.iK.accountIdHashed(t),
                                email_hashe: s.n.emailHashed({
                                    user: t
                                }),
                                statut_retency: d("c:retency-CLerZiGL"),
                                statut_mobsucess: d("663"),
                                statut_happydemics: d("550"),
                                statut_google: d("google"),
                                statut_xandr: d("32"),
                                statut_kairos: d("569"),
                                statut_adsquare: d("66"),
                                statut_facebook: d("facebook"),
                                statut_snapchat: d("c:snapinc-yhYnJZfT"),
                                statut_hawk: d("275"),
                                statut_linkedin: d("804")
                            });
                        a ? c._q.sendPageLoadWeborama(f) : c._q.sendUlimitedAdLoadWeborama(f)
                    }
                },
                d = function(e) {
                    return (0, a.Jy)(e) ? "true" : "false"
                },
                l = function(e) {
                    return "0" === s.n.compte({
                        user: e
                    }) ? 10 : s.n.compte({
                        user: e
                    })
                }
        }
    }
]);