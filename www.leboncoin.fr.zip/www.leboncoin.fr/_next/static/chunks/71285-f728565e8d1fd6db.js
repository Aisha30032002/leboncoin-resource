! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "c859feab-1fc4-460b-9e08-dcfa99127cf3", e._sentryDebugIdIdentifier = "sentry-dbid-c859feab-1fc4-460b-9e08-dcfa99127cf3")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
}, (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [71285], {
        46886: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ng: function() {
                    return k
                },
                OX: function() {
                    return S
                },
                ZP: function() {
                    return L
                },
                cC: function() {
                    return w
                },
                ze: function() {
                    return _
                }
            });
            var r = n(4942),
                o = n(45987),
                i = n(26072),
                a = n(73935),
                l = n(54483),
                u = n.n(l),
                c = n(67294),
                s = n(82876),
                f = n(87462),
                d = n(33233),
                p = n(61148),
                m = n(24292),
                h = n(16678),
                v = n(19181),
                g = n(97685),
                y = (0, c.createContext)({
                    placement: "left",
                    size: "medium",
                    status: "closed",
                    isOpen: !1
                }),
                b = (0, v.default)("button").withConfig({
                    displayName: "indexstyles__DrawerCloseButton",
                    componentId: "sc-1petw59-0"
                })(function(e) {
                    var t = e.theme;
                    return (0, v.css)(["position:absolute;right:0;top:0;display:flex;align-items:center;justify-content:center;border:none;cursor:pointer;border-radius:100%;background-color:", ";padding:", ";margin:", ";"], t.colors.white, t.space.small, t.space.small)
                }, (0, h.qC)(h.Dh, h.bK)),
                w = function(e) {
                    var t = (0, f.Z)({}, e),
                        n = (0, c.useContext)(y).onClose;
                    return c.createElement(b, (0, f.Z)({
                        onClick: n,
                        title: "Fermer"
                    }, (0, m.e)(t)), c.createElement(p.ZP, {
                        color: "grey",
                        colorHover: "greyDark"
                    }, c.createElement(d.Z, null)))
                };
            w.displayName = "DrawerCloseButton";
            var E = function(e, t) {
                    return (0, v.keyframes)(["from{transform:translateX(", ");}to{transform:translateX(", ");}"], e, t)
                },
                x = function(e, t) {
                    return (0, v.keyframes)(["from{transform:translateY(", ");}to{transform:translateY(", ");}"], e, t)
                },
                C = (0, v.keyframes)(["from{opacity:0;}to{opacity:1;}"]),
                O = (0, v.keyframes)(["from{opacity:1;}to{opacity:0;}"]),
                P = (0, v.default)("section").withConfig({
                    displayName: "indexstyles__DrawerContentSizeWrapper",
                    componentId: "sc-br61gi-0"
                })(function(e) {
                    var t = e.theme,
                        n = e.placement,
                        r = (0, v.css)("top" === n || "bottom" === n ? ["max-height:100vh;max-height:-webkit-fill-available;"] : ["max-width:100vw;"]);
                    return (0, v.css)(["", " ", " display:flex;position:fixed;z-index:", ";"], r, "left" === n || "right" === n ? (0, v.css)(["top:0;bottom:0;height:100%;min-width:28rem;", ""], "left" === n ? "left: 0;" : "right: 0;") : (0, v.css)(["left:0;right:0;width:100vw;min-height:10rem;", ""], "top" === n ? "top: 0;" : "bottom: 0;"), t.zIndices.modal)
                }),
                N = (0, v.default)("div").withConfig({
                    displayName: "indexstyles__DrawerContent",
                    componentId: "sc-br61gi-1"
                })(function(e) {
                    var t, n = e.theme,
                        r = e.placement,
                        o = e.size,
                        i = e.isOpen;
                    return (0, v.css)(["background-color:", ";box-shadow:", ";display:flex;flex-direction:column;", " ", "  animation-name:", ";animation-fill-mode:forwards;animation-duration:220ms;"], n.colors.white, n.shadows.normal, (t = {
                        small: "32rem",
                        medium: "48rem",
                        large: "64rem"
                    }, "left" === r || "right" === r ? (0, v.css)(["height:100%;width:", ";max-width:", ";min-width:0;"], t[o], t[o]) : (0, v.css)(["width:100%;max-height:", ";"], t[o])), (0, v.css)({
                        transform: "".concat("left" === r || "right" === r ? "translateX" : "translateY", "(").concat("left" === r || "top" === r ? "-100%" : "100%", ")")
                    }), i ? "left" === r ? E("-100%", "0%") : "right" === r ? E("100%", "0%") : x("top" === r ? "-100%" : "100%", "0%") : "left" === r ? E("0%", "-100%") : "right" === r ? E("0%", "100%") : x("0%", "top" === r ? "-100%" : "100%"))
                }, h.Dh);
            P.displayName = "DrawerSizeController", N.displayName = "StyledDrawerContent";
            var R = function(e) {
                var t = e.children,
                    n = (0, c.useContext)(y),
                    r = n.isOpen,
                    o = n.placement,
                    i = n.size,
                    a = n.ariaLabelledby;
                return c.createElement(P, {
                    placement: o
                }, c.createElement(N, {
                    role: "dialog",
                    "aria-modal": "true",
                    "aria-labelledby": a,
                    isOpen: r,
                    placement: o,
                    size: i
                }, t))
            };
            R.displayName = "DrawerContent";
            var T = function() {
                    return (0, h.qC)(h.Dh, h.$_, h.bK, h.GQ, h.eC, h.Oq, h.Cg, h.AF)
                },
                S = (0, v.default)("header").withConfig({
                    displayName: "indexstyles__DrawerHeader",
                    componentId: "sc-1dl3tjg-0"
                })(function(e) {
                    var t = e.theme;
                    return (0, v.css)(["padding:", ";background-color:", ";border-bottom:1px solid ", ";"], t.space.medium, t.colors.white, t.colors.greyLight)
                }, T()),
                k = (0, v.default)("div").withConfig({
                    displayName: "indexstyles__DrawerBody",
                    componentId: "sc-1dl3tjg-1"
                })(function(e) {
                    var t = e.theme;
                    return (0, v.css)(["padding:", ";overflow:auto;"], t.space.medium)
                }, T()),
                _ = (0, v.default)("footer").withConfig({
                    displayName: "indexstyles__DrawerFooter",
                    componentId: "sc-1dl3tjg-2"
                })(function(e) {
                    var t = e.theme;
                    return (0, v.css)(["padding:", ";background-color:", ";margin-top:auto;border-top:1px solid ", ";"], t.space.medium, t.colors.white, t.colors.greyLight)
                }, T()),
                A = (0, v.default)("div").withConfig({
                    displayName: "indexstyles__DrawerOverlay",
                    componentId: "sc-nf95zu-0"
                })(function(e) {
                    var t = e.theme,
                        n = e.isOpen;
                    return (0, v.css)(["position:fixed;top:0;left:0;z-index:", ";width:100vw;height:100vh;height:-webkit-fill-available;background-color:rgba(0,0,0,0.6);animation-name:", ";animation-fill-mode:forwards;animation-duration:220ms;"], t.zIndices.overlay, n ? C : O)
                }),
                F = function() {
                    var e = (0, c.useContext)(y),
                        t = e.onClose,
                        n = e.isOpen;
                    return c.createElement(A, {
                        isOpen: n,
                        onClick: t
                    })
                };
            F.displayName = "DrawerOverlay";
            var D = ["initialFocus", "preventScroll"];

            function z(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), n.push.apply(n, r)
                }
                return n
            }
            var L = function(e) {
                var t, n, l, f, d, p, m, h, v, b, w, E = e.children,
                    x = e.isOpen,
                    C = e.placement,
                    O = e.size,
                    P = e.hasFocusTrap,
                    N = e.ariaLabelledby,
                    T = e.onClose,
                    S = e.focusTrapOptions,
                    k = void 0 === S ? {} : S,
                    _ = (n = (t = {
                        isOpen: x
                    }).isOpen, f = void 0 === (l = t.duration) ? 220 : l, d = (0, c.useRef)(!1), p = (0, c.useState)(n ? "opened" : "closed"), h = (m = (0, g.Z)(p, 2))[0], v = m[1], b = (0, c.useRef)(), (0, c.useEffect)(function() {
                        return d.current ? (b.current && clearTimeout(b.current), v(n ? "openning" : "closing"), b.current = setTimeout(function() {
                                v(n ? "opened" : "closed")
                            }, f)) : d.current = !0,
                            function() {
                                b.current && clearTimeout(b.current)
                            }
                    }, [n]), h),
                    A = k.initialFocus,
                    L = k.preventScroll,
                    I = (0, o.Z)(k, D);
                (function(e) {
                    var t = {};

                    function n() {
                        "hidden" !== t.overflow && Object.assign(document.body.style, t)
                    }(0, c.useEffect)(function() {
                        var r;
                        return e ? (t = {
                                overflow: (r = document.body.style).overflow
                            }, Object.assign(r, {
                                overflow: "hidden"
                            })) : n(),
                            function() {
                                n()
                            }
                    }, [e])
                })("closed" !== _), w = function(e) {
                    "Escape" === e.key && T()
                }, (0, c.useEffect)(function() {
                    return document.addEventListener("keydown", w), "closed" === _ && document.removeEventListener("keydown", w),
                        function() {
                            document.removeEventListener("keydown", w)
                        }
                }, [_]), (0, s.b6)(function() {
                    "opened" === _ && j()
                }), (0, s.lR)(function() {
                    "openning" === _ && j()
                }, [_]);
                var j = function() {
                        if (A && !L) {
                            var e = "function" == typeof A ? A() : "string" == typeof A ? document.querySelector(A) : A;
                            e && e.scrollIntoView()
                        }
                    },
                    M = (0, i.ML)() ? document.getElementById("root-portal") || document.body : void 0;
                return M && "closed" !== _ ? (0, a.createPortal)(c.createElement(y.Provider, {
                    value: {
                        placement: void 0 === C ? "left" : C,
                        size: void 0 === O ? "medium" : O,
                        status: _,
                        onClose: T,
                        isOpen: x,
                        ariaLabelledby: N
                    }
                }, c.createElement(u(), {
                    active: (void 0 === P || P) && x,
                    focusTrapOptions: function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? arguments[t] : {};
                            t % 2 ? z(Object(n), !0).forEach(function(t) {
                                (0, r.Z)(e, t, n[t])
                            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : z(Object(n)).forEach(function(t) {
                                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                            })
                        }
                        return e
                    }({
                        initialFocus: A,
                        preventScroll: L
                    }, I)
                }, c.createElement("div", null, c.createElement(F, null), c.createElement(R, null, E)))), M) : null
            };
            L.displayName = "Drawer"
        },
        82876: function(e, t, n) {
            "use strict";
            n.d(t, {
                OR: function() {
                    return u
                },
                b6: function() {
                    return c
                },
                iP: function() {
                    return d
                },
                kw: function() {
                    return s
                },
                lR: function() {
                    return l
                }
            });
            var r = n(67294),
                o = n(97685),
                i = n(26072),
                a = n(27856);

            function l(e, t) {
                var n = (0, r.useRef)(!1);
                (0, r.useEffect)(function() {
                    n.current ? e() : n.current = !0
                }, t)
            }

            function u(e, t, n) {
                var o = (0, r.useRef)();
                (0, r.useEffect)(function() {
                    var r = (null == n ? void 0 : n.current) || window;
                    o.current !== t && (o.current = t);
                    var i = function(e) {
                        null != o && o.current && o.current(e)
                    };
                    return r.addEventListener(e, i),
                        function() {
                            r.removeEventListener(e, i)
                        }
                }, [e, n, t])
            }

            function c(e) {
                (0, r.useEffect)(function() {
                    e()
                }, [])
            }

            function s(e) {
                (0, r.useEffect)(function() {
                    return function() {
                        return e()
                    }
                }, [])
            }
            var f = function() {
                return {
                    width: (0, i.ML)() ? window.innerWidth : 0,
                    height: (0, i.ML)() ? window.innerHeight : 0
                }
            };

            function d() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 500,
                    t = (0, r.useState)(f),
                    n = (0, o.Z)(t, 2),
                    i = n[0],
                    l = n[1];
                return (0, r.useEffect)(function() {
                    var t = (0, a.D)(e, function(e) {
                            l(e)
                        }),
                        n = function() {
                            t(f())
                        };
                    return window.addEventListener("resize", n),
                        function() {
                            return window.removeEventListener("resize", n)
                        }
                }, [e]), i
            }
        },
        33487: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return i
                }
            });
            var r, o = n(67294);

            function i(e) {
                return r || (r = o.createElement("symbol", {
                    id: "SvgBurgermenu"
                }, o.createElement("path", {
                    d: "M1.111 14H18.89C19.5 14 20 13.475 20 12.833c0-.641-.5-1.166-1.111-1.166H1.11C.5 11.667 0 12.192 0 12.833 0 13.475.5 14 1.111 14zm0-5.833H18.89C19.5 8.167 20 7.642 20 7s-.5-1.167-1.111-1.167H1.11C.5 5.833 0 6.358 0 7s.5 1.167 1.111 1.167zM0 1.167c0 .641.5 1.166 1.111 1.166H18.89C19.5 2.333 20 1.808 20 1.167 20 .525 19.5 0 18.889 0H1.11C.5 0 0 .525 0 1.167z",
                    fillRule: "evenodd"
                })))
            }
            i.displayName = "SvgBurgermenu", i.defaultProps = {
                viewBox: "0 0 20 14"
            }
        },
        54483: function(e, t, n) {
            "use strict";

            function r(e) {
                return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function o(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }

            function i(e, t) {
                return (i = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }

            function a(e) {
                return (a = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                })(e)
            }
            var l = n(67294),
                u = n(73935),
                c = n(45697),
                s = n(36959).createFocusTrap,
                f = function(e) {
                    ! function(e, t) {
                        if ("function" != typeof t && null !== t) throw TypeError("Super expression must either be null or a function");
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                writable: !0,
                                configurable: !0
                            }
                        }), t && i(e, t)
                    }(f, e);
                    var t, n, c, s = (t = function() {
                        if ("undefined" == typeof Reflect || !Reflect.construct || Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                        } catch (e) {
                            return !1
                        }
                    }(), function() {
                        var e, n = a(f);
                        if (t) {
                            var o = a(this).constructor;
                            e = Reflect.construct(n, arguments, o)
                        } else e = n.apply(this, arguments);
                        return function(e, t) {
                            if (t && ("object" === r(t) || "function" == typeof t)) return t;
                            if (void 0 !== t) throw TypeError("Derived constructors may only return object or undefined");
                            return function(e) {
                                if (void 0 === e) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return e
                            }(e)
                        }(this, e)
                    });

                    function f(e) {
                        (function(e, t) {
                            if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                        })(this, f), (t = s.call(this, e)).tailoredFocusTrapOptions = {
                            returnFocusOnDeactivate: !1
                        }, t.returnFocusOnDeactivate = !0;
                        var t, n = e.focusTrapOptions;
                        for (var r in n)
                            if (Object.prototype.hasOwnProperty.call(n, r)) {
                                if ("returnFocusOnDeactivate" === r) {
                                    t.returnFocusOnDeactivate = !!n[r];
                                    continue
                                }
                                if ("onPostDeactivate" === r) {
                                    t.onPostDeactivate = n[r];
                                    continue
                                }
                                t.tailoredFocusTrapOptions[r] = n[r]
                            }
                        return t.focusTrapElements = e.containerElements || [], t.updatePreviousElement(), t
                    }
                    return n = [{
                        key: "getNodeForOption",
                        value: function(e) {
                            var t = this.tailoredFocusTrapOptions[e];
                            if (!t) return null;
                            var n = t;
                            if ("string" == typeof t && !(n = document.querySelector(t))) throw Error("`".concat(e, "` refers to no known node"));
                            if ("function" == typeof t && !(n = t())) throw Error("`".concat(e, "` did not return a node"));
                            return n
                        }
                    }, {
                        key: "getReturnFocusNode",
                        value: function() {
                            return this.getNodeForOption("setReturnFocus") || this.previouslyFocusedElement
                        }
                    }, {
                        key: "updatePreviousElement",
                        value: function() {
                            var e = this.props.focusTrapOptions.document || ("undefined" != typeof document ? document : void 0);
                            e && (this.previouslyFocusedElement = e.activeElement)
                        }
                    }, {
                        key: "deactivateTrap",
                        value: function() {
                            var e = this,
                                t = this.tailoredFocusTrapOptions,
                                n = t.checkCanReturnFocus,
                                r = t.preventScroll,
                                o = void 0 !== r && r;
                            this.focusTrap && this.focusTrap.deactivate({
                                returnFocus: !1
                            });
                            var i = function() {
                                var t = e.getReturnFocusNode();
                                (null == t ? void 0 : t.focus) && e.returnFocusOnDeactivate && t.focus({
                                    preventScroll: o
                                }), e.onPostDeactivate && e.onPostDeactivate.call(null)
                            };
                            n ? n(this.getReturnFocusNode()).then(i, i) : i()
                        }
                    }, {
                        key: "setupFocusTrap",
                        value: function() {
                            if (!this.focusTrap) {
                                var e = this.focusTrapElements.map(u.findDOMNode);
                                e.some(Boolean) && (this.focusTrap = this.props._createFocusTrap(e, this.tailoredFocusTrapOptions), this.props.active && this.focusTrap.activate(), this.props.paused && this.focusTrap.pause())
                            }
                        }
                    }, {
                        key: "componentDidMount",
                        value: function() {
                            this.setupFocusTrap()
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function(e) {
                            if (this.focusTrap) {
                                e.containerElements !== this.props.containerElements && this.focusTrap.updateContainerElements(this.props.containerElements);
                                var t = !e.active && this.props.active,
                                    n = e.active && !this.props.active,
                                    r = !e.paused && this.props.paused,
                                    o = e.paused && !this.props.paused;
                                if (t && (this.updatePreviousElement(), this.focusTrap.activate()), n) {
                                    this.deactivateTrap();
                                    return
                                }
                                r && this.focusTrap.pause(), o && this.focusTrap.unpause()
                            } else e.containerElements !== this.props.containerElements && (this.focusTrapElements = this.props.containerElements, this.setupFocusTrap())
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.deactivateTrap()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.children ? l.Children.only(this.props.children) : void 0;
                            if (t) {
                                if (t.type && t.type === l.Fragment) throw Error("A focus-trap cannot use a Fragment as its child container. Try replacing it with a <div> element.");
                                return l.cloneElement(t, {
                                    ref: function(n) {
                                        var r = e.props.containerElements;
                                        t && ("function" == typeof t.ref ? t.ref(n) : t.ref && (t.ref.current = n)), e.focusTrapElements = r || [n]
                                    }
                                })
                            }
                            return null
                        }
                    }], o(f.prototype, n), c && o(f, c), f
                }(l.Component),
                d = "undefined" == typeof Element ? Function : Element;
            f.propTypes = {
                active: c.bool,
                paused: c.bool,
                focusTrapOptions: c.shape({
                    document: c.object,
                    onActivate: c.func,
                    onPostActivate: c.func,
                    checkCanFocusTrap: c.func,
                    onDeactivate: c.func,
                    onPostDeactivate: c.func,
                    checkCanReturnFocus: c.func,
                    initialFocus: c.oneOfType([c.instanceOf(d), c.string, c.func, c.bool]),
                    fallbackFocus: c.oneOfType([c.instanceOf(d), c.string, c.func]),
                    escapeDeactivates: c.oneOfType([c.bool, c.func]),
                    clickOutsideDeactivates: c.oneOfType([c.bool, c.func]),
                    returnFocusOnDeactivate: c.bool,
                    setReturnFocus: c.oneOfType([c.instanceOf(d), c.string, c.func]),
                    allowOutsideClick: c.oneOfType([c.bool, c.func]),
                    preventScroll: c.bool
                }),
                containerElements: c.arrayOf(c.instanceOf(d)),
                children: c.oneOfType([c.element, c.instanceOf(d)])
            }, f.defaultProps = {
                active: !0,
                paused: !1,
                focusTrapOptions: {},
                _createFocusTrap: s
            }, e.exports = f
        },
        36959: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                createFocusTrap: function() {
                    return R
                }
            });
            /*!
             * tabbable 5.2.1
             * @license MIT, https://github.com/focus-trap/tabbable/blob/master/LICENSE
             */
            var r, o = ["input", "select", "textarea", "a[href]", "button", "[tabindex]", "audio[controls]", "video[controls]", '[contenteditable]:not([contenteditable="false"])', "details>summary:first-of-type", "details"],
                i = o.join(","),
                a = "undefined" == typeof Element ? function() {} : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector,
                l = function(e, t, n) {
                    var r = Array.prototype.slice.apply(e.querySelectorAll(i));
                    return t && a.call(e, i) && r.unshift(e), r = r.filter(n)
                },
                u = function(e) {
                    var t = parseInt(e.getAttribute("tabindex"), 10);
                    return isNaN(t) ? "true" === e.contentEditable || ("AUDIO" === e.nodeName || "VIDEO" === e.nodeName || "DETAILS" === e.nodeName) && null === e.getAttribute("tabindex") ? 0 : e.tabIndex : t
                },
                c = function(e, t) {
                    return e.tabIndex === t.tabIndex ? e.documentOrder - t.documentOrder : e.tabIndex - t.tabIndex
                },
                s = function(e) {
                    return "INPUT" === e.tagName
                },
                f = function(e, t) {
                    for (var n = 0; n < e.length; n++)
                        if (e[n].checked && e[n].form === t) return e[n]
                },
                d = function(e) {
                    if (!e.name) return !0;
                    var t, n = e.form || e.ownerDocument,
                        r = function(e) {
                            return n.querySelectorAll('input[type="radio"][name="' + e + '"]')
                        };
                    if ("undefined" != typeof window && void 0 !== window.CSS && "function" == typeof window.CSS.escape) t = r(window.CSS.escape(e.name));
                    else try {
                        t = r(e.name)
                    } catch (e) {
                        return console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s", e.message), !1
                    }
                    var o = f(t, e.form);
                    return !o || o === e
                },
                p = function(e, t) {
                    if ("hidden" === getComputedStyle(e).visibility) return !0;
                    var n = a.call(e, "details>summary:first-of-type") ? e.parentElement : e;
                    if (a.call(n, "details:not([open]) *")) return !0;
                    if (t && "full" !== t) {
                        if ("non-zero-area" === t) {
                            var r = e.getBoundingClientRect(),
                                o = r.width,
                                i = r.height;
                            return 0 === o && 0 === i
                        }
                    } else
                        for (; e;) {
                            if ("none" === getComputedStyle(e).display) return !0;
                            e = e.parentElement
                        }
                    return !1
                },
                m = function(e) {
                    if (s(e) || "SELECT" === e.tagName || "TEXTAREA" === e.tagName || "BUTTON" === e.tagName)
                        for (var t = e.parentElement; t;) {
                            if ("FIELDSET" === t.tagName && t.disabled) {
                                for (var n = 0; n < t.children.length; n++) {
                                    var r = t.children.item(n);
                                    if ("LEGEND" === r.tagName) {
                                        if (r.contains(e)) return !1;
                                        break
                                    }
                                }
                                return !0
                            }
                            t = t.parentElement
                        }
                    return !1
                },
                h = function(e, t) {
                    return !(t.disabled || s(t) && "hidden" === t.type || p(t, e.displayCheck) || "DETAILS" === t.tagName && Array.prototype.slice.apply(t.children).some(function(e) {
                        return "SUMMARY" === e.tagName
                    }) || m(t))
                },
                v = function(e, t) {
                    var n;
                    return !(!h(e, t) || s(n = t) && "radio" === n.type && !d(n) || 0 > u(t))
                },
                g = function(e, t) {
                    var n = [],
                        r = [];
                    return l(e, (t = t || {}).includeContainer, v.bind(null, t)).forEach(function(e, t) {
                        var o = u(e);
                        0 === o ? n.push(e) : r.push({
                            documentOrder: t,
                            tabIndex: o,
                            node: e
                        })
                    }), r.sort(c).map(function(e) {
                        return e.node
                    }).concat(n)
                },
                y = function(e, t) {
                    if (t = t || {}, !e) throw Error("No node provided");
                    return !1 !== a.call(e, i) && v(t, e)
                },
                b = o.concat("iframe").join(","),
                w = function(e, t) {
                    if (t = t || {}, !e) throw Error("No node provided");
                    return !1 !== a.call(e, b) && h(t, e)
                };
            /*!
             * focus-trap 6.7.3
             * @license MIT, https://github.com/focus-trap/focus-trap/blob/master/LICENSE
             */
            function E(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), n.push.apply(n, r)
                }
                return n
            }
            var x = (r = [], {
                    activateTrap: function(e) {
                        if (r.length > 0) {
                            var t = r[r.length - 1];
                            t !== e && t.pause()
                        }
                        var n = r.indexOf(e); - 1 === n || r.splice(n, 1), r.push(e)
                    },
                    deactivateTrap: function(e) {
                        var t = r.indexOf(e); - 1 !== t && r.splice(t, 1), r.length > 0 && r[r.length - 1].unpause()
                    }
                }),
                C = function(e) {
                    return setTimeout(e, 0)
                },
                O = function(e, t) {
                    var n = -1;
                    return e.every(function(e, r) {
                        return !t(e) || (n = r, !1)
                    }), n
                },
                P = function(e) {
                    for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                    return "function" == typeof e ? e.apply(void 0, n) : e
                },
                N = function(e) {
                    return e.target.shadowRoot && "function" == typeof e.composedPath ? e.composedPath()[0] : e.target
                },
                R = function(e, t) {
                    var n, r = (null == t ? void 0 : t.document) || document,
                        o = function(e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var n = null != arguments[t] ? arguments[t] : {};
                                t % 2 ? E(Object(n), !0).forEach(function(t) {
                                    var r, o;
                                    r = e, o = n[t], t in r ? Object.defineProperty(r, t, {
                                        value: o,
                                        enumerable: !0,
                                        configurable: !0,
                                        writable: !0
                                    }) : r[t] = o
                                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : E(Object(n)).forEach(function(t) {
                                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                })
                            }
                            return e
                        }({
                            returnFocusOnDeactivate: !0,
                            escapeDeactivates: !0,
                            delayInitialFocus: !0
                        }, t),
                        i = {
                            containers: [],
                            tabbableGroups: [],
                            nodeFocusedBeforeActivation: null,
                            mostRecentlyFocusedNode: null,
                            active: !1,
                            paused: !1,
                            delayInitialFocusTimer: void 0
                        },
                        a = function(e, t, n) {
                            return e && void 0 !== e[t] ? e[t] : o[n || t]
                        },
                        u = function(e) {
                            return !!(e && i.containers.some(function(t) {
                                return t.contains(e)
                            }))
                        },
                        c = function(e) {
                            var t = o[e];
                            if ("function" == typeof t) {
                                for (var n = arguments.length, i = Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) i[a - 1] = arguments[a];
                                t = t.apply(void 0, i)
                            }
                            if (!t) {
                                if (void 0 === t || !1 === t) return t;
                                throw Error("`".concat(e, "` was specified but was not a node, or did not return a node"))
                            }
                            var l = t;
                            if ("string" == typeof t && !(l = r.querySelector(t))) throw Error("`".concat(e, "` as selector refers to no known node"));
                            return l
                        },
                        s = function() {
                            var e = c("initialFocus");
                            if (!1 === e) return !1;
                            if (void 0 === e) {
                                if (u(r.activeElement)) e = r.activeElement;
                                else {
                                    var t = i.tabbableGroups[0];
                                    e = t && t.firstTabbableNode || c("fallbackFocus")
                                }
                            }
                            if (!e) throw Error("Your focus-trap needs to have at least one focusable element");
                            return e
                        },
                        f = function() {
                            if (i.tabbableGroups = i.containers.map(function(e) {
                                    var t, n = g(e),
                                        r = l(e, (t = t || {}).includeContainer, h.bind(null, t));
                                    if (n.length > 0) return {
                                        container: e,
                                        firstTabbableNode: n[0],
                                        lastTabbableNode: n[n.length - 1],
                                        nextTabbableNode: function(e) {
                                            var t = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1],
                                                n = r.findIndex(function(t) {
                                                    return t === e
                                                });
                                            return t ? r.slice(n + 1).find(function(e) {
                                                return y(e)
                                            }) : r.slice(0, n).reverse().find(function(e) {
                                                return y(e)
                                            })
                                        }
                                    }
                                }).filter(function(e) {
                                    return !!e
                                }), i.tabbableGroups.length <= 0 && !c("fallbackFocus")) throw Error("Your focus-trap must have at least one container with at least one tabbable node in it at all times")
                        },
                        d = function e(t) {
                            if (!1 !== t && t !== r.activeElement) {
                                if (!t || !t.focus) {
                                    e(s());
                                    return
                                }
                                t.focus({
                                    preventScroll: !!o.preventScroll
                                }), i.mostRecentlyFocusedNode = t, t.tagName && "input" === t.tagName.toLowerCase() && "function" == typeof t.select && t.select()
                            }
                        },
                        p = function(e) {
                            var t = c("setReturnFocus", e);
                            return t || !1 !== t && e
                        },
                        m = function(e) {
                            var t = N(e);
                            if (!u(t)) {
                                if (P(o.clickOutsideDeactivates, e)) {
                                    n.deactivate({
                                        returnFocus: o.returnFocusOnDeactivate && !w(t)
                                    });
                                    return
                                }
                                P(o.allowOutsideClick, e) || e.preventDefault()
                            }
                        },
                        v = function(e) {
                            var t = N(e),
                                n = u(t);
                            n || t instanceof Document ? n && (i.mostRecentlyFocusedNode = t) : (e.stopImmediatePropagation(), d(i.mostRecentlyFocusedNode || s()))
                        },
                        b = function(e) {
                            var t = N(e);
                            f();
                            var n = null;
                            if (i.tabbableGroups.length > 0) {
                                var r = O(i.tabbableGroups, function(e) {
                                        return e.container.contains(t)
                                    }),
                                    o = r >= 0 ? i.tabbableGroups[r] : void 0;
                                if (r < 0) n = e.shiftKey ? i.tabbableGroups[i.tabbableGroups.length - 1].lastTabbableNode : i.tabbableGroups[0].firstTabbableNode;
                                else if (e.shiftKey) {
                                    var a = O(i.tabbableGroups, function(e) {
                                        return t === e.firstTabbableNode
                                    });
                                    if (a < 0 && (o.container === t || w(t) && !y(t) && !o.nextTabbableNode(t, !1)) && (a = r), a >= 0) {
                                        var l = 0 === a ? i.tabbableGroups.length - 1 : a - 1;
                                        n = i.tabbableGroups[l].lastTabbableNode
                                    }
                                } else {
                                    var u = O(i.tabbableGroups, function(e) {
                                        return t === e.lastTabbableNode
                                    });
                                    if (u < 0 && (o.container === t || w(t) && !y(t) && !o.nextTabbableNode(t)) && (u = r), u >= 0) {
                                        var s = u === i.tabbableGroups.length - 1 ? 0 : u + 1;
                                        n = i.tabbableGroups[s].firstTabbableNode
                                    }
                                }
                            } else n = c("fallbackFocus");
                            n && (e.preventDefault(), d(n))
                        },
                        R = function(e) {
                            if (("Escape" === e.key || "Esc" === e.key || 27 === e.keyCode) && !1 !== P(o.escapeDeactivates, e)) {
                                e.preventDefault(), n.deactivate();
                                return
                            }
                            if ("Tab" === e.key || 9 === e.keyCode) {
                                b(e);
                                return
                            }
                        },
                        T = function(e) {
                            P(o.clickOutsideDeactivates, e) || u(N(e)) || P(o.allowOutsideClick, e) || (e.preventDefault(), e.stopImmediatePropagation())
                        },
                        S = function() {
                            if (i.active) return x.activateTrap(n), i.delayInitialFocusTimer = o.delayInitialFocus ? C(function() {
                                d(s())
                            }) : d(s()), r.addEventListener("focusin", v, !0), r.addEventListener("mousedown", m, {
                                capture: !0,
                                passive: !1
                            }), r.addEventListener("touchstart", m, {
                                capture: !0,
                                passive: !1
                            }), r.addEventListener("click", T, {
                                capture: !0,
                                passive: !1
                            }), r.addEventListener("keydown", R, {
                                capture: !0,
                                passive: !1
                            }), n
                        },
                        k = function() {
                            if (i.active) return r.removeEventListener("focusin", v, !0), r.removeEventListener("mousedown", m, !0), r.removeEventListener("touchstart", m, !0), r.removeEventListener("click", T, !0), r.removeEventListener("keydown", R, !0), n
                        };
                    return (n = {
                        activate: function(e) {
                            if (i.active) return this;
                            var t = a(e, "onActivate"),
                                n = a(e, "onPostActivate"),
                                o = a(e, "checkCanFocusTrap");
                            o || f(), i.active = !0, i.paused = !1, i.nodeFocusedBeforeActivation = r.activeElement, t && t();
                            var l = function() {
                                o && f(), S(), n && n()
                            };
                            return o ? (o(i.containers.concat()).then(l, l), this) : (l(), this)
                        },
                        deactivate: function(e) {
                            if (!i.active) return this;
                            clearTimeout(i.delayInitialFocusTimer), i.delayInitialFocusTimer = void 0, k(), i.active = !1, i.paused = !1, x.deactivateTrap(n);
                            var t = a(e, "onDeactivate"),
                                r = a(e, "onPostDeactivate"),
                                o = a(e, "checkCanReturnFocus");
                            t && t();
                            var l = a(e, "returnFocus", "returnFocusOnDeactivate"),
                                u = function() {
                                    C(function() {
                                        l && d(p(i.nodeFocusedBeforeActivation)), r && r()
                                    })
                                };
                            return l && o ? (o(p(i.nodeFocusedBeforeActivation)).then(u, u), this) : (u(), this)
                        },
                        pause: function() {
                            return i.paused || !i.active || (i.paused = !0, k()), this
                        },
                        unpause: function() {
                            return i.paused && i.active && (i.paused = !1, f(), S()), this
                        },
                        updateContainerElements: function(e) {
                            var t = [].concat(e).filter(Boolean);
                            return i.containers = t.map(function(e) {
                                return "string" == typeof e ? r.querySelector(e) : e
                            }), i.active && f(), this
                        }
                    }).updateContainerElements(e), n
                }
        },
        93740: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = n(72253),
                o = n(14932),
                i = n(47702),
                a = n(24043),
                l = n(248);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return E
                }
            });
            var u = n(38754),
                c = n(61757)._(n(67294)),
                s = u._(n(42636)),
                f = n(97757),
                d = n(3735),
                p = n(83341);
            n(34210);
            var m = u._(n(57746)),
                h = {
                    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                    path: "/_next/image",
                    loader: "default",
                    dangerouslyAllowSVG: !1,
                    unoptimized: !1
                };

            function v(e) {
                return void 0 !== e.default
            }

            function g(e) {
                return void 0 === e ? e : "number" == typeof e ? Number.isFinite(e) ? e : NaN : "string" == typeof e && /^[0-9]+$/.test(e) ? parseInt(e, 10) : NaN
            }

            function y(e, t, n, i, a, l, u) {
                e && e["data-loaded-src"] !== t && (e["data-loaded-src"] = t, ("decode" in e ? e.decode() : Promise.resolve()).catch(function() {}).then(function() {
                    if (e.parentElement && e.isConnected) {
                        if ("blur" === n && l(!0), null == i ? void 0 : i.current) {
                            var t = new Event("load");
                            Object.defineProperty(t, "target", {
                                writable: !1,
                                value: e
                            });
                            var u = !1,
                                c = !1;
                            i.current(o._(r._({}, t), {
                                nativeEvent: t,
                                currentTarget: e,
                                target: e,
                                isDefaultPrevented: function() {
                                    return u
                                },
                                isPropagationStopped: function() {
                                    return c
                                },
                                persist: function() {},
                                preventDefault: function() {
                                    u = !0, t.preventDefault()
                                },
                                stopPropagation: function() {
                                    c = !0, t.stopPropagation()
                                }
                            }))
                        }(null == a ? void 0 : a.current) && a.current(e)
                    }
                }))
            }

            function b(e) {
                var t = a._(c.version.split("."), 2),
                    n = t[0],
                    r = t[1],
                    o = parseInt(n, 10),
                    i = parseInt(r, 10);
                return o > 18 || 18 === o && i >= 3 ? {
                    fetchPriority: e
                } : {
                    fetchpriority: e
                }
            }
            var w = (0, c.forwardRef)(function(e, t) {
                    var n = e.imgAttributes,
                        a = e.heightInt,
                        l = e.widthInt,
                        u = (e.qualityInt, e.className),
                        s = e.imgStyle,
                        f = e.blurStyle,
                        d = e.isLazy,
                        p = e.fetchPriority,
                        m = e.fill,
                        h = e.placeholder,
                        v = e.loading,
                        g = e.srcString,
                        w = (e.config, e.unoptimized),
                        E = (e.loader, e.onLoadRef),
                        x = e.onLoadingCompleteRef,
                        C = e.setBlurComplete,
                        O = e.setShowAltText,
                        P = (e.onLoad, e.onError),
                        N = i._(e, ["imgAttributes", "heightInt", "widthInt", "qualityInt", "className", "imgStyle", "blurStyle", "isLazy", "fetchPriority", "fill", "placeholder", "loading", "srcString", "config", "unoptimized", "loader", "onLoadRef", "onLoadingCompleteRef", "setBlurComplete", "setShowAltText", "onLoad", "onError"]);
                    return v = d ? "lazy" : v, c.default.createElement("img", o._(r._(o._(r._({}, N, b(p)), {
                        loading: v,
                        width: l,
                        height: a,
                        decoding: "async",
                        "data-nimg": m ? "fill" : "1",
                        className: u,
                        style: r._({}, s, f)
                    }), n), {
                        ref: (0, c.useCallback)(function(e) {
                            t && ("function" == typeof t ? t(e) : "object" == typeof t && (t.current = e)), e && (P && (e.src = e.src), e.complete && y(e, g, h, E, x, C, w))
                        }, [g, h, E, x, C, P, w, t]),
                        onLoad: function(e) {
                            y(e.currentTarget, g, h, E, x, C, w)
                        },
                        onError: function(e) {
                            O(!0), "blur" === h && C(!0), P && P(e)
                        }
                    }))
                }),
                E = (0, c.forwardRef)(function(e, t) {
                    var n, u, y, E = e.src,
                        x = e.sizes,
                        C = e.unoptimized,
                        O = void 0 !== C && C,
                        P = e.priority,
                        N = void 0 !== P && P,
                        R = e.loading,
                        T = e.className,
                        S = e.quality,
                        k = e.width,
                        _ = e.height,
                        A = e.fill,
                        F = e.style,
                        D = e.onLoad,
                        z = e.onLoadingComplete,
                        L = e.placeholder,
                        I = void 0 === L ? "empty" : L,
                        j = e.blurDataURL,
                        M = e.fetchPriority,
                        B = e.layout,
                        V = e.objectFit,
                        H = e.objectPosition,
                        W = (e.lazyBoundary, e.lazyRoot, i._(e, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "fill", "style", "onLoad", "onLoadingComplete", "placeholder", "blurDataURL", "fetchPriority", "layout", "objectFit", "objectPosition", "lazyBoundary", "lazyRoot"])),
                        Z = (0, c.useContext)(p.ImageConfigContext),
                        $ = (0, c.useMemo)(function() {
                            var e = h || Z || d.imageConfigDefault,
                                t = l._(e.deviceSizes).concat(l._(e.imageSizes)).sort(function(e, t) {
                                    return e - t
                                }),
                                n = e.deviceSizes.sort(function(e, t) {
                                    return e - t
                                });
                            return o._(r._({}, e), {
                                allSizes: t,
                                deviceSizes: n
                            })
                        }, [Z]),
                        q = W,
                        G = q.loader || m.default;
                    delete q.loader;
                    var U = "__next_img_default" in G;
                    if (U) {
                        if ("custom" === $.loader) throw Error('Image with src "' + E + '" is missing "loader" prop.\nRead more: https://nextjs.org/docs/messages/next-image-missing-loader')
                    } else {
                        var Y = G;
                        G = function(e) {
                            return e.config, Y(i._(e, ["config"]))
                        }
                    }
                    if (B) {
                        "fill" === B && (A = !0);
                        var X = {
                            intrinsic: {
                                maxWidth: "100%",
                                height: "auto"
                            },
                            responsive: {
                                width: "100%",
                                height: "auto"
                            }
                        }[B];
                        X && (F = r._({}, F, X));
                        var K = {
                            responsive: "100vw",
                            fill: "100vw"
                        }[B];
                        K && !x && (x = K)
                    }
                    var J = "",
                        Q = g(k),
                        ee = g(_);
                    if ("object" == typeof(n = E) && (v(n) || void 0 !== n.src)) {
                        var et = v(E) ? E.default : E;
                        if (!et.src) throw Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received " + JSON.stringify(et));
                        if (!et.height || !et.width) throw Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received " + JSON.stringify(et));
                        if (u = et.blurWidth, y = et.blurHeight, j = j || et.blurDataURL, J = et.src, !A) {
                            if (Q || ee) {
                                if (Q && !ee) {
                                    var en = Q / et.width;
                                    ee = Math.round(et.height * en)
                                } else if (!Q && ee) {
                                    var er = ee / et.height;
                                    Q = Math.round(et.width * er)
                                }
                            } else Q = et.width, ee = et.height
                        }
                    }
                    var eo = !N && ("lazy" === R || void 0 === R);
                    (!(E = "string" == typeof E ? E : J) || E.startsWith("data:") || E.startsWith("blob:")) && (O = !0, eo = !1), $.unoptimized && (O = !0), U && E.endsWith(".svg") && !$.dangerouslyAllowSVG && (O = !0), N && (M = "high");
                    var ei = a._((0, c.useState)(!1), 2),
                        ea = ei[0],
                        el = ei[1],
                        eu = a._((0, c.useState)(!1), 2),
                        ec = eu[0],
                        es = eu[1],
                        ef = g(S),
                        ed = Object.assign(A ? {
                            position: "absolute",
                            height: "100%",
                            width: "100%",
                            left: 0,
                            top: 0,
                            right: 0,
                            bottom: 0,
                            objectFit: V,
                            objectPosition: H
                        } : {}, ec ? {} : {
                            color: "transparent"
                        }, F),
                        ep = "blur" === I && j && !ea ? {
                            backgroundSize: ed.objectFit || "cover",
                            backgroundPosition: ed.objectPosition || "50% 50%",
                            backgroundRepeat: "no-repeat",
                            backgroundImage: 'url("data:image/svg+xml;charset=utf-8,' + (0, f.getImageBlurSvg)({
                                widthInt: Q,
                                heightInt: ee,
                                blurWidth: u,
                                blurHeight: y,
                                blurDataURL: j,
                                objectFit: ed.objectFit
                            }) + '")'
                        } : {},
                        em = function(e) {
                            var t = e.config,
                                n = e.src,
                                r = e.unoptimized,
                                o = e.width,
                                i = e.quality,
                                a = e.sizes,
                                u = e.loader;
                            if (r) return {
                                src: n,
                                srcSet: void 0,
                                sizes: void 0
                            };
                            var c = function(e, t, n) {
                                    var r = e.deviceSizes,
                                        o = e.allSizes;
                                    if (n) {
                                        for (var i = /(^|\s)(1?\d?\d)vw/g, a = []; u = i.exec(n); u) a.push(parseInt(u[2]));
                                        if (a.length) {
                                            var u, c, s = .01 * (c = Math).min.apply(c, l._(a));
                                            return {
                                                widths: o.filter(function(e) {
                                                    return e >= r[0] * s
                                                }),
                                                kind: "w"
                                            }
                                        }
                                        return {
                                            widths: o,
                                            kind: "w"
                                        }
                                    }
                                    return "number" != typeof t ? {
                                        widths: r,
                                        kind: "w"
                                    } : {
                                        widths: l._(new Set([t, 2 * t].map(function(e) {
                                            return o.find(function(t) {
                                                return t >= e
                                            }) || o[o.length - 1]
                                        }))),
                                        kind: "x"
                                    }
                                }(t, o, a),
                                s = c.widths,
                                f = c.kind,
                                d = s.length - 1;
                            return {
                                sizes: a || "w" !== f ? a : "100vw",
                                srcSet: s.map(function(e, r) {
                                    return u({
                                        config: t,
                                        src: n,
                                        quality: i,
                                        width: e
                                    }) + " " + ("w" === f ? e : r + 1) + f
                                }).join(", "),
                                src: u({
                                    config: t,
                                    src: n,
                                    quality: i,
                                    width: s[d]
                                })
                            }
                        }({
                            config: $,
                            src: E,
                            unoptimized: O,
                            width: Q,
                            quality: ef,
                            sizes: x,
                            loader: G
                        }),
                        eh = E,
                        ev = (0, c.useRef)(D);
                    (0, c.useEffect)(function() {
                        ev.current = D
                    }, [D]);
                    var eg = (0, c.useRef)(z);
                    (0, c.useEffect)(function() {
                        eg.current = z
                    }, [z]);
                    var ey = r._({
                        isLazy: eo,
                        imgAttributes: em,
                        heightInt: ee,
                        widthInt: Q,
                        qualityInt: ef,
                        className: T,
                        imgStyle: ed,
                        blurStyle: ep,
                        loading: R,
                        config: $,
                        fetchPriority: M,
                        fill: A,
                        unoptimized: O,
                        placeholder: I,
                        loader: G,
                        srcString: eh,
                        onLoadRef: ev,
                        onLoadingCompleteRef: eg,
                        setBlurComplete: el,
                        setShowAltText: es
                    }, q);
                    return c.default.createElement(c.default.Fragment, null, c.default.createElement(w, o._(r._({}, ey), {
                        ref: t
                    })), N ? c.default.createElement(s.default, null, c.default.createElement("link", r._({
                        key: "__nimg-" + em.src + em.srcSet + em.sizes,
                        rel: "preload",
                        as: "image",
                        href: em.srcSet ? void 0 : em.src,
                        imageSrcSet: em.srcSet,
                        imageSizes: em.sizes,
                        crossOrigin: q.crossOrigin,
                        referrerPolicy: q.referrerPolicy
                    }, b(M)))) : null)
                });
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        97757: function(e, t) {
            "use strict";

            function n(e) {
                var t = e.widthInt,
                    n = e.heightInt,
                    r = e.blurWidth,
                    o = e.blurHeight,
                    i = e.blurDataURL,
                    a = e.objectFit,
                    l = r || t,
                    u = o || n,
                    c = i.startsWith("data:image/jpeg") ? "%3CfeComponentTransfer%3E%3CfeFuncA type='discrete' tableValues='1 1'/%3E%3C/feComponentTransfer%3E%" : "";
                return l && u ? "%3Csvg xmlns='http%3A//www.w3.org/2000/svg' viewBox='0 0 " + l + " " + u + "'%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='" + (r && o ? "1" : "20") + "'/%3E" + c + "%3C/filter%3E%3Cimage preserveAspectRatio='none' filter='url(%23b)' x='0' y='0' height='100%25' width='100%25' href='" + i + "'/%3E%3C/svg%3E" : "%3Csvg xmlns='http%3A//www.w3.org/2000/svg'%3E%3Cimage style='filter:blur(20px)' preserveAspectRatio='" + ("contain" === a ? "xMidYMid" : "cover" === a ? "xMidYMid slice" : "none") + "' x='0' y='0' height='100%25' width='100%25' href='" + i + "'/%3E%3C/svg%3E"
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "getImageBlurSvg", {
                enumerable: !0,
                get: function() {
                    return n
                }
            })
        },
        57746: function(e, t) {
            "use strict";

            function n(e) {
                var t = e.config,
                    n = e.src,
                    r = e.width,
                    o = e.quality;
                return t.path + "?url=" + encodeURIComponent(n) + "&w=" + r + "&q=" + (o || 75)
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return r
                }
            }), n.__next_img_default = !0;
            var r = n
        },
        25675: function(e, t, n) {
            e.exports = n(93740)
        },
        85983: function(e, t, n) {
            "use strict";
            n.d(t, {
                Cp: function() {
                    return f
                },
                RR: function() {
                    return u
                },
                cv: function() {
                    return p
                },
                dp: function() {
                    return v
                },
                dr: function() {
                    return h
                },
                oo: function() {
                    return i
                },
                uY: function() {
                    return m
                },
                x7: function() {
                    return l
                }
            });
            var r = n(71347);

            function o(e, t, n) {
                let o, {
                        reference: i,
                        floating: a
                    } = e,
                    l = (0, r.Qq)(t),
                    u = (0, r.Wh)(t),
                    c = (0, r.I4)(u),
                    s = (0, r.k3)(t),
                    f = "y" === l,
                    d = i.x + i.width / 2 - a.width / 2,
                    p = i.y + i.height / 2 - a.height / 2,
                    m = i[c] / 2 - a[c] / 2;
                switch (s) {
                    case "top":
                        o = {
                            x: d,
                            y: i.y - a.height
                        };
                        break;
                    case "bottom":
                        o = {
                            x: d,
                            y: i.y + i.height
                        };
                        break;
                    case "right":
                        o = {
                            x: i.x + i.width,
                            y: p
                        };
                        break;
                    case "left":
                        o = {
                            x: i.x - a.width,
                            y: p
                        };
                        break;
                    default:
                        o = {
                            x: i.x,
                            y: i.y
                        }
                }
                switch ((0, r.hp)(t)) {
                    case "start":
                        o[u] -= m * (n && f ? -1 : 1);
                        break;
                    case "end":
                        o[u] += m * (n && f ? -1 : 1)
                }
                return o
            }
            let i = async (e, t, n) => {
                let {
                    placement: r = "bottom",
                    strategy: i = "absolute",
                    middleware: a = [],
                    platform: l
                } = n, u = a.filter(Boolean), c = await (null == l.isRTL ? void 0 : l.isRTL(t)), s = await l.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: i
                }), {
                    x: f,
                    y: d
                } = o(s, r, c), p = r, m = {}, h = 0;
                for (let n = 0; n < u.length; n++) {
                    let {
                        name: a,
                        fn: v
                    } = u[n], {
                        x: g,
                        y: y,
                        data: b,
                        reset: w
                    } = await v({
                        x: f,
                        y: d,
                        initialPlacement: r,
                        placement: p,
                        strategy: i,
                        middlewareData: m,
                        rects: s,
                        platform: l,
                        elements: {
                            reference: e,
                            floating: t
                        }
                    });
                    if (f = null != g ? g : f, d = null != y ? y : d, m = { ...m,
                            [a]: { ...m[a],
                                ...b
                            }
                        }, w && h <= 50) {
                        h++, "object" == typeof w && (w.placement && (p = w.placement), w.rects && (s = !0 === w.rects ? await l.getElementRects({
                            reference: e,
                            floating: t,
                            strategy: i
                        }) : w.rects), {
                            x: f,
                            y: d
                        } = o(s, p, c)), n = -1;
                        continue
                    }
                }
                return {
                    x: f,
                    y: d,
                    placement: p,
                    strategy: i,
                    middlewareData: m
                }
            };
            async function a(e, t) {
                var n;
                void 0 === t && (t = {});
                let {
                    x: o,
                    y: i,
                    platform: a,
                    rects: l,
                    elements: u,
                    strategy: c
                } = e, {
                    boundary: s = "clippingAncestors",
                    rootBoundary: f = "viewport",
                    elementContext: d = "floating",
                    altBoundary: p = !1,
                    padding: m = 0
                } = (0, r.ku)(t, e), h = (0, r.yd)(m), v = u[p ? "floating" === d ? "reference" : "floating" : d], g = (0, r.JB)(await a.getClippingRect({
                    element: null == (n = await (null == a.isElement ? void 0 : a.isElement(v))) || n ? v : v.contextElement || await (null == a.getDocumentElement ? void 0 : a.getDocumentElement(u.floating)),
                    boundary: s,
                    rootBoundary: f,
                    strategy: c
                })), y = "floating" === d ? { ...l.floating,
                    x: o,
                    y: i
                } : l.reference, b = await (null == a.getOffsetParent ? void 0 : a.getOffsetParent(u.floating)), w = await (null == a.isElement ? void 0 : a.isElement(b)) && await (null == a.getScale ? void 0 : a.getScale(b)) || {
                    x: 1,
                    y: 1
                }, E = (0, r.JB)(a.convertOffsetParentRelativeRectToViewportRelativeRect ? await a.convertOffsetParentRelativeRectToViewportRelativeRect({
                    rect: y,
                    offsetParent: b,
                    strategy: c
                }) : y);
                return {
                    top: (g.top - E.top + h.top) / w.y,
                    bottom: (E.bottom - g.bottom + h.bottom) / w.y,
                    left: (g.left - E.left + h.left) / w.x,
                    right: (E.right - g.right + h.right) / w.x
                }
            }
            let l = e => ({
                    name: "arrow",
                    options: e,
                    async fn(t) {
                        let {
                            x: n,
                            y: o,
                            placement: i,
                            rects: a,
                            platform: l,
                            elements: u
                        } = t, {
                            element: c,
                            padding: s = 0
                        } = (0, r.ku)(e, t) || {};
                        if (null == c) return {};
                        let f = (0, r.yd)(s),
                            d = {
                                x: n,
                                y: o
                            },
                            p = (0, r.Wh)(i),
                            m = (0, r.I4)(p),
                            h = await l.getDimensions(c),
                            v = "y" === p,
                            g = v ? "clientHeight" : "clientWidth",
                            y = a.reference[m] + a.reference[p] - d[p] - a.floating[m],
                            b = d[p] - a.reference[p],
                            w = await (null == l.getOffsetParent ? void 0 : l.getOffsetParent(c)),
                            E = w ? w[g] : 0;
                        E && await (null == l.isElement ? void 0 : l.isElement(w)) || (E = u.floating[g] || a.floating[m]);
                        let x = E / 2 - h[m] / 2 - 1,
                            C = (0, r.VV)(f[v ? "top" : "left"], x),
                            O = (0, r.VV)(f[v ? "bottom" : "right"], x),
                            P = E - h[m] - O,
                            N = E / 2 - h[m] / 2 + (y / 2 - b / 2),
                            R = (0, r.uZ)(C, N, P),
                            T = null != (0, r.hp)(i) && N != R && a.reference[m] / 2 - (N < C ? C : O) - h[m] / 2 < 0,
                            S = T ? N < C ? C - N : P - N : 0;
                        return {
                            [p]: d[p] - S,
                            data: {
                                [p]: R,
                                centerOffset: N - R + S
                            }
                        }
                    }
                }),
                u = function(e) {
                    return void 0 === e && (e = {}), {
                        name: "flip",
                        options: e,
                        async fn(t) {
                            var n, o, i, l;
                            let {
                                placement: u,
                                middlewareData: c,
                                rects: s,
                                initialPlacement: f,
                                platform: d,
                                elements: p
                            } = t, {
                                mainAxis: m = !0,
                                crossAxis: h = !0,
                                fallbackPlacements: v,
                                fallbackStrategy: g = "bestFit",
                                fallbackAxisSideDirection: y = "none",
                                flipAlignment: b = !0,
                                ...w
                            } = (0, r.ku)(e, t), E = (0, r.k3)(u), x = (0, r.k3)(f) === f, C = await (null == d.isRTL ? void 0 : d.isRTL(p.floating)), O = v || (x || !b ? [(0, r.pw)(f)] : (0, r.gy)(f));
                            v || "none" === y || O.push(...(0, r.KX)(f, b, y, C));
                            let P = [f, ...O],
                                N = await a(t, w),
                                R = [],
                                T = (null == (n = c.flip) ? void 0 : n.overflows) || [];
                            if (m && R.push(N[E]), h) {
                                let e = (0, r.i8)(u, s, C);
                                R.push(N[e[0]], N[e[1]])
                            }
                            if (T = [...T, {
                                    placement: u,
                                    overflows: R
                                }], !R.every(e => e <= 0)) {
                                let e = ((null == (o = c.flip) ? void 0 : o.index) || 0) + 1,
                                    t = P[e];
                                if (t) return {
                                    data: {
                                        index: e,
                                        overflows: T
                                    },
                                    reset: {
                                        placement: t
                                    }
                                };
                                let n = null == (i = T.filter(e => e.overflows[0] <= 0).sort((e, t) => e.overflows[1] - t.overflows[1])[0]) ? void 0 : i.placement;
                                if (!n) switch (g) {
                                    case "bestFit":
                                        {
                                            let e = null == (l = T.map(e => [e.placement, e.overflows.filter(e => e > 0).reduce((e, t) => e + t, 0)]).sort((e, t) => e[1] - t[1])[0]) ? void 0 : l[0];e && (n = e);
                                            break
                                        }
                                    case "initialPlacement":
                                        n = f
                                }
                                if (u !== n) return {
                                    reset: {
                                        placement: n
                                    }
                                }
                            }
                            return {}
                        }
                    }
                };

            function c(e, t) {
                return {
                    top: e.top - t.height,
                    right: e.right - t.width,
                    bottom: e.bottom - t.height,
                    left: e.left - t.width
                }
            }

            function s(e) {
                return r.mA.some(t => e[t] >= 0)
            }
            let f = function(e) {
                return void 0 === e && (e = {}), {
                    name: "hide",
                    options: e,
                    async fn(t) {
                        let {
                            rects: n
                        } = t, {
                            strategy: o = "referenceHidden",
                            ...i
                        } = (0, r.ku)(e, t);
                        switch (o) {
                            case "referenceHidden":
                                {
                                    let e = await a(t, { ...i,
                                            elementContext: "reference"
                                        }),
                                        r = c(e, n.reference);
                                    return {
                                        data: {
                                            referenceHiddenOffsets: r,
                                            referenceHidden: s(r)
                                        }
                                    }
                                }
                            case "escaped":
                                {
                                    let e = await a(t, { ...i,
                                            altBoundary: !0
                                        }),
                                        r = c(e, n.floating);
                                    return {
                                        data: {
                                            escapedOffsets: r,
                                            escaped: s(r)
                                        }
                                    }
                                }
                            default:
                                return {}
                        }
                    }
                }
            };
            async function d(e, t) {
                let {
                    placement: n,
                    platform: o,
                    elements: i
                } = e, a = await (null == o.isRTL ? void 0 : o.isRTL(i.floating)), l = (0, r.k3)(n), u = (0, r.hp)(n), c = "y" === (0, r.Qq)(n), s = ["left", "top"].includes(l) ? -1 : 1, f = a && c ? -1 : 1, d = (0, r.ku)(t, e), {
                    mainAxis: p,
                    crossAxis: m,
                    alignmentAxis: h
                } = "number" == typeof d ? {
                    mainAxis: d,
                    crossAxis: 0,
                    alignmentAxis: null
                } : {
                    mainAxis: 0,
                    crossAxis: 0,
                    alignmentAxis: null,
                    ...d
                };
                return u && "number" == typeof h && (m = "end" === u ? -1 * h : h), c ? {
                    x: m * f,
                    y: p * s
                } : {
                    x: p * s,
                    y: m * f
                }
            }
            let p = function(e) {
                    return void 0 === e && (e = 0), {
                        name: "offset",
                        options: e,
                        async fn(t) {
                            let {
                                x: n,
                                y: r
                            } = t, o = await d(t, e);
                            return {
                                x: n + o.x,
                                y: r + o.y,
                                data: o
                            }
                        }
                    }
                },
                m = function(e) {
                    return void 0 === e && (e = {}), {
                        name: "shift",
                        options: e,
                        async fn(t) {
                            let {
                                x: n,
                                y: o,
                                placement: i
                            } = t, {
                                mainAxis: l = !0,
                                crossAxis: u = !1,
                                limiter: c = {
                                    fn: e => {
                                        let {
                                            x: t,
                                            y: n
                                        } = e;
                                        return {
                                            x: t,
                                            y: n
                                        }
                                    }
                                },
                                ...s
                            } = (0, r.ku)(e, t), f = {
                                x: n,
                                y: o
                            }, d = await a(t, s), p = (0, r.Qq)((0, r.k3)(i)), m = (0, r.Rn)(p), h = f[m], v = f[p];
                            if (l) {
                                let e = h + d["y" === m ? "top" : "left"],
                                    t = h - d["y" === m ? "bottom" : "right"];
                                h = (0, r.uZ)(e, h, t)
                            }
                            if (u) {
                                let e = v + d["y" === p ? "top" : "left"],
                                    t = v - d["y" === p ? "bottom" : "right"];
                                v = (0, r.uZ)(e, v, t)
                            }
                            let g = c.fn({ ...t,
                                [m]: h,
                                [p]: v
                            });
                            return { ...g,
                                data: {
                                    x: g.x - n,
                                    y: g.y - o
                                }
                            }
                        }
                    }
                },
                h = function(e) {
                    return void 0 === e && (e = {}), {
                        options: e,
                        fn(t) {
                            let {
                                x: n,
                                y: o,
                                placement: i,
                                rects: a,
                                middlewareData: l
                            } = t, {
                                offset: u = 0,
                                mainAxis: c = !0,
                                crossAxis: s = !0
                            } = (0, r.ku)(e, t), f = {
                                x: n,
                                y: o
                            }, d = (0, r.Qq)(i), p = (0, r.Rn)(d), m = f[p], h = f[d], v = (0, r.ku)(u, t), g = "number" == typeof v ? {
                                mainAxis: v,
                                crossAxis: 0
                            } : {
                                mainAxis: 0,
                                crossAxis: 0,
                                ...v
                            };
                            if (c) {
                                let e = "y" === p ? "height" : "width",
                                    t = a.reference[p] - a.floating[e] + g.mainAxis,
                                    n = a.reference[p] + a.reference[e] - g.mainAxis;
                                m < t ? m = t : m > n && (m = n)
                            }
                            if (s) {
                                var y, b;
                                let e = "y" === p ? "width" : "height",
                                    t = ["top", "left"].includes((0, r.k3)(i)),
                                    n = a.reference[d] - a.floating[e] + (t && (null == (y = l.offset) ? void 0 : y[d]) || 0) + (t ? 0 : g.crossAxis),
                                    o = a.reference[d] + a.reference[e] + (t ? 0 : (null == (b = l.offset) ? void 0 : b[d]) || 0) - (t ? g.crossAxis : 0);
                                h < n ? h = n : h > o && (h = o)
                            }
                            return {
                                [p]: m,
                                [d]: h
                            }
                        }
                    }
                },
                v = function(e) {
                    return void 0 === e && (e = {}), {
                        name: "size",
                        options: e,
                        async fn(t) {
                            let n, o;
                            let {
                                placement: i,
                                rects: l,
                                platform: u,
                                elements: c
                            } = t, {
                                apply: s = () => {},
                                ...f
                            } = (0, r.ku)(e, t), d = await a(t, f), p = (0, r.k3)(i), m = (0, r.hp)(i), h = "y" === (0, r.Qq)(i), {
                                width: v,
                                height: g
                            } = l.floating;
                            "top" === p || "bottom" === p ? (n = p, o = m === (await (null == u.isRTL ? void 0 : u.isRTL(c.floating)) ? "start" : "end") ? "left" : "right") : (o = p, n = "end" === m ? "top" : "bottom");
                            let y = g - d[n],
                                b = v - d[o],
                                w = !t.middlewareData.shift,
                                E = y,
                                x = b;
                            if (h) {
                                let e = v - d.left - d.right;
                                x = m || w ? (0, r.VV)(b, e) : e
                            } else {
                                let e = g - d.top - d.bottom;
                                E = m || w ? (0, r.VV)(y, e) : e
                            }
                            if (w && !m) {
                                let e = (0, r.Fp)(d.left, 0),
                                    t = (0, r.Fp)(d.right, 0),
                                    n = (0, r.Fp)(d.top, 0),
                                    o = (0, r.Fp)(d.bottom, 0);
                                h ? x = v - 2 * (0 !== e || 0 !== t ? e + t : (0, r.Fp)(d.left, d.right)) : E = g - 2 * (0 !== n || 0 !== o ? n + o : (0, r.Fp)(d.top, d.bottom))
                            }
                            await s({ ...t,
                                availableWidth: x,
                                availableHeight: E
                            });
                            let C = await u.getDimensions(c.floating);
                            return v !== C.width || g !== C.height ? {
                                reset: {
                                    rects: !0
                                }
                            } : {}
                        }
                    }
                }
        },
        63853: function(e, t, n) {
            "use strict";
            n.d(t, {
                Me: function() {
                    return A
                },
                oo: function() {
                    return F
                }
            });
            var r = n(71347),
                o = n(85983);

            function i(e) {
                return u(e) ? (e.nodeName || "").toLowerCase() : "#document"
            }

            function a(e) {
                var t;
                return (null == e ? void 0 : null == (t = e.ownerDocument) ? void 0 : t.defaultView) || window
            }

            function l(e) {
                var t;
                return null == (t = (u(e) ? e.ownerDocument : e.document) || window.document) ? void 0 : t.documentElement
            }

            function u(e) {
                return e instanceof Node || e instanceof a(e).Node
            }

            function c(e) {
                return e instanceof Element || e instanceof a(e).Element
            }

            function s(e) {
                return e instanceof HTMLElement || e instanceof a(e).HTMLElement
            }

            function f(e) {
                return "undefined" != typeof ShadowRoot && (e instanceof ShadowRoot || e instanceof a(e).ShadowRoot)
            }

            function d(e) {
                let {
                    overflow: t,
                    overflowX: n,
                    overflowY: r,
                    display: o
                } = v(e);
                return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && !["inline", "contents"].includes(o)
            }

            function p(e) {
                let t = m(),
                    n = v(e);
                return "none" !== n.transform || "none" !== n.perspective || !!n.containerType && "normal" !== n.containerType || !t && !!n.backdropFilter && "none" !== n.backdropFilter || !t && !!n.filter && "none" !== n.filter || ["transform", "perspective", "filter"].some(e => (n.willChange || "").includes(e)) || ["paint", "layout", "strict", "content"].some(e => (n.contain || "").includes(e))
            }

            function m() {
                return "undefined" != typeof CSS && !!CSS.supports && CSS.supports("-webkit-backdrop-filter", "none")
            }

            function h(e) {
                return ["html", "body", "#document"].includes(i(e))
            }

            function v(e) {
                return a(e).getComputedStyle(e)
            }

            function g(e) {
                return c(e) ? {
                    scrollLeft: e.scrollLeft,
                    scrollTop: e.scrollTop
                } : {
                    scrollLeft: e.pageXOffset,
                    scrollTop: e.pageYOffset
                }
            }

            function y(e) {
                if ("html" === i(e)) return e;
                let t = e.assignedSlot || e.parentNode || f(e) && e.host || l(e);
                return f(t) ? t.host : t
            }

            function b(e, t) {
                var n;
                void 0 === t && (t = []);
                let r = function e(t) {
                        let n = y(t);
                        return h(n) ? t.ownerDocument ? t.ownerDocument.body : t.body : s(n) && d(n) ? n : e(n)
                    }(e),
                    o = r === (null == (n = e.ownerDocument) ? void 0 : n.body),
                    i = a(r);
                return o ? t.concat(i, i.visualViewport || [], d(r) ? r : []) : t.concat(r, b(r))
            }

            function w(e) {
                let t = v(e),
                    n = parseFloat(t.width) || 0,
                    o = parseFloat(t.height) || 0,
                    i = s(e),
                    a = i ? e.offsetWidth : n,
                    l = i ? e.offsetHeight : o,
                    u = (0, r.NM)(n) !== a || (0, r.NM)(o) !== l;
                return u && (n = a, o = l), {
                    width: n,
                    height: o,
                    $: u
                }
            }

            function E(e) {
                return c(e) ? e : e.contextElement
            }

            function x(e) {
                let t = E(e);
                if (!s(t)) return (0, r.ze)(1);
                let n = t.getBoundingClientRect(),
                    {
                        width: o,
                        height: i,
                        $: a
                    } = w(t),
                    l = (a ? (0, r.NM)(n.width) : n.width) / o,
                    u = (a ? (0, r.NM)(n.height) : n.height) / i;
                return l && Number.isFinite(l) || (l = 1), u && Number.isFinite(u) || (u = 1), {
                    x: l,
                    y: u
                }
            }
            let C = (0, r.ze)(0);

            function O(e) {
                let t = a(e);
                return m() && t.visualViewport ? {
                    x: t.visualViewport.offsetLeft,
                    y: t.visualViewport.offsetTop
                } : C
            }

            function P(e, t, n, o) {
                var i;
                void 0 === t && (t = !1), void 0 === n && (n = !1);
                let l = e.getBoundingClientRect(),
                    u = E(e),
                    s = (0, r.ze)(1);
                t && (o ? c(o) && (s = x(o)) : s = x(e));
                let f = (void 0 === (i = n) && (i = !1), o && (!i || o === a(u)) && i) ? O(u) : (0, r.ze)(0),
                    d = (l.left + f.x) / s.x,
                    p = (l.top + f.y) / s.y,
                    m = l.width / s.x,
                    h = l.height / s.y;
                if (u) {
                    let e = a(u),
                        t = o && c(o) ? a(o) : o,
                        n = e.frameElement;
                    for (; n && o && t !== e;) {
                        let e = x(n),
                            t = n.getBoundingClientRect(),
                            r = v(n),
                            o = t.left + (n.clientLeft + parseFloat(r.paddingLeft)) * e.x,
                            i = t.top + (n.clientTop + parseFloat(r.paddingTop)) * e.y;
                        d *= e.x, p *= e.y, m *= e.x, h *= e.y, d += o, p += i, n = a(n).frameElement
                    }
                }
                return (0, r.JB)({
                    width: m,
                    height: h,
                    x: d,
                    y: p
                })
            }

            function N(e) {
                return P(l(e)).left + g(e).scrollLeft
            }

            function R(e, t, n) {
                let o;
                if ("viewport" === t) o = function(e, t) {
                    let n = a(e),
                        r = l(e),
                        o = n.visualViewport,
                        i = r.clientWidth,
                        u = r.clientHeight,
                        c = 0,
                        s = 0;
                    if (o) {
                        i = o.width, u = o.height;
                        let e = m();
                        (!e || e && "fixed" === t) && (c = o.offsetLeft, s = o.offsetTop)
                    }
                    return {
                        width: i,
                        height: u,
                        x: c,
                        y: s
                    }
                }(e, n);
                else if ("document" === t) o = function(e) {
                    let t = l(e),
                        n = g(e),
                        o = e.ownerDocument.body,
                        i = (0, r.Fp)(t.scrollWidth, t.clientWidth, o.scrollWidth, o.clientWidth),
                        a = (0, r.Fp)(t.scrollHeight, t.clientHeight, o.scrollHeight, o.clientHeight),
                        u = -n.scrollLeft + N(e),
                        c = -n.scrollTop;
                    return "rtl" === v(o).direction && (u += (0, r.Fp)(t.clientWidth, o.clientWidth) - i), {
                        width: i,
                        height: a,
                        x: u,
                        y: c
                    }
                }(l(e));
                else if (c(t)) o = function(e, t) {
                    let n = P(e, !0, "fixed" === t),
                        o = n.top + e.clientTop,
                        i = n.left + e.clientLeft,
                        a = s(e) ? x(e) : (0, r.ze)(1),
                        l = e.clientWidth * a.x,
                        u = e.clientHeight * a.y,
                        c = i * a.x,
                        f = o * a.y;
                    return {
                        width: l,
                        height: u,
                        x: c,
                        y: f
                    }
                }(t, n);
                else {
                    let n = O(e);
                    o = { ...t,
                        x: t.x - n.x,
                        y: t.y - n.y
                    }
                }
                return (0, r.JB)(o)
            }

            function T(e, t) {
                return s(e) && "fixed" !== v(e).position ? t ? t(e) : e.offsetParent : null
            }

            function S(e, t) {
                let n = a(e);
                if (!s(e)) return n;
                let r = T(e, t);
                for (; r && ["table", "td", "th"].includes(i(r)) && "static" === v(r).position;) r = T(r, t);
                return r && ("html" === i(r) || "body" === i(r) && "static" === v(r).position && !p(r)) ? n : r || function(e) {
                    let t = y(e);
                    for (; s(t) && !h(t);) {
                        if (p(t)) return t;
                        t = y(t)
                    }
                    return null
                }(e) || n
            }
            let k = async function(e) {
                    let {
                        reference: t,
                        floating: n,
                        strategy: o
                    } = e, a = this.getOffsetParent || S, u = this.getDimensions;
                    return {
                        reference: function(e, t, n) {
                            let o = s(t),
                                a = l(t),
                                u = "fixed" === n,
                                c = P(e, !0, u, t),
                                f = {
                                    scrollLeft: 0,
                                    scrollTop: 0
                                },
                                p = (0, r.ze)(0);
                            if (o || !o && !u) {
                                if (("body" !== i(t) || d(a)) && (f = g(t)), o) {
                                    let e = P(t, !0, u, t);
                                    p.x = e.x + t.clientLeft, p.y = e.y + t.clientTop
                                } else a && (p.x = N(a))
                            }
                            return {
                                x: c.left + f.scrollLeft - p.x,
                                y: c.top + f.scrollTop - p.y,
                                width: c.width,
                                height: c.height
                            }
                        }(t, await a(n), o),
                        floating: {
                            x: 0,
                            y: 0,
                            ...await u(n)
                        }
                    }
                },
                _ = {
                    convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
                        let {
                            rect: t,
                            offsetParent: n,
                            strategy: o
                        } = e, a = s(n), u = l(n);
                        if (n === u) return t;
                        let c = {
                                scrollLeft: 0,
                                scrollTop: 0
                            },
                            f = (0, r.ze)(1),
                            p = (0, r.ze)(0);
                        if ((a || !a && "fixed" !== o) && (("body" !== i(n) || d(u)) && (c = g(n)), s(n))) {
                            let e = P(n);
                            f = x(n), p.x = e.x + n.clientLeft, p.y = e.y + n.clientTop
                        }
                        return {
                            width: t.width * f.x,
                            height: t.height * f.y,
                            x: t.x * f.x - c.scrollLeft * f.x + p.x,
                            y: t.y * f.y - c.scrollTop * f.y + p.y
                        }
                    },
                    getDocumentElement: l,
                    getClippingRect: function(e) {
                        let {
                            element: t,
                            boundary: n,
                            rootBoundary: o,
                            strategy: a
                        } = e, l = "clippingAncestors" === n ? function(e, t) {
                            let n = t.get(e);
                            if (n) return n;
                            let r = b(e).filter(e => c(e) && "body" !== i(e)),
                                o = null,
                                a = "fixed" === v(e).position,
                                l = a ? y(e) : e;
                            for (; c(l) && !h(l);) {
                                let t = v(l),
                                    n = p(l);
                                n || "fixed" !== t.position || (o = null);
                                let i = a ? !n && !o : !n && "static" === t.position && !!o && ["absolute", "fixed"].includes(o.position) || d(l) && !n && function e(t, n) {
                                    let r = y(t);
                                    return !(r === n || !c(r) || h(r)) && ("fixed" === v(r).position || e(r, n))
                                }(e, l);
                                i ? r = r.filter(e => e !== l) : o = t, l = y(l)
                            }
                            return t.set(e, r), r
                        }(t, this._c) : [].concat(n), u = [...l, o], s = u[0], f = u.reduce((e, n) => {
                            let o = R(t, n, a);
                            return e.top = (0, r.Fp)(o.top, e.top), e.right = (0, r.VV)(o.right, e.right), e.bottom = (0, r.VV)(o.bottom, e.bottom), e.left = (0, r.Fp)(o.left, e.left), e
                        }, R(t, s, a));
                        return {
                            width: f.right - f.left,
                            height: f.bottom - f.top,
                            x: f.left,
                            y: f.top
                        }
                    },
                    getOffsetParent: S,
                    getElementRects: k,
                    getClientRects: function(e) {
                        return Array.from(e.getClientRects())
                    },
                    getDimensions: function(e) {
                        return w(e)
                    },
                    getScale: x,
                    isElement: c,
                    isRTL: function(e) {
                        return "rtl" === v(e).direction
                    }
                };

            function A(e, t, n, o) {
                let i;
                void 0 === o && (o = {});
                let {
                    ancestorScroll: a = !0,
                    ancestorResize: u = !0,
                    elementResize: c = "function" == typeof ResizeObserver,
                    layoutShift: s = "function" == typeof IntersectionObserver,
                    animationFrame: f = !1
                } = o, d = E(e), p = a || u ? [...d ? b(d) : [], ...b(t)] : [];
                p.forEach(e => {
                    a && e.addEventListener("scroll", n, {
                        passive: !0
                    }), u && e.addEventListener("resize", n)
                });
                let m = d && s ? function(e, t) {
                        let n, o = null,
                            i = l(e);

                        function a() {
                            clearTimeout(n), o && o.disconnect(), o = null
                        }
                        return function l(u, c) {
                            void 0 === u && (u = !1), void 0 === c && (c = 1), a();
                            let {
                                left: s,
                                top: f,
                                width: d,
                                height: p
                            } = e.getBoundingClientRect();
                            if (u || t(), !d || !p) return;
                            let m = (0, r.GW)(f),
                                h = (0, r.GW)(i.clientWidth - (s + d)),
                                v = (0, r.GW)(i.clientHeight - (f + p)),
                                g = (0, r.GW)(s),
                                y = {
                                    rootMargin: -m + "px " + -h + "px " + -v + "px " + -g + "px",
                                    threshold: (0, r.Fp)(0, (0, r.VV)(1, c)) || 1
                                },
                                b = !0;

                            function w(e) {
                                let t = e[0].intersectionRatio;
                                if (t !== c) {
                                    if (!b) return l();
                                    t ? l(!1, t) : n = setTimeout(() => {
                                        l(!1, 1e-7)
                                    }, 100)
                                }
                                b = !1
                            }
                            try {
                                o = new IntersectionObserver(w, { ...y,
                                    root: i.ownerDocument
                                })
                            } catch (e) {
                                o = new IntersectionObserver(w, y)
                            }
                            o.observe(e)
                        }(!0), a
                    }(d, n) : null,
                    h = -1,
                    v = null;
                c && (v = new ResizeObserver(e => {
                    let [r] = e;
                    r && r.target === d && v && (v.unobserve(t), cancelAnimationFrame(h), h = requestAnimationFrame(() => {
                        v && v.observe(t)
                    })), n()
                }), d && !f && v.observe(d), v.observe(t));
                let g = f ? P(e) : null;
                return f && function t() {
                    let r = P(e);
                    g && (r.x !== g.x || r.y !== g.y || r.width !== g.width || r.height !== g.height) && n(), g = r, i = requestAnimationFrame(t)
                }(), n(), () => {
                    p.forEach(e => {
                        a && e.removeEventListener("scroll", n), u && e.removeEventListener("resize", n)
                    }), m && m(), v && v.disconnect(), v = null, f && cancelAnimationFrame(i)
                }
            }
            let F = (e, t, n) => {
                let r = new Map,
                    i = {
                        platform: _,
                        ...n
                    },
                    a = { ...i.platform,
                        _c: r
                    };
                return (0, o.oo)(e, t, { ...i,
                    platform: a
                })
            }
        },
        71347: function(e, t, n) {
            "use strict";
            n.d(t, {
                Fp: function() {
                    return i
                },
                GW: function() {
                    return l
                },
                I4: function() {
                    return v
                },
                JB: function() {
                    return P
                },
                KX: function() {
                    return x
                },
                NM: function() {
                    return a
                },
                Qq: function() {
                    return g
                },
                Rn: function() {
                    return h
                },
                VV: function() {
                    return o
                },
                Wh: function() {
                    return y
                },
                gy: function() {
                    return w
                },
                hp: function() {
                    return m
                },
                i8: function() {
                    return b
                },
                k3: function() {
                    return p
                },
                ku: function() {
                    return d
                },
                mA: function() {
                    return r
                },
                pw: function() {
                    return C
                },
                uZ: function() {
                    return f
                },
                yd: function() {
                    return O
                },
                ze: function() {
                    return u
                }
            });
            let r = ["top", "right", "bottom", "left"],
                o = Math.min,
                i = Math.max,
                a = Math.round,
                l = Math.floor,
                u = e => ({
                    x: e,
                    y: e
                }),
                c = {
                    left: "right",
                    right: "left",
                    bottom: "top",
                    top: "bottom"
                },
                s = {
                    start: "end",
                    end: "start"
                };

            function f(e, t, n) {
                return i(e, o(t, n))
            }

            function d(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function p(e) {
                return e.split("-")[0]
            }

            function m(e) {
                return e.split("-")[1]
            }

            function h(e) {
                return "x" === e ? "y" : "x"
            }

            function v(e) {
                return "y" === e ? "height" : "width"
            }

            function g(e) {
                return ["top", "bottom"].includes(p(e)) ? "y" : "x"
            }

            function y(e) {
                return h(g(e))
            }

            function b(e, t, n) {
                void 0 === n && (n = !1);
                let r = m(e),
                    o = y(e),
                    i = v(o),
                    a = "x" === o ? r === (n ? "end" : "start") ? "right" : "left" : "start" === r ? "bottom" : "top";
                return t.reference[i] > t.floating[i] && (a = C(a)), [a, C(a)]
            }

            function w(e) {
                let t = C(e);
                return [E(e), t, E(t)]
            }

            function E(e) {
                return e.replace(/start|end/g, e => s[e])
            }

            function x(e, t, n, r) {
                let o = m(e),
                    i = function(e, t, n) {
                        let r = ["left", "right"],
                            o = ["right", "left"];
                        switch (e) {
                            case "top":
                            case "bottom":
                                if (n) return t ? o : r;
                                return t ? r : o;
                            case "left":
                            case "right":
                                return t ? ["top", "bottom"] : ["bottom", "top"];
                            default:
                                return []
                        }
                    }(p(e), "start" === n, r);
                return o && (i = i.map(e => e + "-" + o), t && (i = i.concat(i.map(E)))), i
            }

            function C(e) {
                return e.replace(/left|right|bottom|top/g, e => c[e])
            }

            function O(e) {
                return "number" != typeof e ? {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0,
                    ...e
                } : {
                    top: e,
                    right: e,
                    bottom: e,
                    left: e
                }
            }

            function P(e) {
                return { ...e,
                    top: e.y,
                    left: e.x,
                    right: e.x + e.width,
                    bottom: e.y + e.height
                }
            }
        },
        19156: function(e, t, n) {
            "use strict";
            n.d(t, {
                C: function() {
                    return s
                }
            });
            var r = n(67294),
                o = n(74934),
                i = n(29107);
            let a = "danger",
                l = "relative",
                u = (0, i.j)(["inline-flex h-fit", "empty:p-none", "text-center font-bold", "rounded-full box-content"], {
                    variants: {
                        intent: (0, o.TY)({
                            main: ["bg-main", "text-on-main", "border-on-main"],
                            support: ["bg-support", "text-on-support", "border-on-support"],
                            accent: ["bg-accent", "text-on-accent", "border-on-accent"],
                            success: ["bg-success", "text-on-success", "border-on-success"],
                            alert: ["bg-alert", "text-on-alert", "border-on-alert"],
                            danger: ["bg-error", "text-on-error", "border-on-error"],
                            info: ["bg-info", "text-on-info", "border-on-info"],
                            neutral: ["bg-neutral", "text-on-neutral", "border-on-neutral"],
                            surface: ["bg-surface", "text-on-surface", "border-on-surface"],
                            basic: ["bg-basic", "text-on-basic", "border-on-basic"]
                        }),
                        size: (0, o.TY)({
                            sm: ["text-small", "px-[var(--sz-6)] py-[var(--sz-2)]", "empty:h-sz-12 empty:w-sz-12"],
                            md: ["text-caption", "px-md py-sm", "empty:h-sz-16 empty:w-sz-16"]
                        }),
                        type: {
                            relative: ["absolute right-none translate-x-2/4 -translate-y-2/4 border-md"],
                            standalone: []
                        }
                    },
                    defaultVariants: {
                        intent: a,
                        size: "md",
                        type: l
                    }
                }),
                c = (0, r.forwardRef)(({
                    intent: e = a,
                    size: t = "md",
                    type: n = l,
                    count: o,
                    overflowCount: i = 99,
                    "aria-label": c,
                    className: s,
                    ...f
                }, d) => {
                    let p = { ...f,
                        "aria-label": "function" == typeof c ? c({
                            count: o,
                            overflowCount: i
                        }) : c
                    };
                    return r.createElement("span", {
                        ref: d,
                        "data-spark-component": "badge",
                        role: "status",
                        className: u({
                            intent: e,
                            size: t,
                            type: n,
                            className: s
                        }),
                        ...p
                    }, o && o > i ? `${i}+` : o)
                });
            c.displayName = "BadgeItem";
            let s = (0, r.forwardRef)(({
                children: e,
                ...t
            }, n) => e ? r.createElement("div", {
                className: "relative inline-flex"
            }, e, r.createElement(c, {
                ref: n,
                ...t
            })) : r.createElement(c, {
                ref: n,
                type: "standalone",
                ...t
            }));
            s.displayName = "Badge"
        },
        34640: function(e, t, n) {
            "use strict";
            n.d(t, {
                I: function() {
                    return o
                }
            });
            var r = n(67294);
            let o = r.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: n = "none",
                ...o
            }, i) => r.createElement("svg", {
                ref: i,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "ArrowVerticalRight",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: n,
                ...o,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m7.3,2.28c-.38.38-.4,1.02-.03,1.41l7.69,8.31-7.69,8.31c-.37.4-.36,1.03.03,1.41.38.38.99.37,1.36-.03l7.87-8.51c.15-.16.27-.34.35-.54.08-.21.12-.43.12-.65s-.04-.44-.12-.65c-.08-.2-.2-.38-.35-.54L8.66,2.31c-.37-.4-.98-.41-1.36-.03Z"/>'
                }
            }));
            o.displayName = "ArrowVerticalRight"
        },
        63006: function(e, t, n) {
            "use strict";
            n.d(t, {
                J: function() {
                    return e1
                }
            });
            var r = n(67294),
                o = n.t(r, 2),
                i = n(87462);

            function a(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }

            function l(...e) {
                return t => e.forEach(e => {
                    var n;
                    "function" == typeof(n = e) ? n(t): null != n && (n.current = t)
                })
            }

            function u(...e) {
                return (0, r.useCallback)(l(...e), e)
            }
            var c = n(66593),
                s = n(27552),
                f = n(37802);
            let d = (null == globalThis ? void 0 : globalThis.document) ? r.useLayoutEffect : () => {},
                p = o["useId".toString()] || (() => void 0),
                m = 0;
            var h = n(85983),
                v = n(63853),
                g = n(73935);
            let y = e => ({
                name: "arrow",
                options: e,
                fn(t) {
                    let {
                        element: n,
                        padding: r
                    } = "function" == typeof e ? e(t) : e;
                    if (n && ({}).hasOwnProperty.call(n, "current")) {
                        if (null != n.current) return (0, h.x7)({
                            element: n.current,
                            padding: r
                        }).fn(t)
                    } else if (n) return (0, h.x7)({
                        element: n,
                        padding: r
                    }).fn(t);
                    return {}
                }
            });
            var b = "undefined" != typeof document ? r.useLayoutEffect : r.useEffect;

            function w(e, t) {
                let n, r, o;
                if (e === t) return !0;
                if (typeof e != typeof t) return !1;
                if ("function" == typeof e && e.toString() === t.toString()) return !0;
                if (e && t && "object" == typeof e) {
                    if (Array.isArray(e)) {
                        if ((n = e.length) != t.length) return !1;
                        for (r = n; 0 != r--;)
                            if (!w(e[r], t[r])) return !1;
                        return !0
                    }
                    if ((n = (o = Object.keys(e)).length) !== Object.keys(t).length) return !1;
                    for (r = n; 0 != r--;)
                        if (!({}).hasOwnProperty.call(t, o[r])) return !1;
                    for (r = n; 0 != r--;) {
                        let n = o[r];
                        if (("_owner" !== n || !e.$$typeof) && !w(e[n], t[n])) return !1
                    }
                    return !0
                }
                return e != e && t != t
            }

            function E(e) {
                if ("undefined" == typeof window) return 1;
                let t = e.ownerDocument.defaultView || window;
                return t.devicePixelRatio || 1
            }

            function x(e, t) {
                let n = E(e);
                return Math.round(t * n) / n
            }

            function C(e) {
                let t = r.useRef(e);
                return b(() => {
                    t.current = e
                }), t
            }
            let O = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...o
                } = e, a = r.Children.toArray(n), l = a.find(R);
                if (l) {
                    let e = l.props.children,
                        n = a.map(t => t !== l ? t : r.Children.count(e) > 1 ? r.Children.only(null) : (0, r.isValidElement)(e) ? e.props.children : null);
                    return (0, r.createElement)(P, (0, i.Z)({}, o, {
                        ref: t
                    }), (0, r.isValidElement)(e) ? (0, r.cloneElement)(e, void 0, n) : null)
                }
                return (0, r.createElement)(P, (0, i.Z)({}, o, {
                    ref: t
                }), n)
            });
            O.displayName = "Slot";
            let P = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...o
                } = e;
                return (0, r.isValidElement)(n) ? (0, r.cloneElement)(n, { ... function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let o = e[r],
                                i = t[r],
                                a = /^on[A-Z]/.test(r);
                            a ? o && i ? n[r] = (...e) => {
                                i(...e), o(...e)
                            } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                                ...i
                            } : "className" === r && (n[r] = [o, i].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(o, n.props),
                    ref: t ? function(...e) {
                        return t => e.forEach(e => {
                            var n;
                            "function" == typeof(n = e) ? n(t): null != n && (n.current = t)
                        })
                    }(t, n.ref) : n.ref
                }) : r.Children.count(n) > 1 ? r.Children.only(null) : null
            });
            P.displayName = "SlotClone";
            let N = ({
                children: e
            }) => (0, r.createElement)(r.Fragment, null, e);

            function R(e) {
                return (0, r.isValidElement)(e) && e.type === N
            }
            let T = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = (0, r.forwardRef)((e, n) => {
                        let {
                            asChild: o,
                            ...a
                        } = e, l = o ? O : t;
                        return (0, r.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, r.createElement)(l, (0, i.Z)({}, a, {
                            ref: n
                        }))
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                S = (0, r.forwardRef)((e, t) => {
                    let {
                        children: n,
                        width: o = 10,
                        height: a = 5,
                        ...l
                    } = e;
                    return (0, r.createElement)(T.svg, (0, i.Z)({}, l, {
                        ref: t,
                        width: o,
                        height: a,
                        viewBox: "0 0 30 10",
                        preserveAspectRatio: "none"
                    }), e.asChild ? n : (0, r.createElement)("polygon", {
                        points: "0,0 30,0 15,10"
                    }))
                });

            function k(...e) {
                return t => e.forEach(e => {
                    var n;
                    "function" == typeof(n = e) ? n(t): null != n && (n.current = t)
                })
            }

            function _(...e) {
                return (0, r.useCallback)(k(...e), e)
            }
            let A = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...o
                } = e, a = r.Children.toArray(n), l = a.find(z);
                if (l) {
                    let e = l.props.children,
                        n = a.map(t => t !== l ? t : r.Children.count(e) > 1 ? r.Children.only(null) : (0, r.isValidElement)(e) ? e.props.children : null);
                    return (0, r.createElement)(F, (0, i.Z)({}, o, {
                        ref: t
                    }), (0, r.isValidElement)(e) ? (0, r.cloneElement)(e, void 0, n) : null)
                }
                return (0, r.createElement)(F, (0, i.Z)({}, o, {
                    ref: t
                }), n)
            });
            A.displayName = "Slot";
            let F = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...o
                } = e;
                return (0, r.isValidElement)(n) ? (0, r.cloneElement)(n, { ... function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let o = e[r],
                                i = t[r],
                                a = /^on[A-Z]/.test(r);
                            a ? o && i ? n[r] = (...e) => {
                                i(...e), o(...e)
                            } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                                ...i
                            } : "className" === r && (n[r] = [o, i].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(o, n.props),
                    ref: t ? k(t, n.ref) : n.ref
                }) : r.Children.count(n) > 1 ? r.Children.only(null) : null
            });
            F.displayName = "SlotClone";
            let D = ({
                children: e
            }) => (0, r.createElement)(r.Fragment, null, e);

            function z(e) {
                return (0, r.isValidElement)(e) && e.type === D
            }
            let L = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = (0, r.forwardRef)((e, n) => {
                        let {
                            asChild: o,
                            ...a
                        } = e, l = o ? A : t;
                        return (0, r.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, r.createElement)(l, (0, i.Z)({}, a, {
                            ref: n
                        }))
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                I = (null == globalThis ? void 0 : globalThis.document) ? r.useLayoutEffect : () => {},
                j = "Popper",
                [M, B] = function(e, t = []) {
                    let n = [],
                        o = () => {
                            let t = n.map(e => (0, r.createContext)(e));
                            return function(n) {
                                let o = (null == n ? void 0 : n[e]) || t;
                                return (0, r.useMemo)(() => ({
                                    [`__scope${e}`]: { ...n,
                                        [e]: o
                                    }
                                }), [n, o])
                            }
                        };
                    return o.scopeName = e, [function(t, o) {
                        let i = (0, r.createContext)(o),
                            a = n.length;

                        function l(t) {
                            let {
                                scope: n,
                                children: o,
                                ...l
                            } = t, u = (null == n ? void 0 : n[e][a]) || i, c = (0, r.useMemo)(() => l, Object.values(l));
                            return (0, r.createElement)(u.Provider, {
                                value: c
                            }, o)
                        }
                        return n = [...n, o], l.displayName = t + "Provider", [l, function(n, l) {
                            let u = (null == l ? void 0 : l[e][a]) || i,
                                c = (0, r.useContext)(u);
                            if (c) return c;
                            if (void 0 !== o) return o;
                            throw Error(`\`${n}\` must be used within \`${t}\``)
                        }]
                    }, function(...e) {
                        let t = e[0];
                        if (1 === e.length) return t;
                        let n = () => {
                            let n = e.map(e => ({
                                useScope: e(),
                                scopeName: e.scopeName
                            }));
                            return function(e) {
                                let o = n.reduce((t, {
                                    useScope: n,
                                    scopeName: r
                                }) => {
                                    let o = n(e),
                                        i = o[`__scope${r}`];
                                    return { ...t,
                                        ...i
                                    }
                                }, {});
                                return (0, r.useMemo)(() => ({
                                    [`__scope${t.scopeName}`]: o
                                }), [o])
                            }
                        };
                        return n.scopeName = t.scopeName, n
                    }(o, ...t)]
                }(j),
                [V, H] = M(j),
                W = e => {
                    let {
                        __scopePopper: t,
                        children: n
                    } = e, [o, i] = (0, r.useState)(null);
                    return (0, r.createElement)(V, {
                        scope: t,
                        anchor: o,
                        onAnchorChange: i
                    }, n)
                },
                Z = (0, r.forwardRef)((e, t) => {
                    let {
                        __scopePopper: n,
                        virtualRef: o,
                        ...a
                    } = e, l = H("PopperAnchor", n), u = (0, r.useRef)(null), c = _(t, u);
                    return (0, r.useEffect)(() => {
                        l.onAnchorChange((null == o ? void 0 : o.current) || u.current)
                    }), o ? null : (0, r.createElement)(L.div, (0, i.Z)({}, a, {
                        ref: c
                    }))
                }),
                $ = "PopperContent",
                [q, G] = M($),
                U = (0, r.forwardRef)((e, t) => {
                    var n, o, a, l, u, c, s, f;
                    let {
                        __scopePopper: d,
                        side: p = "bottom",
                        sideOffset: m = 0,
                        align: O = "center",
                        alignOffset: P = 0,
                        arrowPadding: N = 0,
                        avoidCollisions: R = !0,
                        collisionBoundary: T = [],
                        collisionPadding: S = 0,
                        sticky: k = "partial",
                        hideWhenDetached: A = !1,
                        updatePositionStrategy: F = "optimized",
                        onPlaced: D,
                        ...z
                    } = e, j = H($, d), [M, B] = (0, r.useState)(null), V = _(t, e => B(e)), [W, Z] = (0, r.useState)(null), G = function(e) {
                        let [t, n] = (0, r.useState)(void 0);
                        return I(() => {
                            if (e) {
                                n({
                                    width: e.offsetWidth,
                                    height: e.offsetHeight
                                });
                                let t = new ResizeObserver(t => {
                                    let r, o;
                                    if (!Array.isArray(t) || !t.length) return;
                                    let i = t[0];
                                    if ("borderBoxSize" in i) {
                                        let e = i.borderBoxSize,
                                            t = Array.isArray(e) ? e[0] : e;
                                        r = t.inlineSize, o = t.blockSize
                                    } else r = e.offsetWidth, o = e.offsetHeight;
                                    n({
                                        width: r,
                                        height: o
                                    })
                                });
                                return t.observe(e, {
                                    box: "border-box"
                                }), () => t.unobserve(e)
                            }
                            n(void 0)
                        }, [e]), t
                    }(W), U = null !== (n = null == G ? void 0 : G.width) && void 0 !== n ? n : 0, Y = null !== (o = null == G ? void 0 : G.height) && void 0 !== o ? o : 0, X = "number" == typeof S ? S : {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0,
                        ...S
                    }, ee = Array.isArray(T) ? T : [T], et = ee.length > 0, en = {
                        padding: X,
                        boundary: ee.filter(K),
                        altBoundary: et
                    }, {
                        refs: er,
                        floatingStyles: eo,
                        placement: ei,
                        isPositioned: ea,
                        middlewareData: el
                    } = function(e) {
                        void 0 === e && (e = {});
                        let {
                            placement: t = "bottom",
                            strategy: n = "absolute",
                            middleware: o = [],
                            platform: i,
                            elements: {
                                reference: a,
                                floating: l
                            } = {},
                            transform: u = !0,
                            whileElementsMounted: c,
                            open: s
                        } = e, [f, d] = r.useState({
                            x: 0,
                            y: 0,
                            strategy: n,
                            placement: t,
                            middlewareData: {},
                            isPositioned: !1
                        }), [p, m] = r.useState(o);
                        w(p, o) || m(o);
                        let [h, y] = r.useState(null), [O, P] = r.useState(null), N = r.useCallback(e => {
                            e != k.current && (k.current = e, y(e))
                        }, [y]), R = r.useCallback(e => {
                            e !== _.current && (_.current = e, P(e))
                        }, [P]), T = a || h, S = l || O, k = r.useRef(null), _ = r.useRef(null), A = r.useRef(f), F = C(c), D = C(i), z = r.useCallback(() => {
                            if (!k.current || !_.current) return;
                            let e = {
                                placement: t,
                                strategy: n,
                                middleware: p
                            };
                            D.current && (e.platform = D.current), (0, v.oo)(k.current, _.current, e).then(e => {
                                let t = { ...e,
                                    isPositioned: !0
                                };
                                L.current && !w(A.current, t) && (A.current = t, g.flushSync(() => {
                                    d(t)
                                }))
                            })
                        }, [p, t, n, D]);
                        b(() => {
                            !1 === s && A.current.isPositioned && (A.current.isPositioned = !1, d(e => ({ ...e,
                                isPositioned: !1
                            })))
                        }, [s]);
                        let L = r.useRef(!1);
                        b(() => (L.current = !0, () => {
                            L.current = !1
                        }), []), b(() => {
                            if (T && (k.current = T), S && (_.current = S), T && S) {
                                if (F.current) return F.current(T, S, z);
                                z()
                            }
                        }, [T, S, z, F]);
                        let I = r.useMemo(() => ({
                                reference: k,
                                floating: _,
                                setReference: N,
                                setFloating: R
                            }), [N, R]),
                            j = r.useMemo(() => ({
                                reference: T,
                                floating: S
                            }), [T, S]),
                            M = r.useMemo(() => {
                                let e = {
                                    position: n,
                                    left: 0,
                                    top: 0
                                };
                                if (!j.floating) return e;
                                let t = x(j.floating, f.x),
                                    r = x(j.floating, f.y);
                                return u ? { ...e,
                                    transform: "translate(" + t + "px, " + r + "px)",
                                    ...E(j.floating) >= 1.5 && {
                                        willChange: "transform"
                                    }
                                } : {
                                    position: n,
                                    left: t,
                                    top: r
                                }
                            }, [n, u, j.floating, f.x, f.y]);
                        return r.useMemo(() => ({ ...f,
                            update: z,
                            refs: I,
                            elements: j,
                            floatingStyles: M
                        }), [f, z, I, j, M])
                    }({
                        strategy: "fixed",
                        placement: p + ("center" !== O ? "-" + O : ""),
                        whileElementsMounted: (...e) => {
                            let t = (0, v.Me)(...e, {
                                animationFrame: "always" === F
                            });
                            return t
                        },
                        elements: {
                            reference: j.anchor
                        },
                        middleware: [(0, h.cv)({
                            mainAxis: m + Y,
                            alignmentAxis: P
                        }), R && (0, h.uY)({
                            mainAxis: !0,
                            crossAxis: !1,
                            limiter: "partial" === k ? (0, h.dr)() : void 0,
                            ...en
                        }), R && (0, h.RR)({ ...en
                        }), (0, h.dp)({ ...en,
                            apply: ({
                                elements: e,
                                rects: t,
                                availableWidth: n,
                                availableHeight: r
                            }) => {
                                let {
                                    width: o,
                                    height: i
                                } = t.reference, a = e.floating.style;
                                a.setProperty("--radix-popper-available-width", `${n}px`), a.setProperty("--radix-popper-available-height", `${r}px`), a.setProperty("--radix-popper-anchor-width", `${o}px`), a.setProperty("--radix-popper-anchor-height", `${i}px`)
                            }
                        }), W && y({
                            element: W,
                            padding: N
                        }), J({
                            arrowWidth: U,
                            arrowHeight: Y
                        }), A && (0, h.Cp)({
                            strategy: "referenceHidden",
                            ...en
                        })]
                    }), [eu, ec] = Q(ei), es = function(e) {
                        let t = (0, r.useRef)(e);
                        return (0, r.useEffect)(() => {
                            t.current = e
                        }), (0, r.useMemo)(() => (...e) => {
                            var n;
                            return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                        }, [])
                    }(D);
                    I(() => {
                        ea && (null == es || es())
                    }, [ea, es]);
                    let ef = null === (a = el.arrow) || void 0 === a ? void 0 : a.x,
                        ed = null === (l = el.arrow) || void 0 === l ? void 0 : l.y,
                        ep = (null === (u = el.arrow) || void 0 === u ? void 0 : u.centerOffset) !== 0,
                        [em, eh] = (0, r.useState)();
                    return I(() => {
                        M && eh(window.getComputedStyle(M).zIndex)
                    }, [M]), (0, r.createElement)("div", {
                        ref: er.setFloating,
                        "data-radix-popper-content-wrapper": "",
                        style: { ...eo,
                            transform: ea ? eo.transform : "translate(0, -200%)",
                            minWidth: "max-content",
                            zIndex: em,
                            "--radix-popper-transform-origin": [null === (c = el.transformOrigin) || void 0 === c ? void 0 : c.x, null === (s = el.transformOrigin) || void 0 === s ? void 0 : s.y].join(" ")
                        },
                        dir: e.dir
                    }, (0, r.createElement)(q, {
                        scope: d,
                        placedSide: eu,
                        onArrowChange: Z,
                        arrowX: ef,
                        arrowY: ed,
                        shouldHideArrow: ep
                    }, (0, r.createElement)(L.div, (0, i.Z)({
                        "data-side": eu,
                        "data-align": ec
                    }, z, {
                        ref: V,
                        style: { ...z.style,
                            animation: ea ? void 0 : "none",
                            opacity: null !== (f = el.hide) && void 0 !== f && f.referenceHidden ? 0 : void 0
                        }
                    }))))
                }),
                Y = {
                    top: "bottom",
                    right: "left",
                    bottom: "top",
                    left: "right"
                },
                X = (0, r.forwardRef)(function(e, t) {
                    let {
                        __scopePopper: n,
                        ...o
                    } = e, a = G("PopperArrow", n), l = Y[a.placedSide];
                    return (0, r.createElement)("span", {
                        ref: a.onArrowChange,
                        style: {
                            position: "absolute",
                            left: a.arrowX,
                            top: a.arrowY,
                            [l]: 0,
                            transformOrigin: {
                                top: "",
                                right: "0 0",
                                bottom: "center 0",
                                left: "100% 0"
                            }[a.placedSide],
                            transform: {
                                top: "translateY(100%)",
                                right: "translateY(50%) rotate(90deg) translateX(-50%)",
                                bottom: "rotate(180deg)",
                                left: "translateY(50%) rotate(-90deg) translateX(50%)"
                            }[a.placedSide],
                            visibility: a.shouldHideArrow ? "hidden" : void 0
                        }
                    }, (0, r.createElement)(S, (0, i.Z)({}, o, {
                        ref: t,
                        style: { ...o.style,
                            display: "block"
                        }
                    })))
                });

            function K(e) {
                return null !== e
            }
            let J = e => ({
                name: "transformOrigin",
                options: e,
                fn(t) {
                    var n, r, o, i, a;
                    let {
                        placement: l,
                        rects: u,
                        middlewareData: c
                    } = t, s = (null === (n = c.arrow) || void 0 === n ? void 0 : n.centerOffset) !== 0, f = s ? 0 : e.arrowWidth, d = s ? 0 : e.arrowHeight, [p, m] = Q(l), h = {
                        start: "0%",
                        center: "50%",
                        end: "100%"
                    }[m], v = (null !== (r = null === (o = c.arrow) || void 0 === o ? void 0 : o.x) && void 0 !== r ? r : 0) + f / 2, g = (null !== (i = null === (a = c.arrow) || void 0 === a ? void 0 : a.y) && void 0 !== i ? i : 0) + d / 2, y = "", b = "";
                    return "bottom" === p ? (y = s ? h : `${v}px`, b = `${-d}px`) : "top" === p ? (y = s ? h : `${v}px`, b = `${u.floating.height+d}px`) : "right" === p ? (y = `${-d}px`, b = s ? h : `${g}px`) : "left" === p && (y = `${u.floating.width+d}px`, b = s ? h : `${g}px`), {
                        data: {
                            x: y,
                            y: b
                        }
                    }
                }
            });

            function Q(e) {
                let [t, n = "center"] = e.split("-");
                return [t, n]
            }
            var ee = n(93090);
            let et = e => {
                let {
                    present: t,
                    children: n
                } = e, o = function(e) {
                    var t;
                    let [n, o] = (0, r.useState)(), i = (0, r.useRef)({}), a = (0, r.useRef)(e), l = (0, r.useRef)("none"), [u, c] = (t = {
                        mounted: {
                            UNMOUNT: "unmounted",
                            ANIMATION_OUT: "unmountSuspended"
                        },
                        unmountSuspended: {
                            MOUNT: "mounted",
                            ANIMATION_END: "unmounted"
                        },
                        unmounted: {
                            MOUNT: "mounted"
                        }
                    }, (0, r.useReducer)((e, n) => {
                        let r = t[e][n];
                        return null != r ? r : e
                    }, e ? "mounted" : "unmounted"));
                    return (0, r.useEffect)(() => {
                        let e = en(i.current);
                        l.current = "mounted" === u ? e : "none"
                    }, [u]), d(() => {
                        let t = i.current,
                            n = a.current;
                        if (n !== e) {
                            let r = l.current,
                                o = en(t);
                            e ? c("MOUNT") : "none" === o || (null == t ? void 0 : t.display) === "none" ? c("UNMOUNT") : n && r !== o ? c("ANIMATION_OUT") : c("UNMOUNT"), a.current = e
                        }
                    }, [e, c]), d(() => {
                        if (n) {
                            let e = e => {
                                    let t = en(i.current),
                                        r = t.includes(e.animationName);
                                    e.target === n && r && (0, g.flushSync)(() => c("ANIMATION_END"))
                                },
                                t = e => {
                                    e.target === n && (l.current = en(i.current))
                                };
                            return n.addEventListener("animationstart", t), n.addEventListener("animationcancel", e), n.addEventListener("animationend", e), () => {
                                n.removeEventListener("animationstart", t), n.removeEventListener("animationcancel", e), n.removeEventListener("animationend", e)
                            }
                        }
                        c("ANIMATION_END")
                    }, [n, c]), {
                        isPresent: ["mounted", "unmountSuspended"].includes(u),
                        ref: (0, r.useCallback)(e => {
                            e && (i.current = getComputedStyle(e)), o(e)
                        }, [])
                    }
                }(t), i = "function" == typeof n ? n({
                    present: o.isPresent
                }) : r.Children.only(n), a = u(o.ref, i.ref);
                return "function" == typeof n || o.isPresent ? (0, r.cloneElement)(i, {
                    ref: a
                }) : null
            };

            function en(e) {
                return (null == e ? void 0 : e.animationName) || "none"
            }
            et.displayName = "Presence";
            let er = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...o
                } = e, a = r.Children.toArray(n), l = a.find(ea);
                if (l) {
                    let e = l.props.children,
                        n = a.map(t => t !== l ? t : r.Children.count(e) > 1 ? r.Children.only(null) : (0, r.isValidElement)(e) ? e.props.children : null);
                    return (0, r.createElement)(eo, (0, i.Z)({}, o, {
                        ref: t
                    }), (0, r.isValidElement)(e) ? (0, r.cloneElement)(e, void 0, n) : null)
                }
                return (0, r.createElement)(eo, (0, i.Z)({}, o, {
                    ref: t
                }), n)
            });
            er.displayName = "Slot";
            let eo = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...o
                } = e;
                return (0, r.isValidElement)(n) ? (0, r.cloneElement)(n, { ... function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let o = e[r],
                                i = t[r],
                                a = /^on[A-Z]/.test(r);
                            a ? o && i ? n[r] = (...e) => {
                                i(...e), o(...e)
                            } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                                ...i
                            } : "className" === r && (n[r] = [o, i].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(o, n.props),
                    ref: t ? l(t, n.ref) : n.ref
                }) : r.Children.count(n) > 1 ? r.Children.only(null) : null
            });
            eo.displayName = "SlotClone";
            let ei = ({
                children: e
            }) => (0, r.createElement)(r.Fragment, null, e);

            function ea(e) {
                return (0, r.isValidElement)(e) && e.type === ei
            }
            let el = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let n = (0, r.forwardRef)((e, n) => {
                    let {
                        asChild: o,
                        ...a
                    } = e, l = o ? er : t;
                    return (0, r.useEffect)(() => {
                        window[Symbol.for("radix-ui")] = !0
                    }, []), (0, r.createElement)(l, (0, i.Z)({}, a, {
                        ref: n
                    }))
                });
                return n.displayName = `Primitive.${t}`, { ...e,
                    [t]: n
                }
            }, {});

            function eu(e) {
                let t = (0, r.useRef)(e);
                return (0, r.useEffect)(() => {
                    t.current = e
                }), (0, r.useMemo)(() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }, [])
            }
            var ec = n(23541),
                es = n(71860);
            let ef = "Popover",
                [ed, ep] = function(e, t = []) {
                    let n = [],
                        o = () => {
                            let t = n.map(e => (0, r.createContext)(e));
                            return function(n) {
                                let o = (null == n ? void 0 : n[e]) || t;
                                return (0, r.useMemo)(() => ({
                                    [`__scope${e}`]: { ...n,
                                        [e]: o
                                    }
                                }), [n, o])
                            }
                        };
                    return o.scopeName = e, [function(t, o) {
                        let i = (0, r.createContext)(o),
                            a = n.length;

                        function l(t) {
                            let {
                                scope: n,
                                children: o,
                                ...l
                            } = t, u = (null == n ? void 0 : n[e][a]) || i, c = (0, r.useMemo)(() => l, Object.values(l));
                            return (0, r.createElement)(u.Provider, {
                                value: c
                            }, o)
                        }
                        return n = [...n, o], l.displayName = t + "Provider", [l, function(n, l) {
                            let u = (null == l ? void 0 : l[e][a]) || i,
                                c = (0, r.useContext)(u);
                            if (c) return c;
                            if (void 0 !== o) return o;
                            throw Error(`\`${n}\` must be used within \`${t}\``)
                        }]
                    }, function(...e) {
                        let t = e[0];
                        if (1 === e.length) return t;
                        let n = () => {
                            let n = e.map(e => ({
                                useScope: e(),
                                scopeName: e.scopeName
                            }));
                            return function(e) {
                                let o = n.reduce((t, {
                                    useScope: n,
                                    scopeName: r
                                }) => {
                                    let o = n(e),
                                        i = o[`__scope${r}`];
                                    return { ...t,
                                        ...i
                                    }
                                }, {});
                                return (0, r.useMemo)(() => ({
                                    [`__scope${t.scopeName}`]: o
                                }), [o])
                            }
                        };
                        return n.scopeName = t.scopeName, n
                    }(o, ...t)]
                }(ef, [B]),
                em = B(),
                [eh, ev] = ed(ef),
                eg = e => {
                    let {
                        __scopePopover: t,
                        children: n,
                        open: o,
                        defaultOpen: i,
                        onOpenChange: a,
                        modal: l = !1
                    } = e, u = em(t), c = (0, r.useRef)(null), [s, f] = (0, r.useState)(!1), [h = !1, v] = function({
                        prop: e,
                        defaultProp: t,
                        onChange: n = () => {}
                    }) {
                        let [o, i] = function({
                            defaultProp: e,
                            onChange: t
                        }) {
                            let n = (0, r.useState)(e),
                                [o] = n,
                                i = (0, r.useRef)(o),
                                a = eu(t);
                            return (0, r.useEffect)(() => {
                                i.current !== o && (a(o), i.current = o)
                            }, [o, i, a]), n
                        }({
                            defaultProp: t,
                            onChange: n
                        }), a = void 0 !== e, l = eu(n), u = (0, r.useCallback)(t => {
                            if (a) {
                                let n = "function" == typeof t ? t(e) : t;
                                n !== e && l(n)
                            } else i(t)
                        }, [a, e, i, l]);
                        return [a ? e : o, u]
                    }({
                        prop: o,
                        defaultProp: i,
                        onChange: a
                    });
                    return (0, r.createElement)(W, u, (0, r.createElement)(eh, {
                        scope: t,
                        contentId: function(e) {
                            let [t, n] = r.useState(p());
                            return d(() => {
                                e || n(e => null != e ? e : String(m++))
                            }, [e]), e || (t ? `radix-${t}` : "")
                        }(),
                        triggerRef: c,
                        open: h,
                        onOpenChange: v,
                        onOpenToggle: (0, r.useCallback)(() => v(e => !e), [v]),
                        hasCustomAnchor: s,
                        onCustomAnchorAdd: (0, r.useCallback)(() => f(!0), []),
                        onCustomAnchorRemove: (0, r.useCallback)(() => f(!1), []),
                        modal: l
                    }, n))
                },
                ey = (0, r.forwardRef)((e, t) => {
                    let {
                        __scopePopover: n,
                        ...o
                    } = e, a = ev("PopoverAnchor", n), l = em(n), {
                        onCustomAnchorAdd: u,
                        onCustomAnchorRemove: c
                    } = a;
                    return (0, r.useEffect)(() => (u(), () => c()), [u, c]), (0, r.createElement)(Z, (0, i.Z)({}, l, o, {
                        ref: t
                    }))
                }),
                eb = (0, r.forwardRef)((e, t) => {
                    let {
                        __scopePopover: n,
                        ...o
                    } = e, l = ev("PopoverTrigger", n), c = em(n), s = u(t, l.triggerRef), f = (0, r.createElement)(el.button, (0, i.Z)({
                        type: "button",
                        "aria-haspopup": "dialog",
                        "aria-expanded": l.open,
                        "aria-controls": l.contentId,
                        "data-state": e_(l.open)
                    }, o, {
                        ref: s,
                        onClick: a(e.onClick, l.onOpenToggle)
                    }));
                    return l.hasCustomAnchor ? f : (0, r.createElement)(Z, (0, i.Z)({
                        asChild: !0
                    }, c), f)
                }),
                ew = "PopoverPortal",
                [eE, ex] = ed(ew, {
                    forceMount: void 0
                }),
                eC = e => {
                    let {
                        __scopePopover: t,
                        forceMount: n,
                        children: o,
                        container: i
                    } = e, a = ev(ew, t);
                    return (0, r.createElement)(eE, {
                        scope: t,
                        forceMount: n
                    }, (0, r.createElement)(et, {
                        present: n || a.open
                    }, (0, r.createElement)(ee.h, {
                        asChild: !0,
                        container: i
                    }, o)))
                },
                eO = "PopoverContent",
                eP = (0, r.forwardRef)((e, t) => {
                    let n = ex(eO, e.__scopePopover),
                        {
                            forceMount: o = n.forceMount,
                            ...a
                        } = e,
                        l = ev(eO, e.__scopePopover);
                    return (0, r.createElement)(et, {
                        present: o || l.open
                    }, l.modal ? (0, r.createElement)(eN, (0, i.Z)({}, a, {
                        ref: t
                    })) : (0, r.createElement)(eR, (0, i.Z)({}, a, {
                        ref: t
                    })))
                }),
                eN = (0, r.forwardRef)((e, t) => {
                    let n = ev(eO, e.__scopePopover),
                        o = (0, r.useRef)(null),
                        l = u(t, o),
                        c = (0, r.useRef)(!1);
                    return (0, r.useEffect)(() => {
                        let e = o.current;
                        if (e) return (0, ec.Ry)(e)
                    }, []), (0, r.createElement)(es.Z, {
                        as: er,
                        allowPinchZoom: !0
                    }, (0, r.createElement)(eT, (0, i.Z)({}, e, {
                        ref: l,
                        trapFocus: n.open,
                        disableOutsidePointerEvents: !0,
                        onCloseAutoFocus: a(e.onCloseAutoFocus, e => {
                            var t;
                            e.preventDefault(), c.current || null === (t = n.triggerRef.current) || void 0 === t || t.focus()
                        }),
                        onPointerDownOutside: a(e.onPointerDownOutside, e => {
                            let t = e.detail.originalEvent,
                                n = 0 === t.button && !0 === t.ctrlKey,
                                r = 2 === t.button || n;
                            c.current = r
                        }, {
                            checkForDefaultPrevented: !1
                        }),
                        onFocusOutside: a(e.onFocusOutside, e => e.preventDefault(), {
                            checkForDefaultPrevented: !1
                        })
                    })))
                }),
                eR = (0, r.forwardRef)((e, t) => {
                    let n = ev(eO, e.__scopePopover),
                        o = (0, r.useRef)(!1),
                        a = (0, r.useRef)(!1);
                    return (0, r.createElement)(eT, (0, i.Z)({}, e, {
                        ref: t,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        onCloseAutoFocus: t => {
                            var r, i;
                            null === (r = e.onCloseAutoFocus) || void 0 === r || r.call(e, t), t.defaultPrevented || (o.current || null === (i = n.triggerRef.current) || void 0 === i || i.focus(), t.preventDefault()), o.current = !1, a.current = !1
                        },
                        onInteractOutside: t => {
                            var r, i;
                            null === (r = e.onInteractOutside) || void 0 === r || r.call(e, t), t.defaultPrevented || (o.current = !0, "pointerdown" !== t.detail.originalEvent.type || (a.current = !0));
                            let l = t.target,
                                u = null === (i = n.triggerRef.current) || void 0 === i ? void 0 : i.contains(l);
                            u && t.preventDefault(), "focusin" === t.detail.originalEvent.type && a.current && t.preventDefault()
                        }
                    }))
                }),
                eT = (0, r.forwardRef)((e, t) => {
                    let {
                        __scopePopover: n,
                        trapFocus: o,
                        onOpenAutoFocus: a,
                        onCloseAutoFocus: l,
                        disableOutsidePointerEvents: u,
                        onEscapeKeyDown: d,
                        onPointerDownOutside: p,
                        onFocusOutside: m,
                        onInteractOutside: h,
                        ...v
                    } = e, g = ev(eO, n), y = em(n);
                    return (0, s.EW)(), (0, r.createElement)(f.M, {
                        asChild: !0,
                        loop: !0,
                        trapped: o,
                        onMountAutoFocus: a,
                        onUnmountAutoFocus: l
                    }, (0, r.createElement)(c.XB, {
                        asChild: !0,
                        disableOutsidePointerEvents: u,
                        onInteractOutside: h,
                        onEscapeKeyDown: d,
                        onPointerDownOutside: p,
                        onFocusOutside: m,
                        onDismiss: () => g.onOpenChange(!1)
                    }, (0, r.createElement)(U, (0, i.Z)({
                        "data-state": e_(g.open),
                        role: "dialog",
                        id: g.contentId
                    }, y, v, {
                        ref: t,
                        style: { ...v.style,
                            "--radix-popover-content-transform-origin": "var(--radix-popper-transform-origin)",
                            "--radix-popover-content-available-width": "var(--radix-popper-available-width)",
                            "--radix-popover-content-available-height": "var(--radix-popper-available-height)",
                            "--radix-popover-trigger-width": "var(--radix-popper-anchor-width)",
                            "--radix-popover-trigger-height": "var(--radix-popper-anchor-height)"
                        }
                    }))))
                }),
                eS = (0, r.forwardRef)((e, t) => {
                    let {
                        __scopePopover: n,
                        ...o
                    } = e, l = ev("PopoverClose", n);
                    return (0, r.createElement)(el.button, (0, i.Z)({
                        type: "button"
                    }, o, {
                        ref: t,
                        onClick: a(e.onClick, () => l.onOpenChange(!1))
                    }))
                }),
                ek = (0, r.forwardRef)((e, t) => {
                    let {
                        __scopePopover: n,
                        ...o
                    } = e, a = em(n);
                    return (0, r.createElement)(X, (0, i.Z)({}, a, o, {
                        ref: t
                    }))
                });

            function e_(e) {
                return e ? "open" : "closed"
            }
            var eA = n(29107),
                eF = n(33274);
            let eD = (0, r.forwardRef)((e, t) => r.createElement(eF.f, {
                ref: t,
                ...e
            }));
            eD.displayName = "VisuallyHidden";
            var ez = n(74934);
            let eL = (0, eA.j)(["fill-current"], {
                    variants: {
                        intent: (0, ez.TY)({
                            current: ["text-current"],
                            main: ["text-main"],
                            support: ["text-support"],
                            accent: ["text-accent"],
                            basic: ["text-basic"],
                            success: ["text-success"],
                            alert: ["text-alert"],
                            error: ["text-error"],
                            info: ["text-info"],
                            neutral: ["text-neutral"]
                        }),
                        size: (0, ez.TY)({
                            current: ["u-current-font-size"],
                            sm: ["w-sz-16", "h-sz-16"],
                            md: ["w-sz-24", "h-sz-24"],
                            lg: ["w-sz-32", "h-sz-32"],
                            xl: ["w-sz-40", "h-sz-40"]
                        })
                    }
                }),
                eI = ({
                    label: e,
                    className: t,
                    size: n = "current",
                    intent: o = "current",
                    children: i,
                    ...a
                }) => {
                    let l = r.Children.only(i);
                    return r.createElement(r.Fragment, null, (0, r.cloneElement)(l, {
                        className: eL({
                            className: t,
                            size: n,
                            intent: o
                        }),
                        "data-spark-component": "icon",
                        "aria-hidden": "true",
                        focusable: "false",
                        ...a
                    }), e && r.createElement(eD, null, e))
                };
            eI.displayName = "Icon";
            var ej = n(93845);
            let eM = (null == globalThis ? void 0 : globalThis.document) ? r.useLayoutEffect : () => {},
                eB = o["useId".toString()] || (() => void 0),
                eV = 0,
                eH = (0, r.createContext)(null),
                eW = ({
                    children: e
                }) => {
                    let [t, n] = (0, r.useState)(!1), [o, i] = (0, r.useState)(null);
                    return r.createElement(eH.Provider, {
                        value: {
                            hasCloseButton: t,
                            setHasCloseButton: n,
                            headerId: o,
                            setHeaderId: i
                        }
                    }, e)
                },
                eZ = () => {
                    let e = (0, r.useContext)(eH);
                    if (!e) throw Error("usePopover must be used within a Popover provider");
                    return e
                },
                e$ = ({
                    children: e,
                    modal: t = !1,
                    ...n
                }) => r.createElement(eW, null, r.createElement(eg, {
                    "data-spark-component": "popover",
                    modal: t,
                    ...n
                }, e));
            e$.displayName = "Popover";
            let eq = (0, r.forwardRef)(({
                asChild: e = !1,
                children: t,
                ...n
            }, o) => r.createElement(ey, {
                "data-spark-component": "popover-anchor",
                ref: o,
                asChild: e,
                ...n
            }, t));
            eq.displayName = "Popover.Anchor";
            let eG = (0, r.forwardRef)(({
                asChild: e = !1,
                width: t = 16,
                height: n = 8,
                className: o,
                ...i
            }, a) => {
                let l = (0, eA.cx)("fill-surface visible", o);
                return r.createElement(ek, {
                    "data-spark-component": "popover-arrow",
                    ref: a,
                    className: l,
                    asChild: e,
                    width: t,
                    height: n,
                    ...i
                })
            });
            eG.displayName = "Popover.Arrow";
            let eU = r.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: n = "none",
                ...o
            }, i) => r.createElement("svg", {
                ref: i,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "Close",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: n,
                ...o,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m21.6,19.67l-7.68-7.68,7.57-7.59c.53-.53.53-1.4,0-1.93-.53-.53-1.4-.53-1.93,0l-7.57,7.58L4.33,2.4c-.53-.53-1.4-.53-1.93,0-.53.53-.53,1.4,0,1.93l7.66,7.66-7.66,7.65c-.53.53-.53,1.4,0,1.93.53.53,1.4.53,1.93,0l7.66-7.66,7.68,7.68c.53.53,1.4.53,1.93,0,.53-.53.53-1.4,0-1.93h0Z"/>'
                }
            }));
            eU.displayName = "Close";
            let eY = (0, r.forwardRef)(({
                "aria-label": e,
                className: t,
                ...n
            }, o) => {
                let {
                    setHasCloseButton: i
                } = eZ();
                return (0, r.useLayoutEffect)(() => (i(!0), () => i(!1)), [i]), r.createElement(eS, {
                    "data-spark-component": "popover-close-button",
                    ref: o,
                    className: (0, eA.cx)("absolute right-md top-md", t),
                    asChild: !0,
                    ...n
                }, r.createElement(ej.h, {
                    size: "sm",
                    intent: "neutral",
                    design: "ghost",
                    "aria-label": e
                }, r.createElement(eI, null, r.createElement(eU, null))))
            });
            eY.displayName = "Popover.CloseButton";
            let eX = (0, eA.j)(["z-popover", "rounded-md", "bg-surface text-on-surface", "shadow", "focus-visible:outline-none focus-visible:u-ring"], {
                    variants: {
                        matchTriggerWidth: {
                            true: "w-[--radix-popper-anchor-width]"
                        },
                        enforceBoundaries: {
                            true: ["max-w-[--radix-popper-available-width]"],
                            false: ["max-w-[min(var(--sz-384),100vw)]"]
                        },
                        hasCloseButton: {
                            true: "pr-[40px]"
                        },
                        inset: {
                            true: "overflow-hidden",
                            false: "p-lg"
                        }
                    },
                    compoundVariants: [{
                        hasCloseButton: !0,
                        inset: !0,
                        class: "pr-none"
                    }],
                    defaultVariants: {
                        matchTriggerWidth: !1,
                        enforceBoundaries: !1,
                        hasCloseButton: !1,
                        inset: !1
                    }
                }),
                eK = (0, r.forwardRef)(({
                    className: e,
                    children: t,
                    matchTriggerWidth: n = !1,
                    align: o = "center",
                    arrowPadding: i = 16,
                    asChild: a = !1,
                    avoidCollisions: l = !0,
                    "aria-labelledby": u,
                    collisionBoundary: c,
                    collisionPadding: s = 0,
                    hideWhenDetached: f = !1,
                    side: d = "bottom",
                    sideOffset: p = 8,
                    sticky: m = "partial",
                    inset: h = !1,
                    ...v
                }, g) => {
                    let {
                        hasCloseButton: y,
                        headerId: b
                    } = eZ();
                    return r.createElement(eP, {
                        "aria-labelledby": b || u,
                        className: eX({
                            enforceBoundaries: !!c,
                            matchTriggerWidth: n,
                            hasCloseButton: y,
                            inset: h,
                            className: e
                        }),
                        "data-spark-component": "popover-content",
                        ref: g,
                        align: o,
                        arrowPadding: i,
                        asChild: a,
                        avoidCollisions: l,
                        collisionBoundary: c,
                        collisionPadding: s,
                        hideWhenDetached: f,
                        side: d,
                        sideOffset: p,
                        sticky: m,
                        ...v
                    }, t)
                });
            eK.displayName = "Popover.Content";
            let eJ = (0, r.forwardRef)(({
                children: e,
                className: t,
                ...n
            }, o) => {
                let i = function(e) {
                        let [t, n] = r.useState(eB());
                        return eM(() => {
                            e || n(e => null != e ? e : String(eV++))
                        }, [e]), e || (t ? `radix-${t}` : "")
                    }(),
                    {
                        setHeaderId: a
                    } = eZ();
                return (0, r.useLayoutEffect)(() => (a(i), () => a(null)), [i, a]), r.createElement("header", {
                    id: i,
                    ref: o,
                    className: (0, eA.cx)("mb-md text-headline-2", t),
                    ...n
                }, e)
            });
            eJ.displayName = "Popover.Header";
            let eQ = ({
                children: e,
                ...t
            }) => r.createElement(eC, { ...t
            }, e);
            eQ.displayName = "Popover.Portal";
            let e0 = (0, r.forwardRef)(({
                asChild: e = !1,
                children: t,
                ...n
            }, o) => r.createElement(eb, {
                "data-spark-component": "popover-trigger",
                ref: o,
                asChild: e,
                ...n
            }, t));
            e0.displayName = "Popover.Trigger";
            let e1 = Object.assign(e$, {
                Anchor: eq,
                Arrow: eG,
                CloseButton: eY,
                Content: eK,
                Header: eJ,
                Portal: eQ,
                Trigger: e0
            });
            e1.displayName = "Popover", eq.displayName = "Popover.Anchor", eG.displayName = "Popover.Arrow", eY.displayName = "Popover.CloseButton", eK.displayName = "Popover.Content", eJ.displayName = "Popover.Header", eQ.displayName = "Popover.Portal", e0.displayName = "Popover.Trigger"
        }
    }
]);