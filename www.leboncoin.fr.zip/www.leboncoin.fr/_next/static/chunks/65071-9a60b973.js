! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            s = Error().stack;
        s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "6e97295e-7341-45e3-9cf0-ca223707039d", e._sentryDebugIdIdentifier = "sentry-dbid-6e97295e-7341-45e3-9cf0-ca223707039d")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [65071], {
        1891: function(e, s, n) {
            n.r(s), n.d(s, {
                default: function() {
                    return et
                }
            });
            var a = n(72253),
                t = n(85893),
                r = n(35150),
                i = n(67294),
                c = n(94363),
                o = n(67837),
                l = n(9873),
                u = n(66865),
                d = n(4804),
                m = n(95270),
                x = n(9196),
                f = n(1295),
                g = n(30294),
                j = n(32737),
                p = n(66123),
                v = n(31354),
                y = n(43387),
                h = n(52026),
                w = n(29107),
                N = (0, w.cx)("flex min-w-0 flex-col gap-y-sm"),
                b = (0, w.cx)("flex items-center"),
                Z = (0, w.cx)("mt-sm flex items-end gap-md"),
                _ = (0, i.memo)(function(e) {
                    var s = e.allowSave,
                        n = e.isPro,
                        a = e.transactionStatus;
                    return (0, t.jsxs)(t.Fragment, {
                        children: [(0, t.jsxs)("div", {
                            className: N,
                            "data-test-id": "bigpicture-default-content",
                            children: [(0, t.jsx)(y.Z, {
                                maxLines: 1
                            }), (0, t.jsx)(j.Z, {
                                dataQaId: "aditem_price"
                            }), (0, t.jsxs)("div", {
                                className: b,
                                children: [n && (0, t.jsx)(d.gQ, {
                                    className: "mr-md"
                                }), (0, t.jsx)(v.Z, {})]
                            }), (0, t.jsx)(h.Z, {
                                className: "mt-md"
                            })]
                        }), (0, t.jsxs)("div", {
                            className: Z,
                            children: ["sold" !== a && (0, t.jsx)(g.Z, {}), s && (0, t.jsx)(p.Z, {
                                className: "ml-auto"
                            })]
                        })]
                    })
                }),
                S = function(e) {
                    var s = (0, x.M)(),
                        n = s.allowSave,
                        r = s.isPro,
                        i = s.transactionStatus;
                    return (0, t.jsx)(_, (0, a._)({
                        allowSave: n,
                        isPro: r,
                        transactionStatus: i
                    }, e))
                },
                I = n(64618),
                C = n(84920),
                E = (0, w.cx)("flex min-w-0 flex-col"),
                k = (0, w.cx)("flex items-start justify-between gap-x-sm");
            (0, w.cx)("flex items-center");
            var D = (0, w.cx)("mt-sm !text-body-2"),
                F = function(e, s) {
                    return "\n  .".concat(s, " {\n    margin-top: var(--spacing-").concat("row" === e.direction ? "lg" : "sm", ")\n  }  \n")
                },
                M = (0, w.cx)("mt-sm flex items-end gap-md"),
                P = (0, i.memo)(function(e) {
                    var s = e.ad,
                        n = e.allowSave,
                        a = e.isPro,
                        r = e.layout;
                    return (0, t.jsxs)(t.Fragment, {
                        children: [(0, t.jsxs)("div", {
                            className: E,
                            "data-test-id": "bigpicture-holidays-content",
                            children: [(0, t.jsxs)("div", {
                                className: k,
                                children: [(0, t.jsx)(y.Z, {
                                    maxLines: 1
                                }), (0, t.jsx)(I.Z, {
                                    ad: s
                                })]
                            }), (0, t.jsx)(C.Z, {
                                light: !0,
                                className: "mt-sm"
                            }), (0, t.jsxs)("div", {
                                className: "flex items-center",
                                children: [a && (0, t.jsx)(d.gQ, {
                                    className: "mr-md mt-sm"
                                }), (0, t.jsx)(v.Z, {
                                    className: "mt-sm"
                                })]
                            }), (0, t.jsx)(f.Z, {
                                as: j.Z,
                                layout: r,
                                stylesFromLayout: F,
                                className: D,
                                dataQaId: "aditem_price"
                            })]
                        }), (0, t.jsxs)("div", {
                            className: M,
                            children: [(0, t.jsx)(g.Z, {}), n && (0, t.jsx)(p.Z, {
                                className: "ml-auto"
                            })]
                        })]
                    })
                }),
                T = function(e) {
                    var s = (0, x.M)(),
                        n = s.ad,
                        r = s.allowSave,
                        i = s.isPro,
                        c = s.layout;
                    return (0, t.jsx)(P, (0, a._)({
                        ad: n,
                        allowSave: r,
                        isPro: i,
                        layout: c
                    }, e))
                },
                L = n(6599),
                Q = n(67741),
                z = n(98050),
                O = n(6583),
                R = n(88540),
                U = n(74840),
                Y = n(70285),
                q = (0, w.cx)("flex justify-between"),
                B = (0, w.cx)("flex min-w-0 flex-col gap-y-sm"),
                H = (0, w.cx)("flex flex-wrap items-center gap-sm"),
                X = (0, w.cx)("!text-body-2 !text-on-surface"),
                A = (0, w.cx)("mt-sm flex items-end justify-between gap-md"),
                G = (0, w.j)("flex items-center", {
                    variants: {
                        isConsulted: {
                            true: "opacity-dim-3"
                        }
                    }
                }),
                K = (0, i.memo)(function(e) {
                    var s = e.ad,
                        n = e.allowSave,
                        a = e.premiumType,
                        r = e.isPro,
                        i = e.isConsulted,
                        c = (0, U.u)([R.Xi, R.MC]),
                        o = "featured" !== a,
                        l = (0, L.kD)("store_logo", s),
                        u = (0, L.kD)("store_name", s);
                    return (0, t.jsxs)(t.Fragment, {
                        children: [(0, t.jsx)("div", {
                            "data-test-id": "bigpicture-housing-content",
                            children: (0, t.jsxs)("div", {
                                className: q,
                                children: [(0, t.jsxs)("div", {
                                    className: B,
                                    children: [(0, t.jsxs)("div", {
                                        className: H,
                                        children: [(0, t.jsx)(j.Z, {
                                            dataQaId: "aditem_price"
                                        }), c(s) && (0, t.jsx)(Y.Z, {
                                            ad: s,
                                            className: "ml-sm text-small"
                                        })]
                                    }), (0, t.jsx)(y.Z, {
                                        maxLines: 1,
                                        className: "text-body-2 font-regular"
                                    }), (0, t.jsx)(v.Z, {}), (0, t.jsx)(g.Z, {
                                        className: X
                                    })]
                                }), r && (0, t.jsx)(d.gQ, {
                                    className: "ml-md"
                                })]
                            })
                        }), (0, t.jsxs)("div", {
                            className: A,
                            children: [l && u ? (0, t.jsxs)("div", {
                                className: G({
                                    isConsulted: i
                                }),
                                "data-test-id": "ad-card-pro-store",
                                children: [(0, t.jsx)(z.Z, {}), (0, t.jsxs)("div", {
                                    children: [(0, t.jsx)(O.Z, {}), o && (0, t.jsx)(Q.Z, {})]
                                })]
                            }) : o && (0, t.jsx)(Q.Z, {}), n && (0, t.jsx)(p.Z, {
                                className: "ml-auto"
                            })]
                        })]
                    })
                }),
                J = function(e) {
                    var s = (0, x.M)(),
                        n = s.ad,
                        r = s.allowSave,
                        i = s.premiumType,
                        c = s.isPro,
                        o = s.isConsulted;
                    return (0, t.jsx)(K, (0, a._)({
                        ad: n,
                        allowSave: r,
                        isPro: c,
                        premiumType: i,
                        isConsulted: o
                    }, e))
                },
                V = (0, w.cx)("relative flex duration-200"),
                W = function(e, s) {
                    return "\n  .".concat(s, " { flex-direction: ").concat(e.direction, " }\n")
                },
                $ = (0, w.j)("relative", {
                    variants: {
                        isCustom: {
                            false: "flex flex-1 flex-col justify-between"
                        }
                    }
                }),
                ee = function(e, s) {
                    return "row" === e.direction ? "\n      .".concat(s, " {\n        margin-left: var(--spacing-lg);\n        margin-top: 0;\n        min-height: 21.5rem;\n      }\n    ") : "\n      .".concat(s, " {\n        margin-left: 0;\n        margin-top: var(--spacing-md);\n        min-height: 0;\n      }\n    ")
                },
                es = (0, w.cx)("absolute left-none top-none flex gap-md p-md"),
                en = function(e) {
                    switch ((0, r.xkK)(e)) {
                        case r.weE.Holidays:
                            return (0, t.jsx)(T, {});
                        case r.weE.Housing:
                            return (0, t.jsx)(J, {});
                        default:
                            return (0, t.jsx)(S, {})
                    }
                },
                ea = (0, i.memo)(function(e) {
                    var s, n = e.ad,
                        a = e.imgSources,
                        r = e.premiumType,
                        i = e.layout,
                        x = e.lazy,
                        g = e.cropImages,
                        j = e.isUrgent,
                        p = e.showOwnerInfo,
                        v = e.children,
                        y = null === (s = n.images.urls) || void 0 === s ? void 0 : s[0],
                        h = (0, t.jsxs)("div", {
                            className: es,
                            children: [("featured_highlighted" === r || "featured" === r) && (0, t.jsx)(d.om, {}), j && (0, t.jsx)(d.Mx, {
                                className: "bg-surface"
                            })]
                        });
                    return (0, t.jsxs)(t.Fragment, {
                        children: [p && (0, t.jsx)(u.Z, {}), (0, t.jsxs)(f.Z, {
                            as: "div",
                            layout: i,
                            stylesFromLayout: W,
                            className: V,
                            "data-test-id": "adcard-big-picture",
                            children: [(0, t.jsx)(m.Z, {
                                renderDefault: function() {
                                    return (0, t.jsx)(o.Z, {
                                        src: y,
                                        alt: "",
                                        sources: null == a ? void 0 : a.singleImage,
                                        cropped: g,
                                        lazy: x,
                                        className: "rounded-md"
                                    })
                                },
                                renderMosaic: function() {
                                    return (0, t.jsx)(l.Z, {
                                        sources: null == a ? void 0 : a.mosaic
                                    })
                                },
                                renderCarousel: function() {
                                    return (0, t.jsx)(c.Z, {
                                        sources: null == a ? void 0 : a.carousel
                                    })
                                },
                                children: h
                            }), (0, t.jsx)(f.Z, {
                                as: "div",
                                layout: i,
                                stylesFromLayout: ee,
                                className: $({
                                    isCustom: !!v
                                }),
                                children: v || en(n.category_id)
                            })]
                        })]
                    })
                }),
                et = function(e) {
                    var s = (0, x.M)(),
                        n = s.ad,
                        r = s.imagesCount,
                        i = s.imgSources,
                        c = s.premiumType,
                        o = s.layout,
                        l = s.lazy,
                        u = s.cropImages,
                        d = s.isUrgent,
                        m = s.showOwnerInfo;
                    return (0, t.jsx)(ea, (0, a._)({
                        ad: n,
                        imgSources: i,
                        premiumType: c,
                        layout: o,
                        lazy: l,
                        cropImages: u,
                        imagesCount: r,
                        isUrgent: d,
                        showOwnerInfo: m
                    }, e))
                }
        },
        70285: function(e, s, n) {
            n.d(s, {
                Z: function() {
                    return f
                }
            });
            var a = n(72253),
                t = n(14932),
                r = n(47702),
                i = n(85893),
                c = n(29107);
            n(67294);
            var o = n(23621),
                l = n(71998),
                u = n(82729),
                d = n(16678);

            function m() {
                var e = (0, u._)(["\n  display: flex;\n  align-items: center;\n\n  ", "\n"]);
                return m = function() {
                    return e
                }, e
            }
            var x = (0, n(19181).default)("span").withConfig({
                    componentId: "sc-3b75e541-0"
                })(m(), (0, d.qC)(d.Dh, d.GQ)),
                f = function(e) {
                    var s = e.ad,
                        n = e.className,
                        u = (0, r._)(e, ["ad", "className"]);
                    return (0, i.jsx)(x, (0, t._)((0, a._)({
                        className: (0, c.cx)("text-caption text-on-background/dim-1", n)
                    }, u), {
                        children: (0, i.jsx)("p", {
                            children: (0, o.p)((0, l.sY)(s))
                        })
                    }))
                }
        },
        88540: function(e, s, n) {
            n.d(s, {
                BT: function() {
                    return c
                },
                MC: function() {
                    return i
                },
                Xi: function() {
                    return o
                }
            });
            var a = n(35150),
                t = n(6599),
                r = n(62651);

            function i(e) {
                var s = e.category_id,
                    n = e.attributes,
                    r = (0, t.kD)("lease_type", {
                        attributes: n
                    });
                return s === a.rOl && "sell" === r
            }

            function c(e) {
                return e.category_id === a.Ydx
            }

            function o(e) {
                var s = e.attributes,
                    n = (0, t.kD)(r.Eq, {
                        attributes: s
                    });
                return c(e) && "new" !== n
            }
        },
        23621: function(e, s, n) {
            n.d(s, {
                p: function() {
                    return a
                }
            });

            function a(e) {
                var s = e.price,
                    n = e.surface,
                    a = s / n;
                return !isNaN(a) && isFinite(a) && !(a < 1) ? "".concat(Intl.NumberFormat("fr-FR", {
                    style: "currency",
                    currency: "EUR",
                    maximumSignificantDigits: 10
                }).format(Math.round(s / n)), "/m\xb2") : void 0
            }
        },
        74840: function(e, s, n) {
            n.d(s, {
                u: function() {
                    return a
                }
            });

            function a(e) {
                return function(s) {
                    var n = [];
                    return e.forEach(function(e) {
                        n.push(e(s))
                    }), n.some(Boolean)
                }
            }
        }
    }
]);