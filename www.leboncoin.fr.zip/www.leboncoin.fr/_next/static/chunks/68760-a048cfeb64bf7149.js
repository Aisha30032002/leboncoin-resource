! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "14aa180c-e420-44a2-8fd9-85105c493acf", e._sentryDebugIdIdentifier = "sentry-dbid-14aa180c-e420-44a2-8fd9-85105c493acf")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [68760], {
        61814: function(e, t, n) {
            n.d(t, {
                II: function() {
                    return P
                },
                BZ: function() {
                    return B
                }
            });
            var r = n(67294),
                l = n(33274);
            let a = (0, r.forwardRef)((e, t) => r.createElement(l.f, {
                ref: t,
                ...e
            }));
            a.displayName = "VisuallyHidden";
            var i = n(74934),
                o = n(29107);
            let s = (0, o.j)(["fill-current"], {
                    variants: {
                        intent: (0, i.TY)({
                            current: ["text-current"],
                            main: ["text-main"],
                            support: ["text-support"],
                            accent: ["text-accent"],
                            basic: ["text-basic"],
                            success: ["text-success"],
                            alert: ["text-alert"],
                            error: ["text-error"],
                            info: ["text-info"],
                            neutral: ["text-neutral"]
                        }),
                        size: (0, i.TY)({
                            current: ["u-current-font-size"],
                            sm: ["w-sz-16", "h-sz-16"],
                            md: ["w-sz-24", "h-sz-24"],
                            lg: ["w-sz-32", "h-sz-32"],
                            xl: ["w-sz-40", "h-sz-40"]
                        })
                    }
                }),
                d = ({
                    label: e,
                    className: t,
                    size: n = "current",
                    intent: l = "current",
                    children: i,
                    ...o
                }) => {
                    let d = r.Children.only(i);
                    return r.createElement(r.Fragment, null, (0, r.cloneElement)(d, {
                        className: s({
                            className: t,
                            size: n,
                            intent: l
                        }),
                        "data-spark-component": "icon",
                        "aria-hidden": "true",
                        focusable: "false",
                        ...o
                    }), e && r.createElement(a, null, e))
                };
            d.displayName = "Icon";
            var u = n(7171),
                c = n(72307),
                f = n(59917),
                m = n(66051);
            let p = r.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: n = "none",
                ...l
            }, a) => r.createElement("svg", {
                ref: a,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "DeleteFill",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: n,
                ...l,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m2,12C2,6.48,6.48,2,12,2s10,4.48,10,10-4.48,10-10,10S2,17.52,2,12Zm7.75-3.67c-.39-.39-1.02-.39-1.41,0-.39.39-.39,1.02,0,1.41l2.23,2.23-2.23,2.23c-.39.39-.39,1.02,0,1.41.39.39,1.02.39,1.41,0l2.23-2.23,2.23,2.23c.39.39,1.02.39,1.41,0s.39-1.02,0-1.41l-2.23-2.23,2.23-2.23c.39-.39.39-1.02,0-1.41-.39-.39-1.02-.39-1.41,0l-2.23,2.23-2.23-2.23Z"/>'
                }
            }));
            p.displayName = "DeleteFill";
            let h = (0, r.createContext)(null),
                g = () => (0, r.useContext)(h) || {
                    isStandalone: !0
                },
                b = (0, r.forwardRef)(({
                    className: e,
                    tabIndex: t = -1,
                    onClick: n,
                    ...l
                }, a) => {
                    let {
                        onClear: i,
                        hasTrailingIcon: s
                    } = g();
                    return r.createElement("button", {
                        ref: a,
                        className: (0, o.cx)(e, "pointer-events-auto absolute top-1/2 -translate-y-1/2", "inline-flex h-full items-center justify-center outline-none", "text-neutral hover:text-neutral-hovered", s ? "right-3xl px-[var(--sz-12)]" : "right-none pl-md pr-lg"),
                        tabIndex: t,
                        onClick: e => {
                            n && n(e), i && i()
                        },
                        type: "button",
                        ...l
                    }, r.createElement(d, {
                        size: "sm"
                    }, r.createElement(p, null)))
                }),
                v = Object.assign(b, {
                    id: "ClearButton"
                });
            v.displayName = "InputGroup.ClearButton";
            let w = (0, o.j)(["relative inline-flex w-full"], {
                    variants: {
                        disabled: {
                            true: ["cursor-not-allowed", "relative", "after:absolute", "after:top-none", "after:h-full", "after:w-full", "after:border-sm after:border-outline", "after:rounded-lg"],
                            false: "after:hidden"
                        },
                        readOnly: {
                            true: ["relative", "after:absolute", "after:top-none", "after:h-full", "after:w-full", "after:border-sm after:border-outline", "after:rounded-lg"],
                            false: "after:hidden"
                        }
                    }
                }),
                y = r.forwardRef(({
                    title: e,
                    fill: t = "currentColor",
                    stroke: n = "none",
                    ...l
                }, a) => r.createElement("svg", {
                    ref: a,
                    viewBox: "0 0 24 24",
                    xmlns: "http://www.w3.org/2000/svg",
                    "data-title": "AlertOutline",
                    ...e && {
                        "data-title": e
                    },
                    fill: t,
                    stroke: n,
                    ...l,
                    dangerouslySetInnerHTML: {
                        __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path d="m12,7.13c-.58,0-1.05.47-1.05,1.05v4.82c0,.58.47,1.05,1.05,1.05s1.05-.47,1.05-1.05v-4.82c0-.58-.47-1.05-1.05-1.05Zm0,7.95c-.8,0-1.45.65-1.45,1.45s.65,1.45,1.45,1.45,1.45-.65,1.45-1.45-.65-1.45-1.45-1.45Z"/><path fill-rule="evenodd" d="m12,2C6.48,2,2,6.48,2,12s4.48,10,10,10,10-4.48,10-10S17.52,2,12,2Zm-7.89,10c0-4.36,3.53-7.89,7.89-7.89s7.89,3.53,7.89,7.89-3.53,7.89-7.89,7.89-7.89-3.53-7.89-7.89Z"/>'
                    }
                }));
            y.displayName = "AlertOutline";
            let E = r.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: n = "none",
                ...l
            }, a) => r.createElement("svg", {
                ref: a,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "Check",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: n,
                ...l,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path d="m8.92,19.08c-.18,0-.36-.03-.53-.1s-.33-.17-.47-.31l-5.49-5.34c-.28-.28-.42-.61-.42-1s.14-.73.42-1c.28-.28.62-.41,1.02-.41s.74.14,1.05.41l4.43,4.3,10.62-10.29c.28-.28.62-.42,1.02-.43.39,0,.73.13,1.02.43.28.28.42.61.42,1s-.14.73-.42,1l-11.65,11.32c-.14.14-.3.24-.47.31-.17.07-.35.1-.53.1Z"/>'
                }
            }));
            E.displayName = "Check";
            let x = r.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: n = "none",
                ...l
            }, a) => r.createElement("svg", {
                ref: a,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "WarningOutline",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: n,
                ...l,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m12,8.23c.55,0,1,.45,1,1v4.58c0,.55-.45,1-1,1s-1-.45-1-1v-4.58c0-.55.45-1,1-1Z"/><path d="m12,18.06c.69,0,1.25-.56,1.25-1.25s-.56-1.25-1.25-1.25-1.25.56-1.25,1.25.56,1.25,1.25,1.25Z"/><path fill-rule="evenodd" d="m10.76,2.35c.37-.23.8-.35,1.24-.35s.87.12,1.24.35c.37.23.68.56.88.95h0s7.62,15.24,7.62,15.24h0c.18.36.27.77.25,1.17-.02.41-.14.8-.35,1.15-.21.35-.51.63-.86.83-.35.2-.75.3-1.16.31H4.38c-.41,0-.81-.11-1.16-.31-.35-.2-.65-.49-.86-.83-.21-.35-.33-.74-.35-1.15-.02-.41.07-.81.25-1.17h0S9.88,3.3,9.88,3.3c.2-.39.5-.72.88-.95Zm1.24,1.65c-.07,0-.14.02-.2.06-.06.04-.11.09-.14.15l-7.62,15.23h0c-.03.06-.04.13-.04.19,0,.07.02.13.06.19.03.06.08.1.14.13.06.03.12.05.19.05h15.23c.07,0,.13-.02.19-.05.06-.03.11-.08.14-.13.03-.06.05-.12.06-.19,0-.07-.01-.13-.04-.19h0s-7.62-15.23-7.62-15.23c-.03-.06-.08-.11-.14-.15-.06-.04-.13-.06-.2-.06Z"/>'
                }
            }));
            x.displayName = "WarningOutline";
            let S = ({
                className: e,
                intent: t,
                children: n,
                ...l
            }) => {
                let {
                    disabled: a,
                    readOnly: i
                } = g();
                return r.createElement(d, {
                    intent: t,
                    className: (0, o.cx)(e, "pointer-events-none absolute top-[calc(var(--sz-44)/2)] -translate-y-1/2", t ? void 0 : "text-neutral peer-focus:text-outline-high", a || i ? "opacity-dim-3" : void 0),
                    ...l
                }, n)
            };
            S.displayName = "InputGroup.Icon";
            let C = ({
                className: e,
                ...t
            }) => r.createElement(S, {
                className: (0, o.cx)(e, "right-lg text-body-1"),
                ...t
            });
            C.id = "TrailingIcon", C.displayName = "InputGroup.TrailingIcon";
            let N = ({
                errorIcon: e = r.createElement(y, null),
                alertIcon: t = r.createElement(x, null),
                successIcon: n = r.createElement(E, null),
                ...l
            }) => {
                let {
                    state: a
                } = g();
                return a ? r.createElement(C, {
                    intent: a,
                    ...l
                }, {
                    error: e,
                    alert: t,
                    success: n
                }[a]) : null
            };
            N.id = "StateIndicator", N.displayName = "InputGroup.StateIndicator";
            let I = (0, r.forwardRef)(({
                className: e,
                children: t,
                state: n,
                disabled: l,
                readOnly: a,
                onClear: i,
                ...o
            }, s) => {
                let d = (...e) => m.find(t => e.includes((t ? t.type.id : "") || "")),
                    m = r.Children.toArray(t).filter(r.isValidElement),
                    p = d("Input"),
                    g = p ? .props || {},
                    b = (0, r.useRef)(null),
                    v = (0, r.useRef)(i),
                    y = (0, f.qq)(p ? .ref, b),
                    [E, x] = function(e, t, n) {
                        let l = void 0 !== e,
                            {
                                current: a
                            } = (0, r.useRef)(l ? e : t),
                            [i, o] = (0, r.useState)(t),
                            s = l ? e : i,
                            d = (0, r.useCallback)((e, t = (e, t) => !c(e, t)) => {
                                let r = "function" != typeof e ? e : e(s);
                                t(s, r) && !l && o(r), n && n(r)
                            }, [l, s, n]);
                        return [s, d, l, a]
                    }(g.value, g.defaultValue, g.onValueChange),
                    S = (0, u.H)(),
                    C = S.state ? ? n,
                    I = S.disabled || !!l,
                    R = S.readOnly || !!a,
                    k = d("LeadingAddon"),
                    _ = d("LeadingIcon"),
                    T = d("ClearButton"),
                    z = C ? d("StateIndicator") || r.createElement(N, null) : d("TrailingIcon"),
                    A = d("TrailingAddon"),
                    M = !!k,
                    D = !!A,
                    O = !!_,
                    P = !!z || !!C,
                    B = !(!E || !T || I || R),
                    L = (0, r.useCallback)(() => {
                        v.current && v.current(), x(""), b.current.focus()
                    }, [x]),
                    V = (0, r.useMemo)(() => ({
                        state: C,
                        disabled: I,
                        readOnly: R,
                        hasLeadingIcon: O,
                        hasTrailingIcon: P,
                        hasLeadingAddon: M,
                        hasTrailingAddon: D,
                        hasClearButton: B,
                        onClear: L
                    }), [C, I, R, O, P, M, D, B, L]);
                return (0, r.useEffect)(() => {
                    v.current = i
                }, [i]), r.createElement(h.Provider, {
                    value: V
                }, r.createElement("div", {
                    ref: s,
                    className: w({
                        disabled: I,
                        readOnly: R,
                        className: e
                    }),
                    ...o
                }, M && k, r.createElement("div", {
                    className: "relative inline-flex w-full"
                }, p && (0, r.cloneElement)(p, {
                    ref: y,
                    defaultValue: void 0,
                    value: E ? ? "",
                    onChange: e => {
                        g.onChange && g.onChange(e), x(e.target.value)
                    }
                }), _, B && T, z), D && A))
            });
            I.displayName = "InputGroup";
            let R = (0, o.j)(["overflow-hidden", "border-sm", "shrink-0", "h-full", "focus-visible:relative focus-visible:z-raised"], {
                    variants: {
                        asChild: {
                            false: ["flex", "items-center", "px-lg"]
                        },
                        intent: {
                            neutral: "border-outline",
                            error: "border-error",
                            alert: "border-alert",
                            success: "border-success"
                        },
                        disabled: {
                            true: ["pointer-events-none !border-outline"]
                        },
                        readOnly: {
                            true: []
                        },
                        design: {
                            text: "",
                            solid: "",
                            inline: ""
                        }
                    },
                    compoundVariants: [{
                        disabled: !1,
                        readOnly: !1,
                        design: "text",
                        class: ["bg-surface", "text-on-surface"]
                    }, {
                        disabled: !0,
                        design: "text",
                        class: ["text-on-surface/dim-3"]
                    }, {
                        disabled: !0,
                        design: ["solid", "inline"],
                        class: ["opacity-dim-3"]
                    }],
                    defaultVariants: {
                        intent: "neutral"
                    }
                }),
                k = (0, r.forwardRef)(({
                    asChild: e,
                    className: t,
                    children: n,
                    ...l
                }, a) => {
                    let {
                        state: i,
                        disabled: o,
                        readOnly: s
                    } = g(), d = "string" == typeof n, u = !(d || !e), c = d ? n : r.Children.only(n), f = u && !d ? m.g7 : "div";
                    return r.createElement(f, {
                        ref: a,
                        className: R({
                            className: t,
                            intent: i,
                            disabled: o,
                            readOnly: s,
                            asChild: u,
                            design: d ? "text" : u ? "solid" : "inline"
                        }),
                        ...o && {
                            tabIndex: -1
                        },
                        ...l
                    }, c)
                });
            k.displayName = "InputGroup.Addon";
            let _ = (0, r.forwardRef)(({
                    className: e,
                    ...t
                }, n) => {
                    let {
                        disabled: l,
                        readOnly: a
                    } = g();
                    return r.createElement("div", {
                        className: (0, o.cx)("rounded-l-lg", l || a ? "bg-on-surface/dim-5" : null)
                    }, r.createElement(k, {
                        ref: n,
                        className: (0, o.cx)(e, "mr-[-1px] !rounded-r-none rounded-l-lg"),
                        ...t
                    }))
                }),
                T = Object.assign(_, {
                    id: "LeadingAddon"
                });
            T.displayName = "InputGroup.LeadingAddon";
            let z = ({
                className: e,
                ...t
            }) => r.createElement(S, {
                className: (0, o.cx)(e, "left-lg text-body-1"),
                ...t
            });
            z.id = "LeadingIcon", z.displayName = "InputGroup.LeadingIcon";
            let A = (0, r.forwardRef)(({
                    className: e,
                    ...t
                }, n) => {
                    let {
                        disabled: l,
                        readOnly: a
                    } = g();
                    return r.createElement("div", {
                        className: (0, o.cx)("rounded-r-lg", l || a ? "bg-on-surface/dim-5" : null)
                    }, r.createElement(k, {
                        ref: n,
                        className: (0, o.cx)(e, "ml-[-1px] !rounded-l-none rounded-r-lg"),
                        ...t
                    }))
                }),
                M = Object.assign(A, {
                    id: "TrailingAddon"
                });
            M.displayName = "InputGroup.TrailingAddon";
            let D = (0, o.j)(["relative", "border-sm", "peer", "w-full", "appearance-none outline-none", "bg-surface", "text-ellipsis text-body-1 text-on-surface", "caret-neutral", "autofill:shadow-surface", "autofill:shadow-[inset_0_0_0px_1000px]", "disabled:cursor-not-allowed", "disabled:bg-on-surface/dim-5 disabled:text-on-surface/dim-3", "read-only:cursor-default", "read-only:bg-on-surface/dim-5", "focus:ring-1 focus:ring-inset", "disabled:border-outline"], {
                    variants: {
                        asChild: {
                            true: ["min-h-sz-44"],
                            false: ["h-sz-44"]
                        },
                        intent: {
                            neutral: ["border-outline", "hover:border-outline-high", "focus:ring-outline-high focus:border-outline-high"],
                            success: ["border-success", "focus:ring-success"],
                            alert: ["border-alert", "focus:ring-alert"],
                            error: ["border-error", "focus:ring-error"]
                        },
                        hasLeadingAddon: {
                            true: ["rounded-l-none"],
                            false: ["rounded-l-lg"]
                        },
                        hasTrailingAddon: {
                            true: ["rounded-r-none"],
                            false: ["rounded-r-lg"]
                        },
                        hasLeadingIcon: {
                            true: ["pl-3xl"],
                            false: ["pl-lg"]
                        },
                        hasTrailingIcon: {
                            true: ""
                        },
                        hasClearButton: {
                            true: ""
                        }
                    },
                    compoundVariants: [{
                        hasTrailingIcon: !1,
                        hasClearButton: !1,
                        class: "pr-lg"
                    }, {
                        hasTrailingIcon: !0,
                        hasClearButton: !1,
                        class: "pr-3xl"
                    }, {
                        hasTrailingIcon: !1,
                        hasClearButton: !0,
                        class: "pr-3xl"
                    }, {
                        hasTrailingIcon: !0,
                        hasClearButton: !0,
                        class: "pr-[calc(theme('spacing.3xl')*2)]"
                    }],
                    defaultVariants: {
                        intent: "neutral"
                    }
                }),
                O = (0, r.forwardRef)(({
                    className: e,
                    asChild: t = !1,
                    onValueChange: n,
                    onChange: l,
                    onKeyDown: a,
                    disabled: i,
                    readOnly: o,
                    ...s
                }, d) => {
                    let c = (0, u.H)(),
                        f = g(),
                        {
                            id: p,
                            name: h,
                            isInvalid: b,
                            isRequired: v,
                            description: w
                        } = c,
                        {
                            hasLeadingAddon: y,
                            hasTrailingAddon: E,
                            hasLeadingIcon: x,
                            hasTrailingIcon: S,
                            hasClearButton: C,
                            onClear: N
                        } = f,
                        I = t ? m.g7 : "input",
                        R = c.state || f.state,
                        k = c.disabled || f.disabled || i,
                        _ = c.readOnly || f.readOnly || o;
                    return r.createElement(I, {
                        ref: d,
                        id: p,
                        name: h,
                        className: D({
                            asChild: t,
                            className: e,
                            intent: R,
                            hasLeadingAddon: !!y,
                            hasTrailingAddon: !!E,
                            hasLeadingIcon: !!x,
                            hasTrailingIcon: !!S,
                            hasClearButton: !!C
                        }),
                        disabled: k,
                        readOnly: _,
                        required: v,
                        "aria-describedby": w,
                        "aria-invalid": b,
                        onChange: e => {
                            l && l(e), n && n(e.target.value)
                        },
                        onKeyDown: e => {
                            a && a(e), C && N && "Escape" === e.key && N()
                        },
                        ...s
                    })
                }),
                P = Object.assign(O, {
                    id: "Input"
                });
            P.displayName = "Input";
            let B = Object.assign(I, {
                LeadingAddon: T,
                TrailingAddon: M,
                LeadingIcon: z,
                TrailingIcon: C,
                StateIndicator: N,
                ClearButton: v
            });
            B.displayName = "InputGroup", T.displayName = "InputGroup.LeadingAddon", M.displayName = "InputGroup.TrailingAddon", z.displayName = "InputGroup.LeadingIcon", C.displayName = "InputGroup.TrailingIcon", N.displayName = "InputGroup.StateIndicator", v.displayName = "InputGroup.ClearButton"
        },
        10832: function(e, t, n) {
            n.d(t, {
                i: function() {
                    return ee
                }
            });
            var r = n(67294),
                l = n(87462);

            function a(e, [t, n]) {
                return Math.min(n, Math.max(t, e))
            }

            function i(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }

            function o(...e) {
                return t => e.forEach(e => {
                    var n;
                    "function" == typeof(n = e) ? n(t): null != n && (n.current = t)
                })
            }

            function s(...e) {
                return (0, r.useCallback)(o(...e), e)
            }

            function d(e, t = []) {
                let n = [],
                    l = () => {
                        let t = n.map(e => (0, r.createContext)(e));
                        return function(n) {
                            let l = (null == n ? void 0 : n[e]) || t;
                            return (0, r.useMemo)(() => ({
                                [`__scope${e}`]: { ...n,
                                    [e]: l
                                }
                            }), [n, l])
                        }
                    };
                return l.scopeName = e, [function(t, l) {
                    let a = (0, r.createContext)(l),
                        i = n.length;

                    function o(t) {
                        let {
                            scope: n,
                            children: l,
                            ...o
                        } = t, s = (null == n ? void 0 : n[e][i]) || a, d = (0, r.useMemo)(() => o, Object.values(o));
                        return (0, r.createElement)(s.Provider, {
                            value: d
                        }, l)
                    }
                    return n = [...n, l], o.displayName = t + "Provider", [o, function(n, o) {
                        let s = (null == o ? void 0 : o[e][i]) || a,
                            d = (0, r.useContext)(s);
                        if (d) return d;
                        if (void 0 !== l) return l;
                        throw Error(`\`${n}\` must be used within \`${t}\``)
                    }]
                }, function(...e) {
                    let t = e[0];
                    if (1 === e.length) return t;
                    let n = () => {
                        let n = e.map(e => ({
                            useScope: e(),
                            scopeName: e.scopeName
                        }));
                        return function(e) {
                            let l = n.reduce((t, {
                                useScope: n,
                                scopeName: r
                            }) => {
                                let l = n(e),
                                    a = l[`__scope${r}`];
                                return { ...t,
                                    ...a
                                }
                            }, {});
                            return (0, r.useMemo)(() => ({
                                [`__scope${t.scopeName}`]: l
                            }), [l])
                        }
                    };
                    return n.scopeName = t.scopeName, n
                }(l, ...t)]
            }

            function u(e) {
                let t = (0, r.useRef)(e);
                return (0, r.useEffect)(() => {
                    t.current = e
                }), (0, r.useMemo)(() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }, [])
            }
            let c = (0, r.createContext)(void 0),
                f = (null == globalThis ? void 0 : globalThis.document) ? r.useLayoutEffect : () => {};
            n(73935);
            let m = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...a
                } = e, i = r.Children.toArray(n), o = i.find(g);
                if (o) {
                    let e = o.props.children,
                        n = i.map(t => t !== o ? t : r.Children.count(e) > 1 ? r.Children.only(null) : (0, r.isValidElement)(e) ? e.props.children : null);
                    return (0, r.createElement)(p, (0, l.Z)({}, a, {
                        ref: t
                    }), (0, r.isValidElement)(e) ? (0, r.cloneElement)(e, void 0, n) : null)
                }
                return (0, r.createElement)(p, (0, l.Z)({}, a, {
                    ref: t
                }), n)
            });
            m.displayName = "Slot";
            let p = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...l
                } = e;
                return (0, r.isValidElement)(n) ? (0, r.cloneElement)(n, { ... function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let l = e[r],
                                a = t[r],
                                i = /^on[A-Z]/.test(r);
                            i ? l && a ? n[r] = (...e) => {
                                a(...e), l(...e)
                            } : l && (n[r] = l) : "style" === r ? n[r] = { ...l,
                                ...a
                            } : "className" === r && (n[r] = [l, a].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(l, n.props),
                    ref: t ? o(t, n.ref) : n.ref
                }) : r.Children.count(n) > 1 ? r.Children.only(null) : null
            });
            p.displayName = "SlotClone";
            let h = ({
                children: e
            }) => (0, r.createElement)(r.Fragment, null, e);

            function g(e) {
                return (0, r.isValidElement)(e) && e.type === h
            }
            let b = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = (0, r.forwardRef)((e, n) => {
                        let {
                            asChild: a,
                            ...i
                        } = e, o = a ? m : t;
                        return (0, r.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, r.createElement)(o, (0, l.Z)({}, i, {
                            ref: n
                        }))
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                v = ["PageUp", "PageDown"],
                w = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"],
                y = {
                    "from-left": ["Home", "PageDown", "ArrowDown", "ArrowLeft"],
                    "from-right": ["Home", "PageDown", "ArrowDown", "ArrowRight"],
                    "from-bottom": ["Home", "PageDown", "ArrowDown", "ArrowLeft"],
                    "from-top": ["Home", "PageDown", "ArrowUp", "ArrowLeft"]
                },
                E = "Slider",
                [x, S, C] = function(e) {
                    let t = e + "CollectionProvider",
                        [n, l] = d(t),
                        [a, i] = n(t, {
                            collectionRef: {
                                current: null
                            },
                            itemMap: new Map
                        }),
                        o = e => {
                            let {
                                scope: t,
                                children: n
                            } = e, l = r.useRef(null), i = r.useRef(new Map).current;
                            return r.createElement(a, {
                                scope: t,
                                itemMap: i,
                                collectionRef: l
                            }, n)
                        },
                        u = e + "CollectionSlot",
                        c = r.forwardRef((e, t) => {
                            let {
                                scope: n,
                                children: l
                            } = e, a = i(u, n), o = s(t, a.collectionRef);
                            return r.createElement(m, {
                                ref: o
                            }, l)
                        }),
                        f = e + "CollectionItemSlot",
                        p = "data-radix-collection-item",
                        h = r.forwardRef((e, t) => {
                            let {
                                scope: n,
                                children: l,
                                ...a
                            } = e, o = r.useRef(null), d = s(t, o), u = i(f, n);
                            return r.useEffect(() => (u.itemMap.set(o, {
                                ref: o,
                                ...a
                            }), () => void u.itemMap.delete(o))), r.createElement(m, {
                                [p]: "",
                                ref: d
                            }, l)
                        });
                    return [{
                        Provider: o,
                        Slot: c,
                        ItemSlot: h
                    }, function(t) {
                        let n = i(e + "CollectionConsumer", t),
                            l = r.useCallback(() => {
                                let e = n.collectionRef.current;
                                if (!e) return [];
                                let t = Array.from(e.querySelectorAll(`[${p}]`)),
                                    r = Array.from(n.itemMap.values()),
                                    l = r.sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current));
                                return l
                            }, [n.collectionRef, n.itemMap]);
                        return l
                    }, l]
                }(E),
                [N, I] = d(E, [C]),
                [R, k] = N(E),
                _ = (0, r.forwardRef)((e, t) => {
                    let {
                        name: n,
                        min: o = 0,
                        max: d = 100,
                        step: c = 1,
                        orientation: f = "horizontal",
                        disabled: m = !1,
                        minStepsBetweenThumbs: p = 0,
                        defaultValue: h = [o],
                        value: g,
                        onValueChange: b = () => {},
                        onValueCommit: y = () => {},
                        inverted: E = !1,
                        ...S
                    } = e, [C, N] = (0, r.useState)(null), I = s(t, e => N(e)), k = (0, r.useRef)(new Set), _ = (0, r.useRef)(0), T = !C || !!C.closest("form"), [z = [], D] = function({
                        prop: e,
                        defaultProp: t,
                        onChange: n = () => {}
                    }) {
                        let [l, a] = function({
                            defaultProp: e,
                            onChange: t
                        }) {
                            let n = (0, r.useState)(e),
                                [l] = n,
                                a = (0, r.useRef)(l),
                                i = u(t);
                            return (0, r.useEffect)(() => {
                                a.current !== l && (i(l), a.current = l)
                            }, [l, a, i]), n
                        }({
                            defaultProp: t,
                            onChange: n
                        }), i = void 0 !== e, o = u(n), s = (0, r.useCallback)(t => {
                            if (i) {
                                let n = "function" == typeof t ? t(e) : t;
                                n !== e && o(n)
                            } else a(t)
                        }, [i, e, a, o]);
                        return [i ? e : l, s]
                    }({
                        prop: g,
                        defaultProp: h,
                        onChange: e => {
                            var t;
                            let n = [...k.current];
                            null === (t = n[_.current]) || void 0 === t || t.focus(), b(e)
                        }
                    }), O = (0, r.useRef)(z);

                    function P(e, t, {
                        commit: n
                    } = {
                        commit: !1
                    }) {
                        let r = (String(c).split(".")[1] || "").length,
                            l = function(e, t) {
                                let n = Math.pow(10, t);
                                return Math.round(e * n) / n
                            }(Math.round((e - o) / c) * c + o, r),
                            i = a(l, [o, d]);
                        D((e = []) => {
                            let r = function(e = [], t, n) {
                                let r = [...e];
                                return r[n] = t, r.sort((e, t) => e - t)
                            }(e, i, t);
                            if (! function(e, t) {
                                    if (t > 0) {
                                        let n = e.slice(0, -1).map((t, n) => e[n + 1] - t);
                                        return Math.min(...n) >= t
                                    }
                                    return !0
                                }(r, p * c)) return e; {
                                _.current = r.indexOf(i);
                                let t = String(r) !== String(e);
                                return t && n && y(r), t ? r : e
                            }
                        })
                    }
                    return (0, r.createElement)(R, {
                        scope: e.__scopeSlider,
                        disabled: m,
                        min: o,
                        max: d,
                        valueIndexToChangeRef: _,
                        thumbs: k.current,
                        values: z,
                        orientation: f
                    }, (0, r.createElement)(x.Provider, {
                        scope: e.__scopeSlider
                    }, (0, r.createElement)(x.Slot, {
                        scope: e.__scopeSlider
                    }, (0, r.createElement)("horizontal" === f ? A : M, (0, l.Z)({
                        "aria-disabled": m,
                        "data-disabled": m ? "" : void 0
                    }, S, {
                        ref: I,
                        onPointerDown: i(S.onPointerDown, () => {
                            m || (O.current = z)
                        }),
                        min: o,
                        max: d,
                        inverted: E,
                        onSlideStart: m ? void 0 : function(e) {
                            let t = function(e, t) {
                                if (1 === e.length) return 0;
                                let n = e.map(e => Math.abs(e - t));
                                return n.indexOf(Math.min(...n))
                            }(z, e);
                            P(e, t)
                        },
                        onSlideMove: m ? void 0 : function(e) {
                            P(e, _.current)
                        },
                        onSlideEnd: m ? void 0 : function() {
                            let e = O.current[_.current],
                                t = z[_.current];
                            t !== e && y(z)
                        },
                        onHomeKeyDown: () => !m && P(o, 0, {
                            commit: !0
                        }),
                        onEndKeyDown: () => !m && P(d, z.length - 1, {
                            commit: !0
                        }),
                        onStepKeyDown: ({
                            event: e,
                            direction: t
                        }) => {
                            if (!m) {
                                let n = v.includes(e.key),
                                    r = n || e.shiftKey && w.includes(e.key),
                                    l = _.current,
                                    a = z[l];
                                P(a + c * (r ? 10 : 1) * t, l, {
                                    commit: !0
                                })
                            }
                        }
                    })))), T && z.map((e, t) => (0, r.createElement)(j, {
                        key: t,
                        name: n ? n + (z.length > 1 ? "[]" : "") : void 0,
                        value: e
                    })))
                }),
                [T, z] = N(E, {
                    startEdge: "left",
                    endEdge: "right",
                    size: "width",
                    direction: 1
                }),
                A = (0, r.forwardRef)((e, t) => {
                    let {
                        min: n,
                        max: a,
                        dir: i,
                        inverted: o,
                        onSlideStart: d,
                        onSlideMove: u,
                        onSlideEnd: f,
                        onStepKeyDown: m,
                        ...p
                    } = e, [h, g] = (0, r.useState)(null), b = s(t, e => g(e)), v = (0, r.useRef)(), w = function(e) {
                        let t = (0, r.useContext)(c);
                        return e || t || "ltr"
                    }(i), E = "ltr" === w, x = E && !o || !E && o;

                    function S(e) {
                        let t = v.current || h.getBoundingClientRect(),
                            r = [0, t.width],
                            l = G(r, x ? [n, a] : [a, n]);
                        return v.current = t, l(e - t.left)
                    }
                    return (0, r.createElement)(T, {
                        scope: e.__scopeSlider,
                        startEdge: x ? "left" : "right",
                        endEdge: x ? "right" : "left",
                        direction: x ? 1 : -1,
                        size: "width"
                    }, (0, r.createElement)(D, (0, l.Z)({
                        dir: w,
                        "data-orientation": "horizontal"
                    }, p, {
                        ref: b,
                        style: { ...p.style,
                            "--radix-slider-thumb-transform": "translateX(-50%)"
                        },
                        onSlideStart: e => {
                            let t = S(e.clientX);
                            null == d || d(t)
                        },
                        onSlideMove: e => {
                            let t = S(e.clientX);
                            null == u || u(t)
                        },
                        onSlideEnd: () => {
                            v.current = void 0, null == f || f()
                        },
                        onStepKeyDown: e => {
                            let t = y[x ? "from-left" : "from-right"].includes(e.key);
                            null == m || m({
                                event: e,
                                direction: t ? -1 : 1
                            })
                        }
                    })))
                }),
                M = (0, r.forwardRef)((e, t) => {
                    let {
                        min: n,
                        max: a,
                        inverted: i,
                        onSlideStart: o,
                        onSlideMove: d,
                        onSlideEnd: u,
                        onStepKeyDown: c,
                        ...f
                    } = e, m = (0, r.useRef)(null), p = s(t, m), h = (0, r.useRef)(), g = !i;

                    function b(e) {
                        let t = h.current || m.current.getBoundingClientRect(),
                            r = [0, t.height],
                            l = G(r, g ? [a, n] : [n, a]);
                        return h.current = t, l(e - t.top)
                    }
                    return (0, r.createElement)(T, {
                        scope: e.__scopeSlider,
                        startEdge: g ? "bottom" : "top",
                        endEdge: g ? "top" : "bottom",
                        size: "height",
                        direction: g ? 1 : -1
                    }, (0, r.createElement)(D, (0, l.Z)({
                        "data-orientation": "vertical"
                    }, f, {
                        ref: p,
                        style: { ...f.style,
                            "--radix-slider-thumb-transform": "translateY(50%)"
                        },
                        onSlideStart: e => {
                            let t = b(e.clientY);
                            null == o || o(t)
                        },
                        onSlideMove: e => {
                            let t = b(e.clientY);
                            null == d || d(t)
                        },
                        onSlideEnd: () => {
                            h.current = void 0, null == u || u()
                        },
                        onStepKeyDown: e => {
                            let t = y[g ? "from-bottom" : "from-top"].includes(e.key);
                            null == c || c({
                                event: e,
                                direction: t ? -1 : 1
                            })
                        }
                    })))
                }),
                D = (0, r.forwardRef)((e, t) => {
                    let {
                        __scopeSlider: n,
                        onSlideStart: a,
                        onSlideMove: o,
                        onSlideEnd: s,
                        onHomeKeyDown: d,
                        onEndKeyDown: u,
                        onStepKeyDown: c,
                        ...f
                    } = e, m = k(E, n);
                    return (0, r.createElement)(b.span, (0, l.Z)({}, f, {
                        ref: t,
                        onKeyDown: i(e.onKeyDown, e => {
                            "Home" === e.key ? (d(e), e.preventDefault()) : "End" === e.key ? (u(e), e.preventDefault()) : v.concat(w).includes(e.key) && (c(e), e.preventDefault())
                        }),
                        onPointerDown: i(e.onPointerDown, e => {
                            let t = e.target;
                            t.setPointerCapture(e.pointerId), e.preventDefault(), m.thumbs.has(t) ? t.focus() : a(e)
                        }),
                        onPointerMove: i(e.onPointerMove, e => {
                            let t = e.target;
                            t.hasPointerCapture(e.pointerId) && o(e)
                        }),
                        onPointerUp: i(e.onPointerUp, e => {
                            let t = e.target;
                            t.hasPointerCapture(e.pointerId) && (t.releasePointerCapture(e.pointerId), s(e))
                        })
                    }))
                }),
                O = (0, r.forwardRef)((e, t) => {
                    let {
                        __scopeSlider: n,
                        ...a
                    } = e, i = k("SliderTrack", n);
                    return (0, r.createElement)(b.span, (0, l.Z)({
                        "data-disabled": i.disabled ? "" : void 0,
                        "data-orientation": i.orientation
                    }, a, {
                        ref: t
                    }))
                }),
                P = "SliderRange",
                B = (0, r.forwardRef)((e, t) => {
                    let {
                        __scopeSlider: n,
                        ...a
                    } = e, i = k(P, n), o = z(P, n), d = (0, r.useRef)(null), u = s(t, d), c = i.values.length, f = i.values.map(e => H(e, i.min, i.max));
                    return (0, r.createElement)(b.span, (0, l.Z)({
                        "data-orientation": i.orientation,
                        "data-disabled": i.disabled ? "" : void 0
                    }, a, {
                        ref: u,
                        style: { ...e.style,
                            [o.startEdge]: (c > 1 ? Math.min(...f) : 0) + "%",
                            [o.endEdge]: 100 - Math.max(...f) + "%"
                        }
                    }))
                }),
                L = "SliderThumb",
                V = (0, r.forwardRef)((e, t) => {
                    let n = S(e.__scopeSlider),
                        [a, i] = (0, r.useState)(null),
                        o = s(t, e => i(e)),
                        d = (0, r.useMemo)(() => a ? n().findIndex(e => e.ref.current === a) : -1, [n, a]);
                    return (0, r.createElement)(Z, (0, l.Z)({}, e, {
                        ref: o,
                        index: d
                    }))
                }),
                Z = (0, r.forwardRef)((e, t) => {
                    var n;
                    let {
                        __scopeSlider: a,
                        index: o,
                        ...d
                    } = e, u = k(L, a), c = z(L, a), [m, p] = (0, r.useState)(null), h = s(t, e => p(e)), g = function(e) {
                        let [t, n] = (0, r.useState)(void 0);
                        return f(() => {
                            if (e) {
                                n({
                                    width: e.offsetWidth,
                                    height: e.offsetHeight
                                });
                                let t = new ResizeObserver(t => {
                                    let r, l;
                                    if (!Array.isArray(t) || !t.length) return;
                                    let a = t[0];
                                    if ("borderBoxSize" in a) {
                                        let e = a.borderBoxSize,
                                            t = Array.isArray(e) ? e[0] : e;
                                        r = t.inlineSize, l = t.blockSize
                                    } else r = e.offsetWidth, l = e.offsetHeight;
                                    n({
                                        width: r,
                                        height: l
                                    })
                                });
                                return t.observe(e, {
                                    box: "border-box"
                                }), () => t.unobserve(e)
                            }
                            n(void 0)
                        }, [e]), t
                    }(m), v = u.values[o], w = void 0 === v ? 0 : H(v, u.min, u.max), y = (n = u.values.length) > 2 ? `Value ${o+1} of ${n}` : 2 === n ? ["Minimum", "Maximum"][o] : void 0, E = null == g ? void 0 : g[c.size], S = E ? function(e, t, n) {
                        let r = e / 2,
                            l = G([0, 50], [0, r]);
                        return (r - l(t) * n) * n
                    }(E, w, c.direction) : 0;
                    return (0, r.useEffect)(() => {
                        if (m) return u.thumbs.add(m), () => {
                            u.thumbs.delete(m)
                        }
                    }, [m, u.thumbs]), (0, r.createElement)("span", {
                        style: {
                            transform: "var(--radix-slider-thumb-transform)",
                            position: "absolute",
                            [c.startEdge]: `calc(${w}% + ${S}px)`
                        }
                    }, (0, r.createElement)(x.ItemSlot, {
                        scope: e.__scopeSlider
                    }, (0, r.createElement)(b.span, (0, l.Z)({
                        role: "slider",
                        "aria-label": e["aria-label"] || y,
                        "aria-valuemin": u.min,
                        "aria-valuenow": v,
                        "aria-valuemax": u.max,
                        "aria-orientation": u.orientation,
                        "data-orientation": u.orientation,
                        "data-disabled": u.disabled ? "" : void 0,
                        tabIndex: u.disabled ? void 0 : 0
                    }, d, {
                        ref: h,
                        style: void 0 === v ? {
                            display: "none"
                        } : e.style,
                        onFocus: i(e.onFocus, () => {
                            u.valueIndexToChangeRef.current = o
                        })
                    }))))
                }),
                j = e => {
                    let {
                        value: t,
                        ...n
                    } = e, a = (0, r.useRef)(null), i = function(e) {
                        let t = (0, r.useRef)({
                            value: e,
                            previous: e
                        });
                        return (0, r.useMemo)(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e])
                    }(t);
                    return (0, r.useEffect)(() => {
                        let e = a.current,
                            n = window.HTMLInputElement.prototype,
                            r = Object.getOwnPropertyDescriptor(n, "value"),
                            l = r.set;
                        if (i !== t && l) {
                            let n = new Event("input", {
                                bubbles: !0
                            });
                            l.call(e, t), e.dispatchEvent(n)
                        }
                    }, [i, t]), (0, r.createElement)("input", (0, l.Z)({
                        style: {
                            display: "none"
                        }
                    }, n, {
                        ref: a,
                        defaultValue: t
                    }))
                };

            function H(e, t, n) {
                return a(100 / (n - t) * (e - t), [0, 100])
            }

            function G(e, t) {
                return n => {
                    if (e[0] === e[1] || t[0] === t[1]) return t[0];
                    let r = (t[1] - t[0]) / (e[1] - e[0]);
                    return t[0] + r * (n - e[0])
                }
            }
            var $ = n(29107);
            let K = (0, $.j)(["flex relative h-sz-24 items-center", "touch-none select-none", "spark-disabled:cursor-not-allowed spark-disabled:opacity-dim-3"]),
                q = (0, r.createContext)({}),
                F = () => (0, r.useContext)(q),
                Y = (0, r.forwardRef)(({
                    asChild: e = !1,
                    intent: t = "basic",
                    shape: n = "square",
                    children: l,
                    className: a,
                    ...i
                }, o) => r.createElement(q.Provider, {
                    value: {
                        intent: t,
                        shape: n
                    }
                }, r.createElement(_, {
                    ref: o,
                    "data-spark-component": "slider",
                    asChild: e,
                    className: K({
                        className: a
                    }),
                    dir: "ltr",
                    orientation: "horizontal",
                    inverted: !1,
                    minStepsBetweenThumbs: 0,
                    ...i
                }, l)));
            Y.displayName = "Slider";
            let U = (0, $.j)(["block h-sz-24 w-sz-24 rounded-full cursor-pointer", "hover:ring-4 u-shadow-border-transition", "outline-none", "focus-visible:u-ring", "spark-disabled:hover:ring-0 spark-disabled:cursor-not-allowed"], {
                    variants: {
                        intent: {
                            main: ["bg-main hover:ring-main-container"],
                            support: ["bg-support hover:ring-support-container"],
                            accent: ["bg-accent hover:ring-accent-container"],
                            basic: ["bg-basic hover:ring-basic-container"],
                            info: ["bg-info hover:ring-info-container"],
                            neutral: ["bg-neutral hover:ring-neutral-container"],
                            success: ["bg-success hover:ring-success-container"],
                            alert: ["bg-alert hover:ring-alert-container"],
                            error: ["bg-error hover:ring-error-container"]
                        }
                    },
                    defaultVariants: {
                        intent: "basic"
                    }
                }),
                W = (0, r.forwardRef)(({
                    asChild: e = !1,
                    className: t,
                    ...n
                }, l) => {
                    let {
                        intent: a
                    } = F();
                    return r.createElement(V, {
                        ref: l,
                        asChild: e,
                        className: U({
                            intent: a,
                            className: t
                        }),
                        ...n
                    })
                });
            W.displayName = "Slider.Thumb";
            let X = (0, $.j)(["relative grow h-sz-4 bg-on-background/dim-4"], {
                    variants: {
                        shape: {
                            rounded: "rounded-sm",
                            square: "rounded-none"
                        }
                    },
                    defaultVariants: {
                        shape: "square"
                    }
                }),
                J = (0, $.j)(["absolute h-full"], {
                    variants: {
                        intent: {
                            main: ["bg-main"],
                            support: ["bg-support"],
                            accent: ["bg-accent"],
                            basic: ["bg-basic"],
                            info: ["bg-info"],
                            neutral: ["bg-neutral"],
                            success: ["bg-success"],
                            alert: ["bg-alert"],
                            error: ["bg-error"]
                        },
                        shape: {
                            rounded: "rounded-sm",
                            square: "rounded-none"
                        }
                    },
                    defaultVariants: {
                        intent: "basic",
                        shape: "square"
                    }
                }),
                Q = (0, r.forwardRef)(({
                    asChild: e = !1,
                    className: t,
                    ...n
                }, l) => {
                    let {
                        intent: a,
                        shape: i
                    } = F();
                    return r.createElement(O, {
                        ref: l,
                        asChild: e,
                        className: X({
                            shape: i
                        }),
                        ...n
                    }, r.createElement(B, {
                        className: J({
                            intent: a,
                            shape: i,
                            className: t
                        })
                    }))
                });
            Q.displayName = "Slider.Track";
            let ee = Object.assign(Y, {
                Thumb: W,
                Track: Q
            });
            ee.displayName = "Slider", W.displayName = "Slider.Thumb", Q.displayName = "Slider.Track"
        },
        76e3: function(e, t, n) {
            n.d(t, {
                $: function() {
                    return s
                }
            });
            var r = n(67294),
                l = n(43574),
                a = n(74934),
                i = n(29107);
            let o = (0, i.j)(["inline-block", "border-solid", "rounded-full", "border-md", "animate-spin"], {
                    variants: {
                        size: {
                            current: ["u-current-font-size"],
                            sm: ["w-sz-20", "h-sz-20"],
                            md: ["w-sz-28", "h-sz-28"],
                            full: ["w-full", "h-full"]
                        },
                        intent: (0, a.TY)({
                            current: ["border-current"],
                            main: ["border-main"],
                            support: ["border-support"],
                            accent: ["border-accent"],
                            basic: ["border-basic"],
                            success: ["border-success"],
                            alert: ["border-alert"],
                            error: ["border-error"],
                            info: ["border-info"],
                            neutral: ["border-neutral"]
                        }),
                        isBackgroundVisible: {
                            true: ["border-b-neutral-container", "border-l-neutral-container"],
                            false: ["border-b-transparent", "border-l-transparent"]
                        }
                    },
                    defaultVariants: {
                        intent: "current",
                        size: "current",
                        isBackgroundVisible: !1
                    }
                }),
                s = (0, r.forwardRef)(({
                    className: e,
                    size: t = "current",
                    intent: n = "current",
                    label: a,
                    isBackgroundVisible: i,
                    ...s
                }, d) => r.createElement("div", {
                    role: "status",
                    "data-spark-component": "spinner",
                    ref: d,
                    className: o({
                        className: e,
                        size: t,
                        intent: n,
                        isBackgroundVisible: i
                    }),
                    ...s
                }, a && r.createElement(l.T, null, a)))
        }
    }
]);