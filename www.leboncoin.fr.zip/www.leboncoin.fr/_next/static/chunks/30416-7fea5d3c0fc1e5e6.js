! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "bc913a24-c154-49d9-9a6d-2e18a09c8cb8", e._sentryDebugIdIdentifier = "sentry-dbid-bc913a24-c154-49d9-9a6d-2e18a09c8cb8")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
}, (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [30416], {
        61049: function(e, n, t) {
            "use strict";
            t.d(n, {
                Z9: function() {
                    return o
                }
            });
            var i = t(44682),
                r = (0, i.kr)({
                    isOpen: !1,
                    submenus: []
                });

            function o(e) {
                return (0, i.Sz)(r, e)
            }
            n.ZP = r
        },
        92405: function(e, n, t) {
            "use strict";
            t.d(n, {
                Ac: function() {
                    return c
                },
                Tz: function() {
                    return u
                }
            });
            var i = t(72253),
                r = t(14932),
                o = t(85893),
                a = t(19156),
                s = t(29107),
                l = function(e) {
                    return e ? "(".concat(e, " ").concat(1 === Number(e) ? "notification" : "notifications", ")") : void 0
                },
                c = function(e, n) {
                    var t = e;
                    return n && (t += " ".concat(l(n))), t
                },
                u = function(e) {
                    var n = e.className,
                        t = e.children,
                        c = e.size,
                        u = e.count,
                        d = {
                            size: void 0 === c ? "sm" : c,
                            count: u,
                            className: (0, s.cx)(n, !u && "hidden", t && "absolute top-md"),
                            "aria-label": l(u)
                        };
                    return (0, o.jsx)(a.C, (0, r._)((0, i._)({
                        intent: "main"
                    }, d), {
                        children: t
                    }))
                }
        },
        33358: function(e, n, t) {
            "use strict";
            t.r(n), t.d(n, {
                NotificationDot: function() {
                    return r
                }
            });
            var i = t(85893),
                r = function() {
                    return (0, i.jsx)("div", {
                        role: "status",
                        "data-notificationsdot": !0,
                        "aria-label": "Vous avez des notifications",
                        className: "absolute -right-[1rem] -top-[0.3rem] h-md w-md rounded-full bg-main"
                    })
                }
        },
        30416: function(e, n, t) {
            "use strict";
            t.d(n, {
                h: function() {
                    return eg
                }
            });
            var i = t(85893),
                r = t(72253),
                o = t(14932),
                a = t(47702),
                s = t(25675),
                l = t.n(s),
                c = t(16678),
                u = t(16816),
                d = t(19181),
                f = t(16928),
                h = (0, d.default)(u.h.Link).withConfig({
                    componentId: "sc-19af91da-0"
                })({
                    display: "flex",
                    height: "6rem",
                    width: "14rem",
                    "> img": {
                        height: "inherit"
                    }
                }, c.bK),
                m = t(24043),
                p = t(67294),
                v = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                        n = (0, m._)((0, p.useState)(e), 2),
                        t = n[0],
                        i = n[1],
                        r = (0, p.useCallback)(function(e) {
                            i(null != e ? e : !t)
                        }, [t]);
                    return [t, r]
                },
                b = t(33487),
                g = t(5152),
                x = t.n(g),
                w = t(61148),
                j = t(61049),
                _ = x()(function() {
                    return Promise.resolve().then(t.bind(t, 33358)).then(function(e) {
                        return e.NotificationDot
                    })
                }, {
                    loadableGenerated: {
                        webpack: function() {
                            return [33358]
                        }
                    },
                    ssr: !1
                }),
                k = (0, d.default)("button").withConfig({
                    componentId: "sc-fce864e9-0"
                })(function(e) {
                    var n = e.theme;
                    return {
                        width: "3rem",
                        padding: "".concat(n.space.small, " 0"),
                        borderRadius: n.radii["x-small"],
                        position: "relative"
                    }
                }),
                y = t(82729),
                C = t(29107),
                I = t(46886),
                N = t(248),
                S = t(84310),
                B = t(82876),
                z = t(57203);

            function O() {
                var e = (0, y._)(["\n  from { visibility: visible; }\n  to { visibility: hidden; }\n"]);
                return O = function() {
                    return e
                }, e
            }

            function Z() {
                var e = (0, y._)(["\n    animation: ", " ", "ms forwards;\n  "]);
                return Z = function() {
                    return e
                }, e
            }

            function L() {
                var e = (0, y._)(["\n  ", "\n  ", "\n"]);
                return L = function() {
                    return e
                }, e
            }
            var H = (0, d.default)("div").withConfig({
                    componentId: "sc-38256f1b-0"
                })({
                    position: "absolute",
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0,
                    pointerEvents: "none",
                    overflow: "hidden",
                    "*": {
                        pointerEvents: "auto"
                    }
                }),
                D = (0, d.keyframes)(O()),
                M = function(e) {
                    return e.isHidden && (0, d.css)(Z(), D, 220)
                },
                R = (0, d.default)("div").withConfig({
                    componentId: "sc-38256f1b-1"
                })(L(), function(e) {
                    var n = e.opened,
                        t = e.fullHeight,
                        i = e.theme;
                    return "\n    position: ".concat(t ? "fixed" : "absolute", ";\n    top: 0;\n    bottom: 0;\n    overflow: auto;\n    background-color: ").concat(i.colors.white, ";\n    box-shadow: ").concat(i.shadows.normal, ";\n    width: 100%;\n    transition: right ").concat(.22, "s;\n    right: ").concat(n ? 0 : "calc(100% + 5px)", ";\n  ")
                }, M),
                E = (0, d.default)("div").withConfig({
                    componentId: "sc-38256f1b-2"
                })({
                    display: "flex",
                    flexDirection: "column",
                    height: "100%"
                }),
                T = (0, d.default)("button").withConfig({
                    componentId: "sc-38256f1b-3"
                })(function(e) {
                    var n = e.theme;
                    return {
                        position: "absolute",
                        left: 0,
                        top: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        border: "none",
                        cursor: "pointer",
                        borderRadius: "100%",
                        padding: n.space.small,
                        margin: n.space.small
                    }
                }),
                J = function() {
                    var e = (0, j.Z9)(function(e) {
                        return e.closeOpenedSubmenu
                    });
                    return (0, j.Z9)(function(e) {
                        var n, t, i = e.submenus,
                            r = e.areSubmenusOpened;
                        return (r.embedded || r.fullHeight) && (n = i[i.length - 1], t = i[i.length - 2]), (null == n ? void 0 : n.opened) ? n.withBackButton : null == t ? void 0 : t.withBackButton
                    }) ? (0, i.jsx)(T, {
                        onClick: function() {
                            return e()
                        },
                        title: "Retour",
                        children: (0, i.jsx)(w.ZP, {
                            color: "grey",
                            colorHover: "greyDark",
                            children: (0, i.jsx)(S.Z, {})
                        })
                    }) : null
                },
                P = function() {
                    var e = (0, j.Z9)(function(e) {
                        return e.submenus
                    });
                    return (0, i.jsx)(H, {
                        children: function() {
                            for (var n = [], t = 0; t < e.length + 1; t++) {
                                var a = e[t],
                                    s = e[t + 1],
                                    l = (null == a ? void 0 : a.ariaLabel) && "burger-submenu-".concat(t);
                                n.push((0, i.jsx)(R, (0, o._)((0, r._)({
                                    opened: null == a ? void 0 : a.opened,
                                    isHidden: t < e.length - 1 && (null == s ? void 0 : s.opened)
                                }, a ? {
                                    fullHeight: a.fullHeight,
                                    role: "dialog",
                                    "aria-modal": !0,
                                    "aria-labelledby": l
                                } : {
                                    "data-test-id": "preloaded-submenu"
                                }), {
                                    children: a && (0, i.jsxs)(E, {
                                        children: [l && (0, i.jsx)("p", {
                                            id: l,
                                            style: {
                                                display: "none"
                                            },
                                            children: a.ariaLabel
                                        }), a.children]
                                    })
                                }), t))
                            }
                            return n
                        }()
                    })
                },
                W = function(e) {
                    var n = (0, m._)((0, z.Z)([]), 2),
                        t = n[0],
                        i = n[1],
                        s = (0, m._)((0, p.useState)({
                            embedded: !1,
                            fullHeight: !1
                        }), 2),
                        l = s[0],
                        c = s[1],
                        u = function(e) {
                            i(e), c({
                                embedded: e.some(function(e) {
                                    return e.opened && !e.fullHeight
                                }),
                                fullHeight: e.some(function(e) {
                                    return e.opened && e.fullHeight
                                })
                            })
                        };
                    return (0, B.lR)(function() {
                        e || u([])
                    }, [e]), {
                        submenus: t(),
                        openSubmenu: function(e) {
                            var n = e.withBackButton,
                                i = (0, a._)(e, ["withBackButton"]),
                                o = (0, r._)({
                                    opened: !0,
                                    withBackButton: void 0 === n || n
                                }, i);
                            u((0, N._)(t()).concat([o]))
                        },
                        closeOpenedSubmenu: function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                                n = t();
                            if (e) {
                                u(n.map(function(e) {
                                    return (0, o._)((0, r._)({}, e), {
                                        opened: !1
                                    })
                                })), setTimeout(function() {
                                    return u([])
                                }, 220);
                                return
                            }
                            var i = (0, o._)((0, r._)({}, n[n.length - 1]), {
                                    opened: !1
                                }),
                                a = n.slice(0, -1);
                            u((0, N._)(a).concat([i])), setTimeout(function() {
                                return u(a)
                            }, 220)
                        },
                        areSubmenusOpened: l
                    }
                },
                F = t(63761),
                A = t.n(F);

            function G() {
                var e = (0, y._)(["\n  ", "\n"]);
                return G = function() {
                    return e
                }, e
            }
            var K = (0, d.default)(I.OX).withConfig({
                    componentId: "sc-54207d57-0"
                })(G(), M),
                q = function(e) {
                    var n = e.className,
                        t = e.isHidden,
                        r = e.children;
                    return (0, i.jsx)("div", {
                        className: (0, C.cx)(n, t && A().isHidden, "absolute inset-none flex flex-col overflow-auto"),
                        children: r
                    })
                },
                V = t(34640),
                Q = t(49477),
                X = (0, p.forwardRef)(function(e, n) {
                    var t = e.ariaLabel,
                        o = void 0 === t ? "Menu principal" : t,
                        a = e.children,
                        s = (0, m._)(v(), 2),
                        l = s[0],
                        c = s[1],
                        u = W(l),
                        d = (0, r._)({
                            ariaLabel: o,
                            isOpen: l,
                            toggleBurgerMenu: c
                        }, u);
                    return (0, p.useImperativeHandle)(n, function() {
                        return d
                    }), (0, i.jsx)(j.ZP.Provider, {
                        value: d,
                        children: (0, i.jsx)("nav", {
                            role: "navigation",
                            "aria-label": o,
                            children: a
                        })
                    })
                }),
                Y = (0, C.j)("relative", {
                    variants: {
                        size: {
                            sm: "h-[1.6rem]",
                            md: "h-[2.4rem]",
                            lg: "h-[4.2rem]"
                        }
                    }
                }),
                U = t(33578),
                $ = (0, C.j)("overflow-hidden leading-none", {
                    variants: {
                        size: {
                            md: "h-[2.4rem] w-[2.4rem]",
                            lg: "h-[4.2rem] w-[4.2rem]"
                        },
                        shape: {
                            round: "rounded-full",
                            square: "rounded-xs"
                        }
                    }
                }),
                ee = t(24292),
                en = (0, d.default)("header").withConfig({
                    componentId: "sc-634784e8-0"
                })(function(e) {
                    var n = e.sticky,
                        t = e.isSticked,
                        i = e.withStroke,
                        a = e.withOverlay,
                        s = e.theme;
                    return (0, r._)((0, o._)((0, r._)({
                        position: "relative",
                        zIndex: s.zIndices.sticky,
                        borderBottom: "0px solid ".concat(t ? "transparent" : s.colors.greyLight),
                        visibility: "visible",
                        transition: "border-bottom-color 220ms"
                    }, i && {
                        borderBottomWidth: s.borderWidths["x-small"]
                    }, n && {
                        position: "sticky",
                        top: 0
                    }), {
                        "::after": {
                            content: '""',
                            position: "fixed",
                            zIndex: s.zIndices.hide,
                            top: 0,
                            right: 0,
                            bottom: 0,
                            left: 0,
                            pointerEvents: "none",
                            userSelect: "none",
                            backgroundColor: s.colors.opacityBlack,
                            opacity: 0,
                            transition: "opacity 220ms"
                        }
                    }), a && {
                        zIndex: s.zIndices.overlay,
                        "&::after": {
                            pointerEvents: "all",
                            cursor: "pointer",
                            opacity: 1
                        }
                    })
                }),
                et = (0, d.default)("div").withConfig({
                    componentId: "sc-634784e8-1"
                })(function(e) {
                    var n = e.theme,
                        t = e.isSticked;
                    return (0, r._)({
                        pointerEvents: "none",
                        position: "absolute",
                        top: "-1px",
                        right: 0,
                        bottom: "-".concat(n.space.small),
                        left: 0,
                        overflow: "hidden",
                        "::before, ::after": {
                            content: '""',
                            position: "absolute",
                            top: 0,
                            right: 0,
                            bottom: n.space.small,
                            left: 0
                        },
                        ":after": {
                            background: "rgb(var(--colors-surface))"
                        }
                    }, t && {
                        "::before": {
                            boxShadow: n.shadows.normal,
                            transition: "box-shadow 220ms"
                        }
                    })
                }),
                ei = (0, d.default)("nav").withConfig({
                    componentId: "sc-634784e8-2"
                })(function(e) {
                    var n = e.theme;
                    return {
                        maxWidth: n.pageWidth.max,
                        margin: "0 auto",
                        padding: "0 ".concat(n.space.medium),
                        display: "flex",
                        columnGap: n.space.small,
                        justifyContent: "space-between",
                        alignItems: "center",
                        flexWrap: "wrap",
                        position: "relative"
                    }
                }, (0, c.qC)(c.bK, c.Dh, c.GQ, c.eC, c.Cg)),
                er = (0, d.default)("div").withConfig({
                    componentId: "sc-634784e8-3"
                })({
                    height: "1px",
                    marginBottom: "-1px",
                    visibility: "hidden"
                }),
                eo = function(e) {
                    var n = (0, m._)((0, p.useState)(!1), 2),
                        t = n[0],
                        r = n[1];
                    return {
                        isSticked: t,
                        scrollTracker: (0, i.jsx)(ea, {
                            onChangeIsSticked: function(n) {
                                r(n), null == e || e(n)
                            }
                        })
                    }
                },
                ea = function(e) {
                    var n = e.onChangeIsSticked,
                        t = (0, p.useRef)(null);
                    return (0, p.useEffect)(function() {
                        if ("undefined" != typeof IntersectionObserver) {
                            var e = new IntersectionObserver(function(e) {
                                return n(!(0, m._)(e, 1)[0].isIntersecting)
                            }, {
                                rootMargin: "-1px"
                            });
                            return e.observe(t.current),
                                function() {
                                    return e.disconnect()
                                }
                        }
                    }, []), (0, i.jsx)(er, {
                        ref: t
                    })
                },
                es = (0, p.forwardRef)(function(e, n) {
                    var t = e.children,
                        s = e.sticky,
                        l = e.withStroke,
                        c = e.withOverlay,
                        u = e.onChangeIsSticked,
                        d = (0, a._)(e, ["children", "sticky", "withStroke", "withOverlay", "onChangeIsSticked"]),
                        f = eo(u),
                        h = f.isSticked,
                        m = f.scrollTracker;
                    return (0, i.jsxs)(i.Fragment, {
                        children: [m, (0, i.jsxs)(en, {
                            role: "banner",
                            sticky: void 0 === s || s,
                            withStroke: void 0 === l || l,
                            withOverlay: void 0 !== c && c,
                            isSticked: h,
                            ref: n,
                            children: [(0, i.jsx)(et, {
                                isSticked: h
                            }), (0, i.jsx)(ei, (0, o._)((0, r._)({
                                className: "bg-surface"
                            }, (0, ee.e)(d)), {
                                children: t
                            }))]
                        })]
                    })
                }),
                el = t(63006),
                ec = (0, C.j)(["group relative flex items-center justify-center self-stretch pl-md pr-md focus-visible:u-ring-inset"], {
                    variants: {
                        orientation: {
                            horizontal: ["flex-row gap-md"],
                            vertical: ["flex-col gap-sm"]
                        }
                    },
                    defaultVariants: {
                        orientation: "horizontal"
                    }
                }),
                eu = function(e) {
                    var n = e.enabled,
                        t = e.renderSubmenu,
                        r = e.children;
                    return n && t ? (0, i.jsxs)(el.J, {
                        children: [(0, i.jsx)(el.J.Trigger, {
                            asChild: !0,
                            children: r
                        }), (0, i.jsx)(el.J.Content, {
                            align: "end",
                            className: (0, C.cx)("rounded-t-none", "grid overflow-auto", "max-h-[calc(100vh-110px)] min-w-[26rem]"),
                            sideOffset: 0,
                            children: t()
                        })]
                    }) : (0, i.jsx)(i.Fragment, {
                        children: r
                    })
                },
                ed = function(e) {
                    var n = e.isOpen,
                        t = e.onClose,
                        r = e.children;
                    return (0, i.jsxs)(el.J, {
                        open: n,
                        "aria-label": "D\xe9placement des liens de menu",
                        children: [(0, i.jsx)(el.J.Trigger, {
                            asChild: !0,
                            children: r
                        }), (0, i.jsxs)(el.J.Content, {
                            align: "end",
                            children: [(0, i.jsx)(el.J.CloseButton, {
                                "aria-label": "Fermer",
                                onClick: t
                            }), (0, i.jsx)("p", {
                                className: "text-headline-2",
                                children: "Retrouvez tous vos outils ici"
                            }), (0, i.jsx)("p", {
                                className: "text-body-1",
                                children: "On nettoie votre interface pour vous simplifier la vie"
                            }), (0, i.jsx)(el.J.Arrow, {})]
                        })]
                    })
                },
                ef = function(e) {
                    var n = e.isActive;
                    return (0, i.jsx)("div", {
                        className: (0, C.cx)("absolute bottom-none block h-[0.3rem] bg-main", "w-none opacity-0 transition-all duration-300 ease-out", "group-hover:w-full group-hover:opacity-none", {
                            "!w-full": n,
                            "!opacity-none": n
                        })
                    })
                },
                eh = t(92405),
                em = t(33358),
                ep = (0, d.default)("a").withConfig({
                    componentId: "sc-1a188230-0"
                })(function(e) {
                    var n = e.theme;
                    return {
                        display: "flex",
                        alignItems: "center",
                        height: "4.4rem",
                        textDecoration: "underline",
                        fontWeight: n.fontWeights.semibold,
                        borderRadius: n.radii.small,
                        padding: "0 ".concat(n.space.small),
                        "&:focus, &:hover": {
                            textDecoration: "none"
                        }
                    }
                }, c.bK),
                ev = (0, d.default)("nav").withConfig({
                    componentId: "sc-dbd57d2e-0"
                })(function(e) {
                    var n = e.theme;
                    return {
                        position: "fixed",
                        top: 0,
                        left: 0,
                        right: 0,
                        height: 0,
                        opacity: 0,
                        maxWidth: n.pageWidth.max,
                        backgroundColor: n.colors.white,
                        boxShadow: n.shadows.normal,
                        borderBottomLeftRadius: n.radii.small,
                        borderBottomRightRadius: n.radii.small,
                        padding: n.space["x-small"],
                        zIndex: n.zIndices.hide,
                        margin: "0 auto",
                        "&:focus-within": {
                            zIndex: n.zIndices.skipLink,
                            width: "100%",
                            height: "auto",
                            opacity: 1
                        }
                    }
                }),
                eb = (0, d.default)("ul").withConfig({
                    componentId: "sc-dbd57d2e-1"
                })(function(e) {
                    var n = e.theme;
                    return {
                        display: "flex",
                        padding: "".concat(n.space["x-small"], " ").concat(n.space.small),
                        gap: n.space.medium
                    }
                }),
                eg = function(e) {
                    var n = e.children;
                    return (0, i.jsx)(i.Fragment, {
                        children: n
                    })
                };
            eg.BrandLogo = function(e) {
                var n = e.linkTitle,
                    t = e.title,
                    s = e.to,
                    c = (0, a._)(e, ["linkTitle", "title", "to"]);
                return (0, i.jsx)(h, (0, o._)((0, r._)({
                    to: void 0 === s ? "home" : s,
                    title: void 0 === n ? "Retour \xe0 la page d’accueil" : n,
                    className: "focus-visible:u-ring-inset"
                }, c), {
                    children: (0, i.jsx)(l(), {
                        src: "/logos/".concat(f.R.name, ".svg"),
                        width: "140",
                        height: "60",
                        alt: void 0 === t ? "Logo" : t
                    })
                }))
            }, eg.BurgerMenu = X, eg.BurgerMenuButton = function(e) {
                var n = e.hasNotificationDot,
                    t = e.onClick,
                    r = (0, j.Z9)(function(e) {
                        return e.isOpen
                    }),
                    o = (0, j.Z9)(function(e) {
                        return e.toggleBurgerMenu
                    });
                return (0, i.jsxs)(k, {
                    onClick: function() {
                        null == t || t(), o()
                    },
                    "aria-expanded": r ? "true" : "false",
                    children: [(0, i.jsx)(w.ZP, {
                        display: "block",
                        size: "fluid",
                        children: (0, i.jsx)(b.Z, {
                            fill: "#ff6e14",
                            title: "".concat(r ? "Fermer" : "Ouvrir", " le menu principal")
                        })
                    }), void 0 !== n && n && (0, i.jsx)(_, {})]
                })
            }, eg.BurgerMenuDrawer = function(e) {
                var n = e.children,
                    t = (0, j.Z9)(function(e) {
                        return e.ariaLabel
                    }),
                    r = (0, j.Z9)(function(e) {
                        return e.isOpen
                    }),
                    o = (0, j.Z9)(function(e) {
                        return e.toggleBurgerMenu
                    });
                return (0, i.jsxs)(I.ZP, {
                    placement: "left",
                    size: "medium",
                    isOpen: r,
                    onClose: function() {
                        return o(!1)
                    },
                    ariaLabelledby: "burger-menu-drawer",
                    children: [(0, i.jsx)("p", {
                        id: "burger-menu-drawer",
                        className: "hidden",
                        children: t
                    }), n, (0, i.jsx)(J, {}), (0, i.jsx)(I.cC, {})]
                })
            }, eg.BurgerMenuDrawerHeader = function(e) {
                var n = (0, j.Z9)(function(e) {
                    return e.areSubmenusOpened.fullHeight
                });
                return (0, i.jsx)(K, (0, o._)((0, r._)({
                    "data-test-id": "main-header"
                }, e), {
                    isHidden: n
                }))
            }, eg.BurgerMenuDrawerBody = function(e) {
                var n = e.children,
                    t = (0, j.Z9)(function(e) {
                        return e.areSubmenusOpened.embedded || e.areSubmenusOpened.fullHeight
                    });
                return (0, i.jsxs)("div", {
                    className: "relative flex flex-1 bg-surface",
                    children: [(0, i.jsx)(q, {
                        isHidden: t,
                        "data-test-id": "main-menu",
                        children: n
                    }), (0, i.jsx)(P, {})]
                })
            }, eg.BurgerMenuDrawerSection = function(e) {
                var n = e.children,
                    t = e.className;
                return (0, i.jsx)("div", {
                    className: (0, C.cx)("grid gap-md p-md", t),
                    children: n
                })
            }, eg.BurgerMenuItem = function(e) {
                var n = e.active,
                    t = void 0 !== n && n,
                    s = e.children,
                    l = e.className,
                    c = e.ariaLabel,
                    d = e.renderSubmenu,
                    f = e.submenuOptions,
                    h = e.withSubmenuChevron,
                    m = e.onClick,
                    p = e.closeBurgerMenuOnClick,
                    v = (0, a._)(e, ["active", "children", "className", "ariaLabel", "renderSubmenu", "submenuOptions", "withSubmenuChevron", "onClick", "closeBurgerMenuOnClick"]),
                    b = (0, j.Z9)(function(e) {
                        return e.openSubmenu
                    }),
                    g = (0, j.Z9)(function(e) {
                        return e.closeOpenedSubmenu
                    }),
                    x = (0, j.Z9)(function(e) {
                        return e.toggleBurgerMenu
                    }),
                    w = !v.to && !v.href,
                    _ = w ? "button" : u.h.Link;
                return (0, i.jsxs)(_, (0, o._)((0, r._)((0, o._)((0, r._)({}, w && {
                    as: "button",
                    type: "button"
                }), {
                    className: (0, C.cx)(l, "group", "relative flex flex-row items-center self-stretch", "gap-md rounded-sm border-none", "min-h-sz-20 w-full p-md", "text-subhead text-on-surface", "hover:bg-main-container-hovered", t && "bg-main-container text-on-main-container"),
                    onClick: function() {
                        w ? (d && b((0, r._)({
                            children: d({
                                goBack: function() {
                                    return g()
                                },
                                goToMainMenu: function() {
                                    return g(!0)
                                }
                            })
                        }, f)), p && x(!1)) : !1 !== p && x(!1), null == m || m()
                    },
                    active: t,
                    "aria-current": t ? "page" : "false",
                    "aria-label": c
                }), v), {
                    children: [s, d && (void 0 === h || h) && (0, i.jsx)("div", {
                        className: "ml-auto flex pl-lg",
                        "data-test-id": "submenu-chevron",
                        children: (0, i.jsx)(Q.J, {
                            size: "sm",
                            intent: "neutral",
                            children: (0, i.jsx)(V.I, {})
                        })
                    })]
                }))
            }, eg.NavbarItem = function(e) {
                var n = e.active,
                    t = void 0 !== n && n,
                    a = e.children,
                    s = e.renderSubmenu,
                    l = e.isInfoOpen,
                    c = e.onCloseInfo,
                    d = e.ariaLabel,
                    f = e.orientation,
                    h = void 0 === f ? "horizontal" : f,
                    b = e.className,
                    g = e.to,
                    x = e.params,
                    w = e.href,
                    j = e.rel,
                    _ = e.target,
                    k = e.onClick,
                    y = (0, m._)(v(!1), 2),
                    C = y[0],
                    I = y[1],
                    N = t || C,
                    S = !g && !w,
                    B = !!s && S,
                    z = (0, p.useRef)(null),
                    O = function() {
                        var e = S ? "button" : u.h.Link,
                            n = {
                                className: ec({
                                    orientation: h,
                                    className: b
                                }),
                                "aria-label": d,
                                "aria-current": t ? "page" : "false",
                                onClick: k,
                                onMouseOver: B ? function() {
                                    return I(!0)
                                } : void 0
                            };
                        return (0, i.jsxs)(e, (0, o._)((0, r._)({}, n, S ? {
                            ref: z,
                            type: "button"
                        } : {
                            to: g,
                            params: x,
                            href: w,
                            rel: j,
                            target: _
                        }), {
                            children: [a, (0, i.jsx)(ef, {
                                isActive: N
                            })]
                        }))
                    };
                return l && c ? (0, i.jsx)(ed, {
                    onClose: c,
                    isOpen: l,
                    children: O()
                }) : (0, i.jsx)(eu, {
                    enabled: B,
                    renderSubmenu: s,
                    children: O()
                })
            }, eg.NavbarSubmenuItem = function(e) {
                var n = e.children,
                    t = e.label,
                    s = e.labelProps,
                    l = e.ariaLabel,
                    c = (0, a._)(e, ["children", "label", "labelProps", "ariaLabel"]),
                    d = !c.to && !c.href,
                    f = d ? "button" : u.h.Link;
                return (0, i.jsxs)(f, (0, o._)((0, r._)((0, o._)((0, r._)({}, d && {
                    type: "button"
                }), {
                    "aria-label": void 0 === l ? t : l
                }), c), {
                    className: (0, C.cx)("relative flex flex-row items-center gap-md self-stretch", "px-lg py-md", "w-full rounded-sm", "bg-surface hover:bg-surface-hovered"),
                    children: [t && (0, i.jsx)("p", (0, o._)((0, r._)({
                        className: "flex text-body-2 font-bold"
                    }, s), {
                        children: t
                    })), n]
                }))
            }, eg.Navbar = es, eg.SkipLink = function(e) {
                var n = e.href,
                    t = e.children,
                    s = (0, a._)(e, ["href", "children"]);
                return (0, i.jsx)("li", {
                    children: (0, i.jsx)(ep, (0, o._)((0, r._)({
                        href: n
                    }, (0, ee.e)(s)), {
                        children: t
                    }))
                })
            }, eg.SkipLinkNav = function(e) {
                var n = e.ariaLabel,
                    t = e.children;
                return (0, i.jsx)(ev, {
                    "aria-label": n,
                    children: (0, i.jsx)(eb, {
                        children: t
                    })
                })
            }, eg.NotificationCount = eh.Tz, eg.NotificationDot = em.NotificationDot, eg.Divider = function(e) {
                var n = e.className;
                return (0, i.jsx)("hr", {
                    className: (0, C.cx)(n, "h-none w-full", "border-t-sm border-solid border-outline")
                })
            }, eg.ItemIcon = function(e) {
                var n = e.className,
                    t = e.icon,
                    r = e.size,
                    o = void 0 === r ? "md" : r,
                    a = e.color,
                    s = e.children;
                return (0, i.jsxs)("div", {
                    className: Y({
                        size: o,
                        className: n
                    }),
                    children: [(0, i.jsx)(Q.J, {
                        size: o,
                        color: a,
                        children: (0, i.jsx)(t, {
                            "data-test-id": "icon"
                        })
                    }), s]
                })
            }, eg.ItemImage = function(e) {
                var n = e.className,
                    t = e.src,
                    r = e.size,
                    o = e.shape,
                    a = e.sources,
                    s = e.attributes,
                    l = e.srcFallback,
                    c = e.children;
                return (0, i.jsxs)("div", {
                    className: (0, C.cx)("relative", n),
                    children: [(0, i.jsx)("div", {
                        className: $({
                            size: void 0 === r ? "md" : r,
                            shape: void 0 === o ? "round" : o
                        }),
                        children: (0, i.jsx)(U.Z, {
                            src: t,
                            srcFallback: l,
                            sources: a,
                            attributes: s
                        })
                    }), c]
                })
            }, eg.useBurgerMenu = j.Z9
        },
        57203: function(e, n, t) {
            "use strict";
            var i = t(24043),
                r = t(67294);
            n.Z = function(e) {
                var n = (0, i._)((0, r.useState)(e), 2),
                    t = n[0],
                    o = n[1],
                    a = (0, r.useRef)(t);
                return [function() {
                    return a.current
                }, function(e) {
                    a.current = "function" == typeof e ? e(t) : e, o(e)
                }]
            }
        },
        63761: function(e) {
            e.exports = {
                isHidden: "styles_isHidden__zRMsB",
                hide: "styles_hide__2wCTr"
            }
        }
    }
]);