! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "2fa15771-cde6-4d23-8d61-2bd96983fa74", e._sentryDebugIdIdentifier = "sentry-dbid-2fa15771-cde6-4d23-8d61-2bd96983fa74")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
}, (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [92898], {
        17489: function(e, t, r) {
            "use strict";
            r.d(t, {
                Z: function() {
                    return g
                }
            });
            var n = r(87462),
                i = r(45987),
                o = r(61148),
                a = r(24292),
                s = r(67294),
                l = r(16678),
                u = r(37947),
                c = r(19181),
                d = (0, c.default)("div").withConfig({
                    displayName: "indexstyles__Container",
                    componentId: "sc-1n4j0e7-0"
                })(function(e) {
                    var t = e.rounded;
                    return (0, u.ZP)({
                        alignItems: "start",
                        borderRadius: t ? "x-small" : "none",
                        display: "flex",
                        padding: "small"
                    })
                }, (0, l.bU)({
                    variants: {
                        error: {
                            bg: "redLight",
                            color: "redDark"
                        },
                        info: {
                            bg: "blueLight"
                        },
                        warning: {
                            bg: "yellowLight"
                        },
                        tip: {
                            bg: "greyLight"
                        }
                    }
                }), l.Dh, l.GQ),
                f = (0, c.default)("span").withConfig({
                    displayName: "indexstyles__Label",
                    componentId: "sc-1n4j0e7-1"
                })((0, u.ZP)({
                    fontWeight: "semibold",
                    whiteSpace: "pre"
                })),
                E = {
                    error: "redDark",
                    info: "blueDark",
                    warning: "yellowDark",
                    tip: "greyDark"
                },
                p = ["children", "dataQaId", "icon", "label", "rounded", "variant"],
                g = function(e) {
                    var t = e.children,
                        r = e.dataQaId,
                        l = e.icon,
                        u = e.label,
                        c = e.rounded,
                        g = e.variant,
                        h = void 0 === g ? "error" : g,
                        v = (0, i.Z)(e, p);
                    return s.createElement(d, (0, n.Z)({
                        "data-qa-id": r,
                        rounded: void 0 === c || c,
                        variant: h
                    }, (0, a.e)(v)), l && s.createElement(o.ZP, {
                        color: E[h],
                        mr: "small",
                        size: "medium"
                    }, l), u && s.createElement(f, null, "".concat(u, " : ")), s.createElement("div", null, t))
                }
        },
        45395: function(e, t, r) {
            "use strict";
            r.d(t, {
                Z: function() {
                    return v
                }
            });
            var n = r(45987),
                i = r(15671),
                o = r(43144),
                a = r(97326),
                s = r(60136),
                l = r(82963),
                u = r(61120),
                c = r(4942),
                d = r(94184),
                f = r.n(d),
                E = r(67294),
                p = r(39189),
                g = {
                    ScrollableContainer: "_13omV",
                    fullWidth: "_26KFO",
                    horizontal: "_1bDxG",
                    content: "_3mtHQ",
                    vertical: "_29suh",
                    withSeparator: "_3SUsb",
                    verticalGradientStart: "_2q_Dt",
                    verticalGradientEnd: "_2xnv_",
                    hidden: "_2hvFF",
                    horizontalGradientStart: "_1VeLd",
                    horizontalGradientEnd: "SdTtA"
                },
                h = ["children", "maxHeight", "blurEffectPosition", "withSeparator", "fullWidth", "variant"],
                v = function(e) {
                    (0, s.Z)(d, E.Component);
                    var t, r = (t = function() {
                        if ("undefined" == typeof Reflect || !Reflect.construct || Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                        } catch (e) {
                            return !1
                        }
                    }(), function() {
                        var e, r = (0, u.Z)(d);
                        if (t) {
                            var n = (0, u.Z)(this).constructor;
                            e = Reflect.construct(r, arguments, n)
                        } else e = r.apply(this, arguments);
                        return (0, l.Z)(this, e)
                    });

                    function d() {
                        var e;
                        (0, i.Z)(this, d);
                        for (var t = arguments.length, n = Array(t), o = 0; o < t; o++) n[o] = arguments[o];
                        return e = r.call.apply(r, [this].concat(n)), (0, c.Z)((0, a.Z)(e), "state", {
                            hasReachedStart: !0,
                            hasReachedEnd: !1
                        }), (0, c.Z)((0, a.Z)(e), "componentDidMount", function() {
                            e.setState({
                                hasReachedStart: e.hasReachedStart(e.scrollableContentRef),
                                hasReachedEnd: e.hasReachedEnd(e.scrollableContentRef)
                            })
                        }), (0, c.Z)((0, a.Z)(e), "handleScroll", function() {
                            e.setState({
                                hasReachedStart: e.hasReachedStart(e.scrollableContentRef),
                                hasReachedEnd: e.hasReachedEnd(e.scrollableContentRef)
                            })
                        }), (0, c.Z)((0, a.Z)(e), "hasReachedStart", function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                r = t.scrollLeft,
                                n = t.scrollTop;
                            return "vertical" === e.props.variant ? 0 >= Math.floor(n) : 0 >= Math.floor(r)
                        }), (0, c.Z)((0, a.Z)(e), "hasReachedEnd", function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                r = t.clientHeight,
                                n = t.clientWidth,
                                i = t.scrollHeight,
                                o = t.scrollLeft,
                                a = t.scrollTop,
                                s = t.scrollWidth;
                            return "vertical" === e.props.variant ? Math.ceil(a + r + 1) >= i : Math.ceil(o + n + 1) >= s
                        }), (0, c.Z)((0, a.Z)(e), "setScrollableContentRef", function(t) {
                            var r, n;
                            e.scrollableContentRef = t, null === (r = (n = e.props).setRef) || void 0 === r || r.call(n, t)
                        }), e
                    }
                    return (0, o.Z)(d, [{
                        key: "componentDidUpdate",
                        value: function() {
                            var e = this.hasReachedStart(this.scrollableContentRef),
                                t = this.hasReachedEnd(this.scrollableContentRef);
                            e === this.state.hasReachedStart && t === this.state.hasReachedEnd || this.setState({
                                hasReachedStart: this.hasReachedStart(this.scrollableContentRef),
                                hasReachedEnd: this.hasReachedEnd(this.scrollableContentRef)
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e, t = this.props,
                                r = t.children,
                                i = t.maxHeight,
                                o = t.blurEffectPosition,
                                a = t.withSeparator,
                                s = t.fullWidth,
                                l = t.variant,
                                u = (0, n.Z)(t, h),
                                d = this.state,
                                v = d.hasReachedStart,
                                I = d.hasReachedEnd;
                            return E.createElement("div", {
                                className: f()(g.ScrollableContainer, g[l], p.Dh.getStyles(u), (e = {}, (0, c.Z)(e, g.withSeparator, a), (0, c.Z)(e, g.fullWidth, s), e))
                            }, E.createElement("div", {
                                ref: this.setScrollableContentRef,
                                className: f()(g.content),
                                onScroll: this.handleScroll,
                                style: {
                                    maxHeight: "".concat(i ? i + "px" : "auto")
                                }
                            }, r), ["start", "both"].includes(o) && E.createElement("div", {
                                className: f()(g["".concat(l, "GradientStart")], (0, c.Z)({}, g.hidden, v))
                            }), ["end", "both"].includes(o) && E.createElement("div", {
                                className: f()(g["".concat(l, "GradientEnd")], (0, c.Z)({}, g.hidden, I))
                            }))
                        }
                    }]), d
                }();
            (0, c.Z)(v, "defaultProps", {
                variant: "vertical",
                blurEffectPosition: "end"
            })
        },
        93949: function(e, t, r) {
            "use strict";
            r.d(t, {
                Z: function() {
                    return i
                }
            });
            var n = r(67294),
                i = function(e) {
                    var t = e.children;
                    return n.createElement("div", {
                        className: "_1XOrJ"
                    }, t)
                }
        },
        75412: function(e, t, r) {
            "use strict";
            r.d(t, {
                P5: function() {
                    return n
                },
                Rc: function() {
                    return i
                },
                i2: function() {
                    return o
                }
            });
            var n = function(e) {
                    return e ? parseFloat((100 * ("string" == typeof e ? parseFloat(e.replace(/\s/g, "").replace(",", ".")) : e)).toFixed(0)) : 0
                },
                i = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    if (!e || "0" === e) return "0";
                    for (var r = e.toString(), n = 3 - r.length, i = 0; i < n;) r = "0".concat(r), i++;
                    var o = r.slice(-2),
                        a = r.slice(0, -2).replace(/(?!^)(?=(?:\d{3})+(?:\.|$))/gm, " ");
                    return 0 === Number(o) && t ? a : "".concat(a, ",").concat(o)
                },
                o = function(e) {
                    return e && "" !== e ? e.toString().replace(/00$/, "") : e
                }
        },
        51190: function(e, t, r) {
            "use strict";
            r.d(t, {
                I8: function() {
                    return g
                },
                Ls: function() {
                    return l
                },
                Nw: function() {
                    return _
                },
                O8: function() {
                    return o
                },
                YD: function() {
                    return p
                },
                hr: function() {
                    return d
                },
                kC: function() {
                    return s
                },
                kE: function() {
                    return v
                },
                n8: function() {
                    return I
                },
                un: function() {
                    return h
                }
            });
            var n = r(62460),
                i = r(4942);
            (0, n.gxs)(/[-_]([a-z])/g, (0, n.zGw)(n.GbB, n.GBc));
            var o = function(e) {
                    var t = e.split("").reduce(function(e, t) {
                        return t === t.toUpperCase() ? e + "_" + t.toLowerCase() : e + t
                    }, "");
                    return "_" === t[0] ? t.slice(1) : t
                },
                a = /[-[\]{}()*+?.,\\^$|#\s]/g,
                s = (0, n.zGw)(n.t$q, (0, n.KJl)(function(e) {
                    return /^.['‘’]/.test(e)
                }, (0, n.gxs)(/^.{3}/, n.GBc), (0, n.gxs)(/^./, n.GBc))),
                l = (0, n.zGw)((0, n.Vl2)(" "), (0, n.UID)(s), (0, n.v_p)(" ")),
                u = /[\\^$.*+?()[\]{}|]/g,
                c = RegExp(u.source),
                d = function(e) {
                    return c.test(e) ? e.replace(u, "\\$&") : e
                };

            function f(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), r.push.apply(r, n)
                }
                return r
            }

            function E(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? f(Object(r), !0).forEach(function(t) {
                        (0, i.Z)(e, t, r[t])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : f(Object(r)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    })
                }
                return e
            }
            var p = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                        r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e.length,
                        n = t.replace(a, "\\$&").replace(/[aàâæ]/gi, "[a\xe0\xe2\xe6]").replace(/[eéèêë]/gi, "[e\xe9\xe8\xea\xeb]").replace(/[iîï]/gi, "[i\xee\xef]").replace(/[oôö]/gi, "[o\xf4\xf6]").replace(/[uû]/gi, "[u\xfb]"),
                        o = RegExp("(".concat(n, ")"), "gi");
                    return e.reduce(function(e, t) {
                        var n = t.match(o),
                            a = Object.keys(e).length >= r;
                        return n && !a ? E(E({}, e), {}, (0, i.Z)({}, t, n[0].trim())) : e
                    }, {})
                },
                g = (0, n.gxs)(/\s/g, ""),
                h = (0, n.zGw)(g, (0, n.gxs)(/(.{2})(?=.)/g, "$1 ")),
                v = function(e) {
                    return ("string" == typeof e || "number" == typeof e) && !isNaN(+e)
                },
                I = (0, n.zGw)((0, n.gxs)(/[ÀÂÁÄÃ]/g, "A"), (0, n.gxs)(/Ç/g, "C"), (0, n.gxs)(/[ÉÈÊË]/g, "E"), (0, n.gxs)(/[ÎÏÌÍ]/g, "I"), (0, n.gxs)(/ÑŃ/g, "N"), (0, n.gxs)(/[ÔÖÒÓÕ]/g, "O"), (0, n.gxs)(/[ÛÙÜÚ]/g, "U"), (0, n.gxs)(/Ÿ/g, "Y"), (0, n.gxs)(/[áàâäã]/g, "a"), (0, n.gxs)(/ç/g, "c"), (0, n.gxs)(/[éèêë¤]/g, "e"), (0, n.gxs)(/[íìîï]/g, "i"), (0, n.gxs)(/ñń/g, "n"), (0, n.gxs)(/[óòôöõ]/g, "o"), (0, n.gxs)(/[úùûü]/g, "u"), (0, n.gxs)(/ÿ/g, "y"), (0, n.gxs)(/²/g, "2"), (0, n.gxs)(/³/g, "3")),
                _ = (0, n.zGw)(n.t$q, I, (0, n.gxs)(/[^a-zA-Z0-9]+/g, "_"));
            (0, n.WAo)(function(e, t) {
                return t.length > e ? t.substring(0, e) + "…" : t
            })
        },
        83528: function(e, t) {
            "use strict";
            /*! *****************************************************************************
            Copyright (c) Microsoft Corporation.

            Permission to use, copy, modify, and/or distribute this software for any
            purpose with or without fee is hereby granted.

            THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
            REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
            AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
            INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
            LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
            OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
            PERFORMANCE OF THIS SOFTWARE.
            ***************************************************************************** */
            var r, n = function() {
                    return (n = Object.assign || function(e) {
                        for (var t, r = 1, n = arguments.length; r < n; r++)
                            for (var i in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                        return e
                    }).apply(this, arguments)
                },
                i = {
                    dispatchEvent: function() {}
                },
                o = function(e) {
                    return e instanceof Error ? e.message : String(e)
                },
                a = Object.freeze({
                    dev: "https://api.houston-dev.advgo.net/v2/houston/experiments/%s/web",
                    pre: "https://api.houston-pre.advgo.net/v2/houston/experiments/%s/web",
                    pro: "https://api.houston.advgo.net/v2/houston/experiments/%s/web"
                }),
                s = function(e, t) {
                    if (!e || !t) throw Error("Could not get SDK key with tenant: '".concat(e, "' and applicationId: '").concat(t, "'"));
                    return "".concat(e, "/").concat(t)
                },
                l = function(e) {
                    var t = e.pulseEventDispatcher,
                        r = e.providerId,
                        i = e.deployStage,
                        o = e.options,
                        a = t(r, n({
                            deployStage: i,
                            logger: e.logger
                        }, o));
                    if (!r || !a) throw Error("Could not create event dispatcher with providerId: '".concat(r, "'"));
                    return a
                },
                u = {
                    collectorDomain: "https://collector.mpianalytics.com",
                    collectorPath: "",
                    deployStage: "pro",
                    eventModifier: function(e) {
                        return e
                    },
                    logger: function() {},
                    userIdPrefix: ""
                },
                c = n(n({}, u), {
                    collectorPath: "api/v1/track"
                }),
                d = function(e) {
                    function t(t) {
                        for (var r, n = 0; n < t.length; n += 1)
                            if (r = t[n], e.match(new RegExp(r))) return !0;
                        return !1
                    }
                    if (e) {
                        if (t(["iPhone;", "iPod;", "iPod touch;", "^HTC", "Fennec", "IEMobile", "BB10;", "BlackBerry", "SymbianOS.*AppleWebKit", "^Mozilla.*Mobile.*Firefox", "^Mozilla.*Chrome.*Mobile", "Opera Mobi", "Android.*Mobile", "Android.*Mini", "Symbian", "^SonyEricsson", "^Nokia", "^SAMSUNG", "^LG"])) return "mobile";
                        if (t(["iPad;", "Android"])) return "tablet"
                    }
                    return "desktop"
                },
                f = function() {
                    if ("undefined" == typeof window) return {};
                    var e = window.navigator.userAgent;
                    return {
                        userAgent: e,
                        deviceType: d(e)
                    }
                }(),
                E = function(e, t) {
                    return p(e).startsWith(t) ? e : "".concat(t).concat(e)
                },
                p = function(e) {
                    return {
                        startsWith: function(t) {
                            return 0 === e.indexOf(t)
                        }
                    }
                },
                g = function(e) {
                    if (!e.visitorId) throw Error("No 'visitor_id' present in event");
                    if (!e.uuid) throw Error("No 'uuid' present in event");
                    var t = new Date(e.timestamp),
                        r = "yellow" === e.campaignType;
                    return n(n({
                        "@id": e.uuid,
                        creationDate: t.toISOString(),
                        deployStage: e.deployStage,
                        device: n(n({
                            "@type": "Device"
                        }, r && {
                            environmentId: E(e.visitorId, "sdrn:schibsted:environment:")
                        }), f)
                    }, !r && {
                        actor: {
                            "@id": E(e.visitorId, e.userIdPrefix)
                        }
                    }), {
                        provider: {
                            "@id": e.providerId,
                            "@type": "Organization"
                        },
                        schema: "http://schema.adevinta.com/events/tracker-event.json/310.json",
                        tracker: {
                            name: "JS Event Dispatcher",
                            type: "JS",
                            version: "0.3.0"
                        }
                    })
                },
                h = function(e, t) {
                    var r, i, o = t.deployStage,
                        a = t.providerId,
                        s = t.userIdPrefix,
                        l = e.snapshots[0].events[0],
                        u = null === (i = e.snapshots[0].decisions) || void 0 === i ? void 0 : i[0];
                    return "campaign_activated" === (r = {
                        campaignType: l.entity_id,
                        deployStage: o,
                        eventKey: l.key,
                        experimentId: null == u ? void 0 : u.experiment_id,
                        providerId: a,
                        timestamp: l.timestamp,
                        userIdPrefix: s,
                        uuid: l.uuid,
                        variant: null == u ? void 0 : u.metadata.variation_key,
                        visitorId: e.visitor_id
                    }).eventKey ? function(e) {
                        var t = e.experimentId,
                            r = e.variant;
                        if (!t) throw Error("No experiment ID is present");
                        if (!r) throw Error("No variant present in Activate event");
                        return n({
                            "@type": "Activate",
                            object: {
                                "@id": t,
                                "@type": "Experiment",
                                status: "assigned",
                                variant: r
                            }
                        }, g(e))
                    }(r) : function(e) {
                        var t = e.eventKey;
                        if (!t) throw Error("No 'key' present in Conversion event");
                        return n({
                            "@type": "Convert",
                            object: {
                                "@type": "ExperimentCustomConversion",
                                customKey: t
                            }
                        }, g(e))
                    }(r)
                },
                v = function(e, t) {
                    if (void 0 === t && (t = {}), !e) throw Error("Provider ID is required");
                    var r, i, a = n(n({}, u), t),
                        s = (r = a.collectorDomain, i = a.collectorPath, "".concat(r, "/").concat(i));
                    if (!a.sendEventHandler) throw Error("No sendEventHandler defined");
                    var l = a.sendEventHandler;
                    return {
                        dispatchEvent: function(t, r) {
                            if ("POST" === t.httpVerb) {
                                var n = JSON.stringify(function(e, t, r) {
                                        try {
                                            var n = t.params.visitors;
                                            return n ? n.map(function(t) {
                                                var n = h(t, {
                                                    deployStage: r.deployStage,
                                                    providerId: e,
                                                    userIdPrefix: r.userIdPrefix
                                                });
                                                return r.eventModifier(n)
                                            }) : []
                                        } catch (e) {
                                            return r.logger({
                                                type: "error",
                                                message: "[createBatchedPulseEvents] ".concat(o(e))
                                            }), []
                                        }
                                    }(e, t, a)),
                                    i = function(e) {
                                        a.logger({
                                            type: "error",
                                            message: "Could not POST: ".concat(o(e))
                                        })
                                    };
                                l(s, n, function(e) {
                                    try {
                                        e && r && "function" == typeof r && r(e)
                                    } catch (e) {
                                        i(e)
                                    }
                                }, i)
                            } else a.logger({
                                type: "warn",
                                message: "Http method ".concat(t.httpVerb, " not supported. Expected 'POST'.")
                            })
                        }
                    }
                },
                I = function(e, t, r) {
                    var n = new XMLHttpRequest;
                    n.open("POST", e, !0), n.setRequestHeader("Content-Type", "application/json"), n.onreadystatechange = function() {
                        4 === n.readyState && r({
                            statusCode: n.status
                        })
                    }, n.send(t)
                },
                _ = (r = function(e, t) {
                    void 0 === t && (t = {});
                    var r = n(n({}, c), t);
                    return r.sendEventHandler || (r.sendEventHandler = I), v(e, r)
                }, function(e, t) {
                    var n, u;
                    try {
                        var c = s(e.tenant, e.applicationId),
                            d = function(e) {
                                var t = a[e];
                                if (!t) throw Error("Could not get URL template with environment: '".concat(e, "'"));
                                return t
                            }(e.environment);
                        return {
                            sdkKey: c,
                            eventDispatcher: l({
                                pulseEventDispatcher: r,
                                providerId: e.providerId,
                                deployStage: e.environment,
                                options: e.eventDispatcherOptions,
                                logger: e.logger
                            }),
                            datafileOptions: {
                                urlTemplate: d
                            }
                        }
                    } catch (r) {
                        return null === (n = e.logger) || void 0 === n || n.call(e, {
                            type: "error",
                            message: "[getHoustonOptimizelySdkOptions]: ".concat(o(r))
                        }), null === (u = null == t ? void 0 : t.onError) || void 0 === u || u.call(t, r instanceof Error ? r : Error(String(r))), {
                            eventDispatcher: i
                        }
                    }
                });
            t.OU = _
        },
        53949: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = r(13196),
                i = function() {
                    function e() {
                        this.errorCount = 0
                    }
                    return e.prototype.getDelay = function() {
                        return 0 === this.errorCount ? 0 : 1e3 * n.BACKOFF_BASE_WAIT_SECONDS_BY_ERROR_COUNT[Math.min(n.BACKOFF_BASE_WAIT_SECONDS_BY_ERROR_COUNT.length - 1, this.errorCount)] + Math.round(1e3 * Math.random())
                    }, e.prototype.countError = function() {
                        this.errorCount < n.BACKOFF_BASE_WAIT_SECONDS_BY_ERROR_COUNT.length - 1 && this.errorCount++
                    }, e.prototype.reset = function() {
                        this.errorCount = 0
                    }, e
                }();
            t.default = i
        },
        20731: function(e, t, r) {
            "use strict";
            var n, i = this && this.__extends || (n = function(e, t) {
                    return (n = Object.setPrototypeOf || ({
                        __proto__: []
                    }) instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r])
                    })(e, t)
                }, function(e, t) {
                    function r() {
                        this.constructor = e
                    }
                    n(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r)
                }),
                o = this && this.__importDefault || function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = r(80064),
                s = function(e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return i(t, e), t.prototype.makeGetRequest = function(e, t) {
                        return a.makeGetRequest(e, t)
                    }, t.prototype.getConfigDefaults = function() {
                        return {
                            autoUpdate: !1
                        }
                    }, t
                }(o(r(20377)).default);
            t.default = s
        },
        80064: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = r(13196),
                i = r(98125).getLogger("DatafileManager");
            t.makeGetRequest = function(e, t) {
                var r = new XMLHttpRequest;
                return {
                    responsePromise: new Promise(function(o, a) {
                        r.open("GET", e, !0),
                            function(e, t) {
                                Object.keys(e).forEach(function(r) {
                                    var n = e[r];
                                    t.setRequestHeader(r, n)
                                })
                            }(t, r), r.onreadystatechange = function() {
                                if (4 === r.readyState) {
                                    if (0 === r.status) {
                                        a(Error("Request error"));
                                        return
                                    }
                                    var e = function(e) {
                                        var t = e.getAllResponseHeaders();
                                        if (null === t) return {};
                                        var r = t.split("\r\n"),
                                            n = {};
                                        return r.forEach(function(e) {
                                            var t = e.indexOf(": ");
                                            if (t > -1) {
                                                var r = e.slice(0, t),
                                                    i = e.slice(t + 2);
                                                i.length > 0 && (n[r] = i)
                                            }
                                        }), n
                                    }(r);
                                    o({
                                        statusCode: r.status,
                                        body: r.responseText,
                                        headers: e
                                    })
                                }
                            }, r.timeout = n.REQUEST_TIMEOUT_MS, r.ontimeout = function() {
                                i.error("Request timed out")
                            }, r.send()
                    }),
                    abort: function() {
                        r.abort()
                    }
                }
            }
        },
        13196: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.DEFAULT_UPDATE_INTERVAL = 3e5, t.MIN_UPDATE_INTERVAL = 1e3, t.DEFAULT_URL_TEMPLATE = "https://cdn.optimizely.com/datafiles/%s.json", t.DEFAULT_AUTHENTICATED_URL_TEMPLATE = "https://config.optimizely.com/datafiles/auth/%s.json", t.BACKOFF_BASE_WAIT_SECONDS_BY_ERROR_COUNT = [0, 8, 16, 32, 64, 128, 256, 512], t.REQUEST_TIMEOUT_MS = 6e4
        },
        10181: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function() {
                function e() {
                    this.listeners = {}, this.listenerId = 1
                }
                return e.prototype.on = function(e, t) {
                    var r = this;
                    this.listeners[e] || (this.listeners[e] = {});
                    var n = String(this.listenerId);
                    return this.listenerId++, this.listeners[e][n] = t,
                        function() {
                            r.listeners[e] && delete r.listeners[e][n]
                        }
                }, e.prototype.emit = function(e, t) {
                    var r = this.listeners[e];
                    r && Object.keys(r).forEach(function(e) {
                        (0, r[e])(t)
                    })
                }, e.prototype.removeAllListeners = function() {
                    this.listeners = {}
                }, e
            }();
            t.default = r
        },
        20377: function(e, t, r) {
            "use strict";
            var n = this && this.__assign || function() {
                    return (n = Object.assign || function(e) {
                        for (var t, r = 1, n = arguments.length; r < n; r++)
                            for (var i in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                        return e
                    }).apply(this, arguments)
                },
                i = this && this.__importDefault || function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = r(98125),
                a = r(27378),
                s = i(r(10181)),
                l = r(13196),
                u = i(r(53949)),
                c = o.getLogger("DatafileManager");

            function d(e) {
                return e >= 200 && e < 400
            }
            var f = {
                    get: function() {
                        return Promise.resolve("")
                    },
                    set: function() {
                        return Promise.resolve()
                    },
                    contains: function() {
                        return Promise.resolve(!1)
                    },
                    remove: function() {
                        return Promise.resolve()
                    }
                },
                E = function() {
                    function e(e) {
                        var t = this,
                            r = n(n({}, this.getConfigDefaults()), e),
                            i = r.datafile,
                            o = r.autoUpdate,
                            d = r.sdkKey,
                            E = r.updateInterval,
                            p = void 0 === E ? l.DEFAULT_UPDATE_INTERVAL : E,
                            g = r.urlTemplate,
                            h = void 0 === g ? l.DEFAULT_URL_TEMPLATE : g,
                            v = r.cache;
                        (this.cache = void 0 === v ? f : v, this.cacheKey = "opt-datafile-" + d, this.isReadyPromiseSettled = !1, this.readyPromiseResolver = function() {}, this.readyPromiseRejecter = function() {}, this.readyPromise = new Promise(function(e, r) {
                            t.readyPromiseResolver = e, t.readyPromiseRejecter = r
                        }), i ? (this.currentDatafile = i, d || this.resolveReadyPromise()) : this.currentDatafile = "", this.isStarted = !1, this.datafileUrl = a.sprintf(h, d), this.emitter = new s.default, this.autoUpdate = void 0 !== o && o, p >= l.MIN_UPDATE_INTERVAL) ? this.updateInterval = p: (c.warn("Invalid updateInterval %s, defaulting to %s", p, l.DEFAULT_UPDATE_INTERVAL), this.updateInterval = l.DEFAULT_UPDATE_INTERVAL), this.currentTimeout = null, this.currentRequest = null, this.backoffController = new u.default, this.syncOnCurrentRequestComplete = !1
                    }
                    return e.prototype.get = function() {
                        return this.currentDatafile
                    }, e.prototype.start = function() {
                        this.isStarted || (c.debug("Datafile manager started"), this.isStarted = !0, this.backoffController.reset(), this.setDatafileFromCacheIfAvailable(), this.syncDatafile())
                    }, e.prototype.stop = function() {
                        return c.debug("Datafile manager stopped"), this.isStarted = !1, this.currentTimeout && (clearTimeout(this.currentTimeout), this.currentTimeout = null), this.emitter.removeAllListeners(), this.currentRequest && (this.currentRequest.abort(), this.currentRequest = null), Promise.resolve()
                    }, e.prototype.onReady = function() {
                        return this.readyPromise
                    }, e.prototype.on = function(e, t) {
                        return this.emitter.on(e, t)
                    }, e.prototype.onRequestRejected = function(e) {
                        this.isStarted && (this.backoffController.countError(), e instanceof Error ? c.error("Error fetching datafile: %s", e.message, e) : "string" == typeof e ? c.error("Error fetching datafile: %s", e) : c.error("Error fetching datafile"))
                    }, e.prototype.onRequestResolved = function(e) {
                        if (this.isStarted) {
                            void 0 !== e.statusCode && d(e.statusCode) ? this.backoffController.reset() : this.backoffController.countError(), this.trySavingLastModified(e.headers);
                            var t = this.getNextDatafileFromResponse(e);
                            "" !== t && (c.info("Updating datafile from response"), this.currentDatafile = t, this.cache.set(this.cacheKey, t), this.isReadyPromiseSettled ? this.emitter.emit("update", {
                                datafile: t
                            }) : this.resolveReadyPromise())
                        }
                    }, e.prototype.onRequestComplete = function() {
                        this.isStarted && (this.currentRequest = null, this.isReadyPromiseSettled || this.autoUpdate || this.rejectReadyPromise(Error("Failed to become ready")), this.autoUpdate && this.syncOnCurrentRequestComplete && this.syncDatafile(), this.syncOnCurrentRequestComplete = !1)
                    }, e.prototype.syncDatafile = function() {
                        var e = this,
                            t = {};
                        this.lastResponseLastModified && (t["if-modified-since"] = this.lastResponseLastModified), c.debug("Making datafile request to url %s with headers: %s", this.datafileUrl, function() {
                            return JSON.stringify(t)
                        }), this.currentRequest = this.makeGetRequest(this.datafileUrl, t);
                        var r = function() {
                            e.onRequestComplete()
                        };
                        this.currentRequest.responsePromise.then(function(t) {
                            e.onRequestResolved(t)
                        }, function(t) {
                            e.onRequestRejected(t)
                        }).then(r, r), this.autoUpdate && this.scheduleNextUpdate()
                    }, e.prototype.resolveReadyPromise = function() {
                        this.readyPromiseResolver(), this.isReadyPromiseSettled = !0
                    }, e.prototype.rejectReadyPromise = function(e) {
                        this.readyPromiseRejecter(e), this.isReadyPromiseSettled = !0
                    }, e.prototype.scheduleNextUpdate = function() {
                        var e = this,
                            t = Math.max(this.backoffController.getDelay(), this.updateInterval);
                        c.debug("Scheduling sync in %s ms", t), this.currentTimeout = setTimeout(function() {
                            e.currentRequest ? e.syncOnCurrentRequestComplete = !0 : e.syncDatafile()
                        }, t)
                    }, e.prototype.getNextDatafileFromResponse = function(e) {
                        return (c.debug("Response status code: %s", e.statusCode), void 0 === e.statusCode || 304 === e.statusCode) ? "" : d(e.statusCode) ? e.body : ""
                    }, e.prototype.trySavingLastModified = function(e) {
                        var t = e["last-modified"] || e["Last-Modified"];
                        void 0 !== t && (this.lastResponseLastModified = t, c.debug("Saved last modified header value from response: %s", this.lastResponseLastModified))
                    }, e.prototype.setDatafileFromCacheIfAvailable = function() {
                        var e = this;
                        this.cache.get(this.cacheKey).then(function(t) {
                            e.isStarted && !e.isReadyPromiseSettled && "" !== t && (c.debug("Using datafile from cache"), e.currentDatafile = t, e.resolveReadyPromise())
                        })
                    }, e
                }();
            t.default = E
        },
        62002: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = r(20731);
            t.HttpPollingDatafileManager = n.default
        },
        67473: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            })
        },
        24909: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.sendEventNotification = t.getQueue = t.validateAndGetBatchSize = t.validateAndGetFlushInterval = t.DEFAULT_BATCH_SIZE = t.DEFAULT_FLUSH_INTERVAL = void 0;
            var n = r(31459),
                i = r(98125),
                o = r(27378);
            t.DEFAULT_FLUSH_INTERVAL = 3e4, t.DEFAULT_BATCH_SIZE = 10;
            var a = i.getLogger("EventProcessor");
            t.validateAndGetFlushInterval = function(e) {
                return e <= 0 && (a.warn("Invalid flushInterval " + e + ", defaulting to " + t.DEFAULT_FLUSH_INTERVAL), e = t.DEFAULT_FLUSH_INTERVAL), e
            }, t.validateAndGetBatchSize = function(e) {
                return (e = Math.floor(e)) < 1 && (a.warn("Invalid batchSize " + e + ", defaulting to " + t.DEFAULT_BATCH_SIZE), e = t.DEFAULT_BATCH_SIZE), e = Math.max(1, e)
            }, t.getQueue = function(e, t, r, i) {
                return e > 1 ? new n.DefaultEventQueue({
                    flushInterval: t,
                    maxQueueSize: e,
                    sink: r,
                    batchComparator: i
                }) : new n.SingleEventQueue({
                    sink: r
                })
            }, t.sendEventNotification = function(e, t) {
                e && e.sendNotifications(o.NOTIFICATION_TYPES.LOG_EVENT, t)
            }
        },
        31459: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.DefaultEventQueue = t.SingleEventQueue = void 0;
            var n = r(98125).getLogger("EventProcessor"),
                i = function() {
                    function e(e) {
                        var t = e.timeout,
                            r = e.callback;
                        this.timeout = Math.max(t, 0), this.callback = r
                    }
                    return e.prototype.start = function() {
                        this.timeoutId = setTimeout(this.callback, this.timeout)
                    }, e.prototype.refresh = function() {
                        this.stop(), this.start()
                    }, e.prototype.stop = function() {
                        this.timeoutId && clearTimeout(this.timeoutId)
                    }, e
                }(),
                o = function() {
                    function e(e) {
                        var t = e.sink;
                        this.sink = t
                    }
                    return e.prototype.start = function() {}, e.prototype.stop = function() {
                        return Promise.resolve()
                    }, e.prototype.enqueue = function(e) {
                        this.sink([e])
                    }, e
                }();
            t.SingleEventQueue = o;
            var a = function() {
                function e(e) {
                    var t = e.flushInterval,
                        r = e.maxQueueSize,
                        n = e.sink,
                        o = e.batchComparator;
                    this.buffer = [], this.maxQueueSize = Math.max(r, 1), this.sink = n, this.batchComparator = o, this.timer = new i({
                        callback: this.flush.bind(this),
                        timeout: t
                    }), this.started = !1
                }
                return e.prototype.start = function() {
                    this.started = !0
                }, e.prototype.stop = function() {
                    this.started = !1;
                    var e = this.sink(this.buffer);
                    return this.buffer = [], this.timer.stop(), e
                }, e.prototype.enqueue = function(e) {
                    if (!this.started) {
                        n.warn("Queue is stopped, not accepting event");
                        return
                    }
                    var t = this.buffer[0];
                    t && !this.batchComparator(t, e) && this.flush(), 0 === this.buffer.length && this.timer.refresh(), this.buffer.push(e), this.buffer.length >= this.maxQueueSize && this.flush()
                }, e.prototype.flush = function() {
                    this.sink(this.buffer), this.buffer = [], this.timer.stop()
                }, e
            }();
            t.DefaultEventQueue = a
        },
        51074: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.areEventContextsEqual = void 0, t.areEventContextsEqual = function(e, t) {
                var r = e.context,
                    n = t.context;
                return r.accountId === n.accountId && r.projectId === n.projectId && r.clientName === n.clientName && r.clientVersion === n.clientVersion && r.revision === n.revision && r.anonymizeIP === n.anonymizeIP && r.botFiltering === n.botFiltering
            }
        },
        65001: function(e, t, r) {
            "use strict";
            var n = this && this.__createBinding || (Object.create ? function(e, t, r, n) {
                    void 0 === n && (n = r), Object.defineProperty(e, n, {
                        enumerable: !0,
                        get: function() {
                            return t[r]
                        }
                    })
                } : function(e, t, r, n) {
                    void 0 === n && (n = r), e[n] = t[r]
                }),
                i = this && this.__exportStar || function(e, t) {
                    for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || n(t, e, r)
                };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), i(r(51074), t), i(r(24909), t), i(r(67473), t), i(r(21310), t), i(r(36896), t), i(r(97168), t), i(r(18994), t)
        },
        21310: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            })
        },
        36896: function(e, t, r) {
            "use strict";
            var n, i = this && this.__extends || (n = function(e, t) {
                return (n = Object.setPrototypeOf || ({
                    __proto__: []
                }) instanceof Array && function(e, t) {
                    e.__proto__ = t
                } || function(e, t) {
                    for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                })(e, t)
            }, function(e, t) {
                function r() {
                    this.constructor = e
                }
                n(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.LocalStoragePendingEventsDispatcher = t.PendingEventsDispatcher = void 0;
            var o = r(98125),
                a = r(36587),
                s = r(27378),
                l = o.getLogger("EventProcessor"),
                u = function() {
                    function e(e) {
                        var t = e.eventDispatcher,
                            r = e.store;
                        this.dispatcher = t, this.store = r
                    }
                    return e.prototype.dispatchEvent = function(e, t) {
                        this.send({
                            uuid: s.generateUUID(),
                            timestamp: s.getTimestamp(),
                            request: e
                        }, t)
                    }, e.prototype.sendPendingEvents = function() {
                        var e = this,
                            t = this.store.values();
                        l.debug("Sending %s pending events from previous page", t.length), t.forEach(function(t) {
                            try {
                                e.send(t, function() {})
                            } catch (e) {}
                        })
                    }, e.prototype.send = function(e, t) {
                        var r = this;
                        this.store.set(e.uuid, e), this.dispatcher.dispatchEvent(e.request, function(n) {
                            r.store.remove(e.uuid), t(n)
                        })
                    }, e
                }();
            t.PendingEventsDispatcher = u;
            var c = function(e) {
                function t(t) {
                    var r = t.eventDispatcher;
                    return e.call(this, {
                        eventDispatcher: r,
                        store: new a.LocalStorageStore({
                            maxValues: 100,
                            key: "fs_optly_pending_events"
                        })
                    }) || this
                }
                return i(t, e), t
            }(u);
            t.LocalStoragePendingEventsDispatcher = c
        },
        36587: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.LocalStorageStore = void 0;
            var n = r(27378),
                i = r(98125).getLogger("EventProcessor"),
                o = function() {
                    function e(e) {
                        var t = e.key,
                            r = e.maxValues;
                        this.LS_KEY = t, this.maxValues = void 0 === r ? 1e3 : r
                    }
                    return e.prototype.get = function(e) {
                        return this.getMap()[e] || null
                    }, e.prototype.set = function(e, t) {
                        var r = this.getMap();
                        r[e] = t, this.replace(r)
                    }, e.prototype.remove = function(e) {
                        var t = this.getMap();
                        delete t[e], this.replace(t)
                    }, e.prototype.values = function() {
                        return n.objectValues(this.getMap())
                    }, e.prototype.clear = function() {
                        this.replace({})
                    }, e.prototype.replace = function(e) {
                        try {
                            window.localStorage && localStorage.setItem(this.LS_KEY, JSON.stringify(e)), this.clean()
                        } catch (e) {
                            i.error(e)
                        }
                    }, e.prototype.clean = function() {
                        var e = this.getMap(),
                            t = Object.keys(e),
                            r = t.length - this.maxValues;
                        if (!(r < 1)) {
                            var n = t.map(function(t) {
                                return {
                                    key: t,
                                    value: e[t]
                                }
                            });
                            n.sort(function(e, t) {
                                return e.value.timestamp - t.value.timestamp
                            });
                            for (var i = 0; i < r; i++) delete e[n[i].key];
                            this.replace(e)
                        }
                    }, e.prototype.getMap = function() {
                        try {
                            var e = window.localStorage && localStorage.getItem(this.LS_KEY);
                            if (e) return JSON.parse(e) || {}
                        } catch (e) {
                            i.error(e)
                        }
                        return {}
                    }, e
                }();
            t.LocalStorageStore = o
        },
        90522: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function() {
                function e() {
                    this.reqsInFlightCount = 0, this.reqsCompleteResolvers = []
                }
                return e.prototype.trackRequest = function(e) {
                    var t = this;
                    this.reqsInFlightCount++;
                    var r = function() {
                        t.reqsInFlightCount--, 0 === t.reqsInFlightCount && (t.reqsCompleteResolvers.forEach(function(e) {
                            return e()
                        }), t.reqsCompleteResolvers = [])
                    };
                    e.then(r, r)
                }, e.prototype.onRequestsComplete = function() {
                    var e = this;
                    return new Promise(function(t) {
                        0 === e.reqsInFlightCount ? t() : e.reqsCompleteResolvers.push(t)
                    })
                }, e
            }();
            t.default = r
        },
        97168: function(e, t) {
            "use strict";
            var r = this && this.__assign || function() {
                return (r = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++)
                        for (var i in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                    return e
                }).apply(this, arguments)
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.formatEvents = t.buildConversionEventV1 = t.buildImpressionEventV1 = t.makeBatchedEventV1 = void 0;
            var n = "$opt_bot_filtering";

            function i(e) {
                var t = [],
                    r = e[0];
                return e.forEach(function(e) {
                    if ("conversion" === e.type || "impression" === e.type) {
                        var r = s(e);
                        "impression" === e.type ? r.snapshots.push(a(e)) : "conversion" === e.type && r.snapshots.push(o(e)), t.push(r)
                    }
                }), {
                    client_name: r.context.clientName,
                    client_version: r.context.clientVersion,
                    account_id: r.context.accountId,
                    project_id: r.context.projectId,
                    revision: r.context.revision,
                    anonymize_ip: r.context.anonymizeIP,
                    enrich_decisions: !0,
                    visitors: t
                }
            }

            function o(e) {
                var t = r({}, e.tags);
                delete t.revenue, delete t.value;
                var n = {
                    entity_id: e.event.id,
                    key: e.event.key,
                    timestamp: e.timestamp,
                    uuid: e.uuid
                };
                return e.tags && (n.tags = e.tags), null != e.value && (n.value = e.value), null != e.revenue && (n.revenue = e.revenue), {
                    events: [n]
                }
            }

            function a(e) {
                var t, r, n = e.layer,
                    i = e.experiment,
                    o = e.variation,
                    a = e.ruleKey,
                    s = e.flagKey,
                    l = e.ruleType,
                    u = e.enabled,
                    c = n ? n.id : null;
                return {
                    decisions: [{
                        campaign_id: c,
                        experiment_id: null !== (t = null == i ? void 0 : i.id) && void 0 !== t ? t : "",
                        variation_id: null !== (r = null == o ? void 0 : o.id) && void 0 !== r ? r : "",
                        metadata: {
                            flag_key: s,
                            rule_key: a,
                            rule_type: l,
                            variation_key: o ? o.key : "",
                            enabled: u
                        }
                    }],
                    events: [{
                        entity_id: c,
                        timestamp: e.timestamp,
                        key: "campaign_activated",
                        uuid: e.uuid
                    }]
                }
            }

            function s(e) {
                var t = {
                    snapshots: [],
                    visitor_id: e.user.id,
                    attributes: []
                };
                return e.user.attributes.forEach(function(e) {
                    t.attributes.push({
                        entity_id: e.entityId,
                        key: e.key,
                        type: "custom",
                        value: e.value
                    })
                }), "boolean" == typeof e.context.botFiltering && t.attributes.push({
                    entity_id: n,
                    key: n,
                    type: "custom",
                    value: e.context.botFiltering
                }), t
            }
            t.makeBatchedEventV1 = i, t.buildImpressionEventV1 = function(e) {
                var t = s(e);
                return t.snapshots.push(a(e)), {
                    client_name: e.context.clientName,
                    client_version: e.context.clientVersion,
                    account_id: e.context.accountId,
                    project_id: e.context.projectId,
                    revision: e.context.revision,
                    anonymize_ip: e.context.anonymizeIP,
                    enrich_decisions: !0,
                    visitors: [t]
                }
            }, t.buildConversionEventV1 = function(e) {
                var t = s(e);
                return t.snapshots.push(o(e)), {
                    client_name: e.context.clientName,
                    client_version: e.context.clientVersion,
                    account_id: e.context.accountId,
                    project_id: e.context.projectId,
                    revision: e.context.revision,
                    anonymize_ip: e.context.anonymizeIP,
                    enrich_decisions: !0,
                    visitors: [t]
                }
            }, t.formatEvents = function(e) {
                return {
                    url: "https://logx.optimizely.com/v1/events",
                    httpVerb: "POST",
                    params: i(e)
                }
            }
        },
        18994: function(e, t, r) {
            "use strict";
            var n = this && this.__awaiter || function(e, t, r, n) {
                    return new(r || (r = Promise))(function(i, o) {
                        function a(e) {
                            try {
                                l(n.next(e))
                            } catch (e) {
                                o(e)
                            }
                        }

                        function s(e) {
                            try {
                                l(n.throw(e))
                            } catch (e) {
                                o(e)
                            }
                        }

                        function l(e) {
                            var t;
                            e.done ? i(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                                e(t)
                            })).then(a, s)
                        }
                        l((n = n.apply(e, t || [])).next())
                    })
                },
                i = this && this.__generator || function(e, t) {
                    var r, n, i, o, a = {
                        label: 0,
                        sent: function() {
                            if (1 & i[0]) throw i[1];
                            return i[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return o = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                        return this
                    }), o;

                    function s(o) {
                        return function(s) {
                            return function(o) {
                                if (r) throw TypeError("Generator is already executing.");
                                for (; a;) try {
                                    if (r = 1, n && (i = 2 & o[0] ? n.return : o[0] ? n.throw || ((i = n.return) && i.call(n), 0) : n.next) && !(i = i.call(n, o[1])).done) return i;
                                    switch (n = 0, i && (o = [2 & o[0], i.value]), o[0]) {
                                        case 0:
                                        case 1:
                                            i = o;
                                            break;
                                        case 4:
                                            return a.label++, {
                                                value: o[1],
                                                done: !1
                                            };
                                        case 5:
                                            a.label++, n = o[1], o = [0];
                                            continue;
                                        case 7:
                                            o = a.ops.pop(), a.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = (i = a.trys).length > 0 && i[i.length - 1]) && (6 === o[0] || 2 === o[0])) {
                                                a = 0;
                                                continue
                                            }
                                            if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                                a.label = o[1];
                                                break
                                            }
                                            if (6 === o[0] && a.label < i[1]) {
                                                a.label = i[1], i = o;
                                                break
                                            }
                                            if (i && a.label < i[2]) {
                                                a.label = i[2], a.ops.push(o);
                                                break
                                            }
                                            i[2] && a.ops.pop(), a.trys.pop();
                                            continue
                                    }
                                    o = t.call(e, a)
                                } catch (e) {
                                    o = [6, e], n = 0
                                } finally {
                                    r = i = 0
                                }
                                if (5 & o[0]) throw o[1];
                                return {
                                    value: o[0] ? o[1] : void 0,
                                    done: !0
                                }
                            }([o, s])
                        }
                    }
                },
                o = this && this.__importDefault || function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.LogTierV1EventProcessor = void 0;
            var a = r(98125),
                s = r(24909),
                l = o(r(90522)),
                u = r(51074),
                c = r(97168),
                d = a.getLogger("LogTierV1EventProcessor"),
                f = function() {
                    function e(e) {
                        var t = e.dispatcher,
                            r = e.flushInterval,
                            n = void 0 === r ? s.DEFAULT_FLUSH_INTERVAL : r,
                            i = e.batchSize,
                            o = void 0 === i ? s.DEFAULT_BATCH_SIZE : i,
                            a = e.notificationCenter;
                        this.dispatcher = t, this.notificationCenter = a, this.requestTracker = new l.default, n = s.validateAndGetFlushInterval(n), o = s.validateAndGetBatchSize(o), this.queue = s.getQueue(o, n, this.drainQueue.bind(this), u.areEventContextsEqual)
                    }
                    return e.prototype.drainQueue = function(e) {
                        var t = this,
                            r = new Promise(function(r) {
                                if (d.debug("draining queue with %s events", e.length), 0 === e.length) {
                                    r();
                                    return
                                }
                                var n = c.formatEvents(e);
                                t.dispatcher.dispatchEvent(n, function() {
                                    r()
                                }), s.sendEventNotification(t.notificationCenter, n)
                            });
                        return this.requestTracker.trackRequest(r), r
                    }, e.prototype.process = function(e) {
                        this.queue.enqueue(e)
                    }, e.prototype.stop = function() {
                        try {
                            return this.queue.stop(), this.requestTracker.onRequestsComplete()
                        } catch (e) {
                            d.error('Error stopping EventProcessor: "%s"', e.message, e)
                        }
                        return Promise.resolve()
                    }, e.prototype.start = function() {
                        return n(this, void 0, void 0, function() {
                            return i(this, function(e) {
                                return this.queue.start(), [2]
                            })
                        })
                    }, e
                }();
            t.LogTierV1EventProcessor = f
        },
        27987: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function() {
                function e() {}
                return e.prototype.handleError = function(e) {}, e
            }();
            t.NoopErrorHandler = r;
            var n = new r;
            t.setErrorHandler = function(e) {
                n = e
            }, t.getErrorHandler = function() {
                return n
            }, t.resetErrorHandler = function() {
                n = new r
            }
        },
        98125: function(e, t, r) {
            "use strict";

            function n(e) {
                for (var r in e) t.hasOwnProperty(r) || (t[r] = e[r])
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), n(r(27987)), n(r(99623)), n(r(46773))
        },
        46773: function(e, t, r) {
            "use strict";
            var n = this && this.__spreadArrays || function() {
                for (var e = 0, t = 0, r = arguments.length; t < r; t++) e += arguments[t].length;
                for (var n = Array(e), i = 0, t = 0; t < r; t++)
                    for (var o = arguments[t], a = 0, s = o.length; a < s; a++, i++) n[i] = o[a];
                return n
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var i = r(27987),
                o = r(27378),
                a = r(99623),
                s = {
                    NOTSET: 0,
                    DEBUG: 1,
                    INFO: 2,
                    WARNING: 3,
                    ERROR: 4
                };

            function l(e) {
                return "string" != typeof e ? e : ("WARN" === (e = e.toUpperCase()) && (e = "WARNING"), s[e]) ? s[e] : e
            }
            var u = function() {
                    function e() {
                        this.defaultLoggerFacade = new E, this.loggers = {}
                    }
                    return e.prototype.getLogger = function(e) {
                        return e ? (this.loggers[e] || (this.loggers[e] = new E({
                            messagePrefix: e
                        })), this.loggers[e]) : this.defaultLoggerFacade
                    }, e
                }(),
                c = function() {
                    function e(e) {
                        void 0 === e && (e = {}), this.logLevel = a.LogLevel.NOTSET, void 0 !== e.logLevel && o.isValidEnum(a.LogLevel, e.logLevel) && this.setLogLevel(e.logLevel), this.logToConsole = void 0 === e.logToConsole || !!e.logToConsole, this.prefix = void 0 !== e.prefix ? e.prefix : "[OPTIMIZELY]"
                    }
                    return e.prototype.log = function(e, t) {
                        if (this.shouldLog(e) && this.logToConsole) {
                            var r = this.prefix + " - " + this.getLogLevelName(e) + " " + this.getTime() + " " + t;
                            this.consoleLog(e, [r])
                        }
                    }, e.prototype.setLogLevel = function(e) {
                        e = l(e), o.isValidEnum(a.LogLevel, e) && void 0 !== e ? this.logLevel = e : this.logLevel = a.LogLevel.ERROR
                    }, e.prototype.getTime = function() {
                        return new Date().toISOString()
                    }, e.prototype.shouldLog = function(e) {
                        return e >= this.logLevel
                    }, e.prototype.getLogLevelName = function(e) {
                        switch (e) {
                            case a.LogLevel.DEBUG:
                                return "DEBUG";
                            case a.LogLevel.INFO:
                                return "INFO ";
                            case a.LogLevel.WARNING:
                                return "WARN ";
                            case a.LogLevel.ERROR:
                                return "ERROR";
                            default:
                                return "NOTSET"
                        }
                    }, e.prototype.consoleLog = function(e, t) {
                        switch (e) {
                            case a.LogLevel.DEBUG:
                                console.log.apply(console, t);
                                break;
                            case a.LogLevel.INFO:
                                console.info.apply(console, t);
                                break;
                            case a.LogLevel.WARNING:
                                console.warn.apply(console, t);
                                break;
                            case a.LogLevel.ERROR:
                                console.error.apply(console, t);
                                break;
                            default:
                                console.log.apply(console, t)
                        }
                    }, e
                }();
            t.ConsoleLogHandler = c;
            var d = a.LogLevel.NOTSET,
                f = null,
                E = function() {
                    function e(e) {
                        void 0 === e && (e = {}), this.messagePrefix = "", e.messagePrefix && (this.messagePrefix = e.messagePrefix)
                    }
                    return e.prototype.log = function(e, t) {
                        for (var r = [], n = 2; n < arguments.length; n++) r[n - 2] = arguments[n];
                        this.internalLog(l(e), {
                            message: t,
                            splat: r
                        })
                    }, e.prototype.info = function(e) {
                        for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                        this.namedLog(a.LogLevel.INFO, e, t)
                    }, e.prototype.debug = function(e) {
                        for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                        this.namedLog(a.LogLevel.DEBUG, e, t)
                    }, e.prototype.warn = function(e) {
                        for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                        this.namedLog(a.LogLevel.WARNING, e, t)
                    }, e.prototype.error = function(e) {
                        for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                        this.namedLog(a.LogLevel.ERROR, e, t)
                    }, e.prototype.format = function(e) {
                        return (this.messagePrefix ? this.messagePrefix + ": " : "") + o.sprintf.apply(void 0, n([e.message], e.splat))
                    }, e.prototype.internalLog = function(e, t) {
                        f && !(e < d) && (f.log(e, this.format(t)), t.error && t.error instanceof Error && i.getErrorHandler().handleError(t.error))
                    }, e.prototype.namedLog = function(e, t, r) {
                        if (t instanceof Error) {
                            t = (n = t).message, this.internalLog(e, {
                                error: n,
                                message: t,
                                splat: r
                            });
                            return
                        }
                        if (0 === r.length) {
                            this.internalLog(e, {
                                message: t,
                                splat: r
                            });
                            return
                        }
                        var n, i = r[r.length - 1];
                        i instanceof Error && (n = i, r.splice(-1)), this.internalLog(e, {
                            message: t,
                            error: n,
                            splat: r
                        })
                    }, e
                }(),
                p = new u;
            t.getLogger = function(e) {
                return p.getLogger(e)
            }, t.setLogHandler = function(e) {
                f = e
            }, t.setLogLevel = function(e) {
                e = l(e), d = o.isValidEnum(a.LogLevel, e) && void 0 !== e ? e : a.LogLevel.ERROR
            }, t.getLogLevel = function() {
                return d
            }, t.resetLogger = function() {
                p = new u, d = a.LogLevel.NOTSET
            }
        },
        99623: function(e, t) {
            "use strict";
            var r;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), (r = t.LogLevel || (t.LogLevel = {}))[r.NOTSET = 0] = "NOTSET", r[r.DEBUG = 1] = "DEBUG", r[r.INFO = 2] = "INFO", r[r.WARNING = 3] = "WARNING", r[r.ERROR = 4] = "ERROR"
        },
        27378: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n, i = r(29799);

            function o(e) {
                return Object.keys(e).map(function(t) {
                    return e[t]
                })
            }
            t.generateUUID = function() {
                return i.v4()
            }, t.getTimestamp = function() {
                return new Date().getTime()
            }, t.isValidEnum = function(e, t) {
                for (var r = !1, n = Object.keys(e), i = 0; i < n.length; i++)
                    if (t === e[n[i]]) {
                        r = !0;
                        break
                    }
                return r
            }, t.groupBy = function(e, t) {
                var r = {};
                return e.forEach(function(e) {
                    var n = t(e);
                    r[n] = r[n] || [], r[n].push(e)
                }), o(r)
            }, t.objectValues = o, t.objectEntries = function(e) {
                return Object.keys(e).map(function(t) {
                    return [t, e[t]]
                })
            }, t.find = function(e, t) {
                for (var r, n = 0; n < e.length; n++) {
                    var i = e[n];
                    if (t(i)) {
                        r = i;
                        break
                    }
                }
                return r
            }, t.keyBy = function(e, t) {
                var r = {};
                return e.forEach(function(e) {
                    r[t(e)] = e
                }), r
            }, t.sprintf = function(e) {
                for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                var n = 0;
                return e.replace(/%s/g, function() {
                    var e = t[n++],
                        r = typeof e;
                    return "function" === r ? e() : "string" === r ? e : String(e)
                })
            }, (n = t.NOTIFICATION_TYPES || (t.NOTIFICATION_TYPES = {})).ACTIVATE = "ACTIVATE:experiment, user_id,attributes, variation, event", n.DECISION = "DECISION:type, userId, attributes, decisionInfo", n.LOG_EVENT = "LOG_EVENT:logEvent", n.OPTIMIZELY_CONFIG_UPDATE = "OPTIMIZELY_CONFIG_UPDATE", n.TRACK = "TRACK:event_key, user_id, attributes, event_tags, event"
        },
        29799: function(e, t, r) {
            var n = r(3805),
                i = r(97385),
                o = i;
            o.v1 = n, o.v4 = i, e.exports = o
        },
        93577: function(e) {
            for (var t = [], r = 0; r < 256; ++r) t[r] = (r + 256).toString(16).substr(1);
            e.exports = function(e, r) {
                var n = r || 0;
                return [t[e[n++]], t[e[n++]], t[e[n++]], t[e[n++]], "-", t[e[n++]], t[e[n++]], "-", t[e[n++]], t[e[n++]], "-", t[e[n++]], t[e[n++]], "-", t[e[n++]], t[e[n++]], t[e[n++]], t[e[n++]], t[e[n++]], t[e[n++]]].join("")
            }
        },
        89694: function(e) {
            var t = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || "undefined" != typeof msCrypto && "function" == typeof window.msCrypto.getRandomValues && msCrypto.getRandomValues.bind(msCrypto);
            if (t) {
                var r = new Uint8Array(16);
                e.exports = function() {
                    return t(r), r
                }
            } else {
                var n = Array(16);
                e.exports = function() {
                    for (var e, t = 0; t < 16; t++)(3 & t) == 0 && (e = 4294967296 * Math.random()), n[t] = e >>> ((3 & t) << 3) & 255;
                    return n
                }
            }
        },
        3805: function(e, t, r) {
            var n, i, o = r(89694),
                a = r(93577),
                s = 0,
                l = 0;
            e.exports = function(e, t, r) {
                var u = t && r || 0,
                    c = t || [],
                    d = (e = e || {}).node || n,
                    f = void 0 !== e.clockseq ? e.clockseq : i;
                if (null == d || null == f) {
                    var E = o();
                    null == d && (d = n = [1 | E[0], E[1], E[2], E[3], E[4], E[5]]), null == f && (f = i = (E[6] << 8 | E[7]) & 16383)
                }
                var p = void 0 !== e.msecs ? e.msecs : new Date().getTime(),
                    g = void 0 !== e.nsecs ? e.nsecs : l + 1,
                    h = p - s + (g - l) / 1e4;
                if (h < 0 && void 0 === e.clockseq && (f = f + 1 & 16383), (h < 0 || p > s) && void 0 === e.nsecs && (g = 0), g >= 1e4) throw Error("uuid.v1(): Can't create more than 10M uuids/sec");
                s = p, l = g, i = f;
                var v = ((268435455 & (p += 122192928e5)) * 1e4 + g) % 4294967296;
                c[u++] = v >>> 24 & 255, c[u++] = v >>> 16 & 255, c[u++] = v >>> 8 & 255, c[u++] = 255 & v;
                var I = p / 4294967296 * 1e4 & 268435455;
                c[u++] = I >>> 8 & 255, c[u++] = 255 & I, c[u++] = I >>> 24 & 15 | 16, c[u++] = I >>> 16 & 255, c[u++] = f >>> 8 | 128, c[u++] = 255 & f;
                for (var _ = 0; _ < 6; ++_) c[u + _] = d[_];
                return t || a(c)
            }
        },
        97385: function(e, t, r) {
            var n = r(89694),
                i = r(93577);
            e.exports = function(e, t, r) {
                var o = t && r || 0;
                "string" == typeof e && (t = "binary" === e ? Array(16) : null, e = null);
                var a = (e = e || {}).random || (e.rng || n)();
                if (a[6] = 15 & a[6] | 64, a[8] = 63 & a[8] | 128, t)
                    for (var s = 0; s < 16; ++s) t[o + s] = a[s];
                return t || i(a)
            }
        },
        19889: function(e, t, r) {
            "use strict";

            function n(e) {
                return e && "object" == typeof e && "default" in e ? e.default : e
            }
            var i, o, a, s, l = r(98125),
                u = r(65001),
                c = n(r(29364)),
                d = n(r(58053)),
                f = r(62002),
                E = function() {
                    return (E = Object.assign || function(e) {
                        for (var t, r = 1, n = arguments.length; r < n; r++)
                            for (var i in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                        return e
                    }).apply(this, arguments)
                };

            function p() {
                for (var e = 0, t = 0, r = arguments.length; t < r; t++) e += arguments[t].length;
                var n = Array(e),
                    i = 0;
                for (t = 0; t < r; t++)
                    for (var o = arguments[t], a = 0, s = o.length; a < s; a++, i++) n[i] = o[a];
                return n
            }

            function g(e) {
                for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                if (!e) return {};
                if ("function" == typeof Object.assign) return Object.assign.apply(Object, p([e], t));
                for (var n = Object(e), i = 0; i < t.length; i++) {
                    var o = t[i];
                    if (null != o)
                        for (var a in o) Object.prototype.hasOwnProperty.call(o, a) && (n[a] = o[a])
                }
                return n
            }

            function h(e, t) {
                return e ? y(e, function(e) {
                    return e[t]
                }) : {}
            }

            function v(e) {
                return Object.keys(e).map(function(t) {
                    return e[t]
                })
            }

            function I(e) {
                return Object.keys(e).map(function(t) {
                    return [t, e[t]]
                })
            }

            function _(e, t) {
                for (var r, n = 0; n < e.length; n++) {
                    var i = e[n];
                    if (t(i)) {
                        r = i;
                        break
                    }
                }
                return r
            }

            function y(e, t) {
                var r = {};
                return e.forEach(function(e) {
                    r[t(e)] = e
                }), r
            }

            function R(e) {
                for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                var n = 0;
                return e.replace(/%s/g, function() {
                    var e = t[n++],
                        r = typeof e;
                    return "function" === r ? e() : "string" === r ? e : String(e)
                })
            }
            var N, O = {
                    assign: g,
                    currentTimestamp: function() {
                        return Math.round((new Date).getTime())
                    },
                    isSafeInteger: function(e) {
                        return "number" == typeof e && 9007199254740992 >= Math.abs(e)
                    },
                    keyBy: h,
                    uuid: function() {
                        return c()
                    },
                    isNumber: function(e) {
                        return "number" == typeof e
                    },
                    getTimestamp: function() {
                        return (new Date).getTime()
                    },
                    isValidEnum: function(e, t) {
                        for (var r = !1, n = Object.keys(e), i = 0; i < n.length; i++)
                            if (t === e[n[i]]) {
                                r = !0;
                                break
                            }
                        return r
                    },
                    groupBy: function(e, t) {
                        var r = {};
                        return e.forEach(function(e) {
                            var n = t(e);
                            r[n] = r[n] || [], r[n].push(e)
                        }), v(r)
                    },
                    objectValues: v,
                    objectEntries: I,
                    find: _,
                    keyByUtil: y,
                    sprintf: R
                },
                m = {
                    NOTSET: 0,
                    DEBUG: 1,
                    INFO: 2,
                    WARNING: 3,
                    ERROR: 4
                },
                T = {
                    CONDITION_EVALUATOR_ERROR: "%s: Error evaluating audience condition of type %s: %s",
                    DATAFILE_AND_SDK_KEY_MISSING: "%s: You must provide at least one of sdkKey or datafile. Cannot start Optimizely",
                    EXPERIMENT_KEY_NOT_IN_DATAFILE: "%s: Experiment key %s is not in datafile.",
                    FEATURE_NOT_IN_DATAFILE: "%s: Feature key %s is not in datafile.",
                    IMPROPERLY_FORMATTED_EXPERIMENT: "%s: Experiment key %s is improperly formatted.",
                    INVALID_ATTRIBUTES: "%s: Provided attributes are in an invalid format.",
                    INVALID_BUCKETING_ID: "%s: Unable to generate hash for bucketing ID %s: %s",
                    INVALID_DATAFILE: "%s: Datafile is invalid - property %s: %s",
                    INVALID_DATAFILE_MALFORMED: "%s: Datafile is invalid because it is malformed.",
                    INVALID_CONFIG: "%s: Provided Optimizely config is in an invalid format.",
                    INVALID_JSON: "%s: JSON object is not valid.",
                    INVALID_ERROR_HANDLER: '%s: Provided "errorHandler" is in an invalid format.',
                    INVALID_EVENT_DISPATCHER: '%s: Provided "eventDispatcher" is in an invalid format.',
                    INVALID_EVENT_TAGS: "%s: Provided event tags are in an invalid format.",
                    INVALID_EXPERIMENT_KEY: "%s: Experiment key %s is not in datafile. It is either invalid, paused, or archived.",
                    INVALID_EXPERIMENT_ID: "%s: Experiment ID %s is not in datafile.",
                    INVALID_GROUP_ID: "%s: Group ID %s is not in datafile.",
                    INVALID_LOGGER: '%s: Provided "logger" is in an invalid format.',
                    INVALID_ROLLOUT_ID: "%s: Invalid rollout ID %s attached to feature %s",
                    INVALID_USER_ID: "%s: Provided user ID is in an invalid format.",
                    INVALID_USER_PROFILE_SERVICE: "%s: Provided user profile service instance is in an invalid format: %s.",
                    NO_DATAFILE_SPECIFIED: "%s: No datafile specified. Cannot start optimizely.",
                    NO_JSON_PROVIDED: "%s: No JSON object to validate against schema.",
                    NO_VARIATION_FOR_EXPERIMENT_KEY: "%s: No variation key %s defined in datafile for experiment %s.",
                    UNDEFINED_ATTRIBUTE: "%s: Provided attribute: %s has an undefined value.",
                    UNRECOGNIZED_ATTRIBUTE: "%s: Unrecognized attribute %s provided. Pruning before sending event to Optimizely.",
                    UNABLE_TO_CAST_VALUE: "%s: Unable to cast value %s to type %s, returning null.",
                    USER_NOT_IN_FORCED_VARIATION: "%s: User %s is not in the forced variation map. Cannot remove their forced variation.",
                    USER_PROFILE_LOOKUP_ERROR: '%s: Error while looking up user profile for user ID "%s": %s.',
                    USER_PROFILE_SAVE_ERROR: '%s: Error while saving user profile for user ID "%s": %s.',
                    VARIABLE_KEY_NOT_IN_DATAFILE: '%s: Variable with key "%s" associated with feature with key "%s" is not in datafile.',
                    VARIATION_ID_NOT_IN_DATAFILE: "%s: No variation ID %s defined in datafile for experiment %s.",
                    VARIATION_ID_NOT_IN_DATAFILE_NO_EXPERIMENT: "%s: Variation ID %s is not in the datafile.",
                    INVALID_INPUT_FORMAT: "%s: Provided %s is in an invalid format.",
                    INVALID_DATAFILE_VERSION: "%s: This version of the JavaScript SDK does not support the given datafile version: %s",
                    INVALID_VARIATION_KEY: "%s: Provided variation key is in an invalid format."
                },
                A = {
                    ACTIVATE_USER: "%s: Activating user %s in experiment %s.",
                    DISPATCH_CONVERSION_EVENT: "%s: Dispatching conversion event to URL %s with params %s.",
                    DISPATCH_IMPRESSION_EVENT: "%s: Dispatching impression event to URL %s with params %s.",
                    DEPRECATED_EVENT_VALUE: "%s: Event value is deprecated in %s call.",
                    EVENT_KEY_NOT_FOUND: "%s: Event key %s is not in datafile.",
                    EXPERIMENT_NOT_RUNNING: "%s: Experiment %s is not running.",
                    FEATURE_ENABLED_FOR_USER: "%s: Feature %s is enabled for user %s.",
                    FEATURE_NOT_ENABLED_FOR_USER: "%s: Feature %s is not enabled for user %s.",
                    FEATURE_HAS_NO_EXPERIMENTS: "%s: Feature %s is not attached to any experiments.",
                    FAILED_TO_PARSE_VALUE: '%s: Failed to parse event value "%s" from event tags.',
                    FAILED_TO_PARSE_REVENUE: '%s: Failed to parse revenue value "%s" from event tags.',
                    FORCED_BUCKETING_FAILED: "%s: Variation key %s is not in datafile. Not activating user %s.",
                    INVALID_OBJECT: "%s: Optimizely object is not valid. Failing %s.",
                    INVALID_CLIENT_ENGINE: "%s: Invalid client engine passed: %s. Defaulting to node-sdk.",
                    INVALID_DEFAULT_DECIDE_OPTIONS: "%s: Provided default decide options is not an array.",
                    INVALID_DECIDE_OPTIONS: "%s: Provided decide options is not an array. Using default decide options.",
                    INVALID_VARIATION_ID: "%s: Bucketed into an invalid variation ID. Returning null.",
                    NOTIFICATION_LISTENER_EXCEPTION: "%s: Notification listener for (%s) threw exception: %s",
                    NO_ROLLOUT_EXISTS: "%s: There is no rollout of feature %s.",
                    NOT_ACTIVATING_USER: "%s: Not activating user %s for experiment %s.",
                    NOT_TRACKING_USER: "%s: Not tracking user %s.",
                    PARSED_REVENUE_VALUE: '%s: Parsed revenue value "%s" from event tags.',
                    PARSED_NUMERIC_VALUE: '%s: Parsed event value "%s" from event tags.',
                    RETURNING_STORED_VARIATION: '%s: Returning previously activated variation "%s" of experiment "%s" for user "%s" from user profile.',
                    ROLLOUT_HAS_NO_EXPERIMENTS: "%s: Rollout of feature %s has no experiments",
                    SAVED_VARIATION: '%s: Saved variation "%s" of experiment "%s" for user "%s".',
                    SAVED_VARIATION_NOT_FOUND: "%s: User %s was previously bucketed into variation with ID %s for experiment %s, but no matching variation was found.",
                    SHOULD_NOT_DISPATCH_ACTIVATE: '%s: Experiment %s is not in "Running" state. Not activating user.',
                    SKIPPING_JSON_VALIDATION: "%s: Skipping JSON schema validation.",
                    TRACK_EVENT: "%s: Tracking event %s for user %s.",
                    UNRECOGNIZED_DECIDE_OPTION: "%s: Unrecognized decide option %s provided.",
                    USER_ASSIGNED_TO_EXPERIMENT_BUCKET: "%s: Assigned bucket %s to user with bucketing ID %s.",
                    USER_BUCKETED_INTO_EXPERIMENT_IN_GROUP: "%s: User %s is in experiment %s of group %s.",
                    USER_BUCKETED_INTO_TARGETING_RULE: "%s: User %s bucketed into targeting rule %s.",
                    USER_IN_FEATURE_EXPERIMENT: "%s: User %s is in variation %s of experiment %s on the feature %s.",
                    USER_IN_ROLLOUT: "%s: User %s is in rollout of feature %s.",
                    USER_NOT_BUCKETED_INTO_EVERYONE_TARGETING_RULE: "%s: User %s not bucketed into everyone targeting rule due to traffic allocation.",
                    USER_NOT_BUCKETED_INTO_EXPERIMENT_IN_GROUP: "%s: User %s is not in experiment %s of group %s.",
                    USER_NOT_BUCKETED_INTO_ANY_EXPERIMENT_IN_GROUP: "%s: User %s is not in any experiment of group %s.",
                    USER_NOT_BUCKETED_INTO_TARGETING_RULE: "%s User %s not bucketed into targeting rule %s due to traffic allocation. Trying everyone rule.",
                    USER_NOT_IN_FEATURE_EXPERIMENT: "%s: User %s is not in any experiment on the feature %s.",
                    USER_NOT_IN_ROLLOUT: "%s: User %s is not in rollout of feature %s.",
                    USER_FORCED_IN_VARIATION: "%s: User %s is forced in variation %s.",
                    USER_MAPPED_TO_FORCED_VARIATION: "%s: Set variation %s for experiment %s and user %s in the forced variation map.",
                    USER_DOESNT_MEET_CONDITIONS_FOR_TARGETING_RULE: "%s: User %s does not meet conditions for targeting rule %s.",
                    USER_MEETS_CONDITIONS_FOR_TARGETING_RULE: "%s: User %s meets conditions for targeting rule %s.",
                    USER_HAS_VARIATION: "%s: User %s is in variation %s of experiment %s.",
                    USER_HAS_FORCED_DECISION_WITH_RULE_SPECIFIED: "Variation (%s) is mapped to flag (%s), rule (%s) and user (%s) in the forced decision map.",
                    USER_HAS_FORCED_DECISION_WITH_NO_RULE_SPECIFIED: "Variation (%s) is mapped to flag (%s) and user (%s) in the forced decision map.",
                    USER_HAS_FORCED_DECISION_WITH_RULE_SPECIFIED_BUT_INVALID: "Invalid variation is mapped to flag (%s), rule (%s) and user (%s) in the forced decision map.",
                    USER_HAS_FORCED_DECISION_WITH_NO_RULE_SPECIFIED_BUT_INVALID: "Invalid variation is mapped to flag (%s) and user (%s) in the forced decision map.",
                    USER_HAS_FORCED_VARIATION: "%s: Variation %s is mapped to experiment %s and user %s in the forced variation map.",
                    USER_HAS_NO_VARIATION: "%s: User %s is in no variation of experiment %s.",
                    USER_HAS_NO_FORCED_VARIATION: "%s: User %s is not in the forced variation map.",
                    USER_HAS_NO_FORCED_VARIATION_FOR_EXPERIMENT: "%s: No experiment %s mapped to user %s in the forced variation map.",
                    USER_NOT_IN_ANY_EXPERIMENT: "%s: User %s is not in any experiment of group %s.",
                    USER_NOT_IN_EXPERIMENT: "%s: User %s does not meet conditions to be in experiment %s.",
                    USER_RECEIVED_DEFAULT_VARIABLE_VALUE: '%s: User "%s" is not in any variation or rollout rule. Returning default value for variable "%s" of feature flag "%s".',
                    FEATURE_NOT_ENABLED_RETURN_DEFAULT_VARIABLE_VALUE: '%s: Feature "%s" is not enabled for user %s. Returning the default variable value "%s".',
                    VARIABLE_NOT_USED_RETURN_DEFAULT_VARIABLE_VALUE: '%s: Variable "%s" is not used in variation "%s". Returning default value.',
                    USER_RECEIVED_VARIABLE_VALUE: '%s: Got variable value "%s" for variable "%s" of feature flag "%s"',
                    VALID_DATAFILE: "%s: Datafile is valid.",
                    VALID_USER_PROFILE_SERVICE: "%s: Valid user profile service provided.",
                    VARIATION_REMOVED_FOR_USER: "%s: Variation mapped to experiment %s has been removed for user %s.",
                    VARIABLE_REQUESTED_WITH_WRONG_TYPE: '%s: Requested variable type "%s", but variable is of type "%s". Use correct API to retrieve value. Returning None.',
                    VALID_BUCKETING_ID: '%s: BucketingId is valid: "%s"',
                    BUCKETING_ID_NOT_STRING: "%s: BucketingID attribute is not a string. Defaulted to userId",
                    EVALUATING_AUDIENCE: '%s: Starting to evaluate audience "%s" with conditions: %s.',
                    EVALUATING_AUDIENCES_COMBINED: '%s: Evaluating audiences for %s "%s": %s.',
                    AUDIENCE_EVALUATION_RESULT: '%s: Audience "%s" evaluated to %s.',
                    AUDIENCE_EVALUATION_RESULT_COMBINED: "%s: Audiences for %s %s collectively evaluated to %s.",
                    MISSING_ATTRIBUTE_VALUE: '%s: Audience condition %s evaluated to UNKNOWN because no value was passed for user attribute "%s".',
                    UNEXPECTED_CONDITION_VALUE: "%s: Audience condition %s evaluated to UNKNOWN because the condition value is not supported.",
                    UNEXPECTED_TYPE: '%s: Audience condition %s evaluated to UNKNOWN because a value of type "%s" was passed for user attribute "%s".',
                    UNEXPECTED_TYPE_NULL: '%s: Audience condition %s evaluated to UNKNOWN because a null value was passed for user attribute "%s".',
                    UNKNOWN_CONDITION_TYPE: "%s: Audience condition %s has an unknown condition type. You may need to upgrade to a newer release of the Optimizely SDK.",
                    UNKNOWN_MATCH_TYPE: "%s: Audience condition %s uses an unknown match type. You may need to upgrade to a newer release of the Optimizely SDK.",
                    UPDATED_OPTIMIZELY_CONFIG: "%s: Updated Optimizely config to revision %s (project id %s)",
                    OUT_OF_BOUNDS: '%s: Audience condition %s evaluated to UNKNOWN because the number value for user attribute "%s" is not in the range [-2^53, +2^53].',
                    UNABLE_TO_ATTACH_UNLOAD: '%s: unable to bind optimizely.close() to page unload event: "%s"'
                },
                D = {
                    BOT_FILTERING: "$opt_bot_filtering",
                    BUCKETING_ID: "$opt_bucketing_id",
                    STICKY_BUCKETING_KEY: "$opt_experiment_bucket_map",
                    USER_AGENT: "$opt_user_agent",
                    FORCED_DECISION_NULL_RULE_KEY: "$opt_null_rule_key"
                },
                S = {
                    AB_TEST: "ab-test",
                    FEATURE: "feature",
                    FEATURE_TEST: "feature-test",
                    FEATURE_VARIABLE: "feature-variable",
                    ALL_FEATURE_VARIABLES: "all-feature-variables",
                    FLAG: "flag"
                },
                L = {
                    FEATURE_TEST: "feature-test",
                    ROLLOUT: "rollout",
                    EXPERIMENT: "experiment"
                },
                U = {
                    RULE: "rule",
                    EXPERIMENT: "experiment"
                },
                C = {
                    BOOLEAN: "boolean",
                    DOUBLE: "double",
                    INTEGER: "integer",
                    STRING: "string",
                    JSON: "json"
                },
                b = {
                    V2: "2",
                    V3: "3",
                    V4: "4"
                },
                P = {
                    SDK_NOT_READY: "Optimizely SDK not configured properly yet.",
                    FLAG_KEY_INVALID: 'No flag was found for key "%s".',
                    VARIABLE_VALUE_INVALID: 'Variable value for key "%s" is invalid or wrong type.'
                };
            (i = N || (N = {})).ACTIVATE = "ACTIVATE:experiment, user_id,attributes, variation, event", i.DECISION = "DECISION:type, userId, attributes, decisionInfo", i.LOG_EVENT = "LOG_EVENT:logEvent", i.OPTIMIZELY_CONFIG_UPDATE = "OPTIMIZELY_CONFIG_UPDATE", i.TRACK = "TRACK:event_key, user_id, attributes, event_tags, event", Object.freeze({
                __proto__: null,
                LOG_LEVEL: m,
                ERROR_MESSAGES: T,
                LOG_MESSAGES: A,
                CONTROL_ATTRIBUTES: D,
                JAVASCRIPT_CLIENT_ENGINE: "javascript-sdk",
                NODE_CLIENT_ENGINE: "node-sdk",
                REACT_CLIENT_ENGINE: "react-sdk",
                REACT_NATIVE_CLIENT_ENGINE: "react-native-sdk",
                REACT_NATIVE_JS_CLIENT_ENGINE: "react-native-js-sdk",
                BROWSER_CLIENT_VERSION: "4.9.3",
                NODE_CLIENT_VERSION: "4.9.3",
                DECISION_NOTIFICATION_TYPES: S,
                DECISION_SOURCES: L,
                AUDIENCE_EVALUATION_TYPES: U,
                FEATURE_VARIABLE_TYPES: C,
                DATAFILE_VERSIONS: b,
                DECISION_MESSAGES: P,
                get NOTIFICATION_TYPES() {
                    return N
                }
            });
            var V = "CONFIG_VALIDATOR",
                F = [b.V2, b.V3, b.V4],
                M = function(e) {
                    if ("object" == typeof e && null !== e) {
                        var t = e.errorHandler,
                            r = e.eventDispatcher,
                            n = e.logger;
                        if (t && "function" != typeof t.handleError) throw Error(R(T.INVALID_ERROR_HANDLER, V));
                        if (r && "function" != typeof r.dispatchEvent) throw Error(R(T.INVALID_EVENT_DISPATCHER, V));
                        if (n && "function" != typeof n.log) throw Error(R(T.INVALID_LOGGER, V));
                        return !0
                    }
                    throw Error(R(T.INVALID_CONFIG, V))
                },
                x = function(e) {
                    if (!e) throw Error(R(T.NO_DATAFILE_SPECIFIED, V));
                    if ("string" == typeof e) try {
                        e = JSON.parse(e)
                    } catch (e) {
                        throw Error(R(T.INVALID_DATAFILE_MALFORMED, V))
                    }
                    if ("object" == typeof e && !Array.isArray(e) && null !== e && -1 === F.indexOf(e.version)) throw Error(R(T.INVALID_DATAFILE_VERSION, V, e.version));
                    return e
                },
                w = {
                    dispatchEvent: function(e, t) {
                        var r, n = e.params,
                            i = e.url;
                        "POST" === e.httpVerb ? ((r = new XMLHttpRequest).open("POST", i, !0), r.setRequestHeader("Content-Type", "application/json"), r.onreadystatechange = function() {
                            if (4 === r.readyState && t && "function" == typeof t) try {
                                t({
                                    statusCode: r.status
                                })
                            } catch (e) {}
                        }, r.send(JSON.stringify(n))) : (i += "?wxhr=true", n && (i += "&" + Object.keys(n).map(function(e) {
                            return encodeURIComponent(e) + "=" + encodeURIComponent(n[e])
                        }).join("&")), (r = new XMLHttpRequest).open("GET", i, !0), r.onreadystatechange = function() {
                            if (4 === r.readyState && t && "function" == typeof t) try {
                                t({
                                    statusCode: r.status
                                })
                            } catch (e) {}
                        }, r.send())
                    }
                },
                k = function() {
                    function e() {}
                    return e.prototype.log = function() {}, e
                }();

            function B(e) {
                return new l.ConsoleLogHandler(e)
            }

            function K(e, t, r) {
                return {
                    variationKey: null,
                    enabled: !1,
                    variables: {},
                    ruleKey: null,
                    flagKey: e,
                    userContext: t,
                    reasons: r
                }
            }
            Object.freeze({
                __proto__: null,
                NoOpLogger: k,
                createLogger: B,
                createNoOpLogger: function() {
                    return new k
                }
            }), (s = o || (o = {})).BOOLEAN = "boolean", s.DOUBLE = "double", s.INTEGER = "integer", s.STRING = "string", s.JSON = "json", (a = t.N1 || (t.N1 = {})).DISABLE_DECISION_EVENT = "DISABLE_DECISION_EVENT", a.ENABLED_FLAGS_ONLY = "ENABLED_FLAGS_ONLY", a.IGNORE_USER_PROFILE_SERVICE = "IGNORE_USER_PROFILE_SERVICE", a.INCLUDE_REASONS = "INCLUDE_REASONS", a.EXCLUDE_VARIABLES = "EXCLUDE_VARIABLES";
            var G = function() {
                    function e(e) {
                        var t, r = e.optimizely,
                            n = e.userId,
                            i = e.attributes;
                        this.optimizely = r, this.userId = n, this.attributes = null !== (t = E({}, i)) && void 0 !== t ? t : {}, this.forcedDecisionsMap = {}
                    }
                    return e.prototype.setAttribute = function(e, t) {
                        this.attributes[e] = t
                    }, e.prototype.getUserId = function() {
                        return this.userId
                    }, e.prototype.getAttributes = function() {
                        return E({}, this.attributes)
                    }, e.prototype.getOptimizely = function() {
                        return this.optimizely
                    }, e.prototype.decide = function(e, t) {
                        return void 0 === t && (t = []), this.optimizely.decide(this.cloneUserContext(), e, t)
                    }, e.prototype.decideForKeys = function(e, t) {
                        return void 0 === t && (t = []), this.optimizely.decideForKeys(this.cloneUserContext(), e, t)
                    }, e.prototype.decideAll = function(e) {
                        return void 0 === e && (e = []), this.optimizely.decideAll(this.cloneUserContext(), e)
                    }, e.prototype.trackEvent = function(e, t) {
                        this.optimizely.track(e, this.userId, this.attributes, t)
                    }, e.prototype.setForcedDecision = function(e, t) {
                        var r, n = e.flagKey,
                            i = null !== (r = e.ruleKey) && void 0 !== r ? r : D.FORCED_DECISION_NULL_RULE_KEY,
                            o = {
                                variationKey: t.variationKey
                            };
                        return this.forcedDecisionsMap[n] || (this.forcedDecisionsMap[n] = {}), this.forcedDecisionsMap[n][i] = o, !0
                    }, e.prototype.getForcedDecision = function(e) {
                        return this.findForcedDecision(e)
                    }, e.prototype.removeForcedDecision = function(e) {
                        var t, r = null !== (t = e.ruleKey) && void 0 !== t ? t : D.FORCED_DECISION_NULL_RULE_KEY,
                            n = e.flagKey,
                            i = !1;
                        return this.forcedDecisionsMap.hasOwnProperty(n) && (this.forcedDecisionsMap[n].hasOwnProperty(r) && (delete this.forcedDecisionsMap[n][r], i = !0), 0 === Object.keys(this.forcedDecisionsMap[n]).length && delete this.forcedDecisionsMap[n]), i
                    }, e.prototype.removeAllForcedDecisions = function() {
                        return this.forcedDecisionsMap = {}, !0
                    }, e.prototype.findForcedDecision = function(e) {
                        var t, r = null !== (t = e.ruleKey) && void 0 !== t ? t : D.FORCED_DECISION_NULL_RULE_KEY,
                            n = e.flagKey;
                        if (this.forcedDecisionsMap.hasOwnProperty(e.flagKey)) {
                            var i = this.forcedDecisionsMap[n];
                            if (i.hasOwnProperty(r)) return {
                                variationKey: i[r].variationKey
                            }
                        }
                        return null
                    }, e.prototype.cloneUserContext = function() {
                        var t = new e({
                            optimizely: this.getOptimizely(),
                            userId: this.getUserId(),
                            attributes: this.getAttributes()
                        });
                        return Object.keys(this.forcedDecisionsMap).length > 0 && (t.forcedDecisionsMap = E({}, this.forcedDecisionsMap)), t
                    }, e
                }(),
                j = ["and", "or", "not"];

            function H(e, t) {
                if (Array.isArray(e)) {
                    var r = e[0],
                        n = e.slice(1);
                    switch ("string" == typeof r && -1 === j.indexOf(r) && (r = "or", n = e), r) {
                        case "and":
                            return function(e, t) {
                                var r = !1;
                                if (Array.isArray(e)) {
                                    for (var n = 0; n < e.length; n++) {
                                        var i = H(e[n], t);
                                        if (!1 === i) return !1;
                                        null === i && (r = !0)
                                    }
                                    return !r || null
                                }
                                return null
                            }(n, t);
                        case "not":
                            return function(e, t) {
                                if (Array.isArray(e) && e.length > 0) {
                                    var r = H(e[0], t);
                                    return null === r ? null : !r
                                }
                                return null
                            }(n, t);
                        default:
                            return function(e, t) {
                                var r = !1;
                                if (Array.isArray(e)) {
                                    for (var n = 0; n < e.length; n++) {
                                        var i = H(e[n], t);
                                        if (!0 === i) return !0;
                                        null === i && (r = !0)
                                    }
                                    return !!r && null
                                }
                                return null
                            }(n, t)
                    }
                }
                return t(e)
            }
            var Y = function() {
                    function e(t, r) {
                        this.sdkKey = null !== (n = t.sdkKey) && void 0 !== n ? n : "", this.environmentKey = null !== (i = t.environmentKey) && void 0 !== i ? i : "", this.attributes = t.attributes, this.audiences = e.getAudiences(t), this.events = t.events, this.revision = t.revision;
                        var n, i, o = (t.featureFlags || []).reduce(function(e, t) {
                                return e[t.id] = t.variables, e
                            }, {}),
                            a = e.getExperimentsMapById(t, o);
                        this.experimentsMap = e.getExperimentsKeyMap(a), this.featuresMap = e.getFeaturesMap(t, o, a), this.datafile = r
                    }
                    return e.prototype.getDatafile = function() {
                        return this.datafile
                    }, e.getAudiences = function(e) {
                        var t = [],
                            r = [];
                        return (e.typedAudiences || []).forEach(function(e) {
                            t.push({
                                id: e.id,
                                conditions: JSON.stringify(e.conditions),
                                name: e.name
                            }), r.push(e.id)
                        }), (e.audiences || []).forEach(function(e) {
                            -1 === r.indexOf(e.id) && "$opt_dummy_audience" != e.id && t.push({
                                id: e.id,
                                conditions: JSON.stringify(e.conditions),
                                name: e.name
                            })
                        }), t
                    }, e.getSerializedAudiences = function(t, r) {
                        var n = "";
                        if (t) {
                            var i = "";
                            t.forEach(function(t) {
                                var o = "";
                                if (t instanceof Array) o = "(" + (o = e.getSerializedAudiences(t, r)) + ")";
                                else if (j.indexOf(t) > -1) i = t.toUpperCase();
                                else {
                                    var a = r[t] ? r[t].name : t;
                                    n || "NOT" === i ? (i = "" === i ? "OR" : i, n = "" === n ? i + ' "' + r[t].name + '"' : n.concat(" " + i + ' "' + a + '"')) : n = '"' + a + '"'
                                }
                                "" !== o && ("" !== n || "NOT" === i ? (i = "" === i ? "OR" : i, n = "" === n ? i + " " + o : n.concat(" " + i + " " + o)) : n = n.concat(o))
                            })
                        }
                        return n
                    }, e.getExperimentAudiences = function(t, r) {
                        return t.audienceConditions ? e.getSerializedAudiences(t.audienceConditions, r.audiencesById) : ""
                    }, e.mergeFeatureVariables = function(e, t, r, n, i) {
                        var o = (e[r] || []).reduce(function(e, t) {
                            return e[t.key] = {
                                id: t.id,
                                key: t.key,
                                type: t.type,
                                value: t.defaultValue
                            }, e
                        }, {});
                        return (n || []).forEach(function(e) {
                            var r = t[e.id],
                                n = {
                                    id: e.id,
                                    key: r.key,
                                    type: r.type,
                                    value: i ? e.value : r.defaultValue
                                };
                            o[r.key] = n
                        }), o
                    }, e.getVariationsMap = function(t, r, n, i) {
                        return t.reduce(function(t, o) {
                            var a = e.mergeFeatureVariables(r, n, i, o.variables, o.featureEnabled);
                            return t[o.key] = {
                                id: o.id,
                                key: o.key,
                                featureEnabled: o.featureEnabled,
                                variablesMap: a
                            }, t
                        }, {})
                    }, e.getVariableIdMap = function(e) {
                        return (e.featureFlags || []).reduce(function(e, t) {
                            return t.variables.forEach(function(t) {
                                e[t.id] = t
                            }), e
                        }, {})
                    }, e.getDeliveryRules = function(t, r, n, i) {
                        var o = e.getVariableIdMap(t);
                        return i.map(function(i) {
                            return {
                                id: i.id,
                                key: i.key,
                                audiences: e.getExperimentAudiences(i, t),
                                variationsMap: e.getVariationsMap(i.variations, r, o, n)
                            }
                        })
                    }, e.getRolloutExperimentIds = function(e) {
                        var t = [];
                        return (e || []).forEach(function(e) {
                            e.experiments.forEach(function(e) {
                                t.push(e.id)
                            })
                        }), t
                    }, e.getExperimentsMapById = function(t, r) {
                        var n = e.getVariableIdMap(t),
                            i = this.getRolloutExperimentIds(t.rollouts);
                        return (t.experiments || []).reduce(function(o, a) {
                            if (-1 === i.indexOf(a.id)) {
                                var s = t.experimentFeatureMap[a.id],
                                    l = "";
                                s && s.length > 0 && (l = s[0]);
                                var u = e.getVariationsMap(a.variations, r, n, l.toString());
                                o[a.id] = {
                                    id: a.id,
                                    key: a.key,
                                    audiences: e.getExperimentAudiences(a, t),
                                    variationsMap: u
                                }
                            }
                            return o
                        }, {})
                    }, e.getExperimentsKeyMap = function(e) {
                        var t = {};
                        for (var r in e) {
                            var n = e[r];
                            t[n.key] = n
                        }
                        return t
                    }, e.getFeaturesMap = function(t, r, n) {
                        var i = {};
                        return t.featureFlags.forEach(function(o) {
                            var a = {},
                                s = [];
                            o.experimentIds.forEach(function(e) {
                                var t = n[e];
                                t && (a[t.key] = t), s.push(n[e])
                            });
                            var l = (o.variables || []).reduce(function(e, t) {
                                    return e[t.key] = {
                                        id: t.id,
                                        key: t.key,
                                        type: t.type,
                                        value: t.defaultValue
                                    }, e
                                }, {}),
                                u = [],
                                c = t.rolloutIdMap[o.rolloutId];
                            c && (u = e.getDeliveryRules(t, r, o.id, c.experiments)), i[o.key] = {
                                id: o.id,
                                key: o.key,
                                experimentRules: s,
                                deliveryRules: u,
                                experimentsMap: a,
                                variablesMap: l
                            }
                        }), i
                    }, e
                }(),
                Z = "PROJECT_CONFIG",
                z = function(e, t) {
                    void 0 === t && (t = null);
                    var r, n, i, o = ((i = g({}, e)).audiences = (e.audiences || []).map(function(e) {
                        return g({}, e)
                    }), i.experiments = (e.experiments || []).map(function(e) {
                        return g({}, e)
                    }), i.featureFlags = (e.featureFlags || []).map(function(e) {
                        return g({}, e)
                    }), i.groups = (e.groups || []).map(function(e) {
                        var t = g({}, e);
                        return t.experiments = (e.experiments || []).map(function(e) {
                            return g({}, e)
                        }), t
                    }), i.rollouts = (e.rollouts || []).map(function(e) {
                        var t = g({}, e);
                        return t.experiments = (e.experiments || []).map(function(e) {
                            return g({}, e)
                        }), t
                    }), i.environmentKey = null !== (r = e.environmentKey) && void 0 !== r ? r : "", i.sdkKey = null !== (n = e.sdkKey) && void 0 !== n ? n : "", i);
                    return o.__datafileStr = null === t ? JSON.stringify(e) : t, (o.audiences || []).forEach(function(e) {
                        e.conditions = JSON.parse(e.conditions)
                    }), o.audiencesById = h(o.audiences, "id"), g(o.audiencesById, h(o.typedAudiences, "id")), o.attributeKeyMap = h(o.attributes, "key"), o.eventKeyMap = h(o.events, "key"), o.groupIdMap = h(o.groups, "id"), Object.keys(o.groupIdMap || {}).forEach(function(e) {
                        (o.groupIdMap[e].experiments || []).forEach(function(t) {
                            o.experiments.push(g(t, {
                                groupId: e
                            }))
                        })
                    }), o.rolloutIdMap = h(o.rollouts || [], "id"), v(o.rolloutIdMap || {}).forEach(function(e) {
                        (e.experiments || []).forEach(function(e) {
                            o.experiments.push(e), e.variationKeyMap = h(e.variations, "key")
                        })
                    }), o.experimentKeyMap = h(o.experiments, "key"), o.experimentIdMap = h(o.experiments, "id"), o.variationIdMap = {}, o.variationVariableUsageMap = {}, (o.experiments || []).forEach(function(e) {
                        e.variationKeyMap = h(e.variations, "key"), g(o.variationIdMap, h(e.variations, "id")), v(e.variationKeyMap || {}).forEach(function(e) {
                            e.variables && (o.variationVariableUsageMap[e.id] = h(e.variables, "id"))
                        })
                    }), o.experimentFeatureMap = {}, o.featureKeyMap = h(o.featureFlags || [], "key"), v(o.featureKeyMap || {}).forEach(function(e) {
                        e.variables.forEach(function(e) {
                            e.type === C.STRING && e.subType === C.JSON && (e.type = C.JSON, delete e.subType)
                        }), e.variableKeyMap = h(e.variables, "key"), (e.experimentIds || []).forEach(function(t) {
                            o.experimentFeatureMap[t] ? o.experimentFeatureMap[t].push(e.id) : o.experimentFeatureMap[t] = [e.id]
                        })
                    }), o.flagRulesMap = {}, (o.featureFlags || []).forEach(function(e) {
                        var t = [];
                        e.experimentIds.forEach(function(e) {
                            var r = o.experimentIdMap[e];
                            r && t.push(r)
                        });
                        var r = o.rolloutIdMap[e.rolloutId];
                        r && t.push.apply(t, r.experiments), o.flagRulesMap[e.key] = t
                    }), o.flagVariationsMap = {}, I(o.flagRulesMap || {}).forEach(function(e) {
                        var t = e[0],
                            r = e[1],
                            n = [];
                        r.forEach(function(e) {
                            e.variations.forEach(function(e) {
                                _(n, function(t) {
                                    return t.id === e.id
                                }) || n.push(e)
                            })
                        }), o.flagVariationsMap[t] = n
                    }), o
                },
                X = function(e, t) {
                    var r = e.experimentIdMap[t];
                    if (!r) throw Error(R(T.INVALID_EXPERIMENT_ID, Z, t));
                    return r.layerId
                },
                q = function(e, t, r) {
                    var n = e.attributeKeyMap[t],
                        i = 0 === t.indexOf("$opt_");
                    return n ? (i && r.log(m.WARNING, "Attribute %s unexpectedly has reserved prefix %s; using attribute ID instead of reserved attribute name.", t, "$opt_"), n.id) : i ? t : (r.log(m.DEBUG, T.UNRECOGNIZED_ATTRIBUTE, Z, t), null)
                },
                W = function(e, t) {
                    var r = e.eventKeyMap[t];
                    return r ? r.id : null
                },
                J = function(e, t) {
                    var r = e.experimentKeyMap[t];
                    if (!r) throw Error(R(T.INVALID_EXPERIMENT_KEY, Z, t));
                    return r.status
                },
                $ = function(e, t) {
                    return e.variationIdMap.hasOwnProperty(t) ? e.variationIdMap[t].key : null
                },
                Q = function(e, t) {
                    if (e.experimentKeyMap.hasOwnProperty(t)) {
                        var r = e.experimentKeyMap[t];
                        if (r) return r
                    }
                    throw Error(R(T.EXPERIMENT_KEY_NOT_IN_DATAFILE, Z, t))
                },
                ee = function(e, t) {
                    var r = e.experimentIdMap[t];
                    if (!r) throw Error(R(T.INVALID_EXPERIMENT_ID, Z, t));
                    return r.trafficAllocation
                },
                et = function(e, t, r) {
                    if (e.experimentIdMap.hasOwnProperty(t)) {
                        var n = e.experimentIdMap[t];
                        if (n) return n
                    }
                    return r.log(m.ERROR, T.INVALID_EXPERIMENT_ID, Z, t), null
                },
                er = function(e, t, r) {
                    return e && _(e.flagVariationsMap[t], function(e) {
                        return e.key === r
                    }) || null
                },
                en = function(e, t, r) {
                    if (e.featureKeyMap.hasOwnProperty(t)) {
                        var n = e.featureKeyMap[t];
                        if (n) return n
                    }
                    return r.log(m.ERROR, T.FEATURE_NOT_IN_DATAFILE, Z, t), null
                },
                ei = function(e) {
                    return e.__datafileStr
                },
                eo = function(e) {
                    try {
                        t = x(e.datafile)
                    } catch (e) {
                        return {
                            configObj: null,
                            error: e
                        }
                    }
                    if (e.jsonSchemaValidator) try {
                        e.jsonSchemaValidator.validate(t), e.logger.log(m.INFO, A.VALID_DATAFILE, Z)
                    } catch (e) {
                        return {
                            configObj: null,
                            error: e
                        }
                    } else e.logger.log(m.INFO, A.SKIPPING_JSON_VALIDATION, Z);
                    var t, r = [t];
                    return "string" == typeof e.datafile && r.push(e.datafile), {
                        configObj: z.apply(void 0, r),
                        error: null
                    }
                },
                ea = function(e) {
                    return !!e.sendFlagDecisions
                },
                es = l.getLogger();

            function el(e, t) {
                return e instanceof Error ? e.message : t || "Unknown error"
            }
            var eu = function() {
                    function e(e) {
                        this.updateListeners = [], this.configObj = null, this.optimizelyConfigObj = null, this.datafileManager = null;
                        try {
                            if (this.jsonSchemaValidator = e.jsonSchemaValidator, !e.datafile && !e.sdkKey) {
                                var t = Error(R(T.DATAFILE_AND_SDK_KEY_MISSING, "PROJECT_CONFIG_MANAGER"));
                                return this.readyPromise = Promise.resolve({
                                    success: !1,
                                    reason: el(t)
                                }), void es.error(t)
                            }
                            var r = null;
                            e.datafile && (r = this.handleNewDatafile(e.datafile)), e.sdkKey && e.datafileManager ? (this.datafileManager = e.datafileManager, this.datafileManager.start(), this.readyPromise = this.datafileManager.onReady().then(this.onDatafileManagerReadyFulfill.bind(this), this.onDatafileManagerReadyReject.bind(this)), this.datafileManager.on("update", this.onDatafileManagerUpdate.bind(this))) : this.configObj ? this.readyPromise = Promise.resolve({
                                success: !0
                            }) : this.readyPromise = Promise.resolve({
                                success: !1,
                                reason: el(r, "Invalid datafile")
                            })
                        } catch (e) {
                            es.error(e), this.readyPromise = Promise.resolve({
                                success: !1,
                                reason: el(e, "Error in initialize")
                            })
                        }
                    }
                    return e.prototype.onDatafileManagerReadyFulfill = function() {
                        if (this.datafileManager) {
                            var e = this.handleNewDatafile(this.datafileManager.get());
                            return e ? {
                                success: !1,
                                reason: el(e)
                            } : {
                                success: !0
                            }
                        }
                        return {
                            success: !1,
                            reason: el(null, "Datafile manager is not provided")
                        }
                    }, e.prototype.onDatafileManagerReadyReject = function(e) {
                        return {
                            success: !1,
                            reason: el(e, "Failed to become ready")
                        }
                    }, e.prototype.onDatafileManagerUpdate = function() {
                        this.datafileManager && this.handleNewDatafile(this.datafileManager.get())
                    }, e.prototype.handleNewDatafile = function(e) {
                        var t = eo({
                                datafile: e,
                                jsonSchemaValidator: this.jsonSchemaValidator,
                                logger: es
                            }),
                            r = t.configObj,
                            n = t.error;
                        if (n) es.error(n);
                        else {
                            var i = this.configObj ? this.configObj.revision : "null";
                            r && i !== r.revision && (this.configObj = r, this.optimizelyConfigObj = null, this.updateListeners.forEach(function(e) {
                                return e(r)
                            }))
                        }
                        return n
                    }, e.prototype.getConfig = function() {
                        return this.configObj
                    }, e.prototype.getOptimizelyConfig = function() {
                        var e, t;
                        return !this.optimizelyConfigObj && this.configObj && (this.optimizelyConfigObj = (e = this.configObj, t = ei(this.configObj), new Y(e, t))), this.optimizelyConfigObj
                    }, e.prototype.onReady = function() {
                        return this.readyPromise
                    }, e.prototype.onUpdate = function(e) {
                        var t = this;
                        return this.updateListeners.push(e),
                            function() {
                                var r = t.updateListeners.indexOf(e);
                                r > -1 && t.updateListeners.splice(r, 1)
                            }
                    }, e.prototype.stop = function() {
                        this.datafileManager && this.datafileManager.stop(), this.updateListeners = []
                    }, e
                }(),
                ec = function(e) {
                    var t = [],
                        r = e.experimentIdMap[e.experimentId].groupId;
                    if (r) {
                        var n = e.groupIdMap[r];
                        if (!n) throw Error(R(T.INVALID_GROUP_ID, "BUCKETER", r));
                        if ("random" === n.policy) {
                            var i = ed(n, e.bucketingId, e.userId, e.logger);
                            if (null === i) return e.logger.log(m.INFO, A.USER_NOT_IN_ANY_EXPERIMENT, "BUCKETER", e.userId, r), t.push([A.USER_NOT_IN_ANY_EXPERIMENT, "BUCKETER", e.userId, r]), {
                                result: null,
                                reasons: t
                            };
                            if (i !== e.experimentId) return e.logger.log(m.INFO, A.USER_NOT_BUCKETED_INTO_EXPERIMENT_IN_GROUP, "BUCKETER", e.userId, e.experimentKey, r), t.push([A.USER_NOT_BUCKETED_INTO_EXPERIMENT_IN_GROUP, "BUCKETER", e.userId, e.experimentKey, r]), {
                                result: null,
                                reasons: t
                            };
                            e.logger.log(m.INFO, A.USER_BUCKETED_INTO_EXPERIMENT_IN_GROUP, "BUCKETER", e.userId, e.experimentKey, r), t.push([A.USER_BUCKETED_INTO_EXPERIMENT_IN_GROUP, "BUCKETER", e.userId, e.experimentKey, r])
                        }
                    }
                    var o = eE("" + e.bucketingId + e.experimentId);
                    e.logger.log(m.DEBUG, A.USER_ASSIGNED_TO_EXPERIMENT_BUCKET, "BUCKETER", o, e.userId), t.push([A.USER_ASSIGNED_TO_EXPERIMENT_BUCKET, "BUCKETER", o, e.userId]);
                    var a = ef(o, e.trafficAllocationConfig);
                    return null === a || e.variationIdMap[a] ? {
                        result: a,
                        reasons: t
                    } : (a && (e.logger.log(m.WARNING, A.INVALID_VARIATION_ID, "BUCKETER"), t.push([A.INVALID_VARIATION_ID, "BUCKETER"])), {
                        result: null,
                        reasons: t
                    })
                },
                ed = function(e, t, r, n) {
                    var i = eE("" + t + e.id);
                    return n.log(m.DEBUG, A.USER_ASSIGNED_TO_EXPERIMENT_BUCKET, "BUCKETER", i, r), ef(i, e.trafficAllocation)
                },
                ef = function(e, t) {
                    for (var r = 0; r < t.length; r++)
                        if (e < t[r].endOfRange) return t[r].entityId;
                    return null
                },
                eE = function(e) {
                    try {
                        var t = d.v3(e, 1) / 4294967296;
                        return Math.floor(1e4 * t)
                    } catch (t) {
                        throw Error(R(T.INVALID_BUCKETING_ID, "BUCKETER", e, t.message))
                    }
                },
                ep = l.getLogger();

            function eg(e) {
                return /^\d+$/.test(e)
            }

            function eh(e) {
                var t = e.indexOf("-"),
                    r = e.indexOf("+");
                return !(t < 0) && (r < 0 || t < r)
            }

            function ev(e) {
                var t = e.indexOf("-"),
                    r = e.indexOf("+");
                return !(r < 0) && (t < 0 || r < t)
            }

            function eI(e) {
                var t = e,
                    r = "";
                if (/\s/.test(e)) return ep.warn(A.UNKNOWN_MATCH_TYPE, "SEMANTIC VERSION", e), null;
                if (eh(e) ? (t = e.substring(0, e.indexOf("-")), r = e.substring(e.indexOf("-") + 1)) : ev(e) && (t = e.substring(0, e.indexOf("+")), r = e.substring(e.indexOf("+") + 1)), "string" != typeof t || "string" != typeof r) return null;
                var n = t.split(".").length - 1;
                if (n > 2) return ep.warn(A.UNKNOWN_MATCH_TYPE, "SEMANTIC VERSION", e), null;
                var i = t.split(".");
                if (i.length != n + 1) return ep.warn(A.UNKNOWN_MATCH_TYPE, "SEMANTIC VERSION", e), null;
                for (var o = 0; o < i.length; o++)
                    if (!eg(i[o])) return ep.warn(A.UNKNOWN_MATCH_TYPE, "SEMANTIC VERSION", e), null;
                return r && i.push(r), i
            }
            var e_ = "CUSTOM_ATTRIBUTE_CONDITION_EVALUATOR",
                ey = l.getLogger(),
                eR = ["exact", "exists", "gt", "ge", "lt", "le", "substring", "semver_eq", "semver_lt", "semver_le", "semver_gt", "semver_ge"],
                eN = {};

            function eO(e) {
                return "string" == typeof e || "boolean" == typeof e || O.isNumber(e)
            }

            function em(e, t) {
                var r = e.value,
                    n = e.name,
                    i = t[n],
                    o = typeof i;
                return !eO(r) || O.isNumber(r) && !O.isSafeInteger(r) ? (ey.warn(A.UNEXPECTED_CONDITION_VALUE, e_, JSON.stringify(e)), null) : null === i ? (ey.debug(A.UNEXPECTED_TYPE_NULL, e_, JSON.stringify(e), n), null) : eO(i) && typeof r === o ? O.isNumber(i) && !O.isSafeInteger(i) ? (ey.warn(A.OUT_OF_BOUNDS, e_, JSON.stringify(e), n), null) : r === i : (ey.warn(A.UNEXPECTED_TYPE, e_, JSON.stringify(e), o, n), null)
            }

            function eT(e, t) {
                var r = e.name,
                    n = t[r],
                    i = e.value;
                return null !== i && O.isSafeInteger(i) ? null === n ? (ey.debug(A.UNEXPECTED_TYPE_NULL, e_, JSON.stringify(e), r), !1) : O.isNumber(n) ? !!O.isSafeInteger(n) || (ey.warn(A.OUT_OF_BOUNDS, e_, JSON.stringify(e), r), !1) : (ey.warn(A.UNEXPECTED_TYPE, e_, JSON.stringify(e), typeof n, r), !1) : (ey.warn(A.UNEXPECTED_CONDITION_VALUE, e_, JSON.stringify(e)), !1)
            }

            function eA(e, t) {
                var r = e.name,
                    n = t[r],
                    i = e.value;
                return "string" != typeof i ? (ey.warn(A.UNEXPECTED_CONDITION_VALUE, e_, JSON.stringify(e)), null) : null === n ? (ey.debug(A.UNEXPECTED_TYPE_NULL, e_, JSON.stringify(e), r), null) : "string" != typeof n ? (ey.warn(A.UNEXPECTED_TYPE, e_, JSON.stringify(e), typeof n, r), null) : function(e, t) {
                    var r = eI(t),
                        n = eI(e);
                    if (!r || !n) return null;
                    for (var i = r.length, o = 0; o < n.length; o++) {
                        if (i <= o) return eh(e) || ev(e) ? 1 : -1;
                        if (eg(r[o])) {
                            var a = parseInt(r[o]),
                                s = parseInt(n[o]);
                            if (a > s) return 1;
                            if (a < s) return -1
                        } else {
                            if (r[o] < n[o]) return eh(e) && !eh(t) ? 1 : -1;
                            if (r[o] > n[o]) return !eh(e) && eh(t) ? -1 : 1
                        }
                    }
                    return eh(t) && !eh(e) ? -1 : 0
                }(i, n)
            }
            eN.exact = em, eN.exists = function(e, t) {
                return null != t[e.name]
            }, eN.gt = function(e, t) {
                var r = t[e.name],
                    n = e.value;
                return eT(e, t) && null !== n ? r > n : null
            }, eN.ge = function(e, t) {
                var r = t[e.name],
                    n = e.value;
                return eT(e, t) && null !== n ? r >= n : null
            }, eN.lt = function(e, t) {
                var r = t[e.name],
                    n = e.value;
                return eT(e, t) && null !== n ? r < n : null
            }, eN.le = function(e, t) {
                var r = t[e.name],
                    n = e.value;
                return eT(e, t) && null !== n ? r <= n : null
            }, eN.substring = function(e, t) {
                var r = e.name,
                    n = t[e.name],
                    i = e.value;
                return "string" != typeof i ? (ey.warn(A.UNEXPECTED_CONDITION_VALUE, e_, JSON.stringify(e)), null) : null === n ? (ey.debug(A.UNEXPECTED_TYPE_NULL, e_, JSON.stringify(e), r), null) : "string" != typeof n ? (ey.warn(A.UNEXPECTED_TYPE, e_, JSON.stringify(e), typeof n, r), null) : -1 !== n.indexOf(i)
            }, eN.semver_eq = function(e, t) {
                var r = eA(e, t);
                return null === r ? null : 0 === r
            }, eN.semver_gt = function(e, t) {
                var r = eA(e, t);
                return null === r ? null : r > 0
            }, eN.semver_ge = function(e, t) {
                var r = eA(e, t);
                return null === r ? null : r >= 0
            }, eN.semver_lt = function(e, t) {
                var r = eA(e, t);
                return null === r ? null : r < 0
            }, eN.semver_le = function(e, t) {
                var r = eA(e, t);
                return null === r ? null : r <= 0
            };
            var eD = Object.freeze({
                    __proto__: null,
                    evaluate: function(e, t) {
                        var r = e.match;
                        if (void 0 !== r && -1 === eR.indexOf(r)) return ey.warn(A.UNKNOWN_MATCH_TYPE, e_, JSON.stringify(e)), null;
                        var n = e.name;
                        return t.hasOwnProperty(n) || "exists" == r ? (r && eN[r] || em)(e, t) : (ey.debug(A.MISSING_ATTRIBUTE_VALUE, e_, JSON.stringify(e), n), null)
                    }
                }),
                eS = l.getLogger(),
                eL = function() {
                    function e(e) {
                        this.typeToEvaluatorMap = O.assign({}, e, {
                            custom_attribute: eD
                        })
                    }
                    return e.prototype.evaluate = function(e, t, r) {
                        var n = this;
                        return void 0 === r && (r = {}), !e || 0 === e.length || !!H(e, function(e) {
                            var i = t[e];
                            if (i) {
                                eS.log(m.DEBUG, A.EVALUATING_AUDIENCE, "AUDIENCE_EVALUATOR", e, JSON.stringify(i.conditions));
                                var o = H(i.conditions, n.evaluateConditionWithUserAttributes.bind(n, r)),
                                    a = null === o ? "UNKNOWN" : o.toString().toUpperCase();
                                return eS.log(m.DEBUG, A.AUDIENCE_EVALUATION_RESULT, "AUDIENCE_EVALUATOR", e, a), o
                            }
                            return null
                        })
                    }, e.prototype.evaluateConditionWithUserAttributes = function(e, t) {
                        var r = this.typeToEvaluatorMap[t.type];
                        if (!r) return eS.log(m.WARNING, A.UNKNOWN_CONDITION_TYPE, "AUDIENCE_EVALUATOR", JSON.stringify(t)), null;
                        try {
                            return r.evaluate(t, e)
                        } catch (e) {
                            eS.log(m.ERROR, T.CONDITION_EVALUATOR_ERROR, "AUDIENCE_EVALUATOR", t.type, e.message)
                        }
                        return null
                    }, e
                }();

            function eU(e) {
                return "string" == typeof e && "" !== e
            }
            var eC = "DECISION_SERVICE",
                eb = function() {
                    function e(e) {
                        var t;
                        this.audienceEvaluator = (t = e.UNSTABLE_conditionEvaluators, new eL(t)), this.forcedVariationMap = {}, this.logger = e.logger, this.userProfileService = e.userProfileService || null
                    }
                    return e.prototype.getVariation = function(e, r, n, i) {
                        void 0 === i && (i = {});
                        var o = n.getUserId(),
                            a = n.getAttributes(),
                            s = this.getBucketingId(o, a),
                            l = [],
                            u = r.key;
                        if (!this.checkIfExperimentIsActive(e, u)) return this.logger.log(m.INFO, A.EXPERIMENT_NOT_RUNNING, eC, u), l.push([A.EXPERIMENT_NOT_RUNNING, eC, u]), {
                            result: null,
                            reasons: l
                        };
                        var c = this.getForcedVariation(e, u, o);
                        l.push.apply(l, c.reasons);
                        var d = c.result;
                        if (d) return {
                            result: d,
                            reasons: l
                        };
                        var f = this.getWhitelistedVariation(r, o);
                        l.push.apply(l, f.reasons);
                        var E = f.result;
                        if (E) return {
                            result: E.key,
                            reasons: l
                        };
                        var p = i[t.N1.IGNORE_USER_PROFILE_SERVICE],
                            g = this.resolveExperimentBucketMap(o, a);
                        if (!p && (E = this.getStoredVariation(e, r, o, g))) return this.logger.log(m.INFO, A.RETURNING_STORED_VARIATION, eC, E.key, u, o), l.push([A.RETURNING_STORED_VARIATION, eC, E.key, u, o]), {
                            result: E.key,
                            reasons: l
                        };
                        var h = this.checkIfUserIsInAudience(e, r, U.EXPERIMENT, a, "");
                        if (l.push.apply(l, h.reasons), !h.result) return this.logger.log(m.INFO, A.USER_NOT_IN_EXPERIMENT, eC, o, u), l.push([A.USER_NOT_IN_EXPERIMENT, eC, o, u]), {
                            result: null,
                            reasons: l
                        };
                        var v = ec(this.buildBucketerParams(e, r, s, o));
                        l.push.apply(l, v.reasons);
                        var I = v.result;
                        return I && (E = e.variationIdMap[I]), E ? (this.logger.log(m.INFO, A.USER_HAS_VARIATION, eC, o, E.key, u), l.push([A.USER_HAS_VARIATION, eC, o, E.key, u]), p || this.saveUserProfile(r, E, o, g), {
                            result: E.key,
                            reasons: l
                        }) : (this.logger.log(m.DEBUG, A.USER_HAS_NO_VARIATION, eC, o, u), l.push([A.USER_HAS_NO_VARIATION, eC, o, u]), {
                            result: null,
                            reasons: l
                        })
                    }, e.prototype.resolveExperimentBucketMap = function(e, t) {
                        t = t || {};
                        var r = this.getUserProfile(e) || {},
                            n = t[D.STICKY_BUCKETING_KEY];
                        return O.assign({}, r.experiment_bucket_map, n)
                    }, e.prototype.checkIfExperimentIsActive = function(e, t) {
                        return "Running" === J(e, t)
                    }, e.prototype.getWhitelistedVariation = function(e, t) {
                        var r = [];
                        if (e.forcedVariations && e.forcedVariations.hasOwnProperty(t)) {
                            var n = e.forcedVariations[t];
                            return e.variationKeyMap.hasOwnProperty(n) ? (this.logger.log(m.INFO, A.USER_FORCED_IN_VARIATION, eC, t, n), r.push([A.USER_FORCED_IN_VARIATION, eC, t, n]), {
                                result: e.variationKeyMap[n],
                                reasons: r
                            }) : (this.logger.log(m.ERROR, A.FORCED_BUCKETING_FAILED, eC, n, t), r.push([A.FORCED_BUCKETING_FAILED, eC, n, t]), {
                                result: null,
                                reasons: r
                            })
                        }
                        return {
                            result: null,
                            reasons: r
                        }
                    }, e.prototype.checkIfUserIsInAudience = function(e, t, r, n, i) {
                        var o = [],
                            a = function(e, t) {
                                var r = e.experimentIdMap[t];
                                if (!r) throw Error(R(T.INVALID_EXPERIMENT_ID, Z, t));
                                return r.audienceConditions || r.audienceIds
                            }(e, t.id),
                            s = e.audiencesById;
                        this.logger.log(m.DEBUG, A.EVALUATING_AUDIENCES_COMBINED, eC, r, i || t.key, JSON.stringify(a)), o.push([A.EVALUATING_AUDIENCES_COMBINED, eC, r, i || t.key, JSON.stringify(a)]);
                        var l = this.audienceEvaluator.evaluate(a, s, n);
                        return this.logger.log(m.INFO, A.AUDIENCE_EVALUATION_RESULT_COMBINED, eC, r, i || t.key, l.toString().toUpperCase()), o.push([A.AUDIENCE_EVALUATION_RESULT_COMBINED, eC, r, i || t.key, l.toString().toUpperCase()]), {
                            result: l,
                            reasons: o
                        }
                    }, e.prototype.buildBucketerParams = function(e, t, r, n) {
                        return {
                            bucketingId: r,
                            experimentId: t.id,
                            experimentKey: t.key,
                            experimentIdMap: e.experimentIdMap,
                            experimentKeyMap: e.experimentKeyMap,
                            groupIdMap: e.groupIdMap,
                            logger: this.logger,
                            trafficAllocationConfig: ee(e, t.id),
                            userId: n,
                            variationIdMap: e.variationIdMap
                        }
                    }, e.prototype.getStoredVariation = function(e, t, r, n) {
                        if (n.hasOwnProperty(t.id)) {
                            var i = n[t.id],
                                o = i.variation_id;
                            if (e.variationIdMap.hasOwnProperty(o)) return e.variationIdMap[i.variation_id];
                            this.logger.log(m.INFO, A.SAVED_VARIATION_NOT_FOUND, eC, r, o, t.key)
                        }
                        return null
                    }, e.prototype.getUserProfile = function(e) {
                        if (!this.userProfileService) return {
                            user_id: e,
                            experiment_bucket_map: {}
                        };
                        try {
                            return this.userProfileService.lookup(e)
                        } catch (t) {
                            this.logger.log(m.ERROR, T.USER_PROFILE_LOOKUP_ERROR, eC, e, t.message)
                        }
                        return null
                    }, e.prototype.saveUserProfile = function(e, t, r, n) {
                        if (this.userProfileService) try {
                            n[e.id] = {
                                variation_id: t.id
                            }, this.userProfileService.save({
                                user_id: r,
                                experiment_bucket_map: n
                            }), this.logger.log(m.INFO, A.SAVED_VARIATION, eC, t.key, e.key, r)
                        } catch (e) {
                            this.logger.log(m.ERROR, T.USER_PROFILE_SAVE_ERROR, eC, r, e.message)
                        }
                    }, e.prototype.getVariationForFeature = function(e, t, r, n) {
                        void 0 === n && (n = {});
                        var i = [],
                            o = this.getVariationForFeatureExperiment(e, t, r, n);
                        i.push.apply(i, o.reasons);
                        var a = o.result;
                        if (null !== a.variation) return {
                            result: a,
                            reasons: i
                        };
                        var s = this.getVariationForRollout(e, t, r);
                        i.push.apply(i, s.reasons);
                        var l = s.result,
                            u = r.getUserId();
                        return l.variation ? (this.logger.log(m.DEBUG, A.USER_IN_ROLLOUT, eC, u, t.key), i.push([A.USER_IN_ROLLOUT, eC, u, t.key]), {
                            result: l,
                            reasons: i
                        }) : (this.logger.log(m.DEBUG, A.USER_NOT_IN_ROLLOUT, eC, u, t.key), i.push([A.USER_NOT_IN_ROLLOUT, eC, u, t.key]), {
                            result: l,
                            reasons: i
                        })
                    }, e.prototype.getVariationForFeatureExperiment = function(e, t, r, n) {
                        void 0 === n && (n = {});
                        var i, o, a = [],
                            s = null;
                        if (t.experimentIds.length > 0)
                            for (o = 0; o < t.experimentIds.length; o++) {
                                var l = et(e, t.experimentIds[o], this.logger);
                                if (l && (i = this.getVariationFromExperimentRule(e, t.key, l, r, n), a.push.apply(a, i.reasons), s = i.result)) {
                                    var u = null;
                                    return (u = l.variationKeyMap[s]) || (u = er(e, t.key, s)), {
                                        result: {
                                            experiment: l,
                                            variation: u,
                                            decisionSource: L.FEATURE_TEST
                                        },
                                        reasons: a
                                    }
                                }
                            } else this.logger.log(m.DEBUG, A.FEATURE_HAS_NO_EXPERIMENTS, eC, t.key), a.push([A.FEATURE_HAS_NO_EXPERIMENTS, eC, t.key]);
                        return {
                            result: {
                                experiment: null,
                                variation: null,
                                decisionSource: L.FEATURE_TEST
                            },
                            reasons: a
                        }
                    }, e.prototype.getVariationForRollout = function(e, t, r) {
                        var n = [];
                        if (!t.rolloutId) return this.logger.log(m.DEBUG, A.NO_ROLLOUT_EXISTS, eC, t.key), n.push([A.NO_ROLLOUT_EXISTS, eC, t.key]), {
                            result: {
                                experiment: null,
                                variation: null,
                                decisionSource: L.ROLLOUT
                            },
                            reasons: n
                        };
                        var i = e.rolloutIdMap[t.rolloutId];
                        if (!i) return this.logger.log(m.ERROR, T.INVALID_ROLLOUT_ID, eC, t.rolloutId, t.key), n.push([T.INVALID_ROLLOUT_ID, eC, t.rolloutId, t.key]), {
                            result: {
                                experiment: null,
                                variation: null,
                                decisionSource: L.ROLLOUT
                            },
                            reasons: n
                        };
                        var o, a, s, l = i.experiments;
                        if (0 === l.length) return this.logger.log(m.ERROR, A.ROLLOUT_HAS_NO_EXPERIMENTS, eC, t.rolloutId), n.push([A.ROLLOUT_HAS_NO_EXPERIMENTS, eC, t.rolloutId]), {
                            result: {
                                experiment: null,
                                variation: null,
                                decisionSource: L.ROLLOUT
                            },
                            reasons: n
                        };
                        for (var u = 0; u < l.length;) {
                            if (o = this.getVariationFromDeliveryRule(e, t.key, l, u, r), n.push.apply(n, o.reasons), s = o.result, a = o.skipToEveryoneElse, s) return {
                                result: {
                                    experiment: e.experimentIdMap[l[u].id],
                                    variation: s,
                                    decisionSource: L.ROLLOUT
                                },
                                reasons: n
                            };
                            u = a ? l.length - 1 : u + 1
                        }
                        return {
                            result: {
                                experiment: null,
                                variation: null,
                                decisionSource: L.ROLLOUT
                            },
                            reasons: n
                        }
                    }, e.prototype.getBucketingId = function(e, t) {
                        var r = e;
                        return null != t && "object" == typeof t && t.hasOwnProperty(D.BUCKETING_ID) && ("string" == typeof t[D.BUCKETING_ID] ? (r = t[D.BUCKETING_ID], this.logger.log(m.DEBUG, A.VALID_BUCKETING_ID, eC, r)) : this.logger.log(m.WARNING, A.BUCKETING_ID_NOT_STRING, eC)), r
                    }, e.prototype.findValidatedForcedDecision = function(e, t, r, n) {
                        var i, o = [],
                            a = t.getForcedDecision({
                                flagKey: r,
                                ruleKey: n
                            }),
                            s = null,
                            l = t.getUserId();
                        return e && a && (i = a.variationKey, (s = er(e, r, i)) ? n ? (this.logger.log(m.INFO, A.USER_HAS_FORCED_DECISION_WITH_RULE_SPECIFIED, i, r, n, l), o.push([A.USER_HAS_FORCED_DECISION_WITH_RULE_SPECIFIED, i, r, n, l])) : (this.logger.log(m.INFO, A.USER_HAS_FORCED_DECISION_WITH_NO_RULE_SPECIFIED, i, r, l), o.push([A.USER_HAS_FORCED_DECISION_WITH_NO_RULE_SPECIFIED, i, r, l])) : n ? (this.logger.log(m.INFO, A.USER_HAS_FORCED_DECISION_WITH_RULE_SPECIFIED_BUT_INVALID, r, n, l), o.push([A.USER_HAS_FORCED_DECISION_WITH_RULE_SPECIFIED_BUT_INVALID, r, n, l])) : (this.logger.log(m.INFO, A.USER_HAS_FORCED_DECISION_WITH_NO_RULE_SPECIFIED_BUT_INVALID, r, l), o.push([A.USER_HAS_FORCED_DECISION_WITH_NO_RULE_SPECIFIED_BUT_INVALID, r, l]))), {
                            result: s,
                            reasons: o
                        }
                    }, e.prototype.removeForcedVariation = function(e, t, r) {
                        if (!e) throw Error(R(T.INVALID_USER_ID, eC));
                        if (!this.forcedVariationMap.hasOwnProperty(e)) throw Error(R(T.USER_NOT_IN_FORCED_VARIATION, eC, e));
                        delete this.forcedVariationMap[e][t], this.logger.log(m.DEBUG, A.VARIATION_REMOVED_FOR_USER, eC, r, e)
                    }, e.prototype.setInForcedVariationMap = function(e, t, r) {
                        this.forcedVariationMap.hasOwnProperty(e) || (this.forcedVariationMap[e] = {}), this.forcedVariationMap[e][t] = r, this.logger.log(m.DEBUG, A.USER_MAPPED_TO_FORCED_VARIATION, eC, r, t, e)
                    }, e.prototype.getForcedVariation = function(e, t, r) {
                        var n, i = [],
                            o = this.forcedVariationMap[r];
                        if (!o) return this.logger.log(m.DEBUG, A.USER_HAS_NO_FORCED_VARIATION, eC, r), {
                            result: null,
                            reasons: i
                        };
                        try {
                            var a = Q(e, t);
                            if (!a.hasOwnProperty("id")) return this.logger.log(m.ERROR, T.IMPROPERLY_FORMATTED_EXPERIMENT, eC, t), i.push([T.IMPROPERLY_FORMATTED_EXPERIMENT, eC, t]), {
                                result: null,
                                reasons: i
                            };
                            n = a.id
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), i.push(e.message), {
                                result: null,
                                reasons: i
                            }
                        }
                        var s = o[n];
                        if (!s) return this.logger.log(m.DEBUG, A.USER_HAS_NO_FORCED_VARIATION_FOR_EXPERIMENT, eC, t, r), {
                            result: null,
                            reasons: i
                        };
                        var l = $(e, s);
                        return l ? (this.logger.log(m.DEBUG, A.USER_HAS_FORCED_VARIATION, eC, l, t, r), i.push([A.USER_HAS_FORCED_VARIATION, eC, l, t, r])) : this.logger.log(m.DEBUG, A.USER_HAS_NO_FORCED_VARIATION_FOR_EXPERIMENT, eC, t, r), {
                            result: l,
                            reasons: i
                        }
                    }, e.prototype.setForcedVariation = function(e, t, r, n) {
                        if (null != n && !eU(n)) return this.logger.log(m.ERROR, T.INVALID_VARIATION_KEY, eC), !1;
                        try {
                            var i, o, a = Q(e, t);
                            if (!a.hasOwnProperty("id")) return this.logger.log(m.ERROR, T.IMPROPERLY_FORMATTED_EXPERIMENT, eC, t), !1;
                            o = a.id
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), !1
                        }
                        if (null == n) try {
                            return this.removeForcedVariation(r, o, t), !0
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), !1
                        }
                        var s = (i = e.experimentKeyMap[t]).variationKeyMap.hasOwnProperty(n) ? i.variationKeyMap[n].id : null;
                        if (!s) return this.logger.log(m.ERROR, T.NO_VARIATION_FOR_EXPERIMENT_KEY, eC, n, t), !1;
                        try {
                            return this.setInForcedVariationMap(r, o, s), !0
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), !1
                        }
                    }, e.prototype.getVariationFromExperimentRule = function(e, t, r, n, i) {
                        void 0 === i && (i = {});
                        var o = [],
                            a = this.findValidatedForcedDecision(e, n, t, r.key);
                        o.push.apply(o, a.reasons);
                        var s = a.result;
                        if (s) return {
                            result: s.key,
                            reasons: o
                        };
                        var l = this.getVariation(e, r, n, i);
                        return o.push.apply(o, l.reasons), {
                            result: l.result,
                            reasons: o
                        }
                    }, e.prototype.getVariationFromDeliveryRule = function(e, t, r, n, i) {
                        var o = [],
                            a = !1,
                            s = r[n],
                            l = this.findValidatedForcedDecision(e, i, t, s.key);
                        o.push.apply(o, l.reasons);
                        var u = l.result;
                        if (u) return {
                            result: u,
                            reasons: o,
                            skipToEveryoneElse: a
                        };
                        var c, d, f = i.getUserId(),
                            E = i.getAttributes(),
                            p = this.getBucketingId(f, E),
                            g = n === r.length - 1,
                            h = g ? "Everyone Else" : n + 1,
                            v = null,
                            I = this.checkIfUserIsInAudience(e, s, U.RULE, E, h);
                        return o.push.apply(o, I.reasons), I.result ? (this.logger.log(m.DEBUG, A.USER_MEETS_CONDITIONS_FOR_TARGETING_RULE, eC, f, h), o.push([A.USER_MEETS_CONDITIONS_FOR_TARGETING_RULE, eC, f, h]), d = ec(this.buildBucketerParams(e, s, p, f)), o.push.apply(o, d.reasons), (c = d.result) && (v = e.variationIdMap.hasOwnProperty(c) ? e.variationIdMap[c] : null), v ? (this.logger.log(m.DEBUG, A.USER_BUCKETED_INTO_TARGETING_RULE, eC, f, h), o.push([A.USER_BUCKETED_INTO_TARGETING_RULE, eC, f, h])) : g || (this.logger.log(m.DEBUG, A.USER_NOT_BUCKETED_INTO_TARGETING_RULE, eC, f, h), o.push([A.USER_NOT_BUCKETED_INTO_TARGETING_RULE, eC, f, h]), a = !0)) : (this.logger.log(m.DEBUG, A.USER_DOESNT_MEET_CONDITIONS_FOR_TARGETING_RULE, eC, f, h), o.push([A.USER_DOESNT_MEET_CONDITIONS_FOR_TARGETING_RULE, eC, f, h])), {
                            result: v,
                            reasons: o,
                            skipToEveryoneElse: a
                        }
                    }, e
                }();

            function eP(e, t) {
                if (e.hasOwnProperty("revenue")) {
                    var r = e.revenue,
                        n = void 0;
                    return "string" == typeof r ? isNaN(n = parseInt(r)) ? (t.log(m.INFO, A.FAILED_TO_PARSE_REVENUE, "EVENT_TAG_UTILS", r), null) : (t.log(m.INFO, A.PARSED_REVENUE_VALUE, "EVENT_TAG_UTILS", n), n) : "number" == typeof r ? (n = r, t.log(m.INFO, A.PARSED_REVENUE_VALUE, "EVENT_TAG_UTILS", n), n) : null
                }
                return null
            }

            function eV(e, t) {
                if (e.hasOwnProperty("value")) {
                    var r = e.value,
                        n = void 0;
                    return "string" == typeof r ? isNaN(n = parseFloat(r)) ? (t.log(m.INFO, A.FAILED_TO_PARSE_VALUE, "EVENT_TAG_UTILS", r), null) : (t.log(m.INFO, A.PARSED_NUMERIC_VALUE, "EVENT_TAG_UTILS", n), n) : "number" == typeof r ? (n = r, t.log(m.INFO, A.PARSED_NUMERIC_VALUE, "EVENT_TAG_UTILS", n), n) : null
                }
                return null
            }

            function eF(e, t) {
                return "string" == typeof e && ("string" == typeof t || "boolean" == typeof t || O.isNumber(t) && O.isSafeInteger(t))
            }
            var eM = "https://logx.optimizely.com/v1/events";

            function ex(e) {
                var t = e.attributes,
                    r = e.userId,
                    n = e.clientEngine,
                    i = e.clientVersion,
                    o = e.configObj,
                    a = e.logger,
                    s = !!o.anonymizeIP && o.anonymizeIP,
                    l = o.botFiltering,
                    u = {
                        account_id: o.accountId,
                        project_id: o.projectId,
                        visitors: [{
                            snapshots: [],
                            visitor_id: r,
                            attributes: []
                        }],
                        revision: o.revision,
                        client_name: n,
                        client_version: i,
                        anonymize_ip: s,
                        enrich_decisions: !0
                    };
                return t && Object.keys(t || {}).forEach(function(e) {
                    if (eF(e, t[e])) {
                        var r = q(o, e, a);
                        r && u.visitors[0].attributes.push({
                            entity_id: r,
                            key: e,
                            type: "custom",
                            value: t[e]
                        })
                    }
                }), "boolean" == typeof l && u.visitors[0].attributes.push({
                    entity_id: D.BOT_FILTERING,
                    key: D.BOT_FILTERING,
                    type: "custom",
                    value: l
                }), u
            }

            function ew(e) {
                var t, r;
                return null !== (r = null === (t = e.experiment) || void 0 === t ? void 0 : t.key) && void 0 !== r ? r : ""
            }

            function ek(e) {
                var t, r;
                return null !== (r = null === (t = e.variation) || void 0 === t ? void 0 : t.key) && void 0 !== r ? r : ""
            }

            function eB(e) {
                var t, r;
                return null !== (r = null === (t = e.variation) || void 0 === t ? void 0 : t.featureEnabled) && void 0 !== r && r
            }

            function eK(e) {
                var t, r;
                return null !== (r = null === (t = e.experiment) || void 0 === t ? void 0 : t.id) && void 0 !== r ? r : null
            }

            function eG(e) {
                var t, r;
                return null !== (r = null === (t = e.variation) || void 0 === t ? void 0 : t.id) && void 0 !== r ? r : null
            }
            var ej = l.getLogger("EVENT_BUILDER");

            function eH(e, t) {
                var r = [];
                return t && Object.keys(t || {}).forEach(function(n) {
                    if (eF(n, t[n])) {
                        var i = q(e, n, ej);
                        i && r.push({
                            entityId: i,
                            key: n,
                            value: t[n]
                        })
                    }
                }), r
            }
            var eY = "USER_PROFILE_SERVICE_VALIDATOR",
                eZ = function() {
                    function e(e) {
                        var r, n = this,
                            i = e.clientEngine;
                        i || (e.logger.log(m.INFO, A.INVALID_CLIENT_ENGINE, "OPTIMIZELY", i), i = "node-sdk"), this.clientEngine = i, this.clientVersion = e.clientVersion || "4.9.3", this.errorHandler = e.errorHandler, this.isOptimizelyConfigValid = e.isValidInstance, this.logger = e.logger;
                        var o = null !== (r = e.defaultDecideOptions) && void 0 !== r ? r : [];
                        Array.isArray(o) || (this.logger.log(m.DEBUG, A.INVALID_DEFAULT_DECIDE_OPTIONS, "OPTIMIZELY"), o = []);
                        var a = {};
                        o.forEach(function(e) {
                            t.N1[e] ? a[e] = !0 : n.logger.log(m.WARNING, A.UNRECOGNIZED_DECIDE_OPTION, "OPTIMIZELY", e)
                        }), this.defaultDecideOptions = a, this.projectConfigManager = (s = {
                            datafile: e.datafile,
                            jsonSchemaValidator: e.jsonSchemaValidator,
                            sdkKey: e.sdkKey,
                            datafileManager: e.datafileManager
                        }, new eu(s)), this.disposeOnUpdate = this.projectConfigManager.onUpdate(function(e) {
                            n.logger.log(m.INFO, A.UPDATED_OPTIMIZELY_CONFIG, "OPTIMIZELY", e.revision, e.projectId), n.notificationCenter.sendNotifications(N.OPTIMIZELY_CONFIG_UPDATE)
                        });
                        var s, l, u = this.projectConfigManager.onReady(),
                            c = null;
                        if (e.userProfileService) try {
                            (function(e) {
                                if ("object" == typeof e && null !== e) {
                                    if ("function" != typeof e.lookup) throw Error(R(T.INVALID_USER_PROFILE_SERVICE, eY, "Missing function 'lookup'"));
                                    if ("function" != typeof e.save) throw Error(R(T.INVALID_USER_PROFILE_SERVICE, eY, "Missing function 'save'"));
                                    return !0
                                }
                                throw Error(R(T.INVALID_USER_PROFILE_SERVICE, eY))
                            })(e.userProfileService) && (c = e.userProfileService, this.logger.log(m.INFO, A.VALID_USER_PROFILE_SERVICE, "OPTIMIZELY"))
                        } catch (e) {
                            this.logger.log(m.WARNING, e.message)
                        }
                        this.decisionService = (l = {
                            userProfileService: c,
                            logger: this.logger,
                            UNSTABLE_conditionEvaluators: e.UNSTABLE_conditionEvaluators
                        }, new eb(l)), this.notificationCenter = e.notificationCenter, this.eventProcessor = e.eventProcessor;
                        var d = this.eventProcessor.start();
                        this.readyPromise = Promise.all([u, d]).then(function(e) {
                            return e[0]
                        }), this.readyTimeouts = {}, this.nextReadyTimeoutId = 0
                    }
                    return e.prototype.isValidInstance = function() {
                        return this.isOptimizelyConfigValid && !!this.projectConfigManager.getConfig()
                    }, e.prototype.activate = function(e, t, r) {
                        try {
                            if (!this.isValidInstance()) return this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "activate"), null;
                            if (!this.validateInputs({
                                    experiment_key: e,
                                    user_id: t
                                }, r)) return this.notActivatingExperiment(e, t);
                            var n = this.projectConfigManager.getConfig();
                            if (!n) return null;
                            try {
                                var i = this.getVariation(e, t, r);
                                if (null === i) return this.notActivatingExperiment(e, t);
                                if ("Running" !== J(n, e)) return this.logger.log(m.DEBUG, A.SHOULD_NOT_DISPATCH_ACTIVATE, "OPTIMIZELY", e), i;
                                var o = Q(n, e),
                                    a = {
                                        experiment: o,
                                        variation: o.variationKeyMap[i],
                                        decisionSource: L.EXPERIMENT
                                    };
                                return this.sendImpressionEvent(a, "", t, !0, r), i
                            } catch (r) {
                                return this.logger.log(m.ERROR, r.message), this.logger.log(m.INFO, A.NOT_ACTIVATING_USER, "OPTIMIZELY", t, e), this.errorHandler.handleError(r), null
                            }
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.sendImpressionEvent = function(e, t, r, n, i) {
                        var o = this.projectConfigManager.getConfig();
                        if (o) {
                            var a, s, l, u, c, d, f, E, p, g, h, v, I, _, y, R = (s = (a = {
                                decisionObj: e,
                                flagKey: t,
                                enabled: n,
                                userId: r,
                                userAttributes: i,
                                clientEngine: this.clientEngine,
                                clientVersion: this.clientVersion,
                                configObj: o
                            }).configObj, l = a.decisionObj, u = a.userId, c = a.flagKey, d = a.enabled, f = a.userAttributes, E = a.clientEngine, p = a.clientVersion, g = l.decisionSource, h = ew(l), v = eK(l), I = ek(l), _ = eG(l), y = null !== v ? X(s, v) : null, {
                                type: "impression",
                                timestamp: O.currentTimestamp(),
                                uuid: O.uuid(),
                                user: {
                                    id: u,
                                    attributes: eH(s, f)
                                },
                                context: {
                                    accountId: s.accountId,
                                    projectId: s.projectId,
                                    revision: s.revision,
                                    clientName: E,
                                    clientVersion: p,
                                    anonymizeIP: s.anonymizeIP || !1,
                                    botFiltering: s.botFiltering
                                },
                                layer: {
                                    id: y
                                },
                                experiment: {
                                    id: v,
                                    key: h
                                },
                                variation: {
                                    id: _,
                                    key: I
                                },
                                ruleKey: h,
                                flagKey: c,
                                ruleType: g,
                                enabled: d
                            });
                            this.eventProcessor.process(R), this.emitNotificationCenterActivate(e, t, r, n, i)
                        }
                    }, e.prototype.emitNotificationCenterActivate = function(e, t, r, n, i) {
                        var o = this.projectConfigManager.getConfig();
                        if (o) {
                            var a, s = e.decisionSource,
                                l = ew(e),
                                u = eK(e),
                                c = ek(e),
                                d = eG(e);
                            null !== u && "" !== c && (a = o.experimentIdMap[u]);
                            var f, E, p, g, h, v, I, _, y, R, m, T, A, D = (m = ex(f = {
                                attributes: i,
                                clientEngine: this.clientEngine,
                                clientVersion: this.clientVersion,
                                configObj: o,
                                experimentId: u,
                                ruleKey: l,
                                flagKey: t,
                                ruleType: s,
                                userId: r,
                                enabled: n,
                                variationId: d,
                                logger: this.logger
                            }), E = f.configObj, p = f.experimentId, g = f.variationId, h = f.ruleKey, v = f.ruleType, I = f.flagKey, _ = f.enabled, y = p ? X(E, p) : null, R = g ? $(E, g) : null, T = {
                                decisions: [{
                                    campaign_id: y,
                                    experiment_id: p,
                                    variation_id: g,
                                    metadata: {
                                        flag_key: I,
                                        rule_key: h,
                                        rule_type: v,
                                        variation_key: R = R || "",
                                        enabled: _
                                    }
                                }],
                                events: [{
                                    entity_id: y,
                                    timestamp: O.currentTimestamp(),
                                    key: "campaign_activated",
                                    uuid: O.uuid()
                                }]
                            }, m.visitors[0].snapshots.push(T), {
                                httpVerb: "POST",
                                url: eM,
                                params: m
                            });
                            a && a.variationKeyMap && "" !== c && (A = a.variationKeyMap[c]), this.notificationCenter.sendNotifications(N.ACTIVATE, {
                                experiment: a,
                                userId: r,
                                attributes: i,
                                variation: A,
                                logEvent: D
                            })
                        }
                    }, e.prototype.track = function(e, t, r, n) {
                        try {
                            if (!this.isValidInstance()) return void this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "track");
                            if (!this.validateInputs({
                                    user_id: t,
                                    event_key: e
                                }, r, n)) return;
                            var i, o, a, s, l, u, c, d, f, E, p, g = this.projectConfigManager.getConfig();
                            if (!g) return;
                            if (!g.eventKeyMap.hasOwnProperty(e)) return this.logger.log(m.WARNING, A.EVENT_KEY_NOT_FOUND, "OPTIMIZELY", e), void this.logger.log(m.WARNING, A.NOT_TRACKING_USER, "OPTIMIZELY", t);
                            var h = (o = (i = {
                                eventKey: e,
                                eventTags: n = this.filterEmptyValues(n),
                                userId: t,
                                userAttributes: r,
                                clientEngine: this.clientEngine,
                                clientVersion: this.clientVersion,
                                configObj: g
                            }).configObj, a = i.userId, s = i.userAttributes, l = i.clientEngine, u = i.clientVersion, c = i.eventKey, d = i.eventTags, f = W(o, c), E = d ? eP(d, ej) : null, p = d ? eV(d, ej) : null, {
                                type: "conversion",
                                timestamp: O.currentTimestamp(),
                                uuid: O.uuid(),
                                user: {
                                    id: a,
                                    attributes: eH(o, s)
                                },
                                context: {
                                    accountId: o.accountId,
                                    projectId: o.projectId,
                                    revision: o.revision,
                                    clientName: l,
                                    clientVersion: u,
                                    anonymizeIP: o.anonymizeIP || !1,
                                    botFiltering: o.botFiltering
                                },
                                event: {
                                    id: f,
                                    key: c
                                },
                                revenue: E,
                                value: p,
                                tags: d
                            });
                            this.logger.log(m.INFO, A.TRACK_EVENT, "OPTIMIZELY", e, t), this.eventProcessor.process(h), this.emitNotificationCenterTrack(e, t, r, n)
                        } catch (e) {
                            this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), this.logger.log(m.ERROR, A.NOT_TRACKING_USER, "OPTIMIZELY", t)
                        }
                    }, e.prototype.emitNotificationCenterTrack = function(e, t, r, n) {
                        try {
                            var i, o, a, s = this.projectConfigManager.getConfig();
                            if (!s) return;
                            var l = (i = {
                                attributes: r,
                                clientEngine: this.clientEngine,
                                clientVersion: this.clientVersion,
                                configObj: s,
                                eventKey: e,
                                eventTags: n,
                                logger: this.logger,
                                userId: t
                            }, o = ex(i), a = function(e, t, r, n) {
                                var i = {
                                        events: []
                                    },
                                    o = {
                                        entity_id: W(e, t),
                                        timestamp: O.currentTimestamp(),
                                        uuid: O.uuid(),
                                        key: t
                                    };
                                if (n) {
                                    var a = eP(n, r);
                                    null !== a && (o.revenue = a);
                                    var s = eV(n, r);
                                    null !== s && (o.value = s), o.tags = n
                                }
                                return i.events.push(o), i
                            }(i.configObj, i.eventKey, i.logger, i.eventTags), o.visitors[0].snapshots = [a], {
                                httpVerb: "POST",
                                url: eM,
                                params: o
                            });
                            this.notificationCenter.sendNotifications(N.TRACK, {
                                eventKey: e,
                                userId: t,
                                attributes: r,
                                eventTags: n,
                                logEvent: l
                            })
                        } catch (e) {
                            this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e)
                        }
                    }, e.prototype.getVariation = function(e, t, r) {
                        try {
                            if (!this.isValidInstance()) return this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "getVariation"), null;
                            try {
                                if (!this.validateInputs({
                                        experiment_key: e,
                                        user_id: t
                                    }, r)) return null;
                                var n, i = this.projectConfigManager.getConfig();
                                if (!i) return null;
                                var o = i.experimentKeyMap[e];
                                if (!o) return this.logger.log(m.DEBUG, T.INVALID_EXPERIMENT_KEY, "OPTIMIZELY", e), null;
                                var a = this.decisionService.getVariation(i, o, this.createUserContext(t, r)).result,
                                    s = (n = o.id, i.experimentFeatureMap.hasOwnProperty(n) ? S.FEATURE_TEST : S.AB_TEST);
                                return this.notificationCenter.sendNotifications(N.DECISION, {
                                    type: s,
                                    userId: t,
                                    attributes: r || {},
                                    decisionInfo: {
                                        experimentKey: e,
                                        variationKey: a
                                    }
                                }), a
                            } catch (e) {
                                return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                            }
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.setForcedVariation = function(e, t, r) {
                        if (!this.validateInputs({
                                experiment_key: e,
                                user_id: t
                            })) return !1;
                        var n = this.projectConfigManager.getConfig();
                        if (!n) return !1;
                        try {
                            return this.decisionService.setForcedVariation(n, e, t, r)
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), !1
                        }
                    }, e.prototype.getForcedVariation = function(e, t) {
                        if (!this.validateInputs({
                                experiment_key: e,
                                user_id: t
                            })) return null;
                        var r = this.projectConfigManager.getConfig();
                        if (!r) return null;
                        try {
                            return this.decisionService.getForcedVariation(r, e, t).result
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.validateInputs = function(e, t, r) {
                        try {
                            if (e.hasOwnProperty("user_id")) {
                                var n = e.user_id;
                                if ("string" != typeof n || null === n || "undefined" === n) throw Error(R(T.INVALID_INPUT_FORMAT, "OPTIMIZELY", "user_id"));
                                delete e.user_id
                            }
                            return Object.keys(e).forEach(function(t) {
                                if (!eU(e[t])) throw Error(R(T.INVALID_INPUT_FORMAT, "OPTIMIZELY", t))
                            }), t && function(e) {
                                if ("object" != typeof e || Array.isArray(e) || null === e) throw Error(R(T.INVALID_ATTRIBUTES, "ATTRIBUTES_VALIDATOR"));
                                Object.keys(e).forEach(function(t) {
                                    if (void 0 === e[t]) throw Error(R(T.UNDEFINED_ATTRIBUTE, "ATTRIBUTES_VALIDATOR", t))
                                })
                            }(t), r && function(e) {
                                if ("object" != typeof e || Array.isArray(e) || null === e) throw Error(R(T.INVALID_EVENT_TAGS, "EVENT_TAGS_VALIDATOR"))
                            }(r), !0
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), !1
                        }
                    }, e.prototype.notActivatingExperiment = function(e, t) {
                        return this.logger.log(m.INFO, A.NOT_ACTIVATING_USER, "OPTIMIZELY", t, e), null
                    }, e.prototype.filterEmptyValues = function(e) {
                        for (var t in e) e.hasOwnProperty(t) && (null === e[t] || void 0 === e[t]) && delete e[t];
                        return e
                    }, e.prototype.isFeatureEnabled = function(e, t, r) {
                        try {
                            if (!this.isValidInstance()) return this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "isFeatureEnabled"), !1;
                            if (!this.validateInputs({
                                    feature_key: e,
                                    user_id: t
                                }, r)) return !1;
                            var n = this.projectConfigManager.getConfig();
                            if (!n) return !1;
                            var i = en(n, e, this.logger);
                            if (!i) return !1;
                            var o = {},
                                a = this.createUserContext(t, r),
                                s = this.decisionService.getVariationForFeature(n, i, a).result,
                                l = s.decisionSource,
                                u = ew(s),
                                c = ek(s),
                                d = eB(s);
                            l === L.FEATURE_TEST && (o = {
                                experimentKey: u,
                                variationKey: c
                            }), (l === L.FEATURE_TEST || l === L.ROLLOUT && ea(n)) && this.sendImpressionEvent(s, i.key, t, d, r), !0 === d ? this.logger.log(m.INFO, A.FEATURE_ENABLED_FOR_USER, "OPTIMIZELY", e, t) : (this.logger.log(m.INFO, A.FEATURE_NOT_ENABLED_FOR_USER, "OPTIMIZELY", e, t), d = !1);
                            var f = {
                                featureKey: e,
                                featureEnabled: d,
                                source: s.decisionSource,
                                sourceInfo: o
                            };
                            return this.notificationCenter.sendNotifications(N.DECISION, {
                                type: S.FEATURE,
                                userId: t,
                                attributes: r || {},
                                decisionInfo: f
                            }), d
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), !1
                        }
                    }, e.prototype.getEnabledFeatures = function(e, t) {
                        var r = this;
                        try {
                            var n = [];
                            if (!this.isValidInstance()) return this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "getEnabledFeatures"), n;
                            if (!this.validateInputs({
                                    user_id: e
                                })) return n;
                            var i = this.projectConfigManager.getConfig();
                            return i && v(i.featureKeyMap).forEach(function(i) {
                                r.isFeatureEnabled(i.key, e, t) && n.push(i.key)
                            }), n
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), []
                        }
                    }, e.prototype.getFeatureVariable = function(e, t, r, n) {
                        try {
                            return this.isValidInstance() ? this.getFeatureVariableForType(e, t, null, r, n) : (this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "getFeatureVariable"), null)
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.getFeatureVariableForType = function(e, t, r, n, i) {
                        if (!this.validateInputs({
                                feature_key: e,
                                variable_key: t,
                                user_id: n
                            }, i)) return null;
                        var o, a, s = this.projectConfigManager.getConfig();
                        if (!s) return null;
                        var l = en(s, e, this.logger);
                        if (!l) return null;
                        var u = (o = this.logger, (a = s.featureKeyMap[e]) ? a.variableKeyMap[t] || (o.log(m.ERROR, T.VARIABLE_KEY_NOT_IN_DATAFILE, Z, t, e), null) : (o.log(m.ERROR, T.FEATURE_NOT_IN_DATAFILE, Z, e), null));
                        if (!u) return null;
                        if (r && u.type !== r) return this.logger.log(m.WARNING, A.VARIABLE_REQUESTED_WITH_WRONG_TYPE, "OPTIMIZELY", r, u.type), null;
                        var c = this.createUserContext(n, i),
                            d = this.decisionService.getVariationForFeature(s, l, c).result,
                            f = eB(d),
                            E = this.getFeatureVariableValueFromVariation(e, f, d.variation, u, n),
                            p = {};
                        return d.decisionSource === L.FEATURE_TEST && null !== d.experiment && null !== d.variation && (p = {
                            experimentKey: d.experiment.key,
                            variationKey: d.variation.key
                        }), this.notificationCenter.sendNotifications(N.DECISION, {
                            type: S.FEATURE_VARIABLE,
                            userId: n,
                            attributes: i || {},
                            decisionInfo: {
                                featureKey: e,
                                featureEnabled: f,
                                source: d.decisionSource,
                                variableKey: t,
                                variableValue: E,
                                variableType: u.type,
                                sourceInfo: p
                            }
                        }), E
                    }, e.prototype.getFeatureVariableValueFromVariation = function(e, t, r, n, i) {
                        var o = this.projectConfigManager.getConfig();
                        if (!o) return null;
                        var a = n.defaultValue;
                        if (null !== r) {
                            var s = function(e, t, r, n) {
                                if (!t || !r) return null;
                                if (!e.variationVariableUsageMap.hasOwnProperty(r.id)) return n.log(m.ERROR, T.VARIATION_ID_NOT_IN_DATAFILE_NO_EXPERIMENT, Z, r.id), null;
                                var i = e.variationVariableUsageMap[r.id][t.id];
                                return i ? i.value : null
                            }(o, n, r, this.logger);
                            null !== s ? t ? (a = s, this.logger.log(m.INFO, A.USER_RECEIVED_VARIABLE_VALUE, "OPTIMIZELY", a, n.key, e)) : this.logger.log(m.INFO, A.FEATURE_NOT_ENABLED_RETURN_DEFAULT_VARIABLE_VALUE, "OPTIMIZELY", e, i, a) : this.logger.log(m.INFO, A.VARIABLE_NOT_USED_RETURN_DEFAULT_VARIABLE_VALUE, "OPTIMIZELY", n.key, r.key)
                        } else this.logger.log(m.INFO, A.USER_RECEIVED_DEFAULT_VARIABLE_VALUE, "OPTIMIZELY", i, n.key, e);
                        return function(e, t, r) {
                            var n;
                            switch (t) {
                                case C.BOOLEAN:
                                    "true" !== e && "false" !== e ? (r.log(m.ERROR, T.UNABLE_TO_CAST_VALUE, Z, e, t), n = null) : n = "true" === e;
                                    break;
                                case C.INTEGER:
                                    isNaN(n = parseInt(e, 10)) && (r.log(m.ERROR, T.UNABLE_TO_CAST_VALUE, Z, e, t), n = null);
                                    break;
                                case C.DOUBLE:
                                    isNaN(n = parseFloat(e)) && (r.log(m.ERROR, T.UNABLE_TO_CAST_VALUE, Z, e, t), n = null);
                                    break;
                                case C.JSON:
                                    try {
                                        n = JSON.parse(e)
                                    } catch (i) {
                                        r.log(m.ERROR, T.UNABLE_TO_CAST_VALUE, Z, e, t), n = null
                                    }
                                    break;
                                default:
                                    n = e
                            }
                            return n
                        }(a, n.type, this.logger)
                    }, e.prototype.getFeatureVariableBoolean = function(e, t, r, n) {
                        try {
                            return this.isValidInstance() ? this.getFeatureVariableForType(e, t, C.BOOLEAN, r, n) : (this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "getFeatureVariableBoolean"), null)
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.getFeatureVariableDouble = function(e, t, r, n) {
                        try {
                            return this.isValidInstance() ? this.getFeatureVariableForType(e, t, C.DOUBLE, r, n) : (this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "getFeatureVariableDouble"), null)
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.getFeatureVariableInteger = function(e, t, r, n) {
                        try {
                            return this.isValidInstance() ? this.getFeatureVariableForType(e, t, C.INTEGER, r, n) : (this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "getFeatureVariableInteger"), null)
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.getFeatureVariableString = function(e, t, r, n) {
                        try {
                            return this.isValidInstance() ? this.getFeatureVariableForType(e, t, C.STRING, r, n) : (this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "getFeatureVariableString"), null)
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.getFeatureVariableJSON = function(e, t, r, n) {
                        try {
                            return this.isValidInstance() ? this.getFeatureVariableForType(e, t, C.JSON, r, n) : (this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "getFeatureVariableJSON"), null)
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.getAllFeatureVariables = function(e, t, r) {
                        var n = this;
                        try {
                            if (!this.isValidInstance()) return this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "getAllFeatureVariables"), null;
                            if (!this.validateInputs({
                                    feature_key: e,
                                    user_id: t
                                }, r)) return null;
                            var i = this.projectConfigManager.getConfig();
                            if (!i) return null;
                            var o = en(i, e, this.logger);
                            if (!o) return null;
                            var a = this.createUserContext(t, r),
                                s = this.decisionService.getVariationForFeature(i, o, a).result,
                                l = eB(s),
                                u = {};
                            o.variables.forEach(function(r) {
                                u[r.key] = n.getFeatureVariableValueFromVariation(e, l, s.variation, r, t)
                            });
                            var c = {};
                            return s.decisionSource === L.FEATURE_TEST && null !== s.experiment && null !== s.variation && (c = {
                                experimentKey: s.experiment.key,
                                variationKey: s.variation.key
                            }), this.notificationCenter.sendNotifications(N.DECISION, {
                                type: S.ALL_FEATURE_VARIABLES,
                                userId: t,
                                attributes: r || {},
                                decisionInfo: {
                                    featureKey: e,
                                    featureEnabled: l,
                                    source: s.decisionSource,
                                    variableValues: u,
                                    sourceInfo: c
                                }
                            }), u
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.getOptimizelyConfig = function() {
                        try {
                            return this.projectConfigManager.getConfig() ? this.projectConfigManager.getOptimizelyConfig() : null
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), null
                        }
                    }, e.prototype.close = function() {
                        var e = this;
                        try {
                            var t = this.eventProcessor.stop();
                            return this.disposeOnUpdate && (this.disposeOnUpdate(), this.disposeOnUpdate = null), this.projectConfigManager && this.projectConfigManager.stop(), Object.keys(this.readyTimeouts).forEach(function(t) {
                                var r = e.readyTimeouts[t];
                                clearTimeout(r.readyTimeout), r.onClose()
                            }), this.readyTimeouts = {}, t.then(function() {
                                return {
                                    success: !0
                                }
                            }, function(e) {
                                return {
                                    success: !1,
                                    reason: String(e)
                                }
                            })
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), Promise.resolve({
                                success: !1,
                                reason: String(e)
                            })
                        }
                    }, e.prototype.onReady = function(e) {
                        var t, r, n = this;
                        "object" == typeof e && null !== e && void 0 !== e.timeout && (t = e.timeout), O.isSafeInteger(t) || (t = 3e4);
                        var i = new Promise(function(e) {
                                r = e
                            }),
                            o = this.nextReadyTimeoutId;
                        this.nextReadyTimeoutId++;
                        var a = setTimeout(function() {
                            delete n.readyTimeouts[o], r({
                                success: !1,
                                reason: R("onReady timeout expired after %s ms", t)
                            })
                        }, t);
                        return this.readyTimeouts[o] = {
                            readyTimeout: a,
                            onClose: function() {
                                r({
                                    success: !1,
                                    reason: "Instance closed"
                                })
                            }
                        }, this.readyPromise.then(function() {
                            clearTimeout(a), delete n.readyTimeouts[o], r({
                                success: !0
                            })
                        }), Promise.race([this.readyPromise, i])
                    }, e.prototype.createUserContext = function(e, t) {
                        return this.validateInputs({
                            user_id: e
                        }, t) ? new G({
                            optimizely: this,
                            userId: e,
                            attributes: t
                        }) : null
                    }, e.prototype.decide = function(e, r, n) {
                        var i, o, a, s, l = this;
                        void 0 === n && (n = []);
                        var u, c = e.getUserId(),
                            d = e.getAttributes(),
                            f = this.projectConfigManager.getConfig(),
                            E = [];
                        if (!this.isValidInstance() || !f) return this.logger.log(m.INFO, A.INVALID_OBJECT, "OPTIMIZELY", "decide"), K(r, e, [P.SDK_NOT_READY]);
                        var g = f.featureKeyMap[r];
                        if (!g) return this.logger.log(m.ERROR, T.FEATURE_NOT_IN_DATAFILE, "OPTIMIZELY", r), K(r, e, [R(P.FLAG_KEY_INVALID, r)]);
                        var h = this.getAllDecideOptions(n),
                            v = this.decisionService.findValidatedForcedDecision(f, e, r);
                        E.push.apply(E, v.reasons);
                        var I = v.result;
                        if (I) u = {
                            experiment: null,
                            variation: I,
                            decisionSource: L.FEATURE_TEST
                        };
                        else {
                            var _ = this.decisionService.getVariationForFeature(f, g, e, h);
                            E.push.apply(E, _.reasons), u = _.result
                        }
                        var y = u.decisionSource,
                            O = null !== (o = null === (i = u.experiment) || void 0 === i ? void 0 : i.key) && void 0 !== o ? o : null,
                            D = null !== (s = null === (a = u.variation) || void 0 === a ? void 0 : a.key) && void 0 !== s ? s : null,
                            U = eB(u);
                        !0 === U ? this.logger.log(m.INFO, A.FEATURE_ENABLED_FOR_USER, "OPTIMIZELY", r, c) : this.logger.log(m.INFO, A.FEATURE_NOT_ENABLED_FOR_USER, "OPTIMIZELY", r, c);
                        var C = {},
                            b = !1;
                        h[t.N1.EXCLUDE_VARIABLES] || g.variables.forEach(function(e) {
                            C[e.key] = l.getFeatureVariableValueFromVariation(r, U, u.variation, e, c)
                        }), !h[t.N1.DISABLE_DECISION_EVENT] && (y === L.FEATURE_TEST || y === L.ROLLOUT && ea(f)) && (this.sendImpressionEvent(u, r, c, U, d), b = !0);
                        var V = [];
                        h[t.N1.INCLUDE_REASONS] && (V = E.map(function(e) {
                            return R.apply(void 0, p([e[0]], e.slice(1)))
                        }));
                        var F = {
                            flagKey: r,
                            enabled: U,
                            variationKey: D,
                            ruleKey: O,
                            variables: C,
                            reasons: V,
                            decisionEventDispatched: b
                        };
                        return this.notificationCenter.sendNotifications(N.DECISION, {
                            type: S.FLAG,
                            userId: c,
                            attributes: d,
                            decisionInfo: F
                        }), {
                            variationKey: D,
                            enabled: U,
                            variables: C,
                            ruleKey: O,
                            flagKey: r,
                            userContext: e,
                            reasons: V
                        }
                    }, e.prototype.getAllDecideOptions = function(e) {
                        var r = this,
                            n = E({}, this.defaultDecideOptions);
                        return Array.isArray(e) ? e.forEach(function(e) {
                            t.N1[e] ? n[e] = !0 : r.logger.log(m.WARNING, A.UNRECOGNIZED_DECIDE_OPTION, "OPTIMIZELY", e)
                        }) : this.logger.log(m.DEBUG, A.INVALID_DECIDE_OPTIONS, "OPTIMIZELY"), n
                    }, e.prototype.decideForKeys = function(e, r, n) {
                        var i = this;
                        void 0 === n && (n = []);
                        var o = {};
                        if (!this.isValidInstance()) return this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "decideForKeys"), o;
                        if (0 === r.length) return o;
                        var a = this.getAllDecideOptions(n);
                        return r.forEach(function(r) {
                            var s = i.decide(e, r, n);
                            a[t.N1.ENABLED_FLAGS_ONLY] && !s.enabled || (o[r] = s)
                        }), o
                    }, e.prototype.decideAll = function(e, t) {
                        void 0 === t && (t = []);
                        var r = this.projectConfigManager.getConfig();
                        if (!this.isValidInstance() || !r) return this.logger.log(m.ERROR, A.INVALID_OBJECT, "OPTIMIZELY", "decideAll"), {};
                        var n = Object.keys(r.featureKeyMap);
                        return this.decideForKeys(e, n, t)
                    }, e
                }(),
                ez = function() {
                    function e(e) {
                        var t = this;
                        this.logger = e.logger, this.errorHandler = e.errorHandler, this.notificationListeners = {}, v(N).forEach(function(e) {
                            t.notificationListeners[e] = []
                        }), this.listenerId = 1
                    }
                    return e.prototype.addNotificationListener = function(e, t) {
                        try {
                            if (!(v(N).indexOf(e) > -1)) return -1;
                            this.notificationListeners[e] || (this.notificationListeners[e] = []);
                            var r = !1;
                            if ((this.notificationListeners[e] || []).forEach(function(e) {
                                    e.callback !== t || (r = !0)
                                }), r) return -1;
                            this.notificationListeners[e].push({
                                id: this.listenerId,
                                callback: t
                            });
                            var n = this.listenerId;
                            return this.listenerId += 1, n
                        } catch (e) {
                            return this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e), -1
                        }
                    }, e.prototype.removeNotificationListener = function(e) {
                        var t, r, n = this;
                        try {
                            if (Object.keys(this.notificationListeners).some(function(i) {
                                    return (n.notificationListeners[i] || []).every(function(n, o) {
                                        return n.id !== e || (t = o, r = i, !1)
                                    }), void 0 !== t && void 0 !== r
                                }), void 0 !== t && void 0 !== r) return this.notificationListeners[r].splice(t, 1), !0
                        } catch (e) {
                            this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e)
                        }
                        return !1
                    }, e.prototype.clearAllNotificationListeners = function() {
                        var e = this;
                        try {
                            v(N).forEach(function(t) {
                                e.notificationListeners[t] = []
                            })
                        } catch (e) {
                            this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e)
                        }
                    }, e.prototype.clearNotificationListeners = function(e) {
                        try {
                            this.notificationListeners[e] = []
                        } catch (e) {
                            this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e)
                        }
                    }, e.prototype.sendNotifications = function(e, t) {
                        var r = this;
                        try {
                            (this.notificationListeners[e] || []).forEach(function(n) {
                                var i = n.callback;
                                try {
                                    i(t)
                                } catch (t) {
                                    r.logger.log(m.ERROR, A.NOTIFICATION_LISTENER_EXCEPTION, "NOTIFICATION_CENTER", e, t.message)
                                }
                            })
                        } catch (e) {
                            this.logger.log(m.ERROR, e.message), this.errorHandler.handleError(e)
                        }
                    }, e
                }(),
                eX = {
                    createEventProcessor: function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        return new(u.LogTierV1EventProcessor.bind.apply(u.LogTierV1EventProcessor, p([void 0], e)))
                    },
                    LocalStoragePendingEventsDispatcher: u.LocalStoragePendingEventsDispatcher
                },
                eq = l.getLogger();
            l.setLogHandler(B()), l.setLogLevel(l.LogLevel.INFO);
            var eW = !1;
            l.setLogHandler, l.setLogLevel, t.N1, t.Fs = function(e) {
                try {
                    var t, r, n = !1;
                    e.errorHandler && l.setErrorHandler(e.errorHandler), e.logger && (l.setLogHandler(e.logger), l.setLogLevel(l.LogLevel.NOTSET)), void 0 !== e.logLevel && l.setLogLevel(e.logLevel);
                    try {
                        M(e), n = !0
                    } catch (e) {
                        eq.error(e)
                    }
                    var i = void 0;
                    null == e.eventDispatcher ? (i = new u.LocalStoragePendingEventsDispatcher({
                        eventDispatcher: w
                    }), eW || (i.sendPendingEvents(), eW = !0)) : i = e.eventDispatcher;
                    var o = e.eventBatchSize,
                        a = e.eventFlushInterval;
                    t = e.eventBatchSize, !("number" != typeof t || !O.isSafeInteger(t)) && t >= 1 || (eq.warn("Invalid eventBatchSize %s, defaulting to %s", e.eventBatchSize, 10), o = 10), r = e.eventFlushInterval, !("number" != typeof r || !O.isSafeInteger(r)) && r > 0 || (eq.warn("Invalid eventFlushInterval %s, defaulting to %s", e.eventFlushInterval, 1e3), a = 1e3);
                    var s = l.getErrorHandler(),
                        c = new ez({
                            logger: eq,
                            errorHandler: s
                        }),
                        d = {
                            dispatcher: i,
                            flushInterval: a,
                            batchSize: o,
                            maxQueueSize: e.eventMaxQueueSize || 1e4,
                            notificationCenter: c
                        },
                        p = E(E({
                            clientEngine: "javascript-sdk"
                        }, e), {
                            eventProcessor: eX.createEventProcessor(d),
                            logger: eq,
                            errorHandler: s,
                            datafileManager: e.sdkKey ? function(e, t, r, n) {
                                var i = {
                                    sdkKey: e
                                };
                                if ((void 0 === n || "object" == typeof n && null !== n) && O.assign(i, n), r) {
                                    var o = eo({
                                            datafile: r,
                                            jsonSchemaValidator: void 0,
                                            logger: t
                                        }),
                                        a = o.configObj,
                                        s = o.error;
                                    s && t.error(s), a && (i.datafile = ei(a))
                                }
                                return new f.HttpPollingDatafileManager(i)
                            }(e.sdkKey, eq, e.datafile, e.datafileOptions) : void 0,
                            notificationCenter: c,
                            isValidInstance: n
                        }),
                        g = new eZ(p);
                    try {
                        if ("function" == typeof window.addEventListener) {
                            var h = "onpagehide" in window ? "pagehide" : "unload";
                            window.addEventListener(h, function() {
                                g.close()
                            }, !1)
                        }
                    } catch (e) {
                        eq.error(A.UNABLE_TO_ATTACH_UNLOAD, "INDEX_BROWSER", e.message)
                    }
                    return g
                } catch (e) {
                    return eq.error(e), null
                }
            }
        },
        29364: function(e, t, r) {
            var n = r(40605),
                i = r(6925),
                o = i;
            o.v1 = n, o.v4 = i, e.exports = o
        },
        8152: function(e) {
            for (var t = [], r = 0; r < 256; ++r) t[r] = (r + 256).toString(16).substr(1);
            e.exports = function(e, r) {
                var n = r || 0;
                return [t[e[n++]], t[e[n++]], t[e[n++]], t[e[n++]], "-", t[e[n++]], t[e[n++]], "-", t[e[n++]], t[e[n++]], "-", t[e[n++]], t[e[n++]], "-", t[e[n++]], t[e[n++]], t[e[n++]], t[e[n++]], t[e[n++]], t[e[n++]]].join("")
            }
        },
        81020: function(e) {
            var t = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || "undefined" != typeof msCrypto && "function" == typeof window.msCrypto.getRandomValues && msCrypto.getRandomValues.bind(msCrypto);
            if (t) {
                var r = new Uint8Array(16);
                e.exports = function() {
                    return t(r), r
                }
            } else {
                var n = Array(16);
                e.exports = function() {
                    for (var e, t = 0; t < 16; t++)(3 & t) == 0 && (e = 4294967296 * Math.random()), n[t] = e >>> ((3 & t) << 3) & 255;
                    return n
                }
            }
        },
        40605: function(e, t, r) {
            var n, i, o = r(81020),
                a = r(8152),
                s = 0,
                l = 0;
            e.exports = function(e, t, r) {
                var u = t && r || 0,
                    c = t || [],
                    d = (e = e || {}).node || n,
                    f = void 0 !== e.clockseq ? e.clockseq : i;
                if (null == d || null == f) {
                    var E = o();
                    null == d && (d = n = [1 | E[0], E[1], E[2], E[3], E[4], E[5]]), null == f && (f = i = (E[6] << 8 | E[7]) & 16383)
                }
                var p = void 0 !== e.msecs ? e.msecs : new Date().getTime(),
                    g = void 0 !== e.nsecs ? e.nsecs : l + 1,
                    h = p - s + (g - l) / 1e4;
                if (h < 0 && void 0 === e.clockseq && (f = f + 1 & 16383), (h < 0 || p > s) && void 0 === e.nsecs && (g = 0), g >= 1e4) throw Error("uuid.v1(): Can't create more than 10M uuids/sec");
                s = p, l = g, i = f;
                var v = ((268435455 & (p += 122192928e5)) * 1e4 + g) % 4294967296;
                c[u++] = v >>> 24 & 255, c[u++] = v >>> 16 & 255, c[u++] = v >>> 8 & 255, c[u++] = 255 & v;
                var I = p / 4294967296 * 1e4 & 268435455;
                c[u++] = I >>> 8 & 255, c[u++] = 255 & I, c[u++] = I >>> 24 & 15 | 16, c[u++] = I >>> 16 & 255, c[u++] = f >>> 8 | 128, c[u++] = 255 & f;
                for (var _ = 0; _ < 6; ++_) c[u + _] = d[_];
                return t || a(c)
            }
        },
        6925: function(e, t, r) {
            var n = r(81020),
                i = r(8152);
            e.exports = function(e, t, r) {
                var o = t && r || 0;
                "string" == typeof e && (t = "binary" === e ? Array(16) : null, e = null);
                var a = (e = e || {}).random || (e.rng || n)();
                if (a[6] = 15 & a[6] | 64, a[8] = 63 & a[8] | 128, t)
                    for (var s = 0; s < 16; ++s) t[o + s] = a[s];
                return t || i(a)
            }
        },
        58053: function(e) {
            ! function() {
                function t(e, t) {
                    var r, n, i, o, a, s;
                    for (r = 3 & e.length, n = e.length - r, i = t, s = 0; s < n;) a = 255 & e.charCodeAt(s) | (255 & e.charCodeAt(++s)) << 8 | (255 & e.charCodeAt(++s)) << 16 | (255 & e.charCodeAt(++s)) << 24, ++s, i ^= a = (65535 & (a = (a = (65535 & a) * 3432918353 + (((a >>> 16) * 3432918353 & 65535) << 16) & 4294967295) << 15 | a >>> 17)) * 461845907 + (((a >>> 16) * 461845907 & 65535) << 16) & 4294967295, i = (65535 & (o = (65535 & (i = i << 13 | i >>> 19)) * 5 + (((i >>> 16) * 5 & 65535) << 16) & 4294967295)) + 27492 + (((o >>> 16) + 58964 & 65535) << 16);
                    switch (a = 0, r) {
                        case 3:
                            a ^= (255 & e.charCodeAt(s + 2)) << 16;
                        case 2:
                            a ^= (255 & e.charCodeAt(s + 1)) << 8;
                        case 1:
                            a ^= 255 & e.charCodeAt(s), i ^= a = (65535 & (a = (a = (65535 & a) * 3432918353 + (((a >>> 16) * 3432918353 & 65535) << 16) & 4294967295) << 15 | a >>> 17)) * 461845907 + (((a >>> 16) * 461845907 & 65535) << 16) & 4294967295
                    }
                    return i ^= e.length, i ^= i >>> 16, i = (65535 & i) * 2246822507 + (((i >>> 16) * 2246822507 & 65535) << 16) & 4294967295, i ^= i >>> 13, i = (65535 & i) * 3266489909 + (((i >>> 16) * 3266489909 & 65535) << 16) & 4294967295, (i ^= i >>> 16) >>> 0
                }
                var r = t;
                r.v2 = function(e, t) {
                    for (var r, n = e.length, i = t ^ n, o = 0; n >= 4;) r = (65535 & (r = 255 & e.charCodeAt(o) | (255 & e.charCodeAt(++o)) << 8 | (255 & e.charCodeAt(++o)) << 16 | (255 & e.charCodeAt(++o)) << 24)) * 1540483477 + (((r >>> 16) * 1540483477 & 65535) << 16), r ^= r >>> 24, i = (65535 & i) * 1540483477 + (((i >>> 16) * 1540483477 & 65535) << 16) ^ (r = (65535 & r) * 1540483477 + (((r >>> 16) * 1540483477 & 65535) << 16)), n -= 4, ++o;
                    switch (n) {
                        case 3:
                            i ^= (255 & e.charCodeAt(o + 2)) << 16;
                        case 2:
                            i ^= (255 & e.charCodeAt(o + 1)) << 8;
                        case 1:
                            i ^= 255 & e.charCodeAt(o), i = (65535 & i) * 1540483477 + (((i >>> 16) * 1540483477 & 65535) << 16)
                    }
                    return i ^= i >>> 13, i = (65535 & i) * 1540483477 + (((i >>> 16) * 1540483477 & 65535) << 16), (i ^= i >>> 15) >>> 0
                }, r.v3 = t, e.exports = r
            }()
        },
        4298: function(e, t, r) {
            e.exports = r(85442)
        },
        80397: function(e, t, r) {
            "use strict";
            r.d(t, {
                V: function() {
                    return eT
                }
            });
            var n = r(67294),
                i = r.t(n, 2),
                o = r(87462);

            function a(e, t, {
                checkForDefaultPrevented: r = !0
            } = {}) {
                return function(n) {
                    if (null == e || e(n), !1 === r || !n.defaultPrevented) return null == t ? void 0 : t(n)
                }
            }

            function s(...e) {
                return t => e.forEach(e => {
                    var r;
                    "function" == typeof(r = e) ? r(t): null != r && (r.current = t)
                })
            }

            function l(...e) {
                return (0, n.useCallback)(s(...e), e)
            }
            let u = (null == globalThis ? void 0 : globalThis.document) ? n.useLayoutEffect : () => {},
                c = i["useId".toString()] || (() => void 0),
                d = 0;

            function f(e) {
                let [t, r] = n.useState(c());
                return u(() => {
                    e || r(e => null != e ? e : String(d++))
                }, [e]), e || (t ? `radix-${t}` : "")
            }

            function E(e) {
                let t = (0, n.useRef)(e);
                return (0, n.useEffect)(() => {
                    t.current = e
                }), (0, n.useMemo)(() => (...e) => {
                    var r;
                    return null === (r = t.current) || void 0 === r ? void 0 : r.call(t, ...e)
                }, [])
            }
            var p = r(66593),
                g = r(37802),
                h = r(93090),
                v = r(73935);
            let I = e => {
                let {
                    present: t,
                    children: r
                } = e, i = function(e) {
                    var t;
                    let [r, i] = (0, n.useState)(), o = (0, n.useRef)({}), a = (0, n.useRef)(e), s = (0, n.useRef)("none"), [l, c] = (t = {
                        mounted: {
                            UNMOUNT: "unmounted",
                            ANIMATION_OUT: "unmountSuspended"
                        },
                        unmountSuspended: {
                            MOUNT: "mounted",
                            ANIMATION_END: "unmounted"
                        },
                        unmounted: {
                            MOUNT: "mounted"
                        }
                    }, (0, n.useReducer)((e, r) => {
                        let n = t[e][r];
                        return null != n ? n : e
                    }, e ? "mounted" : "unmounted"));
                    return (0, n.useEffect)(() => {
                        let e = _(o.current);
                        s.current = "mounted" === l ? e : "none"
                    }, [l]), u(() => {
                        let t = o.current,
                            r = a.current;
                        if (r !== e) {
                            let n = s.current,
                                i = _(t);
                            e ? c("MOUNT") : "none" === i || (null == t ? void 0 : t.display) === "none" ? c("UNMOUNT") : r && n !== i ? c("ANIMATION_OUT") : c("UNMOUNT"), a.current = e
                        }
                    }, [e, c]), u(() => {
                        if (r) {
                            let e = e => {
                                    let t = _(o.current),
                                        n = t.includes(e.animationName);
                                    e.target === r && n && (0, v.flushSync)(() => c("ANIMATION_END"))
                                },
                                t = e => {
                                    e.target === r && (s.current = _(o.current))
                                };
                            return r.addEventListener("animationstart", t), r.addEventListener("animationcancel", e), r.addEventListener("animationend", e), () => {
                                r.removeEventListener("animationstart", t), r.removeEventListener("animationcancel", e), r.removeEventListener("animationend", e)
                            }
                        }
                        c("ANIMATION_END")
                    }, [r, c]), {
                        isPresent: ["mounted", "unmountSuspended"].includes(l),
                        ref: (0, n.useCallback)(e => {
                            e && (o.current = getComputedStyle(e)), i(e)
                        }, [])
                    }
                }(t), o = "function" == typeof r ? r({
                    present: i.isPresent
                }) : n.Children.only(r), a = l(i.ref, o.ref);
                return "function" == typeof r || i.isPresent ? (0, n.cloneElement)(o, {
                    ref: a
                }) : null
            };

            function _(e) {
                return (null == e ? void 0 : e.animationName) || "none"
            }
            I.displayName = "Presence";
            let y = (0, n.forwardRef)((e, t) => {
                let {
                    children: r,
                    ...i
                } = e, a = n.Children.toArray(r), s = a.find(O);
                if (s) {
                    let e = s.props.children,
                        r = a.map(t => t !== s ? t : n.Children.count(e) > 1 ? n.Children.only(null) : (0, n.isValidElement)(e) ? e.props.children : null);
                    return (0, n.createElement)(R, (0, o.Z)({}, i, {
                        ref: t
                    }), (0, n.isValidElement)(e) ? (0, n.cloneElement)(e, void 0, r) : null)
                }
                return (0, n.createElement)(R, (0, o.Z)({}, i, {
                    ref: t
                }), r)
            });
            y.displayName = "Slot";
            let R = (0, n.forwardRef)((e, t) => {
                let {
                    children: r,
                    ...i
                } = e;
                return (0, n.isValidElement)(r) ? (0, n.cloneElement)(r, { ... function(e, t) {
                        let r = { ...t
                        };
                        for (let n in t) {
                            let i = e[n],
                                o = t[n],
                                a = /^on[A-Z]/.test(n);
                            a ? i && o ? r[n] = (...e) => {
                                o(...e), i(...e)
                            } : i && (r[n] = i) : "style" === n ? r[n] = { ...i,
                                ...o
                            } : "className" === n && (r[n] = [i, o].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...r
                        }
                    }(i, r.props),
                    ref: t ? s(t, r.ref) : r.ref
                }) : n.Children.count(r) > 1 ? n.Children.only(null) : null
            });
            R.displayName = "SlotClone";
            let N = ({
                children: e
            }) => (0, n.createElement)(n.Fragment, null, e);

            function O(e) {
                return (0, n.isValidElement)(e) && e.type === N
            }
            let m = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let r = (0, n.forwardRef)((e, r) => {
                    let {
                        asChild: i,
                        ...a
                    } = e, s = i ? y : t;
                    return (0, n.useEffect)(() => {
                        window[Symbol.for("radix-ui")] = !0
                    }, []), (0, n.createElement)(s, (0, o.Z)({}, a, {
                        ref: r
                    }))
                });
                return r.displayName = `Primitive.${t}`, { ...e,
                    [t]: r
                }
            }, {});
            var T = r(27552),
                A = r(71860),
                D = r(23541);
            let S = "Dialog",
                [L, U] = function(e, t = []) {
                    let r = [],
                        i = () => {
                            let t = r.map(e => (0, n.createContext)(e));
                            return function(r) {
                                let i = (null == r ? void 0 : r[e]) || t;
                                return (0, n.useMemo)(() => ({
                                    [`__scope${e}`]: { ...r,
                                        [e]: i
                                    }
                                }), [r, i])
                            }
                        };
                    return i.scopeName = e, [function(t, i) {
                        let o = (0, n.createContext)(i),
                            a = r.length;

                        function s(t) {
                            let {
                                scope: r,
                                children: i,
                                ...s
                            } = t, l = (null == r ? void 0 : r[e][a]) || o, u = (0, n.useMemo)(() => s, Object.values(s));
                            return (0, n.createElement)(l.Provider, {
                                value: u
                            }, i)
                        }
                        return r = [...r, i], s.displayName = t + "Provider", [s, function(r, s) {
                            let l = (null == s ? void 0 : s[e][a]) || o,
                                u = (0, n.useContext)(l);
                            if (u) return u;
                            if (void 0 !== i) return i;
                            throw Error(`\`${r}\` must be used within \`${t}\``)
                        }]
                    }, function(...e) {
                        let t = e[0];
                        if (1 === e.length) return t;
                        let r = () => {
                            let r = e.map(e => ({
                                useScope: e(),
                                scopeName: e.scopeName
                            }));
                            return function(e) {
                                let i = r.reduce((t, {
                                    useScope: r,
                                    scopeName: n
                                }) => {
                                    let i = r(e),
                                        o = i[`__scope${n}`];
                                    return { ...t,
                                        ...o
                                    }
                                }, {});
                                return (0, n.useMemo)(() => ({
                                    [`__scope${t.scopeName}`]: i
                                }), [i])
                            }
                        };
                        return r.scopeName = t.scopeName, r
                    }(i, ...t)]
                }(S),
                [C, b] = L(S),
                P = e => {
                    let {
                        __scopeDialog: t,
                        children: r,
                        open: i,
                        defaultOpen: o,
                        onOpenChange: a,
                        modal: s = !0
                    } = e, l = (0, n.useRef)(null), u = (0, n.useRef)(null), [c = !1, d] = function({
                        prop: e,
                        defaultProp: t,
                        onChange: r = () => {}
                    }) {
                        let [i, o] = function({
                            defaultProp: e,
                            onChange: t
                        }) {
                            let r = (0, n.useState)(e),
                                [i] = r,
                                o = (0, n.useRef)(i),
                                a = E(t);
                            return (0, n.useEffect)(() => {
                                o.current !== i && (a(i), o.current = i)
                            }, [i, o, a]), r
                        }({
                            defaultProp: t,
                            onChange: r
                        }), a = void 0 !== e, s = E(r), l = (0, n.useCallback)(t => {
                            if (a) {
                                let r = "function" == typeof t ? t(e) : t;
                                r !== e && s(r)
                            } else o(t)
                        }, [a, e, o, s]);
                        return [a ? e : i, l]
                    }({
                        prop: i,
                        defaultProp: o,
                        onChange: a
                    });
                    return (0, n.createElement)(C, {
                        scope: t,
                        triggerRef: l,
                        contentRef: u,
                        contentId: f(),
                        titleId: f(),
                        descriptionId: f(),
                        open: c,
                        onOpenChange: d,
                        onOpenToggle: (0, n.useCallback)(() => d(e => !e), [d]),
                        modal: s
                    }, r)
                },
                V = (0, n.forwardRef)((e, t) => {
                    let {
                        __scopeDialog: r,
                        ...i
                    } = e, s = b("DialogTrigger", r), u = l(t, s.triggerRef);
                    return (0, n.createElement)(m.button, (0, o.Z)({
                        type: "button",
                        "aria-haspopup": "dialog",
                        "aria-expanded": s.open,
                        "aria-controls": s.contentId,
                        "data-state": J(s.open)
                    }, i, {
                        ref: u,
                        onClick: a(e.onClick, s.onOpenToggle)
                    }))
                }),
                F = "DialogPortal",
                [M, x] = L(F, {
                    forceMount: void 0
                }),
                w = e => {
                    let {
                        __scopeDialog: t,
                        forceMount: r,
                        children: i,
                        container: o
                    } = e, a = b(F, t);
                    return (0, n.createElement)(M, {
                        scope: t,
                        forceMount: r
                    }, n.Children.map(i, e => (0, n.createElement)(I, {
                        present: r || a.open
                    }, (0, n.createElement)(h.h, {
                        asChild: !0,
                        container: o
                    }, e))))
                },
                k = "DialogOverlay",
                B = (0, n.forwardRef)((e, t) => {
                    let r = x(k, e.__scopeDialog),
                        {
                            forceMount: i = r.forceMount,
                            ...a
                        } = e,
                        s = b(k, e.__scopeDialog);
                    return s.modal ? (0, n.createElement)(I, {
                        present: i || s.open
                    }, (0, n.createElement)(K, (0, o.Z)({}, a, {
                        ref: t
                    }))) : null
                }),
                K = (0, n.forwardRef)((e, t) => {
                    let {
                        __scopeDialog: r,
                        ...i
                    } = e, a = b(k, r);
                    return (0, n.createElement)(A.Z, {
                        as: y,
                        allowPinchZoom: !0,
                        shards: [a.contentRef]
                    }, (0, n.createElement)(m.div, (0, o.Z)({
                        "data-state": J(a.open)
                    }, i, {
                        ref: t,
                        style: {
                            pointerEvents: "auto",
                            ...i.style
                        }
                    })))
                }),
                G = "DialogContent",
                j = (0, n.forwardRef)((e, t) => {
                    let r = x(G, e.__scopeDialog),
                        {
                            forceMount: i = r.forceMount,
                            ...a
                        } = e,
                        s = b(G, e.__scopeDialog);
                    return (0, n.createElement)(I, {
                        present: i || s.open
                    }, s.modal ? (0, n.createElement)(H, (0, o.Z)({}, a, {
                        ref: t
                    })) : (0, n.createElement)(Y, (0, o.Z)({}, a, {
                        ref: t
                    })))
                }),
                H = (0, n.forwardRef)((e, t) => {
                    let r = b(G, e.__scopeDialog),
                        i = (0, n.useRef)(null),
                        s = l(t, r.contentRef, i);
                    return (0, n.useEffect)(() => {
                        let e = i.current;
                        if (e) return (0, D.Ry)(e)
                    }, []), (0, n.createElement)(Z, (0, o.Z)({}, e, {
                        ref: s,
                        trapFocus: r.open,
                        disableOutsidePointerEvents: !0,
                        onCloseAutoFocus: a(e.onCloseAutoFocus, e => {
                            var t;
                            e.preventDefault(), null === (t = r.triggerRef.current) || void 0 === t || t.focus()
                        }),
                        onPointerDownOutside: a(e.onPointerDownOutside, e => {
                            let t = e.detail.originalEvent,
                                r = 0 === t.button && !0 === t.ctrlKey,
                                n = 2 === t.button || r;
                            n && e.preventDefault()
                        }),
                        onFocusOutside: a(e.onFocusOutside, e => e.preventDefault())
                    }))
                }),
                Y = (0, n.forwardRef)((e, t) => {
                    let r = b(G, e.__scopeDialog),
                        i = (0, n.useRef)(!1),
                        a = (0, n.useRef)(!1);
                    return (0, n.createElement)(Z, (0, o.Z)({}, e, {
                        ref: t,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        onCloseAutoFocus: t => {
                            var n, o;
                            null === (n = e.onCloseAutoFocus) || void 0 === n || n.call(e, t), t.defaultPrevented || (i.current || null === (o = r.triggerRef.current) || void 0 === o || o.focus(), t.preventDefault()), i.current = !1, a.current = !1
                        },
                        onInteractOutside: t => {
                            var n, o;
                            null === (n = e.onInteractOutside) || void 0 === n || n.call(e, t), t.defaultPrevented || (i.current = !0, "pointerdown" !== t.detail.originalEvent.type || (a.current = !0));
                            let s = t.target,
                                l = null === (o = r.triggerRef.current) || void 0 === o ? void 0 : o.contains(s);
                            l && t.preventDefault(), "focusin" === t.detail.originalEvent.type && a.current && t.preventDefault()
                        }
                    }))
                }),
                Z = (0, n.forwardRef)((e, t) => {
                    let {
                        __scopeDialog: r,
                        trapFocus: i,
                        onOpenAutoFocus: a,
                        onCloseAutoFocus: s,
                        ...u
                    } = e, c = b(G, r), d = (0, n.useRef)(null), f = l(t, d);
                    return (0, T.EW)(), (0, n.createElement)(n.Fragment, null, (0, n.createElement)(g.M, {
                        asChild: !0,
                        loop: !0,
                        trapped: i,
                        onMountAutoFocus: a,
                        onUnmountAutoFocus: s
                    }, (0, n.createElement)(p.XB, (0, o.Z)({
                        role: "dialog",
                        id: c.contentId,
                        "aria-describedby": c.descriptionId,
                        "aria-labelledby": c.titleId,
                        "data-state": J(c.open)
                    }, u, {
                        ref: f,
                        onDismiss: () => c.onOpenChange(!1)
                    }))), !1)
                }),
                z = "DialogTitle",
                X = (0, n.forwardRef)((e, t) => {
                    let {
                        __scopeDialog: r,
                        ...i
                    } = e, a = b(z, r);
                    return (0, n.createElement)(m.h2, (0, o.Z)({
                        id: a.titleId
                    }, i, {
                        ref: t
                    }))
                }),
                q = (0, n.forwardRef)((e, t) => {
                    let {
                        __scopeDialog: r,
                        ...i
                    } = e, a = b("DialogDescription", r);
                    return (0, n.createElement)(m.p, (0, o.Z)({
                        id: a.descriptionId
                    }, i, {
                        ref: t
                    }))
                }),
                W = (0, n.forwardRef)((e, t) => {
                    let {
                        __scopeDialog: r,
                        ...i
                    } = e, s = b("DialogClose", r);
                    return (0, n.createElement)(m.button, (0, o.Z)({
                        type: "button"
                    }, i, {
                        ref: t,
                        onClick: a(e.onClick, () => s.onOpenChange(!1))
                    }))
                });

            function J(e) {
                return e ? "open" : "closed"
            }
            let [$, Q] = function(e, t) {
                let r = (0, n.createContext)(t);

                function i(e) {
                    let {
                        children: t,
                        ...i
                    } = e, o = (0, n.useMemo)(() => i, Object.values(i));
                    return (0, n.createElement)(r.Provider, {
                        value: o
                    }, t)
                }
                return i.displayName = e + "Provider", [i, function(i) {
                    let o = (0, n.useContext)(r);
                    if (o) return o;
                    if (void 0 !== t) return t;
                    throw Error(`\`${i}\` must be used within \`${e}\``)
                }]
            }("DialogTitleWarning", {
                contentName: G,
                titleName: z,
                docsSlug: "dialog"
            });
            var ee = r(29107),
                et = r(33274);
            let er = (0, n.forwardRef)((e, t) => n.createElement(et.f, {
                ref: t,
                ...e
            }));
            er.displayName = "VisuallyHidden";
            var en = r(74934);
            let ei = (0, ee.j)(["fill-current"], {
                    variants: {
                        intent: (0, en.TY)({
                            current: ["text-current"],
                            main: ["text-main"],
                            support: ["text-support"],
                            accent: ["text-accent"],
                            basic: ["text-basic"],
                            success: ["text-success"],
                            alert: ["text-alert"],
                            error: ["text-error"],
                            info: ["text-info"],
                            neutral: ["text-neutral"]
                        }),
                        size: (0, en.TY)({
                            current: ["u-current-font-size"],
                            sm: ["w-sz-16", "h-sz-16"],
                            md: ["w-sz-24", "h-sz-24"],
                            lg: ["w-sz-32", "h-sz-32"],
                            xl: ["w-sz-40", "h-sz-40"]
                        })
                    }
                }),
                eo = ({
                    label: e,
                    className: t,
                    size: r = "current",
                    intent: i = "current",
                    children: o,
                    ...a
                }) => {
                    let s = n.Children.only(o);
                    return n.createElement(n.Fragment, null, (0, n.cloneElement)(s, {
                        className: ei({
                            className: t,
                            size: r,
                            intent: i
                        }),
                        "data-spark-component": "icon",
                        "aria-hidden": "true",
                        focusable: "false",
                        ...a
                    }), e && n.createElement(er, null, e))
                };
            eo.displayName = "Icon";
            var ea = r(93845);
            let es = (0, n.createContext)(null),
                el = ({
                    children: e
                }) => {
                    let [t, r] = (0, n.useState)(!1);
                    return n.createElement(es.Provider, {
                        value: {
                            isFullScreen: t,
                            setIsFullScreen: r
                        }
                    }, e)
                },
                eu = () => {
                    let e = (0, n.useContext)(es);
                    if (!e) throw Error("useDialog must be used within a Dialog provider");
                    return e
                },
                ec = ({
                    children: e,
                    ...t
                }) => n.createElement(el, null, n.createElement(P, { ...t
                }, e));
            ec.displayName = "Dialog.Root";
            let ed = (0, ee.j)(["grow", "overflow-y-auto", "outline-none", "focus-visible:u-ring"], {
                    variants: {
                        inset: {
                            true: "",
                            false: "px-xl py-lg"
                        }
                    }
                }),
                ef = (0, n.forwardRef)(({
                    children: e,
                    className: t,
                    inset: r = !1,
                    ...i
                }, o) => n.createElement("div", {
                    ref: o,
                    className: ed({
                        inset: r,
                        className: t
                    }),
                    ...i
                }, e));
            ef.displayName = "Dialog.Body";
            let eE = (0, n.forwardRef)((e, t) => n.createElement(W, {
                ref: t,
                ...e
            }));
            eE.displayName = "Dialog.Close";
            let ep = n.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: r = "none",
                ...i
            }, o) => n.createElement("svg", {
                ref: o,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "Close",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: r,
                ...i,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m21.6,19.67l-7.68-7.68,7.57-7.59c.53-.53.53-1.4,0-1.93-.53-.53-1.4-.53-1.93,0l-7.57,7.58L4.33,2.4c-.53-.53-1.4-.53-1.93,0-.53.53-.53,1.4,0,1.93l7.66,7.66-7.66,7.65c-.53.53-.53,1.4,0,1.93.53.53,1.4.53,1.93,0l7.66-7.66,7.68,7.68c.53.53,1.4.53,1.93,0,.53-.53.53-1.4,0-1.93h0Z"/>'
                }
            }));
            ep.displayName = "Close";
            let eg = (0, n.forwardRef)(({
                "aria-label": e,
                className: t,
                size: r = "md",
                intent: i = "neutral",
                design: o = "ghost",
                children: a = n.createElement(ep, null),
                ...s
            }, l) => n.createElement(eE, {
                ref: l,
                className: (0, ee.cx)(["absolute", "top-md", "right-xl"], t),
                asChild: !0,
                ...s
            }, n.createElement(ea.h, {
                intent: i,
                size: r,
                design: o,
                "aria-label": e
            }, n.createElement(eo, null, a))));
            eg.displayName = "Dialog.CloseButton";
            let eh = (0, ee.j)(["z-modal flex flex-col bg-surface", "focus-visible:outline-none focus-visible:u-ring"], {
                    variants: {
                        size: {
                            fullscreen: "fixed w-full h-full  top-none left-none",
                            sm: "max-w-sz-480",
                            md: "max-w-sz-672",
                            lg: "max-w-sz-864"
                        },
                        isNarrow: {
                            true: [],
                            false: []
                        }
                    },
                    compoundVariants: [{
                        size: ["sm", "md", "lg"],
                        class: ["fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2", "max-h-[80%]", "shadow-md rounded-lg", "data-[state=open]:animate-fade-in", "data-[state=closed]:animate-fade-out"]
                    }, {
                        size: ["sm", "md", "lg"],
                        isNarrow: !1,
                        class: ["w-full"]
                    }],
                    defaultVariants: {
                        size: "md",
                        isNarrow: !1
                    }
                }),
                ev = (0, n.forwardRef)(({
                    children: e,
                    className: t,
                    isNarrow: r = !1,
                    size: i = "md",
                    ...o
                }, a) => {
                    let {
                        setIsFullScreen: s
                    } = eu();
                    return (0, n.useEffect)(() => ("fullscreen" === i && s(!0), () => s(!1)), [s, i]), n.createElement(j, {
                        "data-spark-component": "dialog-content",
                        ref: a,
                        className: eh({
                            className: t,
                            isNarrow: r,
                            size: i
                        }),
                        ...o
                    }, e)
                });
            ev.displayName = "Dialog.Content";
            let eI = (0, n.forwardRef)((e, t) => n.createElement(q, {
                ref: t,
                ...e
            }));
            eI.displayName = "Dialog.Description";
            let e_ = (0, n.forwardRef)(({
                children: e,
                className: t,
                ...r
            }, i) => n.createElement("footer", {
                ref: i,
                className: (0, ee.cx)(t, ["px-xl", "py-lg"]),
                ...r
            }, e));
            e_.displayName = "Dialog.Footer";
            let ey = (0, n.forwardRef)(({
                children: e,
                className: t,
                ...r
            }, i) => n.createElement("header", {
                ref: i,
                className: (0, ee.cx)(t, ["px-xl", "py-lg"]),
                ...r
            }, e));
            ey.displayName = "Dialog.Header";
            let eR = (0, n.forwardRef)(({
                className: e,
                ...t
            }, r) => {
                let {
                    isFullScreen: i
                } = eu();
                return n.createElement(B, {
                    ref: r,
                    className: (0, ee.cx)(i ? "hidden" : "fixed", ["top-none", "left-none", "w-screen", "h-screen", "z-overlay"], ["bg-overlay/dim-3"], ["data-[state=open]:animate-fade-in"], ["data-[state=closed]:animate-fade-out"], e),
                    ...t
                })
            });
            eR.displayName = "Dialog.Overlay";
            let eN = ({
                children: e,
                ...t
            }) => n.createElement(w, { ...t
            }, e);
            eN.displayName = "Dialog.Portal";
            let eO = (0, n.forwardRef)(({
                className: e,
                ...t
            }, r) => n.createElement(X, {
                ref: r,
                className: (0, ee.cx)("text-headline-1 text-on-surface", e),
                ...t
            }));
            eO.displayName = "Dialog.Title";
            let em = (0, n.forwardRef)((e, t) => n.createElement(V, {
                ref: t,
                ...e
            }));
            em.displayName = "Dialog.Trigger";
            let eT = Object.assign(ec, {
                Trigger: em,
                Portal: eN,
                Overlay: eR,
                Content: ev,
                Header: ey,
                Body: ef,
                Footer: e_,
                Close: eE,
                CloseButton: eg,
                Title: eO,
                Description: eI
            });
            eT.displayName = "Dialog", eT.Trigger.displayName = "Dialog.Trigger", em.displayName = "Dialog.Trigger", eN.displayName = "Dialog.Portal", eR.displayName = "Dialog.Overlay", ev.displayName = "Dialog.Content", ey.displayName = "Dialog.Header", ef.displayName = "Dialog.Body", e_.displayName = "Dialog.Footer", eg.displayName = "Dialog.CloseButton", eO.displayName = "Dialog.Title", eI.displayName = "Dialog.Description"
        },
        67843: function(e, t, r) {
            "use strict";
            r.d(t, {
                x: function() {
                    return i
                }
            });
            var n = r(67294);
            let i = n.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: r = "none",
                ...i
            }, o) => n.createElement("svg", {
                ref: o,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "Close",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: r,
                ...i,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m21.6,19.67l-7.68-7.68,7.57-7.59c.53-.53.53-1.4,0-1.93-.53-.53-1.4-.53-1.93,0l-7.57,7.58L4.33,2.4c-.53-.53-1.4-.53-1.93,0-.53.53-.53,1.4,0,1.93l7.66,7.66-7.66,7.65c-.53.53-.53,1.4,0,1.93.53.53,1.4.53,1.93,0l7.66-7.66,7.68,7.68c.53.53,1.4.53,1.93,0,.53-.53.53-1.4,0-1.93h0Z"/>'
                }
            }));
            i.displayName = "Close"
        },
        64517: function(e, t, r) {
            "use strict";
            r.d(t, {
                E: function() {
                    return i
                }
            });
            var n = r(67294);
            let i = n.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: r = "none",
                ...i
            }, o) => n.createElement("svg", {
                ref: o,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "InfoOutline",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: r,
                ...i,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path d="m12,16.82c.57,0,1.03-.46,1.03-1.03v-4.64c0-.57-.46-1.03-1.03-1.03s-1.03.46-1.03,1.03v4.64c0,.57.46,1.03,1.03,1.03Zm0-7.66c.78,0,1.41-.63,1.41-1.41s-.63-1.41-1.41-1.41-1.41.63-1.41,1.41.63,1.41,1.41,1.41Z"/><path fill-rule="evenodd" d="m12,2C6.48,2,2,6.48,2,12s4.48,10,10,10,10-4.48,10-10S17.52,2,12,2Zm-7.89,10c0-4.36,3.53-7.89,7.89-7.89s7.89,3.53,7.89,7.89-3.53,7.89-7.89,7.89-7.89-3.53-7.89-7.89Z"/>'
                }
            }));
            i.displayName = "InfoOutline"
        },
        56111: function(e, t, r) {
            "use strict";
            r.d(t, {
                K: function() {
                    return i
                }
            });
            var n = r(67294);
            let i = n.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: r = "none",
                ...i
            }, o) => n.createElement("svg", {
                ref: o,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "MessageOutline",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: r,
                ...i,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m2,6.18c0-2.34,1.9-4.18,4.21-4.18h11.5c2.36,0,4.28,1.92,4.28,4.28v14.7c0,.38-.22.74-.56.91-.34.17-.75.14-1.06-.09l-3.66-2.74H6.3c-2.35,0-4.27-1.9-4.28-4.26-.01-2.52-.02-6.03-.01-8.63Zm4.21-2.15c-1.22,0-2.18.96-2.18,2.15,0,2.6,0,6.09.01,8.62,0,1.24,1.01,2.23,2.25,2.23h10.75c.22,0,.43.07.61.2l2.31,1.73V6.28c0-1.24-1.01-2.25-2.25-2.25H6.22Zm10.68,4.17H7.1c-.56,0-1.02-.45-1.02-1.02,0-.56.45-1.02,1.02-1.02h9.8c.56,0,1.02.45,1.02,1.02s-.45,1.02-1.02,1.02Zm0,3.19H7.1c-.56,0-1.02-.45-1.02-1.02,0-.56.45-1.02,1.02-1.02h9.8c.56,0,1.02.45,1.02,1.02s-.45,1.02-1.02,1.02Zm-10.82,2.25c0-.56.45-1.02,1.02-1.02h6.53c.56,0,1.02.45,1.02,1.02s-.45,1.02-1.02,1.02h-6.53c-.56,0-1.02-.45-1.02-1.02Z"/>'
                }
            }));
            i.displayName = "MessageOutline"
        }
    }
]);