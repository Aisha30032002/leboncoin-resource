! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "d02b5e44-e033-4b65-9eac-c1cbeca3c592", e._sentryDebugIdIdentifier = "sentry-dbid-d02b5e44-e033-4b65-9eac-c1cbeca3c592")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [67134], {
        44958: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return j
                }
            });
            var r = n(87462),
                o = n(97685),
                i = n(45987),
                a = n(84497),
                l = n(42505),
                s = n(61148),
                c = n(24292),
                u = n(67294),
                d = n(19181),
                f = n(4942),
                h = n(16678),
                g = n(37947),
                m = n(27856),
                v = n(26072);

            function b(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), n.push.apply(n, r)
                }
                return n
            }

            function p(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? b(Object(n), !0).forEach(function(t) {
                        (0, f.Z)(e, t, n[t])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : b(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    })
                }
                return e
            }
            var y = (0, d.default)("div").withConfig({
                    displayName: "indexstyles__View",
                    componentId: "sc-10uesfx-0"
                })(function(e) {
                    var t = e.edges,
                        n = e.edgesColor;
                    return (0, g.ZP)(p({
                        position: "relative"
                    }, "none" !== t && {
                        "&::after, &::before": {
                            bottom: 0,
                            content: '""',
                            pointerEvents: "none",
                            position: "absolute",
                            top: 0,
                            width: "5rem",
                            zIndex: 1
                        },
                        "&::before": {
                            background: "linear-gradient(90deg, ".concat(n, " 13%, rgba(255, 255, 255, 0) 94%)"),
                            left: 0,
                            opacity: ["both", "start"].includes(t) ? 1 : 0
                        },
                        "&::after": {
                            background: "linear-gradient(90deg, rgba(255, 255, 255, 0) 13%, ".concat(n, " 94%)"),
                            opacity: ["both", "end"].includes(t) ? 1 : 0,
                            right: 0
                        },
                        img: {
                            maxWidth: "none"
                        }
                    }))
                }, (0, h.qC)(h.bK, h.Dh)),
                x = (0, d.default)("ul").withConfig({
                    displayName: "indexstyles__Root",
                    componentId: "sc-10uesfx-1"
                })({
                    "-ms-overflow-style": "none",
                    "-webkit-overflow-scrolling": "touch"
                }, (0, g.ZP)({
                    alignItems: "center",
                    display: "flex",
                    fontSize: 0,
                    overflow: "auto",
                    padding: "none",
                    scrollbarWidth: "none",
                    "@supports(scroll-snap-align: start)": {
                        scrollSnapType: "x mandatory"
                    },
                    "&::-webkit-scrollbar": {
                        height: 0,
                        width: 0
                    }
                }), (0, h.qC)(h.GQ, h.bK, h.Dh)),
                w = (0, d.default)("li").withConfig({
                    displayName: "indexstyles__Slide",
                    componentId: "sc-10uesfx-2"
                })({
                    scrollSnapAlign: "start",
                    scrollSnapStop: "always"
                }, (0, h.qC)(h.GQ, h.bK, h.Dh)),
                C = (0, d.default)("button").withConfig({
                    displayName: "indexstyles__Nav",
                    componentId: "sc-10uesfx-3"
                })(function(e) {
                    var t = e.pos;
                    return (0, g.ZP)(p({
                        alignItems: "center",
                        bg: "white",
                        boxShadow: "0 4px 8px rgba(26, 26, 26, 0.12)",
                        border: "none",
                        borderRadius: "50%",
                        cursor: "pointer",
                        display: "flex",
                        height: "4.5rem",
                        justifyContent: "center",
                        outline: 0,
                        position: "absolute",
                        top: "50%",
                        transform: "translateY(-50%)",
                        width: "4.5rem",
                        zIndex: 2
                    }, "left" === t ? {
                        left: "large"
                    } : {
                        right: "large"
                    }))
                }, (0, h.qC)(h.$_, h.GQ, h.bK, h.FK, h.Dh)),
                Z = ["ariaLabel", "children", "childCss", "edges", "edgesColor", "infinite", "initialIndex", "onChange", "renderContent", "renderNext", "renderPrev", "rootCss", "step", "withControls"],
                E = ["children", "dataQaId"],
                _ = ["children", "dataQaId"],
                j = (0, u.forwardRef)(function(e, t) {
                    var n, f, h, g, b, p, j, N, S, I, P, L, k, O, z = e.ariaLabel,
                        D = e.children,
                        W = e.childCss,
                        M = e.edges,
                        R = e.edgesColor,
                        q = e.infinite,
                        Q = e.initialIndex,
                        T = void 0 === Q ? 0 : Q,
                        K = e.onChange,
                        F = e.renderContent,
                        G = e.renderNext,
                        A = e.renderPrev,
                        B = e.rootCss,
                        H = e.step,
                        V = void 0 === H ? 1 : H,
                        Y = e.withControls,
                        $ = (0, i.Z)(e, Z),
                        J = "smooth",
                        U = (0, u.useRef)(null),
                        X = (0, u.useContext)(d.ThemeContext),
                        ee = (0, u.useState)(null),
                        et = (0, o.Z)(ee, 2),
                        en = et[0],
                        er = et[1],
                        eo = (0, u.useState)(J),
                        ei = (0, o.Z)(eo, 2),
                        ea = ei[0],
                        el = ei[1],
                        es = (0, u.useState)(null),
                        ec = (0, o.Z)(es, 2),
                        eu = ec[0],
                        ed = ec[1],
                        ef = (0, u.useState)(null),
                        eh = (0, o.Z)(ef, 2),
                        eg = eh[0],
                        em = eh[1],
                        ev = (n = (0, u.useState)((0, v.ML)() && window.innerWidth || null), h = (f = (0, o.Z)(n, 2))[0], g = f[1], (0, u.useEffect)(function() {
                            var e = (0, m.D)(500, function(e) {
                                    return g(e)
                                }),
                                t = function() {
                                    return e((0, v.ML)() && window.innerWidth)
                                };
                            return window.addEventListener("resize", t),
                                function() {
                                    return window.removeEventListener("resize", t)
                                }
                        }, []), {
                            windowWidth: h
                        }).windowWidth,
                        eb = (p = (b = {
                            perPage: eg,
                            root: U.current,
                            setSource: ed
                        }).perPage, j = b.root, N = b.setSource, S = b.throttleMs, I = (0, u.useState)(null), L = (P = (0, o.Z)(I, 2))[0], k = P[1], O = (0, m.P)(void 0 === S ? 100 : S, function(e) {
                            if (j && p) {
                                var t = e.target.scrollLeft + e.target.clientWidth === e.target.scrollWidth,
                                    n = j.children.length - p,
                                    r = Array.from(j.children).findIndex(function(t) {
                                        return t.offsetLeft === e.target.scrollLeft
                                    }),
                                    o = t ? n : r; - 1 !== o && (N("scroll"), k(o))
                            }
                        }), (0, u.useEffect)(function() {
                            if (j && p) return j.addEventListener("scroll", O),
                                function() {
                                    j.removeEventListener("scroll", O)
                                }
                        }, [j]), {
                            visibleIndex: L
                        }).visibleIndex;

                    function ep() {
                        if (eg && D.length && null !== en) {
                            var e = D.length - eg === en ? 0 : en + V;
                            e = en + V > D.length - eg ? q ? 0 : D.length - eg : en + V, ed("button"), er(e)
                        }
                    }

                    function ey() {
                        var e;
                        eg && D.length && null !== en && (e = en - V < 0 ? q ? D.length - eg : 0 : en - V, ed("button"), er(e))
                    }(0, u.useImperativeHandle)(t, function() {
                        return {
                            goTo: function(e) {
                                el(e.behavior || "auto"), ed("button"), er(e.index)
                            },
                            next: ep,
                            prev: ey
                        }
                    }), (0, u.useEffect)(function() {
                        null !== eb && er(eb)
                    }, [eb]), (0, u.useEffect)(function() {
                        var e, t, n, r, o, i, a;
                        null !== en && ("button" === eu && (o = (e = {
                            behavior: ea,
                            index: en,
                            root: U
                        }).behavior, i = e.index, null !== (t = (a = e.root).current) && void 0 !== t && t.children[i] && (null === (n = a.current) || void 0 === n || n.scroll({
                            behavior: o,
                            left: (null === (r = a.current) || void 0 === r ? void 0 : r.children[i]).offsetLeft
                        }))), null == K || K({
                            index: en
                        }), el(J))
                    }, [en]), (0, u.useEffect)(function() {
                        if (null != U && U.current) {
                            var e = U.current.children[0].getBoundingClientRect().width,
                                t = Math.floor(U.current.clientWidth / e);
                            em(t < 1 ? 1 : t)
                        }
                    }, [ev]), (0, u.useEffect)(function() {
                        T >= 0 && T <= D.length - 1 && (el("auto"), ed("button"), er(T))
                    }, [T]);
                    var ex = !q && en === D.length - Number(eg),
                        ew = !q && 0 === en,
                        eC = function(e) {
                            var t = e.edges,
                                n = e.isEnd,
                                r = e.isStart;
                            if (!t) return "none";
                            switch (t) {
                                case "both":
                                    return r ? "end" : n ? "start" : "both";
                                case "end":
                                    return n ? "none" : "end";
                                case "start":
                                    return r ? "none" : "start";
                                default:
                                    return t
                            }
                        }({
                            edges: M,
                            isEnd: ex,
                            isStart: ew
                        }),
                        eZ = function(e) {
                            var t = e.children,
                                n = e.dataQaId,
                                o = (0, i.Z)(e, E);
                            return u.createElement(C, (0, r.Z)({
                                "data-qa-id": n,
                                pos: "left",
                                onClick: ey
                            }, (0, c.e)(o)), t || u.createElement(s.ZP, {
                                color: "grey",
                                size: "large"
                            }, u.createElement(a.Z, {
                                title: "Pr\xe9c\xe9dent"
                            })))
                        },
                        eE = function(e) {
                            var t = e.children,
                                n = e.dataQaId,
                                o = (0, i.Z)(e, _);
                            return u.createElement(C, (0, r.Z)({
                                "data-qa-id": n,
                                pos: "right",
                                onClick: ep
                            }, (0, c.e)(o)), t || u.createElement(s.ZP, {
                                color: "grey",
                                size: "large"
                            }, u.createElement(l.Z, {
                                title: "Suivant"
                            })))
                        };
                    return u.createElement(y, (0, r.Z)({
                        edges: eC,
                        edgesColor: R || X.colors.backgroundGrey
                    }, (0, c.e)($)), u.createElement(x, (0, r.Z)({
                        "aria-label": z,
                        ref: U
                    }, B), u.Children.map(D, function(e, t) {
                        return u.createElement(w, (0, r.Z)({
                            key: t
                        }, W), e)
                    })), (void 0 === Y || Y) && u.createElement(u.Fragment, null, !ew && ((null == A ? void 0 : A({
                        Component: eZ
                    })) || u.createElement(eZ, null)), !ex && ((null == G ? void 0 : G({
                        Component: eE
                    })) || u.createElement(eE, null))), null == F ? void 0 : F({
                        index: en
                    }))
                })
        },
        84497: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return i
                }
            });
            var r, o = n(67294);

            function i(e) {
                return r || (r = o.createElement("symbol", {
                    id: "SvgChevronleft"
                }, o.createElement("path", {
                    d: "M10.13 12l8.25-8.33a2.15 2.15 0 000-3 2.1 2.1 0 00-3 0l-9.76 9.82a2.14 2.14 0 000 3l9.76 9.86a2.1 2.1 0 003 0 2.2 2.2 0 000-3.05z"
                })))
            }
            i.displayName = "SvgChevronleft", i.defaultProps = {
                viewBox: "0 0 24 24"
            }
        },
        42505: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return i
                }
            });
            var r, o = n(67294);

            function i(e) {
                return r || (r = o.createElement("symbol", {
                    id: "SvgChevronright"
                }, o.createElement("path", {
                    d: "M18.38 10.49L8.62.63a2.1 2.1 0 00-3 0 2.15 2.15 0 000 3L13.87 12l-8.25 8.32a2.2 2.2 0 000 3.05 2.1 2.1 0 003 0l9.76-9.86a2.14 2.14 0 000-3.02z"
                })))
            }
            i.displayName = "SvgChevronright", i.defaultProps = {
                viewBox: "0 0 24 24"
            }
        },
        94363: function(e, t, n) {
            var r = n(72253),
                o = n(85893),
                i = n(44958),
                a = n(67294),
                l = n(14949),
                s = n(9196),
                c = n(67837),
                u = (0, a.memo)(function(e) {
                    var t = e.ad,
                        n = e.slidesWidth,
                        r = e.sources,
                        a = t.images.urls;
                    return (0, o.jsx)(i.Z, {
                        ariaLabel: l["images.carousel.label"],
                        withControls: !1,
                        edges: "end",
                        height: "inherit",
                        rootCss: {
                            height: "inherit"
                        },
                        childCss: {
                            flex: "0 0 ".concat(void 0 === n ? "65%" : n),
                            height: "inherit",
                            alignSelf: "stretch",
                            marginRight: "small"
                        },
                        children: a.map(function(e, n) {
                            return (0, o.jsx)(c.Z, {
                                src: e,
                                alt: "",
                                sources: null == r ? void 0 : r[n],
                                className: "rounded-md"
                            }, "".concat(t.list_id, "-image-").concat(n))
                        })
                    })
                });
            t.Z = function(e) {
                var t = (0, s.M)().ad;
                return (0, o.jsx)(u, (0, r._)({
                    ad: t
                }, e))
            }
        },
        9873: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return h
                }
            });
            var r = n(72253),
                o = n(14932),
                i = n(24043),
                a = n(85893),
                l = n(29107),
                s = n(67294),
                c = n(9196),
                u = n(67837),
                d = (0, l.cx)("grid h-full w-full grid-rows-2 gap-md overflow-hidden"),
                f = (0, s.memo)(function(e) {
                    var t = e.ad,
                        n = e.lazy,
                        s = e.gridTemplateColumns,
                        c = e.sources,
                        f = e.children,
                        h = (0, i._)(t.images.urls, 3),
                        g = h[0],
                        m = h[1],
                        v = h[2],
                        b = {
                            alt: "",
                            className: "rounded-md",
                            lazy: n
                        };
                    return (0, a.jsxs)("div", {
                        style: {
                            gridTemplateColumns: void 0 === s ? "2fr 1fr" : s
                        },
                        className: d,
                        "data-test-id": "mosaic",
                        children: [(0, a.jsx)(u.Z, (0, o._)((0, r._)({
                            src: g,
                            sources: null == c ? void 0 : c[0]
                        }, b), {
                            className: (0, l.cx)(b.className, "row-span-2")
                        })), (0, a.jsx)(u.Z, (0, r._)({
                            src: m,
                            sources: null == c ? void 0 : c[1]
                        }, b)), (0, a.jsx)(u.Z, (0, r._)({
                            src: v,
                            sources: null == c ? void 0 : c[2]
                        }, b)), f]
                    })
                }),
                h = function(e) {
                    var t = (0, c.M)(),
                        n = t.ad,
                        o = t.lazy;
                    return (0, a.jsx)(f, (0, r._)({
                        ad: n,
                        lazy: o
                    }, e))
                }
        },
        64618: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return c
                }
            });
            var r = n(85893),
                o = n(29107),
                i = n(78908),
                a = n(47611),
                l = (0, o.cx)("inline-flex h-[--font-size-callout-line-height] items-center text-body-2"),
                s = (0, o.cx)("ml-sm text-caption text-neutral"),
                c = function(e) {
                    var t, n, c = e.ad,
                        u = e.style,
                        d = e.className,
                        f = 0,
                        h = 10;
                    return (0, a.qi)(c.owner.store_id) ? f = .92 : (f = Number(null === (t = c.attributes.find(function(e) {
                        return "score_from_trippers" === e.key
                    })) || void 0 === t ? void 0 : t.value) || 0, h = Number(null === (n = c.attributes.find(function(e) {
                        return "number_ratings_from_trippers" === e.key
                    })) || void 0 === n ? void 0 : n.value) || 0), (0, r.jsxs)("span", {
                        style: u,
                        className: (0, o.cx)(l, d),
                        children: [f > 0 && (0, r.jsx)(i.Z, {
                            variant: "small",
                            value: f
                        }), h > 0 && (0, r.jsxs)("span", {
                            className: s,
                            children: ["(", h, ")"]
                        })]
                    })
                }
        },
        91653: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return g
                }
            });
            var r = n(72253),
                o = n(85893),
                i = n(29107),
                a = n(67294),
                l = n(9196),
                s = n(1295),
                c = (0, i.cx)("relative", "before:block"),
                u = function(e, t) {
                    var n = "row" === e.direction ? ".".concat(t, " { flex: 0 0").concat(e.imageWidth, " }") : ".".concat(t, " { width: ").concat(e.imageWidth, " }");
                    return "\n    ".concat(void 0 !== e.imageWidth ? n : "", "\n    .").concat(t, "::before { padding-bottom: ").concat(e.imageHeight || 0, " }\n  ")
                },
                d = (0, i.cx)("relative h-full"),
                f = function(e, t) {
                    return e.imageHeight ? "\n      .".concat(t, " {\n        position: absolute;\n        inset: 0;\n        height: auto;\n      }\n    ") : void 0
                },
                h = (0, a.memo)(function(e) {
                    var t = e.layout,
                        n = e.children,
                        r = e.style,
                        a = e.className;
                    return (0, o.jsx)(s.Z, {
                        as: "div",
                        layout: t,
                        style: r,
                        stylesFromLayout: u,
                        className: (0, i.cx)(c, a),
                        "data-test-id": "image",
                        children: (0, o.jsx)(s.Z, {
                            as: "div",
                            layout: t,
                            stylesFromLayout: f,
                            className: d,
                            children: n
                        })
                    })
                }),
                g = function(e) {
                    var t = (0, l.M)().layout;
                    return (0, o.jsx)(h, (0, r._)({
                        layout: t
                    }, e))
                }
        },
        95270: function(e, t, n) {
            var r = n(72253),
                o = n(85893),
                i = n(67294),
                a = n(71709),
                l = n(9196),
                s = n(91653),
                c = n(52146),
                u = (0, i.memo)(function(e) {
                    var t = e.layout,
                        n = e.imagesCount,
                        r = e.renderDefault,
                        i = e.renderCarousel,
                        l = e.renderMosaic,
                        u = e.children,
                        d = {
                            default: r,
                            carousel: i,
                            mosaic: l
                        },
                        f = function(e) {
                            var t = d[e];
                            return t ? t() : null
                        },
                        h = (0, a.Vc)(t),
                        g = n < 3 ? f("default") : h.length > 1 ? h.map(function(e, t) {
                            return d[e] ? (0, o.jsx)(c.Z, {
                                condition: function(t) {
                                    return t.imageType === e
                                },
                                className: "h-full",
                                children: f(e)
                            }, "".concat(e, "-").concat(t)) : null
                        }) : f(h[0]);
                    return (0, o.jsxs)(s.Z, {
                        children: [g, u]
                    })
                });
            t.Z = function(e) {
                var t = (0, l.M)(),
                    n = t.layout,
                    i = t.imagesCount;
                return (0, o.jsx)(u, (0, r._)({
                    layout: n,
                    imagesCount: i
                }, e))
            }
        }
    }
]);