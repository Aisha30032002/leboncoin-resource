! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "943239ab-72b5-4d98-919d-5178aa788bd2", e._sentryDebugIdIdentifier = "sentry-dbid-943239ab-72b5-4d98-919d-5178aa788bd2")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [72239], {
        61821: function(e, t, s) {
            s.d(t, {
                z: function() {
                    return m
                }
            });
            var i = s(66051),
                n = s(67294),
                r = s(33274);
            let a = (0, n.forwardRef)((e, t) => n.createElement(r.f, {
                ref: t,
                ...e
            }));
            a.displayName = "VisuallyHidden";
            var c = s(74934),
                o = s(29107);
            let u = (0, o.j)(["inline-block", "border-solid", "rounded-full", "border-md", "animate-spin"], {
                    variants: {
                        size: {
                            current: ["u-current-font-size"],
                            sm: ["w-sz-20", "h-sz-20"],
                            md: ["w-sz-28", "h-sz-28"],
                            full: ["w-full", "h-full"]
                        },
                        intent: (0, c.TY)({
                            current: ["border-current"],
                            main: ["border-main"],
                            support: ["border-support"],
                            accent: ["border-accent"],
                            basic: ["border-basic"],
                            success: ["border-success"],
                            alert: ["border-alert"],
                            error: ["border-error"],
                            info: ["border-info"],
                            neutral: ["border-neutral"]
                        }),
                        isBackgroundVisible: {
                            true: ["border-b-neutral-container", "border-l-neutral-container"],
                            false: ["border-b-transparent", "border-l-transparent"]
                        }
                    },
                    defaultVariants: {
                        intent: "current",
                        size: "current",
                        isBackgroundVisible: !1
                    }
                }),
                l = (0, n.forwardRef)(({
                    className: e,
                    size: t = "current",
                    intent: s = "current",
                    label: i,
                    isBackgroundVisible: r,
                    ...c
                }, o) => n.createElement("div", {
                    role: "status",
                    "data-spark-component": "spinner",
                    ref: o,
                    className: u({
                        className: e,
                        size: t,
                        intent: s,
                        isBackgroundVisible: r
                    }),
                    ...c
                }, i && n.createElement(a, null, i))),
                d = [{
                    intent: "main",
                    design: "filled",
                    class: (0, c.tw)(["bg-main", "text-on-main", "hover:bg-main-hovered", "enabled:active:bg-main-pressed", "focus-visible:bg-main-focused"])
                }, {
                    intent: "support",
                    design: "filled",
                    class: (0, c.tw)(["bg-support", "text-on-support", "hover:bg-support-hovered", "enabled:active:bg-support-pressed", "focus-visible:bg-support-focused"])
                }, {
                    intent: "accent",
                    design: "filled",
                    class: (0, c.tw)(["bg-accent", "text-on-accent", "hover:bg-accent-hovered", "enabled:active:bg-accent-pressed", "focus-visible:bg-accent-focused"])
                }, {
                    intent: "basic",
                    design: "filled",
                    class: (0, c.tw)(["bg-basic", "text-on-basic", "hover:bg-basic-hovered", "enabled:active:bg-basic-pressed", "focus-visible:bg-basic-focused"])
                }, {
                    intent: "success",
                    design: "filled",
                    class: (0, c.tw)(["bg-success", "text-on-success", "hover:bg-success-hovered", "enabled:active:bg-success-pressed", "focus-visible:bg-success-focused"])
                }, {
                    intent: "alert",
                    design: "filled",
                    class: (0, c.tw)(["bg-alert", "text-on-alert", "hover:bg-alert-hovered", "enabled:active:bg-alert-pressed", "focus-visible:bg-alert-focused"])
                }, {
                    intent: "danger",
                    design: "filled",
                    class: (0, c.tw)(["text-on-error bg-error", "hover:bg-error-hovered enabled:active:bg-error-pressed", "focus-visible:bg-error-focused"])
                }, {
                    intent: "info",
                    design: "filled",
                    class: (0, c.tw)(["text-on-error bg-info", "hover:bg-info-hovered enabled:active:bg-info-pressed", "focus-visible:bg-info-focused"])
                }, {
                    intent: "neutral",
                    design: "filled",
                    class: (0, c.tw)(["bg-neutral", "text-on-neutral", "hover:bg-neutral-hovered", "enabled:active:bg-neutral-pressed", "focus-visible:bg-neutral-focused"])
                }, {
                    intent: "surface",
                    design: "filled",
                    class: (0, c.tw)(["bg-surface", "text-on-surface", "hover:bg-surface-hovered", "enabled:active:bg-surface-pressed", "focus-visible:bg-surface-focused"])
                }],
                b = [{
                    intent: "main",
                    design: "ghost",
                    class: (0, c.tw)(["text-main", "hover:bg-main/dim-5", "enabled:active:bg-main/dim-5", "focus-visible:bg-main/dim-5"])
                }, {
                    intent: "support",
                    design: "ghost",
                    class: (0, c.tw)(["text-support", "hover:bg-support/dim-5", "enabled:active:bg-support/dim-5", "focus-visible:bg-support/dim-5"])
                }, {
                    intent: "accent",
                    design: "ghost",
                    class: (0, c.tw)(["text-accent", "hover:bg-accent/dim-5", "enabled:active:bg-accent/dim-5", "focus-visible:bg-accent/dim-5"])
                }, {
                    intent: "basic",
                    design: "ghost",
                    class: (0, c.tw)(["text-basic", "hover:bg-basic/dim-5", "enabled:active:bg-basic/dim-5", "focus-visible:bg-basic/dim-5"])
                }, {
                    intent: "success",
                    design: "ghost",
                    class: (0, c.tw)(["text-success", "hover:bg-success/dim-5", "enabled:active:bg-success/dim-5", "focus-visible:bg-success/dim-5"])
                }, {
                    intent: "alert",
                    design: "ghost",
                    class: (0, c.tw)(["text-alert", "hover:bg-alert/dim-5", "enabled:active:bg-alert/dim-5", "focus-visible:bg-alert/dim-5"])
                }, {
                    intent: "danger",
                    design: "ghost",
                    class: (0, c.tw)(["text-error", "hover:bg-error/dim-5", "enabled:active:bg-error/dim-5", "focus-visible:bg-error/dim-5"])
                }, {
                    intent: "info",
                    design: "ghost",
                    class: (0, c.tw)(["text-info", "hover:bg-info/dim-5", "enabled:active:bg-info/dim-5", "focus-visible:bg-info/dim-5"])
                }, {
                    intent: "neutral",
                    design: "ghost",
                    class: (0, c.tw)(["text-neutral", "hover:bg-neutral/dim-5", "enabled:active:bg-neutral/dim-5", "focus-visible:bg-neutral/dim-5"])
                }, {
                    intent: "surface",
                    design: "ghost",
                    class: (0, c.tw)(["text-surface", "hover:bg-surface/dim-5", "enabled:active:bg-surface/dim-5", "focus-visible:bg-surface/dim-5"])
                }],
                h = [{
                    intent: "main",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-main/dim-5", "enabled:active:bg-main/dim-5", "focus-visible:bg-main/dim-5", "text-main"])
                }, {
                    intent: "support",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-support/dim-5", "enabled:active:bg-support/dim-5", "focus-visible:bg-support/dim-5", "text-support"])
                }, {
                    intent: "accent",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-accent/dim-5", "enabled:active:bg-accent/dim-5", "focus-visible:bg-accent/dim-5", "text-accent"])
                }, {
                    intent: "basic",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-basic/dim-5", "enabled:active:bg-basic/dim-5", "focus-visible:bg-basic/dim-5", "text-basic"])
                }, {
                    intent: "success",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-success/dim-5", "enabled:active:bg-success/dim-5", "focus-visible:bg-success/dim-5", "text-success"])
                }, {
                    intent: "alert",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-alert/dim-5", "enabled:active:bg-alert/dim-5", "focus-visible:bg-alert/dim-5", "text-alert"])
                }, {
                    intent: "danger",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-error/dim-5", "enabled:active:bg-error/dim-5", "focus-visible:bg-error/dim-5", "text-error"])
                }, {
                    intent: "info",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-info/dim-5", "enabled:active:bg-info/dim-5", "focus-visible:bg-info/dim-5", "text-info"])
                }, {
                    intent: "neutral",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-neutral/dim-5", "enabled:active:bg-neutral/dim-5", "focus-visible:bg-neutral/dim-5", "text-neutral"])
                }, {
                    intent: "surface",
                    design: "outlined",
                    class: (0, c.tw)(["hover:bg-surface/dim-5", "enabled:active:bg-surface/dim-5", "focus-visible:bg-surface/dim-5", "text-surface"])
                }],
                f = [{
                    intent: "main",
                    design: "tinted",
                    class: (0, c.tw)(["bg-main-container", "text-on-main-container", "hover:bg-main-container-hovered", "enabled:active:bg-main-container-pressed", "focus-visible:bg-main-container-focused"])
                }, {
                    intent: "support",
                    design: "tinted",
                    class: (0, c.tw)(["bg-support-container", "text-on-support-container", "hover:bg-support-container-hovered", "enabled:active:bg-support-container-pressed", "focus-visible:bg-support-container-focused"])
                }, {
                    intent: "accent",
                    design: "tinted",
                    class: (0, c.tw)(["bg-accent-container", "text-on-accent-container", "hover:bg-accent-container-hovered", "enabled:active:bg-accent-container-pressed", "focus-visible:bg-accent-container-focused"])
                }, {
                    intent: "basic",
                    design: "tinted",
                    class: (0, c.tw)(["bg-basic-container", "text-on-basic-container", "hover:bg-basic-container-hovered", "enabled:active:bg-basic-container-pressed", "focus-visible:bg-basic-container-focused"])
                }, {
                    intent: "success",
                    design: "tinted",
                    class: (0, c.tw)(["bg-success-container", "text-on-success-container", "hover:bg-success-container-hovered", "enabled:active:bg-success-container-pressed", "focus-visible:bg-success-container-focused"])
                }, {
                    intent: "alert",
                    design: "tinted",
                    class: (0, c.tw)(["bg-alert-container", "text-on-alert-container", "hover:bg-alert-container-hovered", "enabled:active:bg-alert-container-pressed", "focus-visible:bg-alert-container-focused"])
                }, {
                    intent: "danger",
                    design: "tinted",
                    class: (0, c.tw)(["bg-error-container", "text-on-error-container", "hover:bg-error-container-hovered", "enabled:active:bg-error-container-pressed", "focus-visible:bg-error-container-focused"])
                }, {
                    intent: "info",
                    design: "tinted",
                    class: (0, c.tw)(["bg-info-container", "text-on-info-container", "hover:bg-info-container-hovered", "enabled:active:bg-info-container-pressed", "focus-visible:bg-info-container-focused"])
                }, {
                    intent: "neutral",
                    design: "tinted",
                    class: (0, c.tw)(["bg-neutral-container", "text-on-neutral-container", "hover:bg-neutral-container-hovered", "enabled:active:bg-neutral-container-pressed", "focus-visible:bg-neutral-container-focused"])
                }, {
                    intent: "surface",
                    design: "tinted",
                    class: (0, c.tw)(["bg-surface", "text-on-surface", "hover:bg-surface-hovered", "enabled:active:bg-surface-pressed", "focus-visible:bg-surface-focused"])
                }],
                g = [{
                    intent: "main",
                    design: "contrast",
                    class: (0, c.tw)(["text-main", "hover:bg-main-container-hovered", "enabled:active:bg-main-container-pressed", "focus-visible:bg-main-container-focused"])
                }, {
                    intent: "support",
                    design: "contrast",
                    class: (0, c.tw)(["text-support", "hover:bg-support-container-hovered", "enabled:active:bg-support-container-pressed", "focus-visible:bg-support-container-focused"])
                }, {
                    intent: "accent",
                    design: "contrast",
                    class: (0, c.tw)(["text-accent", "hover:bg-accent-container-hovered", "enabled:active:bg-accent-container-pressed", "focus-visible:bg-accent-container-focused"])
                }, {
                    intent: "basic",
                    design: "contrast",
                    class: (0, c.tw)(["text-basic", "hover:bg-basic-container-hovered", "enabled:active:bg-basic-container-pressed", "focus-visible:bg-basic-container-focused"])
                }, {
                    intent: "success",
                    design: "contrast",
                    class: (0, c.tw)(["text-success", "hover:bg-success-container-hovered", "enabled:active:bg-success-container-pressed", "focus-visible:bg-success-container-focused"])
                }, {
                    intent: "alert",
                    design: "contrast",
                    class: (0, c.tw)(["text-alert", "hover:bg-alert-container-hovered", "enabled:active:bg-alert-container-pressed", "focus-visible:bg-alert-container-focused"])
                }, {
                    intent: "danger",
                    design: "contrast",
                    class: (0, c.tw)(["text-error", "hover:bg-error-container-hovered", "enabled:active:bg-error-container-pressed", "focus-visible:bg-error-container-focused"])
                }, {
                    intent: "info",
                    design: "contrast",
                    class: (0, c.tw)(["text-info", "hover:bg-info-container-hovered", "enabled:active:bg-info-container-pressed", "focus-visible:bg-info-container-focused"])
                }, {
                    intent: "neutral",
                    design: "contrast",
                    class: (0, c.tw)(["text-neutral", "hover:bg-neutral-container-hovered", "enabled:active:bg-neutral-container-pressed", "focus-visible:bg-neutral-container-focused"])
                }, {
                    intent: "surface",
                    design: "contrast",
                    class: (0, c.tw)(["text-on-surface", "hover:bg-surface-hovered", "enabled:active:bg-surface-pressed", "focus-visible:bg-surface-focused"])
                }],
                p = (0, o.j)(["u-shadow-border-transition", "box-border inline-flex items-center justify-center gap-md whitespace-nowrap", "px-lg", "text-body-1 font-bold", "focus-visible:outline-none focus-visible:u-ring [&:not(:focus-visible)]:ring-inset"], {
                    variants: {
                        design: (0, c.TY)({
                            filled: [],
                            outlined: ["bg-transparent", "border-sm", "border-current"],
                            tinted: [],
                            ghost: [],
                            contrast: ["bg-surface"]
                        }),
                        intent: (0, c.TY)({
                            main: [],
                            support: [],
                            accent: [],
                            basic: [],
                            success: [],
                            alert: [],
                            danger: [],
                            info: [],
                            neutral: [],
                            surface: []
                        }),
                        size: (0, c.TY)({
                            sm: ["min-w-sz-32", "h-sz-32"],
                            md: ["min-w-sz-44", "h-sz-44"],
                            lg: ["min-w-sz-56", "h-sz-56"]
                        }),
                        shape: (0, c.TY)({
                            rounded: ["rounded-lg"],
                            square: ["rounded-none"],
                            pill: ["rounded-full"]
                        }),
                        disabled: {
                            true: ["cursor-not-allowed", "opacity-dim-3"]
                        }
                    },
                    compoundVariants: [...d, ...h, ...f, ...b, ...g],
                    defaultVariants: {
                        design: "filled",
                        intent: "main",
                        size: "md",
                        shape: "rounded"
                    }
                }),
                v = ["onClick", "onMouseDown", "onMouseUp", "onMouseEnter", "onMouseLeave", "onMouseOver", "onMouseOut", "onKeyDown", "onKeyPress", "onKeyUp", "onSubmit"],
                m = (0, n.forwardRef)(({
                    children: e,
                    design: t = "filled",
                    disabled: s = !1,
                    intent: r = "main",
                    isLoading: a = !1,
                    loadingLabel: c,
                    loadingText: u,
                    shape: d = "rounded",
                    size: b = "md",
                    spinnerPlacement: h = "left",
                    asChild: f,
                    className: g,
                    ...m
                }, y) => {
                    let w = f ? i.g7 : "button",
                        R = !!s || a,
                        x = (0, n.useMemo)(() => {
                            let e = {};
                            return R && v.forEach(t => e[t] = void 0), e
                        }, [R]),
                        E = {
                            size: "current",
                            className: u ? "inline-block" : "absolute",
                            ...c && {
                                "aria-label": c
                            }
                        };
                    return n.createElement(w, {
                        "data-spark-component": "button",
                        ref: y,
                        className: p({
                            className: g,
                            design: t,
                            disabled: R,
                            intent: r,
                            shape: d,
                            size: b
                        }),
                        disabled: !!s,
                        "aria-busy": a,
                        "aria-live": a ? "assertive" : "off",
                        ...m,
                        ...x
                    }, (0, i.ZE)(f, e, e => a ? n.createElement(n.Fragment, null, "left" === h && n.createElement(l, { ...E
                    }), u && u, "right" === h && n.createElement(l, { ...E
                    }), n.createElement("div", {
                        "aria-hidden": !0,
                        className: (0, o.cx)("inline-flex gap-md", u ? "hidden" : "opacity-0")
                    }, e)) : e))
                });
            m.displayName = "Button"
        },
        72536: function(e, t, s) {
            s.d(t, {
                z: function() {
                    return o
                }
            });
            var i = s(24139),
                n = s(27037),
                r = s(66474),
                a = s(7506),
                c = s(72008),
                o = class extends a.l {
                    constructor(e, t) {
                        super(), this.#e = void 0, this.#t = void 0, this.#s = void 0, this.#i = new Set, this.#n = e, this.options = t, this.#r = null, this.bindMethods(), this.setOptions(t)
                    }#
                    n;#
                    e;#
                    t;#
                    s;#
                    a;#
                    c;#
                    r;#
                    o;#
                    u;#
                    l;#
                    d;#
                    b;#
                    h;#
                    i;
                    bindMethods() {
                        this.refetch = this.refetch.bind(this)
                    }
                    onSubscribe() {
                        1 === this.listeners.size && (this.#e.addObserver(this), u(this.#e, this.options) && this.#f(), this.#g())
                    }
                    onUnsubscribe() {
                        this.hasListeners() || this.destroy()
                    }
                    shouldFetchOnReconnect() {
                        return l(this.#e, this.options, this.options.refetchOnReconnect)
                    }
                    shouldFetchOnWindowFocus() {
                        return l(this.#e, this.options, this.options.refetchOnWindowFocus)
                    }
                    destroy() {
                        this.listeners = new Set, this.#p(), this.#v(), this.#e.removeObserver(this)
                    }
                    setOptions(e, t) {
                        let s = this.options,
                            n = this.#e;
                        if (this.options = this.#n.defaultQueryOptions(e), (0, i.VS)(s, this.options) || this.#n.getQueryCache().notify({
                                type: "observerOptionsUpdated",
                                query: this.#e,
                                observer: this
                            }), void 0 !== this.options.enabled && "boolean" != typeof this.options.enabled) throw Error("Expected enabled to be a boolean");
                        this.options.queryKey || (this.options.queryKey = s.queryKey), this.#m();
                        let r = this.hasListeners();
                        r && d(this.#e, n, this.options, s) && this.#f(), this.updateResult(t), r && (this.#e !== n || this.options.enabled !== s.enabled || this.options.staleTime !== s.staleTime) && this.#y();
                        let a = this.#w();
                        r && (this.#e !== n || this.options.enabled !== s.enabled || a !== this.#h) && this.#R(a)
                    }
                    getOptimisticResult(e) {
                        let t = this.#n.getQueryCache().build(this.#n, e),
                            s = this.createResult(t, e);
                        return (0, i.VS)(this.getCurrentResult(), s) || (this.#s = s, this.#c = this.options, this.#a = this.#e.state), s
                    }
                    getCurrentResult() {
                        return this.#s
                    }
                    trackResult(e) {
                        let t = {};
                        return Object.keys(e).forEach(s => {
                            Object.defineProperty(t, s, {
                                configurable: !1,
                                enumerable: !0,
                                get: () => (this.#i.add(s), e[s])
                            })
                        }), t
                    }
                    getCurrentQuery() {
                        return this.#e
                    }
                    refetch({ ...e
                    } = {}) {
                        return this.fetch({ ...e
                        })
                    }
                    fetchOptimistic(e) {
                        let t = this.#n.defaultQueryOptions(e),
                            s = this.#n.getQueryCache().build(this.#n, t);
                        return s.isFetchingOptimistic = !0, s.fetch().then(() => this.createResult(s, t))
                    }
                    fetch(e) {
                        return this.#f({ ...e,
                            cancelRefetch: e.cancelRefetch ? ? !0
                        }).then(() => (this.updateResult(), this.#s))
                    }#
                    f(e) {
                        this.#m();
                        let t = this.#e.fetch(this.options, e);
                        return e ? .throwOnError || (t = t.catch(i.ZT)), t
                    }#
                    y() {
                        if (this.#p(), i.sk || this.#s.isStale || !(0, i.PN)(this.options.staleTime)) return;
                        let e = (0, i.Kp)(this.#s.dataUpdatedAt, this.options.staleTime);
                        this.#d = setTimeout(() => {
                            this.#s.isStale || this.updateResult()
                        }, e + 1)
                    }#
                    w() {
                        return ("function" == typeof this.options.refetchInterval ? this.options.refetchInterval(this.#e) : this.options.refetchInterval) ? ? !1
                    }#
                    R(e) {
                        this.#v(), this.#h = e, !i.sk && !1 !== this.options.enabled && (0, i.PN)(this.#h) && 0 !== this.#h && (this.#b = setInterval(() => {
                            (this.options.refetchIntervalInBackground || r.j.isFocused()) && this.#f()
                        }, this.#h))
                    }#
                    g() {
                        this.#y(), this.#R(this.#w())
                    }#
                    p() {
                        this.#d && (clearTimeout(this.#d), this.#d = void 0)
                    }#
                    v() {
                        this.#b && (clearInterval(this.#b), this.#b = void 0)
                    }
                    createResult(e, t) {
                        let s;
                        let n = this.#e,
                            r = this.options,
                            a = this.#s,
                            o = this.#a,
                            l = this.#c,
                            h = e !== n ? e.state : this.#t,
                            {
                                state: f
                            } = e,
                            {
                                error: g,
                                errorUpdatedAt: p,
                                fetchStatus: v,
                                status: m
                            } = f,
                            y = !1;
                        if (t._optimisticResults) {
                            let s = this.hasListeners(),
                                i = !s && u(e, t),
                                a = s && d(e, n, t, r);
                            (i || a) && (v = (0, c.Kw)(e.options.networkMode) ? "fetching" : "paused", f.dataUpdatedAt || (m = "pending")), "isRestoring" === t._optimisticResults && (v = "idle")
                        }
                        if (t.select && void 0 !== f.data) {
                            if (a && f.data === o ? .data && t.select === this.#o) s = this.#u;
                            else try {
                                this.#o = t.select, s = t.select(f.data), s = (0, i.oE)(a ? .data, s, t), this.#u = s, this.#r = null
                            } catch (e) {
                                this.#r = e
                            }
                        } else s = f.data;
                        if (void 0 !== t.placeholderData && void 0 === s && "pending" === m) {
                            let e;
                            if (a ? .isPlaceholderData && t.placeholderData === l ? .placeholderData) e = a.data;
                            else if (e = "function" == typeof t.placeholderData ? t.placeholderData(this.#l ? .state.data, this.#l) : t.placeholderData, t.select && void 0 !== e) try {
                                e = t.select(e), this.#r = null
                            } catch (e) {
                                this.#r = e
                            }
                            void 0 !== e && (m = "success", s = (0, i.oE)(a ? .data, e, t), y = !0)
                        }
                        this.#r && (g = this.#r, s = this.#u, p = Date.now(), m = "error");
                        let w = "fetching" === v,
                            R = "pending" === m,
                            x = "error" === m,
                            E = R && w,
                            Q = {
                                status: m,
                                fetchStatus: v,
                                isPending: R,
                                isSuccess: "success" === m,
                                isError: x,
                                isInitialLoading: E,
                                isLoading: E,
                                data: s,
                                dataUpdatedAt: f.dataUpdatedAt,
                                error: g,
                                errorUpdatedAt: p,
                                failureCount: f.fetchFailureCount,
                                failureReason: f.fetchFailureReason,
                                errorUpdateCount: f.errorUpdateCount,
                                isFetched: f.dataUpdateCount > 0 || f.errorUpdateCount > 0,
                                isFetchedAfterMount: f.dataUpdateCount > h.dataUpdateCount || f.errorUpdateCount > h.errorUpdateCount,
                                isFetching: w,
                                isRefetching: w && !R,
                                isLoadingError: x && 0 === f.dataUpdatedAt,
                                isPaused: "paused" === v,
                                isPlaceholderData: y,
                                isRefetchError: x && 0 !== f.dataUpdatedAt,
                                isStale: b(e, t),
                                refetch: this.refetch
                            };
                        return Q
                    }
                    updateResult(e) {
                        let t = this.#s,
                            s = this.createResult(this.#e, this.options);
                        if (this.#a = this.#e.state, this.#c = this.options, (0, i.VS)(s, t)) return;
                        void 0 !== this.#a.data && (this.#l = this.#e), this.#s = s;
                        let n = {};
                        e ? .listeners !== !1 && (() => {
                            if (!t) return !0;
                            let {
                                notifyOnChangeProps: e
                            } = this.options, s = "function" == typeof e ? e() : e;
                            if ("all" === s || !s && !this.#i.size) return !0;
                            let i = new Set(s ? ? this.#i);
                            return this.options.throwOnError && i.add("error"), Object.keys(this.#s).some(e => {
                                let s = this.#s[e] !== t[e];
                                return s && i.has(e)
                            })
                        })() && (n.listeners = !0), this.#x({ ...n,
                            ...e
                        })
                    }#
                    m() {
                        let e = this.#n.getQueryCache().build(this.#n, this.options);
                        if (e === this.#e) return;
                        let t = this.#e;
                        this.#e = e, this.#t = e.state, this.hasListeners() && (t ? .removeObserver(this), e.addObserver(this))
                    }
                    onQueryUpdate() {
                        this.updateResult(), this.hasListeners() && this.#g()
                    }#
                    x(e) {
                        n.V.batch(() => {
                            e.listeners && this.listeners.forEach(e => {
                                e(this.#s)
                            }), this.#n.getQueryCache().notify({
                                query: this.#e,
                                type: "observerResultsUpdated"
                            })
                        })
                    }
                };

            function u(e, t) {
                return !1 !== t.enabled && !e.state.dataUpdatedAt && !("error" === e.state.status && !1 === t.retryOnMount) || e.state.dataUpdatedAt > 0 && l(e, t, t.refetchOnMount)
            }

            function l(e, t, s) {
                if (!1 !== t.enabled) {
                    let i = "function" == typeof s ? s(e) : s;
                    return "always" === i || !1 !== i && b(e, t)
                }
                return !1
            }

            function d(e, t, s, i) {
                return !1 !== s.enabled && (e !== t || !1 === i.enabled) && (!s.suspense || "error" !== e.state.status) && b(e, s)
            }

            function b(e, t) {
                return e.isStaleByTime(t.staleTime)
            }
        },
        20364: function(e, t, s) {
            let i;
            s.d(t, {
                r: function() {
                    return y
                }
            });
            var n = s(67294),
                r = s(27037),
                a = n.createContext((i = !1, {
                    clearReset: () => {
                        i = !1
                    },
                    reset: () => {
                        i = !0
                    },
                    isReset: () => i
                })),
                c = () => n.useContext(a),
                o = s(30202),
                u = n.createContext(!1),
                l = () => n.useContext(u);
            u.Provider;
            var d = s(86290),
                b = (e, t) => {
                    (e.suspense || e.throwOnError) && !t.isReset() && (e.retryOnMount = !1)
                },
                h = e => {
                    n.useEffect(() => {
                        e.clearReset()
                    }, [e])
                },
                f = ({
                    result: e,
                    errorResetBoundary: t,
                    throwOnError: s,
                    query: i
                }) => e.isError && !t.isReset() && !e.isFetching && (0, d.L)(s, [e.error, i]),
                g = e => {
                    e.suspense && "number" != typeof e.staleTime && (e.staleTime = 1e3)
                },
                p = (e, t) => e.isLoading && e.isFetching && !t,
                v = (e, t, s) => e ? .suspense && p(t, s),
                m = (e, t, s) => t.fetchOptimistic(e).catch(() => {
                    s.clearReset()
                });

            function y(e, t, s) {
                let i = (0, o.NL)(s),
                    a = l(),
                    u = c(),
                    d = i.defaultQueryOptions(e);
                d._optimisticResults = a ? "isRestoring" : "optimistic", g(d), b(d, u), h(u);
                let [p] = n.useState(() => new t(i, d)), y = p.getOptimisticResult(d);
                if (n.useSyncExternalStore(n.useCallback(e => {
                        let t = a ? () => void 0 : p.subscribe(r.V.batchCalls(e));
                        return p.updateResult(), t
                    }, [p, a]), () => p.getCurrentResult(), () => p.getCurrentResult()), n.useEffect(() => {
                        p.setOptions(d, {
                            listeners: !1
                        })
                    }, [d, p]), v(d, y, a)) throw m(d, p, u);
                if (f({
                        result: y,
                        errorResetBoundary: u,
                        throwOnError: d.throwOnError,
                        query: p.getCurrentQuery()
                    })) throw y.error;
                return d.notifyOnChangeProps ? y : p.trackResult(y)
            }
        },
        78551: function(e, t, s) {
            s.d(t, {
                a: function() {
                    return r
                }
            });
            var i = s(72536),
                n = s(20364);

            function r(e, t) {
                return (0, n.r)(e, i.z, t)
            }
        },
        86290: function(e, t, s) {
            s.d(t, {
                L: function() {
                    return i
                }
            });

            function i(e, t) {
                return "function" == typeof e ? e(...t) : !!e
            }
        }
    }
]);