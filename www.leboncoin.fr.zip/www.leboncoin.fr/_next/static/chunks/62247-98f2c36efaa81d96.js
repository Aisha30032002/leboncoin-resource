! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "9d030357-1b8c-45a4-806b-a84d252aef92", e._sentryDebugIdIdentifier = "sentry-dbid-9d030357-1b8c-45a4-806b-a84d252aef92")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [62247], {
        57631: function(e, t) {
            t.T = void 0;
            var n, r, a = ["offsetHeight", "scrollHeight", "clientHeight"],
                i = /text|password|search|tel|url/;

            function s() {
                var e = l() || document.body,
                    t = b(e);
                return c(e, t)
            }

            function o(e) {
                return void 0 === e && (e = document.body), {
                    toPreviousElement: function() {
                        return c(e, u(), !0)
                    },
                    toNextElement: function() {
                        return c(e, b(e))
                    },
                    to: function(t, n) {
                        return void 0 === n && (n = !1), c(e, t, n)
                    }
                }
            }

            function c(e, t, n) {
                if (void 0 === n && (n = !1), !e.dispatchEvent(d("keydown", n))) return e.dispatchEvent(d("keypress", n)), e.dispatchEvent(d("keyup", n)), !1;
                if (e.blur(), t.focus(), document.activeElement !== t) try {
                    document.activeElement = t
                } catch (e) {
                    console.warn("could not switch active element")
                }
                t instanceof HTMLInputElement && i.test(t.type) && (t.selectionStart = 0);
                var r = d("keyup", n);
                return t.dispatchEvent(r), !0
            }

            function d(e, t) {
                return void 0 === t && (t = !1), new KeyboardEvent(e, {
                    code: "Tab",
                    key: "Tab",
                    cancelable: !0,
                    bubbles: !0,
                    shiftKey: t
                })
            }

            function l() {
                var e = document.activeElement;
                return e instanceof HTMLElement ? e : void 0
            }

            function u(e) {
                void 0 === e && (e = document.body);
                var t = f();
                if (t.length < 1) throw Error("no selectable elements found");
                var n = t.indexOf(e),
                    r = (n > 0 ? n : t.length) - 1;
                return t[r]
            }

            function b(e) {
                void 0 === e && (e = document.body);
                var t = f();
                if (t.length < 1) throw Error("no selectable elements found");
                var n = t.indexOf(e),
                    r = n + 1 < t.length ? n + 1 : 0;
                return t[r]
            }

            function f() {
                var e = Array.from(document.querySelectorAll("*")).filter(p);
                return g(), Object.values(e.filter(function() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    return function(t) {
                        return !e.some(function(e) {
                            return !e(t)
                        })
                    }
                }(m, r, y, x, _)).reduce(function(e, t) {
                    var n = t.tabIndex,
                        r = e["" + n] || {
                            tabIndex: n,
                            elements: []
                        };
                    return r.elements.push(t), e[n] = r, e
                }, {})).sort(w).reduce(function(e, t) {
                    return e.concat(t.elements)
                }, [])
            }
            t.T = s, (n = s = t.T || (t.T = {})).from = o, n.to = function(e, t) {
                return void 0 === t && (t = !1), o(l()).to(e, t)
            }, n.backwards = function() {
                return n.to(u(l()), !0)
            }, n.forwards = function() {
                return n()
            }, n.findSelectableElements = f;
            var p = function(e) {
                    return e instanceof HTMLElement
                },
                g = function() {
                    var e = function e(t) {
                        void 0 === t && (t = document.body);
                        var n = t,
                            r = a.find(function(e) {
                                var t = n[e];
                                return t && "number" == typeof t && t > 0
                            });
                        if (r) return r;
                        for (var i = t.children, s = 0, o = Array.from(i); s < o.length; s++) {
                            var c = e(o[s]);
                            if (c) return c
                        }
                    }();
                    r = e ? v(e) : h, g = function() {}
                },
                v = function(e) {
                    return function(t) {
                        var n = t[e];
                        return !!n && "number" == typeof n && n > 0
                    }
                },
                h = function(e) {
                    if (!e.isConnected) return !1;
                    if ("BODY" === e.tagName) return !0;
                    var t = getComputedStyle(e);
                    if ("none" === t.display || "collapse" === t.visibility) return !1;
                    var n = e.parentElement;
                    return !!n && h(n)
                };

            function m(e) {
                return "number" == typeof e.tabIndex && e.tabIndex >= 0
            }
            var y = function(e) {
                return !e.disabled
            };

            function x(e) {
                return !(e instanceof HTMLAnchorElement) || !!e.href || null !== e.getAttribute("tabIndex")
            }
            var _ = function(e) {
                return "collapse" !== getComputedStyle(e).visibility
            };

            function w(e, t) {
                if (e.tabIndex > 0 && t.tabIndex > 0) return e.tabIndex - t.tabIndex;
                if (e.tabIndex > 0) return -e.tabIndex;
                if (t.tabIndex > 0) return t.tabIndex;
                throw Error("same tab index for two groups")
            }
        },
        77631: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return O
                }
            });
            var r, a = n(67294),
                i = n(74934),
                s = n(29107),
                o = n(66051),
                c = n(57631),
                d = n(33274);
            let l = (0, a.forwardRef)((e, t) => a.createElement(d.f, {
                ref: t,
                ...e
            }));
            l.displayName = "VisuallyHidden";
            let u = (0, s.j)(["fill-current"], {
                    variants: {
                        intent: (0, i.TY)({
                            current: ["text-current"],
                            main: ["text-main"],
                            support: ["text-support"],
                            accent: ["text-accent"],
                            basic: ["text-basic"],
                            success: ["text-success"],
                            alert: ["text-alert"],
                            error: ["text-error"],
                            info: ["text-info"],
                            neutral: ["text-neutral"]
                        }),
                        size: (0, i.TY)({
                            current: ["u-current-font-size"],
                            sm: ["w-sz-16", "h-sz-16"],
                            md: ["w-sz-24", "h-sz-24"],
                            lg: ["w-sz-32", "h-sz-32"],
                            xl: ["w-sz-40", "h-sz-40"]
                        })
                    }
                }),
                b = ({
                    label: e,
                    className: t,
                    size: n = "current",
                    intent: r = "current",
                    children: i,
                    ...s
                }) => {
                    let o = a.Children.only(i);
                    return a.createElement(a.Fragment, null, (0, a.cloneElement)(o, {
                        className: u({
                            className: t,
                            size: n,
                            intent: r
                        }),
                        "data-spark-component": "icon",
                        "aria-hidden": "true",
                        focusable: "false",
                        ...s
                    }), e && a.createElement(l, null, e))
                };
            b.displayName = "Icon";
            let f = [{
                    design: "outlined",
                    intent: "main",
                    class: (0, i.tw)(["enabled:hover:bg-main/dim-5", "enabled:active:bg-main/dim-5", "focus-visible:bg-main/dim-5", "aria-pressed:bg-main-container aria-pressed:text-on-main-container aria-pressed:enabled:hover:bg-main-container/dim-1", "text-main"])
                }, {
                    design: "outlined",
                    intent: "support",
                    class: (0, i.tw)(["enabled:hover:bg-support/dim-5", "enabled:active:bg-support/dim-5", "focus-visible:bg-support/dim-5", "aria-pressed:bg-support-container aria-pressed:text-on-support-container aria-pressed:enabled:hover:bg-support-container/dim-1", "text-support"])
                }, {
                    design: "outlined",
                    intent: "basic",
                    class: (0, i.tw)(["enabled:hover:bg-basic/dim-5", "enabled:active:bg-basic/dim-5", "focus-visible:bg-basic/dim-5", "aria-pressed:bg-basic-container aria-pressed:text-on-basic-container aria-pressed:enabled:hover:bg-basic-container/dim-1", "text-basic"])
                }, {
                    intent: "accent",
                    design: "outlined",
                    class: (0, i.tw)(["enabled:hover:bg-accent/dim-5", "enabled:active:bg-accent/dim-5", "focus-visible:bg-accent/dim-5", "aria-pressed:bg-accent-container", "aria-pressed:bg-accent-container aria-pressed:text-on-accent-container aria-pressed:enabled:hover:bg-accent-container/dim-1", "text-accent"])
                }, {
                    design: "outlined",
                    intent: "success",
                    class: (0, i.tw)(["enabled:hover:bg-success/dim-5", "enabled:active:bg-success/dim-5", "focus-visible:bg-success/dim-5", "aria-pressed:bg-success-container aria-pressed:text-on-success-container aria-pressed:enabled:hover:bg-success-container/dim-1", "text-success"])
                }, {
                    intent: "alert",
                    design: "outlined",
                    class: (0, i.tw)(["enabled:hover:bg-alert/dim-5", "enabled:active:bg-alert/dim-5", "focus-visible:bg-alert/dim-5", "aria-pressed:bg-alert-container aria-pressed:text-on-alert-container aria-pressed:enabled:hover:bg-alert-container/dim-1", "text-alert"])
                }, {
                    design: "outlined",
                    intent: "danger",
                    class: (0, i.tw)(["enabled:hover:bg-error/dim-5", "enabled:active:bg-error/dim-5", "focus-visible:bg-error/dim-5", "aria-pressed:bg-error-container aria-pressed:text-on-error-container aria-pressed:enabled:hover:bg-error-container/dim-1", "text-error"])
                }, {
                    design: "outlined",
                    intent: "info",
                    class: (0, i.tw)(["enabled:hover:bg-info/dim-5", "enabled:active:bg-info/dim-5", "focus-visible:bg-info/dim-5", "aria-pressed:bg-info-container aria-pressed:text-on-info-container aria-pressed:enabled:hover:bg-info-container/dim-1", "text-info"])
                }, {
                    design: "outlined",
                    intent: "neutral",
                    class: (0, i.tw)(["enabled:hover:bg-neutral/dim-5", "enabled:active:bg-neutral/dim-5", "focus-visible:bg-neutral/dim-5", "aria-pressed:bg-neutral-container aria-pressed:text-on-neutral-container aria-pressed:enabled:hover:bg-neutral-container/dim-1", "text-neutral"])
                }, {
                    design: "outlined",
                    intent: "surface",
                    class: (0, i.tw)(["enabled:hover:bg-surface/dim-5", "enabled:active:bg-surface/dim-5", "focus-visible:bg-surface/dim-5", "aria-pressed:bg-surface aria-pressed:text-on-surface aria-pressed:enabled:hover:bg-surface-hovered", "text-surface"])
                }, {
                    design: "outlined",
                    hasClearButton: !1,
                    class: (0, i.tw)(["px-[calc(var(--spacing-md)-var(--border-width-sm))]"])
                }, {
                    design: "outlined",
                    hasClearButton: !0,
                    class: (0, i.tw)(["pl-[calc(var(--spacing-md)-var(--border-width-sm))]"])
                }],
                p = [{
                    intent: "main",
                    design: "tinted",
                    class: (0, i.tw)(["bg-main-container", "enabled:hover:bg-main-container-hovered", "enabled:active:bg-main-container-pressed", "focus-visible:bg-main-container-focused", "aria-pressed:bg-main aria-pressed:text-on-main aria-pressed:enabled:hover:bg-main/dim-1", "text-on-main-container"])
                }, {
                    intent: "support",
                    design: "tinted",
                    class: (0, i.tw)(["bg-support-container", "enabled:hover:bg-support-container-hovered", "enabled:active:bg-support-container-pressed", "focus-visible:bg-support-container-focused", "aria-pressed:bg-support aria-pressed:text-on-support aria-pressed:enabled:hover:bg-support/dim-1", "text-on-support-container"])
                }, {
                    intent: "basic",
                    design: "tinted",
                    class: (0, i.tw)(["bg-basic-container", "enabled:hover:bg-basic-container-hovered", "enabled:active:bg-basic-container-pressed", "focus-visible:bg-basic-container-focused", "aria-pressed:bg-basic aria-pressed:text-on-basic aria-pressed:enabled:hover:bg-basic/dim-1", "text-on-basic-container"])
                }, {
                    intent: "accent",
                    design: "tinted",
                    class: (0, i.tw)(["bg-accent-container", "enabled:hover:bg-accent-container-hovered", "enabled:active:bg-accent-container-pressed", "focus-visible:bg-accent-container-focused", "aria-pressed:bg-accent aria-pressed:text-on-accent aria-pressed:enabled:hover:bg-accent/dim-1", "text-on-accent-container"])
                }, {
                    intent: "success",
                    design: "tinted",
                    class: (0, i.tw)(["bg-success-container", "enabled:hover:bg-success-container-hovered", "enabled:active:bg-success-container-pressed", "focus-visible:bg-success-container-focused", "aria-pressed:bg-success aria-pressed:text-on-success aria-pressed:enabled:hover:bg-success/dim-1", "text-on-success-container"])
                }, {
                    intent: "alert",
                    design: "tinted",
                    class: (0, i.tw)(["bg-alert-container", "enabled:hover:bg-alert-container-hovered", "enabled:active:bg-alert-container-pressed", "focus-visible:bg-alert-container-focused", "aria-pressed:bg-alert aria-pressed:text-on-alert aria-pressed:enabled:hover:bg-alert/dim-1", "text-on-alert-container"])
                }, {
                    intent: "danger",
                    design: "tinted",
                    class: (0, i.tw)(["bg-error-container", "enabled:hover:bg-error-container-hovered", "enabled:active:bg-error-container-pressed", "focus-visible:bg-error-container-focused", "aria-pressed:bg-error aria-pressed:text-on-error aria-pressed:enabled:hover:bg-error/dim-1", "text-on-error-container"])
                }, {
                    intent: "info",
                    design: "tinted",
                    class: (0, i.tw)(["bg-info-container", "enabled:hover:bg-info-container-hovered", "enabled:active:bg-info-container-pressed", "focus-visible:bg-info-container-focused", "aria-pressed:bg-info aria-pressed:text-on-info aria-pressed:enabled:hover:bg-info/dim-1", "text-on-info-container"])
                }, {
                    intent: "neutral",
                    design: "tinted",
                    class: (0, i.tw)(["bg-neutral-container", "enabled:hover:bg-neutral-container-hovered", "enabled:active:bg-neutral-container-pressed", "focus-visible:bg-neutral-container-focused", "aria-pressed:bg-neutral aria-pressed:text-on-neutral aria-pressed:enabled:hover:bg-neutral/dim-1", "text-on-neutral-container"])
                }, {
                    intent: "surface",
                    design: "tinted",
                    class: (0, i.tw)(["bg-surface/dim-1", "enabled:hover:bg-surface-hovered/dim-1", "enabled:active:bg-surface-pressed/dim-1", "focus-visible:bg-surface-focused/dim-1", "aria-pressed:bg-surface aria-pressed:text-on-surface aria-pressed:enabled:hover:bg-surface-hovered", "text-on-surface/dim-1"])
                }, {
                    design: "tinted",
                    hasClearButton: !1,
                    class: (0, i.tw)(["px-md"])
                }, {
                    design: "tinted",
                    hasClearButton: !0,
                    class: (0, i.tw)(["pl-md"])
                }],
                g = [{
                    intent: "main",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-main/dim-5", "enabled:active:bg-main/dim-5", "focus-visible:bg-main/dim-5", "aria-pressed:bg-main-container aria-pressed:text-on-main-container aria-pressed:enabled:hover:bg-main-container/dim-1", "text-main"])
                }, {
                    intent: "support",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-support/dim-5", "enabled:active:bg-support/dim-5", "focus-visible:bg-support/dim-5", "aria-pressed:bg-support-container aria-pressed:text-on-support-container aria-pressed:enabled:hover:bg-support-container/dim-1", "text-support"])
                }, {
                    intent: "basic",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-basic/dim-5", "enabled:active:bg-basic/dim-5", "focus-visible:bg-basic/dim-5", "aria-pressed:bg-basic-container aria-pressed:text-on-basic-container aria-pressed:enabled:hover:bg-basic-container/dim-1", "text-basic"])
                }, {
                    intent: "accent",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-accent/dim-5", "enabled:active:bg-accent/dim-5", "focus-visible:bg-accent/dim-5", "aria-pressed:bg-accent-container aria-pressed:text-on-accent-container aria-pressed:enabled:hover:bg-accent-container/dim-1", "text-accent"])
                }, {
                    intent: "success",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-success/dim-5", "enabled:active:bg-success/dim-5", "focus-visible:bg-success/dim-5", "aria-pressed:bg-success-container aria-pressed:text-on-success-container aria-pressed:enabled:hover:bg-success-container/dim-1", "text-success"])
                }, {
                    intent: "alert",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-alert/dim-5", "enabled:active:bg-alert/dim-5", "focus-visible:bg-alert/dim-5", "aria-pressed:bg-alert-container aria-pressed:text-on-alert-container aria-pressed:enabled:hover:bg-alert-container/dim-1", "text-alert"])
                }, {
                    intent: "danger",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-error/dim-5", "enabled:active:bg-error/dim-5", "focus-visible:bg-error/dim-5", "aria-pressed:bg-error-container aria-pressed:text-on-error-container aria-pressed:enabled:hover:bg-error-container/dim-1", "text-error"])
                }, {
                    intent: "info",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-info/dim-5", "enabled:active:bg-info/dim-5", "focus-visible:bg-info/dim-5", "aria-pressed:bg-info-container aria-pressed:text-on-info-container aria-pressed:enabled:hover:bg-info-container/dim-1", "text-info"])
                }, {
                    intent: "neutral",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-neutral/dim-5", "enabled:active:bg-neutral/dim-5", "focus-visible:bg-neutral/dim-5", "aria-pressed:bg-neutral-container aria-pressed:text-on-neutral-container aria-pressed:enabled:hover:bg-neutral-container/dim-1", "text-neutral"])
                }, {
                    intent: "surface",
                    design: "dashed",
                    class: (0, i.tw)(["enabled:hover:bg-surface/dim-5", "enabled:active:bg-surface/dim-5", "focus-visible:bg-surface/dim-5", "aria-pressed:bg-surface aria-pressed:text-on-surface aria-pressed:enabled:hover:bg-surface-hovered", "text-surface"])
                }, {
                    design: "dashed",
                    hasClearButton: !1,
                    class: (0, i.tw)(["px-[calc(var(--spacing-md)-var(--border-width-sm))]"])
                }, {
                    design: "dashed",
                    hasClearButton: !0,
                    class: (0, i.tw)(["pl-[calc(var(--spacing-md)-var(--border-width-sm))]"])
                }],
                v = (0, s.j)(["box-border max-w-sz-240 inline-flex h-sz-32 flex-nowrap items-center justify-center rounded-md text-body-1 font-regular", "focus-visible:outline-none focus-visible:u-ring [&:not(:focus-visible)]:ring-inset", "ease-out duration-150"], {
                    variants: {
                        design: (0, i.TY)({
                            outlined: ["bg-transparent border-sm border-solid border-current"],
                            tinted: [""],
                            dashed: ["bg-transparent border-sm border-dashed shadow-none focus-visible:border-outline-high"]
                        }),
                        intent: (0, i.TY)({
                            main: [],
                            support: [],
                            basic: [],
                            accent: [],
                            success: [],
                            alert: [],
                            danger: [],
                            info: [],
                            neutral: [],
                            surface: []
                        }),
                        disabled: {
                            true: ["cursor-not-allowed", "opacity-dim-3"]
                        },
                        hasClearButton: {
                            true: [],
                            false: []
                        }
                    },
                    compoundVariants: [...f, ...p, ...g],
                    defaultVariants: {
                        design: "outlined",
                        intent: "basic"
                    }
                }),
                h = (0, a.createContext)({});
            var m = "u" > typeof globalThis ? globalThis : "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof self ? self : {},
                y = {
                    exports: {}
                };
            ! function(e, t) {
                var n = "__lodash_hash_undefined__",
                    r = "[object Arguments]",
                    a = "[object Array]",
                    i = "[object Boolean]",
                    s = "[object Date]",
                    o = "[object Error]",
                    c = "[object Function]",
                    d = "[object Map]",
                    l = "[object Number]",
                    u = "[object Object]",
                    b = "[object Promise]",
                    f = "[object RegExp]",
                    p = "[object Set]",
                    g = "[object String]",
                    v = "[object WeakMap]",
                    h = "[object ArrayBuffer]",
                    y = "[object DataView]",
                    x = /^\[object .+?Constructor\]$/,
                    _ = /^(?:0|[1-9]\d*)$/,
                    w = {};
                w["[object Float32Array]"] = w["[object Float64Array]"] = w["[object Int8Array]"] = w["[object Int16Array]"] = w["[object Int32Array]"] = w["[object Uint8Array]"] = w["[object Uint8ClampedArray]"] = w["[object Uint16Array]"] = w["[object Uint32Array]"] = !0, w[r] = w[a] = w[h] = w[i] = w[y] = w[s] = w[o] = w[c] = w[d] = w[l] = w[u] = w[f] = w[p] = w[g] = w[v] = !1;
                var C = "object" == typeof m && m && m.Object === Object && m,
                    j = "object" == typeof self && self && self.Object === Object && self,
                    E = C || j || Function("return this")(),
                    I = t && !t.nodeType && t,
                    k = I && e && !e.nodeType && e,
                    z = k && k.exports === I,
                    N = z && C.process,
                    T = function() {
                        try {
                            return N && N.binding && N.binding("util")
                        } catch {}
                    }(),
                    A = T && T.isTypedArray;

                function O(e) {
                    var t = -1,
                        n = Array(e.size);
                    return e.forEach(function(e, r) {
                        n[++t] = [r, e]
                    }), n
                }

                function B(e) {
                    var t = -1,
                        n = Array(e.size);
                    return e.forEach(function(e) {
                        n[++t] = e
                    }), n
                }
                var S, L, P, R = Array.prototype,
                    V = Function.prototype,
                    D = Object.prototype,
                    M = E["__core-js_shared__"],
                    F = V.toString,
                    H = D.hasOwnProperty,
                    $ = (S = /[^.]+$/.exec(M && M.keys && M.keys.IE_PROTO || "")) ? "Symbol(src)_1." + S : "",
                    Y = D.toString,
                    U = RegExp("^" + F.call(H).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                    K = z ? E.Buffer : void 0,
                    W = E.Symbol,
                    q = E.Uint8Array,
                    G = D.propertyIsEnumerable,
                    Z = R.splice,
                    J = W ? W.toStringTag : void 0,
                    Q = Object.getOwnPropertySymbols,
                    X = K ? K.isBuffer : void 0,
                    ee = (L = Object.keys, P = Object, function(e) {
                        return L(P(e))
                    }),
                    et = eE(E, "DataView"),
                    en = eE(E, "Map"),
                    er = eE(E, "Promise"),
                    ea = eE(E, "Set"),
                    ei = eE(E, "WeakMap"),
                    es = eE(Object, "create"),
                    eo = ez(et),
                    ec = ez(en),
                    ed = ez(er),
                    el = ez(ea),
                    eu = ez(ei),
                    eb = W ? W.prototype : void 0,
                    ef = eb ? eb.valueOf : void 0;

                function ep(e) {
                    var t = -1,
                        n = null == e ? 0 : e.length;
                    for (this.clear(); ++t < n;) {
                        var r = e[t];
                        this.set(r[0], r[1])
                    }
                }

                function eg(e) {
                    var t = -1,
                        n = null == e ? 0 : e.length;
                    for (this.clear(); ++t < n;) {
                        var r = e[t];
                        this.set(r[0], r[1])
                    }
                }

                function ev(e) {
                    var t = -1,
                        n = null == e ? 0 : e.length;
                    for (this.clear(); ++t < n;) {
                        var r = e[t];
                        this.set(r[0], r[1])
                    }
                }

                function eh(e) {
                    var t = -1,
                        n = null == e ? 0 : e.length;
                    for (this.__data__ = new ev; ++t < n;) this.add(e[t])
                }

                function em(e) {
                    var t = this.__data__ = new eg(e);
                    this.size = t.size
                }

                function ey(e, t) {
                    for (var n = e.length; n--;)
                        if (eN(e[n][0], t)) return n;
                    return -1
                }

                function ex(e) {
                    return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : J && J in Object(e) ? function(e) {
                        var t = H.call(e, J),
                            n = e[J];
                        try {
                            e[J] = void 0;
                            var r = !0
                        } catch {}
                        var a = Y.call(e);
                        return r && (t ? e[J] = n : delete e[J]), a
                    }(e) : Y.call(e)
                }

                function e_(e) {
                    return eP(e) && ex(e) == r
                }

                function ew(e, t, n, r, a, i) {
                    var s = 1 & n,
                        o = e.length,
                        c = t.length;
                    if (o != c && !(s && c > o)) return !1;
                    var d = i.get(e);
                    if (d && i.get(t)) return d == t;
                    var l = -1,
                        u = !0,
                        b = 2 & n ? new eh : void 0;
                    for (i.set(e, t), i.set(t, e); ++l < o;) {
                        var f = e[l],
                            p = t[l];
                        if (r) var g = s ? r(p, f, l, t, e, i) : r(f, p, l, e, t, i);
                        if (void 0 !== g) {
                            if (g) continue;
                            u = !1;
                            break
                        }
                        if (b) {
                            if (! function(e, t) {
                                    for (var n = -1, r = null == e ? 0 : e.length; ++n < r;)
                                        if (t(e[n], n, e)) return !0;
                                    return !1
                                }(t, function(e, t) {
                                    if (!b.has(t) && (f === e || a(f, e, n, r, i))) return b.push(t)
                                })) {
                                u = !1;
                                break
                            }
                        } else if (f !== p && !a(f, p, n, r, i)) {
                            u = !1;
                            break
                        }
                    }
                    return i.delete(e), i.delete(t), u
                }

                function eC(e) {
                    var t;
                    return t = function(e) {
                        return null != e && eS(e.length) && !eB(e) ? function(e, t) {
                            var n, r, a = eA(e),
                                i = !a && eT(e),
                                s = !a && !i && eO(e),
                                o = !a && !i && !s && eR(e),
                                c = a || i || s || o,
                                d = c ? function(e, t) {
                                    for (var n = -1, r = Array(e); ++n < e;) r[n] = t(n);
                                    return r
                                }(e.length, String) : [],
                                l = d.length;
                            for (var u in e) !H.call(e, u) || c && ("length" == u || s && ("offset" == u || "parent" == u) || o && ("buffer" == u || "byteLength" == u || "byteOffset" == u) || (n = u, (r = (r = l) ? ? 9007199254740991) && ("number" == typeof n || _.test(n)) && n > -1 && n % 1 == 0 && n < r)) || d.push(u);
                            return d
                        }(e) : function(e) {
                            if (n = "function" == typeof(t = e && e.constructor) && t.prototype || D, e !== n) return ee(e);
                            var t, n, r = [];
                            for (var a in Object(e)) H.call(e, a) && "constructor" != a && r.push(a);
                            return r
                        }(e)
                    }(e), eA(e) ? t : function(e, t) {
                        for (var n = -1, r = t.length, a = e.length; ++n < r;) e[a + n] = t[n];
                        return e
                    }(t, eI(e))
                }

                function ej(e, t) {
                    var n, r = e.__data__;
                    return ("string" == (n = typeof t) || "number" == n || "symbol" == n || "boolean" == n ? "__proto__" !== t : null === t) ? r["string" == typeof t ? "string" : "hash"] : r.map
                }

                function eE(e, t) {
                    var n = e ? .[t];
                    return !(!eL(n) || $ && $ in n) && (eB(n) ? U : x).test(ez(n)) ? n : void 0
                }
                ep.prototype.clear = function() {
                    this.__data__ = es ? es(null) : {}, this.size = 0
                }, ep.prototype.delete = function(e) {
                    var t = this.has(e) && delete this.__data__[e];
                    return this.size -= t ? 1 : 0, t
                }, ep.prototype.get = function(e) {
                    var t = this.__data__;
                    if (es) {
                        var r = t[e];
                        return r === n ? void 0 : r
                    }
                    return H.call(t, e) ? t[e] : void 0
                }, ep.prototype.has = function(e) {
                    var t = this.__data__;
                    return es ? void 0 !== t[e] : H.call(t, e)
                }, ep.prototype.set = function(e, t) {
                    var r = this.__data__;
                    return this.size += this.has(e) ? 0 : 1, r[e] = es && void 0 === t ? n : t, this
                }, eg.prototype.clear = function() {
                    this.__data__ = [], this.size = 0
                }, eg.prototype.delete = function(e) {
                    var t = this.__data__,
                        n = ey(t, e);
                    return !(n < 0) && (n == t.length - 1 ? t.pop() : Z.call(t, n, 1), --this.size, !0)
                }, eg.prototype.get = function(e) {
                    var t = this.__data__,
                        n = ey(t, e);
                    return n < 0 ? void 0 : t[n][1]
                }, eg.prototype.has = function(e) {
                    return ey(this.__data__, e) > -1
                }, eg.prototype.set = function(e, t) {
                    var n = this.__data__,
                        r = ey(n, e);
                    return r < 0 ? (++this.size, n.push([e, t])) : n[r][1] = t, this
                }, ev.prototype.clear = function() {
                    this.size = 0, this.__data__ = {
                        hash: new ep,
                        map: new(en || eg),
                        string: new ep
                    }
                }, ev.prototype.delete = function(e) {
                    var t = ej(this, e).delete(e);
                    return this.size -= t ? 1 : 0, t
                }, ev.prototype.get = function(e) {
                    return ej(this, e).get(e)
                }, ev.prototype.has = function(e) {
                    return ej(this, e).has(e)
                }, ev.prototype.set = function(e, t) {
                    var n = ej(this, e),
                        r = n.size;
                    return n.set(e, t), this.size += n.size == r ? 0 : 1, this
                }, eh.prototype.add = eh.prototype.push = function(e) {
                    return this.__data__.set(e, n), this
                }, eh.prototype.has = function(e) {
                    return this.__data__.has(e)
                }, em.prototype.clear = function() {
                    this.__data__ = new eg, this.size = 0
                }, em.prototype.delete = function(e) {
                    var t = this.__data__,
                        n = t.delete(e);
                    return this.size = t.size, n
                }, em.prototype.get = function(e) {
                    return this.__data__.get(e)
                }, em.prototype.has = function(e) {
                    return this.__data__.has(e)
                }, em.prototype.set = function(e, t) {
                    var n = this.__data__;
                    if (n instanceof eg) {
                        var r = n.__data__;
                        if (!en || r.length < 199) return r.push([e, t]), this.size = ++n.size, this;
                        n = this.__data__ = new ev(r)
                    }
                    return n.set(e, t), this.size = n.size, this
                };
                var eI = Q ? function(e) {
                        return null == e ? [] : function(e, t) {
                            for (var n = -1, r = null == e ? 0 : e.length, a = 0, i = []; ++n < r;) {
                                var s = e[n];
                                t(s, n, e) && (i[a++] = s)
                            }
                            return i
                        }(Q(e = Object(e)), function(t) {
                            return G.call(e, t)
                        })
                    } : function() {
                        return []
                    },
                    ek = ex;

                function ez(e) {
                    if (null != e) {
                        try {
                            return F.call(e)
                        } catch {}
                        try {
                            return e + ""
                        } catch {}
                    }
                    return ""
                }

                function eN(e, t) {
                    return e === t || e != e && t != t
                }(et && ek(new et(new ArrayBuffer(1))) != y || en && ek(new en) != d || er && ek(er.resolve()) != b || ea && ek(new ea) != p || ei && ek(new ei) != v) && (ek = function(e) {
                    var t = ex(e),
                        n = t == u ? e.constructor : void 0,
                        r = n ? ez(n) : "";
                    if (r) switch (r) {
                        case eo:
                            return y;
                        case ec:
                            return d;
                        case ed:
                            return b;
                        case el:
                            return p;
                        case eu:
                            return v
                    }
                    return t
                });
                var eT = e_(function() {
                        return arguments
                    }()) ? e_ : function(e) {
                        return eP(e) && H.call(e, "callee") && !G.call(e, "callee")
                    },
                    eA = Array.isArray,
                    eO = X || function() {
                        return !1
                    };

                function eB(e) {
                    if (!eL(e)) return !1;
                    var t = ex(e);
                    return t == c || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t
                }

                function eS(e) {
                    return "number" == typeof e && e > -1 && e % 1 == 0 && e <= 9007199254740991
                }

                function eL(e) {
                    var t = typeof e;
                    return null != e && ("object" == t || "function" == t)
                }

                function eP(e) {
                    return null != e && "object" == typeof e
                }
                var eR = A ? function(e) {
                    return A(e)
                } : function(e) {
                    return eP(e) && eS(e.length) && !!w[ex(e)]
                };
                e.exports = function(e, t) {
                    return function e(t, n, c, b, v) {
                        return t === n || (null != t && null != n && (eP(t) || eP(n)) ? function(e, t, n, c, b, v) {
                            var m = eA(e),
                                x = eA(t),
                                _ = m ? a : ek(e),
                                w = x ? a : ek(t),
                                C = (_ = _ == r ? u : _) == u,
                                j = (w = w == r ? u : w) == u,
                                E = _ == w;
                            if (E && eO(e)) {
                                if (!eO(t)) return !1;
                                m = !0, C = !1
                            }
                            if (E && !C) return v || (v = new em), m || eR(e) ? ew(e, t, n, c, b, v) : function(e, t, n, r, a, c, u) {
                                switch (n) {
                                    case y:
                                        if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) break;
                                        e = e.buffer, t = t.buffer;
                                    case h:
                                        return !(e.byteLength != t.byteLength || !c(new q(e), new q(t)));
                                    case i:
                                    case s:
                                    case l:
                                        return eN(+e, +t);
                                    case o:
                                        return e.name == t.name && e.message == t.message;
                                    case f:
                                    case g:
                                        return e == t + "";
                                    case d:
                                        var b = O;
                                    case p:
                                        var v = 1 & r;
                                        if (b || (b = B), e.size != t.size && !v) break;
                                        var m = u.get(e);
                                        if (m) return m == t;
                                        r |= 2, u.set(e, t);
                                        var x = ew(b(e), b(t), r, a, c, u);
                                        return u.delete(e), x;
                                    case "[object Symbol]":
                                        if (ef) return ef.call(e) == ef.call(t)
                                }
                                return !1
                            }(e, t, _, n, c, b, v);
                            if (!(1 & n)) {
                                var I = C && H.call(e, "__wrapped__"),
                                    k = j && H.call(t, "__wrapped__");
                                if (I || k) {
                                    var z = I ? e.value() : e,
                                        N = k ? t.value() : t;
                                    return v || (v = new em), b(z, N, n, c, v)
                                }
                            }
                            return !!E && (v || (v = new em), function(e, t, n, r, a, i) {
                                var s = 1 & n,
                                    o = eC(e),
                                    c = o.length;
                                if (c != eC(t).length && !s) return !1;
                                for (var d = c; d--;) {
                                    var l = o[d];
                                    if (!(s ? l in t : H.call(t, l))) return !1
                                }
                                var u = i.get(e);
                                if (u && i.get(t)) return u == t;
                                var b = !0;
                                i.set(e, t), i.set(t, e);
                                for (var f = s; ++d < c;) {
                                    var p = e[l = o[d]],
                                        g = t[l];
                                    if (r) var v = s ? r(g, p, l, t, e, i) : r(p, g, l, e, t, i);
                                    if (!(void 0 === v ? p === g || a(p, g, n, r, i) : v)) {
                                        b = !1;
                                        break
                                    }
                                    f || (f = "constructor" == l)
                                }
                                if (b && !f) {
                                    var h = e.constructor,
                                        m = t.constructor;
                                    h == m || !("constructor" in e) || !("constructor" in t) || "function" == typeof h && h instanceof h && "function" == typeof m && m instanceof m || (b = !1)
                                }
                                return i.delete(e), i.delete(t), b
                            }(e, t, n, c, b, v))
                        }(t, n, c, b, e, v) : t != t && n != n)
                    }(e, t)
                }
            }(y, y.exports);
            let x = (r = y.exports) && r.__esModule && Object.prototype.hasOwnProperty.call(r, "default") ? r.default : r;

            function _(e, t, n) {
                let r = void 0 !== e,
                    {
                        current: i
                    } = (0, a.useRef)(r ? e : t),
                    [s, o] = (0, a.useState)(t),
                    c = r ? e : s,
                    d = (0, a.useCallback)((e, t = (e, t) => !x(e, t)) => {
                        let a = "function" != typeof e ? e : e(c);
                        t(c, a) && !r && o(a), n && n(a)
                    }, [r, c, n]);
                return [c, d, r, i]
            }
            let w = ({
                    onClick: e,
                    asChild: t,
                    pressed: n,
                    defaultPressed: r,
                    disabled: i,
                    value: s,
                    defaultValue: d,
                    children: l,
                    onClear: u
                }) => {
                    let [b, f] = _(n, r), [p] = _(s, d), g = (...e) => a.Children.toArray(l).filter(a.isValidElement).find(t => {
                        let n = t ? t.type.displayName : "";
                        return e.includes(n || "")
                    }), v = g("Chip.LeadingIcon"), h = g("Chip.TrailingIcon"), m = g("Chip.Content"), y = g("Chip.ClearButton"), x = [v, m, y].every(e => void 0 === e) ? a.createElement("span", {
                        className: "inline-block grow truncate"
                    }, l) : a.createElement(a.Fragment, null, v, m, void 0 === v ? h : null, y), w = e => {
                        y && !i && ["Delete", "Backspace"].includes(e.key) && u && (u(), "Delete" === e.key && (0, c.T)(), "Backspace" === e.key && c.T.backwards())
                    };
                    return (e || b) !== void 0 ? {
                        Element: t ? o.g7 : "button",
                        chipProps: {
                            type: "button",
                            ...void 0 !== b && {
                                "aria-pressed": b,
                                "data-state": b ? "on" : "off"
                            },
                            onClick: t => {
                                void 0 !== b && f(!b), e && e(t, {
                                    pressed: b,
                                    value: p
                                })
                            },
                            onKeyDown: w,
                            disabled: i,
                            children: x
                        },
                        compoundElements: {
                            leadingIcon: v,
                            trailingIcon: h,
                            content: m,
                            clearButton: y
                        }
                    } : {
                        Element: t ? o.g7 : "div",
                        chipProps: {
                            "aria-disabled": i,
                            children: x,
                            onKeyDown: w
                        },
                        compoundElements: {
                            leadingIcon: v,
                            trailingIcon: h,
                            content: m,
                            clearButton: y
                        }
                    }
                },
                C = (0, a.forwardRef)(({
                    design: e = "outlined",
                    disabled: t,
                    children: n,
                    intent: r = "basic",
                    defaultPressed: i,
                    pressed: s,
                    asChild: o,
                    className: c,
                    onClick: d,
                    onClear: l,
                    ...u
                }, b) => {
                    let {
                        Element: f,
                        chipProps: {
                            children: p,
                            ...g
                        },
                        compoundElements: m
                    } = w({
                        asChild: o,
                        pressed: s,
                        defaultPressed: i,
                        onClick: d,
                        disabled: !!t,
                        value: u.value,
                        defaultValue: u.defaultValue,
                        children: n,
                        onClear: l
                    }), {
                        clearButton: y
                    } = m;
                    return a.createElement(h.Provider, {
                        value: {
                            disabled: t,
                            design: e,
                            intent: r,
                            onClear: l
                        }
                    }, a.createElement(f, {
                        ref: b,
                        className: v({
                            className: c,
                            design: e,
                            disabled: t,
                            intent: r,
                            hasClearButton: !!y
                        }),
                        ...g,
                        ...u,
                        "data-spark-component": "chip"
                    }, p))
                });
            C.displayName = "Chip";
            let j = a.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: n = "none",
                ...r
            }, i) => a.createElement("svg", {
                ref: i,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "Close",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: n,
                ...r,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m21.6,19.67l-7.68-7.68,7.57-7.59c.53-.53.53-1.4,0-1.93-.53-.53-1.4-.53-1.93,0l-7.57,7.58L4.33,2.4c-.53-.53-1.4-.53-1.93,0-.53.53-.53,1.4,0,1.93l7.66,7.66-7.66,7.65c-.53.53-.53,1.4,0,1.93.53.53,1.4.53,1.93,0l7.66-7.66,7.68,7.68c.53.53,1.4.53,1.93,0,.53-.53.53-1.4,0-1.93h0Z"/>'
                }
            }));
            j.displayName = "Close";
            let E = (0, s.j)(["ml-md flex h-full items-center justify-center focus-visible:outline-none"], {
                    variants: {
                        disabled: {
                            false: ["cursor-pointer"],
                            true: ["cursor-not-allowed"]
                        },
                        isBordered: {
                            false: ["pr-md"],
                            true: ["pr-[7px]"]
                        },
                        design: {
                            outlined: [],
                            tinted: [],
                            dashed: []
                        }
                    },
                    compoundVariants: [{
                        design: "outlined",
                        disabled: !1,
                        class: (0, i.tw)(["hover:opacity-dim-1"])
                    }, {
                        design: "outlined",
                        disabled: !0,
                        class: (0, i.tw)(["opacity-dim-3"])
                    }, {
                        design: "tinted",
                        disabled: !1,
                        class: (0, i.tw)(["hover:opacity-dim-1"])
                    }, {
                        design: "tinted",
                        disabled: !0,
                        class: (0, i.tw)(["opacity-dim-3"])
                    }, {
                        design: "dashed",
                        disabled: !1,
                        class: (0, i.tw)(["hover:opacity-dim-1"])
                    }, {
                        design: "dashed",
                        disabled: !0,
                        class: (0, i.tw)(["opacity-dim-3"])
                    }]
                }),
                I = (0, s.j)(["rounded-full p-[--sz-2] [font-size:--sz-8] border-sm", "focus-visible:outline-2 focus-visible:outline focus-visible:outline-offset-2  focus-visible:outline-[blue]"], {
                    variants: {
                        disabled: {
                            true: ["cursor-not-allowed"],
                            false: ["cursor-pointer"]
                        }
                    }
                }),
                k = (0, a.forwardRef)(({
                    children: e = a.createElement(b, null, a.createElement(j, null)),
                    tabIndex: t = 0,
                    label: n
                }, r) => {
                    let {
                        design: i,
                        disabled: s,
                        onClear: o
                    } = (0, a.useContext)({ ...h
                    }) || {}, c = (0, a.useCallback)(e => {
                        e.stopPropagation(), !s && o && o(e)
                    }, [s, o]);
                    return a.createElement("span", {
                        className: E({
                            isBordered: ["outline", "dashed"].includes(`${i}`),
                            disabled: !!s,
                            design: i
                        }),
                        onClick: c,
                        ref: r
                    }, a.createElement("button", {
                        tabIndex: t,
                        type: "button",
                        disabled: !!s,
                        className: I({
                            disabled: s
                        }),
                        "aria-label": n
                    }, e && (0, a.cloneElement)(e, {
                        "aria-label": n
                    })))
                });
            k.displayName = "Chip.ClearButton";
            let z = (0, a.forwardRef)(({
                children: e,
                className: t
            }, n) => a.createElement("span", {
                className: (0, s.cx)("inline-block grow truncate", t),
                ref: n
            }, e));
            z.displayName = "Chip.Content";
            let N = (0, a.forwardRef)(({
                children: e,
                className: t
            }, n) => a.createElement("span", {
                className: (0, s.cx)("flex h-full items-center justify-center", t),
                ref: n
            }, e));
            N.displayName = "Chip.Icon";
            let T = (0, a.forwardRef)(({
                className: e,
                ...t
            }, n) => a.createElement(N, {
                className: (0, s.cx)("mr-sm", e),
                ref: n,
                ...t
            }));
            T.displayName = "Chip.LeadingIcon";
            let A = (0, a.forwardRef)(({
                className: e,
                ...t
            }, n) => a.createElement(N, {
                className: (0, s.cx)("ml-md", e),
                ref: n,
                ...t
            }));
            A.displayName = "Chip.TrailingIcon";
            let O = Object.assign(C, {
                Content: z,
                LeadingIcon: T,
                TrailingIcon: A,
                ClearButton: k
            });
            O.displayName = "Chip", O.ClearButton.displayName = "Chip.ClearButton", O.Content.displayName = "Chip.Content", O.LeadingIcon.displayName = "Chip.LeadingIcon", O.TrailingIcon.displayName = "Chip.TrailingIcon"
        },
        9221: function(e, t, n) {
            n.d(t, {
                V: function() {
                    return c
                }
            });
            var r = n(67294),
                a = n(66051),
                i = n(74934),
                s = n(29107);
            let o = (0, s.j)(["box-border inline-flex items-center justify-center gap-sm whitespace-nowrap", "text-caption font-bold", "h-sz-20 px-md", "rounded-full"], {
                    variants: {
                        design: (0, i.TY)({
                            filled: [],
                            outlined: ["border-sm", "border-current"],
                            tinted: []
                        }),
                        intent: (0, i.TY)({
                            main: [],
                            support: [],
                            accent: [],
                            basic: [],
                            success: [],
                            alert: [],
                            danger: [],
                            info: [],
                            neutral: []
                        })
                    },
                    compoundVariants: [{
                        intent: "main",
                        design: "filled",
                        class: ["bg-main", "text-on-main"]
                    }, {
                        intent: "support",
                        design: "filled",
                        class: ["bg-support", "text-on-support"]
                    }, {
                        intent: "accent",
                        design: "filled",
                        class: ["bg-accent", "text-on-accent"]
                    }, {
                        intent: "basic",
                        design: "filled",
                        class: ["bg-basic", "text-on-basic"]
                    }, {
                        intent: "success",
                        design: "filled",
                        class: ["bg-success", "text-on-success"]
                    }, {
                        intent: "alert",
                        design: "filled",
                        class: ["bg-alert", "text-on-alert"]
                    }, {
                        intent: "danger",
                        design: "filled",
                        class: ["bg-error", "text-on-error"]
                    }, {
                        intent: "info",
                        design: "filled",
                        class: ["bg-info", "text-on-info"]
                    }, {
                        intent: "neutral",
                        design: "filled",
                        class: ["bg-neutral", "text-on-neutral"]
                    }, {
                        intent: "main",
                        design: "outlined",
                        class: ["text-main"]
                    }, {
                        intent: "support",
                        design: "outlined",
                        class: ["text-support"]
                    }, {
                        intent: "accent",
                        design: "outlined",
                        class: ["text-accent"]
                    }, {
                        intent: "basic",
                        design: "outlined",
                        class: ["text-basic"]
                    }, {
                        intent: "success",
                        design: "outlined",
                        class: ["text-success"]
                    }, {
                        intent: "alert",
                        design: "outlined",
                        class: ["text-alert"]
                    }, {
                        intent: "danger",
                        design: "outlined",
                        class: ["text-error"]
                    }, {
                        intent: "info",
                        design: "outlined",
                        class: ["text-info"]
                    }, {
                        intent: "neutral",
                        design: "outlined",
                        class: ["text-neutral"]
                    }, {
                        intent: "main",
                        design: "tinted",
                        class: ["bg-main-container", "text-on-main-container"]
                    }, {
                        intent: "support",
                        design: "tinted",
                        class: ["bg-support-container", "text-on-support-container"]
                    }, {
                        intent: "accent",
                        design: "tinted",
                        class: ["bg-accent-container", "text-on-accent-container"]
                    }, {
                        intent: "basic",
                        design: "tinted",
                        class: ["bg-basic-container", "text-on-basic-container"]
                    }, {
                        intent: "success",
                        design: "tinted",
                        class: ["bg-success-container", "text-on-success-container"]
                    }, {
                        intent: "alert",
                        design: "tinted",
                        class: ["bg-alert-container", "text-on-alert-container"]
                    }, {
                        intent: "danger",
                        design: "tinted",
                        class: ["bg-error-container", "text-on-error-container"]
                    }, {
                        intent: "info",
                        design: "tinted",
                        class: ["bg-info-container", "text-on-info-container"]
                    }, {
                        intent: "neutral",
                        design: "tinted",
                        class: ["bg-neutral-container", "text-on-neutral-container"]
                    }],
                    defaultVariants: {
                        design: "filled",
                        intent: "basic"
                    }
                }),
                c = (0, r.forwardRef)(({
                    design: e = "filled",
                    intent: t = "basic",
                    asChild: n,
                    className: i,
                    ...s
                }, c) => {
                    let d = n ? a.g7 : "span";
                    return r.createElement(d, {
                        "data-spark-component": "tag",
                        ref: c,
                        className: o({
                            className: i,
                            design: e,
                            intent: t
                        }),
                        ...s
                    })
                })
        }
    }
]);