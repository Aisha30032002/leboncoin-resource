! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "651ae8fd-e105-40e8-8857-ca2385e20778", e._sentryDebugIdIdentifier = "sentry-dbid-651ae8fd-e105-40e8-8857-ca2385e20778")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
}, (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [49097], {
        91388: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return eC
                }
            });
            var r, o = n(85893),
                i = n(29107),
                s = n(70686);
            n(67294);
            var a = n(31525),
                l = n(34788),
                c = n(12796),
                u = n(72253),
                f = n(78551),
                d = n(11390),
                m = n(73374),
                p = n(63941),
                h = function(e) {
                    var t = (0, l._)({}, (0, c._)(e)),
                        n = (0, f.a)({
                            queryKey: ["getTrustpilotScore"],
                            queryFn: d.G
                        }).data;
                    return (0, m.P)(n) ? (0, o.jsx)(p.Z, (0, u._)({
                        link: "https://fr.trustpilot.com/review/www.leboncoin.fr",
                        variant: "combo",
                        textColor: "white",
                        trustInfo: n
                    }, t)) : null
                },
                x = function(e) {
                    var t = e.brandName,
                        n = e.startYear;
                    return (0, o.jsx)("span", {
                        children: "".concat(t, " ").concat(n, " - ").concat(new Date().getFullYear())
                    })
                },
                g = (0, i.j)(["inline-flex whitespace-normal", "after:whitespace-pre after:content-['_\xb7_'] last:after:content-none first:after:content-none"], {
                    variants: {
                        withPrefix: {
                            true: "whitespace-pre",
                            false: "whitespace-normal"
                        }
                    },
                    defaultVariants: {
                        withPrefix: !1
                    }
                }),
                _ = function(e) {
                    var t = e.className,
                        n = e.items,
                        r = e.prefix;
                    return (0, o.jsxs)("ul", {
                        className: (0, i.cx)("mx-none mb-md mt-xl p-md", "border-b-sm border-t-sm border-outline", "text-center text-body-1", "hover:[&_a]:underline", t),
                        children: [r && (0, o.jsx)("li", {
                            className: g({
                                withPrefix: !0
                            }),
                            children: "".concat(r, " : ")
                        }), n.map(function(e, t) {
                            return (0, o.jsx)("li", {
                                className: g(),
                                children: (0, o.jsx)(e, {})
                            }, t)
                        })]
                    })
                },
                w = n(75766),
                b = n(24356),
                A = n(76883),
                v = n(68915);

            function k() {
                v.Z.track({
                    event_name: "footer::a_propos_du_bon_coin::qui_sommes_nous::%pagetype",
                    event_s2: "9"
                })
            }

            function j() {
                v.Z.track({
                    event_name: "footer::a_propos_du_bon_coin::recrutement::%pagetype",
                    event_s2: "9"
                })
            }

            function y() {
                v.Z.track({
                    event_name: "footer::informations_legales::conditions_generales_d_utilisation::%pagetype",
                    event_s2: "9"
                })
            }

            function N() {
                v.Z.track({
                    event_name: "footer::informations_legales::regles_de_diffusion::%pagetype",
                    event_s2: "9"
                })
            }

            function C() {
                v.Z.track({
                    event_name: "footer::informations_legales::avis_utilisateurs::%pagetype",
                    event_s2: "9"
                })
            }

            function E() {
                v.Z.track({
                    event_name: "footer::informations_legales::charte_bonne_conduite::%pagetype",
                    event_s2: "9"
                })
            }

            function I() {
                v.Z.track({
                    event_name: "footer::informations_legales::paiement_en_plusieurs_fois::%pagetype",
                    event_s2: "9"
                })
            }

            function Z() {
                v.Z.track({
                    event_name: "footer::informations_legales::conditions_generales_de_vente::%pagetype",
                    event_s2: "9"
                })
            }

            function T() {
                v.Z.track({
                    event_name: "footer::informations_legales::vie_privee_cookies::%pagetype",
                    event_s2: "9"
                })
            }

            function D() {
                v.Z.track({
                    event_name: "footer::professionnels::publicite::%pagetype",
                    event_s2: "9"
                })
            }

            function L() {
                v.Z.track({
                    event_name: "footer::informations_legales::vos_droits_et_obligations::%pagetype",
                    event_s2: "9"
                })
            }

            function S() {
                v.Z.track({
                    event_name: "footer::professionnels::professionnels_de_l_immobilier::%pagetype",
                    event_s2: "9"
                })
            }

            function B() {
                v.Z.track({
                    event_name: "footer::professionnels_emploi::formulaire::%pagetype",
                    event_s2: "9"
                })
            }

            function U() {
                v.Z.track({
                    event_name: "footer::professionnels::auto",
                    event_s2: "9"
                })
            }

            function P() {
                v.Z.track({
                    event_name: "footer::professionnels::vacances",
                    event_s2: "9"
                })
            }

            function M() {
                v.Z.track({
                    event_name: "footer::professionnels::multicat",
                    event_s2: "9"
                })
            }

            function V() {
                v.Z.track({
                    event_name: "footer::professionnels::annuaire_pro",
                    event_s2: "9"
                })
            }

            function R() {
                v.Z.track({
                    event_name: "footer::des_questions::aide::%pagetype",
                    event_s2: "9"
                })
            }

            function z() {
                A._q.cleanUtagData(), A._q.sendUnlimitedPageLoad({
                    eventname: "footer_holidays_host_landing_page"
                })
            }

            function G() {
                v.Z.track({
                    event_name: "reseaux_sociaux::linkedin::%pagetype",
                    event_s2: "9"
                })
            }

            function Y() {
                v.Z.track({
                    event_name: "reseaux_sociaux::twitter::%pagetype",
                    event_s2: "9"
                })
            }

            function Q() {
                v.Z.track({
                    event_name: "reseaux_sociaux::instagram::%pagetype",
                    event_s2: "9"
                })
            }

            function O() {
                v.Z.track({
                    event_name: "reseaux_sociaux::pinterest::%pagetype",
                    event_s2: "9"
                })
            }

            function W() {
                A._q.cleanUtagData(), A._q.sendUnlimitedPageLoad({
                    eventname: "footer::professionnels::gratuite_tpe"
                })
            }

            function q(e) {
                return function() {
                    v.Z.track({
                        event_name: "footer::vous_etes_a_l_etranger::".concat(e, "::%pagetype"),
                        event_s2: "9"
                    })
                }
            }

            function F(e) {
                return function() {
                    v.Z.track({
                        event_name: "footer::partenaires::".concat(e, "::%pagetype"),
                        event_s2: "9"
                    })
                }
            }

            function J() {
                v.Z.track({
                    event_name: "footer::informations_legales::accessibilite::%pagetype",
                    event_s2: "9"
                })
            }
            var H = (r = {}, (0, w._)(r, b.Vh.name, F("avendrealouer")), (0, w._)(r, b.ES.name, F("avendrealouerneuf")), (0, w._)(r, b.El.name, F("largus")), (0, w._)(r, b.TC.name, F("agriaffaires")), (0, w._)(r, b.O0.name, F("machineryzone")), (0, w._)(r, b.tf.name, F("truckscorner")), (0, w._)(r, b.YK.name, F("locasun")), (0, w._)(r, b.ko.name, F("locasun-vp")), (0, w._)(r, b.Jr.name, F("videdressing")), (0, w._)(r, b.Zh.name, F("ledenicheur")), (0, w._)(r, b.IB.name, F("younited_credit")), r),
                K = b.pS.map(function(e) {
                    return function() {
                        var t = e.name,
                            n = e.description,
                            r = e.href;
                        return (0, o.jsx)("a", {
                            href: r,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: n || t,
                            onClick: H[t],
                            children: t
                        })
                    }
                }),
                X = n(9210),
                $ = n(59225),
                ee = n(25043),
                et = n(41664),
                en = n.n(et),
                er = n(16816),
                eo = {
                    src: "/_next/static/media/download_on_app_gallery.00e5b754.png",
                    height: 35,
                    width: 117,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAGFBMVEV5KzRiXl07MzBOPz9KRUNXUlGiJDRIPTzOQzalAAAABXRSTlP6/eX95B2/K+0AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAaSURBVAiZY2BgY2dlZWVnYmBgY2ZkZWRlAQACZQA/tl6UgQAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 2
                },
                ei = {
                    src: "/_next/static/media/download_on_app_store.7341ef41.png",
                    height: 40,
                    width: 135,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAElBMVEUgICAuLi48PDxKSkpycnKUlJTgvWadAAAAA3RSTlP9/v6XUDd1AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGklEQVQImWNgZGFgZGRkYGBgYmVgZmJiYgAAAN4AGXvNy0YAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 2
                },
                es = n(16928),
                ea = {
                    src: "/_next/static/media/download_on_google_play.270265cc.png",
                    height: 35,
                    width: 117,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAG1BMVEU9Pj4yMjJMTEwaU1suJyU2NyggSi0XFxcgICAbVB8BAAAACHRSTlP98/74/f7+6Ul8FsQAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAaSURBVAiZY2BmY2FgZOBgZ2BmZWFgYmBiBAAB7AAv6qeVWgAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 2
                },
                el = n(23378),
                ec = n(51190),
                eu = [{
                    TLD: $.SA,
                    countryName: $.xE[$.SA],
                    shortUrl: "gumtree.co.za",
                    tracking: q((0, ec.Nw)($.xE[$.SA])),
                    url: "https://www.gumtree.co.za/"
                }, {
                    TLD: $.GE,
                    countryName: $.xE[$.GE],
                    shortUrl: "mobile.de",
                    tracking: q((0, ec.Nw)($.xE[$.GE])),
                    url: "https://www.mobile.de/"
                }, {
                    TLD: $.AU,
                    countryName: $.xE[$.AU],
                    shortUrl: "autotrader.com.au",
                    tracking: q((0, ec.Nw)($.xE[$.AU])),
                    url: "https://www.autotrader.com.au/"
                }, {
                    TLD: $.AT,
                    countryName: $.xE[$.AT],
                    shortUrl: "willhaben.at",
                    tracking: q((0, ec.Nw)($.xE[$.AT])),
                    url: "https://www.willhaben.at/"
                }, {
                    TLD: $.BE,
                    countryName: $.xE[$.BE],
                    shortUrl: "2dehands.be",
                    tracking: q((0, ec.Nw)($.xE[$.BE])),
                    url: "https://www.2dehands.be/"
                }, {
                    TLD: $.BY,
                    countryName: $.xE[$.BY],
                    shortUrl: "kufar.by",
                    tracking: q((0, ec.Nw)($.xE[$.BY])),
                    url: "https://www.kufar.by/"
                }, {
                    TLD: $.BR,
                    countryName: $.xE[$.BR],
                    shortUrl: "olx.com.br",
                    tracking: q((0, ec.Nw)($.xE[$.BR])),
                    url: "https://www.olx.com.br/"
                }, {
                    TLD: $.CA,
                    countryName: $.xE[$.CA],
                    shortUrl: "kijiji.ca",
                    tracking: q((0, ec.Nw)($.xE[$.CA])),
                    url: "https://www.kijiji.ca/"
                }, {
                    TLD: $.ES,
                    countryName: $.xE[$.ES],
                    shortUrl: "milanuncios.com",
                    tracking: q((0, ec.Nw)($.xE[$.ES])),
                    url: "https://www.milanuncios.com/"
                }, {
                    TLD: $.HU,
                    countryName: $.xE[$.HU],
                    shortUrl: "jofogas.hu",
                    tracking: q((0, ec.Nw)($.xE[$.HU])),
                    url: "https://www.jofogas.hu/"
                }, {
                    TLD: $.IE,
                    countryName: $.xE[$.IE],
                    shortUrl: "donedeal.ie",
                    tracking: q((0, ec.Nw)($.xE[$.IE])),
                    url: "https://www.donedeal.ie/"
                }, {
                    TLD: $.IT,
                    countryName: $.xE[$.IT],
                    shortUrl: "subito.it",
                    tracking: q((0, ec.Nw)($.xE[$.IT])),
                    url: "https://www.subito.it/"
                }, {
                    TLD: $.MX,
                    countryName: $.xE[$.MX],
                    shortUrl: "segundamano.mx",
                    tracking: q((0, ec.Nw)($.xE[$.MX])),
                    url: "https://www.segundamano.mx/"
                }, {
                    TLD: $.NE,
                    countryName: $.xE[$.NE],
                    shortUrl: "marktplaats.nl",
                    tracking: q((0, ec.Nw)($.xE[$.NE])),
                    url: "https://www.marktplaats.nl/"
                }, {
                    TLD: $.SG,
                    countryName: $.xE[$.SG],
                    shortUrl: "gumtree.sg",
                    tracking: q((0, ec.Nw)($.xE[$.SG])),
                    url: "https://www.gumtree.sg/"
                }],
                ef = {
                    title: "\xe0 propos du boncoin",
                    items: [function() {
                        return (0, o.jsx)("a", {
                            href: "https://leboncoincorporate.com/",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: "Qui sommes-nous ?",
                            onClick: k,
                            children: "Qui sommes-nous ?"
                        })
                    }, function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "proWithName",
                            params: {
                                id: 11532,
                                name: "postulez_aux_offres_d_emploi_leboncoin"
                            },
                            title: "Nous rejoindre",
                            onClick: j,
                            children: "Nous rejoindre"
                        })
                    }, function() {
                        return (0, o.jsx)("a", {
                            href: "https://leboncoincorporate.com/nos-engagements/",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: "Nos engagements",
                            children: "Nos engagements"
                        })
                    }, function() {
                        return (0, o.jsx)("a", {
                            href: "https://www.laveniradubon.fr",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: "L’Avenir a du bon",
                            children: "L’Avenir a du bon"
                        })
                    }, function() {
                        return (0, o.jsx)(o.Fragment, {
                            children: "lbc" === es.R.shortName && (0, o.jsx)("a", {
                                href: "https://www.lebonobservatoire.fr",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                title: "Le bon observatoire",
                                children: "Le bon observatoire"
                            })
                        })
                    }, function() {
                        return (0, o.jsx)("a", {
                            href: "https://presse.leboncoincorporate.com/",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: "Espace presse",
                            children: "Espace presse"
                        })
                    }]
                },
                ed = (0, i.cx)("w-[calc(50%-(var(--spacing-md)/2))]"),
                em = {
                    title: "Nos applications",
                    items: [function() {
                        return (0, o.jsxs)("div", {
                            className: "flex flex-wrap justify-between gap-md",
                            children: [(0, o.jsx)("a", {
                                className: ed,
                                rel: "nofollow noopener noreferrer",
                                href: "https://itunes.apple.com/fr/app/leboncoin/id484115113",
                                title: "T\xe9l\xe9charger l’application iOS",
                                target: "_blank",
                                children: (0, o.jsx)(ee.Z, {
                                    offset: 700,
                                    children: (0, o.jsx)(el.Z, {
                                        src: ei,
                                        layout: "responsive",
                                        alt: "T\xe9l\xe9charger l’application iOS"
                                    })
                                })
                            }), (0, o.jsx)("a", {
                                className: ed,
                                rel: "nofollow noopener noreferrer",
                                href: "https://play.google.com/store/apps/details?id=fr.leboncoin",
                                title: "T\xe9l\xe9charger l’application Android",
                                target: "_blank",
                                children: (0, o.jsx)(ee.Z, {
                                    offset: 700,
                                    children: (0, o.jsx)(el.Z, {
                                        src: ea,
                                        layout: "responsive",
                                        alt: "T\xe9l\xe9charger l’application Android"
                                    })
                                })
                            }), (0, o.jsx)("a", {
                                className: ed,
                                rel: "nofollow noopener noreferrer",
                                href: "https://appgallery.cloud.huawei.com/ag/n/app/C101705887?channelId=leboncoin.fr&id=061f09a725194fdfbb58352c03b2db7b&s=CD1AE1B024AB543E1F77EA6EC83A69D1C085AD4FD562DACAC9B0EFE131499C0A&detailType=0&v=&callType=AGDLINK&installType=0000",
                                title: "T\xe9l\xe9charger l’application sur l’AppGallery",
                                target: "_blank",
                                children: (0, o.jsx)(ee.Z, {
                                    offset: 700,
                                    children: (0, o.jsx)(el.Z, {
                                        src: eo,
                                        layout: "responsive",
                                        alt: "T\xe9l\xe9charger l’application sur l’AppGallery"
                                    })
                                })
                            })]
                        })
                    }]
                },
                ep = {
                    title: "Nos solutions pros",
                    items: [function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "https://leboncoinpublicite.fr/",
                            title: "Publicit\xe9",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            "data-qa-id": "footer_pub_link",
                            onClick: D,
                            children: "Publicit\xe9"
                        })
                    }, function() {
                        return (0, o.jsx)("a", {
                            href: "https://leboncoinsolutionspro.fr/immobilier",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: "Professionnels de l’immobilier",
                            "data-qa-id": "footer_real_estate_link",
                            onClick: S,
                            children: "Professionnels de l’immobilier"
                        })
                    }, function() {
                        return (0, o.jsx)("a", {
                            href: "https://leboncoinsolutionspro.fr/emploi",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: "Vos recrutements",
                            "data-qa-id": "footer_recruitment_link",
                            onClick: B,
                            children: "Vos recrutements"
                        })
                    }, function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "https://leboncoinsolutionspro.fr/automobile",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: "Professionnels de l'auto",
                            "data-qa-id": "footer_auto_link",
                            onClick: U,
                            children: "Professionnels de l’auto"
                        })
                    }, function() {
                        return (0, o.jsx)("a", {
                            href: "https://leboncoinsolutionspro.fr/location-de-vacances",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: "Professionnels du tourisme",
                            "data-qa-id": "footer_holidays_link",
                            onClick: P,
                            children: "Professionnels du tourisme"
                        })
                    }, function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "https://leboncoinsolutionspro.fr/commerces-services",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            title: "Autres solutions professionnelles",
                            "data-qa-id": "footer_multicat_link",
                            onClick: M,
                            children: "Autres solutions professionnelles"
                        })
                    }, function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "proSearch",
                            params: {
                                activitySector: "tout_secteur_d_activite"
                            },
                            title: "Annuaire des professionnels",
                            "data-qa-id": "footer_pro_phonebook_link",
                            onClick: V,
                            children: "Annuaire des professionnels"
                        })
                    }, function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "/solutions-emploi/offre-emploi-tpe",
                            title: "D\xe9p\xf4t gratuit d'emploi pour les TPE",
                            "data-qa-id": "footer_jobsTPE_link",
                            onClick: W,
                            children: "D\xe9p\xf4t gratuit d’emploi pour les TPE"
                        })
                    }]
                },
                eh = {
                    title: "Des questions ?",
                    items: [function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "https://assistance.leboncoin.info/hc/fr",
                            title: "Aide",
                            onClick: R,
                            children: "Aide"
                        })
                    }, function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "DynamicLanding",
                            params: {
                                type: "service",
                                seoSlug: "paiement-securise"
                            },
                            children: "Le service de paiement s\xe9curis\xe9 et la livraison"
                        })
                    }, function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "DynamicLanding",
                            params: {
                                type: "service",
                                seoSlug: "porte-monnaie"
                            },
                            title: "Le porte-monnaie",
                            children: "Le porte-monnaie"
                        })
                    }, function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "/reservation-de-vacances/hote",
                            title: "Le service de r\xe9servation de vacances en ligne pour les h\xf4tes",
                            onClick: z,
                            children: "Le service de r\xe9servation de vacances en ligne pour les h\xf4tes"
                        })
                    }, function() {
                        return (0, o.jsx)(en(), {
                            href: "/immo/profil-locataire",
                            title: "Votre dossier de location en ligne",
                            children: "Votre dossier de location en ligne"
                        })
                    }, function() {
                        return (0, o.jsx)(er.h.Link, {
                            to: "DynamicLanding",
                            params: {
                                type: "service",
                                seoSlug: "espace-bailleur"
                            },
                            title: "Votre espace bailleur",
                            children: "Votre espace bailleur"
                        })
                    }, function() {
                        return (0, o.jsx)("a", {
                            href: "https://status.leboncoin.fr",
                            target: "_blank",
                            rel: "noopener noreferrer nofollow",
                            title: "Statut de nos services",
                            children: "Statut de nos services"
                        })
                    }]
                },
                ex = {
                    title: "Vous \xeates \xe0 l’\xe9tranger ?",
                    items: [function() {
                        return (0, o.jsx)($.ZP, {
                            listAlignement: "right",
                            listWidth: X.Z.medium.max,
                            flags: eu,
                            renderItem: function(e) {
                                var t = e.FlagIconComponent,
                                    n = e.WrapperComponent,
                                    r = e.item;
                                return (0, o.jsxs)(n, {
                                    as: "a",
                                    href: r.url,
                                    rel: "noopener",
                                    target: "_blank",
                                    title: "".concat(r.shortUrl, " - ").concat(r.countryName),
                                    onClick: r.tracking,
                                    children: [(0, o.jsx)(t, {}), r.countryName]
                                })
                            }
                        })
                    }]
                },
                eg = [
                    [ef, em], {
                        title: "Informations l\xe9gales",
                        items: [function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/cgu",
                                rel: "nofollow",
                                title: "Conditions g\xe9n\xe9rales d’utilisation",
                                onClick: y,
                                children: "Conditions g\xe9n\xe9rales d’utilisation"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/rules",
                                rel: "nofollow",
                                title: "R\xe9f\xe9rencement et classement des annonces",
                                onClick: N,
                                children: "R\xe9f\xe9rencement et classement des annonces"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                rel: "nofollow",
                                href: "/dc/cgv",
                                title: "Conditions g\xe9n\xe9rales de vente",
                                onClick: Z,
                                children: "Conditions g\xe9n\xe9rales de vente"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/cookies",
                                rel: "nofollow",
                                title: "Vie priv\xe9e / cookies",
                                onClick: T,
                                children: "Vie priv\xe9e / cookies"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/vos_droits_et_obligations",
                                rel: "nofollow",
                                title: "Vos droits et obligations",
                                onClick: L,
                                children: "Vos droits et obligations"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/avis_utilisateurs",
                                rel: "nofollow",
                                title: "Avis utilisateurs",
                                onClick: C,
                                children: "Avis utilisateurs"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/charte_de_bonne_conduite",
                                rel: "nofollow",
                                title: "Charte de bonne conduite",
                                onClick: E,
                                children: "Charte de bonne conduite"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/paiement_en_plusieurs_fois",
                                rel: "nofollow",
                                title: "Paiement en plusieurs fois",
                                onClick: I,
                                children: "Paiement en plusieurs fois"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/accessibilite",
                                rel: "nofollow",
                                title: "Accessibilit\xe9",
                                onClick: J,
                                children: "Accessibilit\xe9"
                            })
                        }]
                    },
                    ep, [eh, ex]
                ],
                e_ = [
                    [ef, em], {
                        title: "Informations l\xe9gales",
                        items: [function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/cgu",
                                rel: "nofollow",
                                title: "Conditions g\xe9n\xe9rales d’utilisation",
                                onClick: y,
                                children: "Conditions g\xe9n\xe9rales d’utilisation"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/rules",
                                rel: "nofollow",
                                title: "R\xe9f\xe9rencement et classement des annonces",
                                onClick: N,
                                children: "R\xe9f\xe9rencement et classement des annonces"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                rel: "nofollow",
                                href: "/dc/cgv_pro",
                                title: "Conditions g\xe9n\xe9rales de vente",
                                onClick: Z,
                                children: "Conditions g\xe9n\xe9rales de vente"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/cookies",
                                rel: "nofollow",
                                title: "Vie priv\xe9e / cookies",
                                onClick: T,
                                children: "Vie priv\xe9e / cookies"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/vos_droits_et_obligations",
                                rel: "nofollow",
                                title: "Vos droits et obligations",
                                onClick: L,
                                children: "Vos droits et obligations"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/avis_utilisateurs",
                                rel: "nofollow",
                                title: "Avis utilisateurs",
                                onClick: C,
                                children: "Avis utilisateurs"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/charte_de_bonne_conduite",
                                rel: "nofollow",
                                title: "Charte de bonne conduite",
                                onClick: E,
                                children: "Charte de bonne conduite"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/paiement_en_plusieurs_fois",
                                rel: "nofollow",
                                title: "Paiement en plusieurs fois",
                                onClick: I,
                                children: "Paiement en plusieurs fois"
                            })
                        }, function() {
                            return (0, o.jsx)(en(), {
                                href: "/dc/accessibilite",
                                rel: "nofollow",
                                title: "Accessibilit\xe9",
                                onClick: J,
                                children: "Accessibilit\xe9"
                            })
                        }]
                    },
                    ep, [eh, ex]
                ],
                ew = n(61148),
                eb = n(64820),
                eA = n(81595),
                ev = n(68044),
                ek = n(66414),
                ej = [function() {
                    return (0, o.jsx)("a", {
                        href: "https://www.linkedin.com/company/leboncoin",
                        target: "_blank",
                        rel: "noopener nofollow noreferrer",
                        onClick: G,
                        children: (0, o.jsx)(ew.ZP, {
                            color: "white",
                            marginRight: "small",
                            size: "x-large",
                            children: (0, o.jsx)(eA.Z, {
                                title: "LinkedIn"
                            })
                        })
                    })
                }, function() {
                    return (0, o.jsx)("a", {
                        href: "https://twitter.com/leboncoin/",
                        target: "_blank",
                        rel: "noopener nofollow noreferrer",
                        onClick: Y,
                        children: (0, o.jsx)(ew.ZP, {
                            color: "white",
                            marginRight: "small",
                            size: "x-large",
                            children: (0, o.jsx)(ek.Z, {
                                title: "twitter"
                            })
                        })
                    })
                }, function() {
                    return (0, o.jsx)("a", {
                        href: "https://www.instagram.com/leboncoin/",
                        target: "_blank",
                        rel: "noopener nofollow noreferrer",
                        onClick: Q,
                        children: (0, o.jsx)(ew.ZP, {
                            color: "white",
                            marginRight: "small",
                            size: "x-large",
                            children: (0, o.jsx)(eb.Z, {
                                title: "instagram"
                            })
                        })
                    })
                }, function() {
                    return (0, o.jsx)("a", {
                        href: "https://www.pinterest.fr/leboncoin/",
                        target: "_blank",
                        rel: "noopener nofollow noreferrer",
                        onClick: O,
                        children: (0, o.jsx)(ew.ZP, {
                            color: "white",
                            size: "x-large",
                            children: (0, o.jsx)(ev.Z, {
                                title: "pinterest"
                            })
                        })
                    })
                }],
                ey = function(e) {
                    var t = e.className,
                        n = e.source;
                    return (0, o.jsx)(o.Fragment, {
                        children: (0, o.jsx)("div", {
                            className: (0, i.cx)("grid grid-cols-4 gap-xl", t),
                            children: n.map(function(e, t) {
                                var n = Array.isArray(e) ? e : [e];
                                return (0, o.jsx)("div", {
                                    children: n.map(function(e, t) {
                                        return (0, o.jsxs)("div", {
                                            className: "mb-xl mr-lg w-full",
                                            children: [(0, o.jsx)("p", {
                                                className: (0, i.cx)("mb-lg border-b-sm border-b-outline pb-sm", "text-body-1 font-bold uppercase text-on-support"),
                                                children: e.title
                                            }), (0, o.jsx)("ul", {
                                                className: (0, i.cx)("flex flex-col gap-md", "text-body-2 text-on-support", "hover:[&_a]:underline"),
                                                children: e.items.map(function(e, t) {
                                                    return (0, o.jsx)("li", {
                                                        children: (0, o.jsx)(e, {})
                                                    }, t)
                                                })
                                            })]
                                        }, t)
                                    })
                                }, t)
                            })
                        })
                    })
                },
                eN = function(e) {
                    var t = e.className,
                        n = e.items,
                        r = e.prefix;
                    return (0, o.jsxs)("div", {
                        className: (0, i.cx)("flex items-center justify-end [&_a]:flex", t),
                        children: [r && (0, o.jsx)("span", {
                            className: "hidden custom:mr-md custom:block",
                            children: r
                        }), n.map(function(e, t) {
                            return (0, o.jsx)(e, {}, t)
                        })]
                    })
                },
                eC = function(e) {
                    var t = e.minimized,
                        n = (0, a.C)(function(e) {
                            return (0, s._y)(e.user)
                        }),
                        r = "leboncoin";
                    return (0, o.jsx)("footer", {
                        className: (0, i.cx)("mx-auto bg-surface-inverse px-xl py-xl", "text-body-1 text-on-surface-inverse", "lg:px-2xl lg:py-xl"),
                        children: (0, o.jsxs)("div", {
                            className: "mx-auto max-w-page-max",
                            children: [!t && (0, o.jsx)(ey, {
                                source: n ? e_ : eg,
                                className: "hidden custom:grid"
                            }), !t && K && (0, o.jsx)(_, {
                                items: K,
                                prefix: r,
                                className: "hidden custom:block"
                            }), (0, o.jsxs)("div", {
                                className: (0, i.cx)("flex items-center justify-between [&>*]:flex-1"),
                                children: [(0, o.jsx)(x, {
                                    brandName: r,
                                    startYear: 2006
                                }), (0, o.jsx)(h, {}), !t && (0, o.jsx)(eN, {
                                    className: "hidden custom:flex",
                                    items: ej,
                                    prefix: "Retrouvez-nous sur"
                                })]
                            })]
                        })
                    })
                }
        },
        63941: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return D
                }
            });
            var r = n(72253),
                o = n(14932),
                i = n(47702),
                s = n(82729),
                a = n(85893),
                l = n(16678);
            n(67294);
            var c = n(19181),
                u = n(29107),
                f = n(89271),
                d = n(57327),
                m = n(89755),
                p = n.n(m),
                h = "data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgNzk5IDc2MSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiA+PHBhdGggZD0iTTc0NyAyOTAgSDQ1NCBMNDAwIDAgbC05NCAyOTAgTDAgMjkwIGwyNDcgMTc5IEwxNTIgNzYxIGwyNDctMTc5IEw2NDcgNzYxIEw1NzQgNTM2IEw0MDAgNTgxIEw1NTIgNDcwIiBmaWxsPSJ3aGl0ZSIgLz48L3N2Zz4=",
                x = function(e) {
                    var t = e.textColor,
                        n = e.logoColor;
                    return (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("div", {
                            className: (0, u.cx)(["flex", "mr-sm", "w-[16px] sm:w-[18px]"]),
                            children: "green" === (void 0 === n ? "green" : n) ? (0, a.jsx)(p(), {
                                src: "data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgNzk5Ljg5IDc2MSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiA+PHBhdGggZD0iTTc5OSAyOTBINDk0TDQwMCAwbC05NCAyOTBMMCAyOTBsMjQ3IDE3OUwxNTIgNzYxbDI0Ny0xNzlMNjQ3IDc2MWwtOTQtMjkweiIgZmlsbD0iIzAwYjY3YSIvPjxwYXRoIGQ9Ik01NzQgNTM2bC0yMS02NS0xNTIgMTEweiIgZmlsbD0iIzAwNTEyOCIvPjwvc3ZnPg==",
                                "data-test-id": "TrustpilotStar",
                                width: 18,
                                height: 18,
                                alt: ""
                            }) : (0, a.jsx)(p(), {
                                src: h,
                                "data-test-id": "TrustpilotStarWhite",
                                width: 18,
                                height: 18,
                                alt: ""
                            })
                        }), (0, a.jsx)(f.Z, {
                            color: t,
                            variant: "body",
                            style: {
                                fontWeight: "500"
                            },
                            children: "Trustpilot"
                        })]
                    })
                },
                g = "#00b67a";

            function _() {
                var e = (0, s._)(["\n    z-index: ", ";\n  "]);
                return _ = function() {
                    return e
                }, e
            }
            var w = (0, c.default)("div").withConfig({
                    componentId: "sc-ef9c235-0"
                })(function(e) {
                    var t = e.fillPourcentage;
                    return "\n  position: relative;\n  display: flex;\n  align-items : center;\n  justify-content: center;\n  width: 15px;\n  height: 15px;\n  background-color: ".concat("#dcdce6", ";\n  margin-right: 1px;\n  &:before{\n    content: '';\n    position: absolute;\n    background: ").concat(g, ";\n    top: 0; bottom: 0;\n    left: 0; \n    width: ").concat(t, "%;\n  }\n")
                }),
                b = (0, c.default)(p()).withConfig({
                    componentId: "sc-ef9c235-1"
                })(function(e) {
                    var t = e.theme;
                    return (0, c.css)(_(), t.zIndices.raised)
                }),
                A = function(e) {
                    var t = e.fillPourcentage,
                        n = void 0 === t ? 100 : t;
                    return (0, a.jsx)(w, {
                        fillPourcentage: n,
                        children: (0, a.jsx)(b, {
                            alt: "Etoile de notation Trustpilot",
                            "data-test-id": "".concat(n, "star"),
                            src: h,
                            width: 15,
                            height: 15
                        })
                    })
                },
                v = n(65968),
                k = n.n(v),
                j = function(e) {
                    var t = e.trustInfo,
                        n = e.textColor,
                        r = (0, d.$G)("components/trustpilot").t,
                        o = function(e) {
                            switch (!0) {
                                case e > .7:
                                    return 100;
                                case e < .3:
                                    return 0;
                                default:
                                    return 50
                            }
                        },
                        i = t.number_of_reviews.total;
                    return (0, a.jsxs)("div", {
                        className: (0, u.cx)(["hidden custom:flex", "items-baseline justify-center", "h-full w-full"]),
                        children: [(0, a.jsx)(f.Z, {
                            className: k().Spaced,
                            color: n,
                            variant: "largeImportant",
                            children: t.score.trust_score > 4.2 ? r("trustpilot.score-excellent.label", "Excellent") : r("trustpilot.score-good.label", "Bien")
                        }), (0, a.jsx)("div", {
                            className: "mr-md flex items-baseline",
                            children: Array.from([, , , , , ].keys()).map(function(e) {
                                var n = o(t.score.stars - e);
                                return (0, a.jsx)(A, {
                                    fillPourcentage: n
                                }, e)
                            })
                        }), (0, a.jsx)(f.Z, {
                            className: k().Spaced,
                            color: n,
                            children: (0, a.jsx)(d.cC, {
                                i18nKey: "trustpilot.score-trust-score-total.label",
                                t: r,
                                values: {
                                    totalReviews: i
                                },
                                components: {
                                    b: (0, a.jsx)("b", {})
                                },
                                ns: "components/trustpilot",
                                defaults: "<b>{{ totalReviews }}</b> avis sur"
                            })
                        }), (0, a.jsx)("div", {
                            className: "flex h-full items-baseline",
                            children: (0, a.jsx)(x, {
                                textColor: n
                            })
                        })]
                    })
                },
                y = function(e) {
                    var t = e.trustInfo,
                        n = (0, d.$G)("components/trustpilot").t,
                        r = (t.number_of_reviews.total / 1e3).toFixed(1);
                    return (0, a.jsxs)("div", {
                        className: (0, u.cx)(["flex custom:hidden", "items-baseline", "h-full", "rounded-sm", "bg-surface"]),
                        children: [(0, a.jsx)("div", {
                            className: (0, u.cx)(["flex items-baseline", "px-md py-sm", "h-full", "rounded-l-sm", "bg-".concat(g)]),
                            children: (0, a.jsx)(x, {
                                textColor: "white",
                                logoColor: "white"
                            })
                        }), (0, a.jsx)("div", {
                            className: "px-md",
                            children: (0, a.jsx)(f.Z, {
                                color: "opacityBlack",
                                whiteSpace: "nowrap",
                                children: n("trustpilot.score-trust-score-mobile.label", {
                                    reviews: r,
                                    defaultValue: "".concat(r, "k avis")
                                })
                            })
                        })]
                    })
                },
                N = function(e) {
                    var t = e.trustInfo,
                        n = e.textColor;
                    return (0, a.jsxs)("div", {
                        className: (0, u.cx)(["flex items-baseline justify-end custom:justify-normal", "h-full w-full"]),
                        children: [(0, a.jsx)(y, {
                            trustInfo: t
                        }), (0, a.jsx)(j, {
                            trustInfo: t,
                            textColor: n
                        })]
                    })
                },
                C = function(e) {
                    var t = e.link,
                        n = e.children;
                    return t ? (0, a.jsx)("a", {
                        href: t,
                        target: "_blank",
                        rel: "noreferrer",
                        children: n
                    }) : n
                },
                E = function(e) {
                    var t = e.trustInfo,
                        n = e.textColor,
                        r = (0, d.$G)("components/trustpilot").t;
                    return (0, a.jsxs)("div", {
                        className: "flex w-full items-baseline",
                        children: [(0, a.jsx)(f.Z, {
                            className: "mr-md",
                            color: n,
                            variant: "largeImportant",
                            children: t.score.trust_score > 4.2 ? r("trustpilot.score-excellent.label", "Excellent") : r("trustpilot.score-good.label", "Bien")
                        }), (0, a.jsx)(f.Z, {
                            className: "mr-md",
                            color: n,
                            variant: "body",
                            children: r("trustpilot.score-trust-score.label", {
                                score: t.score.trust_score,
                                defaultValue: "".concat(t.score.trust_score, " sur 5")
                            })
                        }), (0, a.jsx)(x, {
                            textColor: n
                        })]
                    })
                };

            function I() {
                var e = (0, s._)(["\n  ", "\n  display: flex;\n  flex-direction: row;\n  font-family: 'Helvetica Neue', Arial, Helvetica, sans-serif;\n"]);
                return I = function() {
                    return e
                }, e
            }
            var Z = (0, c.default)("div").withConfig({
                    componentId: "sc-6eddd0a7-0"
                })(I(), (0, l.qC)(l.bK, l.Dh)),
                T = function(e) {
                    var t = e.variant,
                        n = e.trustInfo,
                        s = e.textColor,
                        l = e.link,
                        c = (0, i._)(e, ["variant", "trustInfo", "textColor", "link"]);
                    return (0, a.jsx)(C, {
                        link: l,
                        children: (0, a.jsx)(Z, (0, o._)((0, r._)({}, c), {
                            children: (0, a.jsx)("combo" === t ? N : E, {
                                trustInfo: n,
                                textColor: s
                            })
                        }))
                    })
                };
            T.defaultProps = {
                variant: "combo"
            };
            var D = T
        },
        11390: function(e, t, n) {
            "use strict";
            n.d(t, {
                G: function() {
                    return i
                }
            });
            var r = n(16928),
                o = n(16533),
                i = function() {
                    return (0, o.W)("".concat(r.R.apiBaseUrl, "/api/trustpilot-proxy-api/v1/lbc"), {
                        method: "get"
                    })
                }
        },
        73374: function(e, t, n) {
            "use strict";
            n.d(t, {
                P: function() {
                    return r
                }
            });
            var r = function(e) {
                return !!e && "score" in e
            }
        },
        24356: function(e, t, n) {
            "use strict";
            n.d(t, {
                ES: function() {
                    return i
                },
                El: function() {
                    return s
                },
                IB: function() {
                    return p
                },
                Jr: function() {
                    return d
                },
                O0: function() {
                    return l
                },
                TC: function() {
                    return a
                },
                Vh: function() {
                    return o
                },
                YK: function() {
                    return u
                },
                Zh: function() {
                    return m
                },
                ko: function() {
                    return f
                },
                pS: function() {
                    return h
                },
                tf: function() {
                    return c
                }
            });
            var r = n(35150),
                o = {
                    name: "AVendreALouer",
                    href: "https://www.avendrealouer.fr"
                },
                i = {
                    name: "leboncoin Immobilier Neuf",
                    href: r.LEM
                },
                s = {
                    name: "L'argus",
                    href: "https://www.largus.fr"
                },
                a = {
                    name: "Agriaffaires",
                    href: "https://www.agriaffaires.com#at_medium=custom4&at_campaign=fr_aa_veh_mot_lbc_part_site-footer-autopromo-lbc_______"
                },
                l = {
                    name: "MachineryZone",
                    href: "https://www.machineryzone.fr#at_medium=custom4&at_campaign=fr_mz_veh_mot_lbc_part_site-footer-autopromo-lbc_______"
                },
                c = {
                    name: "Truckscorner",
                    href: "https://www.truckscorner.fr#at_medium=custom4&at_campaign=fr_tc_veh_mot_lbc_part_site-footer-autopromo-lbc_______"
                },
                u = {
                    name: "Locasun",
                    description: "Locasun - Les locations vacances",
                    href: "https://www.locasun.fr/"
                },
                f = {
                    name: "Locasun-vp",
                    description: "Locasun-vp - Ventes priv\xe9es de locations vacances et weekends",
                    href: "https://www.locasun-vp.fr/"
                },
                d = {
                    name: "Videdressing",
                    href: "https://www.videdressing.com/"
                },
                m = {
                    name: "LeD\xe9nicheur",
                    href: "http://www.ledenicheur.fr"
                },
                p = {
                    name: "Younited Credit",
                    href: "http://www.younited-credit.com"
                },
                h = [o, i, s, a, l, c, u, f, d, m, p]
        },
        65968: function(e) {
            e.exports = {
                Spaced: "styles_Spaced__xB1o1"
            }
        }
    }
]);