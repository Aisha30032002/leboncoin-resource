! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            l = Error().stack;
        l && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[l] = "2903c355-ca4d-4aa7-8179-d1691be4d45a", e._sentryDebugIdIdentifier = "sentry-dbid-2903c355-ca4d-4aa7-8179-d1691be4d45a")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [45905], {
        45905: function(e, l, a) {
            a.d(l, {
                Gx: function() {
                    return r
                },
                Ul: function() {
                    return O
                },
                wL: function() {
                    return o
                }
            });
            var u, v = a(4942),
                o = Object.freeze({
                    __proto__: null,
                    SELECTED_ADS_FOR_DELETION: "selectedAdsForDeletion"
                }),
                r = Object.freeze({
                    __proto__: null,
                    HOLIDAYS_AD_ACTIVE: 1,
                    HOLIDAYS_AD_DISABLED: 0,
                    HOLIDAYS_TYPE_BOOKING_ACCEPTED: "booking_accepted",
                    HOLIDAYS_TYPE_BOOKING_PENDING: "booking_pending",
                    HOLIDAYS_TYPE_OPEN: "open",
                    HOLIDAYS_TYPE_CLOSED: "closed",
                    HOLIDAYS_TYPE_FIXED: "fixed",
                    HOLIDAYS_TYPE_UNAVAILABLE: "unavailable",
                    HOLIDAYS_TYPE_BOOKING_VALIDATED: "bookingValidated",
                    HOLIDAYS_TYPE_BOOKING_WAITING: "bookingWaiting",
                    HOLIDAYS_TYPE_NIGHT: "night",
                    HOLIDAYS_TYPE_WEEK: "week",
                    HOLIDAYS_BOOKING_BOOKED: "booked",
                    HOLIDAYS_BOOKING_CANCEL: "cancelled",
                    HOLIDAYS_BOOKING_DONE: "done",
                    HOLIDAYS_BOOKING_WAITING: "waiting",
                    HOLIDAYS_STATUS_ISCANCELBYHOST: 15
                }),
                s = {
                    DEAL: "DEAL",
                    OFFER: "OFFER"
                },
                i = Object.values(s),
                t = {
                    SALES: "SALES",
                    PURCHASES: "PURCHASES"
                },
                c = Object.values(t),
                _ = {
                    FACE_TO_FACE: "face_to_face",
                    DISTANCE: "distance",
                    MONDIAL_RELAY: "mondial_relay",
                    COLISSIMO: "colissimo",
                    COURRIER_SUIVI: "courrier_suivi",
                    CLICK_AND_COLLECT: "click_and_collect",
                    SHOP2SHOP: "shop2shop",
                    DHL: "dhl"
                },
                n = Object.values(_),
                h = [_.COLISSIMO, _.MONDIAL_RELAY, _.COURRIER_SUIVI, _.SHOP2SHOP],
                m = {
                    SELLER: "seller",
                    BUYER: "buyer",
                    ADMIN: "admin",
                    SYSTEM: "system"
                },
                d = Object.values(m),
                p = {
                    SELLER: "seller",
                    BUYER: "buyer"
                },
                E = Object.values(p),
                A = {
                    SELLER: "seller",
                    BUYER: "buyer"
                },
                f = Object.values(A),
                x = {
                    ABORTED: {
                        value: "aborted",
                        label: "annul\xe9e",
                        step: 0
                    },
                    ACCEPTED: {
                        value: "accepted",
                        label: "en cours",
                        step: 2
                    },
                    ALERT: {
                        value: "alert",
                        label: "en cours",
                        step: 2
                    },
                    CANCELLED: {
                        value: "cancelled",
                        label: "annul\xe9e",
                        step: 0
                    },
                    CANCELLED_AND_REFUND: {
                        value: "cancelled_and_refunded",
                        label: "annul\xe9e",
                        step: 0
                    },
                    CLOSED: {
                        value: "closed",
                        label: "termin\xe9e",
                        step: 5
                    },
                    DELETED: {
                        value: "deleted",
                        label: "termin\xe9e",
                        step: 5
                    },
                    EXPIRED_KYC: {
                        value: "expired_kyc",
                        label: "termin\xe9e",
                        step: 0
                    },
                    EXPIRED_PAID: {
                        value: "expired_paid",
                        label: "termin\xe9e",
                        step: 5
                    },
                    EXPIRED_PROPOSAL: {
                        value: "expired_proposal",
                        label: "annul\xe9e",
                        step: 0
                    },
                    EXPIRED_SHIPPING_AND_REFUNDED: {
                        value: "expired_shipping_and_refunded",
                        label: "annul\xe9e",
                        step: 0
                    },
                    FROZEN_PAYOUT: {
                        value: "frozen_payout",
                        label: "en cours",
                        step: 2
                    },
                    KYC_FAILED: {
                        value: "kyc_failed",
                        label: "annul\xe9e",
                        step: 0
                    },
                    MESSAGE_ACCESS: {
                        value: "message_access",
                        label: "en cours",
                        step: 2
                    },
                    PAID: {
                        value: "paid",
                        label: "en cours",
                        step: 2
                    },
                    PAYIN_FAILED: {
                        value: "payin_failed",
                        label: "en cours",
                        step: 1
                    },
                    PAYOUT: {
                        value: "payout",
                        label: "termin\xe9e",
                        step: 5
                    },
                    PAYOUT_FAILED: {
                        value: "payout_failed",
                        label: "en cours",
                        step: 4
                    },
                    PROPOSAL: {
                        value: "proposal",
                        label: "en cours",
                        step: 1
                    },
                    RECEIVED: {
                        value: "received",
                        label: "termin\xe9e",
                        step: 5
                    },
                    REFUNDED: {
                        value: "refunded",
                        label: "termin\xe9e",
                        step: 5
                    },
                    REFUSED: {
                        value: "refused",
                        label: "annul\xe9e",
                        step: 0
                    },
                    SENDING: {
                        value: "sending",
                        label: "en cours",
                        step: 4
                    },
                    SENT: {
                        value: "sent",
                        label: "en cours",
                        step: 3
                    },
                    UNFROZEN_PAYOUT: {
                        value: "unfrozen_payout",
                        label: "en cours",
                        step: 2
                    },
                    WAITING_KYC: {
                        value: "waiting_kyc",
                        label: "en cours",
                        step: 0
                    },
                    WAITING_KYC_VERIF: {
                        value: "waiting_kyc_verif",
                        label: "en cours",
                        step: 0
                    },
                    WAITING_PAYIN: {
                        value: "waiting_payin",
                        label: "en cours",
                        step: 1
                    }
                },
                I = Object.values(x).map(function(e) {
                    return e.value
                }),
                S = ((0, v.Z)(u = {}, s.DEAL, {
                    request: {
                        title: "\xcates-vous s\xfbr de vouloir annuler l’offre ?",
                        text: ""
                    },
                    confirmation: {
                        title: "Confirmation d'annulation",
                        text: "L’acheteur a \xe9t\xe9 notifi\xe9. Si vous souhaitez d\xe9marrer une nouvelle transaction, vous devrez envoyer une nouvelle offre."
                    }
                }), (0, v.Z)(u, s.OFFER, {
                    request: {
                        title: "\xcates-vous s\xfbr de vouloir annuler votre offre ?",
                        text: ""
                    },
                    confirmation: {
                        title: "Confirmation d'annulation",
                        text: "Le vendeur a \xe9t\xe9 notifi\xe9. Si vous souhaitez d\xe9marrer une nouvelle transaction, vous devrez envoyer une nouvelle offre."
                    }
                }), (0, v.Z)(u, "POST_PAYIN", {
                    request: {
                        title: "\xcates-vous s\xfbr de vouloir annuler la transaction en cours ?",
                        text: "Cette action d\xe9clenchera le remboursement \xe0 l’acheteur."
                    },
                    confirmation: {
                        title: "Confirmation d’annulation",
                        text: "La transaction a bien \xe9t\xe9 annul\xe9e. L’acheteur a \xe9t\xe9 notifi\xe9 et le remboursement a \xe9t\xe9 d\xe9clench\xe9."
                    }
                }), u),
                O = Object.freeze({
                    __proto__: null,
                    TRANSACTION_TYPES: s,
                    AVAILABLE_TRANSACTION_TYPES: i,
                    DEAL_TYPES: t,
                    AVAILABLE_DEAL_TYPES: c,
                    DELIVERY: _,
                    AVAILABLE_DELIVERIES: n,
                    THIRD_PARTY_DELIVERIES: h,
                    SENDER: m,
                    AVAILABLE_SENDERS: d,
                    SHIPPING_PAYER: p,
                    AVAILABLE_SHIPPING_PAYERS: E,
                    USER_TYPE: A,
                    AVAILABLE_USER_TYPES: f,
                    DEAL_STEP: {
                        started: {
                            label: "D\xe9marr\xe9e",
                            color: "greenDark"
                        },
                        ongoing: {
                            label: "En cours",
                            color: "yellowDark"
                        },
                        received: {
                            label: "Colis re\xe7u",
                            color: "greenDark"
                        },
                        sent: {
                            label: "Colis envoy\xe9",
                            color: "greenDark"
                        },
                        done: {
                            label: "Termin\xe9e",
                            color: "greenDark"
                        },
                        cancelled: {
                            label: "Annul\xe9e",
                            color: "greyMedium"
                        },
                        blocked: {
                            label: "Suspendue",
                            color: "red"
                        },
                        refunded: {
                            label: "Rembours\xe9e",
                            color: "greyMedium"
                        }
                    },
                    PROCESSING_LABEL: "en cours",
                    ENDED_LABEL: "termin\xe9e",
                    CANCELLED_LABEL: "annul\xe9e",
                    DROPOFF_MODES: {
                        MAILBOX: "sender_mailbox",
                        PROVIDER: "provider_store"
                    },
                    DEAL_STATUS: x,
                    AVAILABLE_STATUS: I,
                    AVAILABLE_DEAL_ERRORS: {
                        ACTION_PROCESSING: "ACTION_PROCESSING",
                        DEAL_PROCESSING: "DEAL_PROCESSING",
                        DEAL_AWAITING: "DEAL_AWAITING",
                        SHIPPING_PROCESSING: "SHIPPING_PROCESSING",
                        DEFAULT: "DEFAULT"
                    },
                    AVAILABLE_OFFER_ERRORS: {
                        ERROR_DIRECT_DEAL_ALREADY_EXISTS: "ERROR_DIRECT_DEAL_ALREADY_EXISTS",
                        ERROR_DEAL_ALREADY_EXISTS: "ERROR_DEAL_ALREADY_EXISTS",
                        ERROR_OFFER_ALREADY_EXISTS: "ERROR_OFFER_ALREADY_EXISTS",
                        BUYER_OFFER_PRO_ERROR: "BUYER_OFFER_PRO_ERROR",
                        DEFAULT: "DEFAULT"
                    },
                    KYC_PENDING_CONTENT: {
                        TITLE: "V\xe9rification de votre identit\xe9 en cours",
                        BODY: "Nous proc\xe9dons actuellement \xe0 la v\xe9rification de votre identit\xe9. L’offre de vente sera envoy\xe9e \xe0 l’acheteur d\xe8s validation de vos informations."
                    },
                    P2P_ONB_DISPLAY_FROM_EMAIL_QUERY_PARAM: "email",
                    LITIGATION_REASONS: [{
                        value: "not_received_item",
                        label: "Colis non re\xe7u"
                    }, {
                        value: "not_compliant_item",
                        label: "Commande non conforme"
                    }, {
                        value: "damaged_item",
                        label: "Colis incomplet / Article(s) ab\xeem\xe9(s)"
                    }],
                    PRO_LITIGATION_REASONS: [{
                        value: "return_item",
                        label: "J’ai chang\xe9 d’avis, je ne souhaite pas garder l’article"
                    }, {
                        value: "not_compliant_item",
                        label: "L’article ne correspond pas \xe0 sa description"
                    }, {
                        value: "damaged_item",
                        label: "L’article est ab\xeem\xe9"
                    }],
                    OFFER_PRICE_THRESHOLD: 50,
                    POST_PAYIN_CANCEL_TYPE: "post_payin",
                    WORDING_CANCEL: S,
                    DEPOSIT_CONFIGURATIONS_BY_CATEGORIES: {
                        parcel_weight: {
                            0: {
                                comment: "All",
                                values: [{
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            6: {
                                comment: "\xc9quipement Auto",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            15: {
                                comment: "Informatique",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            16: {
                                comment: "Image & Son",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            17: {
                                comment: "T\xe9l\xe9phonie",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            19: {
                                comment: "Ameublement",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            20: {
                                comment: "\xc9lectrom\xe9nager",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            21: {
                                comment: "Bricolage",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            22: {
                                comment: "V\xeatements",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            23: {
                                comment: "\xc9quipement b\xe9b\xe9",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            25: {
                                comment: "DVD / Films",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            26: {
                                comment: "CD / Musique",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            27: {
                                comment: "Livres",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            29: {
                                comment: "Sports & Hobbies",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            30: {
                                comment: "Instruments de musique",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            38: {
                                comment: "Autres",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            39: {
                                comment: "D\xe9coration",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            40: {
                                comment: "Collection",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            41: {
                                comment: "Jeux & Jouets",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            42: {
                                comment: "Montres & Bijoux",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            43: {
                                comment: "Consoles & Jeux vid\xe9o",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            44: {
                                comment: "\xc9quipement Moto",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            45: {
                                comment: "Arts de la table",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            46: {
                                comment: "Linge de maison",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            47: {
                                comment: "Accessoires & Bagagerie",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            48: {
                                comment: "Vins & Gastronomie",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            50: {
                                comment: "\xc9quipement Caravaning",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            51: {
                                comment: "\xc9quipement Nautisme",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            52: {
                                comment: "Jardinage",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            53: {
                                comment: "Chaussures",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            54: {
                                comment: "V\xeatements b\xe9b\xe9",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            55: {
                                comment: "V\xe9los",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            61: {
                                comment: "Restauration - H\xf4tellerie",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            62: {
                                comment: "Fournitures de bureau",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            64: {
                                comment: "Mat\xe9riel M\xe9dical",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            76: {
                                comment: "Accessoires animaux",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            80: {
                                comment: "Mobilier Enfant",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 2e3
                            },
                            81: {
                                comment: "Accessoires t\xe9l\xe9phone & objets connect\xe9s",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            82: {
                                comment: "Tablettes et liseuses",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 2e3
                            },
                            83: {
                                comment: "Accessoires informatique",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 2e3
                            },
                            84: {
                                comment: "Jeux vid\xe9os",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            85: {
                                comment: "\xc9quipements V\xe9los",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            86: {
                                comment: "Mod\xe9lisme",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            87: {
                                comment: "Esotherisme et spiritualit\xe9",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            88: {
                                comment: "Loisirs cr\xe9atifs",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            89: {
                                comment: "Antiquit\xe9s",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            },
                            96: {
                                comment: "Papeterie & fournitures",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 2e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 500
                            }
                        },
                        available_shippings: [{
                            shipping_type: "mondial_relay",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 96],
                            max_price_in_cents: 2e5
                        }, {
                            shipping_type: "colissimo",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96],
                            max_price_in_cents: 4e4
                        }, {
                            shipping_type: "courrier_suivi",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96],
                            max_price_in_cents: 4e4
                        }, {
                            shipping_type: "shop2shop",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 96],
                            max_price_in_cents: 2e5
                        }, {
                            shipping_type: "distance",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96]
                        }, {
                            shipping_type: "face_to_face",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96]
                        }]
                    },
                    PRO_DEPOSIT_CONFIGURATIONS_BY_CATEGORIES: {
                        parcel_weight: {
                            0: {
                                comment: "All",
                                values: [{
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            6: {
                                comment: "\xc9quipement Auto",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            15: {
                                comment: "Informatique",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            16: {
                                comment: "Image & Son",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            17: {
                                comment: "T\xe9l\xe9phonie",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            19: {
                                comment: "Ameublement",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            20: {
                                comment: "\xc9lectrom\xe9nager",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            21: {
                                comment: "Bricolage",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            22: {
                                comment: "V\xeatements",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            23: {
                                comment: "\xc9quipement b\xe9b\xe9",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            25: {
                                comment: "DVD / Films",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            26: {
                                comment: "CD / Musique",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            27: {
                                comment: "Livres",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            29: {
                                comment: "Sports & Hobbies",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            30: {
                                comment: "Instruments de musique",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            38: {
                                comment: "Autres",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            39: {
                                comment: "D\xe9coration",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            40: {
                                comment: "Collection",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            41: {
                                comment: "Jeux & Jouets",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            42: {
                                comment: "Montres & Bijoux",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            43: {
                                comment: "Consoles & Jeux vid\xe9o",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            44: {
                                comment: "\xc9quipement Moto",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            45: {
                                comment: "Arts de la table",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            46: {
                                comment: "Linge de maison",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            47: {
                                comment: "Accessoires & Bagagerie",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            48: {
                                comment: "Vins & Gastronomie",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            50: {
                                comment: "\xc9quipement Caravaning",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            51: {
                                comment: "\xc9quipement Nautisme",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            52: {
                                comment: "Jardinage",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            53: {
                                comment: "Chaussures",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            54: {
                                comment: "V\xeatements b\xe9b\xe9",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            55: {
                                comment: "V\xe9los",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            61: {
                                comment: "Restauration - H\xf4tellerie",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            62: {
                                comment: "Fournitures de bureau",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 500
                            },
                            64: {
                                comment: "Mat\xe9riel M\xe9dical",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    courrier_suivi: 2e3
                                },
                                default: 1e3
                            },
                            76: {
                                comment: "Accessoires animaux",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            80: {
                                comment: "Mobilier Enfant",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            81: {
                                comment: "Accessoires t\xe9l\xe9phone & objets connect\xe9s",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            82: {
                                comment: "Tablettes et liseuses",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            83: {
                                comment: "Accessoires informatique",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            84: {
                                comment: "Jeux vid\xe9os",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            85: {
                                comment: "\xc9quipements V\xe9los",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            86: {
                                comment: "Mod\xe9lisme",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            87: {
                                comment: "Esotherisme et spiritualit\xe9",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            88: {
                                comment: "Loisirs cr\xe9atifs",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            89: {
                                comment: "Antiquit\xe9s",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            },
                            96: {
                                comment: "Papeterie & fournitures",
                                values: [{
                                    value: 100
                                }, {
                                    value: 250
                                }, {
                                    value: 500
                                }, {
                                    value: 1e3
                                }, {
                                    value: 2e3
                                }, {
                                    value: 5e3
                                }, {
                                    value: 1e4
                                }, {
                                    value: 3e4
                                }, {
                                    value: 31e3
                                }],
                                precheck_threshold: {
                                    colissimo: 3e4,
                                    courrier_suivi: 2e3,
                                    mondial_relay: 3e4,
                                    shop2shop: 2e4
                                },
                                default: 1e3
                            }
                        },
                        available_shippings: [{
                            shipping_type: "mondial_relay",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96],
                            max_price_in_cents: 2e5,
                            max_weight: 3e4
                        }, {
                            shipping_type: "colissimo",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96],
                            max_price_in_cents: 4e4,
                            max_weight: 3e4
                        }, {
                            shipping_type: "courrier_suivi",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96],
                            max_price_in_cents: 4e4,
                            max_weight: 2e3
                        }, {
                            shipping_type: "distance",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96]
                        }, {
                            shipping_type: "click_and_collect",
                            available_categories: [6, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 29, 30, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 60, 61, 62, 64, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96]
                        }]
                    }
                });
            Object.freeze({
                __proto__: null,
                FUEL: {
                    1: "Essence",
                    2: "Diesel",
                    3: "GPL",
                    4: "Electrique",
                    5: "Autre",
                    6: "Hybride"
                },
                GEARBOX: {
                    1: "Manuelle",
                    2: "Automatique"
                },
                FURNISHED: {
                    1: !0,
                    2: !1
                },
                REAL_ESTATE_TYPE: {
                    1: "Maison",
                    2: "Appartement",
                    3: "Terrain",
                    4: "Parking",
                    5: "Autre"
                },
                PARROT_USED_TYPES: {
                    withoutParrot_default: 1,
                    withoutParrot_recent: 2,
                    withoutParrot_saved: 3,
                    withParrot_parrot: 4,
                    withParrot_recent: 5,
                    withParrot_saved: 6,
                    withParrot_default: 7
                }
            })
        }
    }
]);