! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "058c29cf-d8dd-4b19-91f4-94db5c983939", e._sentryDebugIdIdentifier = "sentry-dbid-058c29cf-d8dd-4b19-91f4-94db5c983939")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [41519], {
        41519: function(e, t, r) {
            r.d(t, {
                X: function() {
                    return ei
                },
                c: function() {
                    return eu
                }
            });
            var n, a = r(67294),
                i = r.t(a, 2);
            let o = (null == globalThis ? void 0 : globalThis.document) ? a.useLayoutEffect : () => {},
                l = i["useId".toString()] || (() => void 0),
                s = 0;

            function c(e) {
                let [t, r] = a.useState(l());
                return o(() => {
                    e || r(e => null != e ? e : String(s++))
                }, [e]), e || (t ? `radix-${t}` : "")
            }
            var u = r(7171),
                d = r(59917),
                f = r(29107),
                p = r(87462);

            function h(...e) {
                return t => e.forEach(e => {
                    var r;
                    "function" == typeof(r = e) ? r(t): null != r && (r.current = t)
                })
            }

            function b(...e) {
                return (0, a.useCallback)(h(...e), e)
            }

            function m(e, t, {
                checkForDefaultPrevented: r = !0
            } = {}) {
                return function(n) {
                    if (null == e || e(n), !1 === r || !n.defaultPrevented) return null == t ? void 0 : t(n)
                }
            }

            function v(e) {
                let t = (0, a.useRef)(e);
                return (0, a.useEffect)(() => {
                    t.current = e
                }), (0, a.useMemo)(() => (...e) => {
                    var r;
                    return null === (r = t.current) || void 0 === r ? void 0 : r.call(t, ...e)
                }, [])
            }
            let y = (null == globalThis ? void 0 : globalThis.document) ? a.useLayoutEffect : () => {};
            var g = r(73935);
            let _ = e => {
                let {
                    present: t,
                    children: r
                } = e, n = function(e) {
                    var t;
                    let [r, n] = (0, a.useState)(), i = (0, a.useRef)({}), o = (0, a.useRef)(e), l = (0, a.useRef)("none"), [s, c] = (t = {
                        mounted: {
                            UNMOUNT: "unmounted",
                            ANIMATION_OUT: "unmountSuspended"
                        },
                        unmountSuspended: {
                            MOUNT: "mounted",
                            ANIMATION_END: "unmounted"
                        },
                        unmounted: {
                            MOUNT: "mounted"
                        }
                    }, (0, a.useReducer)((e, r) => {
                        let n = t[e][r];
                        return null != n ? n : e
                    }, e ? "mounted" : "unmounted"));
                    return (0, a.useEffect)(() => {
                        let e = k(i.current);
                        l.current = "mounted" === s ? e : "none"
                    }, [s]), y(() => {
                        let t = i.current,
                            r = o.current;
                        if (r !== e) {
                            let n = l.current,
                                a = k(t);
                            e ? c("MOUNT") : "none" === a || (null == t ? void 0 : t.display) === "none" ? c("UNMOUNT") : r && n !== a ? c("ANIMATION_OUT") : c("UNMOUNT"), o.current = e
                        }
                    }, [e, c]), y(() => {
                        if (r) {
                            let e = e => {
                                    let t = k(i.current),
                                        n = t.includes(e.animationName);
                                    e.target === r && n && (0, g.flushSync)(() => c("ANIMATION_END"))
                                },
                                t = e => {
                                    e.target === r && (l.current = k(i.current))
                                };
                            return r.addEventListener("animationstart", t), r.addEventListener("animationcancel", e), r.addEventListener("animationend", e), () => {
                                r.removeEventListener("animationstart", t), r.removeEventListener("animationcancel", e), r.removeEventListener("animationend", e)
                            }
                        }
                        c("ANIMATION_END")
                    }, [r, c]), {
                        isPresent: ["mounted", "unmountSuspended"].includes(s),
                        ref: (0, a.useCallback)(e => {
                            e && (i.current = getComputedStyle(e)), n(e)
                        }, [])
                    }
                }(t), i = "function" == typeof r ? r({
                    present: n.isPresent
                }) : a.Children.only(r), o = b(n.ref, i.ref);
                return "function" == typeof r || n.isPresent ? (0, a.cloneElement)(i, {
                    ref: o
                }) : null
            };

            function k(e) {
                return (null == e ? void 0 : e.animationName) || "none"
            }
            _.displayName = "Presence";
            let w = (0, a.forwardRef)((e, t) => {
                let {
                    children: r,
                    ...n
                } = e, i = a.Children.toArray(r), o = i.find(x);
                if (o) {
                    let e = o.props.children,
                        r = i.map(t => t !== o ? t : a.Children.count(e) > 1 ? a.Children.only(null) : (0, a.isValidElement)(e) ? e.props.children : null);
                    return (0, a.createElement)(E, (0, p.Z)({}, n, {
                        ref: t
                    }), (0, a.isValidElement)(e) ? (0, a.cloneElement)(e, void 0, r) : null)
                }
                return (0, a.createElement)(E, (0, p.Z)({}, n, {
                    ref: t
                }), r)
            });
            w.displayName = "Slot";
            let E = (0, a.forwardRef)((e, t) => {
                let {
                    children: r,
                    ...n
                } = e;
                return (0, a.isValidElement)(r) ? (0, a.cloneElement)(r, { ... function(e, t) {
                        let r = { ...t
                        };
                        for (let n in t) {
                            let a = e[n],
                                i = t[n],
                                o = /^on[A-Z]/.test(n);
                            o ? a && i ? r[n] = (...e) => {
                                i(...e), a(...e)
                            } : a && (r[n] = a) : "style" === n ? r[n] = { ...a,
                                ...i
                            } : "className" === n && (r[n] = [a, i].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...r
                        }
                    }(n, r.props),
                    ref: t ? h(t, r.ref) : r.ref
                }) : a.Children.count(r) > 1 ? a.Children.only(null) : null
            });
            E.displayName = "SlotClone";
            let N = ({
                children: e
            }) => (0, a.createElement)(a.Fragment, null, e);

            function x(e) {
                return (0, a.isValidElement)(e) && e.type === N
            }
            let C = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let r = (0, a.forwardRef)((e, r) => {
                        let {
                            asChild: n,
                            ...i
                        } = e, o = n ? w : t;
                        return (0, a.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, a.createElement)(o, (0, p.Z)({}, i, {
                            ref: r
                        }))
                    });
                    return r.displayName = `Primitive.${t}`, { ...e,
                        [t]: r
                    }
                }, {}),
                j = "Checkbox",
                [R, z] = function(e, t = []) {
                    let r = [],
                        n = () => {
                            let t = r.map(e => (0, a.createContext)(e));
                            return function(r) {
                                let n = (null == r ? void 0 : r[e]) || t;
                                return (0, a.useMemo)(() => ({
                                    [`__scope${e}`]: { ...r,
                                        [e]: n
                                    }
                                }), [r, n])
                            }
                        };
                    return n.scopeName = e, [function(t, n) {
                        let i = (0, a.createContext)(n),
                            o = r.length;

                        function l(t) {
                            let {
                                scope: r,
                                children: n,
                                ...l
                            } = t, s = (null == r ? void 0 : r[e][o]) || i, c = (0, a.useMemo)(() => l, Object.values(l));
                            return (0, a.createElement)(s.Provider, {
                                value: c
                            }, n)
                        }
                        return r = [...r, n], l.displayName = t + "Provider", [l, function(r, l) {
                            let s = (null == l ? void 0 : l[e][o]) || i,
                                c = (0, a.useContext)(s);
                            if (c) return c;
                            if (void 0 !== n) return n;
                            throw Error(`\`${r}\` must be used within \`${t}\``)
                        }]
                    }, function(...e) {
                        let t = e[0];
                        if (1 === e.length) return t;
                        let r = () => {
                            let r = e.map(e => ({
                                useScope: e(),
                                scopeName: e.scopeName
                            }));
                            return function(e) {
                                let n = r.reduce((t, {
                                    useScope: r,
                                    scopeName: n
                                }) => {
                                    let a = r(e),
                                        i = a[`__scope${n}`];
                                    return { ...t,
                                        ...i
                                    }
                                }, {});
                                return (0, a.useMemo)(() => ({
                                    [`__scope${t.scopeName}`]: n
                                }), [n])
                            }
                        };
                        return r.scopeName = t.scopeName, r
                    }(n, ...t)]
                }(j),
                [S, I] = R(j),
                O = (0, a.forwardRef)((e, t) => {
                    let {
                        __scopeCheckbox: r,
                        name: n,
                        checked: i,
                        defaultChecked: o,
                        required: l,
                        disabled: s,
                        value: c = "on",
                        onCheckedChange: u,
                        ...d
                    } = e, [f, h] = (0, a.useState)(null), y = b(t, e => h(e)), g = (0, a.useRef)(!1), _ = !f || !!f.closest("form"), [k = !1, w] = function({
                        prop: e,
                        defaultProp: t,
                        onChange: r = () => {}
                    }) {
                        let [n, i] = function({
                            defaultProp: e,
                            onChange: t
                        }) {
                            let r = (0, a.useState)(e),
                                [n] = r,
                                i = (0, a.useRef)(n),
                                o = v(t);
                            return (0, a.useEffect)(() => {
                                i.current !== n && (o(n), i.current = n)
                            }, [n, i, o]), r
                        }({
                            defaultProp: t,
                            onChange: r
                        }), o = void 0 !== e, l = v(r), s = (0, a.useCallback)(t => {
                            if (o) {
                                let r = "function" == typeof t ? t(e) : t;
                                r !== e && l(r)
                            } else i(t)
                        }, [o, e, i, l]);
                        return [o ? e : n, s]
                    }({
                        prop: i,
                        defaultProp: o,
                        onChange: u
                    }), E = (0, a.useRef)(k);
                    return (0, a.useEffect)(() => {
                        let e = null == f ? void 0 : f.form;
                        if (e) {
                            let t = () => w(E.current);
                            return e.addEventListener("reset", t), () => e.removeEventListener("reset", t)
                        }
                    }, [f, w]), (0, a.createElement)(S, {
                        scope: r,
                        state: k,
                        disabled: s
                    }, (0, a.createElement)(C.button, (0, p.Z)({
                        type: "button",
                        role: "checkbox",
                        "aria-checked": T(k) ? "mixed" : k,
                        "aria-required": l,
                        "data-state": P(k),
                        "data-disabled": s ? "" : void 0,
                        disabled: s,
                        value: c
                    }, d, {
                        ref: y,
                        onKeyDown: m(e.onKeyDown, e => {
                            "Enter" === e.key && e.preventDefault()
                        }),
                        onClick: m(e.onClick, e => {
                            w(e => !!T(e) || !e), _ && (g.current = e.isPropagationStopped(), g.current || e.stopPropagation())
                        })
                    })), _ && (0, a.createElement)(M, {
                        control: f,
                        bubbles: !g.current,
                        name: n,
                        value: c,
                        checked: k,
                        required: l,
                        disabled: s,
                        style: {
                            transform: "translateX(-100%)"
                        }
                    }))
                }),
                A = (0, a.forwardRef)((e, t) => {
                    let {
                        __scopeCheckbox: r,
                        forceMount: n,
                        ...i
                    } = e, o = I("CheckboxIndicator", r);
                    return (0, a.createElement)(_, {
                        present: n || T(o.state) || !0 === o.state
                    }, (0, a.createElement)(C.span, (0, p.Z)({
                        "data-state": P(o.state),
                        "data-disabled": o.disabled ? "" : void 0
                    }, i, {
                        ref: t,
                        style: {
                            pointerEvents: "none",
                            ...e.style
                        }
                    })))
                }),
                M = e => {
                    let {
                        control: t,
                        checked: r,
                        bubbles: n = !0,
                        ...i
                    } = e, o = (0, a.useRef)(null), l = function(e) {
                        let t = (0, a.useRef)({
                            value: e,
                            previous: e
                        });
                        return (0, a.useMemo)(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e])
                    }(r), s = function(e) {
                        let [t, r] = (0, a.useState)(void 0);
                        return y(() => {
                            if (e) {
                                r({
                                    width: e.offsetWidth,
                                    height: e.offsetHeight
                                });
                                let t = new ResizeObserver(t => {
                                    let n, a;
                                    if (!Array.isArray(t) || !t.length) return;
                                    let i = t[0];
                                    if ("borderBoxSize" in i) {
                                        let e = i.borderBoxSize,
                                            t = Array.isArray(e) ? e[0] : e;
                                        n = t.inlineSize, a = t.blockSize
                                    } else n = e.offsetWidth, a = e.offsetHeight;
                                    r({
                                        width: n,
                                        height: a
                                    })
                                });
                                return t.observe(e, {
                                    box: "border-box"
                                }), () => t.unobserve(e)
                            }
                            r(void 0)
                        }, [e]), t
                    }(t);
                    return (0, a.useEffect)(() => {
                        let e = o.current,
                            t = window.HTMLInputElement.prototype,
                            a = Object.getOwnPropertyDescriptor(t, "checked"),
                            i = a.set;
                        if (l !== r && i) {
                            let t = new Event("click", {
                                bubbles: n
                            });
                            e.indeterminate = T(r), i.call(e, !T(r) && r), e.dispatchEvent(t)
                        }
                    }, [l, r, n]), (0, a.createElement)("input", (0, p.Z)({
                        type: "checkbox",
                        "aria-hidden": !0,
                        defaultChecked: !T(r) && r
                    }, i, {
                        tabIndex: -1,
                        ref: o,
                        style: { ...e.style,
                            ...s,
                            position: "absolute",
                            pointerEvents: "none",
                            opacity: 0,
                            margin: 0
                        }
                    }))
                };

            function T(e) {
                return "indeterminate" === e
            }

            function P(e) {
                return T(e) ? "indeterminate" : e ? "checked" : "unchecked"
            }
            var L = r(33274);
            let $ = (0, a.forwardRef)((e, t) => a.createElement(L.f, {
                ref: t,
                ...e
            }));
            $.displayName = "VisuallyHidden";
            var q = r(74934);
            let D = (0, f.j)(["fill-current"], {
                    variants: {
                        intent: (0, q.TY)({
                            current: ["text-current"],
                            main: ["text-main"],
                            support: ["text-support"],
                            accent: ["text-accent"],
                            basic: ["text-basic"],
                            success: ["text-success"],
                            alert: ["text-alert"],
                            error: ["text-error"],
                            info: ["text-info"],
                            neutral: ["text-neutral"]
                        }),
                        size: (0, q.TY)({
                            current: ["u-current-font-size"],
                            sm: ["w-sz-16", "h-sz-16"],
                            md: ["w-sz-24", "h-sz-24"],
                            lg: ["w-sz-32", "h-sz-32"],
                            xl: ["w-sz-40", "h-sz-40"]
                        })
                    }
                }),
                U = ({
                    label: e,
                    className: t,
                    size: r = "current",
                    intent: n = "current",
                    children: i,
                    ...o
                }) => {
                    let l = a.Children.only(i);
                    return a.createElement(a.Fragment, null, (0, a.cloneElement)(l, {
                        className: D({
                            className: t,
                            size: r,
                            intent: n
                        }),
                        "data-spark-component": "icon",
                        "aria-hidden": "true",
                        focusable: "false",
                        ...o
                    }), e && a.createElement($, null, e))
                };
            U.displayName = "Icon";
            let V = (0, a.forwardRef)((e, t) => {
                let {
                    children: r,
                    ...n
                } = e, i = a.Children.toArray(r), o = i.find(B);
                if (o) {
                    let e = o.props.children,
                        r = i.map(t => t !== o ? t : a.Children.count(e) > 1 ? a.Children.only(null) : (0, a.isValidElement)(e) ? e.props.children : null);
                    return (0, a.createElement)(Z, (0, p.Z)({}, n, {
                        ref: t
                    }), (0, a.isValidElement)(e) ? (0, a.cloneElement)(e, void 0, r) : null)
                }
                return (0, a.createElement)(Z, (0, p.Z)({}, n, {
                    ref: t
                }), r)
            });
            V.displayName = "Slot";
            let Z = (0, a.forwardRef)((e, t) => {
                let {
                    children: r,
                    ...n
                } = e;
                return (0, a.isValidElement)(r) ? (0, a.cloneElement)(r, { ... function(e, t) {
                        let r = { ...t
                        };
                        for (let n in t) {
                            let a = e[n],
                                i = t[n],
                                o = /^on[A-Z]/.test(n);
                            o ? a && i ? r[n] = (...e) => {
                                i(...e), a(...e)
                            } : a && (r[n] = a) : "style" === n ? r[n] = { ...a,
                                ...i
                            } : "className" === n && (r[n] = [a, i].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...r
                        }
                    }(n, r.props),
                    ref: t ? function(...e) {
                        return t => e.forEach(e => {
                            var r;
                            "function" == typeof(r = e) ? r(t): null != r && (r.current = t)
                        })
                    }(t, r.ref) : r.ref
                }) : a.Children.count(r) > 1 ? a.Children.only(null) : null
            });
            Z.displayName = "SlotClone";
            let F = ({
                children: e
            }) => (0, a.createElement)(a.Fragment, null, e);

            function B(e) {
                return (0, a.isValidElement)(e) && e.type === F
            }
            let H = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let r = (0, a.forwardRef)((e, r) => {
                        let {
                            asChild: n,
                            ...i
                        } = e, o = n ? V : t;
                        return (0, a.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, a.createElement)(o, (0, p.Z)({}, i, {
                            ref: r
                        }))
                    });
                    return r.displayName = `Primitive.${t}`, { ...e,
                        [t]: r
                    }
                }, {}),
                W = (0, a.forwardRef)((e, t) => (0, a.createElement)(H.label, (0, p.Z)({}, e, {
                    ref: t,
                    onMouseDown: t => {
                        var r;
                        null === (r = e.onMouseDown) || void 0 === r || r.call(e, t), !t.defaultPrevented && t.detail > 1 && t.preventDefault()
                    }
                }))),
                Y = (0, a.forwardRef)(({
                    className: e,
                    ...t
                }, r) => a.createElement(W, {
                    ref: r,
                    "data-spark-component": "label",
                    className: (0, f.cx)("text-body-1", e),
                    ...t
                }));
            Y.displayName = "Label";
            let G = (0, a.forwardRef)(({
                className: e,
                children: t = "*",
                ...r
            }, n) => a.createElement("span", {
                ref: n,
                "data-spark-component": "label-required-indicator",
                role: "presentation",
                "aria-hidden": "true",
                className: (0, f.cx)(e, "text-caption text-on-surface/dim-3"),
                ...r
            }, t));
            G.displayName = "Label.RequiredIndicator";
            let K = Object.assign(Y, {
                RequiredIndicator: G
            });
            K.displayName = "Label", G.displayName = "Label.RequiredIndicator";
            let X = (0, a.createContext)({}),
                J = a.forwardRef(({
                    title: e,
                    fill: t = "currentColor",
                    stroke: r = "none",
                    ...n
                }, i) => a.createElement("svg", {
                    ref: i,
                    viewBox: "0 0 24 24",
                    xmlns: "http://www.w3.org/2000/svg",
                    "data-title": "Check",
                    ...e && {
                        "data-title": e
                    },
                    fill: t,
                    stroke: r,
                    ...n,
                    dangerouslySetInnerHTML: {
                        __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path d="m8.92,19.08c-.18,0-.36-.03-.53-.1s-.33-.17-.47-.31l-5.49-5.34c-.28-.28-.42-.61-.42-1s.14-.73.42-1c.28-.28.62-.41,1.02-.41s.74.14,1.05.41l4.43,4.3,10.62-10.29c.28-.28.62-.42,1.02-.43.39,0,.73.13,1.02.43.28.28.42.61.42,1s-.14.73-.42,1l-11.65,11.32c-.14.14-.3.24-.47.31-.17.07-.35.1-.53.1Z"/>'
                    }
                }));
            J.displayName = "Check";
            let Q = a.forwardRef(({
                title: e,
                fill: t = "currentColor",
                stroke: r = "none",
                ...n
            }, i) => a.createElement("svg", {
                ref: i,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "Minus",
                ...e && {
                    "data-title": e
                },
                fill: t,
                stroke: r,
                ...n,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m2,12c0-.62.45-1.12,1-1.12h18c.55,0,1,.5,1,1.12s-.45,1.12-1,1.12H3c-.55,0-1-.5-1-1.12Z"/>'
                }
            }));
            Q.displayName = "Minus";
            let ee = (0, a.forwardRef)((e, t) => a.createElement(A, {
                ref: t,
                className: "flex h-full w-full items-center justify-center text-surface",
                ...e
            }));
            ee.displayName = "CheckboxIndicator";
            let et = (0, f.j)(["h-sz-24 w-sz-24 shrink-0 items-center justify-center rounded-sm border-md bg-transparent outline-none", "spark-disabled:cursor-not-allowed spark-disabled:opacity-dim-3 spark-disabled:hover:ring-0", "focus-visible:u-ring", "hover:border-main-container hover:ring-2", "u-shadow-border-transition"], {
                    variants: {
                        intent: (0, q.TY)({
                            main: ["spark-state-unchecked:border-outline", "spark-state-indeterminate:border-main spark-state-indeterminate:bg-main", "spark-state-checked:border-main spark-state-checked:bg-main"],
                            support: ["spark-state-unchecked:border-outline", "spark-state-indeterminate:border-support spark-state-indeterminate:bg-support", "spark-state-checked:border-support spark-state-checked:bg-support"],
                            accent: ["spark-state-unchecked:border-outline", "spark-state-indeterminate:border-accent spark-state-indeterminate:bg-accent", "spark-state-checked:border-accent spark-state-checked:bg-accent"],
                            basic: ["spark-state-unchecked:border-outline", "spark-state-indeterminate:border-basic spark-state-indeterminate:bg-basic", "spark-state-checked:border-basic spark-state-checked:bg-basic"],
                            success: ["spark-state-unchecked:border-success", "spark-state-indeterminate:border-success spark-state-indeterminate:bg-success", "spark-state-checked:border-success spark-state-checked:bg-success"],
                            alert: ["spark-state-unchecked:border-alert", "spark-state-indeterminate:border-alert spark-state-indeterminate:bg-alert", "spark-state-checked:border-alert spark-state-checked:bg-alert"],
                            error: ["spark-state-unchecked:border-error", "spark-state-indeterminate:border-error spark-state-indeterminate:bg-error", "spark-state-checked:border-error spark-state-checked:bg-error"],
                            info: ["spark-state-unchecked:border-info", "spark-state-indeterminate:border-info spark-state-indeterminate:bg-info", "spark-state-checked:border-info spark-state-checked:bg-info"],
                            neutral: ["spark-state-unchecked:border-neutral", "spark-state-indeterminate:border-neutral spark-state-indeterminate:bg-neutral", "spark-state-checked:border-neutral spark-state-checked:bg-neutral"]
                        })
                    },
                    defaultVariants: {
                        intent: "basic"
                    }
                }),
                er = (0, a.forwardRef)(({
                    className: e,
                    icon: t = a.createElement(J, null),
                    indeterminateIcon: r = a.createElement(Q, null),
                    intent: n,
                    checked: i,
                    ...o
                }, l) => a.createElement(O, {
                    ref: l,
                    className: et({
                        intent: n,
                        className: e
                    }),
                    checked: i,
                    ...o
                }, a.createElement(ee, null, a.createElement(U, {
                    size: "sm"
                }, "indeterminate" === i ? r : t))));
            er.displayName = "CheckboxInput";
            let en = (0, f.j)("grow", {
                    variants: {
                        disabled: {
                            true: ["text-neutral/dim-2", "cursor-not-allowed"],
                            false: ["cursor-pointer"]
                        }
                    },
                    defaultVariants: {
                        disabled: !1
                    }
                }),
                ea = ({
                    disabled: e,
                    ...t
                }) => a.createElement(K, {
                    className: en({
                        disabled: e
                    }),
                    ...t
                });
            ea.displayName = "CheckboxLabel";
            let ei = (0, a.forwardRef)(({
                id: e,
                className: t,
                intent: r,
                checked: n,
                value: i,
                disabled: o,
                onCheckedChange: l,
                children: s,
                ...p
            }, h) => {
                let b = c(e),
                    m = c(),
                    v = (0, u.H)(),
                    y = (0, a.useContext)(X),
                    g = (0, a.useRef)(),
                    _ = (0, d.qq)(h, g),
                    k = i ? y.value ? .includes(i) : n,
                    {
                        id: w,
                        name: E,
                        isInvalid: N,
                        isRequired: x,
                        description: C,
                        intent: j
                    } = (({
                        fieldState: e,
                        groupState: t,
                        checkboxIntent: r
                    }) => {
                        let n = e.name ? ? t.name,
                            a = e.isRequired ? ? t.isRequired,
                            i = e.state ? ? t.state,
                            o = e.isInvalid ? ? t.isInvalid,
                            l = e.id !== t.id;
                        return {
                            name: n,
                            isRequired: a,
                            isInvalid: o,
                            id: l ? e.id : void 0,
                            description: l ? e.description : void 0,
                            intent: i ? ? r ? ? t.intent
                        }
                    })({
                        fieldState: v,
                        groupState: y,
                        checkboxIntent: r
                    });
                return a.createElement("div", {
                    "data-spark-component": "checkbox",
                    className: (0, f.cx)("relative flex items-start gap-md text-body-1", t)
                }, a.createElement(er, {
                    ref: _,
                    id: w || b,
                    name: E,
                    value: i,
                    intent: j,
                    checked: k,
                    disabled: o,
                    required: x,
                    "aria-describedby": C,
                    "aria-invalid": N,
                    onCheckedChange: e => {
                        l ? .(e);
                        let t = g.current ? .value;
                        t && y.onCheckedChange && y.onCheckedChange(e, t)
                    },
                    "aria-labelledby": s ? m : v.labelId,
                    ...p
                }), s && a.createElement(ea, {
                    disabled: o,
                    htmlFor: w || b,
                    id: m
                }, s))
            });
            ei.displayName = "Checkbox";
            var eo = "u" > typeof globalThis ? globalThis : "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof self ? self : {},
                el = {
                    exports: {}
                };
            ! function(e, t) {
                var r = "__lodash_hash_undefined__",
                    n = "[object Arguments]",
                    a = "[object Array]",
                    i = "[object Boolean]",
                    o = "[object Date]",
                    l = "[object Error]",
                    s = "[object Function]",
                    c = "[object Map]",
                    u = "[object Number]",
                    d = "[object Object]",
                    f = "[object Promise]",
                    p = "[object RegExp]",
                    h = "[object Set]",
                    b = "[object String]",
                    m = "[object WeakMap]",
                    v = "[object ArrayBuffer]",
                    y = "[object DataView]",
                    g = /^\[object .+?Constructor\]$/,
                    _ = /^(?:0|[1-9]\d*)$/,
                    k = {};
                k["[object Float32Array]"] = k["[object Float64Array]"] = k["[object Int8Array]"] = k["[object Int16Array]"] = k["[object Int32Array]"] = k["[object Uint8Array]"] = k["[object Uint8ClampedArray]"] = k["[object Uint16Array]"] = k["[object Uint32Array]"] = !0, k[n] = k[a] = k[v] = k[i] = k[y] = k[o] = k[l] = k[s] = k[c] = k[u] = k[d] = k[p] = k[h] = k[b] = k[m] = !1;
                var w = "object" == typeof eo && eo && eo.Object === Object && eo,
                    E = "object" == typeof self && self && self.Object === Object && self,
                    N = w || E || Function("return this")(),
                    x = t && !t.nodeType && t,
                    C = x && e && !e.nodeType && e,
                    j = C && C.exports === x,
                    R = j && w.process,
                    z = function() {
                        try {
                            return R && R.binding && R.binding("util")
                        } catch {}
                    }(),
                    S = z && z.isTypedArray;

                function I(e) {
                    var t = -1,
                        r = Array(e.size);
                    return e.forEach(function(e, n) {
                        r[++t] = [n, e]
                    }), r
                }

                function O(e) {
                    var t = -1,
                        r = Array(e.size);
                    return e.forEach(function(e) {
                        r[++t] = e
                    }), r
                }
                var A, M, T, P = Array.prototype,
                    L = Function.prototype,
                    $ = Object.prototype,
                    q = N["__core-js_shared__"],
                    D = L.toString,
                    U = $.hasOwnProperty,
                    V = (A = /[^.]+$/.exec(q && q.keys && q.keys.IE_PROTO || "")) ? "Symbol(src)_1." + A : "",
                    Z = $.toString,
                    F = RegExp("^" + D.call(U).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                    B = j ? N.Buffer : void 0,
                    H = N.Symbol,
                    W = N.Uint8Array,
                    Y = $.propertyIsEnumerable,
                    G = P.splice,
                    K = H ? H.toStringTag : void 0,
                    X = Object.getOwnPropertySymbols,
                    J = B ? B.isBuffer : void 0,
                    Q = (M = Object.keys, T = Object, function(e) {
                        return M(T(e))
                    }),
                    ee = ex(N, "DataView"),
                    et = ex(N, "Map"),
                    er = ex(N, "Promise"),
                    en = ex(N, "Set"),
                    ea = ex(N, "WeakMap"),
                    ei = ex(Object, "create"),
                    el = eR(ee),
                    es = eR(et),
                    ec = eR(er),
                    eu = eR(en),
                    ed = eR(ea),
                    ef = H ? H.prototype : void 0,
                    ep = ef ? ef.valueOf : void 0;

                function eh(e) {
                    var t = -1,
                        r = null == e ? 0 : e.length;
                    for (this.clear(); ++t < r;) {
                        var n = e[t];
                        this.set(n[0], n[1])
                    }
                }

                function eb(e) {
                    var t = -1,
                        r = null == e ? 0 : e.length;
                    for (this.clear(); ++t < r;) {
                        var n = e[t];
                        this.set(n[0], n[1])
                    }
                }

                function em(e) {
                    var t = -1,
                        r = null == e ? 0 : e.length;
                    for (this.clear(); ++t < r;) {
                        var n = e[t];
                        this.set(n[0], n[1])
                    }
                }

                function ev(e) {
                    var t = -1,
                        r = null == e ? 0 : e.length;
                    for (this.__data__ = new em; ++t < r;) this.add(e[t])
                }

                function ey(e) {
                    var t = this.__data__ = new eb(e);
                    this.size = t.size
                }

                function eg(e, t) {
                    for (var r = e.length; r--;)
                        if (ez(e[r][0], t)) return r;
                    return -1
                }

                function e_(e) {
                    return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : K && K in Object(e) ? function(e) {
                        var t = U.call(e, K),
                            r = e[K];
                        try {
                            e[K] = void 0;
                            var n = !0
                        } catch {}
                        var a = Z.call(e);
                        return n && (t ? e[K] = r : delete e[K]), a
                    }(e) : Z.call(e)
                }

                function ek(e) {
                    return eP(e) && e_(e) == n
                }

                function ew(e, t, r, n, a, i) {
                    var o = 1 & r,
                        l = e.length,
                        s = t.length;
                    if (l != s && !(o && s > l)) return !1;
                    var c = i.get(e);
                    if (c && i.get(t)) return c == t;
                    var u = -1,
                        d = !0,
                        f = 2 & r ? new ev : void 0;
                    for (i.set(e, t), i.set(t, e); ++u < l;) {
                        var p = e[u],
                            h = t[u];
                        if (n) var b = o ? n(h, p, u, t, e, i) : n(p, h, u, e, t, i);
                        if (void 0 !== b) {
                            if (b) continue;
                            d = !1;
                            break
                        }
                        if (f) {
                            if (! function(e, t) {
                                    for (var r = -1, n = null == e ? 0 : e.length; ++r < n;)
                                        if (t(e[r], r, e)) return !0;
                                    return !1
                                }(t, function(e, t) {
                                    if (!f.has(t) && (p === e || a(p, e, r, n, i))) return f.push(t)
                                })) {
                                d = !1;
                                break
                            }
                        } else if (p !== h && !a(p, h, r, n, i)) {
                            d = !1;
                            break
                        }
                    }
                    return i.delete(e), i.delete(t), d
                }

                function eE(e) {
                    var t;
                    return t = function(e) {
                        return null != e && eM(e.length) && !eA(e) ? function(e, t) {
                            var r, n, a = eI(e),
                                i = !a && eS(e),
                                o = !a && !i && eO(e),
                                l = !a && !i && !o && eL(e),
                                s = a || i || o || l,
                                c = s ? function(e, t) {
                                    for (var r = -1, n = Array(e); ++r < e;) n[r] = t(r);
                                    return n
                                }(e.length, String) : [],
                                u = c.length;
                            for (var d in e) !U.call(e, d) || s && ("length" == d || o && ("offset" == d || "parent" == d) || l && ("buffer" == d || "byteLength" == d || "byteOffset" == d) || (r = d, (n = (n = u) ? ? 9007199254740991) && ("number" == typeof r || _.test(r)) && r > -1 && r % 1 == 0 && r < n)) || c.push(d);
                            return c
                        }(e) : function(e) {
                            if (r = "function" == typeof(t = e && e.constructor) && t.prototype || $, e !== r) return Q(e);
                            var t, r, n = [];
                            for (var a in Object(e)) U.call(e, a) && "constructor" != a && n.push(a);
                            return n
                        }(e)
                    }(e), eI(e) ? t : function(e, t) {
                        for (var r = -1, n = t.length, a = e.length; ++r < n;) e[a + r] = t[r];
                        return e
                    }(t, eC(e))
                }

                function eN(e, t) {
                    var r, n = e.__data__;
                    return ("string" == (r = typeof t) || "number" == r || "symbol" == r || "boolean" == r ? "__proto__" !== t : null === t) ? n["string" == typeof t ? "string" : "hash"] : n.map
                }

                function ex(e, t) {
                    var r = e ? .[t];
                    return !(!eT(r) || V && V in r) && (eA(r) ? F : g).test(eR(r)) ? r : void 0
                }
                eh.prototype.clear = function() {
                    this.__data__ = ei ? ei(null) : {}, this.size = 0
                }, eh.prototype.delete = function(e) {
                    var t = this.has(e) && delete this.__data__[e];
                    return this.size -= t ? 1 : 0, t
                }, eh.prototype.get = function(e) {
                    var t = this.__data__;
                    if (ei) {
                        var n = t[e];
                        return n === r ? void 0 : n
                    }
                    return U.call(t, e) ? t[e] : void 0
                }, eh.prototype.has = function(e) {
                    var t = this.__data__;
                    return ei ? void 0 !== t[e] : U.call(t, e)
                }, eh.prototype.set = function(e, t) {
                    var n = this.__data__;
                    return this.size += this.has(e) ? 0 : 1, n[e] = ei && void 0 === t ? r : t, this
                }, eb.prototype.clear = function() {
                    this.__data__ = [], this.size = 0
                }, eb.prototype.delete = function(e) {
                    var t = this.__data__,
                        r = eg(t, e);
                    return !(r < 0) && (r == t.length - 1 ? t.pop() : G.call(t, r, 1), --this.size, !0)
                }, eb.prototype.get = function(e) {
                    var t = this.__data__,
                        r = eg(t, e);
                    return r < 0 ? void 0 : t[r][1]
                }, eb.prototype.has = function(e) {
                    return eg(this.__data__, e) > -1
                }, eb.prototype.set = function(e, t) {
                    var r = this.__data__,
                        n = eg(r, e);
                    return n < 0 ? (++this.size, r.push([e, t])) : r[n][1] = t, this
                }, em.prototype.clear = function() {
                    this.size = 0, this.__data__ = {
                        hash: new eh,
                        map: new(et || eb),
                        string: new eh
                    }
                }, em.prototype.delete = function(e) {
                    var t = eN(this, e).delete(e);
                    return this.size -= t ? 1 : 0, t
                }, em.prototype.get = function(e) {
                    return eN(this, e).get(e)
                }, em.prototype.has = function(e) {
                    return eN(this, e).has(e)
                }, em.prototype.set = function(e, t) {
                    var r = eN(this, e),
                        n = r.size;
                    return r.set(e, t), this.size += r.size == n ? 0 : 1, this
                }, ev.prototype.add = ev.prototype.push = function(e) {
                    return this.__data__.set(e, r), this
                }, ev.prototype.has = function(e) {
                    return this.__data__.has(e)
                }, ey.prototype.clear = function() {
                    this.__data__ = new eb, this.size = 0
                }, ey.prototype.delete = function(e) {
                    var t = this.__data__,
                        r = t.delete(e);
                    return this.size = t.size, r
                }, ey.prototype.get = function(e) {
                    return this.__data__.get(e)
                }, ey.prototype.has = function(e) {
                    return this.__data__.has(e)
                }, ey.prototype.set = function(e, t) {
                    var r = this.__data__;
                    if (r instanceof eb) {
                        var n = r.__data__;
                        if (!et || n.length < 199) return n.push([e, t]), this.size = ++r.size, this;
                        r = this.__data__ = new em(n)
                    }
                    return r.set(e, t), this.size = r.size, this
                };
                var eC = X ? function(e) {
                        return null == e ? [] : function(e, t) {
                            for (var r = -1, n = null == e ? 0 : e.length, a = 0, i = []; ++r < n;) {
                                var o = e[r];
                                t(o, r, e) && (i[a++] = o)
                            }
                            return i
                        }(X(e = Object(e)), function(t) {
                            return Y.call(e, t)
                        })
                    } : function() {
                        return []
                    },
                    ej = e_;

                function eR(e) {
                    if (null != e) {
                        try {
                            return D.call(e)
                        } catch {}
                        try {
                            return e + ""
                        } catch {}
                    }
                    return ""
                }

                function ez(e, t) {
                    return e === t || e != e && t != t
                }(ee && ej(new ee(new ArrayBuffer(1))) != y || et && ej(new et) != c || er && ej(er.resolve()) != f || en && ej(new en) != h || ea && ej(new ea) != m) && (ej = function(e) {
                    var t = e_(e),
                        r = t == d ? e.constructor : void 0,
                        n = r ? eR(r) : "";
                    if (n) switch (n) {
                        case el:
                            return y;
                        case es:
                            return c;
                        case ec:
                            return f;
                        case eu:
                            return h;
                        case ed:
                            return m
                    }
                    return t
                });
                var eS = ek(function() {
                        return arguments
                    }()) ? ek : function(e) {
                        return eP(e) && U.call(e, "callee") && !Y.call(e, "callee")
                    },
                    eI = Array.isArray,
                    eO = J || function() {
                        return !1
                    };

                function eA(e) {
                    if (!eT(e)) return !1;
                    var t = e_(e);
                    return t == s || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t
                }

                function eM(e) {
                    return "number" == typeof e && e > -1 && e % 1 == 0 && e <= 9007199254740991
                }

                function eT(e) {
                    var t = typeof e;
                    return null != e && ("object" == t || "function" == t)
                }

                function eP(e) {
                    return null != e && "object" == typeof e
                }
                var eL = S ? function(e) {
                    return S(e)
                } : function(e) {
                    return eP(e) && eM(e.length) && !!k[e_(e)]
                };
                e.exports = function(e, t) {
                    return function e(t, r, s, f, m) {
                        return t === r || (null != t && null != r && (eP(t) || eP(r)) ? function(e, t, r, s, f, m) {
                            var g = eI(e),
                                _ = eI(t),
                                k = g ? a : ej(e),
                                w = _ ? a : ej(t),
                                E = (k = k == n ? d : k) == d,
                                N = (w = w == n ? d : w) == d,
                                x = k == w;
                            if (x && eO(e)) {
                                if (!eO(t)) return !1;
                                g = !0, E = !1
                            }
                            if (x && !E) return m || (m = new ey), g || eL(e) ? ew(e, t, r, s, f, m) : function(e, t, r, n, a, s, d) {
                                switch (r) {
                                    case y:
                                        if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) break;
                                        e = e.buffer, t = t.buffer;
                                    case v:
                                        return !(e.byteLength != t.byteLength || !s(new W(e), new W(t)));
                                    case i:
                                    case o:
                                    case u:
                                        return ez(+e, +t);
                                    case l:
                                        return e.name == t.name && e.message == t.message;
                                    case p:
                                    case b:
                                        return e == t + "";
                                    case c:
                                        var f = I;
                                    case h:
                                        var m = 1 & n;
                                        if (f || (f = O), e.size != t.size && !m) break;
                                        var g = d.get(e);
                                        if (g) return g == t;
                                        n |= 2, d.set(e, t);
                                        var _ = ew(f(e), f(t), n, a, s, d);
                                        return d.delete(e), _;
                                    case "[object Symbol]":
                                        if (ep) return ep.call(e) == ep.call(t)
                                }
                                return !1
                            }(e, t, k, r, s, f, m);
                            if (!(1 & r)) {
                                var C = E && U.call(e, "__wrapped__"),
                                    j = N && U.call(t, "__wrapped__");
                                if (C || j) {
                                    var R = C ? e.value() : e,
                                        z = j ? t.value() : t;
                                    return m || (m = new ey), f(R, z, r, s, m)
                                }
                            }
                            return !!x && (m || (m = new ey), function(e, t, r, n, a, i) {
                                var o = 1 & r,
                                    l = eE(e),
                                    s = l.length;
                                if (s != eE(t).length && !o) return !1;
                                for (var c = s; c--;) {
                                    var u = l[c];
                                    if (!(o ? u in t : U.call(t, u))) return !1
                                }
                                var d = i.get(e);
                                if (d && i.get(t)) return d == t;
                                var f = !0;
                                i.set(e, t), i.set(t, e);
                                for (var p = o; ++c < s;) {
                                    var h = e[u = l[c]],
                                        b = t[u];
                                    if (n) var m = o ? n(b, h, u, t, e, i) : n(h, b, u, e, t, i);
                                    if (!(void 0 === m ? h === b || a(h, b, r, n, i) : m)) {
                                        f = !1;
                                        break
                                    }
                                    p || (p = "constructor" == u)
                                }
                                if (f && !p) {
                                    var v = e.constructor,
                                        y = t.constructor;
                                    v == y || !("constructor" in e) || !("constructor" in t) || "function" == typeof v && v instanceof v && "function" == typeof y && y instanceof y || (f = !1)
                                }
                                return i.delete(e), i.delete(t), f
                            }(e, t, r, s, f, m))
                        }(t, r, s, f, e, m) : t != t && r != r)
                    }(e, t)
                }
            }(el, el.exports);
            let es = (n = el.exports) && n.__esModule && Object.prototype.hasOwnProperty.call(n, "default") ? n.default : n,
                ec = (0, f.j)(["flex"], {
                    variants: {
                        orientation: {
                            vertical: ["flex-col", "gap-lg"],
                            horizontal: ["gap-xl"]
                        }
                    }
                }),
                eu = (0, a.forwardRef)(({
                    name: e,
                    value: t,
                    defaultValue: r,
                    className: n,
                    intent: i,
                    orientation: o = "vertical",
                    onCheckedChange: l,
                    children: s,
                    ...c
                }, d) => {
                    let [f, p] = function(e, t, r) {
                        let n = void 0 !== e,
                            {
                                current: i
                            } = (0, a.useRef)(n ? e : t),
                            [o, l] = (0, a.useState)(t),
                            s = n ? e : o,
                            c = (0, a.useCallback)((e, t = (e, t) => !es(e, t)) => {
                                let a = "function" != typeof e ? e : e(s);
                                t(s, a) && !n && l(a), r && r(a)
                            }, [n, s]);
                        return [s, c, n, i]
                    }(t, r), h = (0, u.H)(), b = (0, a.useRef)(l), {
                        id: m,
                        labelId: v,
                        description: y,
                        state: g,
                        isInvalid: _,
                        isRequired: k
                    } = h, w = e ? ? h.name, E = (0, a.useMemo)(() => ({
                        id: m,
                        name: w,
                        value: f,
                        intent: i,
                        state: g,
                        isInvalid: _,
                        description: y,
                        isRequired: k,
                        onCheckedChange: (e, t) => {
                            let r = f || [],
                                n = e ? [...r, t] : r.filter(e => e !== t);
                            p(n), b.current && b.current(n)
                        }
                    }), [m, w, f, i, g, _, y, k, p]);
                    return (0, a.useEffect)(() => {
                        b.current = l
                    }, [l]), a.createElement(X.Provider, {
                        value: E
                    }, a.createElement("div", {
                        ref: d,
                        className: ec({
                            className: n,
                            orientation: o
                        }),
                        role: "group",
                        "aria-labelledby": v,
                        "aria-describedby": y,
                        ...c
                    }, s))
                });
            eu.displayName = "CheckboxGroup"
        },
        59917: function(e, t, r) {
            r.d(t, {
                qq: function() {
                    return a
                }
            });
            var n = r(67294);

            function a(...e) {
                return (0, n.useMemo)(() => (function(...e) {
                    return t => {
                        e.forEach(e => (function(e, t) {
                            if (null != e) {
                                if ("function" != typeof e) try {
                                    e.current = t
                                } catch {
                                    throw Error(`Cannot assign value '${t}' to ref '${e}'`)
                                } else e(t)
                            }
                        })(e, t))
                    }
                })(...e), e)
            }
        }
    }
]);