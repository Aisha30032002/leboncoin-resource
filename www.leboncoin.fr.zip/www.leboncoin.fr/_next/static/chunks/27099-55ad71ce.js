! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "97544d2b-874e-4d34-8958-47c645a33577", e._sentryDebugIdIdentifier = "sentry-dbid-97544d2b-874e-4d34-8958-47c645a33577")
    } catch (e) {}
}();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = {
    id: "2023-11-29.104374"
};
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [27099], {
        5143: function(e, n, t) {
            t.d(n, {
                Z: function() {
                    return w
                }
            });
            var r = t(11010),
                i = t(72253),
                s = t(24043),
                a = t(70655),
                l = t(85893),
                d = t(29107),
                c = t(49477),
                o = t(67294),
                u = t(16928),
                h = t(62780),
                m = t(16533),
                f = "".concat(u.R.apiBaseUrl, "/api/insights/v1/auth/trends/tension/motors/cars/_compare"),
                g = {
                    getTension: function(e) {
                        return (0, h.ZP)(function(n) {
                            return (0, m.W)("".concat(f, "?").concat(new URLSearchParams(e)), {
                                headers: {
                                    authorization: "Bearer ".concat(n)
                                },
                                method: "get"
                            })
                        })
                    }
                },
                v = t(57327),
                b = t(68504),
                x = t(50670),
                p = t(32313),
                _ = (0, d.j)("h-xl w-xl rounded-full p-sm", {
                    variants: {
                        variant: {
                            high: "bg-success text-on-success",
                            low: "bg-error text-on-error",
                            middle: "bg-neutral/dim-2 text-on-neutral"
                        }
                    }
                }),
                w = function(e) {
                    var n, t = e.brand,
                        d = e.children,
                        u = e.model,
                        h = e.region,
                        m = (0, v.$G)("vehicle/components/market-trends").t,
                        f = (0, s._)((0, o.useState)(), 2),
                        w = f[0],
                        j = f[1];
                    if ((0, o.useEffect)(function() {
                            (0, r._)(function() {
                                var e;
                                return (0, a.__generator)(this, function(n) {
                                    switch (n.label) {
                                        case 0:
                                            return [4, g.getTension((0, i._)({
                                                brand: t,
                                                model: u
                                            }, h ? {
                                                region: h
                                            } : {})).catch(j)];
                                        case 1:
                                            if (e = n.sent()) {
                                                var r;
                                                j((r = e.data.buckets[0].value) < -33 ? "low" : r > 33 ? "high" : "middle")
                                            }
                                            return [2]
                                    }
                                })
                            })()
                        }, [t, u, h]), w instanceof Error) return d({
                        children: null,
                        loading: "failed"
                    });
                    var y = h ? m("banner.region-suffix.text", {
                            region: h
                        }) : ".",
                        N = {
                            high: m("banner.high.text"),
                            low: m("banner.less.text"),
                            middle: m("banner.middle.text")
                        };
                    return d(w ? {
                        children: (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsxs)("div", {
                                className: "mb-md flex",
                                children: [(0, l.jsx)("div", {
                                    className: "shrink-0 pr-md",
                                    children: (0, l.jsx)("div", {
                                        className: _({
                                            variant: w
                                        }),
                                        children: (n = ({
                                            high: b.B,
                                            low: x.r,
                                            middle: p.c
                                        })[w], (0, l.jsx)(c.J, {
                                            size: "sm",
                                            children: (0, l.jsx)(n, {})
                                        }))
                                    })
                                }), (0, l.jsx)("div", {
                                    className: "grow",
                                    children: (0, l.jsx)("div", {
                                        className: "text-body-1 font-semi-bold",
                                        children: (0, l.jsx)(v.cC, {
                                            i18nKey: {
                                                high: "banner.high-demand.title",
                                                low: "banner.low-demand.title",
                                                middle: "banner.middle-demand.title"
                                            }[w],
                                            ns: "vehicle/components/market-trends"
                                        })
                                    })
                                })]
                            }), (0, l.jsxs)("div", {
                                className: "text-body-2",
                                children: [(0, l.jsx)(v.cC, {
                                    components: [(0, l.jsx)("span", {
                                        className: "font-semi-bold"
                                    }, "strong")],
                                    i18nKey: "banner.data-explanation.text",
                                    ns: "vehicle/components/market-trends",
                                    values: {
                                        variant: N[w]
                                    }
                                }), y]
                            })]
                        }),
                        loading: "succeeded"
                    } : {
                        children: null,
                        loading: "pending"
                    })
                }
        },
        4993: function(e, n, t) {
            t.r(n);
            var r = t(24043),
                i = t(85893),
                s = t(61821),
                a = t(35150),
                l = t(70686),
                d = t(67294),
                c = t(76217),
                o = t(93949),
                u = t(76883),
                h = t(9221),
                m = t(38597),
                f = t(1085),
                g = t(57327),
                v = t(62938),
                b = t(5143);
            n.default = function(e) {
                var n, t, x = e.onOpenDrawer,
                    p = e.search,
                    _ = (0, v.Z)(),
                    w = (0, f.L)().categories,
                    j = c.W3.getId(p),
                    y = (0, g.$G)("vehicle/components/market-trends").t,
                    N = (0, l.kK)(_),
                    k = c.u8.get("u_car_brand", p),
                    E = c.u8.get("u_car_model", p),
                    Z = (0, l._y)(_) && j && j === a.jMr && "offer" === c.rz.getAdType(p) && k && E,
                    I = (0, d.useRef)(!1),
                    T = (0, r._)((0, d.useState)(), 2),
                    A = T[0],
                    C = T[1],
                    R = (0, d.useCallback)(function() {
                        I.current || (I.current = !0, u._q.sendUnlimitedPageLoad({
                            eventname: "search",
                            path: "market_trends",
                            store_id: N,
                            cat_id: (0, m.A)(p, w),
                            step_name: "impression_banner_results",
                            sub_cat_id: c.W3.getId(p)
                        }, !0, "ATINTERNET"))
                    }, [p, N]);
                return (0, d.useEffect)(function() {
                    Z ? A && E.includes(A) || (R(), C(E[0])) : C(void 0)
                }, [E, A, Z, R]), Z && A ? (n = k[0], t = A.split("_")[1], (0, i.jsx)(b.Z, {
                    brand: n,
                    model: t,
                    children: function(e) {
                        var r = e.children,
                            a = e.loading;
                        return "pending" === a ? (0, i.jsx)("div", {
                            className: "mb-lg",
                            children: (0, i.jsx)(o.Z, {
                                children: (0, i.jsx)("div", {
                                    className: "h-sz-160 rounded-md bg-neutral-container"
                                })
                            })
                        }) : (0, i.jsxs)("div", {
                            className: "mb-lg rounded-md !bg-info-container p-lg",
                            children: [(0, i.jsx)(h.V, {
                                className: "mb-md",
                                intent: "main",
                                children: y("banner.only-visible-pro.tag")
                            }), (0, i.jsx)("div", {
                                className: "mb-lg mt-md",
                                children: (0, i.jsxs)("div", {
                                    className: "text-headline-1",
                                    children: [n, " ", t]
                                })
                            }), "succeeded" === a ? r : (0, i.jsxs)(i.Fragment, {
                                children: [(0, i.jsx)("div", {
                                    className: "mb-lg",
                                    children: (0, i.jsx)("div", {
                                        className: "text-body-2",
                                        children: y("banner.no-estimate.text")
                                    })
                                }), (0, i.jsx)(s.z, {
                                    onClick: function() {
                                        return null == x ? void 0 : x()
                                    },
                                    children: y("banner.change-filter.cta")
                                })]
                            })]
                        })
                    }
                })) : null
            }
        },
        32313: function(e, n, t) {
            t.d(n, {
                c: function() {
                    return i
                }
            });
            var r = t(67294);
            let i = r.forwardRef(({
                title: e,
                fill: n = "currentColor",
                stroke: t = "none",
                ...i
            }, s) => r.createElement("svg", {
                ref: s,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "Activity",
                ...e && {
                    "data-title": e
                },
                fill: n,
                stroke: t,
                ...i,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m4.38,4c-.1,0-.2.04-.27.11-.07.07-.11.17-.11.27v3.46c0,.55-.45,1-1,1s-1-.45-1-1v-3.46c0-.63.25-1.24.7-1.69.45-.45,1.05-.7,1.69-.7h3.46c.55,0,1,.45,1,1s-.45,1-1,1h-3.46Zm10.77-1c0-.55.45-1,1-1h3.46c.63,0,1.24.25,1.69.7.45.45.7,1.05.7,1.69v3.46c0,.55-.45,1-1,1s-1-.45-1-1v-3.46c0-.1-.04-.2-.11-.27-.07-.07-.17-.11-.27-.11h-3.46c-.55,0-1-.45-1-1Zm-5.92,3.15c.42,0,.79.26.93.66l1.97,5.43,1.73-3.46c.16-.33.49-.54.86-.55.36-.01.71.17.9.48l1.79,2.98h2.9c.55,0,1,.45,1,1s-.45,1-1,1h-3.46c-.35,0-.68-.18-.86-.49l-1.14-1.9-1.95,3.91c-.18.36-.55.57-.95.55-.4-.02-.75-.28-.88-.66l-1.84-5.07-1.13,3c-.15.39-.52.65-.94.65h-3.46c-.55,0-1-.45-1-1s.45-1,1-1h2.77l1.83-4.89c.15-.39.52-.65.94-.65ZM3,15.15c.55,0,1,.45,1,1v3.46c0,.1.04.2.11.27.07.07.17.11.27.11h3.46c.55,0,1,.45,1,1s-.45,1-1,1h-3.46c-.63,0-1.24-.25-1.69-.7-.45-.45-.7-1.05-.7-1.69v-3.46c0-.55.45-1,1-1Zm18,0c.55,0,1,.45,1,1v3.46c0,.63-.25,1.24-.7,1.69-.45.45-1.05.7-1.69.7h-3.46c-.55,0-1-.45-1-1s.45-1,1-1h3.46c.1,0,.2-.04.27-.11.07-.07.11-.17.11-.27v-3.46c0-.55.45-1,1-1Z"/>'
                }
            }));
            i.displayName = "Activity"
        },
        68504: function(e, n, t) {
            t.d(n, {
                B: function() {
                    return i
                }
            });
            var r = t(67294);
            let i = r.forwardRef(({
                title: e,
                fill: n = "currentColor",
                stroke: t = "none",
                ...i
            }, s) => r.createElement("svg", {
                ref: s,
                viewBox: "0 0 24 24",
                xmlns: "http://www.w3.org/2000/svg",
                "data-title": "GraphArrowUp",
                ...e && {
                    "data-title": e
                },
                fill: n,
                stroke: t,
                ...i,
                dangerouslySetInnerHTML: {
                    __html: (void 0 === e ? "" : `<title>${e}</title>`) + '<path fill-rule="evenodd" d="m2.29,17.7c.39.4,1.02.4,1.41,0l4.83-4.96,2.97,3.05c.32.32.74.5,1.18.5s.87-.18,1.18-.5h0s6.12-6.28,6.12-6.28v3.21c0,.57.45,1.03,1,1.03s1-.46,1-1.03v-5.68c0-.57-.45-1.03-1-1.03h-5.54c-.55,0-1,.46-1,1.03s.45,1.03,1,1.03h3.12l-5.89,6.05-2.97-3.05c-.32-.32-.74-.5-1.18-.5s-.87.18-1.18.5h0s-5.05,5.19-5.05,5.19c-.39.4-.39,1.05,0,1.45Z"/>'
                }
            }));
            i.displayName = "GraphArrowUp"
        }
    }
]);