! function(e) {
    "use strict";

    function t(e, t, s, i) {
        return new(s || (s = Promise))((function(n, o) {
            function r(e) {
                try {
                    d(i.next(e))
                } catch (e) {
                    o(e)
                }
            }

            function a(e) {
                try {
                    d(i.throw(e))
                } catch (e) {
                    o(e)
                }
            }

            function d(e) {
                var t;
                e.done ? n(e.value) : (t = e.value, t instanceof s ? t : new s((function(e) {
                    e(t)
                }))).then(r, a)
            }
            d((i = i.apply(e, t || [])).next())
        }))
    }
    var s, i;
    "function" == typeof SuppressedError && SuppressedError;
    const n = /pbstck:debug/.test(window.location.href),
        o = !!(null === (s = window.localStorage) || void 0 === s ? void 0 : s.getItem) && null !== window.localStorage.getItem("pbstck"),
        r = `[pbstck-${null!==(i="d8cb7f0")?i:"unknown"}]`;

    function a() {
        return n || o
    }

    function d(...e) {
        a() && console.log(r, ...e)
    }

    function c(...e) {
        a() && console.warn(r, ...e)
    }

    function u(...e) {
        a() && console.error(r, ...e)
    }
    var l, b;
    ! function(e) {
        e[e.LOADED = 0] = "LOADED", e[e.FAILED = 1] = "FAILED", e[e.NOT_READY = 2] = "NOT_READY"
    }(l || (l = {})),
    function(e) {
        e.RUNNING = "running", e.NO_BID = "noBid", e.BID = "bidResponse", e.TIMEOUT = "bidTimeout"
    }(b || (b = {}));
    const p = e => e.state === b.BID,
        h = e => p(e) ? e.bidResponseId : e.bidId;
    var m, v;
    ! function(e) {
        e[e.ON_DONE = 0] = "ON_DONE", e[e.ON_SMART_MERGED = 1] = "ON_SMART_MERGED", e[e.NEVER = 2] = "NEVER"
    }(m || (m = {})),
    function(e) {
        e[e.PBJS = 0] = "PBJS", e[e.SMART_RTB = 1] = "SMART_RTB", e[e.AMAZON = 2] = "AMAZON", e[e.GAM = 3] = "GAM"
    }(v || (v = {}));
    class f extends Error {
        constructor(e) {
            super(e)
        }
    }

    function g(e, t) {
        if (!Array.isArray(e)) throw new f(null != t ? t : "Expected value to be an array, but received " + typeof e)
    }

    function y(e) {
        return "number" == typeof e && !isNaN(e)
    }

    function I(e) {
        return "string" == typeof e
    }

    function k(e, t) {
        if (!y(e)) throw new f(null != t ? t : "Expected value to be a number, but received " + typeof e)
    }

    function w(e, t) {
        if ("string" != typeof e) throw new f(null != t ? t : "Expected value to be a string, but received " + typeof e)
    }

    function A(e, t) {
        if (null == e) throw new f(null != t ? t : `Expected value to be defined, but received ${e}`)
    }

    function C(e, t) {
        if (!Array.isArray(e) || 0 === e.filter((e => void 0 !== e)).length) throw new f(null != t ? t : "Expected array to be not empty")
    }
    const R = e => "object" == typeof e && null !== e && !Array.isArray(e);

    function T(e, t) {
        if (!R(e)) throw new f(null != t ? t : `Expected value to be record, but received '${typeof e}'`)
    }
    const U = (e, t) => R(e) && t in e;
    class E {
        constructor() {
            this.storeAuctions = new Map, this.storeCoreBidResponses = new Map, this.mappingAdUnitNameAuctions = new Map, this.mappingAdUnitCodeLastAuctions = new Map
        }
        setAuction(e) {
            var t;
            this.storeAuctions.set(e.auctionId, e);
            const s = null !== (t = this.mappingAdUnitNameAuctions.get(e.adUnit.name)) && void 0 !== t ? t : [];
            s.find((t => t === e.auctionId)) || (s.push(e.auctionId), this.mappingAdUnitNameAuctions.set(e.adUnit.name, s)), this.mappingAdUnitCodeLastAuctions.set(e.adUnit.code, e.auctionId)
        }
        getAuction(e) {
            const t = this.storeAuctions.get(e);
            return A(t, `auction not found, @auctionId=${e}`), t
        }
        findBidsByAuctionId(e) {
            var t;
            return (null === (t = this.storeAuctions.get(e)) || void 0 === t ? void 0 : t.bidRequests) || []
        }
        findLastAuctionId(e) {
            return this.mappingAdUnitCodeLastAuctions.get(e.code)
        }
        findAuctionByAdUnitPath(e) {
            return Array.from(this.storeAuctions.values()).find((t => {
                var s;
                return null === (s = t.adUnit.path) || void 0 === s ? void 0 : s.endsWith(e)
            }))
        }
    }
    class S {
        constructor(e) {
            this.subscriptions = [], this.children = [], this.processingChain = e ? [...e] : []
        }
        subscribe(e, t) {
            this.subscriptions.push({
                onEvent: e,
                onError: t
            })
        }
        unsubscribe(e, t) {
            this.subscriptions = this.subscriptions.filter((s => !(s.onEvent === e && s.onError === t)))
        }
        pipe(...e) {
            const t = new S([...this.processingChain, ...e]);
            return this.children.push(t), t
        }
        next(e) {
            this.subscriptions.forEach((t => {
                try {
                    const s = this.processingChain.reduce(((e, t) => {
                        if (void 0 !== e) return t(e)
                    }), e);
                    void 0 !== s && t.onEvent(s)
                } catch (e) {
                    t.onError && t.onError(e)
                }
            })), this.children.forEach((t => t.next(e)))
        }
    }
    const B = e => {
            return [(t = ([t]) => e.test(t), e => {
                if (t(e)) return e
            }), ([, [e, ...t]]) => [e, t]];
            var t
        },
        j = [],
        N = new S;

    function O(e, t) {
        let s = 0;
        j.push((i => {
            s >= t || (s += 1, e(i))
        }))
    }

    function V(e) {
        j.forEach((t => t({
            error: e
        })))
    }

    function $(e) {
        var t;
        V({
            context: null !== (t = e.context) && void 0 !== t ? t : {},
            message: e.message
        })
    }
    const q = ["39216077", "22181265", "6943", "22815767462", "1030155", "49313688", "127208727", "21794835430", "8456"],
        x = e => {
            var t, s, i;
            if (!(null === (t = e.pubstack) || void 0 === t ? void 0 : t.adUnitName) && e.ortb2Imp)
                for (const t of q)
                    if (e.ortb2Imp.ext.data.pbadslot.startsWith(`/${t}/`)) {
                        const t = e.ortb2Imp.ext.data.pbadslot.replace(/\/$/, "").split("/").pop();
                        return t || e.code
                    }
            return null !== (i = null === (s = e.pubstack) || void 0 === s ? void 0 : s.adUnitName) && void 0 !== i ? i : e.code
        },
        F = e => {
            var t;
            return (null === (t = e.pubstack) || void 0 === t ? void 0 : t.adUnitPath) ? P(e.pubstack.adUnitPath) : e.ortb2Imp ? P(e.ortb2Imp.ext.data.pbadslot) : void 0
        },
        z = e => {
            const t = [];
            return e.forEach((e => {
                H(e).bids.forEach((e => {
                    t.some((t => t.bidder === e.bidder)) || t.push(e)
                }))
            })), t
        },
        M = e => {
            const t = {};
            return e.forEach((e => {
                const s = H(e);
                void 0 !== s.mediaTypes.native && (t.native = s.mediaTypes.native), void 0 !== s.mediaTypes.video && s.mediaTypes.video.playerSize && (t.video ? t.video.playerSize = [...t.video.playerSize, ...s.mediaTypes.video.playerSize] : t.video = s.mediaTypes.video), void 0 !== s.mediaTypes.banner && (t.banner ? (t.banner.sizes = [...t.banner.sizes, ...s.mediaTypes.banner.sizes], s.mediaTypes.banner.sizeConfig && (t.banner.sizeConfig = s.mediaTypes.banner.sizeConfig)) : t.banner = s.mediaTypes.banner)
            })), t
        },
        D = e => {
            var t, s, i;
            const n = e => "string" == typeof e ? e : Array.isArray(e) && 2 === e.length ? `${e[0]}x${e[1]}` : "unknown",
                o = new Set;
            return (e => {
                var t, s;
                return (void 0 === (null === (t = e.mediaTypes.banner) || void 0 === t ? void 0 : t.sizes) || 0 === (null === (s = e.mediaTypes.banner) || void 0 === s ? void 0 : s.sizes.length)) && void 0 === e.mediaTypes.native && void 0 === e.mediaTypes.video
            })(e) ? [] : ((null === (t = e.mediaTypes.banner) || void 0 === t ? void 0 : t.sizes) && (Array.isArray(e.mediaTypes.banner.sizes[0]) ? e.mediaTypes.banner.sizes.forEach((e => o.add(n(e)))) : o.add(n(e.mediaTypes.banner.sizes))), (null === (s = e.mediaTypes.video) || void 0 === s ? void 0 : s.playerSize) && (null === (i = e.mediaTypes.video) || void 0 === i || i.playerSize.forEach((e => o.add((e => {
                const t = n(e);
                return "unknown" === t ? "video" : `video-${t}`
            })(e))))), e.mediaTypes.native && o.add("native"), Array.from(o))
        },
        P = e => e.startsWith("/") ? e : `/${e}`,
        _ = e => {
            var t, s;
            const i = /^(adUnitPath)/;
            return (null !== (s = null === (t = e.pubstack) || void 0 === t ? void 0 : t.tags) && void 0 !== s ? s : []).filter((e => "string" == typeof e)).filter((e => e.length > 0 && e.length < 256 || i.test(e)))
        },
        W = e => {
            const t = (e => e.placementId || e.zoneId || e.siteId || void 0)(e);
            if (t) return `slot:${t}`
        },
        L = e => {
            const t = {
                hasUserId: "notAvailable",
                userIdProviderList: []
            };
            if (0 === e.length) return t;
            let s = !0;
            const i = e[0].bids[0];
            return e.forEach((e => {
                e.bids.forEach((e => {
                    if (t.userIdProviderList = t.userIdProviderList.concat(Object.keys(e.userId || {})), t.userIdProviderList = t.userIdProviderList.concat(Object.keys(e.crumbs || {})), s = s && typeof i.crumbs == typeof e.crumbs, i.crumbs && e.crumbs) {
                        const t = Object.keys(i.crumbs),
                            n = Object.keys(e.crumbs);
                        s = s && t.length === n.length && t.every((e => n.includes(e)))
                    }
                    if (s = s && typeof i.userId == typeof e.userId, i.userId && e.userId) {
                        const t = Object.keys(i.userId),
                            n = Object.keys(e.userId);
                        s = s && t.length === n.length && t.every((e => n.includes(e)))
                    }
                }))
            })), t.userIdProviderList.length > 0 && s ? t.hasUserId = "available" : t.userIdProviderList.length > 0 && !s && (t.hasUserId = "notConsistent"), t.userIdProviderList = Array.from(new Set(t.userIdProviderList)), t
        },
        G = e => {
            let t = e.map((e => e.gdprConsent)).filter((e => void 0 !== e));
            return e.length !== t.length && (t = []), t
        },
        J = e => {
            const t = {
                userConsentState: "notAvailable",
                userConsentVersion: "notAvailable"
            };
            try {
                if (0 === e.length) return t;
                const s = e.every(((e, t, s) => e.apiVersion === s[0].apiVersion)),
                    i = e.every(((e, t, s) => e.consentString === s[0].consentString));
                if (!s || !i) throw new Error("API version and Consent string must be unique within a bid request array");
                return (e => {
                    const t = {
                        userConsentState: "notAvailable",
                        userConsentVersion: "notAvailable"
                    };
                    if (void 0 === e) return t;
                    let s = !1,
                        i = !1;
                    if (e.apiVersion && 1 !== e.apiVersion) {
                        if (2 !== e.apiVersion) throw e.apiVersion > 2 ? new Error(`API version is not yet supported: ${e.apiVersion}`) : new Error(`An issue occured while identifying TCF version: ${e.apiVersion}`);
                        if (t.userConsentVersion = "tcf-v2", "boolean" == typeof e.gdprApplies && !e.gdprApplies) return Object.assign(Object.assign({}, t), {
                            userConsentState: "notApplicable"
                        });
                        if ((e => {
                                const t = e;
                                return !!(t && t.purpose && t.purpose.consents && t.vendor && t.vendor.consents)
                            })(e.vendorData)) {
                            const n = Object.values(e.vendorData.purpose.consents),
                                o = Object.values(e.vendorData.vendor.consents);
                            if (s = n.filter((e => e)).length > 0, i = o.filter((e => e)).length > 0, 0 === n.length || 0 === o.length) return Object.assign(Object.assign({}, t), {
                                userConsentState: "notAvailable"
                            })
                        }
                    } else {
                        if (t.userConsentVersion = "tcf-v1", "boolean" == typeof e.gdprApplies && !e.gdprApplies) return Object.assign(Object.assign({}, t), {
                            userConsentState: "notApplicable"
                        });
                        if ((e => {
                                const t = e;
                                return !(!t || !t.purposeConsents || !t.vendorConsents)
                            })(e.vendorData)) {
                            const n = Object.values(e.vendorData.purposeConsents),
                                o = Object.values(e.vendorData.vendorConsents);
                            if (s = n.filter((e => e)).length > 0, i = o.filter((e => e)).length > 0, 0 === n.length || 0 === o.length) return Object.assign(Object.assign({}, t), {
                                userConsentState: "notAvailable"
                            })
                        }
                    }
                    return t.userConsentState = s && i ? "accepted" : "refused", t
                })(e[0])
            } catch (e) {
                return e.context = e.context || {}, e.context.pbjs = {
                    source: "pbjs:helpers"
                }, $(e), t
            }
        },
        H = e => JSON.parse(JSON.stringify(e));

    function Q(e, t) {
        const s = function(e) {
                const t = e.split("?")[1];
                if (void 0 !== t) {
                    const e = t.split("=");
                    return {
                        key: e[0],
                        value: e[1]
                    }
                }
                return
            }(e),
            i = e.split("?")[0].startsWith("/") ? e.split("?")[0] : `/${e.split("?")[0]}`,
            n = function(e) {
                return e.getAdUnitPath().replace("//", "/")
            }(t);
        return i === (n.startsWith("/") ? n : `/${n}`) && (void 0 === s || t.getTargeting(s.key)[0] === s.value)
    }
    const Y = (e, t) => {
        const s = e.path;
        if (void 0 === t || void 0 === s) return;
        const i = t.pubads().getSlots();
        if (void 0 === i) return;
        const n = i.filter((e => Q(s, e)));
        switch (n.length) {
            case 0:
                return;
            case 1:
                return n[0];
            default:
                if (-1 !== s.indexOf("?")) return d("[pubstackGoogleTag] retrieve first slot matching the  dimension", s), n[0]; {
                    const i = t.pubads();
                    try {
                        ! function(e) {
                            if ("object" != typeof e || null === e || !("getSlotIdMap" in e) || "function" != typeof e.getSlotIdMap) throw new Error("Missing property getSlotIdMap on googletag")
                        }(i);
                        const t = i.getSlotIdMap();
                        d("[pubstackGoogleTag] get all slot map", t);
                        return t[Object.keys(t).filter((e => e.startsWith(s)))[function(e) {
                            const t = Array.from(document.querySelectorAll(`div[id*='${e.name}']`)).map((e => e.id));
                            return t.findIndex((t => t === e.code))
                        }(e)]]
                    } catch (e) {
                        return void d(`[pubstackGoogleTag] ${e}`)
                    }
                }
        }
    };
    const K = e => {
        const t = e;
        if (void 0 !== t && t.apiReady && void 0 !== t.cmd && void 0 !== t.pubads && "function" == typeof t.pubads) {
            if ("function" == typeof t.pubads().refresh) return t
        }
    };
    const X = e => {
            const t = (e => K(e.googletag))(window);
            d("[pubstackFindElementById] adUnit ", e);
            const s = Y(e, t);
            return d("[pubstackFindElementById] slot ", s), s ? document.getElementById(s.getSlotElementId()) : Z(e.code)
        },
        Z = e => {
            const t = document.getElementById(e);
            return null === t ? document.querySelector(`iframe[id*='${e}']`) : t
        };

    function ee(e) {
        const t = document.getElementsByTagName("meta");
        return Array.from(t).filter((t => t.name.includes(`${e}:`)))
    }

    function te(e, t) {
        return e.replace(`${t}:`, "")
    }
    const se = [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 59],
        ie = e => {
            if (!e) throw new Error("IllegalArgumentException");
            const t = {
                _value: [108, 98, 39, 46, 7, 187, 1, 66, 98, 184, 33, 117, 98, 149, 197, 141],
                _scratch: new Array(16)
            };

            function s() {
                let e, s;
                for (s = 0; s < 16; s++) t._scratch[s] = 0;
                for (s = 0; s < 16; s++)
                    for (let i = 0; i < 16 - s; i++) e = t._value[15 - s] * se[15 - i] + (t._scratch[15 - (s + i)] || 0), e > 255 && (s + i + 1 < 16 && (t._scratch[15 - (s + i + 1)] += e >>> 8), e -= e >>> 8 << 8), t._scratch[15 - (s + i)] = e;
                const i = t._scratch;
                t._scratch = t._value, t._value = i
            }
            return function(e) {
                let i;
                if ("string" == typeof e) {
                    const t = e.replace(/\r\n/g, "\n"),
                        s = [];
                    let n = 0;
                    for (i = 0; i < t.length; i++) {
                        const e = t.charCodeAt(i);
                        e < 128 ? s[n++] = e : e < 2048 ? (s[n++] = e >> 6 | 192, s[n++] = 63 & e | 128) : (s[n++] = e >> 12 | 224, s[n++] = e >> 6 & 63 | 128, s[n++] = 63 & e | 128)
                    }
                    e = s
                }
                for (i = 0; i < e.length; i++) t._value[15] ^= e[i], s()
            }(e), t._value.reduce(((e, t) => e + ("00" + t.toString(16)).slice(-2)), "")
        },
        ne = (e, ...t) => {
            if (0 === t.length || "" === t.join("")) throw new Error("Failed to create hash");
            return ie(t.join("")).substr(0, e)
        },
        oe = (...e) => {
            try {
                return ne(14, ...e)
            } catch (e) {
                throw new Error("Failed to create an auction Id")
            }
        },
        re = (...e) => {
            try {
                return ne(8, ...e)
            } catch (e) {
                throw new Error("Failed to create a bid Id")
            }
        },
        ae = () => ie(`${Math.random().toString(36)}${(new Date).getTime()}`),
        de = (e, t) => {
            const s = new Set;
            return e.tags.forEach((e => s.add(e))), t.tags.forEach((e => s.add(e))), s
        };
    class ce {
        constructor(e) {
            this.coreAuctionStream = new S, this.coreImpressionStream = new S, this.state = e
        }
        subscribe(e) {
            this.coreAuctionStream.subscribe(e.onAuction), this.coreImpressionStream.subscribe(e.onImpression)
        }
        pushNewImpression(e) {
            var t, s, i, n, o;
            const r = this.state.getAuction(e.auctionId),
                a = null !== (t = this.state.findLastAuctionId(r.adUnit)) && void 0 !== t ? t : "",
                d = this.state.findBidsByAuctionId(r.auctionId).filter((e => e.state === b.BID)).map((e => e)).sort(((e, t) => t.cpm - e.cpm)),
                c = (null !== (i = null === (s = d[0]) || void 0 === s ? void 0 : s.cpm) && void 0 !== i ? i : 0) - (null !== (o = null === (n = d[1]) || void 0 === n ? void 0 : n.cpm) && void 0 !== o ? o : 0);
            return this.state.storeCoreBidResponses.set(e.bidId, e), this.impressionFormatAndForward(r, e, c, a)
        }
        pushNewAuction(e) {
            var t, s;
            e.bidRequests = (t = e.bidRequests, s = "adThink", t.filter((e => e.bidderCode !== s))), 0 !== e.bidRequests.length && this.coreAuctionStream.next(e)
        }
        checkMeasurability(e) {
            return "IntersectionObserver" in window && "IntersectionObserverEntry" in window && "intersectionRatio" in window.IntersectionObserverEntry.prototype && "isIntersecting" in window.IntersectionObserverEntry.prototype && !!X(e)
        }
        impressionSasFormatAndForward(e, t) {
            const s = {
                bidId: "smart-" + ae(),
                auctionId: "smart-" + ae(),
                lastAuctionId: "smart-" + ae(),
                adUnit: t,
                bidderCode: e.bidderCode,
                cpm: e.cpm,
                currency: e.currency,
                refresh: !1,
                size: e.size,
                userConsentState: "notAvailable",
                userConsentVersion: "notAvailable",
                hasUserId: "notAvailable",
                userIdProviderList: [],
                pbjsVersion: "smart-ad-server",
                tags: new Set,
                viewabilityMeasurable: !1,
                cpmUplift: 0,
                pubstackRefresh: !1,
                pubstackRefreshRank: 0,
                customFields: e.customFields
            };
            this.coreImpressionStream.next(s)
        }
        impressionFormatAndForward(e, t, s, i) {
            const n = this.state.findBidsByAuctionId(e.auctionId),
                o = this.state.getAuction(i),
                r = G(n),
                a = this.checkMeasurability(e.adUnit),
                {
                    userConsentState: d,
                    userConsentVersion: c
                } = J(r),
                u = {
                    bidId: t.bidResponseId,
                    auctionId: e.auctionId,
                    lastAuctionId: i,
                    adUnit: e.adUnit,
                    bidderCode: t.bidderCode,
                    cpm: t.cpm,
                    currency: t.currency,
                    refresh: !1,
                    size: t.size,
                    userConsentState: d,
                    userConsentVersion: c,
                    hasUserId: e.hasUserId,
                    userIdProviderList: e.userIdProviderList,
                    pbjsVersion: e.pbjsVersion,
                    tags: de(e, t),
                    viewabilityMeasurable: a,
                    cpmUplift: s,
                    pubstackRefresh: o.pubstackRefresh,
                    pubstackRefreshRank: o.pubstackRefreshRank,
                    customFields: t.customFields
                };
            this.coreImpressionStream.next(u)
        }
    }
    const ue = e => void 0 !== e,
        le = 400,
        be = "unknown",
        pe = new Map;
    class he {
        constructor(e) {
            this.onBidResponseStream = new S, this.onAuctionEndStream = new S, this.onBidWonStream = new S, this.onBidWonFromSdkStream = new S, e && (this.pbjsConfig = e)
        }
        getAdServerCurrency() {
            var e;
            return null === (e = this.pbjsConfig) || void 0 === e ? void 0 : e.adServerCurrency
        }
        onBidResponse(e) {
            const t = oe(e.adUnitCode, e.auctionId),
                s = re(e.requestId),
                i = re(s, e.adId);
            pe.set(e.adId, s), this.onBidResponseStream.next({
                adId: e.adId,
                auctionId: t,
                bidId: s,
                bidResponseId: i,
                cpm: e.cpm,
                currency: e.currency,
                size: e.size,
                mediaType: e.mediaType,
                tags: [],
                bidderCode: e.bidderCode,
                customFields: {},
                timeToRespond: e.timeToRespond,
                adapterCode: e.adapterCode
            })
        }
        onAuctionEnd(e, t = "prebid") {
            ! function(e, t) {
                const s = [];
                if (e.forEach((e => {
                        try {
                            t(e)
                        } catch (e) {
                            s.push(e)
                        }
                    })), 0 !== s.length) {
                    const e = `forEach: Unexpected (${s.length}) errors\n${s.reduce(((e,t)=>`${e}\t- ${t.message}\n`),"")}`;
                    throw new Error(e)
                }
            }(e.adUnits.filter((t => void 0 === e.adUnitCodes || e.adUnitCodes.includes(t.code))).reduce(((e, t) => (e.find((e => t.code === e.code)) || e.push(t), e)), []), (s => {
                var i, n, o, r;
                const a = function(e, t) {
                        const s = e.adUnits.filter((e => e.code === t)),
                            i = {
                                code: t,
                                bids: z(s),
                                mediaTypes: M(s)
                            },
                            n = (e => {
                                let t;
                                return e.forEach((e => {
                                    const s = H(e);
                                    s.pubstack && 0 != Object.keys(s.pubstack).length ? t = s.pubstack : JSON.stringify(s.pubstack) !== JSON.stringify(t) && c(`Two different pubstack declaration found for a adUnitCode ${s.code}`, s.pubstack, t)
                                })), t
                            })(s);
                        n && (i.pubstack = n);
                        const o = (e => {
                            let t;
                            return e.forEach((e => {
                                const s = H(e);
                                s.ortb2Imp ? t = s.ortb2Imp : JSON.stringify(s.ortb2Imp) !== JSON.stringify(t) && c(`Two different ortb2imp declaration found for a adUnitCode ${s.code}`, s.ortb2Imp, t)
                            })), t
                        })(s);
                        o && (i.ortb2Imp = o);
                        return i
                    }(e, s.code),
                    d = (e => ({
                        code: e.code,
                        name: x(e),
                        path: F(e)
                    }))(a),
                    u = oe(a.code, e.auctionId),
                    l = e.labels || [],
                    p = (g(h = e.bidderRequests), h.length > 0 && h.every((e => A(e.bidderRequestId))), h);
                var h;
                const m = e.bidderRequests.flatMap((t => {
                        var i;
                        const n = oe(s.code, e.auctionId),
                            o = t.gdprConsent,
                            r = t.bidderCode,
                            a = null === (i = e.seatNonBids) || void 0 === i ? void 0 : i.find((e => e.seat === t.bidderCode)),
                            d = null == a ? void 0 : a.nonbid.find((e => e.impid === s.code)),
                            c = t.bids.filter((e => e.adUnitCode === s.code)).map((t => {
                                const s = re(t.bidId),
                                    i = e.bidsReceived.find((e => e.requestId === t.bidId)),
                                    a = e.noBids.find((e => e.bidId === t.bidId)),
                                    d = e.bidsRejected.find((e => e.requestId === t.bidId));
                                let c = {
                                    state: b.TIMEOUT
                                };
                                if (i) {
                                    const e = re(s, i.adId);
                                    c = {
                                        adId: i.adId,
                                        bidResponseId: e,
                                        cpm: i.cpm,
                                        currency: i.currency,
                                        size: i.size,
                                        mediaType: i.mediaType,
                                        state: b.BID,
                                        timeToRespond: i.timeToRespond
                                    }
                                } else a ? c = {
                                    state: b.NO_BID
                                } : d && (c = {
                                    state: b.NO_BID,
                                    rejectionReason: d.rejectionReason
                                });
                                return Object.assign({
                                    auctionId: n,
                                    bidId: s,
                                    gdprConsent: o,
                                    bidderCode: r,
                                    tags: [W(t.params)].filter(ue),
                                    customFields: {}
                                }, c)
                            }));
                        return d && c.push({
                            bidId: re(ae()),
                            auctionId: n,
                            gdprConsent: o,
                            bidderCode: r,
                            tags: [],
                            customFields: {
                                source: "s2s"
                            },
                            state: 101 === d.statuscode ? b.TIMEOUT : b.NO_BID
                        }), c
                    })),
                    v = {
                        auctionId: u,
                        adUnit: d,
                        refreshIndex: 0,
                        sizes: D(a),
                        userId: L(p),
                        pbjsVersion: null !== (n = null === (i = this.pbjsConfig) || void 0 === i ? void 0 : i.version) && void 0 !== n ? n : be,
                        tags: [..._(a)],
                        labels: l,
                        gracePeriod: null !== (r = null === (o = this.pbjsConfig) || void 0 === o ? void 0 : o.gracePeriod) && void 0 !== r ? r : le,
                        duration: e.auctionEnd - e.timestamp,
                        bidRequests: m,
                        timeout: e.timeout,
                        customFields: {
                            source: t
                        }
                    };
                this.onAuctionEndStream.next(v)
            }))
        }
        onBidWon(e) {
            const t = Object.assign(Object.assign({}, e), {
                auctionId: oe(e.adUnitCode, e.auctionId),
                tags: [W(e.params[0] || {})].filter(ue),
                customFields: {
                    source: "prebid"
                }
            });
            this.onBidWonStream.next(t)
        }
        onBidWonFromSdk(e) {
            const t = Object.assign(Object.assign({}, e), {
                customFields: {
                    source: "sdk"
                }
            });
            this.onBidWonFromSdkStream.next(t)
        }
    }
    class me {
        constructor() {
            this.onAdStream = new S
        }
        onAd(e) {
            const t = `/${e.formatId}`,
                s = e.formatId,
                i = {
                    bidderCode: "smart-rtb+",
                    cpm: e.cpm,
                    size: e.size,
                    adUnitName: s,
                    adUnitPathSuffix: t,
                    formatId: e.formatId,
                    customFields: {}
                };
            this.onAdStream.next(i)
        }
    }

    function ve(e) {
        if (e.includes("pubstackRefresh")) {
            const t = e.find((e => e.startsWith("pubstackRefreshRank")));
            if (void 0 !== t && t.includes(":")) {
                const e = parseInt(t.split(":")[1]) || 0;
                return e > 0 ? e : 0
            }
        }
        return 0
    }
    class fe {
        constructor() {
            this.state = new E, this.forwarder = new ce(this.state), this.fallbackCurrency = void 0
        }
        bindIntegration(e) {
            e instanceof he && (e.onBidResponseStream.subscribe((e => this.bidResponse(e)), $), e.onAuctionEndStream.subscribe((e => this.auctionDone(e)), $), e.onBidWonStream.subscribe((e => this.impression(e)), $), e.onBidWonFromSdkStream.subscribe((e => this.impressionFromSdk(e)), $), this.fallbackCurrency = e.getAdServerCurrency()), e instanceof me && e.onAdStream.subscribe((e => this.impressionSas(e)), $)
        }
        helperToBidResponse(e, t) {
            var s;
            const i = Object.assign({}, e);
            i.state = b.BID, t.tags.forEach((e => i.tags.add(e)));
            let n = t.size;
            return "native" === t.mediaType && (n = "native"), "video" === t.mediaType && (n = `video-${n}`), i.size = n, i.cpm = t.cpm, i.currency = null !== (s = t.currency) && void 0 !== s ? s : this.fallbackCurrency, i.bidResponseId = t.bidResponseId, i.bidderCode = t.bidderCode, i
        }
        bidResponse(e) {
            d("[pubstackCoreController] onBidResponse", e), e.bidderCode = "nexx360" === e.adapterCode ? "nexx360" : e.bidderCode;
            const t = {
                auctionId: e.auctionId,
                state: b.BID,
                tags: new Set(e.tags),
                customFields: e.customFields
            };
            try {
                const s = this.state.getAuction(e.auctionId);
                if (s) {
                    const i = s.bidRequests.find((t => t.bidId === e.bidId));
                    i && (s.bidRequests = s.bidRequests.filter((t => t.bidId !== e.bidId)), s.bidRequests.push(Object.assign(Object.assign(Object.assign({}, i), this.helperToBidResponse(t, e)), {
                        tags: i.tags
                    })))
                }
            } catch (e) {}
        }
        helperAuctionBidToBidResponse(e) {
            var t;
            const s = Object.assign(Object.assign({}, e), {
                tags: new Set
            });
            if (e.state === b.BID) {
                let i = e.size;
                "native" === e.mediaType && (i = "native"), "video" === e.mediaType && (i = `video-${i}`), s.size = i, s.cpm = e.cpm, s.currency = null !== (t = e.currency) && void 0 !== t ? t : this.fallbackCurrency, s.bidResponseId = e.bidResponseId, s.timeToRespond = e.timeToRespond
            }
            return e.tags.forEach((e => s.tags.add(e))), s
        }
        bidWonToCoreBidResponse(e) {
            var t, s;
            const i = re(e.requestId);
            let n = e.size;
            return "native" === e.mediaType && (n = "native"), "video" === e.mediaType && (n = `video-${n}`), {
                adId: e.adId,
                bidId: i,
                bidResponseId: re(i, e.adId),
                bidderCode: "nexx360" === e.adapterCode ? "nexx360" : null !== (t = e.bidderCode) && void 0 !== t ? t : "",
                cpm: e.cpm,
                size: n,
                state: b.BID,
                auctionId: e.auctionId,
                tags: new Set(e.tags),
                currency: null !== (s = e.currency) && void 0 !== s ? s : this.fallbackCurrency,
                customFields: e.customFields
            }
        }
        auctionDone(e) {
            d("[pubstackCoreController] onAuctionDone", e.auctionId);
            try {
                const t = (e.bidRequests || []).map(this.helperAuctionBidToBidResponse),
                    s = G(t),
                    {
                        userConsentState: i,
                        userConsentVersion: n
                    } = J(s),
                    o = {
                        auctionId: e.auctionId,
                        adUnit: e.adUnit,
                        tags: new Set(e.tags),
                        sizes: new Set(e.sizes),
                        hasUserId: e.userId.hasUserId,
                        userIdProviderList: e.userId.userIdProviderList,
                        refreshIndex: e.refreshIndex,
                        pbjsVersion: e.pbjsVersion,
                        refresh: !1,
                        pubstackRefresh: e.labels.includes("pubstackRefresh"),
                        pubstackRefreshRank: ve(e.labels),
                        userConsentState: i,
                        userConsentVersion: n,
                        bidRequests: t,
                        customFields: e.customFields,
                        duration: e.duration,
                        timeout: e.timeout,
                        state: "RUNNING"
                    };
                this.state.setAuction(o);
                const r = () => {
                    const t = this.state.getAuction(e.auctionId);
                    "FINISHED" !== t.state ? (this.forwarder.pushNewAuction(t), t.state = "FINISHED", this.state.setAuction(t)) : d("[pubstackCoreController] auction is already finished", t)
                };
                void 0 === e.gracePeriod ? r() : setTimeout((() => r()), e.gracePeriod)
            } catch (e) {
                d("[pubstackCoreController] error: cannot set auction as done because auction is not running")
            }
        }
        findBidResponseDuplicate(e) {
            const t = this.state.storeCoreBidResponses.get(e.bidId),
                s = !!t && t.bidResponseId === e.bidResponseId && t.bidderCode === e.bidderCode;
            return s && d("[pubstackCoreController] duplicate bid response found", e), s
        }
        _impression(e) {
            if ("FINISHED" === this.state.getAuction(e.auctionId).state) this.findBidResponseDuplicate(e) || this.forwarder.pushNewImpression(e);
            else {
                const t = s => {
                    s.auctionId === e.auctionId && (this.findBidResponseDuplicate(e) || this.forwarder.pushNewImpression(e), this.forwarder.coreAuctionStream.unsubscribe(t))
                };
                this.forwarder.coreAuctionStream.subscribe(t)
            }
        }
        impression(e) {
            d("[pubstackCoreController] onImpression", e);
            try {
                const t = this.bidWonToCoreBidResponse(e);
                this._impression(t)
            } catch (e) {
                d("[pubstackCoreController] error: cannot create impression", e)
            }
        }
        impressionFromSdk(e) {
            d("[pubstackCoreController] onImpression", e);
            try {
                const t = Array.from(this.state.storeAuctions.values()).find((t => t.bidRequests.filter((e => e.state === b.BID)).find((t => t.adId === e.adId))));
                if (t) {
                    const s = t.bidRequests.filter((e => e.state === b.BID)).find((t => t.adId === e.adId));
                    s.customFields = Object.assign(Object.assign({}, s.customFields), e.customFields), this._impression(s)
                }
            } catch (e) {
                d("[pubstackCoreController] error: cannot create impression", e)
            }
        }
        impressionSas(e) {
            d("[pubstackCoreController] onImpressionSas", e);
            try {
                const t = this.state.findAuctionByAdUnitPath(e.adUnitPathSuffix);
                A(t, `onSasNewBidResponse: cannot retrieve related auction, @adUnitName=${e.adUnitName}, @adUnitPath=${e.adUnitPathSuffix}`), e.currency = this.fallbackCurrency, this.forwarder.impressionSasFormatAndForward(e, t.adUnit)
            } catch (e) {
                d("[pubstackCoreController] error: cannot create impression", e)
            }
        }
        subscribe(e) {
            this.forwarder.subscribe(e)
        }
        debug() {
            const e = [];
            return this.forwarder.subscribe({
                onAuction: t => e.push(t),
                onImpression: t => e.push(t)
            }), {
                auctions: this.state,
                auctionsDone: void 0,
                adUnits: void 0,
                events: e
            }
        }
    }
    const ge = (e, t) => Object.entries(t).every((([t, s]) => typeof s == typeof {} && typeof e[t] == typeof {} ? ge(e[t], s) : typeof e[t] == typeof s)),
        ye = (e, t) => {
            if (t)
                for (let s = 0; s < 1e3; s += 1) try {
                    const i = e([], {}, [s]);
                    try {
                        if (ge(i, t)) return i
                    } catch (e) {}
                } catch (e) {}
        },
        Ie = {
            AUCTION_INIT: "auctionInit",
            AUCTION_END: "auctionEnd",
            BID_TIMEOUT: "bidTimeout",
            BID_REQUESTED: "bidRequested",
            BID_RESPONSE: "bidResponse",
            BID_WON: "bidWon",
            NO_BID: "noBid"
        };

    function ke(e, t, s = "prebid") {
        return {
            on(i, n) {
                d(`[pbjsIntegration] pbjs.dispatcher (${s}) ${i}`, n), i === Ie.AUCTION_END && t.onAuctionEnd(e.toAuctionEnd(n), s), i === Ie.BID_RESPONSE && t.onBidResponse(e.toBidResponse(n)), i === Ie.BID_WON && "prebid" === s && t.onBidWon(e.toBidWon(n)), i === Ie.BID_WON && "sdk" === s && t.onBidWonFromSdk(e.toBidWonFromSdk(n))
            }
        }
    }

    function we(e) {
        let t;
        if (void 0 !== e)
            if (y(e)) t = e;
            else if (I(e)) {
            const s = Number(e);
            isNaN(s) || (t = s)
        }
        return void 0 !== t ? Math.trunc(t) : t
    }

    function Ae() {
        const e = e => {
                var t, s;
                T(e, "Auction event's adUnits should all be objects"), w(e.code, 'Auction event\'s adUnits should all have a key "code" as a string'), g(e.bids, 'Auction event\'s adUnits should all have a key "bids" as an array');
                const i = e.bids.map((t => {
                        try {
                            return (e => {
                                var t;
                                T(e, "Auction event's adUnits bidders should all be objects"), w(e.bidder, 'Auction event\'s adUnits bidders should all have a key "bidder" as a string');
                                const s = null !== (t = e.params) && void 0 !== t ? t : {};
                                return T(s, 'Auction event\'s adUnits bidders should all have a key "params" as an object'), {
                                    bidder: e.bidder,
                                    params: s
                                }
                            })(t)
                        } catch (t) {
                            return void c(`[pbjsIntegration] Discarding bidder from ${e.code}`, t)
                        }
                    })).filter((e => void 0 !== e)),
                    n = {};
                if (e.mediaTypes) {
                    if (T(e.mediaTypes, 'Auction event\'s adUnits should all have a key "mediaTypes" as an object'), e.mediaTypes.banner) {
                        T(e.mediaTypes.banner, 'Auction event\'s adUnits mediaTypes can all have a key "banner" that should be an object');
                        const s = null !== (t = e.mediaTypes.banner.sizes) && void 0 !== t ? t : [];
                        g(s, 'Auction event\'s adUnits mediaTypes banner should all have a key "sizes" that should be an array');
                        const i = s.filter((e => Array.isArray(e) && 2 === e.length)).map((e => {
                            try {
                                return g(e), [parseInt(e[0]), parseInt(e[1])]
                            } catch (e) {
                                return [0, 0]
                            }
                        }));
                        n.banner = {
                            sizes: i,
                            sizeConfig: e.mediaTypes.banner.sizeConfig
                        }
                    }
                    if (e.mediaTypes.native && (n.native = {
                            sizes: "native"
                        }), e.mediaTypes.video && (T(e.mediaTypes.video, 'Auction event\'s adUnits mediaTypes can all have a key "video" that should be an object'), e.mediaTypes.video.playerSize)) {
                        g(e.mediaTypes.video.playerSize, 'Auction event\'s adUnits mediaTypes video should all have a key "playerSize" that should be an array');
                        const t = (null !== (s = e.mediaTypes.video.playerSize) && void 0 !== s ? s : []).filter((e => Array.isArray(e) && 2 === e.length));
                        n.video = {
                            playerSize: t
                        }
                    }
                }
                const o = {
                        bids: i,
                        code: e.code,
                        mediaTypes: n
                    },
                    r = e.pubstack;
                void 0 !== r && (T(r), o.pubstack = r);
                const a = (e => {
                    if (!U(e, "ortb2Imp")) return;
                    const t = e.ortb2Imp;
                    if (!U(t, "ext")) return;
                    const s = t.ext;
                    if (!U(s, "data")) return;
                    const i = s.data;
                    return U(i, "pbadslot") && I(i.pbadslot) ? {
                        ext: {
                            data: {
                                pbadslot: i.pbadslot
                            }
                        }
                    } : void 0
                })(e);
                return a && (o.ortb2Imp = a), o
            },
            t = e => {
                T(e, "Auction event's bidderRequests should all be objects"), w(e.bidderRequestId, 'Auction event\'s bidderRequests should all have a key "bidderRequestId" as a string'), w(e.bidderCode, 'Auction event\'s bidderRequests should all have a key "bidderCode" as a string'), g(e.bids, 'Auction event\'s bidderRequests should all have a key "bids" as an array');
                const t = e.bids.map((t => {
                        try {
                            return s(t, "Auction event's bidderRequests")
                        } catch (t) {
                            return void c(`[pbjsIntegration] Discarding bid request from ${e.bidderRequestId}`, t)
                        }
                    })).filter((e => void 0 !== e)),
                    i = {
                        bidderRequestId: e.bidderRequestId,
                        bids: t,
                        bidderCode: e.bidderCode
                    };
                return e.gdprConsent && (i.gdprConsent = e.gdprConsent), i
            },
            s = (e, t) => {
                var s, i, n;
                T(e, t + "'s bids should all be objects"), w(e.adUnitCode, t + ' bids should all have a key "adUnitCode" as a string'), w(e.bidId, t + ' bids should all have a key "bidId" as a string'), w(e.bidder, t + ' bids should all have a key "bidder" as a string');
                const o = null !== (s = e.params) && void 0 !== s ? s : {};
                T(o, t + ' bids can all have a key "params" that should be an object');
                const r = null !== (i = e.userId) && void 0 !== i ? i : {};
                T(r, t + ' bids can all have a key "userId" that should be an object');
                const a = null !== (n = e.crumbs) && void 0 !== n ? n : {};
                return T(a, t + ' bids can all have a key "crumbs" that should be an object'), {
                    adUnitCode: e.adUnitCode,
                    bidId: e.bidId,
                    bidder: e.bidder,
                    params: o,
                    userId: r,
                    crumbs: a
                }
            };
        return {
            toBidRejected(e) {
                const t = this.toBidResponse(e);
                return T(e, "BidRejected event should be an object"), w(e.rejectionReason, 'BidRejected event should have a "rejectionReason" key as a string'), Object.assign(Object.assign({}, t), {
                    rejectionReason: e.rejectionReason
                })
            },
            toSeatNonBid: function(e) {
                return T(e, "SeatNonBid event should be an object"), w(e.seat, 'SeatNonBid event should have a "seat" key as a string'), g(e.nonbid, 'SeatNonBid event should have a "seat" key as a string'), e.nonbid.map((t => {
                    try {
                        return T(t, "Nonbid should be an object"), w(t.impid, 'Nonbid should have a "impid" key as a string'), k(t.statuscode, 'Nonbid should have a "statuscode" key as a number'), {
                            impid: t.impid,
                            statuscode: t.statuscode
                        }
                    } catch (t) {
                        return void c(`[pbjsIntegration] Discarding Nonbid from auction event ${e.auctionId}`, t)
                    }
                })).filter((e => void 0 !== e)), {
                    seat: e.seat,
                    nonbid: e.nonbid
                }
            },
            toAuctionEnd: function(s) {
                let i, n, o = [];
                T(s, "Auction event should be an object"), w(s.auctionId, 'Auction event should have a "auctionId" key as a string'), g(s.adUnits, 'Auction event should have a "adUnits" key as a non-empty array'), C(s.adUnits, 'Auction event should have a "adUnits" key as a non-empty array'), void 0 !== s.labels && (g(s.labels, 'Auction event can have a "labels" key that should be an array'), n = s.labels), g(s.bidderRequests, 'Auction event should have a "bidderRequests" key as a non-empty array'), C(s.bidderRequests, 'Auction event should have a "bidderRequests" key as a non-empty array');
                const r = we(s.timeout);
                s.timeout && !r && c(`[pbjsIntegration] unable to read timeout from auction event ${s.auctionId}`);
                const a = s.adUnits.map((t => {
                        try {
                            return e(t)
                        } catch (e) {
                            return void c(`[pbjsIntegration] Discarding adUnit from auction event ${s.auctionId}`, e)
                        }
                    })).filter((e => void 0 !== e)),
                    u = s.bidderRequests.map((e => {
                        try {
                            return t(e)
                        } catch (e) {
                            return void c(`[pbjsIntegration] Discarding bidderRequest from auction event ${s.auctionId}`, e)
                        }
                    })).filter((e => void 0 !== e));
                g(s.bidsReceived, 'Auction event should have a "bidsReceived" key as a non-empty array');
                const l = s.bidsReceived.map((e => {
                    try {
                        return this.toBidResponse(e)
                    } catch (e) {
                        return void c(`[pbjsIntegration] Discarding bidReceived from auction event ${s.auctionId}`, e)
                    }
                })).filter((e => void 0 !== e));
                g(s.adUnitCodes, 'Auction event should have a "adUnitCodes" key as a non-empty array'), C(s.adUnitCodes, 'Auction event should have a "adUnitCodes" key as a non-empty array');
                try {
                    g(s.bidsRejected, 'Auction event should have a "bidsRejected" key as an array'), o = s.bidsRejected.map((e => {
                        try {
                            return this.toBidRejected(e)
                        } catch (e) {
                            return void c(`[pbjsIntegration] Discarding bidRejected from auction event ${s.auctionId}`, e)
                        }
                    })).filter((e => void 0 !== e))
                } catch (e) {
                    d("Error on validator but not throwing since not mandatory", e.message)
                }
                g(s.noBids, 'Auction event should have a "noBids" key as an array');
                const b = s.noBids.map((e => {
                    try {
                        return this.toNoBid(e)
                    } catch (e) {
                        return void c(`[pbjsIntegration] Discarding noBid from auction event ${s.auctionId}`, e)
                    }
                })).filter((e => void 0 !== e));
                try {
                    g(s.seatNonBids, 'Auction event should have a "noBids" key as an array'), i = s.seatNonBids.map((e => {
                        try {
                            return this.toSeatNonBid(e)
                        } catch (e) {
                            return void c(`[pbjsIntegration] Discarding SeatNonBids from auction event ${s.auctionId}`, e)
                        }
                    })).filter((e => void 0 !== e))
                } catch (e) {
                    d("Error on validator but not throwing since not mandatory", e.message)
                }
                return function(e, t, s) {
                    if (!t.includes(e)) throw new f(null != s ? s : `Expected values to be one of '${t}', but received ${e}`)
                }(s.auctionStatus, ["completed", "inProgress", "started"]), k(s.auctionEnd), k(s.timestamp), {
                    auctionId: s.auctionId,
                    bidderRequests: u,
                    adUnits: a,
                    labels: n,
                    timeout: r,
                    auctionEnd: s.auctionEnd,
                    auctionStatus: s.auctionStatus,
                    noBids: b,
                    adUnitCodes: s.adUnitCodes,
                    bidsRejected: o,
                    bidsReceived: l,
                    timestamp: s.timestamp,
                    winningBids: [],
                    seatNonBids: i
                }
            },
            toAuction: function(s) {
                let i;
                T(s, "Auction event should be an object"), w(s.auctionId, 'Auction event should have a "auctionId" key as a string'), g(s.adUnits, 'Auction event should have a "adUnits" key as a non-empty array'), C(s.adUnits, 'Auction event should have a "adUnits" key as a non-empty array'), void 0 !== s.labels && (g(s.labels, 'Auction event can have a "labels" key that should be an array'), i = s.labels), g(s.bidderRequests, 'Auction event should have a "bidderRequests" key as a non-empty array'), C(s.bidderRequests, 'Auction event should have a "bidderRequests" key as a non-empty array');
                const n = we(s.timeout);
                s.timeout && !n && c(`[pbjsIntegration] unable to read timeout from auction event ${s.auctionId}`);
                const o = s.adUnits.map((t => {
                        try {
                            return e(t)
                        } catch (e) {
                            return void c(`[pbjsIntegration] Discarding adUnit from auction event ${s.auctionId}`, e)
                        }
                    })).filter((e => void 0 !== e)),
                    r = s.bidderRequests.map((e => {
                        try {
                            return t(e)
                        } catch (e) {
                            return void c(`[pbjsIntegration] Discarding bidderRequest from auction event ${s.auctionId}`, e)
                        }
                    })).filter((e => void 0 !== e));
                return {
                    auctionId: s.auctionId,
                    bidderRequests: r,
                    adUnits: o,
                    labels: i,
                    timeout: n
                }
            },
            toBidRequested(e) {
                T(e, "BidRequested event should be an object"), w(e.auctionId, 'BidRequested event should have a "auctionId" key as a string'), g(e.bids, 'BidRequested event should have a "bids" key as an array');
                const t = e.bids.map((t => {
                        try {
                            return s(t, "BidRequested event")
                        } catch (t) {
                            return void c(`[pbjsIntegration] Discarding bid request from bid requested event ${e.auctionId}`, t)
                        }
                    })).filter((e => void 0 !== e)),
                    i = {
                        auctionId: e.auctionId,
                        bids: t
                    };
                return e.gdprConsent && (i.gdprConsent = e.gdprConsent), i
            },
            toBidResponse(e) {
                var t;
                T(e, "BidResponse event should be an object"), w(e.auctionId, 'BidRequested event should have a "auctionId" key as a string'), w(e.adUnitCode, 'BidRequested event should have a "adUnitCode" key as a string'), w(e.adId, 'BidRequested event should have a "adId" key as a string'), w(e.requestId, 'BidRequested event should have a "requestId" key as a string');
                const s = I(e.cpm) ? Number.parseFloat(e.cpm) : e.cpm;
                let i;
                k(s, 'BidRequested event should have a "cpm" key as a number');
                let n, o = e.size;
                "string" != typeof o && (o = e.width && e.height ? `${e.width}x${e.height}` : "unknown"), w(e.mediaType, 'BidRequested event should have a "mediaType" key as a string'), w(o, 'BidRequested event should have a "size" key as a string'), I(e.currency) && (n = e.currency), w(e.bidderCode, 'BidResponse event should have a "bidderCode" key as a string'),
                    function(e, t) {
                        if (null != e && !y(e)) throw new f(null != t ? t : "Expected value to be a number, but received " + typeof e)
                    }(e.timeToRespond);
                try {
                    w(e.adapterCode, 'BidWon event should have a "bidderCode" key as a string'), i = e.adapterCode
                } catch (e) {
                    d("Error on validator but not throwing since not mandatory", e.message)
                }
                return {
                    adId: e.adId,
                    adUnitCode: e.adUnitCode,
                    auctionId: e.auctionId,
                    cpm: s,
                    currency: n,
                    requestId: e.requestId,
                    size: o,
                    bidderCode: e.bidderCode,
                    mediaType: null !== (t = e.mediaType) && void 0 !== t ? t : "banner",
                    timeToRespond: e.timeToRespond,
                    adapterCode: i
                }
            },
            toBidTimeout(e) {
                g(e, "BidTimeout event should be an array");
                const t = [];
                return e.forEach((e => {
                    try {
                        T(e, "BidTimeout events should all be objects"), w(e.adUnitCode, 'BidTimeout events should all have a key "adUnitCode" as a string'), w(e.auctionId, 'BidTimeout events should all have a key "auctionId" as a string'), w(e.bidId, 'BidTimeout events should all have a key "bidId" as a string'), t.push({
                            adUnitCode: e.adUnitCode,
                            auctionId: e.auctionId,
                            bidId: e.bidId
                        })
                    } catch (t) {
                        d("Discarding bid timeout event because ", t.message, e)
                    }
                })), t
            },
            toNoBid: e => (T(e, "NoBid event should be an object"), w(e.auctionId, 'NoBid event should have a "auctionId" key as a string'), w(e.bidId, 'NoBid event should have a "bidId" key as a string'), w(e.adUnitCode, 'NoBid event should have a "adUnitCode" key as a string'), {
                bidId: e.bidId,
                adUnitCode: e.adUnitCode,
                auctionId: e.auctionId
            }),
            toBidWon(e) {
                var t;
                let s, i, n, o, r, a;
                T(e, "BidWon event should be an object"), w(e.adId, 'BidWon event should have a "adId" key as a string'), w(e.requestId, 'BidWon event should have a "requestId" key as a string'), I(e.currency) && (a = e.currency);
                const c = I(e.cpm) ? Number.parseFloat(e.cpm) : e.cpm;
                k(c, 'BidRequested event should have a "cpm" key as a number'), w(e.mediaType, 'BidRequested event should have a "mediaType" key as a string'), w(e.size, 'BidWon event should have a "size" key as a string'), r = e.size, w(e.auctionId, 'BidWon event should have a "auctionId" key as a string'), s = e.auctionId, w(e.adUnitCode, 'BidWon event should have a "adUnitCode" key as a string'), i = e.adUnitCode;
                try {
                    w(e.bidderCode, 'BidWon event should have a "bidderCode" key as a string'), n = e.bidderCode
                } catch (e) {
                    d("Error on validator but not throwing since not mandatory for monitoring (only for refresh)", e.message)
                }
                try {
                    w(e.adapterCode, 'BidWon event should have a "bidderCode" key as a string'), o = e.adapterCode
                } catch (e) {
                    d("Error on validator but not throwing since not mandatory", e.message)
                }
                return g(e.params), {
                    adId: e.adId,
                    adUnitCode: i,
                    auctionId: s,
                    bidderCode: n,
                    adapterCode: o,
                    size: r,
                    requestId: e.requestId,
                    currency: a,
                    cpm: c,
                    mediaType: null !== (t = e.mediaType) && void 0 !== t ? t : "banner",
                    params: e.params
                }
            },
            toBidWonFromSdk: e => (T(e, "BidWon event should be an object"), w(e.adId, 'BidWon event should have a "adId" key as a string'), {
                adId: e.adId
            })
        }
    }
    const Ce = 400;
    class Re {
        constructor() {
            this.state = "new", this.elapsedTime = 0, this.timeTargets = []
        }
        start() {
            return "stopped" === this.state && (this.elapsedTime = 0), "started" === this.state ? this.elapsed() : (this.state = "started", this.timeoutId = setTimeout((() => this.update()), Re.pacing), this.elapsedTime)
        }
        pause() {
            if ("paused" === this.state || "stopped" === this.state) return this.elapsedTime;
            const e = this.update();
            return this.state = "paused", e
        }
        stop() {
            if ("stopped" === this.state) return this.elapsedTime;
            const e = this.update();
            return this.state = "stopped", e
        }
        elapsed() {
            return "started" === this.state && this.update(), this.elapsedTime
        }
        timeTargetReached(e) {
            return new Promise((t => {
                this.timeTargets.push([e, t])
            }))
        }
        update() {
            let e = Re.pacing;
            if ("started" === this.state) {
                this.elapsedTime += e;
                for (let t = this.timeTargets.length; t--;) {
                    const [s, i] = this.timeTargets[t];
                    this.elapsedTime >= s ? (i(s), this.timeTargets.splice(t, 1)) : e = Math.min(e, s - this.elapsedTime)
                }
            }
            return "stopped" !== this.state && (this.timeoutId && clearTimeout(this.timeoutId), this.timeoutId = setTimeout((() => this.update()), e)), this.elapsedTime
        }
    }
    Re.pacing = 100;
    class Te {
        constructor(e, t, s, i, n) {
            this.creative = i, this.timer = new Re, this.inViewPercentage = e, this.cumulative = s, this.timer.timeTargetReached(t).then((() => {
                n()
            }))
        }
        pauseTimer() {
            this.timer.pause()
        }
        startTimer() {
            this.timer.start()
        }
        stopTimer() {
            this.timer.stop()
        }
        getElapsed() {
            return this.timer.elapsed()
        }
        isViewable() {
            return this.inView
        }
        intersectionChange(e) {
            this.creative.visibilityRatioFromIntersection(e) >= this.inViewPercentage ? this.inView || (this.timer.start(), this.inView = !0) : this.inView && (this.cumulative ? this.timer.pause() : this.timer.stop(), this.inView = !1)
        }
        getTimerState() {
            return this.timer.state
        }
    }
    class Ue {
        constructor(e) {
            this.adUnit = e
        }
        visibilityRatioFromIntersection(e) {
            const t = Ee(this.adUnit, this.adUnit);
            if (this.adUnit === t) return e.intersectionRatio;
            const s = t.getBoundingClientRect();
            return e.intersectionRect.height / s.height
        }
    }
    const Ee = (e, t) => (Se(e) < Se(t) && (e = t), Array.from(t.children).filter((e => e instanceof HTMLElement)).forEach((t => {
            e = Ee(e, t)
        })), e),
        Se = e => e.getBoundingClientRect ? e.getBoundingClientRect().height : 0,
        Be = {
            root: null,
            rootMargin: "0px",
            threshold: [0, .3, .5, 1]
        };
    class je {
        constructor(e, t, s) {
            this.windowActive = !0, this.pbstckWindow = s, this.visibilityState = s.document.visibilityState, this.trackedOnFocusChange = this.onFocusChange.bind(this), s.addEventListener("focus", this.trackedOnFocusChange), s.addEventListener("blur", this.trackedOnFocusChange), this.trackedOnVisibilityChange = this.onVisibilityChange.bind(this), s.addEventListener("visibilitychange", this.trackedOnVisibilityChange);
            const i = this.getObserverThresholds(t);
            this.observer = new IntersectionObserver((e => this.intersectionObserverCallback(e)), i), this.observer.observe(e);
            const n = new Ue(e);
            this.computer = new Te(t.minPercentageInView, t.minTimeInView, t.cumulativeTimer, n, (() => t.completionCallback(e.id))), "hidden" !== this.visibilityState && this.windowActive || this.stop()
        }
        getObserverThresholds(e) {
            return .3 === e.minPercentageInView ? Object.assign(Object.assign({}, Be), {
                threshold: [.3, .5, .75, 1]
            }) : Object.assign(Object.assign({}, Be), {
                threshold: [.5, .75, 1]
            })
        }
        onVisibilityChange() {
            this.visibilityState = "visible" === this.visibilityState ? "hidden" : "visible", this.checkWindowActive()
        }
        onFocusChange(e) {
            this.windowActive = "focusin" === e.type || "focus" === e.type, this.checkWindowActive()
        }
        checkWindowActive() {
            "visible" === this.visibilityState && this.windowActive ? this.start() : this.pause()
        }
        destroy() {
            var e;
            this.stop(), null === (e = this.observer) || void 0 === e || e.disconnect(), this.pbstckWindow.removeEventListener("visibilitychange", this.trackedOnVisibilityChange), this.pbstckWindow.removeEventListener("focus", this.trackedOnFocusChange), this.pbstckWindow.removeEventListener("blur", this.trackedOnFocusChange), this.computer = null, this.observer = null
        }
        getElapsed() {
            return null === this.computer ? 0 : this.computer.getElapsed()
        }
        pause() {
            var e;
            null === (e = this.computer) || void 0 === e || e.pauseTimer()
        }
        start() {
            var e;
            null === (e = this.computer) || void 0 === e || e.startTimer()
        }
        stop() {
            var e;
            null === (e = this.computer) || void 0 === e || e.stopTimer()
        }
        intersectionObserverCallback(e) {
            e.forEach((e => {
                var t;
                null === (t = this.computer) || void 0 === t || t.intersectionChange(e)
            }))
        }
        getTimerState() {
            var e;
            return null === (e = this.computer) || void 0 === e ? void 0 : e.getTimerState()
        }
    }
    const Ne = {
        viewableTime: 1e3,
        largeAdunitSize: 242e3,
        largeAdunitTreshold: .3,
        standardAdunitTreshold: .5
    };
    class Oe {
        constructor(e, t) {
            this.viewabilityState = new Map, this.viewedTimeState = new Map, this.elementIdToCode = new Map, this.viewabilityStream = new S, this.viewedStream = new S, d("[pubstackViewability] Create ViewabilityController with config", Ne), this.pbstckWindow = t, this.pbstckWindow.addEventListener("unload", (() => this.unloadMeasuredImpressions())), e.forwarder.coreImpressionStream.subscribe((e => {
                d("[pubstackViewability] Receive impression", e.bidderCode, e.adUnit.code), this.track(e)
            })), e.forwarder.coreAuctionStream.subscribe((e => {
                d("[pubstackViewability] Receive auctionend", e.adUnit.code), this.endMeasure(e.adUnit.code)
            }))
        }
        onUnload(e) {
            this.unloadCallback = e
        }
        endMeasure(e) {
            d("[pubstackViewability] receive event to stop measure");
            const t = this.viewedTimeState.get(e);
            void 0 !== t ? (t.viewabilitytracker.stop(), this.onMeasurable(e)) : d("[pubstackViewability] event received but no tracker to stop, skipping")
        }
        track(e) {
            if (!e.viewabilityMeasurable) return void d("[pubstackViewability] Cannot track impression for adUnit ", e.adUnit);
            const t = X(e.adUnit);
            null !== t ? (this.trackViewability(e, t), this.trackMeasure(e, t)) : $(new Error(`[pubstackViewability] Unexpected null HTML Element on viewable impression for adUnit ${e.adUnit.name}`))
        }
        trackMeasure(e, s) {
            var i;
            return t(this, void 0, void 0, (function*() {
                let t = null === (i = this.viewedTimeState.get(e.adUnit.code)) || void 0 === i ? void 0 : i.viewabilitytracker;
                this.elementIdToCode.set(s.id, e.adUnit.code), void 0 !== t && (d(`[pubstackViewability] replacing existing measurability tracker on ${s.id}`), t.stop(), this.onMeasurable(e.adUnit.code)), d(`[pubstackViewability] tracking code ${e.adUnit.code} with rule MRC for measurability`);
                const n = {
                    minPercentageInView: this.minPercentageInView(s, Ne),
                    minTimeInView: 18e4,
                    cumulativeTimer: !0,
                    completionCallback: e => {
                        const t = this.elementIdToCode.get(e);
                        void 0 !== t ? this.onMeasurable(t) : d(`[pubstackViewability] unable to find matching adunitcode for element ${e}`)
                    }
                };
                t = new je(s, n, this.pbstckWindow), this.viewedTimeState.set(e.adUnit.code, {
                    impression: e,
                    viewabilitytracker: t
                })
            }))
        }
        trackViewability(e, s) {
            var i;
            return t(this, void 0, void 0, (function*() {
                let t = null === (i = this.viewabilityState.get(s.id)) || void 0 === i ? void 0 : i.viewabilitytracker;
                void 0 !== t && (d(`[pubstackViewability] replacing existing tracker on ${s.id}`), t.destroy(), this.viewabilityState.delete(s.id)), d(`[pubstackViewability] tracking element ${s.id} with rule MRC for monitoring`);
                const n = {
                    minPercentageInView: this.minPercentageInView(s, Ne),
                    minTimeInView: Ne.viewableTime,
                    cumulativeTimer: !1,
                    completionCallback: e => this.onViewable(e)
                };
                t = new je(s, n, this.pbstckWindow), this.viewabilityState.set(s.id, {
                    impression: e,
                    viewabilitytracker: t
                })
            }))
        }
        minPercentageInView(e, t) {
            const s = window.getComputedStyle(e);
            return Number(s.getPropertyValue("width").replace(/px/, "")) * Number(s.getPropertyValue("height").replace(/px/, "")) > t.largeAdunitSize ? t.largeAdunitTreshold : t.standardAdunitTreshold
        }
        unloadMeasuredImpressions() {
            if (d("[pubstackViewability] page unloaded, forwarding impressions measured"), void 0 !== this.unloadCallback) {
                const e = [];
                Array.from(this.viewedTimeState.values()).forEach((t => {
                    if (void 0 !== t.viewabilitytracker) {
                        t.viewabilitytracker.stop();
                        const s = Math.floor(t.viewabilitytracker.getElapsed() / 1e3);
                        s > 0 && e.push({
                            bidId: t.impression.bidId,
                            auctionId: t.impression.auctionId,
                            lastAuctionId: t.impression.lastAuctionId,
                            adUnit: t.impression.adUnit,
                            bidderCode: t.impression.bidderCode,
                            pbjsVersion: t.impression.pbjsVersion,
                            cpm: t.impression.cpm,
                            currency: t.impression.currency,
                            refresh: t.impression.refresh,
                            size: t.impression.size,
                            viewedTime: s,
                            pubstackRefresh: t.impression.pubstackRefresh,
                            pubstackRefreshRank: t.impression.pubstackRefreshRank
                        })
                    }
                })), e.length > 0 && this.unloadCallback(e)
            }
        }
        onMeasurable(e) {
            d(`[pubstackViewability] Measurability Event on AdUnit code ${e}`);
            const t = this.viewedTimeState.get(e);
            if (void 0 === t) return void $(new Error(`[pubstackViewability] Impression not found for AdUnit code ${e}`));
            this.viewedTimeState.delete(e);
            if (Math.floor(t.viewabilitytracker.getElapsed() / 1e3) > 0) {
                const e = t.impression,
                    s = {
                        bidId: e.bidId,
                        auctionId: e.auctionId,
                        lastAuctionId: e.lastAuctionId,
                        adUnit: e.adUnit,
                        bidderCode: e.bidderCode,
                        pbjsVersion: e.pbjsVersion,
                        cpm: e.cpm,
                        currency: e.currency,
                        refresh: e.refresh,
                        size: e.size,
                        viewedTime: Math.floor(t.viewabilitytracker.getElapsed() / 1e3),
                        pubstackRefresh: e.pubstackRefresh,
                        pubstackRefreshRank: e.pubstackRefreshRank
                    };
                d(`[pubstackViewability] Forwarding measured impression on code ${e.adUnit.code}`), this.viewedStream.next(s)
            }
            t.viewabilitytracker.destroy()
        }
        onViewable(e) {
            d(`[pubstackViewability] Viewability Event on element ${e}`);
            const t = this.viewabilityState.get(e);
            if (void 0 === t) return void $(new Error(`[pubstackViewability] Impression not found for ElementId ${e}`));
            this.viewabilityState.set(e, t);
            const s = t.impression,
                i = {
                    bidId: s.bidId,
                    auctionId: s.auctionId,
                    lastAuctionId: s.lastAuctionId,
                    adUnit: s.adUnit,
                    bidderCode: s.bidderCode,
                    pbjsVersion: s.pbjsVersion,
                    cpm: s.cpm,
                    currency: s.currency,
                    refresh: s.refresh,
                    size: s.size,
                    htmlElementId: e,
                    pubstackRefresh: s.pubstackRefresh,
                    pubstackRefreshRank: s.pubstackRefreshRank
                };
            d(`[pubstackViewability] Forwarding viewable impression ${i.htmlElementId}`), this.viewabilityStream.next(i)
        }
    }

    function Ve(e, t) {
        return "object" == typeof t && t instanceof Set ? Array.from(t) : t
    }

    function $e(e, t) {
        return "tags" !== e && "sizes" !== e || !Array.isArray(t) ? t : new Set(t)
    }
    class qe {
        constructor(e) {
            this.coreEvents = [], this.errors = [], e.forwarder.coreAuctionStream.subscribe((e => this.addEvent(e))), e.forwarder.coreImpressionStream.subscribe((e => this.addEvent(e)))
        }
        addEvent(e) {
            this.coreEvents.push(e)
        }
        addError(e) {
            this.errors.push(e)
        }
        getEvents() {
            return this.coreEvents.map((e => JSON.parse(JSON.stringify(e, Ve), $e)))
        }
        getErrors() {
            return this.errors
        }
    }
    const xe = e => {
            var t;
            const s = null !== (t = null == e ? void 0 : e.host) && void 0 !== t ? t : "unknown";
            return s.startsWith("www.") ? s.substring(4) : s
        },
        Fe = e => {
            let t;
            return t = e && e.protocol && e.host && e.pathname ? `${e.protocol}//${e.host}${e.pathname}` : "unknown", t
        };

    function ze(e) {
        var t;
        const s = "pbstck_context";
        let i = null === (t = ee(s).find((e => "pbstck_ab_test" === te(e.name, s)))) || void 0 === t ? void 0 : t.content;
        return i && !e.includes(i) && (i = void 0), i
    }
    class Me {
        constructor(e, t, s, i, n) {
            var o;
            this.items = [], this.url = e, this.buffer = null !== (o = null == n ? void 0 : n.buffer) && void 0 !== o ? o : Me.defaults.buffer, this.sender = t, this.context = s, this.abTestValues = i
        }
        buildUrl() {
            const e = this.context.customFields["kleanads-version"],
                t = this.context.customFields["config-version"];
            return e ? `${this.url}?tId=${this.context.tagId}&c=${this.items.length}&v=${e}&s=${t}` : `${this.url}?tId=${this.context.tagId}&c=${this.items.length}`
        }
        batchThenSend(e) {
            const t = De(e, this.context, this.abTestValues);
            if (this.items.push(t), 0 === this.buffer) return this.flush();
            1 === this.items.length && setTimeout((() => this.flush()), this.buffer)
        }
        flush() {
            0 !== this.items.length && (this.sender(this.buildUrl(), [...this.items]), this.reset())
        }
        reset() {
            this.items = []
        }
    }
    Me.defaults = {
        buffer: 150
    };
    const De = (e, t, s) => {
        const {
            customFields: i
        } = t, {
            customFields: n
        } = e, o = Object.assign(Object.assign({}, n), i);
        return Object.assign(Object.assign(Object.assign({}, e), t), {
            customFields: o,
            abTestPopulation: s ? ze(s) : void 0,
            domain: xe(window.location),
            href: Fe(window.location),
            kleanAdsStackVersion: o["config-version"],
            kleanAdsStackId: o["kleanads-stack-id"]
        })
    };
    class Pe {
        constructor(e, t, s) {
            this.url = e, this.context = s, this.sender = t
        }
        buildUrl(e) {
            return `${this.url}?sId=${this.context.scopeId.substring(0,8)}&tId=${this.context.tagId}&c=${e}&ctr=${this.context.country}`
        }
        send(e) {
            const t = e.map((e => _e(e, this.context)));
            this.sender(this.buildUrl(t.length), t)
        }
    }
    const _e = (e, t) => Object.assign(Object.assign(Object.assign({}, e), t), {
            domain: xe(window.location),
            href: Fe(window.location)
        }),
        We = ae();
    class Le {
        constructor(e, t, s, i, n, o) {
            this.buffers = {
                locked: !1,
                auctionBuffer: [],
                impressionBuffer: [],
                viewabilityEventBuffer: [],
                measuredImpressionBuffer: [],
                measuredImpressionBeaconBuffer: []
            }, this.adUnitManageable = s, this.viewabilityGateway = new Me(`${e}/viewability`, Ge, t, o), this.auctionGateway = new Me(`${e}/auction`, Ge, t, o), this.impressionGateway = new Me(`${e}/impression`, Ge, t, o), this.errorGateway = new Me(`${e}/error`, Ge, t, o), this.measuredImpressionGateway = new Me(`${e}/measured`, Ge, t, o), this.measuredImpressionBeaconGateway = new Pe(`${e}/measured`, Je, t), this.pageGateway = new Me(`${e}/page`, Ge, t, o), this.bindController(i, n)
        }
        bindController(e, t) {
            e.forwarder.coreAuctionStream.subscribe((e => this.formatAndForwardAuction(e))), e.forwarder.coreImpressionStream.subscribe((e => {
                this.formatAndForwardImpression(e)
            })), void 0 !== t && (t.viewabilityStream.subscribe((e => {
                this.formatAndForwardViewability(e)
            })), t.viewedStream.subscribe((e => {
                this.formatAndForwardMeasuredImpression(e)
            })), t.onUnload((e => this.formatAndForwardMeasuredImpressionForBeacon(e))))
        }
        set adUnitManageable(e) {
            this._adUnitManageable = e
        }
        get adUnitManageable() {
            return this._adUnitManageable
        }
        lock() {
            this.buffers.locked = !0
        }
        release() {
            for (this.buffers.locked = !1; this.buffers.auctionBuffer.length;) this.formatAndForwardAuction(this.buffers.auctionBuffer.pop());
            for (; this.buffers.impressionBuffer.length;) this.formatAndForwardImpression(this.buffers.impressionBuffer.pop());
            for (; this.buffers.viewabilityEventBuffer.length;) this.formatAndForwardViewability(this.buffers.viewabilityEventBuffer.pop());
            for (; this.buffers.measuredImpressionBuffer.length;) this.formatAndForwardMeasuredImpression(this.buffers.measuredImpressionBuffer.pop());
            for (; this.buffers.measuredImpressionBeaconBuffer.length;) this.formatAndForwardMeasuredImpressionForBeacon(this.buffers.measuredImpressionBeaconBuffer.pop())
        }
        formatAndForwardAuction(e) {
            if (this.buffers.locked) this.buffers.auctionBuffer.push(e);
            else {
                const t = [];
                e.bidRequests.forEach((e => {
                    t.push({
                        bidId: h(e),
                        bidderCode: e.bidderCode,
                        state: e.state,
                        tags: 0 === e.tags.size ? void 0 : Array.from(e.tags),
                        cpm: p(e) ? e.cpm : void 0,
                        currency: p(e) ? e.currency : void 0,
                        size: p(e) ? e.size : void 0,
                        customFields: e.customFields,
                        timeToRespond: e.timeToRespond
                    })
                }));
                const s = void 0 === e.userConsentState ? "notAvailable" : e.userConsentState,
                    i = void 0 === e.userConsentVersion ? "notAvailable" : e.userConsentVersion,
                    n = {
                        auctionId: e.auctionId,
                        adUnit: e.adUnit.name,
                        adUnitPath: e.adUnit.path,
                        sizes: Array.from(e.sizes),
                        tags: 0 === e.tags.size ? void 0 : Array.from(e.tags),
                        refresh: e.refresh,
                        userConsentState: s,
                        userConsentVersion: i,
                        hasUserId: e.hasUserId,
                        userIdProviderList: e.userIdProviderList,
                        pbjsVersion: e.pbjsVersion,
                        bidRequests: t,
                        pubstackManaged: this.adUnitManageable.includes(e.adUnit.name),
                        pubstackRefresh: e.pubstackRefresh,
                        pubstackRefreshRank: e.pubstackRefreshRank,
                        customFields: e.customFields,
                        duration: e.duration,
                        timeout: e.timeout
                    };
                this.auctionGateway.batchThenSend(n)
            }
        }
        formatAndForwardImpression(e) {
            if (this.buffers.locked) this.buffers.impressionBuffer.push(e);
            else {
                const t = {
                    bidId: e.bidId,
                    auctionId: e.auctionId,
                    lastAuctionId: e.lastAuctionId,
                    adUnit: e.adUnit.name,
                    adUnitPath: e.adUnit.path,
                    bidderCode: e.bidderCode,
                    cpm: e.cpm,
                    currency: e.currency,
                    refresh: e.refresh,
                    size: e.size,
                    userConsentState: e.userConsentState,
                    userConsentVersion: e.userConsentVersion,
                    hasUserId: e.hasUserId,
                    userIdProviderList: e.userIdProviderList,
                    pbjsVersion: e.pbjsVersion,
                    cpmUplift: e.cpmUplift,
                    tags: Array.from(e.tags),
                    viewabilityMeasurable: e.viewabilityMeasurable,
                    pubstackManaged: this.adUnitManageable.includes(e.adUnit.name),
                    pubstackRefresh: e.pubstackRefresh,
                    pubstackRefreshRank: e.pubstackRefreshRank,
                    customFields: e.customFields
                };
                this.impressionGateway.batchThenSend(t)
            }
        }
        formatAndForwardViewability(e) {
            if (this.buffers.locked) this.buffers.viewabilityEventBuffer.push(e);
            else {
                const t = {
                    bidId: e.bidId,
                    auctionId: e.auctionId,
                    lastAuctionId: e.lastAuctionId,
                    adUnit: e.adUnit.name,
                    adUnitPath: e.adUnit.path,
                    bidderCode: e.bidderCode,
                    pbjsVersion: e.pbjsVersion,
                    cpm: e.cpm,
                    currency: e.currency,
                    size: e.size,
                    refresh: e.refresh,
                    htmlElementId: e.htmlElementId,
                    mrcViewable: !0,
                    pubstackManaged: this.adUnitManageable.includes(e.adUnit.name),
                    pubstackRefresh: e.pubstackRefresh,
                    pubstackRefreshRank: e.pubstackRefreshRank
                };
                this.viewabilityGateway.batchThenSend(t)
            }
        }
        formatAndForwardMeasuredImpression(e) {
            if (this.buffers.locked) this.buffers.measuredImpressionBuffer.push(e);
            else {
                const t = {
                    bidId: e.bidId,
                    auctionId: e.auctionId,
                    lastAuctionId: e.lastAuctionId,
                    adUnit: e.adUnit.name,
                    adUnitPath: e.adUnit.path,
                    bidderCode: e.bidderCode,
                    cpm: e.cpm,
                    currency: e.currency,
                    refresh: e.refresh,
                    size: e.size,
                    pbjsVersion: e.pbjsVersion,
                    viewedTime: e.viewedTime,
                    pubstackManaged: this.adUnitManageable.includes(e.adUnit.name),
                    pubstackRefresh: e.pubstackRefresh,
                    pubstackRefreshRank: e.pubstackRefreshRank
                };
                this.measuredImpressionGateway.batchThenSend(t)
            }
        }
        formatAndForwardMeasuredImpressionForBeacon(e) {
            if (this.buffers.locked) this.buffers.measuredImpressionBeaconBuffer.push(e);
            else {
                const t = e.map((e => ({
                    bidId: e.bidId,
                    auctionId: e.auctionId,
                    lastAuctionId: e.lastAuctionId,
                    adUnit: e.adUnit.name,
                    adUnitPath: e.adUnit.path,
                    bidderCode: e.bidderCode,
                    cpm: e.cpm,
                    currency: e.currency,
                    refresh: e.refresh,
                    size: e.size,
                    pbjsVersion: e.pbjsVersion,
                    viewedTime: e.viewedTime,
                    pubstackManaged: this.adUnitManageable.includes(e.adUnit.name),
                    pubstackRefresh: e.pubstackRefresh,
                    pubstackRefreshRank: e.pubstackRefreshRank
                })));
                this.measuredImpressionBeaconGateway.send(t)
            }
        }
        sendError(e) {
            this.errorGateway.batchThenSend(e)
        }
        sendToDatadog(e) {
            var t;
            if (void 0 === e.error || "" === e.error) return;
            const s = e.error,
                i = null !== (t = e.context) && void 0 !== t ? t : {};
            T(i), w(s);
            const n = Object.assign(Object.assign({
                    pageId: We,
                    status: "error",
                    domain: xe(window.location),
                    href: Fe(window.location)
                }, i), {
                    message: s
                }),
                o = new XMLHttpRequest;
            o.open("POST", "https://browser-http-intake.logs.datadoghq.com/v1/input/pub551f730416e5317842afc2792691e95c?ddsource=browser&ddtags=version:1.3.2", !0), o.setRequestHeader("Content-Type", "text/plain"), o.send(JSON.stringify(n))
        }
    }
    const Ge = (e, t) => {
            const s = new XMLHttpRequest;
            s.open("POST", e, !0), s.setRequestHeader("Content-Type", "text/plain"), s.send(JSON.stringify(t)), d("post", e, t)
        },
        Je = (e, t) => {
            const s = JSON.stringify(t);
            navigator.sendBeacon(e, s), d("beacon", e, t)
        },
        He = (e, t) => {
            if (!e || !t) throw new Error("IllegalArgumentException");
            return `${e}_${t}`
        },
        Qe = 20;

    function Ye() {
        const e = "pbstck",
            t = new Map;
        ee(e).forEach((s => {
            const i = te(s.name, e);
            t.has(i) && c(`Custom dim ${i} is present many times`), t.size < Qe ? t.set(i, s.content) : c(`Skipping custom dim ${i} with ${s.content}: limit of ${Qe} keys exceeded`)
        }));
        const s = Object.assign({}, ...Array.from(t.entries()).map((([e, t]) => ({
            [e]: t
        }))));
        return t.size > 0 && d("Custom dim found :", s), s
    }
    const Ke = e => {
            const t = [];
            return JSON.parse(JSON.stringify(e, ((e, s) => {
                if ("object" == typeof s && null !== s) {
                    if (t.includes(s)) return;
                    t.push(s)
                }
                return s
            })))
        },
        Xe = (e, t) => {
            const s = Ae(),
                i = new he(void 0),
                n = ke(s, i, "sdk");
            t.bindIntegration(i), e.subscribe((([e, [t]]) => {
                try {
                    n.on(e, t)
                } catch (e) {
                    e.context = e.context || {}, e.context.pbjs = {
                        source: "sdk:pbjs"
                    }, $(e)
                }
            }))
        },
        Ze = (e, t, s) => {
            const i = e;
            i[s] = i[s] || [];
            const n = i[s];
            e.pbstck = e.pbstck || {}, e.pbstck.sdk = e.pbstck.sdk || {}, e.pbstck.sdk[t] = e.pbstck.sdk[t] || {
                p: [],
                q: n
            }, e.pbstck.sdk[t].p = e.pbstck.sdk[t].p || [], e.pbstck.sdk[t].q = e.pbstck.sdk[t].q || n, e.pbstck.sdk[t].q !== n && (e.pbstck.sdk[t].q = e.pbstck.sdk[t].q.concat(n));
            const o = {
                cmd: (...s) => {
                    const i = ["cmd", s];
                    (e.pbstck.sdk[t].q || []).push(i), (e.pbstck.sdk[t].p || []).forEach((e => e(i)))
                }
            };
            return e.Pubstack = o, o
        };

    function et(e, t, s) {
        const i = new S,
            n = [];
        Ze(e, s.tagId, s.globalQueue);
        const o = e[s.globalQueue],
            r = t => {
                ! function(e, t) {
                    if (void 0 !== e) throw new f(null != t ? t : `Expected value to be undefined, but received ${e}`)
                }(Object.values(e.pbstck.sdk).find((t => t !== e.pbstck.sdk[s.tagId] && t.q === o)), `Concurrency on '${s.globalQueue}' globalQueue (more than 1 destination configured)`), i.next([t[0], Ke(Object.values(t[1]))])
            };
        return i.subscribe(((...e) => n.push(e))), Xe(i.pipe(...B(/cmd/)).pipe(...B(/pbjs|prebid/)), t), {
            debug: () => ({
                events: n
            }),
            dispatchEvents: () => {
                e.pbstck.sdk[s.tagId].q.forEach(r), e.pbstck.sdk[s.tagId].p.push(r)
            }
        }
    }
    const tt = {
        CALL: "call",
        AD_CALLBACK: "pbstck:ad"
    };
    const st = () => ({
        toAd(e, t) {
            T(e), A(t, "toAd: id is undefined"), A(e.formatId, "toAd: formatId is undefined"), w(t),
                function(e, t, s) {
                    if (!U(e, t)) throw new f(null != s ? s : `Expected object to have key '${t}', but not found`)
                }(e, "formatId");
            const s = "string" == typeof e.size ? e.size : "unknown";
            return {
                cpm: y(e.cpm) ? e.cpm : 0,
                size: s,
                formatId: y(e.formatId) ? e.formatId.toString() : e.formatId
            }
        }
    });
    const it = new WeakSet;

    function nt(e, t, s) {
        const i = e[s.globalName];
        if (void 0 === i || !i.__smartLoaded) return {
            status: l.NOT_READY
        };
        const n = st(),
            o = new me,
            r = function(e, t) {
                return {
                    on(s, i, n) {
                        d("sas.dispatcher", s, i), s === tt.AD_CALLBACK && t.onAd(e.toAd(i, n))
                    }
                }
            }(n, o);
        t.bindIntegration(o);
        const a = [];
        if (it.has(i)) return {
            status: l.LOADED
        };
        it.add(i);
        const c = Object.values(tt);
        return c.forEach((e => {
            i.events.on(e, ((t, s) => {
                const i = Ke(t);
                a.push({
                    eventName: e,
                    data: i,
                    id: s
                });
                try {
                    r.on(e, i, s)
                } catch (e) {
                    e.context = e.context || {}, e.context.adapter = {
                        source: "sas:on"
                    }, $(e)
                }
            }))
        })), i.events.history().filter((({
            eventName: e
        }) => c.includes(e))).map(Ke).forEach((({
            eventName: e,
            data: t,
            id: s
        }) => {
            const i = Ke(t);
            a.push({
                eventName: e,
                data: i,
                id: s
            });
            try {
                r.on(e, t, s)
            } catch (e) {
                e.context = e.context || {}, e.context.adapter = {
                    source: "sas:replayed"
                }, $(e)
            }
        })), {
            status: l.LOADED,
            instance: {
                debug: () => ({
                    events: a
                })
            }
        }
    }

    function ot(e, s, i) {
        var n;
        e.pbstck = e.pbstck || {
            lock: {}
        }, e.pbstck.lock = e.pbstck.lock || {}, e.pbstck.scopeId = i.scopeId;
        const o = {},
            r = `${i.tagId}@${s.gateway}@collector`;
        if (function(e, t) {
                return e[t]
            }(e.pbstck.lock, r)) return;
        ! function(e, t) {
            e[t] = !0
        }(e.pbstck.lock, r);
        const c = new fe;
        let l;
        o.core = c, s.viewabilityEnabled && (l = new Oe(c, e), o.viewability = l);
        const b = new Le(s.gateway, i, [], c, l, s.abTestValues);
        var p;
        o.intake = b, O((e => b.sendError(e)), 1), p = e => b.sendToDatadog(e), N.subscribe(p);
        const h = new Promise(((i, n) => {
            if (s.pbjsVariableName) {
                d("Prebid dropin mode", s.pbjsVariableName);
                const r = {
                        debug: a(),
                        globalName: s.pbjsVariableName
                    },
                    l = function(e, t) {
                        return e[t.globalName] || (e[t.globalName] = {}), e[t.globalName].que || (e[t.globalName].que = []), e[t.globalName].que
                    }(e, r);
                l.push((() => t(this, void 0, void 0, (function*() {
                    var t, s;
                    const a = e[r.globalName],
                        l = null !== (t = Number(a.getConfig("timeoutBuffer"))) && void 0 !== t ? t : Ce,
                        b = null === (s = a.getConfig("currency")) || void 0 === s ? void 0 : s.adServerCurrency;
                    let p;
                    I(b) && (p = b);
                    const h = new he({
                        version: a.version,
                        gracePeriod: l,
                        adServerCurrency: p,
                        pbjsVariableName: r.globalName
                    });
                    o.prebid = h;
                    try {
                        o.prebid = function(e, t, s, i) {
                            const n = e[i.globalName];
                            s.bindIntegration(t);
                            const o = ke(Ae(), t);
                            let r;
                            if (null != n.getEvents) d("[pbjsIntegration] retrieve pbjs events using getEvents on public API"), r = n.getEvents;
                            else {
                                d("[pbjsIntegration] retrieve pbjs events using chunk");
                                const t = e[`${i.globalName}Chunk`];
                                if (void 0 === t) throw new Error("[pbjsIntegration] unable to find pbjs chunk");
                                const s = ye(t, {
                                    on: Function,
                                    getEvents: Function
                                });
                                if (void 0 === s) throw new Error("[pbjsIntegration] unable to use event handler on adapter");
                                r = s.getEvents
                            }
                            return Object.values(Ie).forEach((e => {
                                n.onEvent(e, (t => {
                                    var s;
                                    try {
                                        o.on(e, t)
                                    } catch (i) {
                                        u("[pbjsIntegration] Error on event " + e + ": " + i.message, t), V({
                                            context: Object.assign(Object.assign({}, null !== (s = i.context) && void 0 !== s ? s : {}), {
                                                adapter: {
                                                    version: n.version,
                                                    source: "pbjs:on"
                                                }
                                            }),
                                            message: i.message
                                        })
                                    }
                                }))
                            })), r().forEach((({
                                eventType: e,
                                args: t
                            }) => {
                                var s;
                                try {
                                    o.on(e, t)
                                } catch (i) {
                                    u("[pbjsIntegration] Error on event " + e + ": " + i.message, t), V({
                                        context: Object.assign(Object.assign({}, null !== (s = i.context) && void 0 !== s ? s : {}), {
                                            adapter: {
                                                version: n.version,
                                                source: "pbjs:replayed"
                                            }
                                        }),
                                        message: i.message
                                    })
                                }
                            })), t
                        }(e, h, c, r), i()
                    } catch (e) {
                        return u("Unable to load pbjs integration due to", e), void n()
                    }
                }))))
            }
        }));
        let m, v = [];
        if (s.smartEnabled || s.debug) {
            const t = {
                debug: a(),
                globalName: "sas"
            };
            v = function(e, t) {
                return e[t.globalName] || (e[t.globalName] = {}), e[t.globalName].cmd || (e[t.globalName].cmd = []), e[t.globalName].cmd
            }(e, t), v.push((() => {
                m = nt(e, c, t).instance
            }))
        }
        const f = {
                tagId: i.tagId,
                globalQueue: s.sdk.globalQueue
            },
            g = et(e, c, f);
        if (g.dispatchEvents(), s.debug || a()) {
            c.subscribe({
                onAuction: e => d("controller.onAuction", e),
                onImpression: e => d("controller.onImpression", e)
            });
            const t = new qe(c);
            o.debug = t, O((e => t.addError(e)), 1e3), e.pbstck.debug = e.pbstck.debug || {}, e.pbstck.debug[r] = {
                getEvents: () => t.getEvents(),
                getErrors: () => t.getErrors(),
                sdk: null !== (n = null == g ? void 0 : g.debug()) && void 0 !== n ? n : void 0
            }, (s.smartEnabled || s.debug) && v.push((() => {
                m && (e.pbstck.debug[r].sas = m.debug())
            }))
        }
        return Promise.resolve().finally(), e.pbstck.controllers = e.pbstck.controllers || {}, e.pbstck.controllers[`${s.gateway}@collector`] = o, h.then((() => {
            e.dispatchEvent(new Event(He(`${s.gateway}@collector`, "pubstackMonitoringReady")))
        })), c
    }
    e.bootPubstack = ot, e.pubstackAutoconfig = function(e) {
        var t, s, i, n;
        const o = {
            gateway: null === (t = e.endpoint) || void 0 === t ? void 0 : t.gateway,
            sdk: {
                globalQueue: "pbstckQ"
            },
            debug: !0 === e.debug,
            viewabilityEnabled: e.viewabilityEnabled,
            smartEnabled: null !== (s = e.smartEnabled) && void 0 !== s && s,
            refreshConfigurationUrl: null !== (i = e.refreshConfigurationUrl) && void 0 !== i ? i : "",
            pbjsVariableName: e.pbjsVariableName || "pbjs",
            abTestValues: e.abTestValues
        };
        if (void 0 === o.gateway) return;
        const r = {
            tagId: e.tagId,
            scopeId: e.scopeId,
            country: e.country,
            device: e.device,
            browserName: e.browserName,
            browserVersion: e.browserVersion,
            osName: e.osName,
            osVersion: e.osVersion,
            pbstckVersion: null !== (n = "d8cb7f0") ? n : "unknown",
            customFields: Ye()
        };
        r.tagId && r.scopeId && ot(window, o, r)
    }
}(this.collector = this.collector || {});