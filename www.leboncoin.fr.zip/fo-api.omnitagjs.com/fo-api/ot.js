(function() {
    var omnitagResults = /*OMNITAG*/ [
        [{
            "Disabled": false,
            "Attempt": "b2d689e190bd1cdb59520c16e93f900e",
            "ApiPrefix": "https://fo-api-us-west-2.omnitagjs.com/fo-api",
            "TrackingPrefix": "https://tracking-us-west-2.omnitagjs.com/tracking",
            "DynamicPrefix": "https://fo-dyn.omnitagjs.com/fo-dyn",
            "StaticPrefix": "https://fo-static.omnitagjs.com/fo-static",
            "BlobPrefix": "https://fo-api-us-west-2.omnitagjs.com/fo-api/blobs",
            "SspPrefix": "https://fo-ssp-us-west-2.omnitagjs.com/fo-ssp",
            "VisitorPrefix": "https://visitor-us-west-2.omnitagjs.com/visitor",
            "Trusted": true,
            "Placement": "59520c16e93f900e5c0b1f7d61b470f5",
            "Realm": "edea93ac85495750f5f983ace20d848a",
            "PlacementAccess": "ALL",
            "Site": "d0cbfd844877e105653a9817c2322104",
            "PlacementPassbacks": [{
                "Kind": "PUBLISHER",
                "Data": "\u003cscript\u003e window.postMessage({ key: 'passback',data: 'goPassBack'} , '*');\u003c/script\u003e",
                "Selector": ""
            }],
            "OnEvents": {
                "INVENTORY": [{
                    "Kind": "JAVASCRIPT_CODE",
                    "OncePerAttempt": true,
                    "Guard": "ALWAYS",
                    "Isolated": false,
                    "Url": "",
                    "Code": "dmFyIHdpZHRoID0gcGFyZW50LmRvY3VtZW50LmJvZHkuY2xpZW50V2lkdGg7CnZhciBjb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgiYXlsX3dyYXBwZXIiKTsKCmlmICh3aWR0aCA+PSAiNzUzIikgewpjb250YWluZXIuc2V0QXR0cmlidXRlKCJjbGFzcyIsImRlc2siKTsKfSBlbHNlIGlmICgod2lkdGggPD0gIjc1MiIpICYmICh3aWR0aCA+PSAiNDgwIikpewpjb250YWluZXIuc2V0QXR0cmlidXRlKCJjbGFzcyIsInRhYiIpOwp9IGVsc2UgaWYgKHdpZHRoIDw9ICI0NzkiKSB7CmNvbnRhaW5lci5zZXRBdHRyaWJ1dGUoImNsYXNzIiwibW9iIik7Cn0=",
                    "Partner": null
                }]
            },
            "Lang": "FR",
            "SiteLogo": null,
            "HasSponsorImage": true,
            "ResizeIframe": false,
            "IntegrationConfig": {
                "Kind": "TEMPLATE",
                "Template": {
                    "Placeholders": {
                        "Description": {
                            "Length": 250
                        },
                        "Image": {
                            "Width": 310,
                            "Height": 215,
                            "Lowres": false,
                            "Raw": false
                        },
                        "Sponsor": {
                            "Color": {
                                "R": 0,
                                "G": 0,
                                "B": 0,
                                "A": 0
                            },
                            "Label": true,
                            "WithoutLogo": false
                        }
                    },
                    "Selector": {
                        "Kind": "CSS",
                        "Css": "script[src*='omnitagjs.com'][src*='Placement=59520c16e93f900e5c0b1f7d61b470f5']"
                    },
                    "Insertion": "AFTER",
                    "ClickFormat": true,
                    "Html": "\u003cdiv id=\"{{uid}}\"\u003e \u003cdiv id=\"ayl_wrapper\"\u003e \u003cdiv class=\"{{uid}}-left {{uid}}-img\" \u003e \u003cimg src=\"{{image}}\" style=\"opacity:0;display:block;width:100%;height:auto;\"\u003e \u003c/div\u003e \u003cdiv class=\"{{uid}}-right\"\u003e \u003cspan class=\"{{uid}}-legal\"\u003e{{legal}}\u003c/span\u003e \u003cdiv class=\"{{uid}}-title\"\u003e{{title}} \u003c/div\u003e \u003cdiv class=\"{{uid}}-description\"\u003e{{description}} \u003c/div\u003e \u003cdiv class=\"{{uid}}-cta\"\u003e{{calltoaction}} \u003c/div\u003e \u003cspan class=\"{{uid}}-sponsor\"\u003e{{sponsor}}\u003c/span\u003e \u003c/div\u003e \u003c/div\u003e\u003c/div\u003e",
                    "StyleSheet": "@import url(\"https://fonts.googleapis.com/css2?family=Open+Sans:wght@400\u0026display=swap\");\nbody {\n  background-color: #fff;\n  font-family: \"Open Sans\" , Helvetica , Arial , sans-serif , Arial;\n  font-size: 12px;\n}\n\n/****\n * GLOBAL **/\n\n#{{uid}}{\n    background-color: #FFFFFF;\n  \tcolor : rgb(51, 51, 51)\n  }\n  #{{uid}}, #{{uid}} *{\n    box-sizing:border-box;\n  }\n  #{{uid}}:after{\n    content:'';\n    display:block;\n    clear:both;\n  }\n  .{{uid}}-left{\n    float:left;\n    border-radius:6px;\n  }\n  .{{uid}}-img{\n    background-image: url(\"{{image}}\");\n    background-size: cover;\n    background-position: center;\n  }\n  .{{uid}}-right{\n    float:left;\n    font-size:14px;\n    font-weight:400;\n  }\n\n  .{{uid}}-legal{\n    display: inline-flex;\n    position: initial !important;\n    font-size: 12px !important;\n    box-shadow: none !important;\n    border: 1px solid rgb(51, 51, 51);\n    margin-left: 8px;\n    padding: 2px 8px!important;\n    border-radius: 4px!important;\n    color: rgb(51, 51, 51);\n    visibility: visible !important;\n    margin-left: 0 !important;\n    margin-bottom: 10px;\n  }\n  .{{uid}}-title{\n    font-size: 16px;\n    font-weight: 600;\n    text-align: left;\n    padding-top: 0px;\n    padding-bottom: 0px;\n    padding-left: 0px;\n    padding-right: 15px;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    display: -webkit-box !important;\n    -webkit-line-clamp: 1;\n    -webkit-box-orient: vertical;\n  }\n  \n  .{{uid}}-description{\n    font-size: 14px;\n    text-align: left;\n    padding-top: 10px;\n    padding-bottom: 0px;\n    padding-left: 0px;\n    padding-right: 15px;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    display: -webkit-box !important;\n    -webkit-line-clamp: 2;\n    -webkit-box-orient: vertical;\n  }\n  .{{uid}}-cta{\n    font-size: 14px;\n    font-weight:600;\n    text-decoration:underline;\n    display: block;\n    padding-bottom: 4px;\n    padding-left: 0px;\n    padding-right: 25px;\n    margin-top: 4px;\n    margin-bottom: 0px;\n    margin-left: 0px;\n    margin-right: 8px;\n  }\n  .{{uid}}-sponsor{\n    font-size: 12px;\n    color: #4D4D4D;\n    position:absolute;\n    bottom: 2px;\n    right: 2px;\n  }\n\n#{{uid}} .ayl_native_template_credit img{\n  width:30px !important;\n  height:30px !important;\n}\n\n  /****** \n   * DESK **/\n\n  .desk .{{uid}}-left{\n    width:310px;\n    height: 215px;\n  }\n  .desk .{{uid}}-right{\n    width: calc(100% - 310px);\n    padding: 0px 20px 10px;\n  }\n  \n\n/****** \n   * TAB **/\n\n\t#{{uid}} .tab {\n\t  width:100%;\n    height: 403px;\n  }\n  .tab .{{uid}}-left{\n    padding-top: 0px;\n    padding-bottom: 0px;\n    padding-left: 0px;\n    padding-right: 0px;\n    display: flex;\n    border-radius: 8px;\n    overflow: hidden;\n    margin-bottom: 10px;\n\t  width:100%;\n\t  height:300px;\n  }\n  .tab .{{uid}}-right{\n    width: 100%;\n\t  text-align: left;\n    padding-bottom: 0px;\n    padding-left: 0px;\n    padding-right: 0px;\n    overflow: hidden;\n  }\n\n\n/****** \n   * MOB **/\n\n  #{{uid}} .mob {\n\t  width:100%;\n    height: 350px;\n  }\n\n  .mob .{{uid}}-left{\n    padding-top: 0px;\n    padding-bottom: 0px;\n    padding-left: 0px;\n    padding-right: 0px;\n    display: flex;\n    border-radius: 8px;\n    overflow: hidden;\n    margin-bottom: 10px;\n\t  width:100%;\n\t  height:200px;\n  }\n  .mob .{{uid}}-right{\n    width: 100%;\n\t  text-align: left;\n    padding-bottom: 0px;\n    padding-left: 0px;\n    padding-right: 0px;\n    overflow: hidden;\n  }\n\n  "
                }
            },
            "Legal": "Sponsorisé",
            "ForcedCampaign": "",
            "ForcedTrack": "",
            "ForcedCreative": "",
            "ForcedSource": "",
            "DisplayMode": "UNSET",
            "InviewExpand": false,
            "Campaign": "e2a82912438eaa7d2f234f778f82c274",
            "CampaignAccess": "ALL",
            "CampaignKind": "AD_TRAFFIC",
            "DataSource": "SSP",
            "DataSourceUrl": "",
            "DataSourceOnEventsIsolated": false,
            "DataSourceWithoutCookie": false,
            "Opener": "REDIRECT",
            "PerformUITriggers": ["CLICK"],
            "RedirectionTarget": "TAB"
        }]
    ] /*OMNITAG*/ ;

    var insertAds = function insertAds() {
        if (window.AylTag) {
            window.AylTag.Insert(omnitagResults);
        }
        document.removeEventListener('ayl:tag_loaded', insertAds);
    };

    if (!window.AylTag) {
        // Listen to load
        document.addEventListener('ayl:tag_loaded', insertAds);

        // Load script if not already loading
        if (!window.AylTagLoading) {
            window.AylTagLoading = true;

            var sc = document.createElement('script');
            sc.type = 'text/javascript';
            sc.crossOrigin = "anonymous";
            sc.async = "true";
            sc.src = 'https://fo-static.omnitagjs.com/fo-static/ot_multi_template.js';
            sc.className = 'ayl-injected-element';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(sc, s);

            sc.addEventListener('load', function() {
                var evt = document.createEvent('Event');
                evt.initEvent('ayl:tag_loaded', true, true);
                document.dispatchEvent(evt);
                window.AylTagLoading = false;
            });
        }
    } else {
        insertAds();
    }
})();