(function() {
    var l, ba;

    function ca(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }
    var da = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function ea(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var fa = ea(this),
        ha = "function" === typeof Symbol && "symbol" === typeof Symbol("x"),
        q = {},
        ia = {};

    function u(a, b, c) {
        if (!c || null != a) {
            c = ia[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        }
    }

    function v(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in q ? f = q : f = fa;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = ha && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? da(q, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === ia[d] && (a = 1E9 * Math.random() >>> 0, ia[d] = ha ? fa.Symbol(d) : "$jscp$" + a + "$" + d), da(f, ia[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    v("Symbol", function(a) {
        function b(f) {
            if (this instanceof b) throw new TypeError("Symbol is not a constructor");
            return new c(d + (f || "") + "_" + e++, f)
        }

        function c(f, g) {
            this.g = f;
            da(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.g
        };
        var d = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            e = 0;
        return b
    }, "es6");
    v("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, q.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = fa[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && da(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ja(ca(this))
                }
            })
        }
        return a
    }, "es6");

    function ja(a) {
        a = {
            next: a
        };
        a[u(q.Symbol, "iterator")] = function() {
            return this
        };
        return a
    }

    function ka(a) {
        return a.raw = a
    }

    function la(a) {
        var b = "undefined" != typeof q.Symbol && u(q.Symbol, "iterator") && a[u(q.Symbol, "iterator")];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: ca(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function pa(a) {
        for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
        return c
    }
    var qa = ha && "function" == typeof u(Object, "assign") ? u(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
        }
        return a
    };
    v("Object.assign", function(a) {
        return a || qa
    }, "es6");

    function ra() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }

    function sa(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    }
    v("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = sa(this, b, "endsWith");
            void 0 === c && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; 0 < e && 0 < c;)
                if (d[--c] != b[--e]) return !1;
            return 0 >= e
        }
    }, "es6");

    function ta(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[u(q.Symbol, "iterator")] = function() {
            return e
        };
        return e
    }
    v("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return ta(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    v("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return ta(this, function(b) {
                return b
            })
        }
    }, "es6");
    v("globalThis", function(a) {
        return a || fa
    }, "es_2020");
    v("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    v("Array.prototype.values", function(a) {
        return a ? a : function() {
            return ta(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    v("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    v("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || u(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    v("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== sa(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    v("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var w = this || self;

    function ua(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.ba = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.X = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    }

    function va(a) {
        return a
    };

    function y(a) {
        a = parseFloat(a);
        return isNaN(a) || 1 < a || 0 > a ? 0 : a
    };

    function wa(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, wa);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        void 0 !== b && (this.cause = b)
    }
    ua(wa, Error);
    wa.prototype.name = "CustomError";

    function xa(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        wa.call(this, c + a[d])
    }
    ua(xa, wa);
    xa.prototype.name = "AssertionError";

    function A(a, b) {
        this.h = a === ya && b || "";
        this.F = za
    }
    A.prototype.j = !0;
    A.prototype.g = function() {
        return this.h
    };

    function Aa(a) {
        return a instanceof A && a.constructor === A && a.F === za ? a.h : "type_error:Const"
    }
    var za = {},
        ya = {};

    function Ba(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var Ca = Array.prototype.indexOf ? function(a, b) {
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        Da = Array.prototype.some ? function(a, b) {
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };
    var Ea, Fa;
    a: {
        for (var Ga = ["CLOSURE_FLAGS"], Ha = w, Ka = 0; Ka < Ga.length; Ka++)
            if (Ha = Ha[Ga[Ka]], null == Ha) {
                Fa = null;
                break a
            }
        Fa = Ha
    }
    var La = Fa && Fa[610401301];
    Ea = null != La ? La : !1;

    function Ma(a) {
        if (!Na.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(Oa, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(Pa, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(Qa, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(Ra, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(Sa, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(Ta, "&#0;"));
        return a
    }
    var Oa = /&/g,
        Pa = /</g,
        Qa = />/g,
        Ra = /"/g,
        Sa = /'/g,
        Ta = /\x00/g,
        Na = /[\x00&<>"']/;

    function Ua() {
        var a = w.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Va, Wa = w.navigator;
    Va = Wa ? Wa.userAgentData || null : null;

    function Xa(a) {
        return Ea ? Va ? Va.brands.some(function(b) {
            return (b = b.brand) && -1 != b.indexOf(a)
        }) : !1 : !1
    }

    function C(a) {
        return -1 != Ua().indexOf(a)
    };

    function D() {
        return Ea ? !!Va && 0 < Va.brands.length : !1
    }

    function Ya() {
        return D() ? Xa("Chromium") : (C("Chrome") || C("CriOS")) && !(D() ? 0 : C("Edge")) || C("Silk")
    };

    function Za(a) {
        Za[" "](a);
        return a
    }
    Za[" "] = function() {};
    var $a = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var ab;

    function bb() {
        if (void 0 === ab) {
            var a = null,
                b = w.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: va,
                        createScript: va,
                        createScriptURL: va
                    })
                } catch (c) {
                    w.console && w.console.error(c.message)
                }
                ab = a
            } else ab = a
        }
        return ab
    };

    function E(a) {
        this.h = a
    }
    E.prototype.toString = function() {
        return this.h + ""
    };
    E.prototype.j = !0;
    E.prototype.g = function() {
        return this.h.toString()
    };

    function cb(a) {
        return a instanceof E && a.constructor === E ? a.h : "type_error:TrustedResourceUrl"
    }
    var db = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        eb = {};

    function fb(a) {
        var b = bb();
        a = b ? b.createScriptURL(a) : a;
        return new E(a, eb)
    }

    function gb(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };

    function F(a) {
        this.h = a
    }
    F.prototype.toString = function() {
        return this.h.toString()
    };
    F.prototype.j = !0;
    F.prototype.g = function() {
        return this.h.toString()
    };

    function hb(a) {
        return a instanceof F && a.constructor === F ? a.h : "type_error:SafeUrl"
    }
    var ib = /^data:(.*);base64,[a-z0-9+\/]+=*$/i,
        jb = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;

    function kb(a) {
        if (a instanceof F) return a;
        a = "object" == typeof a && a.j ? a.g() : String(a);
        jb.test(a) ? a = new F(a, lb) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(ib) ? new F(a, lb) : null);
        return a
    }
    var lb = {},
        mb = new F("about:invalid#zClosurez", lb);
    var ob = {};

    function G(a) {
        this.h = a;
        this.j = !0
    }
    G.prototype.g = function() {
        return this.h
    };
    G.prototype.toString = function() {
        return this.h.toString()
    };
    var pb = new G("", ob);

    function qb(a) {
        if (a instanceof F) return 'url("' + hb(a).replace(/</g, "%3c").replace(/[\\"]/g, "\\$&") + '")';
        if (a instanceof A) a = Aa(a);
        else {
            a = String(a);
            var b = a.replace(rb, "$1").replace(rb, "$1").replace(sb, "url");
            if (tb.test(b)) {
                if (b = !ub.test(a)) {
                    for (var c = b = !0, d = 0; d < a.length; d++) {
                        var e = a.charAt(d);
                        "'" == e && c ? b = !b : '"' == e && b && (c = !c)
                    }
                    b = b && c && vb(a)
                }
                a = b ? wb(a) : "zClosurez"
            } else a = "zClosurez"
        }
        if (/[{;}]/.test(a)) throw new xa("Value does not allow [{;}], got: %s.", [a]);
        return a
    }

    function vb(a) {
        for (var b = !0, c = /^[-_a-zA-Z0-9]$/, d = 0; d < a.length; d++) {
            var e = a.charAt(d);
            if ("]" == e) {
                if (b) return !1;
                b = !0
            } else if ("[" == e) {
                if (!b) return !1;
                b = !1
            } else if (!b && !c.test(e)) return !1
        }
        return b
    }
    var tb = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$"),
        sb = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g"),
        rb = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g"),
        ub = /\/\*/;

    function wb(a) {
        return a.replace(sb, function(b, c, d, e) {
            var f = "";
            d = d.replace(/^(['"])(.*)\1$/, function(g, h, k) {
                f = h;
                return k
            });
            b = (kb(d) || mb).g();
            return c + f + b + f + e
        })
    };
    var xb = {};

    function H(a) {
        this.h = a;
        this.j = !0
    }
    H.prototype.g = function() {
        return this.h.toString()
    };
    H.prototype.toString = function() {
        return this.h.toString()
    };

    function yb(a) {
        return a instanceof H && a.constructor === H ? a.h : "type_error:SafeHtml"
    }

    function zb(a) {
        return a instanceof H ? a : Ab(Ma("object" == typeof a && a.j ? a.g() : String(a)))
    }

    function Bb(a) {
        function b(e) {
            Array.isArray(e) ? e.forEach(b) : (e = zb(e), d.push(yb(e).toString()))
        }
        var c = zb(Cb),
            d = [];
        a.forEach(b);
        return Ab(d.join(yb(c).toString()))
    }

    function Db(a) {
        return Bb(Array.prototype.slice.call(arguments))
    }

    function Ab(a) {
        var b = bb();
        a = b ? b.createHTML(a) : a;
        return new H(a, xb)
    }
    var Eb = /^[a-zA-Z0-9-]+$/,
        Fb = {
            action: !0,
            cite: !0,
            data: !0,
            formaction: !0,
            href: !0,
            manifest: !0,
            poster: !0,
            src: !0
        },
        Gb = {
            APPLET: !0,
            BASE: !0,
            EMBED: !0,
            IFRAME: !0,
            LINK: !0,
            MATH: !0,
            META: !0,
            OBJECT: !0,
            SCRIPT: !0,
            STYLE: !0,
            SVG: !0,
            TEMPLATE: !0
        },
        Cb = new H(w.trustedTypes && w.trustedTypes.emptyHTML || "", xb);
    var Hb = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Ib(a) {
        var b = a.match(Hb);
        a = b[5];
        var c = b[6];
        b = b[7];
        var d = "";
        a && (d += a);
        c && (d += "?" + c);
        b && (d += "#" + b);
        return d
    }

    function Jb(a, b, c, d) {
        for (var e = c.length; 0 <= (b = a.indexOf(c, b)) && b < d;) {
            var f = a.charCodeAt(b - 1);
            if (38 == f || 63 == f)
                if (f = a.charCodeAt(b + e), !f || 61 == f || 38 == f || 35 == f) return b;
            b += e + 1
        }
        return -1
    }
    var Kb = /#|$/;

    function Lb(a, b) {
        var c = a.search(Kb),
            d = Jb(a, 0, b, c);
        if (0 > d) return null;
        var e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    }
    var Mb = /[?&]($|#)/;

    function J(a, b, c) {
        for (var d = a.search(Kb), e = 0, f, g = []; 0 <= (f = Jb(a, e, b, d));) g.push(a.substring(e, f)), e = Math.min(a.indexOf("&", f) + 1 || d, d);
        g.push(a.slice(e));
        a = g.join("").replace(Mb, "$1");
        c = null != c ? "=" + encodeURIComponent(String(c)) : "";
        (b += c) ? (c = a.indexOf("#"), 0 > c && (c = a.length), d = a.indexOf("?"), 0 > d || d > c ? (d = c, e = "") : e = a.substring(d + 1, c), c = [a.slice(0, d), e, a.slice(c)], a = c[1], c[1] = b ? a ? a + "&" + b : b : a, b = c[0] + (c[1] ? "?" + c[1] : "") + c[2]) : b = a;
        return b
    };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function Nb(a, b) {
        a.src = cb(b);
        var c, d;
        (c = (b = null == (d = (c = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : d.call(c, "script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", c)
    };

    function Ob(a, b) {
        a.write(yb(b))
    };

    function Pb(a) {
        try {
            var b;
            if (b = !!a && null != a.location.href) a: {
                try {
                    Za(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch (c) {
            return !1
        }
    }

    function Qb() {
        if (!q.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            q.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    }

    function Rb(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }
    var Tb = Ba(function() {
            return Da(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], Sb) || 1E-4 > Math.random()
        }),
        Ub = Ba(function() {
            return Sb("MSIE")
        });

    function Sb(a) {
        return -1 != Ua().indexOf(a)
    }

    function L(a) {
        return /^true$/.test(a)
    }

    function Vb(a, b) {
        if (!a || !b.head) return null;
        var c = Wb("META");
        b.head.appendChild(c);
        c.httpEquiv = "origin-trial";
        c.content = a;
        return c
    }

    function Wb(a, b) {
        b = void 0 === b ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    var Xb = y("0.20"),
        Yb = y("0.002"),
        Zb = y("1.0"),
        $b = y("0.1"),
        ac = y("0.00"),
        bc = y("0.00"),
        cc = L("false"),
        dc = L("true"),
        ec = L("true"),
        fc = L("true"),
        gc = L("true"),
        hc = L("true");
    var ic = null;

    function jc() {
        if (null === ic) {
            ic = "";
            try {
                var a = "";
                try {
                    a = w.top.location.hash
                } catch (c) {
                    a = w.location.hash
                }
                if (a) {
                    var b = a.match(/\bdeid=([\d,]+)/);
                    ic = b ? b[1] : ""
                }
            } catch (c) {}
        }
        return ic
    }

    function M(a, b, c) {
        var d = N;
        if (c ? d.g.hasOwnProperty(c) && "" == d.g[c] : 1) {
            var e;
            e = (e = jc()) ? (e = e.match(new RegExp("\\b(" + a.join("|") + ")\\b"))) ? e[0] : null : null;
            if (e) a = e;
            else a: {
                if (!Ub() && !Tb() && (e = Math.random(), e < b)) {
                    e = Qb();
                    a = a[Math.floor(e * a.length)];
                    break a
                }
                a = null
            }
            a && "" != a && (c ? d.g.hasOwnProperty(c) && (d.g[c] = a) : d.h[a] = !0)
        }
    }

    function O(a) {
        var b = N;
        return b.g.hasOwnProperty(a) ? b.g[a] : ""
    }

    function kc() {
        var a = N,
            b = [];
        Rb(a.h, function(c, d) {
            b.push(d)
        });
        Rb(a.g, function(c) {
            "" != c && b.push(c)
        });
        return b
    };
    var lc = {
            M: 2,
            U: 13,
            T: 14,
            P: 16,
            O: 17,
            N: 18,
            L: 19,
            W: 20,
            V: 21,
            K: 22
        },
        N = null;

    function mc() {
        return !!N && ("466465926" == O(20) || "466465925" == O(20))
    }

    function nc() {
        return !!N && "592230571" == O(16)
    }

    function oc() {
        return !!N && ("512247839" == O(22) || "512247838" == O(22))
    };

    function pc(a) {
        var b = void 0 === b ? w : b;
        var c, d;
        return (null == (c = b.performance) ? void 0 : null == (d = c.timing) ? void 0 : d[a]) || 0
    };

    function qc(a) {
        var b = "s";
        if (a.s && a.hasOwnProperty(b)) return a.s;
        b = new a;
        return a.s = b
    };
    var rc = {
        R: 0,
        H: 1,
        S: 2,
        J: 3,
        I: 4
    };

    function sc() {
        this.g = {}
    }

    function tc(a, b, c) {
        "number" === typeof c && 0 < c && (a.g[b] = Math.round(c))
    }

    function uc(a) {
        var b = qc(sc);
        var c = void 0 === c ? w : c;
        c = c.performance;
        tc(b, a, c && c.now ? c.now() : null)
    }

    function vc() {
        function a() {
            return tc(b, 0, pc("loadEventStart") - pc("navigationStart"))
        }
        var b = qc(sc);
        0 != pc("loadEventStart") ? a() : window.addEventListener("load", a)
    }

    function wc() {
        var a = qc(sc);
        return u(Object, "values").call(Object, rc).map(function(b) {
            return [b, a.g[b] || 0]
        })
    };
    var xc = L("false");
    var yc = {};

    function zc(a) {
        yc.TAGGING = yc.TAGGING || [];
        yc.TAGGING[a] = !0
    };

    function P(a) {
        return "string" === typeof a
    }
    var Ac = Array.isArray;

    function Bc(a, b) {
        if (a && Ac(a))
            for (var c = 0; c < a.length; c++)
                if (a[c] && b(a[c])) return a[c]
    }

    function Cc(a, b) {
        for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
    };

    function Dc(a) {
        a = Ec(a);
        return Ab(a)
    }

    function Ec(a) {
        return null === a ? "null" : void 0 === a ? "undefined" : a
    };
    var Q = window,
        R = document;

    function Fc(a, b) {
        b && (a.addEventListener ? a.onload = b : a.onreadystatechange = function() {
            a.readyState in {
                loaded: 1,
                complete: 1
            } && (a.onreadystatechange = null, b())
        })
    }
    var Gc = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        Hc = {
            onload: 1,
            src: 1,
            width: 1,
            height: 1,
            style: 1
        };

    function Ic(a, b, c) {
        b && Cc(b, function(d, e) {
            d = d.toLowerCase();
            c.hasOwnProperty(d) || a.setAttribute(d, e)
        })
    }

    function Jc(a, b, c, d) {
        var e = R.createElement("script");
        Ic(e, c, Gc);
        e.type = "text/javascript";
        e.async = c && !1 === c.async ? !1 : !0;
        a = fb(Ec(a));
        Nb(e, a);
        Fc(e, b);
        d ? d.appendChild(e) : (b = R.getElementsByTagName("script")[0] || R.body || R.head, b.parentNode.insertBefore(e, b))
    }

    function Kc(a, b, c) {
        var d = !1;
        d = void 0 === d ? !0 : d;
        var e = !1;
        c || (c = R.createElement("iframe"), e = !0);
        Ic(c, void 0, Hc);
        d && (c.height = "0", c.width = "0", c.style.display = "none", c.style.visibility = "hidden");
        e && (d = R.body && R.body.lastChild || R.body || R.head, d.parentNode.insertBefore(c, d));
        Fc(c, b);
        void 0 !== a && (c.src = a)
    };

    function Lc() {
        var a = void 0 === a ? document : a;
        var b;
        return !(null == (b = a.featurePolicy) || !(ba = b.allowedFeatures(), u(ba, "includes")).call(ba, "attribution-reporting"))
    };

    function Mc(a, b, c) {
        a = Nc(a, !0);
        if (a[b]) return !1;
        a[b] = [];
        a[b][0] = c;
        return !0
    }

    function Nc(a, b) {
        var c = a.GooglebQhCsO;
        c || (c = {}, b && (a.GooglebQhCsO = c));
        return c
    };
    !C("Android") || Ya();
    Ya();
    C("Safari") && (Ya() || (D() ? 0 : C("Coast")) || (D() ? 0 : C("Opera")) || (D() ? 0 : C("Edge")) || (D() ? Xa("Microsoft Edge") : C("Edg/")) || D() && Xa("Opera"));
    var Pc = {},
        Qc = null;

    function Rc(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            255 < e && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        a = 4;
        void 0 === a && (a = 0);
        if (!Qc)
            for (Qc = {}, c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), d = ["+/=", "+/", "-_=", "-_.", "-_"], e = 0; 5 > e; e++) {
                var f = c.concat(d[e].split(""));
                Pc[e] = f;
                for (var g = 0; g < f.length; g++) {
                    var h = f[g];
                    void 0 === Qc[h] && (Qc[h] = g)
                }
            }
        a = Pc[a];
        c = Array(Math.floor(b.length / 3));
        d = a[64] || "";
        for (e = f = 0; f < b.length - 2; f += 3) {
            var k = b[f],
                m = b[f + 1];
            h = b[f + 2];
            g = a[k >> 2];
            k = a[(k &
                3) << 4 | m >> 4];
            m = a[(m & 15) << 2 | h >> 6];
            h = a[h & 63];
            c[e++] = g + k + m + h
        }
        g = 0;
        h = d;
        switch (b.length - f) {
            case 2:
                g = b[f + 1], h = a[(g & 15) << 2] || d;
            case 1:
                b = b[f], c[e] = a[b >> 2] + a[(b & 3) << 4 | g >> 4] + h + d
        }
        return c.join("")
    };

    function Sc(a, b, c, d, e) {
        var f = Lb(c, "fmt");
        if (d) {
            var g = Lb(c, "random"),
                h = Lb(c, "label") || "";
            if (!g) return !1;
            g = Rc(decodeURIComponent(h.replace(/\+/g, " ")) + ":" + decodeURIComponent(g.replace(/\+/g, " ")));
            if (!Mc(a, g, d)) return !1
        }
        f && 4 != f && (c = J(c, "rfmt", f));
        c = J(c, "fmt", 4);
        Jc(c, function() {
            a.google_noFurtherRedirects && d && d.call && (a.google_noFurtherRedirects = null, d())
        }, e, b.getElementsByTagName("script")[0].parentElement || void 0);
        return !0
    };
    var Tc = new function(a, b) {
        this.g = a;
        this.defaultValue = void 0 === b ? !1 : b
    }(1933);

    function Uc() {
        var a = {};
        this.g = function() {
            var b = Tc.g,
                c = Tc.defaultValue;
            return null != a[b] ? a[b] : c
        }
    };
    var Vc = [];

    function Wc(a) {
        return void 0 == Vc[a] ? !1 : Vc[a]
    };
    var Xc = {},
        Yc = {
            ad_storage: !1,
            ad_user_data: !1,
            ad_personalization: !1
        };

    function Zc() {
        var a = {};
        var b = Q.google_tag_data;
        Q.google_tag_data = void 0 === b ? a : b;
        a = Q.google_tag_data;
        return a.ics = a.ics || new $c
    }

    function $c() {
        this.entries = {};
        this.cps = {};
        this.waitPeriodTimedOut = this.wasSetLate = this.accessedAny = this.accessedDefault = this.usedSetCps = this.usedImplicit = this.usedUpdate = this.usedDefault = this.usedDeclare = this.active = !1;
        this.g = []
    }
    l = $c.prototype;
    l.default = function(a, b, c, d, e, f) {
        this.usedDefault || !this.accessedDefault && !this.accessedAny || (this.wasSetLate = !0);
        this.usedDefault = this.active = !0;
        zc(19);
        void 0 == b ? zc(18) : ad(this, a, "granted" === b, c, d, e, f)
    };
    l.waitForUpdate = function(a, b) {
        for (var c = 0; c < a.length; c++) ad(this, a[c], void 0, void 0, "", "", b)
    };

    function ad(a, b, c, d, e, f, g) {
        var h = u(a, "entries"),
            k = h[b] || {},
            m = k.region;
        d = d && P(d) ? d.toUpperCase() : void 0;
        e = e.toUpperCase();
        f = f.toUpperCase();
        if (bd(d, m, e, f)) {
            f = !!(g && 0 < g && void 0 === k.update);
            var p = {
                region: d,
                declare_region: k.declare_region,
                implicit: k.implicit,
                default: void 0 !== c ? c : k.default,
                declare: k.declare,
                update: k.update,
                quiet: f
            };
            if ("" !== e || !1 !== k.default) h[b] = p;
            f && Q.setTimeout(function() {
                h[b] === p && p.quiet && (zc(2), a.waitPeriodTimedOut = !0, a.clearTimeout(b, void 0), a.notifyListeners())
            }, g)
        }
    }
    l.clearTimeout = function(a, b) {
        var c = [a];
        for (d in Xc) Xc.hasOwnProperty(d) && Xc[d] === a && c.push(d);
        var d = u(this, "entries")[a] || {};
        a = this.getConsentState(a);
        if (d.quiet)
            for (d.quiet = !1, c = la(c), b = c.next(); !b.done; b = c.next()) cd(this, b.value);
        else if (void 0 !== b && a !== b)
            for (c = la(c), b = c.next(); !b.done; b = c.next()) cd(this, b.value)
    };
    l.update = function(a, b) {
        this.usedDefault || this.usedUpdate || !this.accessedAny || (this.wasSetLate = !0);
        this.usedUpdate = this.active = !0;
        if (void 0 != b) {
            var c = this.getConsentState(a),
                d = u(this, "entries");
            (d[a] = d[a] || {}).update = "granted" === b;
            this.clearTimeout(a, c)
        }
    };
    l.declare = function(a, b, c, d, e) {
        this.usedDeclare = this.active = !0;
        var f = u(this, "entries"),
            g = f[a] || {},
            h = g.declare_region;
        c = c && P(c) ? c.toUpperCase() : void 0;
        d = d.toUpperCase();
        e = e.toUpperCase();
        bd(c, h, d, e) && (b = {
            region: g.region,
            declare_region: c,
            declare: "granted" === b,
            implicit: g.implicit,
            default: g.default,
            update: g.update,
            quiet: g.quiet
        }, "" !== d || !1 !== g.declare) && (f[a] = b)
    };
    l.implicit = function(a, b) {
        this.usedImplicit = !0;
        var c = u(this, "entries");
        a = c[a] = c[a] || {};
        !1 !== a.implicit && (a.implicit = "granted" === b)
    };
    l.getConsentState = function(a) {
        var b = u(this, "entries"),
            c = b[a] || {},
            d = c.update;
        if (void 0 !== d) return d ? 1 : 2;
        d = c.default;
        if (void 0 !== d) return d ? 1 : 2;
        if (Xc.hasOwnProperty(a)) {
            b = b[Xc[a]] || {};
            d = b.update;
            if (void 0 !== d) return d ? 1 : 2;
            d = b.default;
            if (void 0 !== d) return d ? 1 : 2
        }
        d = c.declare;
        if (void 0 !== d) return d ? 1 : 2;
        if (Wc(3)) {
            d = c.implicit;
            if (void 0 !== d) return d ? 3 : 4;
            if (Yc.hasOwnProperty(a)) return Yc[a] ? 3 : 4
        }
        return 0
    };
    l.setCps = function(a, b, c, d, e) {
        a: {
            var f = this.cps,
                g = f[a] || {},
                h = g.region;c = c && P(c) ? c.toUpperCase() : void 0;d = d.toUpperCase();
            if (bd(c, h, d, e.toUpperCase()) && (b = {
                    enabled: "granted" === b,
                    region: c
                }, "" !== d || !1 !== g.enabled)) {
                f[a] = b;
                a = !0;
                break a
            }
            a = !1
        }
        a && (this.usedSetCps = !0)
    };
    l.addListener = function(a, b) {
        this.g.push({
            consentTypes: a,
            B: b
        })
    };

    function cd(a, b) {
        for (var c = 0; c < a.g.length; ++c) {
            var d = a.g[c];
            Ac(d.consentTypes) && -1 !== d.consentTypes.indexOf(b) && (d.A = !0)
        }
    }
    l.notifyListeners = function(a, b) {
        for (var c = 0; c < this.g.length; ++c) {
            var d = this.g[c];
            if (d.A) {
                d.A = !1;
                try {
                    d.B({
                        consentEventId: a,
                        consentPriorityId: b
                    })
                } catch (e) {}
            }
        }
    };

    function bd(a, b, c, d) {
        return "" === c || a === d ? !0 : a === c ? b !== d : !a && !b
    }

    function dd(a) {
        var b = Zc();
        b.accessedAny = !0;
        return (P(a) ? [a] : a).every(function(c) {
            switch (b.getConsentState(c)) {
                case 1:
                case 3:
                    return !0;
                case 2:
                case 4:
                    return !1;
                default:
                    return !0
            }
        })
    }

    function ed(a) {
        var b = Zc();
        b.accessedAny = !0;
        return !(u(b, "entries")[a] || {}).quiet
    }

    function fd(a, b) {
        Zc().addListener(a, b)
    }

    function gd(a) {
        function b() {
            for (var e = 0; e < c.length; e++)
                if (!ed(c[e])) return !0;
            return !1
        }
        var c = T();
        if (b()) {
            var d = !1;
            fd(c, function(e) {
                d || b() || (d = !0, a(e))
            })
        } else a({})
    }

    function hd(a) {
        function b() {
            for (var g = [], h = 0; h < e.length; h++) {
                var k = e[h];
                dd(k) && !f[k] && g.push(k)
            }
            return g
        }

        function c(g) {
            for (var h = 0; h < g.length; h++) f[g[h]] = !0
        }
        var d = T(),
            e = P(d) ? [d] : d,
            f = {};
        d = b();
        d.length !== e.length && (c(d), fd(e, function(g) {
            function h(p) {
                0 !== p.length && (c(p), g.consentTypes = p, a(g))
            }
            var k = b();
            if (0 !== k.length) {
                var m = u(Object, "keys").call(Object, f).length;
                k.length + m >= e.length ? h(k) : Q.setTimeout(function() {
                    h(b())
                }, 500)
            }
        }))
    };

    function id(a, b, c, d) {
        if (jd(d)) {
            d = [];
            b = String(b || kd()).split(";");
            for (var e = 0; e < b.length; e++) {
                var f = b[e].split("="),
                    g = f[0].replace(/^\s*|\s*$/g, "");
                g && g == a && ((f = f.slice(1).join("=").replace(/^\s*|\s*$/g, "")) && c && (f = decodeURIComponent(f)), d.push(f))
            }
            a = d
        } else a = [];
        return a
    }

    function ld(a, b, c, d) {
        var e = kd(),
            f = window;
        "null" !== f.origin && (f.document.cookie = a);
        a = kd();
        return e != a || void 0 != c && 0 <= id(b, a, !1, d).indexOf(c)
    }

    function md(a, b, c) {
        function d(n, r, I) {
            if (null == I) return delete g[r], n;
            g[r] = I;
            return n + "; " + r + "=" + I
        }

        function e(n, r) {
            if (null == r) return delete g[r], n;
            g[r] = !0;
            return n + "; " + r
        }
        if (jd(c.l)) {
            if (void 0 == b) var f = a + "=deleted; expires=" + (new Date(0)).toUTCString();
            else c.encode && (b = encodeURIComponent(b)), b = nd(b), f = a + "=" + b;
            var g = {};
            f = d(f, "path", c.path);
            if (c.expires instanceof Date) var h = c.expires.toUTCString();
            else null != c.expires && (h = c.expires);
            f = d(f, "expires", h);
            f = d(f, "max-age", c.Y);
            f = d(f, "samesite", c.Z);
            c.aa &&
                (f = e(f, "secure"));
            if ((h = c.domain) && "auto" === h.toLowerCase()) {
                h = od();
                for (var k = 0; k < h.length; ++k) {
                    var m = "none" !== h[k] ? h[k] : void 0,
                        p = d(f, "domain", m);
                    p = e(p, c.flags);
                    if (!pd(m, c.path) && ld(p, a, b, c.l)) break
                }
            } else h && "none" !== h.toLowerCase() && (f = d(f, "domain", h)), f = e(f, c.flags), pd(h, c.path) || ld(f, a, b, c.l)
        }
    }

    function qd(a, b, c) {
        null == c.path && (c.path = "/");
        c.domain || (c.domain = "auto");
        md(a, b, c)
    }

    function nd(a) {
        a && 1200 < a.length && (a = a.substring(0, 1200));
        return a
    }
    var rd = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        sd = /(^|\.)doubleclick\.net$/i;

    function pd(a, b) {
        return sd.test(window.document.location.hostname) || "/" === b && rd.test(a)
    }

    function kd() {
        return "null" !== window.origin ? window.document.cookie : ""
    }

    function od() {
        var a = [],
            b = window.document.location.hostname.split(".");
        if (4 === b.length) {
            var c = b[b.length - 1];
            if (parseInt(c, 10).toString() === c) return ["none"]
        }
        for (c = b.length - 2; 0 <= c; c--) a.push(b.slice(c).join("."));
        b = window.document.location.hostname;
        sd.test(b) || rd.test(b) || a.push("none");
        return a
    }

    function jd(a) {
        return a && qc(Uc).g() ? (P(a) ? [a] : a).every(function(b) {
            return ed(b) && dd(b)
        }) : !0
    };

    function td(a, b) {
        var c, d = Number(null != a.v ? a.v : void 0);
        0 !== d && (c = new Date((b || (new Date(Date.now())).getTime()) + 1E3 * (d || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !0,
            expires: c,
            l: void 0
        }
    };

    function ud(a) {
        var b = [],
            c = R.cookie.split(";");
        a = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$");
        for (var d = 0; d < c.length; d++) {
            var e = c[d].match(a);
            e && b.push({
                u: e[1],
                value: e[2],
                timestamp: Number(e[2].split(".")[1]) || 0
            })
        }
        b.sort(function(f, g) {
            return g.timestamp - f.timestamp
        });
        return b
    }

    function vd(a, b) {
        a = ud(a);
        var c = {};
        if (!a || !a.length) return c;
        for (var d = 0; d < a.length; d++) {
            var e = a[d].value.split(".");
            if (!("1" !== e[0] || b && 3 > e.length || !b && 3 !== e.length) && Number(e[1])) {
                c[a[d].u] || (c[a[d].u] = []);
                var f = {
                    version: e[0],
                    timestamp: 1E3 * Number(e[1]),
                    i: e[2]
                };
                b && 3 < e.length && (f.labels = e.slice(3));
                c[a[d].u].push(f)
            }
        }
        return c
    };
    var wd = /:[0-9]+$/;

    function xd(a, b) {
        function c(f) {
            return Wc(10) ? decodeURIComponent(f.replace(/\+/g, " ")) : decodeURIComponent(f).replace(/\+/g, " ")
        }
        a = la(a.split("&"));
        for (var d = a.next(); !d.done; d = a.next()) {
            var e = la(d.value.split("="));
            d = e.next().value;
            e = pa(e);
            if (c(d) === b) return c(e.join("="))
        }
    }

    function yd(a, b) {
        var c = "query";
        var d = (d = a.protocol) ? d.replace(":", "").toLowerCase() : "";
        c && (c = String(c).toLowerCase());
        switch (c) {
            case "url_no_fragment":
                b = "";
                a && a.href && (b = a.href.indexOf("#"), b = 0 > b ? a.href : a.href.substr(0, b));
                a = b;
                break;
            case "protocol":
                a = d;
                break;
            case "host":
                a = a.hostname.replace(wd, "").toLowerCase();
                break;
            case "port":
                a = String(Number(a.port) || ("http" === d ? 80 : "https" === d ? 443 : ""));
                break;
            case "path":
                a.pathname || a.hostname || zc(1);
                a = "/" === a.pathname.charAt(0) ? a.pathname : "/" + a.pathname;
                a = a.split("/");
                0 <= [].indexOf(a[a.length - 1]) && (a[a.length - 1] = "");
                a = a.join("/");
                break;
            case "query":
                a = a.search.replace("?", "");
                b && (a = xd(a, b));
                break;
            case "extension":
                a = a.pathname.split(".");
                a = 1 < a.length ? a[a.length - 1] : "";
                a = a.split("/")[0];
                break;
            case "fragment":
                a = a.hash.replace("#", "");
                break;
            default:
                a = a && a.href
        }
        return a
    };
    var zd = /^\w+$/,
        Ad = /^[\w-]+$/,
        Bd = {
            aw: "_aw",
            dc: "_dc",
            gf: "_gf",
            ha: "_ha",
            gp: "_gp",
            gb: "_gb"
        };

    function T() {
        return Wc(14) ? ["ad_storage", "ad_user_data"] : ["ad_storage"]
    }

    function U() {
        return qc(Uc).g() ? dd(T()) : !0
    }

    function Cd(a) {
        function b() {
            var c = U();
            c && a();
            return c
        }
        gd(function() {
            b() || hd(b)
        })
    }

    function Dd(a) {
        return Ed(a).map(function(b) {
            return b.i
        })
    }

    function Ed(a) {
        var b = [];
        if ("null" === Q.origin || !R.cookie) return b;
        a = id(a, R.cookie, void 0, T());
        if (!a || 0 == a.length) return b;
        for (var c = {}, d = 0; d < a.length; c = {
                i: c.i
            }, d++) {
            var e = Fd(a[d]);
            if (null != e) {
                var f = e;
                e = f.version;
                c.i = f.i;
                var g = f.timestamp;
                f = f.labels;
                var h = Bc(b, function(k) {
                    return function(m) {
                        return m.i === k.i
                    }
                }(c));
                h ? (h.timestamp = Math.max(h.timestamp, g), h.labels = Gd(h.labels, f || [])) : b.push({
                    version: e,
                    i: c.i,
                    timestamp: g,
                    labels: f
                })
            }
        }
        b.sort(function(k, m) {
            return m.timestamp - k.timestamp
        });
        return Hd(b)
    }

    function Gd(a, b) {
        for (var c = {}, d = [], e = 0; e < a.length; e++) c[a[e]] = !0, d.push(a[e]);
        for (a = 0; a < b.length; a++) c[b[a]] || d.push(b[a]);
        return d
    }

    function Id(a) {
        return a && "string" == typeof a && a.match(zd) ? a : "_gcl"
    }

    function Jd() {
        var a = Q.location.href,
            b = R.createElement("a");
        a && (b.href = a);
        var c = b.pathname;
        "/" !== c[0] && (a || zc(1), c = "/" + c);
        a = b.hostname.replace(wd, "");
        var d = {
            href: b.href,
            protocol: b.protocol,
            host: b.host,
            hostname: a,
            pathname: c,
            search: b.search,
            hash: b.hash,
            port: b.port
        };
        b = yd(d, "gclid");
        c = yd(d, "gclsrc");
        a = yd(d, "wbraid");
        var e = yd(d, "dclid");
        b && c && a || (d = d.hash.replace("#", ""), b = b || xd(d, "gclid"), c = c || xd(d, "gclsrc"), a = a || xd(d, "wbraid"));
        return Kd(b, c, e, a)
    }

    function Kd(a, b, c, d) {
        function e(g, h) {
            f[h] || (f[h] = []);
            f[h].push(g)
        }
        var f = {};
        f.gclid = a;
        f.gclsrc = b;
        f.dclid = c;
        void 0 !== d && Ad.test(d) && (f.gbraid = d, e(d, "gb"));
        if (void 0 !== a && a.match(Ad)) switch (b) {
            case void 0:
                e(a, "aw");
                break;
            case "aw.ds":
                e(a, "aw");
                e(a, "dc");
                break;
            case "ds":
                e(a, "dc");
                break;
            case "3p.ds":
                e(a, "dc");
                break;
            case "gf":
                e(a, "gf");
                break;
            case "ha":
                e(a, "ha")
        }
        c && e(c, "dc");
        return f
    }

    function Ld() {
        var a = {},
            b = Jd();
        Cd(function() {
            Md(b, !1, a)
        })
    }

    function Md(a, b, c, d, e) {
        function f(n) {
            n = ["GCL", p, n];
            0 < e.length && n.push(e.join("."));
            return n.join(".")
        }

        function g(n, r) {
            if (n = Nd(n, h)) qd(n, r, k), m = !0
        }
        c = c || {};
        e = e || [];
        var h = Id(c.prefix);
        d = d || (new Date(Date.now())).getTime();
        var k = td(c, d);
        k.l = T();
        var m = !1,
            p = Math.round(d / 1E3);
        a.aw && g("aw", f(a.aw[0]));
        a.dc && g("dc", f(a.dc[0]));
        a.gf && g("gf", f(a.gf[0]));
        a.ha && g("ha", f(a.ha[0]));
        a.gp && g("gp", f(a.gp[0]));
        if (!m && a.gb) {
            a = a.gb[0];
            d = Nd("gb", h);
            c = !1;
            if (!b)
                for (b = Ed(d), d = 0; d < b.length; d++) b[d].i === a && b[d].labels && 0 < b[d].labels.length &&
                    (c = !0);
            c || g("gb", f(a))
        }
    }

    function Nd(a, b) {
        a = Bd[a];
        if (void 0 !== a) return b + a
    }

    function Od(a) {
        return 0 !== Pd(a.split(".")).length ? 1E3 * (Number(a.split(".")[1]) || 0) : 0
    }

    function Fd(a) {
        a = Pd(a.split("."));
        return 0 === a.length ? null : {
            version: a[0],
            i: a[2],
            timestamp: 1E3 * (Number(a[1]) || 0),
            labels: a.slice(3)
        }
    }

    function Pd(a) {
        return 3 > a.length || "GCL" !== a[0] && "1" !== a[0] || !/^\d+$/.test(a[1]) || !Ad.test(a[2]) ? [] : a
    }

    function Hd(a) {
        return a.filter(function(b) {
            return Ad.test(b.i)
        })
    }

    function Qd() {
        var a = ["aw"],
            b = {};
        if ("null" !== Q.origin) {
            for (var c = Id(b.prefix), d = {}, e = 0; e < a.length; e++) Bd[a[e]] && (d[a[e]] = Bd[a[e]]);
            Cd(function() {
                Cc(d, function(f, g) {
                    g = id(c + g, R.cookie, void 0, T());
                    g.sort(function(p, n) {
                        return Od(n) - Od(p)
                    });
                    if (g.length) {
                        var h = g[0];
                        g = Od(h);
                        var k = 0 !== Pd(h.split(".")).length ? h.split(".").slice(3) : [],
                            m = {};
                        h = 0 !== Pd(h.split(".")).length ? h.split(".")[2] : void 0;
                        m[f] = [h];
                        Md(m, !0, b, g, k)
                    }
                })
            })
        }
    }

    function Rd(a, b, c, d) {
        var e = [];
        c = c || {};
        if (!U()) return e;
        var f = Ed(a);
        if (!f.length) return e;
        for (var g = 0; g < f.length; g++) - 1 === (f[g].labels || []).indexOf(b) ? e.push(0) : e.push(1);
        if (d) return e;
        1 !== e[0] && (d = f[0], f = f[0].timestamp, b = [d.version, Math.round(f / 1E3), d.i].concat(d.labels || [], [b]).join("."), c = td(c, f), c.l = T(), qd(a, b, c));
        return e
    }

    function Sd(a, b) {
        b = Id(b);
        a = Nd(a, b);
        if (!a) return 0;
        a = Ed(a);
        for (var c = b = 0; c < a.length; c++) b = Math.max(b, a[c].timestamp);
        return b
    }

    function Td(a) {
        var b = 0,
            c;
        for (c in a)
            for (var d = a[c], e = 0; e < d.length; e++) b = Math.max(b, Number(d[e].timestamp));
        return b
    };
    var Ud = RegExp("^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"),
        Vd = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
        Wd = /^\d+\.fls\.doubleclick\.net$/,
        Xd = /;gac=([^;?]+)/,
        Yd = /;gacgb=([^;?]+)/,
        Zd = /;gclaw=([^;?]+)/,
        $d = /;gclgb=([^;?]+)/;

    function ae(a, b, c) {
        if (Wd.test(a.location.host)) return (b = a.location.href.match(c)) && 2 == b.length && b[1].match(Ud) ? decodeURIComponent(b[1]) : "";
        a = [];
        for (var d in b) {
            c = [];
            for (var e = b[d], f = 0; f < e.length; f++) c.push(e[f].i);
            a.push(d + ":" + c.join(","))
        }
        return 0 < a.length ? a.join(";") : ""
    }

    function be(a, b, c, d) {
        var e = U() ? vd("_gac_gb", !0) : {},
            f = [],
            g = !1,
            h;
        for (h in e) {
            var k = Rd("_gac_gb_" + h, b, c, d);
            g = g || 0 !== k.length && k.some(function(m) {
                return 1 === m
            });
            f.push(h + ":" + k.join(","))
        }
        return {
            D: g ? f.join(";") : "",
            C: ae(a, e, Yd)
        }
    }

    function ce(a, b, c, d) {
        if (Wd.test(a.location.host)) {
            if ((a = a.location.href.match(d)) && 2 == a.length && a[1].match(Vd)) return [{
                i: a[1]
            }]
        } else return Ed((b || "_gcl") + c);
        return []
    }

    function de(a, b) {
        return ce(a, b, "_aw", Zd).map(function(c) {
            return c.i
        }).join(".")
    }

    function ee(a, b) {
        return ce(a, b, "_gb", $d).map(function(c) {
            return c.i
        }).join(".")
    }

    function fe(a) {
        0 !== Dd("_gcl_aw").length || a && 0 !== Dd(a + "_aw").length || (Ld(), Qd())
    }

    function ge(a, b, c) {
        a = Rd((b && b.prefix || "_gcl") + "_gb", a, b, c);
        return 0 === a.length || a.every(function(d) {
            return 0 === d
        }) ? "" : a.join(".")
    };

    function he() {
        if ("function" === typeof Q.__uspapi) {
            var a = "";
            try {
                Q.__uspapi("getUSPData", 1, function(b, c) {
                    c && b && (b = b.uspString) && RegExp("^[\\da-zA-Z-]{1,20}$").test(b) && (a = b)
                })
            } catch (b) {}
            return a
        }
    };
    Object.freeze({});
    var ie = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function je(a) {
        var b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    }

    function ke(a) {
        a = a.google_tag_data;
        if (null != a && a.uach) {
            a = a.uach;
            var b = u(Object, "assign").call(Object, {}, a);
            a.fullVersionList && (b.fullVersionList = a.fullVersionList.slice(0));
            a = b
        } else a = null;
        return a
    }

    function le(a) {
        var b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    }

    function me() {
        var a = window;
        if (le(a)) {
            var b = je(a);
            b.uach_promise || (a = a.navigator.userAgentData.getHighEntropyValues(ie).then(function(c) {
                null != b.uach || (b.uach = c);
                return c
            }), b.uach_promise = a)
        }
    };
    var ne = /^[a-zA-Z0-9_]+$/,
        oe = !1,
        pe = "google_conversion_id google_conversion_format google_conversion_type google_conversion_order_id google_conversion_language google_conversion_value google_conversion_currency google_conversion_domain google_conversion_label google_conversion_color google_disable_viewthrough google_enable_display_cookie_match google_gtag_event_data google_remarketing_only google_conversion_linker google_tag_for_child_directed_treatment google_tag_for_under_age_of_consent google_allow_ad_personalization_signals google_restricted_data_processing google_conversion_items google_conversion_merchant_id google_user_id google_custom_params google_conversion_date google_conversion_time google_conversion_js_version onload_callback opt_image_generator google_gtm_url_processor google_conversion_page_url google_conversion_referrer_url google_gcl_cookie_prefix google_gcl_cookie_path google_gcl_cookie_flags google_gcl_cookie_domain google_gcl_cookie_max_age_seconds google_read_gcl_cookie_opt_out google_basket_feed_country google_basket_feed_language google_basket_discount google_basket_transaction_type google_additional_conversion_params google_additional_params google_transport_url google_gtm_experiments".split(" "),
        qe = ["google_conversion_first_time", "google_conversion_snippets"];

    function V(a) {
        return null != a ? encodeURIComponent(String(a)) : ""
    }

    function re(a) {
        if (null != a) {
            a = String(a).substring(0, 512);
            var b = a.indexOf("#");
            return -1 == b ? a : a.substring(0, b)
        }
        return ""
    }

    function W(a, b) {
        b = V(b);
        return "" != b && (a = V(a), "" != a) ? "&".concat(a, "=", b) : ""
    }

    function se(a) {
        var b = typeof a;
        return null == a || "object" == b || "function" == b ? null : String(a).replace(/,/g, "\\,").replace(/;/g, "\\;").replace(/=/g, "\\=")
    }

    function te(a) {
        if (!a || "object" != typeof a || "function" == typeof a.join) return "";
        var b = [],
            c;
        for (c in a)
            if (Object.prototype.hasOwnProperty.call(a, c)) {
                var d = a[c];
                if (d && "function" === typeof d.join) {
                    for (var e = [], f = 0; f < d.length; ++f) {
                        var g = se(d[f]);
                        null != g && e.push(g)
                    }
                    d = 0 == e.length ? null : e.join(",")
                } else d = se(d);
                (e = se(c)) && null != d && b.push(e + "=" + d)
            }
        return b.join(";")
    }

    function ue(a) {
        return "number" != typeof a && "string" != typeof a ? "" : V(a.toString())
    }

    function ve(a, b) {
        if (b.google_read_gcl_cookie_opt_out || b.google_remarketing_only || b.google_conversion_domain && (!b.google_gcl_cookie_prefix || !/^_ycl/.test(b.google_gcl_cookie_prefix))) return "";
        var c = "";
        var d = b.google_gcl_cookie_prefix && "_gcl" !== b.google_gcl_cookie_prefix && ne.test(b.google_gcl_cookie_prefix) ? b.google_gcl_cookie_prefix : "";
        var e = {};
        b.google_gcl_cookie_domain && (e.domain = b.google_gcl_cookie_domain);
        b.google_gcl_cookie_flags && (e.flags = b.google_gcl_cookie_flags);
        null != b.google_gcl_cookie_max_age_seconds &&
            (e.v = b.google_gcl_cookie_max_age_seconds);
        b.google_gcl_cookie_path && (e.path = b.google_gcl_cookie_path);
        d && (e.prefix = d);
        if (we(b) && b.o) var f = void 0 === b.m;
        else Wd.test(a.location.host) ? f = !(Zd.test(a.location.href) || Xd.test(a.location.href)) : (f = Math.max(Sd("aw", d), Td(U() ? vd() : {})), f = Math.max(Sd("gb", d), Td(U() ? vd("_gac_gb", !0) : {})) > f);
        if (f) {
            if (void 0 !== b.m) return b.m;
            c = ee(a, d || void 0);
            f = b.google_conversion_label;
            var g = ge(f, e, b.o);
            c = W("gclgb", c) + (g ? W("mcov", g) : "");
            if (d) return b.m = c;
            d = be(a, f, e, b.o);
            a = d.C;
            d = d.D;
            c += (a ? W("gacgb", a) : "") + (d ? W("gacmcov", d) : "");
            return b.m = c
        }
        if (d) return b = de(a, d), W("gclaw", b);
        (b = de(a)) && (c = W("gclaw", b));
        b = ae(a, U() ? vd() : {}, Xd);
        return c + (b ? W("gac", b) : "")
    }

    function xe(a) {
        function b(d) {
            try {
                return decodeURIComponent(d), !0
            } catch (e) {
                return !1
            }
        }
        a = a ? a.title : "";
        if (void 0 == a || "" == a) return "";
        a = encodeURIComponent(a);
        for (var c = 256; !b(a.substr(0, c));) c--;
        return "&tiba=" + a.substr(0, c)
    }

    function ye(a, b, c, d, e) {
        var f = "https://",
            g = "landing" === d.google_conversion_type ? "/extclk" : "/";
        switch (e) {
            default: return "";
            case 2:
                    case 3:
                    var h = "googleads.g.doubleclick.net/";
                var k = "pagead/viewthroughconversion/";
                break;
            case 1:
                    h = "www.google.com/";k = "pagead/1p-conversion/";
                break;
            case 6:
                    h = "www.google.com/";k = "ccm/conversion/";
                break;
            case 0:
                    h = d.google_conversion_domain || "www.googleadservices.com/";k = "pagead/conversion/";
                break;
            case 5:
                    h = d.google_conversion_domain || "www.googleadservices.com/";k = "ccm/conversion/";
                break;
            case 4:
                    h = (h = d.google_gtm_experiments) && h.apcm ? "www.google.com" : h && h.capiorig ? d.google_conversion_id + ".privacysandbox.googleadservices.com" : "www.google.com/";k = "pagead/privacysandbox/conversion/";
                break;
            case 7:
                    h = "googleads.g.doubleclick.net/",
                k = "td/rul/"
        }
        cc && d.google_transport_url && (h = d.google_transport_url);
        "/" !== h[h.length - 1] && (h += "/");
        if (0 === h.indexOf("http://") || 0 === h.indexOf("https://")) f = "";
        f = [f, h, k, V(d.google_conversion_id), g, "?random=", V(d.google_conversion_time)].join("");
        g = W("cv", d.google_conversion_js_version);
        h = W("fst", d.google_conversion_first_time);
        k = W("num", d.google_conversion_snippets);
        var m = W("fmt", d.google_conversion_format),
            p = d.google_remarketing_only ? W("userId", d.google_user_id) : "";
        var n = d.google_tag_for_child_directed_treatment;
        n = null == n || 0 !== n && 1 !== n ? "" : W("tfcd", n);
        var r = d.google_tag_for_under_age_of_consent;
        r = null == r || 0 !== r && 1 !== r ? "" : W("tfua", r);
        var I = d.google_allow_ad_personalization_signals;
        I = !1 === I ? W("npa", 1) : !0 === I ? W("npa", 0) : "";
        var Ia = d.google_restricted_data_processing;
        Ia = ec ? !0 === Ia ? W("rdp",
            1) : !1 === Ia ? W("rdp", 0) : "" : "";
        var Ke = W("value", d.google_conversion_value),
            Le = W("currency_code", d.google_conversion_currency),
            Me = W("label", d.google_conversion_label),
            Ne = W("oid", d.google_conversion_order_id),
            Oe = W("bg", d.google_conversion_color);
        a: {
            var B = d.google_conversion_language;
            if (null != B) {
                B = B.toString();
                if (2 == B.length) {
                    B = W("hl", B);
                    break a
                }
                if (5 == B.length) {
                    B = W("hl", B.substring(0, 2)) + W("gl", B.substring(3, 5));
                    break a
                }
            }
            B = ""
        }
        var Pe = W("guid", "ON"),
            Qe = !d.google_conversion_domain && "GooglemKTybQhCsO" in w &&
            "function" == typeof w.GooglemKTybQhCsO ? W("resp", "GooglemKTybQhCsO") : "",
            Re = W("disvt", d.google_disable_viewthrough),
            Se = W("eid", kc().join());
        var ma = d.google_conversion_date;
        var z = [];
        if (a) {
            var K = a.screen;
            K && (z.push(W("u_h", K.height)), z.push(W("u_w", K.width)), z.push(W("u_ah", K.availHeight)), z.push(W("u_aw", K.availWidth)), z.push(W("u_cd", K.colorDepth)));
            a.history && z.push(W("u_his", a.history.length))
        }
        ma && "function" == typeof ma.getTimezoneOffset && z.push(W("u_tz", -ma.getTimezoneOffset()));
        b && ("function" == typeof b.javaEnabled &&
            z.push(W("u_java", b.javaEnabled())), b.plugins && z.push(W("u_nplug", b.plugins.length)), b.mimeTypes && z.push(W("u_nmime", b.mimeTypes.length)));
        ma = z.join("");
        b = b && b.sendBeacon ? W("sendb", "1") : "";
        z = ze();
        K = W("ig", /googleadservices\.com/.test("www.googleadservices.com") ? 1 : 0);
        var S = te(d.google_custom_params);
        var Ja = te();
        S = S.concat(0 < S.length && 0 < Ja.length ? ";" : "", Ja);
        S = "" == S ? "" : "&".concat("data=", encodeURIComponent(S));
        Ja = ve(c, d);
        var na = d.google_conversion_page_url,
            Ue = d.google_conversion_referrer_url,
            oa = "";
        if (c) {
            var Z =
                a.top == a ? 0 : (Z = a.location.ancestorOrigins) ? Z[Z.length - 1] == a.location.origin ? 1 : 2 : Pb(a.top) ? 1 : 2;
            na = na ? na : 1 == Z ? a.top.location.href : a.location.href;
            var Oc = "";
            N && M(["509562772", "509562773"], $b, 21);
            if (N && ("509562773" == O(21) || "509562772" == O(21))) {
                for (var x, t = a, aa = t; t && t != t.parent;) t = t.parent, Pb(t) && (aa = t);
                x = aa;
                t = x.location.href;
                if (x === x.top) t = {
                    url: t,
                    G: !0
                };
                else {
                    aa = !1;
                    var nb = x.document;
                    nb && nb.referrer && (t = nb.referrer, x.parent === x.top && (aa = !0));
                    (x = x.location.ancestorOrigins) && (x = x[x.length - 1]) && -1 === t.indexOf(x) &&
                        (aa = !1, t = x);
                    t = {
                        url: t,
                        G: aa
                    }
                }
                t.url && na !== t.url && (Oc = t.url)
            }
            oa += W("frm", Z);
            oa += W("url", re(na));
            oa += W("ref", re(Ue || c.referrer));
            oa += W("top", re(Oc))
        }
        a = [g, h, k, m, p, n, r, I, Ia, Ke, Le, Me, Ne, Oe, B, Pe, Qe, Re, Se, ma, b, z, K, S, Ja, oa, xe(c), Ae(d.google_additional_params), Ae(d.google_remarketing_only ? {} : d.google_additional_conversion_params), "&hn=" + V("www.googleadservices.com"), Be(a), Ce(a)].join("");
        c = jc();
        a += 0 < c.length ? "&debug_experiment_id=" + c : "";
        if (!d.google_remarketing_only && !d.google_conversion_domain) {
            c = [W("mid", d.google_conversion_merchant_id),
                W("fcntr", d.google_basket_feed_country), W("flng", d.google_basket_feed_language), W("dscnt", d.google_basket_discount), W("bttype", d.google_basket_transaction_type)
            ].join("");
            if (d)
                if (g = d.google_conversion_items) {
                    h = [];
                    k = 0;
                    for (m = g.length; k < m; k++) p = g[k], n = [], p && (n.push(ue(p.value)), n.push(ue(p.quantity)), n.push(ue(p.item_id)), n.push(ue(p.start_date)), n.push(ue(p.end_date)), h.push("(" + n.join("*") + ")"));
                    g = 0 < h.length ? "&item=" + h.join("") : ""
                } else g = "";
            else g = "";
            c = [a, c, g].join("");
            a = 4E3 < c.length ? [a, W("item", "elngth")].join("") :
                c
        }
        f += a;
        1 === e || 6 === e ? f += [W("gcp", 1), W("sscte", 1), W("ct_cookie_present", 1)].join("") : 3 == e && (f += W("gcp", 1), f += W("ct_cookie_present", 1));
        dc && (e = he(), void 0 !== e && (f += W("us_privacy", e || "error")));
        we(d) && (f = d.o ? f + W("gbcov", 1) : f + W("gbcov", 0));
        return f
    }

    function De(a, b, c, d, e, f, g) {
        return '<iframe name="' + a + '"' + (g ? ' id="' + g + '"' : "") + ' title="' + b + '" width="' + d + '" height="' + e + '"' + (c ? ' src="' + c + '"' : "") + ' frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true"' + (f ? ' style="display:none"' : "") + ' scrolling="no"></iframe>'
    }

    function Ee(a) {
        return {
            ar: 1,
            bg: 1,
            cs: 1,
            da: 1,
            de: 1,
            el: 1,
            en_AU: 1,
            en_US: 1,
            en_GB: 1,
            es: 1,
            et: 1,
            fi: 1,
            fr: 1,
            hi: 1,
            hr: 1,
            hu: 1,
            id: 1,
            is: 1,
            it: 1,
            iw: 1,
            ja: 1,
            ko: 1,
            lt: 1,
            nl: 1,
            no: 1,
            pl: 1,
            pt_BR: 1,
            pt_PT: 1,
            ro: 1,
            ru: 1,
            sk: 1,
            sl: 1,
            sr: 1,
            sv: 1,
            th: 1,
            tl: 1,
            tr: 1,
            vi: 1,
            zh_CN: 1,
            zh_TW: 1
        }[a] ? a + ".html": "en_US.html"
    }

    function Fe(a, b, c, d) {
        function e(h, k, m, p, n) {
            p = p ? ' style="display:none"' : "";
            return "<img " + (n && oc() ? "attributionsrc " : "") + 'height="' + m + '" width="' + k + '" border="0" alt="" src="' + h + '"' + p + " />"
        }
        nc() && uc(2);
        var f = "";
        d.google_remarketing_only && d.google_enable_display_cookie_match && !xc && (N && M(["376635470", "376635471"], Xb, 2), f = d.google_remarketing_only && d.google_enable_display_cookie_match && !xc && N && "376635471" == O(2) ? De("google_cookie_match_frame", "Google cookie match frame", "https://bid.g.doubleclick.net/xbbe/pixel?d=KAE",
            1, 1, !0, null) : "");
        d.google_remarketing_only && !d.google_conversion_domain && N && M(["759238990", "759238991"], bc, 13);
        !d.google_remarketing_only || d.google_conversion_domain || N && ("759248991" == O(14) || "759248990" == O(14)) || N && M(["759248990", "759248991"], ac, 14);
        !1 !== d.google_conversion_linker && fe(d.google_gcl_cookie_prefix);
        b = ye(a, b, c, d, d.google_remarketing_only ? 2 : 0);
        if (0 == d.google_conversion_format && null == d.google_conversion_domain) return '<a href="https://services.google.com/sitestats/' + (Ee(d.google_conversion_language) +
            "?cid=" + V(d.google_conversion_id)) + '" target="_blank">' + e(b, 135, 27, !1, !1) + "</a>" + f;
        if (void 0 !== d.google_conversion_snippets && 1 < d.google_conversion_snippets || 3 == d.google_conversion_format) {
            var g = b;
            null == d.google_conversion_domain && (g = 3 == d.google_conversion_format ? b : J(b, "fmt", 3));
            b = void 0;
            oc() && !d.google_remarketing_only && (b = {
                attributionsrc: ""
            });
            return Ge(a, c, d, g, b) ? f : e(g, 1, 1, !0, !d.google_remarketing_only) + f
        }
        g = null;
        !d.google_conversion_domain && Ge(a, c, d, b) && (g = "goog_conv_iframe", b = "");
        return De("google_conversion_frame",
            "Google conversion frame", b, 2 == d.google_conversion_format ? 200 : 300, 2 == d.google_conversion_format ? 26 : 13, !1, g) + f
    }

    function Ge(a, b, c, d, e) {
        if (c.google_conversion_domain) return !1;
        try {
            return Sc(a, b, d, null, e)
        } catch (f) {
            return !1
        }
    }

    function He(a) {
        if ("landing" === a.google_conversion_type || !a.google_conversion_id || a.google_remarketing_only && a.google_disable_viewthrough) return !1;
        a.google_conversion_date = new Date;
        a.google_conversion_time = a.google_conversion_date.getTime();
        a.google_conversion_snippets = "number" === typeof a.google_conversion_snippets && 0 < a.google_conversion_snippets ? a.google_conversion_snippets + 1 : 1;
        void 0 === a.google_conversion_first_time && (a.google_conversion_first_time = a.google_conversion_time);
        a.google_conversion_js_version =
            "9";
        0 != a.google_conversion_format && 1 != a.google_conversion_format && 2 != a.google_conversion_format && 3 != a.google_conversion_format && (a.google_conversion_format = 3);
        !1 !== a.google_enable_display_cookie_match && (a.google_enable_display_cookie_match = !0);
        return !0
    }

    function Ie(a) {
        for (var b = 0; b < pe.length; b++) a[pe[b]] = null
    }

    function Je(a) {
        for (var b = {}, c = 0; c < pe.length; c++) b[pe[c]] = a[pe[c]];
        for (c = 0; c < qe.length; c++) b[qe[c]] = a[qe[c]];
        return b
    }

    function ze() {
        var a = "";
        nc() && (a = wc().map(function(b) {
            return b.join("-")
        }).join("_"));
        return W("li", a)
    }

    function Be(a) {
        if (!fc || !a.__gsaExp || !a.__gsaExp.id) return "";
        a = a.__gsaExp.id;
        if ("function" !== typeof a) return "";
        try {
            var b = Number(a());
            return isNaN(b) ? "" : W("gsaexp", b)
        } catch (c) {
            return ""
        }
    }

    function Ce(a) {
        function b(d, e) {
            null != e && c.push(d + "=" + encodeURIComponent(e))
        }
        if (!mc()) return "";
        a = ke(a);
        if (!a) return "";
        var c = [];
        b("&uaa", a.architecture);
        b("&uab", a.bitness);
        b("&uam", a.model);
        b("&uap", a.platform);
        b("&uapv", a.platformVersion);
        null != a.wow64 && b("&uaw", a.wow64 ? "1" : "0");
        a.fullVersionList && b("&uafvl", a.fullVersionList.map(function(d) {
            return encodeURIComponent(d.brand || "") + ";" + encodeURIComponent(d.version || "")
        }).join("|"));
        return c.join("")
    }

    function Ae(a) {
        if (!a) return "";
        var b = "",
            c;
        for (c in a) a.hasOwnProperty(c) && (b += W(c, a[c]));
        return b
    }

    function we(a) {
        return (a = a.google_gtm_experiments) && a.gbcov ? !0 : !1
    }

    function Te(a, b) {
        var c;
        if (c = !b.google_remarketing_only)
            if (b.google_transport_url || !N || "375603261" != O(19) && "375603260" != O(19)) c = !1;
            else {
                b: {
                    if (!oe) {
                        Vb("A4w7HyCK6tScR/6oxyP31X0MsYLu0ZlIdOBV/7GEXwRIQZy3/qaAa0jm3+mKd8mQDUB6svQWIUC2X/gyNdSvbgAAAACUeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJBdHRyaWJ1dGlvblJlcG9ydGluZ0Nyb3NzQXBwV2ViIiwiZXhwaXJ5IjoxNzA3MjYzOTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ\x3d\x3d", a);
                        if (!Lc() && !Vb(u("www.googleadservices.com", "endsWith").call("www.googleadservices.com", "google.com") ? "" : "A2kc5o2ErHAbqJvF2MHSdYtnc2Bp3n6Jn2kNeko6SgHH6zXBHn0+4BbAW2No9ylVJMkzJAPwMqCVHqXm+IF1DgQAAACKeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJQcml2YWN5U2FuZGJveEFkc0FQSXMiLCJleHBpcnkiOjE2OTUxNjc5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", a)) {
                            a = !1;
                            break b
                        }
                        oe = !0
                    }
                    a = Lc()
                }
                c = a
            }
        c && (a = b.google_additional_conversion_params || {}, c = b.google_gtm_experiments, a.capi = c && c.apcm ? "2" : "1", b.google_additional_conversion_params =
            a)
    };

    function Ve(a) {
        var b = ra.apply(1, arguments);
        if (0 === b.length) return fb(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return fb(c)
    };
    var We = ka(["https://www.googletagmanager.com/debug/bootstrap"]),
        Xe = !1,
        Ye = document.currentScript && document.currentScript.src || "";

    function Ze(a, b, c) {
        try {
            if (!Xe && (Xe = !0, !c.google_gtm)) {
                var d = void 0,
                    e = void 0,
                    f = Lb(a.location.href, "gtm_debug");
                $e(f) && (d = 2);
                d || 0 !== b.referrer.indexOf("https://tagassistant.google.com/") || (d = 3);
                !d && 0 <= Ca(b.cookie.split("; "), "__TAG_ASSISTANT=x") && (d = 4);
                d || (e = b.documentElement.getAttribute("data-tag-assistant-present"), $e(e) && (d = 5));
                if (d) {
                    var g = "AW-" + (c.google_conversion_id || "");
                    if (!a["google.tagmanager.debugui2.queue"]) {
                        a["google.tagmanager.debugui2.queue"] = [];
                        var h = Ve(We);
                        c = {
                            id: g,
                            src: "LEGACY",
                            cond: d
                        };
                        var k = db.exec(cb(h).toString()),
                            m = k[3] || "";
                        var p = fb(k[1] + gb("?", k[2] || "", c) + gb("#", m));
                        var n = Wb("SCRIPT", b);
                        Nb(n, p);
                        var r = b.getElementsByTagName("script")[0];
                        r && r.parentNode && r.parentNode.insertBefore(n, r)
                    }
                    a["google.tagmanager.debugui2.queue"].push({
                        messageType: "LEGACY_CONTAINER_STARTING",
                        data: {
                            id: g,
                            scriptSource: Ye
                        }
                    })
                }
            }
        } catch (I) {}
    }

    function $e(a) {
        if (null == a || 0 === a.length) return !1;
        a = Number(a);
        var b = Date.now();
        return a < b + 3E5 && a > b - 9E5
    };

    function af(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    }

    function bf(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function cf(a, b) {
        if (3 == af(b)) return !1;
        a();
        return !0
    }

    function df(a, b) {
        var c = void 0 === c ? !1 : c;
        if (!cf(a, b))
            if (c) {
                var d = function() {
                    b.removeEventListener && b.removeEventListener("prerenderingchange", d, !1);
                    a()
                };
                b.addEventListener && b.addEventListener("prerenderingchange", d, !1)
            } else {
                var e = !1,
                    f = bf(b),
                    g = function() {
                        !e && cf(a, b) && (e = !0, b.removeEventListener && b.removeEventListener(f, g, !1))
                    };
                f && b.addEventListener && b.addEventListener(f, g, !1)
            }
    };

    function ef(a) {
        var b = u(Object, "assign").call(Object, {}, a);
        a = a.id;
        b = (delete b.id, b);
        if (u(Object, "keys").call(Object, b).length) throw Error("Invalid attribute(s): " + u(Object, "keys").call(Object, b));
        a = {
            id: a
        };
        if (!Eb.test("span")) throw Error("");
        if ("SPAN" in Gb) throw Error("");
        b = void 0;
        var c = "";
        if (a)
            for (k in a)
                if (Object.prototype.hasOwnProperty.call(a, k)) {
                    if (!Eb.test(k)) throw Error("");
                    var d = a[k];
                    if (null != d) {
                        var e = void 0;
                        var f = k;
                        if (d instanceof A) d = Aa(d);
                        else if ("style" == f.toLowerCase()) {
                            var g = typeof d;
                            g = "object" == g && null != d || "function" == g;
                            if (!g) throw Error("");
                            if (!(d instanceof G)) {
                                g = "";
                                for (e in d)
                                    if (Object.prototype.hasOwnProperty.call(d, e)) {
                                        if (!/^[-_a-zA-Z0-9]+$/.test(e)) throw Error("Name allows only [-_a-zA-Z0-9], got: " + e);
                                        var h = d[e];
                                        null != h && (h = Array.isArray(h) ? h.map(qb).join(" ") : qb(h), g += e + ":" + h + ";")
                                    }
                                d = g ? new G(g, ob) : pb
                            }
                            d = d instanceof G && d.constructor === G ? d.h : "type_error:SafeStyle"
                        } else {
                            if (/^on/i.test(f)) throw Error("");
                            if (f.toLowerCase() in Fb)
                                if (d instanceof E) d = cb(d).toString();
                                else if (d instanceof F) d = hb(d);
                            else if ("string" === typeof d) d = (kb(d) || mb).g();
                            else throw Error("");
                        }
                        d.j && (d = d.g());
                        e = f + '="' + Ma(String(d)) + '"';
                        c += " " + e
                    }
                }
        var k = "<span" + c;
        null == b ? b = [] : Array.isArray(b) || (b = [b]);
        !0 === $a.span ? k += ">" : (b = Db(b), k += ">" + yb(b).toString() + "</span>");
        return Ab(k)
    };
    N = new function() {
        var a = [];
        var b = 0,
            c;
        for (c in lc) a[b++] = lc[c];
        a = void 0 === a ? [] : a;
        this.h = {};
        this.g = {};
        for (b = 0; b < a.length; ++b) this.g[a[b]] = ""
    };
    M(["466465925", "466465926"], Zb, 20);
    mc() && me();
    N && M(["592230570", "592230571"], Yb, 16);
    nc() && (uc(1), vc());

    function ff(a, b, c) {
        function d(m, p) {
            var n = new Image;
            n.onload = m;
            n.src = p
        }

        function e() {
            --f;
            if (0 >= f) {
                var m = Nc(a, !1),
                    p = m[b];
                p && (delete m[b], (m = p[0]) && m.call && m())
            }
        }
        var f = c.length + 1;
        if (2 == c.length) {
            var g = c[0],
                h = c[1];
            0 <= Jb(g, 0, "rmt_tld", g.search(Kb)) && 0 <= Jb(g, 0, "ipr", g.search(Kb)) && !h.match(Hb)[6] && (h += Ib(g), c[1] = J(h, "rmt_tld", "1"))
        }
        for (g = 0; g < c.length; g++) {
            h = c[g];
            var k = Lb(h, "fmt");
            switch (parseInt(k, 10)) {
                case 1:
                case 2:
                    (k = a.document.getElementById("goog_conv_iframe")) && !k.src ? Kc(h, e, k) : d(e, h);
                    break;
                case 4:
                    Sc(a,
                        a.document, h, e);
                    break;
                case 5:
                    if (a.navigator && a.navigator.sendBeacon)
                        if (a.navigator.sendBeacon(h, "")) {
                            e();
                            break
                        } else h = J(h, "sendb", 2);
                    h = J(h, "fmt", 3);
                default:
                    d(e, h)
            }
        }
        e()
    }
    var gf = ["GooglemKTybQhCsO"],
        X = w;
    gf[0] in X || "undefined" == typeof X.execScript || X.execScript("var " + gf[0]);
    for (var Y; gf.length && (Y = gf.shift());) gf.length || void 0 === ff ? X[Y] && X[Y] !== Object.prototype[Y] ? X = X[Y] : X = X[Y] = {} : X[Y] = ff;
    (function(a, b, c) {
        if (a) {
            Ze(a, c, a);
            try {
                if (He(a)) {
                    var d = Je(a);
                    N && M(["375603260", "375603261"], gc ? 1 : 0, 19);
                    N && M(["512247838", "512247839"], hc ? 1 : 0, 22);
                    if (3 == af(c)) {
                        var e = "google_conversion_" + Math.floor(1E9 * Math.random());
                        Ob(c, ef({
                            id: e
                        }));
                        df(function() {
                            try {
                                Te(c, d);
                                var f = c.getElementById(e);
                                if (f) {
                                    var g = Dc(Fe(a, b, c, d));
                                    if (1 === f.nodeType) {
                                        var h = f.tagName;
                                        if ("SCRIPT" === h || "STYLE" === h) throw Error("");
                                    }
                                    f.innerHTML = yb(g)
                                }
                            } catch (k) {}
                        }, c)
                    } else Te(c, d), Ob(c, Dc(Fe(a, b, c, d)))
                }
            } catch (f) {}
            Ie(a)
        }
    })(window, navigator, document);
}).call(this);