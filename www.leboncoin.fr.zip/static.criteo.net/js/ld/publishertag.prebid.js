// Hash: dDCeMJ35K677VQD6RXV4xxjpT9oxNyDPT2uFPrXj98qIvUQQ373neJOw0SuRdK4ZiXjYrkLM8MCTg+YaZxzJtbN+9TN5tOHLUlP/dmQf/gv7QW9+mXIkFEa0wLIbjfJbUW4NLbnLLWvuW1YqDcHh42vAkkGSG31oCZSwbIRJKPw=
! function(e) {
    "use strict";
    var n = function(e, t) {
        return (n = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var i in t) t.hasOwnProperty(i) && (e[i] = t[i])
            })(e, t)
    };

    function t(e, t) {
        function i() {
            this.constructor = e
        }
        n(e, t), e.prototype = null === t ? Object.create(t) : (i.prototype = t.prototype, new i)
    }
    var L = function() {
        return (L = Object.assign || function(e) {
            for (var t, i = 1, n = arguments.length; i < n; i++)
                for (var r in t = arguments[i]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            return e
        }).apply(this, arguments)
    };

    function i(e, t) {
        var i = {};
        for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (i[n] = e[n]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
            var r = 0;
            for (n = Object.getOwnPropertySymbols(e); r < n.length; r++) t.indexOf(n[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[r]) && (i[n[r]] = e[n[r]])
        }
        return i
    }

    function r(e, t, i, n) {
        var r, o = arguments.length,
            s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, i) : n;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, i, n);
        else
            for (var a = e.length - 1; 0 <= a; a--)(r = e[a]) && (s = (o < 3 ? r(s) : 3 < o ? r(t, i, s) : r(t, i)) || s);
        return 3 < o && s && Object.defineProperty(t, i, s), s
    }

    function o(i, n) {
        return function(e, t) {
            n(e, t, i)
        }
    }

    function s(e, t) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t)
    }

    function a(e, s, a, c) {
        return new(a = a || Promise)(function(i, t) {
            function n(e) {
                try {
                    o(c.next(e))
                } catch (e) {
                    t(e)
                }
            }

            function r(e) {
                try {
                    o(c.throw(e))
                } catch (e) {
                    t(e)
                }
            }

            function o(e) {
                var t;
                e.done ? i(e.value) : ((t = e.value) instanceof a ? t : new a(function(e) {
                    e(t)
                })).then(n, r)
            }
            o((c = c.apply(e, s || [])).next())
        })
    }

    function c(i, n) {
        var r, o, s, e, a = {
            label: 0,
            sent: function() {
                if (1 & s[0]) throw s[1];
                return s[1]
            },
            trys: [],
            ops: []
        };
        return e = {
            next: t(0),
            throw: t(1),
            return: t(2)
        }, "function" == typeof Symbol && (e[Symbol.iterator] = function() {
            return this
        }), e;

        function t(t) {
            return function(e) {
                return function(t) {
                    if (r) throw new TypeError("Generator is already executing.");
                    for (; a;) try {
                        if (r = 1, o && (s = 2 & t[0] ? o.return : t[0] ? o.throw || ((s = o.return) && s.call(o), 0) : o.next) && !(s = s.call(o, t[1])).done) return s;
                        switch (o = 0, s && (t = [2 & t[0], s.value]), t[0]) {
                            case 0:
                            case 1:
                                s = t;
                                break;
                            case 4:
                                return a.label++, {
                                    value: t[1],
                                    done: !1
                                };
                            case 5:
                                a.label++, o = t[1], t = [0];
                                continue;
                            case 7:
                                t = a.ops.pop(), a.trys.pop();
                                continue;
                            default:
                                if (!(s = 0 < (s = a.trys).length && s[s.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                    a = 0;
                                    continue
                                }
                                if (3 === t[0] && (!s || t[1] > s[0] && t[1] < s[3])) {
                                    a.label = t[1];
                                    break
                                }
                                if (6 === t[0] && a.label < s[1]) {
                                    a.label = s[1], s = t;
                                    break
                                }
                                if (s && a.label < s[2]) {
                                    a.label = s[2], a.ops.push(t);
                                    break
                                }
                                s[2] && a.ops.pop(), a.trys.pop();
                                continue
                        }
                        t = n.call(i, a)
                    } catch (e) {
                        t = [6, e], o = 0
                    } finally {
                        r = s = 0
                    }
                    if (5 & t[0]) throw t[1];
                    return {
                        value: t[0] ? t[1] : void 0,
                        done: !0
                    }
                }([t, e])
            }
        }
    }

    function d(e, t) {
        for (var i in e) t.hasOwnProperty(i) || (t[i] = e[i])
    }

    function l(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            i = t && e[t],
            n = 0;
        if (i) return i.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    }

    function u(e, t) {
        var i = "function" == typeof Symbol && e[Symbol.iterator];
        if (!i) return e;
        var n, r, o = i.call(e),
            s = [];
        try {
            for (;
                (void 0 === t || 0 < t--) && !(n = o.next()).done;) s.push(n.value)
        } catch (e) {
            r = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (i = o.return) && i.call(o)
            } finally {
                if (r) throw r.error
            }
        }
        return s
    }

    function p() {
        for (var e = [], t = 0; t < arguments.length; t++) e = e.concat(u(arguments[t]));
        return e
    }

    function h() {
        for (var e = 0, t = 0, i = arguments.length; t < i; t++) e += arguments[t].length;
        var n = Array(e),
            r = 0;
        for (t = 0; t < i; t++)
            for (var o = arguments[t], s = 0, a = o.length; s < a; s++, r++) n[r] = o[s];
        return n
    }

    function v(e) {
        return this instanceof v ? (this.v = e, this) : new v(e)
    }

    function f(e, t, i) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var r, o = i.apply(e, t || []),
            s = [];
        return r = {}, n("next"), n("throw"), n("return"), r[Symbol.asyncIterator] = function() {
            return this
        }, r;

        function n(n) {
            o[n] && (r[n] = function(i) {
                return new Promise(function(e, t) {
                    1 < s.push([n, i, e, t]) || a(n, i)
                })
            })
        }

        function a(e, t) {
            try {
                (i = o[e](t)).value instanceof v ? Promise.resolve(i.value.v).then(c, d) : l(s[0][2], i)
            } catch (e) {
                l(s[0][3], e)
            }
            var i
        }

        function c(e) {
            a("next", e)
        }

        function d(e) {
            a("throw", e)
        }

        function l(e, t) {
            e(t), s.shift(), s.length && a(s[0][0], s[0][1])
        }
    }

    function m(n) {
        var e, r;
        return e = {}, t("next"), t("throw", function(e) {
            throw e
        }), t("return"), e[Symbol.iterator] = function() {
            return this
        }, e;

        function t(t, i) {
            e[t] = n[t] ? function(e) {
                return (r = !r) ? {
                    value: v(n[t](e)),
                    done: "return" === t
                } : i ? i(e) : e
            } : i
        }
    }

    function g(c) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var e, t = c[Symbol.asyncIterator];
        return t ? t.call(c) : (c = "function" == typeof l ? l(c) : c[Symbol.iterator](), e = {}, i("next"), i("throw"), i("return"), e[Symbol.asyncIterator] = function() {
            return this
        }, e);

        function i(a) {
            e[a] = c[a] && function(s) {
                return new Promise(function(e, t) {
                    var i, n, r, o;
                    s = c[a](s), i = e, n = t, r = s.done, o = s.value, Promise.resolve(o).then(function(e) {
                        i({
                            value: e,
                            done: r
                        })
                    }, n)
                })
            }
        }
    }

    function y(e, t) {
        return Object.defineProperty ? Object.defineProperty(e, "raw", {
            value: t
        }) : e.raw = t, e
    }

    function b(e) {
        if (e && e.__esModule) return e;
        var t = {};
        if (null != e)
            for (var i in e) Object.hasOwnProperty.call(e, i) && (t[i] = e[i]);
        return t.default = e, t
    }

    function w(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function C(e, t) {
        if (!t.has(e)) throw new TypeError("attempted to get private field on non-instance");
        return t.get(e)
    }

    function _(e, t, i) {
        if (!t.has(e)) throw new TypeError("attempted to set private field on non-instance");
        return t.set(e, i), i
    }
    var S = (E.prototype.isAdBlocked = function(e) {
        var t = this;
        this.createPixel(E.allowedPixelUrl, function() {
            (t.allowedPixelLoaded = !0) === t.blockedPixelFailed && e(!0)
        }, function() {}), this.createPixel(E.blockedPixelUrl, function() {
            e(!1)
        }, function() {
            (t.blockedPixelFailed = !0) === t.allowedPixelLoaded && e(!0)
        })
    }, E.prototype.createPixel = function(e, t, i) {
        var n = document.createElement("img");
        n.src = e, n.height = 1, n.width = 1, n.style.display = "none", n.onload = t, n.onerror = i
    }, E.allowedPixelUrl = "https://static.criteo.net/images/pixel.gif?ch=1", E.blockedPixelUrl = "https://static.criteo.net/images/pixel.gif?ch=2", E);

    function E() {
        this.allowedPixelLoaded = !1, this.blockedPixelFailed = !1
    }
    var B = (I.create = function(e) {
        return new I(e)
    }, I.prototype.adBlockFlagEnabled = function() {
        var e = I.ADBLOCK_FLAG_KEY;
        return null !== this.localStorageHelper.getItem(e)
    }, I.prototype.enableAdBlockFlag = function() {
        var e = I.ADBLOCK_FLAG_KEY;
        this.localStorageHelper.setItem(e, "1", I.ADBLOCK_FLAG_LIFETIME)
    }, I.prototype.disableAdBlockFlag = function() {
        var e = I.ADBLOCK_FLAG_KEY;
        this.localStorageHelper.removeItem(e)
    }, I.prototype.setAdBlockFlagTimer = function(e) {
        var t = this;
        this.adBlockFlagEnabled() || !this.timerEnabled || this.timerStarted || (this.timerStarted = !0, setTimeout(function() {
            t.timerEnabled && (t.refreshAdblockFlag(), t.timerEnabled = !1)
        }, e))
    }, I.prototype.disableAdBlockFlagTimer = function() {
        this.timerEnabled = !1, this.adBlockFlagEnabled() && this.refreshAdblockFlag()
    }, I.prototype.refreshAdblockFlag = function() {
        var t = this;
        (new S).isAdBlocked(function(e) {
            e ? t.enableAdBlockFlag() : t.disableAdBlockFlag()
        })
    }, I.ADBLOCK_FLAG_KEY = "criteo_adblock_flag", I.ADBLOCK_FLAG_LIFETIME = 864e5, I);

    function I(e) {
        this.timerEnabled = !0, this.timerStarted = !1, this.localStorageHelper = e
    }

    function T() {
        return (window.criteo_pubtag_prebid_144 || window.criteo_pubtag).context.getIdfs()
    }

    function P(e) {
        (window.criteo_pubtag_prebid_144 || window.criteo_pubtag).context.setIdfs(e)
    }

    function N(e) {
        (window.criteo_pubtag_prebid_144 || window.criteo_pubtag).context.ceh = e
    }
    var A = function() {};

    function x(e) {
        return e.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")
    }
    var F = (R = A, t(D, R), D.prototype.ResizeFrame = function(e, t) {
            if (this.document.defaultView && this.document.defaultView.frameElement) {
                var i = this.document.defaultView.frameElement;
                i.width = e.toString(), i.height = t.toString()
            }
        }, D.prototype.Write = function(e) {
            this.document.open(), this.document.write(e), this.document.close()
        }, D.prototype.LoadScript = function(e) {
            this.Write("<script type='text/javascript' src='" + x(e) + "'><\/script>")
        }, D),
        R;

    function D(e) {
        var t = R.call(this) || this;
        return t.document = e, t
    }
    var k = (O.prototype.eval = function(e) {}, O);

    function O(e) {
        this.name = e
    }
    var M = (U = k, t(W, U), W.prototype.eval = function(e) {
            this.callback && this.callback.apply(this)
        }, W.NAME = "genericEvent", W),
        U;

    function W(e) {
        var t = U.call(this, W.NAME) || this;
        return t.callback = e, t
    }
    var H = (q.prototype.generateRandomId = function() {
        return Math.random().toString(36).replace(/[^a-z]+/g, "").substr(0, 6)
    }, q);

    function q(e, t, i, n, r, o, s, a) {
        this.id = this.generateRandomId(), this.slotId = e, this.impressionId = t, this.cpm = i, this.width = n, this.height = r, this.zoneId = o, this.dealCode = s, this.useSafeframe = null != a && a
    }
    var G = (z = H, t(V, z), V.prototype.GenerateEvent = function(e) {
            var t = this;
            return e.ResizeFrame(this.width, this.height), new M(function() {
                return e.LoadScript(t.displayUrl)
            })
        }, V.prototype.GenerateMessage = function() {
            return {
                displayUrl: this.displayUrl
            }
        }, V),
        z;

    function V(e, t, i, n, r, o, s, a, c) {
        var d = z.call(this, e, t, i, n, r, o, a, c) || this;
        return d.displayUrl = s, d
    }
    var j = (K = H, t(Y, K), Y.prototype.GenerateEvent = function(e) {
            var t = this;
            return e.ResizeFrame(this.width, this.height), new M(function() {
                return e.Write(t.creative)
            })
        }, Y.prototype.GenerateMessage = function() {
            return {
                creative: this.creative
            }
        }, Y),
        K, X, J;

    function Y(e, t, i, n, r, o, s, a, c) {
        var d = K.call(this, e, t, i, n, r, o, a, c) || this;
        return d.creative = s, d
    }
    J = X = X || {}, J[J.Error = 0] = "Error", J[J.Warning = 1] = "Warning", J[J.Debug = 2] = "Debug";
    var Q = ["color: #fff;", "background: #ff8f1c;", "display: inline-block;", "padding: 1px 4px;", "border-radius: 3px;"].join(" "),
        $ = (Z.Log = function(e, t) {
            if (!(Z.LOGLEVEL < e)) {
                var i = X[e].toUpperCase(),
                    n = window.navigator.userAgent,
                    r = 0 < n.indexOf("MSIE ") || 0 < n.indexOf("Trident/");
                window.console && (r ? console.log("[PubTag] " + i + ": " + t) : console.log("%cPubTag", Q, i + ": " + t))
            }
        }, Z.Debug = function(e) {
            Z.Log(X.Debug, e)
        }, Z.Warning = function(e) {
            Z.Log(X.Warning, e)
        }, Z.Error = function(e) {
            Z.Log(X.Error, e)
        }, Z.LOGLEVEL = X.Error, Z);

    function Z() {}

    function ee(e) {
        $.LOGLEVEL = e
    }
    var te = (ie = H, t(ne, ie), ne.prototype.GenerateEvent = function(e) {
            var t = this;
            return "function" != typeof this.nativeCallback ? ($.Error("'nativeCallback' parameter is not a function in placements object"), new M(void 0)) : "object" != typeof this.nativePayload ? ($.Error("'nativePayload' parameter is not an object in placements object"), new M(void 0)) : new M(function() {
                return t.nativeCallback(t.nativePayload)
            })
        }, ne.prototype.GenerateMessage = function() {
            return {
                nativePayload: this.nativePayload
            }
        }, ne),
        ie;

    function ne(e, t, i, n, r, o, s, a, c) {
        var d = ie.call(this, e, t, i, n, r, o, c) || this;
        return d.nativeCallback = s, d.nativePayload = a, d
    }

    function re(e, t) {
        if (e) {
            var i;
            try {
                i = eval("(function(){return " + e + "})()")
            } catch (e) {
                return void $.Error("Error evaluating the function: " + e)
            }
            if ("function" == typeof i) return i.apply(i, t);
            $.Error("The passed value is not a function")
        } else $.Error("Cannot execute an empty function")
    }
    var oe = (se = H, t(ae, se), ae.prototype.GenerateEvent = function(e) {
            var t = this;
            return void 0 !== this.videoCallback ? "function" != typeof this.videoCallback ? ($.Error("'videoCallback' parameter is not a function in video object"), new M(void 0)) : new M(function() {
                return t.videoCallback(t.GenerateMessage())
            }) : (re(this.videoPlayerFunction, [{
                slotid: this.impressionId,
                vastUrl: this.vastUrl,
                vastXml: this.vastXml
            }]), new M(void 0))
        }, ae.prototype.GenerateMessage = function() {
            return {
                vastUrl: this.vastUrl,
                vastXml: this.vastXml,
                slotid: this.impressionId,
                cpm: this.cpm
            }
        }, ae),
        se;

    function ae(e, t, i, n, r, o, s, a, c, d, l) {
        var u = se.call(this, e, t, i, n, r, o, a) || this;
        return u.videoCallback = s, u.vastUrl = c, u.vastXml = d, u.videoPlayerFunction = l, u
    }

    function ce(e, t, i, n, r, o, s, a, c, d, l, u, p, h, v) {
        if (u) return new oe(e, t, i, n, r, o, p, l, c, d, v);
        if (void 0 !== s && void 0 !== a) return new te(e, t, i, n, r, o, s, a, l);
        if (void 0 !== d && 0 !== d.indexOf("<script")) return new j(e, t, i, n, r, o, d, l, h);
        if (void 0 !== d && 0 === d.indexOf("<script")) {
            var f = new RegExp("(?<=src='|\")(.*)(?='|\")"),
                m = d.match(f);
            if (null !== m && 0 < m.length) return new G(e, t, i, n, r, o, m[0], l, h)
        }
        return void 0 !== c ? new G(e, t, i, n, r, o, c, l, h) : void 0
    }
    var de = (le.prototype.getMetricsManager = function() {
        return this.metricsManager
    }, le.prototype.withElapsed = function(e) {
        return this.elapsed = Math.round(e), this
    }, le.prototype.withIsTimeout = function(e) {
        return (this.isTimeout = e) && this.events.push({
            eventId: "CdbCallTimeout"
        }), this
    }, le.prototype.withAdapterStartElapsed = function(e) {
        return this.adapterStartElapsed = Math.round(e), this.events.push({
            eventId: "AdapterBidStart",
            elapsed: this.adapterStartElapsed
        }), this
    }, le.prototype.withCdbCallStartElapsed = function(e) {
        return this.cdbCallStartElapsed = Math.round(e), this.events.push({
            eventId: "CdbCallStart",
            elapsed: this.cdbCallStartElapsed
        }), this
    }, le.prototype.withCdbCallEndElapsed = function(e) {
        return this.cdbCallEndElapsed = Math.round(e), this.events.push({
            eventId: "CdbCallEnd",
            elapsed: this.cdbCallEndElapsed
        }), this
    }, le.prototype.withAdapterEndElapsed = function(e) {
        return this.adapterEndElapsed = Math.round(e), this.events.push({
            eventId: "AdapterBidEnd",
            elapsed: this.adapterEndElapsed
        }), this
    }, le.prototype.withAdapterTimeout = function(e) {
        return this.adapterTimeout = e && Math.round(e), this
    }, le.prototype.withTimeToFirstByte = function(e) {
        return this.timeToFirstByte = e && Math.round(e), this.timeToFirstByte && this.events.push({
            eventId: "TimeToFirstByte",
            elapsed: this.timeToFirstByte
        }), this
    }, le.prototype.withConnectionEstablishmentTime = function(e) {
        return this.connectionEstablishmentTime = e && Math.round(e), this.connectionEstablishmentTime && this.events.push({
            eventId: "TcpConnectionElapsedTime",
            elapsed: this.connectionEstablishmentTime
        }), this
    }, le.prototype.withDomainLookupTime = function(e) {
        return this.domainLookupTime = e && Math.round(e), this.domainLookupTime && this.events.push({
            eventId: "DomainLookupElapsedTime",
            elapsed: this.domainLookupTime
        }), this
    }, le.prototype.withUserPreviousTimestamp = function(e) {
        return e && this.events.push({
            eventId: "UserReturnTime",
            elapsed: (new Date).getTime() - e
        }), this
    }, le.prototype.buildEvents = function(e) {
        if (this.events.length) {
            var t = {
                requestId: e,
                events: this.events
            };
            return void 0 !== this.adapterTimeout && this.adapterEndElapsed > this.adapterTimeout && t.events.push({
                eventId: "AdapterTimeout"
            }), t
        }
    }, le.prototype.clear = function() {
        this.events = []
    }, le);

    function le(e) {
        this.elapsed = 0, this.isTimeout = !1, this.adapterStartElapsed = 0, this.cdbCallStartElapsed = 0, this.cdbCallEndElapsed = 0, this.adapterEndElapsed = 0, this.slotIdsMatchedByCache = [], this.events = [], this.metricsManager = e
    }

    function ue(e) {
        try {
            return JSON.parse(e)
        } catch (e) {
            return
        }
    }
    var pe = (fe.generateCacheBuster = function() {
            return Math.floor(99999999999 * Math.random())
        }, fe),
        he, ve;

    function fe() {}

    function me(e) {
        switch (e.toLowerCase()) {
            case "amp":
                return he.AMP;
            default:
                return he.Unspecified
        }
    }
    ve = he = he || {}, ve[ve.Unspecified = 0] = "Unspecified", ve[ve.AMP = 1] = "AMP";
    var ge = 144,
        ye = (be.prototype.buildUrl = function(e, t, i, n, r) {
            void 0 === i && (i = he.Unspecified);
            var o = be.CRITEO_BIDDER_URL + this.getHandlerPath();
            return o += "?ptv=" + ge, !0 === t.isAdBlocked && (o += "&abp=1"), o = this.appendCommonParameters(o, e, n, r), o += t.isOptOut ? "&optout=1" : "", o += t.bundle ? "&bundle=" + t.bundle : "", i !== he.Unspecified && (o += "&im=" + i), o += "&cb=" + String(pe.generateCacheBuster()), o += t.getContextFlags()
        }, be.prototype.buildErrorUrl = function() {
            return be.CRITEO_BIDDER_URL + be.CRITEO_ERROR_HANDLER
        }, be.prototype.buildCsmEventsUrl = function() {
            return be.CRITEO_BIDDER_URL + be.CRITEO_CSM_EVENTS_HANDLER
        }, be.prototype.buildCsmCountersUrl = function() {
            return be.CRITEO_BIDDER_URL + be.CRITEO_CSM_COUNTERS_HANDLER
        }, be.prototype.appendCommonParameters = function(e, t, i, n) {
            return e += "&profileId=" + String(t), void 0 !== i && (e += "&av=" + String(i)), void 0 !== n && (e += "&wv=" + encodeURIComponent(n)), e
        }, be.prototype.getHandlerPath = function() {
            return this.auditMode ? be.CRITEO_BIDDER_AUDIT_HANDLER : be.CRITEO_BIDDER_HANDLER
        }, be.CRITEO_BIDDER_URL = "https://bidder.criteo.com/", be.CRITEO_BIDDER_HANDLER = "cdb", be.CRITEO_CSM_HANDLER = "csm", be.CRITEO_CSM_EVENTS_HANDLER = "csm/events", be.CRITEO_CSM_COUNTERS_HANDLER = "csm/counters", be.CRITEO_ERROR_HANDLER = "error", be.CRITEO_BIDDER_AUDIT_HANDLER = "prebid/audit", be);

    function be(e) {
        void 0 === e && (e = !1), this.auditMode = e
    }
    var we = (Ce.prototype.sendEventsToBeacon = function(e, t) {
        navigator.sendBeacon && e && navigator.sendBeacon(t, JSON.stringify(e))
    }, Ce);

    function Ce() {
        this.urlBuilder = new ye
    }
    var _e = (Se = we, t(Ee, Se), Ee.prototype.getManagerMetrics = function() {
            var e = this.localStorageHelper.getItem(Ee.MANAGER_METRICS_STORAGE_KEY);
            if (null == e) return {};
            var t = ue(e);
            return void 0 === t ? {} : t
        }, Ee.prototype.setManagerMetrics = function(e) {
            this.localStorageHelper.setItem(Ee.MANAGER_METRICS_STORAGE_KEY, JSON.stringify(e))
        }, Ee.prototype.getLocalStorageKeyCount = function() {
            return this.localStorageHelper.getAllItemsByPrefix("criteo_").length + this.localStorageHelper.getAllItemsByPrefix("cto_").length
        }, Ee.prototype.getPreviousBuildRequestTimestamp = function() {
            var e = this.getManagerMetrics().previousBuildRequestTimestamp;
            return isNaN(e) ? void 0 : e
        }, Ee.prototype.resetPreviousBuildRequestTimestamp = function() {
            var e = this.getManagerMetrics();
            e.previousBuildRequestTimestamp = (new Date).getTime().toString(), this.setManagerMetrics(e)
        }, Ee.prototype.sendEvents = function(e, t, i) {
            void 0 === i && (i = !1), i && (e.withUserPreviousTimestamp(this.getPreviousBuildRequestTimestamp()), this.resetPreviousBuildRequestTimestamp()), this.sendEventsToBeacon(e.buildEvents(t), this.urlBuilder.buildCsmEventsUrl()), e.clear()
        }, Ee.MANAGER_METRICS_STORAGE_KEY = "criteo_pt_cdb_mngr_metrics", Ee),
        Se;

    function Ee(e) {
        var t = Se.call(this) || this;
        return t.localStorageHelper = e, t
    }
    var Ie = (Te.tryInsertPlaceholder = function(e, t, i) {
        var n = document.getElementById(e);
        if (null === n) return $.Warning("Unable to insert ad placeholder : impression id " + e + " not found."), !1;
        if (n.appendChild(this.createPlaceholder()), !t && this.isVisible(n)) return !0;
        this.removePlaceholder(e, i);
        var r = n.parentElement;
        if (null === r) return !1;
        var o = this.createClone(n);
        return r.insertBefore(o, n), o.appendChild(this.createPlaceholder()), this.isVisible(o) ? (i[e] = o, !0) : ($.Warning("Ad placeholder created but not visible : can't render."), r.removeChild(o), !1)
    }, Te.isVisible = function(e) {
        return 0 !== e.offsetWidth && 0 !== e.offsetHeight && 0 !== e.getClientRects().length
    }, Te.createClone = function(e) {
        var t = e.cloneNode(!1);
        return t.id = this.generateRandomId(), t.className = "", "none" === t.style.display && t.style.removeProperty("display"), "SPAN" === t.tagName && (t.style.display = "block"), e.style.display = "none", t
    }, Te.generateRandomId = function() {
        for (var e = "1234567890abcdefghijklmnopqrstuvwxyz", t = "", i = 0; i < 20; i++) {
            var n = Math.floor(Math.random() * e.length);
            t += e.charAt(n)
        }
        return t
    }, Te.createPlaceholder = function() {
        var e = document.createElement("div");
        return e.style.width = "1px", e.style.height = "1px", e.style.display = "block", e.className = Te.PLACEHOLDER_NAME, e
    }, Te.removePlaceholder = function(e, t) {
        var i = t[e];
        void 0 !== i && null !== i.parentNode && i.parentNode.removeChild(i);
        var n = document.getElementById(e);
        if (null !== n)
            for (var r = 0, o = n.getElementsByClassName(Te.PLACEHOLDER_NAME); r < o.length; r++) {
                var s = o[r];
                null !== s.parentNode && s.parentNode.removeChild(s)
            }
    }, Te.insertAdIFrame = function(e, t) {
        var i, n = t[e];
        if (void 0 !== n) i = n;
        else {
            var r = document.getElementById(e);
            if (null === r) return null;
            i = r
        }
        for (var o = 0, s = i.getElementsByClassName(Te.PLACEHOLDER_NAME); o < s.length; o++) {
            for (var a = s[o], c = 0, d = a.childNodes; c < d.length; c++) {
                var l = d[c];
                null !== l.parentNode && l.parentNode.removeChild(l)
            }
            var u = this.createAdIFrame();
            return a.appendChild(u), a.style.width = "", a.style.height = "", a.style.display = "", u
        }
        return null
    }, Te.createAdIFrame = function() {
        var e = document.createElement("iframe");
        return e.scrolling = "no", e.marginWidth = "0", e.marginHeight = "0", e.frameBorder = "0", e.style.border = "0", e.style.verticalAlign = "bottom", e
    }, Te.removePlaceholders = function(e, t, i) {
        for (var n = 0, r = e; n < r.length; n++) {
            var o = r[n].impId; - 1 === t.indexOf(o) && Te.removePlaceholder(o, i)
        }
    }, Te.tryInsertPlaceholders = function(e, t, i) {
        for (var n = [], r = 0, o = e; r < o.length; r++) {
            var s = o[r],
                a = s.impId;
            Te.tryInsertPlaceholder(a, t, i) && n.push(s)
        }
        return n
    }, Te.PLACEHOLDER_NAME = "criteo_placeholder", Te);

    function Te() {}
    var Pe = (Ae.prototype.isValid = function() {
        return 0 < this.slots.length
    }, Ae.prototype.getRequest = function() {
        for (var e, t = [], i = 0, n = this.slots; i < n.length; i++) {
            var r = n[i],
                o = {
                    slotid: r.slotId,
                    impid: r.impId
                };
            if (void 0 !== r.zoneId && (o.zoneid = r.zoneId), void 0 === r.nativeCallback && !r.native || (o.native = !0), void 0 !== r.transactionId && (o.transactionid = r.transactionId), void 0 !== r.publisherSubId && (o.publishersubid = r.publisherSubId), void 0 !== r.sizes) {
                for (var s = [], a = 0, c = r.sizes; a < c.length; a++) {
                    var d = c[a];
                    s.push(d.width + "x" + d.height)
                }
                o.sizes = s
            }
            if (void 0 !== r.video) {
                var l = {
                    playersizes: this.parsePlayerSizes(r.video.playersize),
                    mimes: r.video.mimes,
                    protocols: r.video.protocols,
                    maxduration: r.video.maxduration,
                    api: r.video.api,
                    skip: r.video.skip,
                    placement: r.video.placement,
                    playbackmethod: r.video.playbackmethod,
                    minduration: r.video.minduration,
                    startdelay: r.video.startdelay,
                    plcmt: r.video.plcmt
                };
                o.video = l
            }
            if (void 0 !== this.viewportComputer) {
                var u = this.viewportComputer.getSlotPosition(r);
                void 0 !== u && (o.position = {
                    top: u.top,
                    left: u.left
                })
            }
            void 0 !== r.ext && (o.ext = r.ext), void 0 !== r.rwdd && (o.rwdd = r.rwdd), !this.fledgeEnabled && (null === (e = o.ext) || void 0 === e ? void 0 : e.ae) && delete o.ext.ae, t.push(o)
        }
        var p = L(L({}, this.context.getUser()), {
                ceh: this.context.ceh,
                uspOptout: this.context.ccpaOptout
            }),
            h = this.context.getSite();
        this.context.getUserExtWithContextualData(), this.context.getPublisherExt();
        var v = {
            publisher: {
                url: this.context.highestAccessibleUrl
            },
            slots: t,
            user: p,
            site: h,
            bcat: this.bcat,
            badv: this.badv,
            bapp: this.bapp
        };
        if (void 0 !== this.networkId && (v.publisher.networkid = this.networkId), this.privacyWrapper && (this.privacyWrapper.gdprConsent && (v.gdprConsent = this.privacyWrapper.gdprConsent), this.privacyWrapper.ccpaIabConsent && (p.uspIab = this.privacyWrapper.ccpaIabConsent.uspString), this.privacyWrapper.gppConsent && (void 0 === this.regs && (this.regs = {}), this.regs.gpp = this.privacyWrapper.gppConsent.gpp, this.regs.gpp_sid = this.privacyWrapper.gppConsent.gppSid)), void 0 !== this.viewportComputer) {
            var f = this.viewportComputer.getViewport();
            v.viewport = {
                width: f.width,
                height: f.height,
                scrollTop: f.scrollTop,
                scrollLeft: f.scrollLeft
            }
        }
        return void 0 !== this.adapterTimeout && (v.tmax = this.adapterTimeout), void 0 !== this.auctionStart && (v.auctionStart = this.auctionStart), void 0 !== this.clientRequestId && (v.id = this.clientRequestId), void 0 !== this.userIds && (v.eids = this.userIds), void 0 !== this.source && (v.source = this.source), void 0 === this.regs || void 0 === this.regs.coppa && void 0 === this.regs.gpp && void 0 === this.regs.gpp_sid || (v.regs = {
            coppa: this.regs.coppa,
            gpp: this.regs.gpp,
            gpp_sid: this.regs.gpp_sid
        }), v
    }, Ae.parsePlayerSize = function(e) {
        return e[0] + "x" + e[1]
    }, Ae.prototype.parsePlayerSizes = function(e) {
        return e ? Array.isArray(e[0]) ? e.map(function(e) {
            return Ae.parsePlayerSize(e)
        }) : [Ae.parsePlayerSize(e)] : e
    }, Ae.prototype.getUrl = function() {
        return this.urlBuilder.buildUrl(this.profileId, this.context, this.integrationMode, this.adapterVersion, this.wrapperVersion)
    }, Ae);

    function Ae(e, t, i, n, r, o, s, a, c, d, l, u, p, h, v, f, m, g, y, b) {
        this.slots = e, this.context = t, this.urlBuilder = i, this.profileId = n, this.integrationMode = r || he.Unspecified, this.networkId = o, this.adapterVersion = s, this.privacyWrapper = a, this.wrapperVersion = c, this.viewportComputer = d, this.adapterTimeout = l, this.clientRequestId = u, this.userIds = p, this.auctionStart = h, this.source = v, this.regs = f, this.bcat = m, this.badv = g, this.bapp = y, this.fledgeEnabled = b || !1
    }

    function xe(e) {
        var t = {
            slots: void 0,
            time_to_next_call: 0
        };
        return void 0 !== e.exd && (void 0 !== e.exd.time_to_next_call && (t.time_to_next_call = e.exd.time_to_next_call), t.slots = e.exd.slots, delete e.exd), t
    }

    function Re() {
        var i = (new Date).getTime();
        return "undefined" != typeof performance && "function" == typeof performance.now && (i += performance.now()), "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
            var t = (i + 16 * Math.random()) % 16 | 0;
            return i = Math.floor(i / 16), ("x" === e ? t : 3 & t | 8).toString(16)
        })
    }
    var De = function(e, t, i, n, r, o, s, a, c, d, l, u) {
            this.slotId = null != u ? u : Re().replace(/-/g, ""), this.impId = e, this.zoneId = t, this.native = i, this.nativeCallback = n, this.transactionId = r, this.sizes = o, this.publisherSubId = s, this.mediaTypes = a, this.video = c, this.ext = d, this.rwdd = l
        },
        ke = function(e, t, i, n, r, o, s, a, c, d, l, u) {
            this.playersize = e, this.mimes = t, this.protocols = i, this.maxduration = n, this.api = r, this.skip = o, this.placement = s, this.playbackmethod = a, this.minduration = c, this.startdelay = d, this.videoCallback = l, this.plcmt = u
        },
        Oe = (Me.CreateRunning = function() {
            var e = new Me;
            return e.start(), e
        }, Me.CreateWithStartTime = function(e) {
            var t = new Me(!1);
            return t.startTime = e, t
        }, Me.TimeSincePageLoad = function() {
            if (window.performance) {
                if (window.performance.now) return window.performance.now();
                if (window.performance.timing && window.performance.timing.navigationStart) return (new Date).getTime() - performance.timing.navigationStart
            }
            return 0
        }, Me.prototype.start = function() {
            this.startTime = this.now()
        }, Me.prototype.elapsed = function() {
            return this.now() - this.startTime
        }, Me);

    function Me(e) {
        void 0 === e && (e = !0), e && window.performance && window.performance.now ? this.now = window.performance.now.bind(window.performance) : Date.now ? this.now = Date.now : this.now = function() {
            return (new Date).getTime()
        }
    }

    function Ue(e) {
        if (window.performance && window.performance.getEntries)
            for (var t = window.performance.getEntries(), i = t.length - 1; 0 <= i; --i) {
                var n = t[i];
                if (n.name === e && n.duration) return Math.round(n.duration)
            }
    }
    var Fe = (Le.prototype.sendRequest = function(e) {
        this.url = e, this.sendTime = Oe.CreateRunning(), this.builder.withCdbCallStartElapsed(this.timer.elapsed())
    }, Le.prototype.requestReceived = function(e) {
        void 0 === e && (e = !1), this.builder.withElapsed(Ue(this.url) || this.sendTime.elapsed()), this.builder.withCdbCallEndElapsed(this.timer.elapsed()), this.builder.withIsTimeout(e)
    }, Le.prototype.finish = function() {
        this.builder.withAdapterEndElapsed(this.timer.elapsed());
        var e = Le.getLastCdbTiming();
        void 0 !== e && (this.builder.withTimeToFirstByte(Le.computeTimeToFirstByte(e)), this.builder.withConnectionEstablishmentTime(Le.computeConnectionEstablishmentTime(e)), this.builder.withDomainLookupTime(Le.computeDomainLookupTime(e)))
    }, Le.getLastCdbTiming = function() {
        if (void 0 !== window.performance && void 0 !== window.performance.getEntriesByType && "function" == typeof window.performance.getEntriesByType) {
            var e = window.performance.getEntriesByType("resource");
            if (void 0 !== e) {
                var t = e.filter(function(e) {
                    return 0 <= e.name.indexOf("cdb")
                });
                return void 0 !== t && 0 < t.length ? t[t.length - 1] : void 0
            }
        }
    }, Le.computeTimeToFirstByte = function(e) {
        var t = e.responseStart,
            i = e.requestStart;
        if (void 0 !== t && void 0 !== i) return t - i
    }, Le.computeConnectionEstablishmentTime = function(e) {
        var t = e.connectEnd - e.connectStart;
        return isNaN(t) ? void 0 : t
    }, Le.computeDomainLookupTime = function(e) {
        var t = e.domainLookupEnd - e.domainLookupStart;
        return isNaN(t) ? void 0 : t
    }, Le);

    function Le(e, t, i) {
        this.builder = e, this.timer = void 0 !== t ? Oe.CreateWithStartTime(t) : Oe.CreateRunning();
        var n = this.timer.elapsed();
        this.builder.withAdapterStartElapsed(n), void 0 !== i && this.builder.withAdapterTimeout(i)
    }
    var Be = (Ne.prototype.toString = function() {
        return this.width + "x" + this.height
    }, Ne);

    function Ne(e, t) {
        this.width = e, this.height = t
    }

    function We(e) {
        var t = "number" == typeof window.PREBID_TIMEOUT ? window.PREBID_TIMEOUT : void 0;
        return e && t ? Math.min(e, t) : e || t || void 0
    }
    var He = function(e, t) {
            this.top = e, this.left = t
        },
        qe = function(e, t, i, n) {
            this.width = e, this.height = t, this.scrollTop = i, this.scrollLeft = n
        },
        Ge = (ze.getHighestAccessibleWindow = function(e) {
            var t = e,
                i = !1;
            try {
                for (; t.parent.document !== t.document;) {
                    if (!t.parent.document) {
                        i = !0;
                        break
                    }
                    t = t.parent
                }
            } catch (e) {
                i = !0
            }
            return {
                topFrame: t,
                err: i
            }
        }, ze.getHighestAccessibleUrl = function(e) {
            var t = e.topFrame;
            if (!e.err) return t.location.href;
            try {
                var i = t.top.location.href;
                if (i) return i
            } catch (e) {}
            try {
                var n = t.location.ancestorOrigins;
                if (n) return n[n.length - 1]
            } catch (e) {}
            return t.document.referrer
        }, ze.inIframe = function() {
            try {
                return window.self !== window.top
            } catch (e) {
                return !0
            }
        }, ze);

    function ze() {}
    var Ve = (je.prototype.getViewport = function() {
        var e = Ge.getHighestAccessibleWindow(window).topFrame,
            t = e.document,
            i = e.innerWidth || t.documentElement.clientWidth,
            n = e.innerHeight || t.documentElement.clientHeight,
            r = t.documentElement.scrollTop || t.body && t.body.scrollTop || 0,
            o = t.documentElement.scrollLeft || t.body && t.body.scrollLeft || 0;
        return new qe(i, n, r, o)
    }, je.prototype.getSlotPosition = function(e) {
        var t = e.impId,
            i = document.getElementById(t);
        if (null !== i) {
            var n = i.getBoundingClientRect();
            return new He(n.top, n.left)
        }
    }, je);

    function je() {}

    function Ke(e) {
        try {
            return e.localStorage
        } catch (e) {
            return
        }
    }
    var Xe = (Je.prototype.checkLocalStorage = function(e) {
        if (!this.localStorage) return !1;
        var t = this.CHECK_STORAGE_KEY;
        try {
            return this.checkTcfPurposeOne(e) ? (this.localStorage.setItem(t, t), this.localStorage.removeItem(t), !0) : ($.Debug("Purpose One not granted"), !1)
        } catch (e) {
            return !1
        }
    }, Je.prototype.checkTcfPurposeOne = function(e) {
        return !(e && e.gdprConsent && e.gdprConsent.purposes) || !0 === e.gdprConsent.purposes[1]
    }, Je.prototype.removeItem = function(e) {
        this.localStorageEnabled && (this.localStorage.removeItem(e), this.localStorage.removeItem(e + this.EXPIRE_SUFFIX))
    }, Je.prototype.getItem = function(e, t) {
        if (!this.localStorageEnabled) return null;
        var i = (new Date).getTime(),
            n = this.localStorage.getItem(e + this.EXPIRE_SUFFIX),
            r = n ? parseInt(n, 10) : -1;
        return -1 !== r && r < i || t && (-1 === r || t < r - i) ? (this.removeItem(e), null) : this.localStorage.getItem(e)
    }, Je.prototype.setItem = function(e, t, i) {
        if (this.localStorageEnabled) try {
            if (this.localStorage.setItem(e, t), i) {
                var n = (new Date).getTime() + i;
                this.localStorage.setItem(e + this.EXPIRE_SUFFIX, n.toString())
            }
        } catch (e) {}
    }, Je.prototype.getAllItemsByPrefix = function(e) {
        var t = [];
        if (this.localStorageEnabled)
            for (var i in localStorage) 0 === i.indexOf(e) && t.push(i);
        return t
    }, Je);

    function Je(e, t) {
        this.EXPIRE_SUFFIX = "_expires", this.CHECK_STORAGE_KEY = "criteo_localstorage_check", this.localStorage = Ke(e || window), this.localStorageEnabled = this.checkLocalStorage(t)
    }
    var Ye = (Qe.prototype.send = function(e, t, i, n) {
        var r = void 0 !== this.data ? "POST" : "GET",
            o = this.getXMLHttpRequest(r, e, t, i, n);
        if (void 0 !== o) o.send(this.data);
        else {
            var s = this.getXDomainRequest(r, e, t, i, n);
            void 0 !== s && s.send(this.data)
        }
    }, Qe.prototype.getXMLHttpRequest = function(e, t, i, n, r) {
        var o = new XMLHttpRequest;
        if ("withCredentials" in o) return o.open(e, this.url, !0), o.timeout = r || Qe.LOCAL_PASSBACK_TIMEOUT, this.contentType ? o.setRequestHeader("Content-type", this.contentType) : "POST" === e && o.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), o.withCredentials = this.withCredentials, o.onload = function() {
            4 === o.readyState && 200 === o.status ? t(o.responseText) : i(o.readyState, o.status)
        }, o.onerror = function() {
            i(void 0, void 0)
        }, n && (o.ontimeout = n), o
    }, Qe.prototype.getXDomainRequest = function(e, t, i, n, r) {
        if ("undefined" != typeof XDomainRequest) {
            var o = new XDomainRequest;
            return o.timeout = r || Qe.LOCAL_PASSBACK_TIMEOUT, o.open(e, this.url), o.onload = function() {
                void 0 !== o.responseText ? t(o.responseText) : i(void 0, void 0)
            }, o.onerror && (o.onerror = function() {
                i(void 0, void 0)
            }), o.ontimeout && n && (o.ontimeout = n), o
        }
    }, Qe.LOCAL_PASSBACK_TIMEOUT = 3e4, Qe);

    function Qe(e, t, i, n) {
        void 0 === n && (n = !0), this.url = e, this.data = t, this.contentType = i, this.withCredentials = n
    }
    var $e = (Ze.prototype.retrievePixels = function(e, t) {
        var i = this;
        new Ye(this.getUserSyncUrl(e, t)).send(function(e) {
            if (e) {
                var t = Ze.parseUserSyncResponse(e);
                t ? i.onPixelsRetrieved(t) : i.errorReporter.log("Error", "Unable to parse response from user sync")
            }
        }, function(e, t) {
            $.Warning("User Sync Pixel endpoint error; readyState " + e + "; requestStatus " + t)
        }, function() {
            $.Warning("User Sync Pixel endpoint timeout")
        }, this.pixelSyncTimeout)
    }, Ze.prototype.getUserSyncUrl = function(e, t) {
        var i = null == e ? void 0 : e.gdprConsent,
            n = null == e ? void 0 : e.ccpaIabConsent,
            r = [];
        return (null == i ? void 0 : i.consentData) && r.push("gdpr=" + i.consentData), (null == i ? void 0 : i.gdprApplies) && r.push("gdprapplies=" + i.gdprApplies), (null == n ? void 0 : n.uspString) && r.push("ccpa=" + n.uspString), (null == t ? void 0 : t.country_code) && r.push("countrycode=" + t.country_code), this.debug && r.push("debug=1"), this.pixelSyncEndpoint + (r.length ? "?" + r.join("&") : "")
    }, Ze.parseUserSyncResponse = function(e) {
        var t = ue(e);
        return t ? ("pixels" in t ? Array.isArray(t.pixels) ? t.pixels = t.pixels.filter(function(t) {
            try {
                return new URL(t), !0
            } catch (e) {
                return $.Warning("Failed to parse User Sync Pixel URL: " + t), !1
            }
        }) : ($.Warning("pixels field in user sync response is not an array: " + t.pixels), t.pixels = []) : t.pixels = [], t) : void $.Warning("Failed to parse user sync pixel JSON payload")
    }, Ze);

    function Ze(e, t, i) {
        void 0 === i && (i = !1), this.pixelSyncEndpoint = "https://ssp-sync.criteo.com/user-sync/pixels", this.pixelSyncTimeout = 2e3, this.errorReporter = t, this.onPixelsRetrieved = e, this.debug = i
    }
    var et = (tt.execUserSync = function(e, t, i, n) {
        void 0 === n && (n = !1), new $e(tt.appendUserSyncPixels, e, n).retrievePixels(t, i)
    }, tt.getOrCreateTagContainer = function() {
        var e = document.getElementById(tt.tagElementName);
        if (e) return e;
        var t = document.createElement("div");
        return t.setAttribute("id", tt.tagElementName), t.style.display = "none", document.body.appendChild(t), t
    }, tt.appendUserSyncPixels = function(e) {
        if (e.pixels.length)
            for (var t = tt.getOrCreateTagContainer(), i = 0, n = e.pixels; i < n.length; i++) {
                var r = n[i],
                    o = new Image;
                o.src = r, o.alt = "", t.appendChild(o)
            }
    }, tt.tagElementName = "criteoUserSyncTagsContainer", tt);

    function tt() {}
    var it = function(e, t, i) {
            this.coppa = e, this.gpp = t, this.gpp_sid = i
        },
        nt = 280,
        rt = 5e3,
        ot = "https://grid-mercury.criteo.com",
        st = 500,
        at = "https://grid-mercury.criteo.com/fledge/decision",
        ct, dt;
    dt = ct = ct || {}, dt.Native = "native", dt.Banner = "banner", dt.Video = "video";
    var lt = (ut.prototype.interpretResponse = function(e, t) {
        return []
    }, ut.prototype.handleBidWon = function() {}, ut.prototype.handleBidTimeout = function() {}, ut.prototype.handleSetTargeting = function() {}, ut);

    function ut() {}
    var pt = (ht.prototype.hasValidNativeParams = function(e) {
        return !(e.nativeParams && (e.nativeParams.image && (!0 !== e.nativeParams.image.sendId || !0 === e.nativeParams.image.sendTargetingKeys) || e.nativeParams.icon && (!0 !== e.nativeParams.icon.sendId || !0 === e.nativeParams.icon.sendTargetingKeys) || e.nativeParams.clickUrl && (!0 !== e.nativeParams.clickUrl.sendId || !0 === e.nativeParams.clickUrl.sendTargetingKeys) || e.nativeParams.displayUrl && (!0 !== e.nativeParams.displayUrl.sendId || !0 === e.nativeParams.displayUrl.sendTargetingKeys) || e.nativeParams.privacyLink && (!0 !== e.nativeParams.privacyLink.sendId || !0 === e.nativeParams.privacyLink.sendTargetingKeys) || e.nativeParams.privacyIcon && (!0 !== e.nativeParams.privacyIcon.sendId || !0 === e.nativeParams.privacyIcon.sendTargetingKeys)))
    }, ht.prototype.buildCdbUrl = function() {
        return this.url
    }, ht.prototype.buildCdbRequest = function() {
        if (this.requestBuilder.isValid()) {
            var e = Math.min((this.timeout || rt) + 1e3, rt);
            return this.adBlockFlagManager.setAdBlockFlagTimer(e), this.timer.sendRequest(this.url), this.requestBuilder.getRequest()
        }
        $.Debug("Request ignored because it doesnt contain any slot")
    }, ht.GetAllAdapters = function() {
        return (window.Criteo_prebid_144 || window.Criteo).prebid_adapters
    }, ht.GetAdapter = function(e) {
        if ("string" == typeof e) return new lt;
        for (var t = ht.GetAllAdapters(), i = 0, n = e.bidRequests; i < n.length; i++) {
            var r = n[i];
            if ((null == r ? void 0 : r.bidId) && t && r.bidId in t) return t[r.bidId]
        }
        var o = e.bidRequests[0].auctionId;
        return t && o in t ? t[o] : void 0
    }, ht.isPrebid3OrAbove = function(e) {
        if (null == e) return !1;
        var t = parseInt(e, 10);
        return t != Number.NaN && 3 <= t
    }, ht.createCriteoNativeAdWithCallback = function(e, t, i) {
        var n = x(e);
        return window.criteo_prebid_native_slots = window.criteo_prebid_native_slots || {}, window.criteo_prebid_native_slots[n] = {
            callback: i,
            payload: t
        }, '<script type="text/javascript">\n            var win = window;\n            for (var i = 0; i < 10; ++i) {\n                win = win.parent;\n                if (win.criteo_prebid_native_slots) {\n                    var responseSlot = win.criteo_prebid_native_slots["' + n + '"];\n                    responseSlot.callback(responseSlot.payload);\n                    break;\n                }\n            }\n        <\/script>'
    }, ht.createPrebidNativeAd = function(e) {
        return {
            sendTargetingKeys: !1,
            title: e.products[0].title,
            body: e.products[0].description,
            sponsoredBy: e.advertiser.description,
            icon: e.advertiser.logo,
            image: e.products[0].image,
            clickUrl: e.products[0].click_url,
            privacyLink: e.privacy.optout_click_url,
            privacyIcon: e.privacy.optout_image_url,
            cta: e.products[0].call_to_action,
            price: e.products[0].price,
            impressionTrackers: e.impression_pixels.map(function(e) {
                return e.url
            })
        }
    }, ht.prototype.getBidRequestForSlot = function(e) {
        for (var t, i, n, r = 0, o = this.bidRequests; r < o.length; r++) {
            var s = o[r];
            if (s.adUnitCode === e.impid) {
                if (s.params.zoneId && parseInt(s.params.zoneId, 10) === e.zoneid) return s;
                if (e.native) {
                    if ((null === (t = s.mediaTypes) || void 0 === t ? void 0 : t.native) || s.nativeParams) return s
                } else if (e.video) {
                    if (null === (i = s.mediaTypes) || void 0 === i ? void 0 : i.video) return s
                } else if (null === (n = s.mediaTypes) || void 0 === n ? void 0 : n.banner) return s
            }
        }
    }, ht.prototype.getSlotForAdUnitCode = function(e) {
        for (var t = 0, i = this.slots; t < i.length; t++) {
            var n = i[t];
            if (n && n.impId === e) return n
        }
    }, ht.getVideoInfoFromBidRequest = function(e) {
        var t, i, n, r, o;
        if (ht.hasVideoMediaType(e)) return new ke(e.mediaTypes.video.playerSize, e.mediaTypes.video.mimes, e.mediaTypes.video.protocols, e.mediaTypes.video.maxduration, e.mediaTypes.video.api, e.mediaTypes.video.skip || (null === (t = e.params.video) || void 0 === t ? void 0 : t.skip) || 0, e.mediaTypes.video.placement || (null === (i = e.params.video) || void 0 === i ? void 0 : i.placement), e.mediaTypes.video.playbackmethod || (null === (n = e.params.video) || void 0 === n ? void 0 : n.playbackmethod), e.mediaTypes.video.minduration || (null === (r = e.params.video) || void 0 === r ? void 0 : r.minduration), e.mediaTypes.video.startdelay || (null === (o = e.params.video) || void 0 === o ? void 0 : o.startdelay) || 0, void 0, e.mediaTypes.video.plcmt)
    }, ht.hasVideoMediaType = function(e) {
        var t, i, n;
        return 0 < (null === (n = null === (i = null === (t = null == e ? void 0 : e.mediaTypes) || void 0 === t ? void 0 : t.video) || void 0 === i ? void 0 : i.playerSize) || void 0 === n ? void 0 : n.length)
    }, ht.prototype.interpretResponse = function(e, t) {
        var i, n, r, o, s, a, c, d, l, u, p, h, v, f = this,
            m = window.criteo_pubtag_prebid_144 || window.criteo_pubtag;
        this.timer.requestReceived(), this.adBlockFlagManager.disableAdBlockFlagTimer();
        var g = xe(e),
            y = {};
        if (void 0 !== g.slots)
            for (var b = 0, w = g.slots; b < w.length; b++) y[(I = w[b]).imp_id] = I;
        var C = [],
            _ = [];
        if (e.slots && Array.isArray(e.slots))
            for (var S = 0, E = e.slots; S < E.length; S++) {
                var I = E[S],
                    T = this.getBidRequestForSlot(I);
                if (T)
                    if (!0 === m.context.isAdBlocked) {
                        if (void 0 !== (D = ce(I.slotid, I.impid, I.cpm, I.width, I.height, I.zoneid, T.params.nativeCallback, I.native, I.displayurl, I.creative, I.deal, null === (i = y[I.slotid]) || void 0 === i ? void 0 : i.enable_safeframe)) && Ie.tryInsertPlaceholder(T.adUnitCode, !0, m.context.cloneByImpressionId)) {
                            var P = Ie.insertAdIFrame(T.adUnitCode, m.context.cloneByImpressionId);
                            if (null != P) {
                                var A = new F(P.contentDocument);
                                D.GenerateEvent(A).eval(window.criteo_pubtag_prebid_144)
                            }
                        }
                    } else {
                        var x = T.bidId,
                            R = I.ttl || y[I.slotid] && y[I.slotid].ttl || 60,
                            D = {
                                requestId: x,
                                cpm: I.cpm,
                                currency: I.currency,
                                netRevenue: !0,
                                ttl: R,
                                creativeId: I.creativecode || x,
                                width: I.width,
                                height: I.height,
                                dealId: I.deal
                            };
                        if ((null === (r = null === (n = e.ext) || void 0 === n ? void 0 : n.paf) || void 0 === r ? void 0 : r.transmission) && (null === (s = null === (o = I.ext) || void 0 === o ? void 0 : o.paf) || void 0 === s ? void 0 : s.content_id)) {
                            var k = {
                                content_id: I.ext.paf.content_id,
                                transmission: e.ext.paf.transmission
                            };
                            D.meta = L(L({}, D.meta), {
                                paf: k
                            })
                        }(null === (c = null === (a = I.ext) || void 0 === a ? void 0 : a.meta) || void 0 === c ? void 0 : c.networkName) && (D.meta = L(L({}, D.meta), {
                            networkName: I.ext.meta.networkName
                        })), I.adomain && (D.meta = L(L({}, D.meta), {
                            advertiserDomains: I.adomain
                        })), I.native ? T.params.nativeCallback ? D.ad = ht.createCriteoNativeAdWithCallback(x, I.native, T.params.nativeCallback) : (D.native = ht.createPrebidNativeAd(I.native), D.mediaType = ct.Native) : I.video ? (D.vastUrl = I.displayurl, D.mediaType = ct.Video, "outstream" === (null === (l = null === (d = T.mediaTypes) || void 0 === d ? void 0 : d.video) || void 0 === l ? void 0 : l.context) && ((null === (u = this.utilMethods) || void 0 === u ? void 0 : u.createOutstreamVideoRenderer) && (D.renderer = null === (p = this.utilMethods) || void 0 === p ? void 0 : p.createOutstreamVideoRenderer(I)), D.renderer = null !== (h = D.renderer) && void 0 !== h ? h : this.createOutstreamVideoRenderer(I))) : D.ad = I.creative, C.push(D)
                    }
                else $.Error("Unable to bid request for slot " + I)
            }
        if (this.fledgeEnabled && e.ext && Array.isArray(null === (v = e.ext) || void 0 === v ? void 0 : v.igbid)) {
            var O = e.ext.seller || ot,
                M = e.ext.sellerTimeout || st,
                U = e.ext.sellerSignals || {};
            e.ext.igbid.forEach(function(e) {
                var t, i = {};
                e.igbuyer.forEach(function(e) {
                    i[e.origin] = e.buyerdata
                });
                for (var n = 0, r = f.bidRequests; n < r.length; n++) {
                    var o = r[n];
                    if (o.bidId === e.impid) {
                        t = o;
                        break
                    }
                }!U.floor && (null == t ? void 0 : t.params.bidFloor) && (U.floor = null == t ? void 0 : t.params.bidFloor), !U.sellerCurrency && (null == t ? void 0 : t.params.bidFloorCur) && (U.sellerCurrency = null == t ? void 0 : t.params.bidFloorCur), _.push({
                    bidId: e.impid,
                    config: {
                        seller: O,
                        sellerSignals: U,
                        sellerTimeout: M,
                        perBuyerSignals: i,
                        auctionSignals: {},
                        decisionLogicUrl: at,
                        interestGroupBuyers: Object.keys(i)
                    }
                })
            })
        }
        return this.timer.finish(), this.metricsManager.sendEvents(this.metricBuilder, this.clientRequestId, !0), !0 === e.user_sync && et.execUserSync(m.context.remoteLogging, this.privacies, e), _.length ? {
            bids: C,
            fledgeAuctionConfigs: _
        } : C
    }, ht.prototype.handleBidWon = function() {}, ht.prototype.handleBidTimeout = function() {
        this.timer.requestReceived(!0), this.timer.finish(), this.metricsManager.sendEvents(this.metricBuilder, this.clientRequestId, !0)
    }, ht.prototype.handleSetTargeting = function() {}, ht.prototype.onDataDeletionRequest = function(e) {
        var t = (window.criteo_pubtag_prebid_144 || window.criteo_pubtag).context,
            i = t.bundle;
        t.identityHelper.deleteCriteoUid(), i && fetch("https://privacy.criteo.com/api/privacy/datadeletionrequest", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                publisherUserId: i
            })
        })
    }, ht.prototype.getBannerSizes = function(e, t) {
        var i, n;
        return (null === (n = null === (i = e.mediaTypes) || void 0 === i ? void 0 : i.banner) || void 0 === n ? void 0 : n.sizes) || (t ? e.sizes : []) || []
    }, ht.prototype.getNativeSizes = function(e) {
        var t, i, n;
        return (null === (n = null === (i = null === (t = e.mediaTypes) || void 0 === t ? void 0 : t.native) || void 0 === i ? void 0 : i.image) || void 0 === n ? void 0 : n.sizes) || []
    }, ht.prototype.getSizes = function(e, t) {
        var i = this.getBannerSizes(e, !t).map(function(e) {
                return new Be(e[0], e[1])
            }),
            n = this.getNativeSizes(e).map(function(e) {
                return new Be(e[0], e[1])
            });
        return i.concat(n).filter(function(e, t, i) {
            return i.indexOf(e) === t
        })
    }, ht.prototype.createOutstreamVideoRenderer = function(i) {
        if (void 0 !== i.video_callback) return {
            url: "#",
            render: function(e, t) {
                re(i.video_callback, [{
                    slotid: i.impid,
                    vastUrl: i.displayurl,
                    vastXml: i.creative,
                    documentContext: t
                }])
            },
            config: {
                documentResolver: function(e, t, i) {
                    return null != i ? i : t
                }
            }
        }
    }, ht.prototype.parseSizes = function(e) {
        try {
            if (e) return 2 === e.length && "number" == typeof e[0] && "number" == typeof e[1] ? [new Be(e[0], e[1])] : (e || []).map(function(e) {
                return new Be(e[0], e[1])
            })
        } catch (e) {
            $.Debug("Could not parse size" + e)
        }
        return []
    }, ht.prototype.pickAvailableGetFloorFunc = function(t) {
        if (t.getFloor) return t.getFloor;
        if (t.params.bidFloor && t.params.bidFloorCur) try {
            var i = parseFloat(t.params.bidFloor);
            return function(e) {
                return {
                    currency: t.params.bidFloorCur,
                    floor: i
                }
            }
        } catch (e) {}
    }, ht.prototype.enrichSlotWithFloors = function(e, t) {
        var i, n, r, o, s, a, c;
        try {
            var d = {},
                l = this.pickAvailableGetFloorFunc(t);
            void 0 !== l && ((null === (i = t.mediaTypes) || void 0 === i ? void 0 : i.banner) && (d.banner = {}, this.parseSizes(null === (r = null === (n = t.mediaTypes) || void 0 === n ? void 0 : n.banner) || void 0 === r ? void 0 : r.sizes).forEach(function(e) {
                void 0 !== l && (d.banner[e.toString()] = l.call(t, {
                    size: [e.width, e.height],
                    mediaType: ct.Banner
                }))
            })), (null === (o = t.mediaTypes) || void 0 === o ? void 0 : o.video) && (d.video = {}, this.parseSizes(null === (a = null === (s = t.mediaTypes) || void 0 === s ? void 0 : s.video) || void 0 === a ? void 0 : a.playerSize).forEach(function(e) {
                void 0 !== l && (d.video[e.toString()] = l.call(t, {
                    size: [e.width, e.height],
                    mediaType: ct.Video
                }))
            })), (null === (c = t.mediaTypes) || void 0 === c ? void 0 : c.native) && (d.native = {}, d.native["*"] = l.call(t, {
                size: "*",
                mediaType: ct.Native
            })), Object.keys(d).length && (e = L(L({}, e), {
                floors: d
            })))
        } catch (e) {
            $.Debug("Could not parse floors from Prebid: " + e)
        }
        return e
    }, ht);

    function ht(e, t, i, n, r, o) {
        var s, a, c, d, l, u, p, h, v, f, m, g, y, b, w, C;
        this.utilMethods = o;
        var _ = window.criteo_pubtag_prebid_144 || window.criteo_pubtag;
        this.clientRequestId = Re(), this.privacies = {}, n.gdprConsent && (this.privacies.gdprConsent = {}, void 0 !== n.gdprConsent.consentString && (this.privacies.gdprConsent.consentData = n.gdprConsent.consentString), void 0 !== n.gdprConsent.gdprApplies && (this.privacies.gdprConsent.gdprApplies = !!n.gdprConsent.gdprApplies), this.privacies.gdprConsent.version = n.gdprConsent.apiVersion), this.privacies.ccpaIabConsent = {
            uspString: n.uspConsent
        }, this.regs = new it(n.coppa, null === (a = null === (s = n.ortb2) || void 0 === s ? void 0 : s.regs) || void 0 === a ? void 0 : a.gpp, null === (d = null === (c = n.ortb2) || void 0 === c ? void 0 : c.regs) || void 0 === d ? void 0 : d.gpp_sid);
        var S = new Xe(void 0, this.privacies);
        this.timeout = We(n.timeout), this.metricsManager = new _e(S), this.metricBuilder = new de(this.metricsManager), this.timer = new Fe(this.metricBuilder, n.start, this.timeout);
        var E, I, T, P = new Ve;
        this.adBlockFlagManager = B.create(S), this.adBlockFlagManager.adBlockFlagEnabled() && (e = nt, _.context.isAdBlocked = !0), this.auctionId = n.auctionId, this.bidRequests = i, (window.Criteo_prebid_144 || window.Criteo).prebid_adapters = (window.Criteo_prebid_144 || window.Criteo).prebid_adapters || {}, ((window.Criteo_prebid_144 || window.Criteo).prebid_adapters[this.auctionId] = this).slots = [];
        for (var A = !0, x = 0, R = i; x < R.length; x++) {
            (M = R[x]).bidId && ((window.Criteo_prebid_144 || window.Criteo).prebid_adapters[M.bidId] = this);
            var D = void 0;
            M.fpd && M.fpd.context && (D = M.fpd.context), (null === (l = M.ortb2Imp) || void 0 === l ? void 0 : l.ext) && ((null == D ? void 0 : D.data) && M.ortb2Imp.ext.data && (D.data = L(L({}, D.data), M.ortb2Imp.ext.data)), D = L(L({}, M.ortb2Imp.ext), D)), M.params.ext && ((null == D ? void 0 : D.data) && M.params.ext.data && (D.data = L(L({}, D.data), M.params.ext.data)), D = L(L({}, M.params.ext), D)), (null === (u = M.nativeOrtbRequest) || void 0 === u ? void 0 : u.assets) && (D = L({
                assets: M.nativeOrtbRequest.assets
            }, D)), A = this.hasValidNativeParams(M);
            var k = ht.isPrebid3OrAbove(r);
            D = this.enrichSlotWithFloors(D, M), this.slots.push(new De(M.adUnitCode, M.params.zoneId, void 0 !== M.params.nativeCallback || void 0 !== (null === (p = null == M ? void 0 : M.mediaTypes) || void 0 === p ? void 0 : p.native), M.params.nativeCallback, M.transactionId, this.getSizes(M, k), M.params.publisherSubId, M.mediaTypes, ht.getVideoInfoFromBidRequest(M), D, null === (h = M.ortb2Imp) || void 0 === h ? void 0 : h.rwdd, M.bidId)), E = M.params.networkId || E, I = M.schain || I, N(n.ceh), M.params.integrationMode && (T = me(M.params.integrationMode))
        }
        A || $.Warning("All native assets containing URL should be sent as placeholders with sendId(icon, image, clickUrl, privacyLink, privacyIcon)");
        var O, M, U = new ye(!1);
        0 < i.length && (M = i[0]).userIdAsEids && 0 < M.userIdAsEids.length && (O = M.userIdAsEids);
        (null === (v = n.ortb2) || void 0 === v ? void 0 : v.user) && _.context.setUser(n.ortb2.user), (null === (f = n.ortb2) || void 0 === f ? void 0 : f.site) && _.context.setSite(n.ortb2.site), (null === (m = n.ortb2) || void 0 === m ? void 0 : m.device) && _.context.setDevice(n.ortb2.device);
        var F = {
            tid: null === (y = null === (g = n.ortb2) || void 0 === g ? void 0 : g.source) || void 0 === y ? void 0 : y.tid,
            ext: I ? {
                schain: I
            } : void 0
        };
        this.requestBuilder = new Pe(this.slots, _.context, U, e, T, E, t, {
            ccpaIabConsent: this.privacies.ccpaIabConsent,
            gdprConsent: this.privacies.gdprConsent
        }, r, P, this.timeout, this.clientRequestId, O, n.start, F, this.regs, null === (b = n.ortb2) || void 0 === b ? void 0 : b.bcat, null === (w = n.ortb2) || void 0 === w ? void 0 : w.badv, null === (C = n.ortb2) || void 0 === C ? void 0 : C.bapp, n.fledgeEnabled), this.url = this.requestBuilder.getUrl(), this.fledgeEnabled = !!n.fledgeEnabled
    }

    function vt(e) {
        try {
            return JSON.parse(e)
        } catch (e) {
            return
        }
    }
    var ft = 1,
        mt = (gt.prototype.getCMPFrame = function() {
            for (var e, t = this.currentWindow, i = 0; i < 10; ++i) {
                try {
                    t.frames.__uspapiLocator && (e = t)
                } catch (e) {}
                if (t === this.currentWindow.top) break;
                t = t.parent
            }
            return e
        }, gt.prototype.hasCallerFunctionInWindow = function() {
            return "function" == typeof this.currentWindow.__uspapi
        }, gt.prototype.readyToRetrieve = function() {
            return this.hasCallerFunctionInWindow() || void 0 !== this.getCMPFrame()
        }, gt.prototype.retrieveConsent = function(i) {
            var n = this,
                r = !1,
                o = window.setTimeout(function() {
                    r = !0, n.logger("Timeout: Unable to resolve CCPA consent after " + n.timeout + "ms"), i(void 0)
                }, this.timeout);
            this.executeCommand("getUSPData", ft, function(e, t) {
                r || (clearTimeout(o), t ? (n.logger("CCPA consent retrieved"), n.processResponseData(e, i)) : (n.logger("Error retrieving CCPA consent data from CMP"), i(void 0)))
            })
        }, gt.prototype.processResponseData = function(e, t) {
            e ? t(e) : (this.logger("Unable to read CCPA consent data from CMP"), t(void 0))
        }, gt.prototype.executeCommand = function(e, t, i) {
            var o = this;
            if (!this.hasCallerFunctionInWindow()) {
                this.logger("No CCPA CMP defined on current frame");
                var s = this.getCMPFrame();
                this.currentWindow.__uspapi = function(e, t, i) {
                    if (!s) return o.logger("CCPA CMP not found in any frame"), void i({
                        msg: "CCPA CMP not found in any frame"
                    }, !1);
                    var n = Math.random().toString(10),
                        r = {
                            __uspapiCall: {
                                command: e,
                                parameter: t,
                                callId: n
                            }
                        };
                    o.uspapiCallbacks[n] = i, s.postMessage(r, "*")
                }, this.currentWindow.addEventListener("message", function(e) {
                    var t = "string" == typeof e.data ? vt(e.data) : e.data;
                    if (t && t.__uspapiReturn && t.__uspapiReturn.callId && t.__uspapiReturn.returnValue) {
                        var i = t.__uspapiReturn;
                        o.uspapiCallbacks && o.uspapiCallbacks[i.callId] && (o.uspapiCallbacks[i.callId](i.returnValue, i.success), delete o.uspapiCallbacks[i.callId])
                    }
                }, !1)
            }
            this.currentWindow.__uspapi(e, t, i)
        }, gt.prototype.hasUserOptOut = function(e) {
            return !(!e || !e.uspString || "1YNY" === e.uspString.toUpperCase() || "1YNN" === e.uspString.toUpperCase() || "1YN-" === e.uspString.toUpperCase() || "1-N-" === e.uspString.toUpperCase() || "1---" === e.uspString)
        }, gt);

    function gt(e, t, i) {
        void 0 === i && (i = function(e) {}), this.uspapiCallbacks = {}, this.currentWindow = e, this.timeout = t.uspApiTimeout, this.logger = i
    }
    var yt = (bt.prototype.getReadyToRetrieveProvider = function() {
        return this.tcfv2ConsentProvider.hasCallerFunctionInFrame() ? this.tcfv2ConsentProvider : this.tcfv1ConsentProvider.hasCallerFunctionInFrame() ? this.tcfv1ConsentProvider : void 0 !== this.tcfv2ConsentProvider.getCMPFrame() ? this.tcfv2ConsentProvider : void 0 !== this.tcfv1ConsentProvider.getCMPFrame() ? this.tcfv1ConsentProvider : void 0
    }, bt.prototype.retrieveConsentForPassback = function(e) {
        var t = this.getReadyToRetrieveProvider();
        void 0 === t && (this.logger("No compatible GDPR privacy provider found"), e(void 0)), t === this.tcfv1ConsentProvider ? this.tcfv1ConsentProvider.retrieveConsentForPassback(e) : t === this.tcfv2ConsentProvider && this.tcfv2ConsentProvider.retrieveConsent(e)
    }, bt.prototype.retrieveConsent = function(e) {
        var t = this.getReadyToRetrieveProvider();
        void 0 === t && (this.logger("No compatible GDPR privacy provider found"), e(void 0)), null == t || t.retrieveConsent(e)
    }, bt.prototype.readyToRetrieve = function() {
        return this.tcfv2ConsentProvider.readyToRetrieve() || this.tcfv1ConsentProvider.readyToRetrieve()
    }, bt);

    function bt(e, t, i) {
        void 0 === i && (i = function(e) {}), this.tcfv1ConsentProvider = e, this.tcfv2ConsentProvider = t, this.logger = i
    }
    var wt = 91,
        Ct = (_t.prototype.getCMPFrame = function() {
            for (var e, t = this.currentWindow, i = 0; i < 10; ++i) {
                try {
                    t.frames.__cmpLocator && (e = t)
                } catch (e) {}
                if (t === this.currentWindow.top) break;
                t = t.parent
            }
            return e
        }, _t.prototype.hasCallerFunctionInFrame = function() {
            return "function" == typeof this.currentWindow.__cmp
        }, _t.prototype.readyToRetrieve = function() {
            return this.hasCallerFunctionInFrame() || void 0 !== this.getCMPFrame()
        }, _t.prototype.pingWithTimeout = function(n, e, t, i) {
            function r(e, t) {
                o.logger(t), clearTimeout(e), i()
            }
            var o = this;
            return window.setTimeout(function() {
                var i = window.setTimeout(function() {
                    r(n, "Timeout: Unable to get ping return after " + e + "ms")
                }, e);
                o.executeCommand("ping", null, function(e, t) {
                    clearTimeout(i), t ? (o.logger("GDPR CMP ping returned"), !0 !== e.cmpLoaded && r(n, "GDPR ping returned cmpLoaded which is not true"), o.logger("GDPR ping returned cmpLoaded which is true")) : r(n, "Error sending ping to GDPR CMP")
                })
            }, t)
        }, _t.prototype.retrieveConsent = function(e) {
            this.executeRetrieveConsent("getConsentData", null, e)
        }, _t.prototype.retrieveConsentForPassback = function(e) {
            this.executeRetrieveConsent("getVendorConsents", [wt], e)
        }, _t.prototype.executeRetrieveConsent = function(e, t, i) {
            var n = this,
                r = !1,
                o = window.setTimeout(function() {
                    r = !0, n.logger("Timeout: Unable to resolve GDPR consent after " + n.timeout + "ms"), i(void 0)
                }, this.timeout),
                s = !1 !== this.cmpAutoDetect ? this.pingWithTimeout(o, this.pingTimeout, this.pingDelay, function() {
                    r = !0, n.logger("Timeout: Unable to ping GDPR API after " + n.pingTimeout + "ms"), i(void 0)
                }) : void 0;
            this.executeCommand(e, t, function(e, t) {
                clearTimeout(s), r || (clearTimeout(o), t ? (n.logger("GDPR consent retrieved"), n.processConsentData(e, i)) : (n.logger("Error retrieving GDPR consent data from CMP"), i(void 0)))
            })
        }, _t.prototype.processConsentData = function(e, t) {
            if (e) {
                var i = {};
                void 0 !== e.consentData && (i.consentData = e.consentData), void 0 !== e.gdprApplies && (i.gdprApplies = !!e.gdprApplies), t(i)
            } else this.logger("Unable to read GDPR consent data from CMP"), t(void 0)
        }, _t.prototype.executeCommand = function(e, t, i) {
            var o = this;
            if (!this.hasCallerFunctionInFrame()) {
                this.logger("No GDPR CMP defined on current frame");
                var s = this.getCMPFrame();
                this.currentWindow.__cmp = function(e, t, i) {
                    if (!s) return o.logger("GDPR CMP not found in any frame"), void i({
                        msg: "GDPR CMP not found in any frame"
                    }, !1);
                    var n = Math.random().toString(10),
                        r = {
                            __cmpCall: {
                                command: e,
                                parameter: t,
                                callId: n
                            }
                        };
                    o.cmpCallbacks[n] = i, s.postMessage(r, "*")
                }, this.currentWindow.addEventListener("message", function(e) {
                    var t = "string" == typeof e.data ? vt(e.data) : e.data;
                    if (t && t.__cmpReturn && t.__cmpReturn.callId && t.__cmpReturn.returnValue) {
                        var i = t.__cmpReturn;
                        o.cmpCallbacks && o.cmpCallbacks[i.callId] && (o.cmpCallbacks[i.callId](i.returnValue, i.success), delete o.cmpCallbacks[i.callId])
                    }
                }, !1)
            }
            this.currentWindow.__cmp(e, t, i)
        }, _t);

    function _t(e, t, i) {
        void 0 === i && (i = function(e) {}), this.cmpCallbacks = {}, this.currentWindow = e, this.timeout = t.tcfTimeout, this.pingTimeout = t.tcfPingTimeout, this.pingDelay = t.tcfPingDelay, this.cmpAutoDetect = t.cmpAutoDetect, this.logger = i
    }
    var St = 2,
        Et, It;
    It = Et = Et || {}, It.LOADED = "tcloaded", It.UI_SHOWN = "cmpuishown", It.USER_ACTION_COMPLETE = "useractioncomplete";
    var Tt = (Pt.prototype.getCMPFrame = function() {
        for (var e, t = this.currentWindow, i = 0; i < 10; ++i) {
            try {
                t.frames.__tcfapiLocator && (e = t)
            } catch (e) {}
            if (t === this.currentWindow.top) break;
            t = t.parent
        }
        return e
    }, Pt.prototype.hasCallerFunctionInFrame = function() {
        return "function" == typeof this.currentWindow.__tcfapi
    }, Pt.prototype.readyToRetrieve = function() {
        return this.hasCallerFunctionInFrame() || void 0 !== this.getCMPFrame()
    }, Pt.prototype.pingWithTimeout = function(i, e, t, n) {
        function r(e, t) {
            o.logger(t), clearTimeout(e), n()
        }
        var o = this;
        return window.setTimeout(function() {
            var t = window.setTimeout(function() {
                r(i, "Timeout: Unable to get TCFv2 ping return after " + e + "ms")
            }, e);
            o.executeCommand("ping", St, function(e) {
                clearTimeout(t), o.logger("TCFv2 CMP ping returned in ms"), "error" === e.cmpStatus ? r(i, "Error status on ping to TCFv2 CMP") : !0 !== e.cmpLoaded ? r(i, "TCFv2 ping returned cmpLoaded = false") : o.logger("TCFv2 ping returned cmpLoaded = true")
            })
        }, t)
    }, Pt.prototype.retrieveConsent = function(i) {
        var n, r, o = this,
            s = !1,
            a = window.setTimeout(function() {
                s = !0, r === Et.UI_SHOWN ? (o.logger("Timeout: User hasn't confirm their consent settings after " + o.timeout + "ms"), i(n)) : (o.logger("Timeout: Unable to resolve TCFv2 consent after " + o.timeout + "ms"), i(void 0))
            }, this.timeout),
            c = !1 !== this.cmpAutoDetect ? this.pingWithTimeout(a, this.pingTimeout, this.pingDelay, function() {
                s = !0, o.logger("Timeout: Unable to ping TCFv2 API after " + o.pingTimeout + "ms"), i(void 0)
            }) : void 0;
        this.executeCommand("addEventListener", St, function(e, t) {
            clearTimeout(c), s || ((r = e.eventStatus) !== Et.UI_SHOWN && clearTimeout(a), t ? (o.logger("TCFv2 consent retrieved in ms"), e || (o.logger("Unable to read GDPR consent data from CMP"), i(void 0)), n = o.processResponseData(e), r !== Et.LOADED && r !== Et.USER_ACTION_COMPLETE || i(n)) : (o.logger("Error retrieving TCFv2 consent data from CMP"), i(void 0)))
        })
    }, Pt.prototype.processResponseData = function(e) {
        var t, i, n = {};
        return void 0 !== e.tcString && (n.consentData = e.tcString), void 0 !== e.gdprApplies && (n.gdprApplies = !!e.gdprApplies), n.version = e.tcfPolicyVersion ? e.tcfPolicyVersion : St, n.purposes = null === (t = null == e ? void 0 : e.purpose) || void 0 === t ? void 0 : t.consents, n.vendorConsents = null === (i = null == e ? void 0 : e.vendor) || void 0 === i ? void 0 : i.consents, n
    }, Pt.prototype.executeCommand = function(e, t, i, n) {
        var s = this;
        if (!this.hasCallerFunctionInFrame()) {
            this.logger("No TCFv2 CMP defined on current frame");
            var a = this.getCMPFrame();
            this.currentWindow.__tcfapi = function(e, t, i, n) {
                if (!a) return s.logger("TCFv2 CMP not found in any frame"), void i({
                    msg: "TCFv2 CMP not found in any frame"
                }, !1);
                var r = Math.random().toString(10),
                    o = {
                        __tcfapiCall: {
                            command: e,
                            version: t,
                            parameter: n,
                            callId: r
                        }
                    };
                s.cmpCallbacks[r] = i, a.postMessage(o, "*")
            }, this.currentWindow.addEventListener("message", function(e) {
                var t = "string" == typeof e.data ? vt(e.data) : e.data;
                if (t && t.__tcfapiReturn && t.__tcfapiReturn.callId && t.__tcfapiReturn.returnValue) {
                    var i = t.__tcfapiReturn;
                    s.cmpCallbacks && s.cmpCallbacks[i.callId] && "function" == typeof s.cmpCallbacks[i.callId] && (s.cmpCallbacks[i.callId](i.returnValue, i.success), i.returnValue.eventStatus !== Et.UI_SHOWN && delete s.cmpCallbacks[i.callId])
                }
            }, !1)
        }
        this.currentWindow.__tcfapi(e, t, i, n)
    }, Pt);

    function Pt(e, t, i) {
        void 0 === i && (i = function(e) {}), this.cmpCallbacks = {}, this.currentWindow = e, this.timeout = t.tcfTimeout, this.pingTimeout = t.tcfPingTimeout, this.pingDelay = t.tcfPingDelay, this.cmpAutoDetect = t.cmpAutoDetect, this.logger = i
    }
    var At = "1.0",
        xt = "1.1",
        Rt = (Dt.prototype.getCMPFrame = function() {
            for (var e, t = this.currentWindow, i = 0; i < 10; ++i) {
                try {
                    void 0 !== t && t.frames.__gppLocator && (e = t)
                } catch (e) {}
                if (t === this.currentWindow.top) break;
                t = t.parent
            }
            return e
        }, Dt.prototype.hasCallerFunctionInFrame = function() {
            return "function" == typeof this.currentWindow.__gpp
        }, Dt.prototype.readyToRetrieve = function() {
            return this.hasCallerFunctionInFrame() || void 0 !== this.getCMPFrame()
        }, Dt.prototype.retrieveConsent = function(i) {
            function n(e, t) {
                r.logger(t), clearTimeout(e), o = !0, r.logger("Timeout: Unable to ping GPP after " + r.pingTimeout + "ms"), i(void 0)
            }
            var r = this,
                o = !1,
                s = window.setTimeout(function() {
                    o = !0, r.logger("Timeout: Unable to resolve GPP consent after " + r.timeout + "ms"), i(void 0)
                }, this.timeout);
            window.setTimeout(function() {
                var t = window.setTimeout(function() {
                    n(s, "Timeout: Unable to get GPP ping return after " + r.pingTimeout + "ms")
                }, r.pingTimeout);
                r.executeCommand("ping", function(e) {
                    clearTimeout(t), r.logger("GPP CMP ping has responsed"), e.gppVersion === At ? (r.logger("Detected GPP CMP 1.0"), "error" === e.cmpStatus ? n(s, "Error status on ping to GPP CMP") : "loaded" === e.cmpStatus ? (r.logger("GPP ping returned cmpStatus = loaded"), r.executeCommand("getGPPData", function(e, t) {
                        o || (clearTimeout(s), t ? (r.logger("GPP consent retrieved"), r.processResponseData(e, i)) : (r.logger("Error retrieving GPP consent data from CMP"), i(void 0)))
                    })) : n(s, "GPP ping returned cmpStatus != loaded")) : e.gppVersion === xt ? (r.logger("Detected GPP CMP 1.1"), "ready" === e.signalStatus ? (clearTimeout(s), r.logger("GPP consent retrieved"), r.processResponseData(e, i)) : r.executeCommand("addEventListener", function(e, t) {
                        o || "signalStatus" === e.eventName && "ready" === e.pingData.signalStatus && (clearTimeout(s), r.logger("GPP consent retrieved"), r.processResponseData(e.pingData, i))
                    })) : n(s, "Unknown GPP version " + e.gppVersion)
                })
            }, this.pingDelay)
        }, Dt.prototype.processResponseData = function(e, t) {
            if (e) {
                var i = {};
                void 0 !== e.gppString && (i.gpp = e.gppString), void 0 !== e.applicableSections && (i.gppSid = e.applicableSections), t(i)
            } else this.logger("Unable to read GPP consent data from CMP"), t(void 0)
        }, Dt.prototype.executeCommand = function(e, t, i) {
            var o = this;
            if (!this.hasCallerFunctionInFrame()) {
                this.logger("No GPP CMP defined on current frame");
                var s = this.getCMPFrame();
                this.currentWindow.__gpp = function(e, t, i) {
                    if (!s) return o.logger("GPP CMP not found in any frame"), void t({
                        msg: "GPP CMP not found in any frame"
                    }, !1);
                    var n = Math.random().toString(10),
                        r = {
                            __gppCall: {
                                command: e,
                                parameter: i,
                                callId: n
                            }
                        };
                    o.cmpCallbacks[n] = t, s.postMessage(r, "*")
                }, this.currentWindow.addEventListener("message", function(e) {
                    var t = "string" == typeof e.data ? vt(e.data) : e.data;
                    if (t && t.__gppReturn && t.__gppReturn.callId && t.__gppReturn.returnValue) {
                        var i = t.__gppReturn;
                        o.cmpCallbacks && o.cmpCallbacks[i.callId] && "function" == typeof o.cmpCallbacks[i.callId] && (o.cmpCallbacks[i.callId](i.returnValue, i.success), delete o.cmpCallbacks[i.callId])
                    }
                }, !1)
            }
            this.currentWindow.__gpp(e, t, i)
        }, Dt);

    function Dt(e, t, i) {
        void 0 === i && (i = function(e) {}), this.cmpCallbacks = {}, this.currentWindow = e, this.timeout = t.gppTimeout, this.pingTimeout = t.gppPingTimeout, this.pingDelay = t.gppPingDelay, this.logger = i
    }

    function kt(e) {
        return {
            uspApiTimeout: parseInt("50", 10),
            tcfTimeout: parseInt("10000", 10),
            tcfPingTimeout: Math.min(parseInt("10000", 10), parseInt("50", 10)),
            tcfPingDelay: Math.min(parseInt("10000", 10), parseInt("1000", 10)),
            gppTimeout: parseInt("10000", 10),
            gppPingTimeout: Math.min(parseInt("10000", 10), parseInt("50", 10)),
            gppPingDelay: Math.min(parseInt("10000", 10), parseInt("1000", 10)),
            cmpAutoDetect: null == e ? void 0 : e.cmpAutoDetect
        }
    }
    var Ot = (Mt.prototype.checkTcfPurposeOne = function(e) {
        return !(e && (null == e ? void 0 : e.gdprConsent) && e.gdprConsent.purposes) || !0 === e.gdprConsent.purposes[1]
    }, Mt.prototype.setCookie = function(e, t, i, n, r) {
        void 0 === r && (r = !1);
        var o = n || document,
            s = o.location.hostname,
            a = new Date;
        a.setTime(a.getTime() + 60 * i * 60 * 1e3);
        var c = "expires=" + a.toUTCString();
        if (!r) return this.setCookieString(e, t, c, void 0, o), s;
        for (var d = s.split("."), l = 1; l < d.length; ++l) {
            var u = d.slice(d.length - l - 1, d.length).join(".");
            if (!(-1 < this.publicTopTlds.indexOf(u))) try {
                this.setCookieString(e, t, c, u, o);
                var p = this.getCookie(e, n);
                if (p && p === t) return u
            } catch (e) {}
        }
        return s
    }, Mt.prototype.deleteCookie = function(e, t, i) {
        void 0 === i && (i = !1), this.setCookie(e, "", 0, t, i)
    }, Mt.prototype.getCookie = function(e, t) {
        if (this.cookiesEnabled)
            for (var i = 0, n = (t || document).cookie.split(";"); i < n.length; i++) {
                var r = n[i],
                    o = r.substr(0, r.indexOf("=")).replace(/^\s+|\s+$/g, ""),
                    s = r.substr(r.indexOf("=") + 1);
                if (o === e) return decodeURIComponent(s)
            }
    }, Mt.prototype.setCookieString = function(e, t, i, n, r) {
        if (this.cookiesEnabled) {
            var o = e + "=" + encodeURIComponent(t) + ";" + i + ";";
            n && "" !== n && (o += "domain=." + n + ";"), r.cookie = o + "path=/"
        }
    }, Mt);

    function Mt(e) {
        this.publicTopTlds = ["co.id", "co.il", "co.jp", "co.kr", "co.nz", "co.th", "co.uk", "com.au", "com.br", "com.mx", "com.my", "com.pl", "com.sg", "com.tr", "com.vn"], this.cookiesEnabled = this.checkTcfPurposeOne(e)
    }
    var Ut = (Ft.prototype.initializeServices = function() {
        var i = this;
        this.initializing = !0, this.retrievePrivacyConsent(function(e) {
            var t = {
                localStorageHelper: new Xe(i.topFrame, e),
                privacies: e,
                ccpaConsentProvider: i.ccpaConsentProvider,
                gppConsentProvider: i.gppConsentProvider,
                cookieHelper: new Ot(e)
            };
            i.services = t, i.initialized = !0, i.initializing = !1, i.postInitiliazeServicesCallbacks.forEach(function(e) {
                e(t)
            })
        })
    }, Ft.prototype.getServicesAsync = function(e) {
        this.initialized ? e(this.services) : (this.postInitiliazeServicesCallbacks.push(e), this.initializing || this.initializeServices())
    }, Ft.prototype.retrievePrivacyConsent = function(t) {
        var e = this.tcfCompatibleConsentProvider.readyToRetrieve(),
            i = this.ccpaConsentProvider.readyToRetrieve(),
            n = this.gppConsentProvider.readyToRetrieve();
        e || i || n || t(void 0);
        var r = [];
        e && r.push(yt), i && r.push(mt), n && r.push(Rt);
        var o = {};
        e && this.tcfCompatibleConsentProvider.retrieveConsent(function(e) {
            o.gdprConsent = e, r.splice(r.indexOf(yt), 1), 0 === r.length && t(o)
        }), i && this.ccpaConsentProvider.retrieveConsent(function(e) {
            o.ccpaIabConsent = e, r.splice(r.indexOf(mt), 1), 0 === r.length && t(o)
        }), n && this.gppConsentProvider.retrieveConsent(function(e) {
            o.gppConsent = e, r.splice(r.indexOf(Rt), 1), 0 === r.length && t(o)
        })
    }, Ft);

    function Ft(e, t, i, n, r) {
        this.initializing = !1, this.initialized = !1, this.postInitiliazeServicesCallbacks = [], this.topFrame = e || window;
        var o = kt(r);
        this.ccpaConsentProvider = t || new mt(window, o, $.Warning);
        var s = new Ct(window, o, $.Warning),
            a = new Tt(window, o, $.Warning);
        this.tcfCompatibleConsentProvider = i || new yt(s, a, $.Warning), this.gppConsentProvider = n || new Rt(window, o, $.Warning), this.initializeServices()
    }
    var Lt = (Bt = k, t(Nt, Bt), Nt.prototype.getMetricBuilder = function() {
            return this.metricBuilder
        }, Nt.prototype.eval = function(e) {
            this.evalWithTimeout(e, void 0)
        }, Nt.prototype.evalWithTimeout = function(t, i) {
            var n = this;
            (this.serviceProvider || new Ut).getServicesAsync(function(e) {
                n.metricsManager || (n.metricsManager = new _e(e.localStorageHelper)), n.metricBuilder || (n.metricBuilder = new de(n.metricsManager)), n.innerEval(t, n.metricBuilder, e.privacies, i)
            })
        }, Nt.prototype.innerEval = function(n, r, o, e) {
            var s = this,
                a = Re(),
                t = Nt.getCriteoAdapterBidRequest(),
                i = Nt.getRequestAuctionStart(t),
                c = e || We(t && t.timeout),
                d = new Fe(r, i, c),
                l = new Pe(this.slots, n.context, this.urlBuilder, this.profileId, this.integrationMode, this.networkId, this.adapterVersion, o, void 0, this.viewportComputer, c, a, n.context.userIds, Math.round(new Date / 1e3));
            if (!l.isValid() || "undefined" == typeof JSON) return $.Debug("Request ignored because it doesnt contain any slot"), void this.callbackError(void 0, void 0);
            var u = l.getRequest(),
                p = JSON.stringify(u),
                h = l.getUrl(),
                v = new Ye(h, p, "application/x-www-form-urlencoded");
            d.sendRequest(h), v.send(function(e) {
                try {
                    d.requestReceived();
                    var t = ue(e) || {},
                        i = xe(t);
                    void 0 !== s.callbackSuccess && s.callbackSuccess(JSON.stringify(t), i), d.finish(), !0 === t.user_sync && et.execUserSync(n.context.remoteLogging, o, t), r.getMetricsManager().sendEvents(r, a, !0)
                } catch (e) {
                    s.reportAsyncRequestException(n, "onSuccess", e)
                }
                n.context.remoteLogging.sendErrorReport(s.urlBuilder, a), s.metricBuilder = void 0
            }, function(e, t) {
                try {
                    d.requestReceived(), void 0 !== s.callbackError && s.callbackError(e, t), d.finish(), r.getMetricsManager().sendEvents(r, a, !0)
                } catch (e) {
                    s.reportAsyncRequestException(n, "onError", e)
                }
                n.context.remoteLogging.sendErrorReport(s.urlBuilder, a), s.metricBuilder = void 0
            }, function() {
                try {
                    d.requestReceived(!0), void 0 !== s.callbackTimeout && s.callbackTimeout(), d.finish(), r.getMetricsManager().sendEvents(r, a, !0)
                } catch (e) {
                    s.reportAsyncRequestException(n, "onTimeout", e)
                }
                n.context.remoteLogging.sendErrorReport(s.urlBuilder, a), s.metricBuilder = void 0
            }, this.timeout)
        }, Nt.prototype.reportAsyncRequestException = function(e, t, i) {
            var n = i.stack ? i.stack : i.toString();
            e.context.remoteLogging.log("Exception", "Exception caught in AsyncRequest " + t + " callback:\n" + n), $.Error("Error " + t + ":\n\t" + n)
        }, Nt.getCriteoAdapterBidRequest = function() {
            try {
                return window.pbjs._bidsRequested.find(function(e) {
                    return "criteo" === e.bidderCode
                })
            } catch (e) {
                return
            }
        }, Nt.getRequestAuctionStart = function(e) {
            return e && e.auctionStart
        }, Nt.NAME = "directbidding", Nt),
        Bt;

    function Nt(e, t, i, n, r, o, s, a, c, d, l, u, p) {
        var h = Bt.call(this, Nt.NAME) || this;
        return h.profileId = e, h.urlBuilder = t, h.slots = i, h.callbackSuccess = n, h.callbackError = r, h.callbackTimeout = o, h.serviceProvider = s, h.timeout = c, h.networkId = d, h.integrationMode = l, h.adapterVersion = u, h.viewportComputer = p, h.metricsManager = a, h.metricsManager && (h.metricBuilder = new de(h.metricsManager)), h
    }
    var Wt = (Ht = k, t(qt, Ht), qt.prototype.eval = function(e) {
            var t = this;
            setTimeout(function() {
                return t.onTimeout()
            }, this.timeout), this.directBiddingEvent.evalWithTimeout(e, this.timeout)
        }, qt.prototype.onSuccess = function(e, t) {
            this.hasResponded = !0, this.hasTimeouted || this.callbackSuccess(e, t)
        }, qt.prototype.onError = function(e, t) {
            this.hasResponded = !0, this.hasTimeouted || this.callbackError(e, t)
        }, qt.prototype.onHttpTimeout = function() {
            this.hasResponded = !0, this.hasTimeouted || this.callbackTimeout()
        }, qt.prototype.onTimeout = function() {
            this.hasResponded || (this.hasTimeouted = !0, this.callbackTimeout())
        }, qt.prototype.getMetricBuilder = function() {
            return this.directBiddingEvent.getMetricBuilder()
        }, qt.NAME = "directbidding", qt),
        Ht;

    function qt(e, t, i, n, r, o, s, a, c, d, l, u, p) {
        var h = Ht.call(this, qt.NAME) || this,
            v = Math.max(10 * (c || 3e3), 3e3);
        return h.directBiddingEvent = new Lt(e, t, i, function(e, t) {
            return h.onSuccess(e, t)
        }, function(e, t) {
            return h.onError(e, t)
        }, function() {
            return h.onHttpTimeout()
        }, a, s, v, d, l, u, p), h.slots = i, h.callbackSuccess = n, h.callbackError = r, h.callbackTimeout = o, h.timeout = 0 === c ? 0 : c || 3e3, h.hasTimeouted = !1, h.hasResponded = !1, h
    }

    function Gt(t) {
        var i = "criteo_fast_bid";
        null === t.getItem(i, 864e5) && new Ye("https://static.criteo.net/js/ld/publishertag.prebid.144.js", void 0, void 0, !1).send(function(e) {
            t.setItem(i, e, 864e5)
        }, function(e, t) {
            $.Error("Could not update FastBid" + (t ? " (" + t + ")" : ""))
        })
    }

    function zt(e) {
        function t() {
            try {
                return i.apply(this, arguments)
            } catch (e) {
                $.Error("Exception caught: " + e.toString())
            }
        }
        var i = e;
        for (var n in t.prototype = i.prototype, i) i.hasOwnProperty(n) && (t[n] = i[n]);
        return t
    }

    function Vt(e) {
        for (var t in e)
            if (t in e) {
                var i = e[t];
                "function" == typeof i ? e[t] = zt(i) : "object" == typeof i && (e[t] = Vt(i))
            }
        return e
    }

    function jt(e) {
        var t = {
            push: function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                if (void 0 !== e)
                    for (var i = 0, n = e; i < n.length; i++) {
                        var r = n[i];
                        "function" == typeof r && zt(r)()
                    }
            }
        };
        return e && Array.isArray(e) && t.push.apply(t, e), t
    }
    var Kt = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

    function Xt() {
        throw new Error("Dynamic requires are not currently supported by rollup-plugin-commonjs")
    }

    function Jt(e) {
        return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
    }

    function Yt(e, t) {
        return e(t = {
            exports: {}
        }, t.exports), t.exports
    }

    function Qt(e) {
        return e && e.default || e
    }
    var $t = Yt(function(e, t) {
            var i;
            i = function() {
                function c(e) {
                    return "function" == typeof e
                }
                var i = Array.isArray ? Array.isArray : function(e) {
                        return "[object Array]" === Object.prototype.toString.call(e)
                    },
                    n = 0,
                    t = void 0,
                    r = void 0,
                    s = function(e, t) {
                        p[n] = e, p[n + 1] = t, 2 === (n += 2) && (r ? r(h) : y())
                    };
                var e = "undefined" != typeof window ? window : void 0,
                    o = e || {},
                    a = o.MutationObserver || o.WebKitMutationObserver,
                    d = "undefined" == typeof self && "undefined" != typeof process && "[object process]" === {}.toString.call(process),
                    l = "undefined" != typeof Uint8ClampedArray && "undefined" != typeof importScripts && "undefined" != typeof MessageChannel;

                function u() {
                    var e = setTimeout;
                    return function() {
                        return e(h, 1)
                    }
                }
                var p = new Array(1e3);

                function h() {
                    for (var e = 0; e < n; e += 2) {
                        (0, p[e])(p[e + 1]), p[e] = void 0, p[e + 1] = void 0
                    }
                    n = 0
                }
                var v, f, m, g, y = void 0;

                function b(e, t) {
                    var i = this,
                        n = new this.constructor(_);
                    void 0 === n[C] && F(n);
                    var r = i._state;
                    if (r) {
                        var o = arguments[r - 1];
                        s(function() {
                            return M(r, n, o, i._result)
                        })
                    } else k(i, n, e, t);
                    return n
                }

                function w(e) {
                    if (e && "object" == typeof e && e.constructor === this) return e;
                    var t = new this(_);
                    return A(t, e), t
                }
                y = d ? function() {
                    return process.nextTick(h)
                } : a ? (f = 0, m = new a(h), g = document.createTextNode(""), m.observe(g, {
                    characterData: !0
                }), function() {
                    g.data = f = ++f % 2
                }) : l ? ((v = new MessageChannel).port1.onmessage = h, function() {
                    return v.port2.postMessage(0)
                }) : (void 0 === e && "function" == typeof Xt ? function() {
                    try {
                        var e = Function("return this")().require("vertx");
                        return void 0 !== (t = e.runOnLoop || e.runOnContext) ? function() {
                            t(h)
                        } : u()
                    } catch (e) {
                        return u()
                    }
                } : u)();
                var C = Math.random().toString(36).substring(2);

                function _() {}
                var S = void 0,
                    E = 1,
                    I = 2;

                function T(e, n, r) {
                    s(function(t) {
                        var i = !1,
                            e = function(e, t, i, n) {
                                try {
                                    e.call(t, i, n)
                                } catch (e) {
                                    return e
                                }
                            }(r, n, function(e) {
                                i || (i = !0, (n !== e ? A : R)(t, e))
                            }, function(e) {
                                i || (i = !0, D(t, e))
                            }, t._label);
                        !i && e && (i = !0, D(t, e))
                    }, e)
                }

                function P(e, t, i) {
                    var n, r;
                    t.constructor === e.constructor && i === b && t.constructor.resolve === w ? (n = e, (r = t)._state === E ? R(n, r._result) : r._state === I ? D(n, r._result) : k(r, void 0, function(e) {
                        return A(n, e)
                    }, function(e) {
                        return D(n, e)
                    })) : void 0 === i ? R(e, t) : c(i) ? T(e, t, i) : R(e, t)
                }

                function A(t, e) {
                    if (t === e) D(t, new TypeError("You cannot resolve a promise with itself"));
                    else if (r = typeof(n = e), null === n || "object" != r && "function" != r) R(t, e);
                    else {
                        var i = void 0;
                        try {
                            i = e.then
                        } catch (e) {
                            return void D(t, e)
                        }
                        P(t, e, i)
                    }
                    var n, r
                }

                function x(e) {
                    e._onerror && e._onerror(e._result), O(e)
                }

                function R(e, t) {
                    e._state === S && (e._result = t, e._state = E, 0 !== e._subscribers.length && s(O, e))
                }

                function D(e, t) {
                    e._state === S && (e._state = I, e._result = t, s(x, e))
                }

                function k(e, t, i, n) {
                    var r = e._subscribers,
                        o = r.length;
                    e._onerror = null, r[o] = t, r[o + E] = i, r[o + I] = n, 0 === o && e._state && s(O, e)
                }

                function O(e) {
                    var t = e._subscribers,
                        i = e._state;
                    if (0 !== t.length) {
                        for (var n = void 0, r = void 0, o = e._result, s = 0; s < t.length; s += 3) n = t[s], r = t[s + i], n ? M(i, n, r, o) : r(o);
                        e._subscribers.length = 0
                    }
                }

                function M(e, t, i, n) {
                    var r = c(i),
                        o = void 0,
                        s = void 0,
                        a = !0;
                    if (r) {
                        try {
                            o = i(n)
                        } catch (e) {
                            a = !1, s = e
                        }
                        if (t === o) return void D(t, new TypeError("A promises callback cannot return that same promise."))
                    } else o = n;
                    t._state !== S || (r && a ? A(t, o) : !1 === a ? D(t, s) : e === E ? R(t, o) : e === I && D(t, o))
                }
                var U = 0;

                function F(e) {
                    e[C] = U++, e._state = void 0, e._result = void 0, e._subscribers = []
                }
                var L = (B.prototype._enumerate = function(e) {
                    for (var t = 0; this._state === S && t < e.length; t++) this._eachEntry(e[t], t)
                }, B.prototype._eachEntry = function(t, e) {
                    var i = this._instanceConstructor,
                        n = i.resolve;
                    if (n === w) {
                        var r = void 0,
                            o = void 0,
                            s = !1;
                        try {
                            r = t.then
                        } catch (e) {
                            s = !0, o = e
                        }
                        if (r === b && t._state !== S) this._settledAt(t._state, e, t._result);
                        else if ("function" != typeof r) this._remaining--, this._result[e] = t;
                        else if (i === N) {
                            var a = new i(_);
                            s ? D(a, o) : P(a, t, r), this._willSettleAt(a, e)
                        } else this._willSettleAt(new i(function(e) {
                            return e(t)
                        }), e)
                    } else this._willSettleAt(n(t), e)
                }, B.prototype._settledAt = function(e, t, i) {
                    var n = this.promise;
                    n._state === S && (this._remaining--, e === I ? D(n, i) : this._result[t] = i), 0 === this._remaining && R(n, this._result)
                }, B.prototype._willSettleAt = function(e, t) {
                    var i = this;
                    k(e, void 0, function(e) {
                        return i._settledAt(E, t, e)
                    }, function(e) {
                        return i._settledAt(I, t, e)
                    })
                }, B);

                function B(e, t) {
                    this._instanceConstructor = e, this.promise = new e(_), this.promise[C] || F(this.promise), i(t) ? (this.length = t.length, this._remaining = t.length, this._result = new Array(this.length), 0 === this.length ? R(this.promise, this._result) : (this.length = this.length || 0, this._enumerate(t), 0 === this._remaining && R(this.promise, this._result))) : D(this.promise, new Error("Array Methods must be provided an Array"))
                }
                var N = (W.prototype.catch = function(e) {
                    return this.then(null, e)
                }, W.prototype.finally = function(t) {
                    var i = this.constructor;
                    return c(t) ? this.then(function(e) {
                        return i.resolve(t()).then(function() {
                            return e
                        })
                    }, function(e) {
                        return i.resolve(t()).then(function() {
                            throw e
                        })
                    }) : this.then(t, t)
                }, W);

                function W(e) {
                    this[C] = U++, this._result = this._state = void 0, this._subscribers = [], _ !== e && ("function" != typeof e && function() {
                        throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")
                    }(), this instanceof W ? function(t, e) {
                        try {
                            e(function(e) {
                                A(t, e)
                            }, function(e) {
                                D(t, e)
                            })
                        } catch (e) {
                            D(t, e)
                        }
                    }(this, e) : function() {
                        throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")
                    }())
                }
                return N.prototype.then = b, N.all = function(e) {
                    return new L(this, e).promise
                }, N.race = function(r) {
                    var o = this;
                    return i(r) ? new o(function(e, t) {
                        for (var i = r.length, n = 0; n < i; n++) o.resolve(r[n]).then(e, t)
                    }) : new o(function(e, t) {
                        return t(new TypeError("You must pass an array to race."))
                    })
                }, N.resolve = w, N.reject = function(e) {
                    var t = new this(_);
                    return D(t, e), t
                }, N._setScheduler = function(e) {
                    r = e
                }, N._setAsap = function(e) {
                    s = e
                }, N._asap = s, N.polyfill = function() {
                    var e = void 0;
                    if (void 0 !== Kt) e = Kt;
                    else if ("undefined" != typeof self) e = self;
                    else try {
                        e = Function("return this")()
                    } catch (e) {
                        throw new Error("polyfill failed because global object is unavailable in this environment")
                    }
                    var t = e.Promise;
                    if (t) {
                        var i = null;
                        try {
                            i = Object.prototype.toString.call(t.resolve())
                        } catch (e) {}
                        if ("[object Promise]" === i && !t.cast) return
                    }
                    e.Promise = N
                }, N.Promise = N
            }, e.exports = i()
        }),
        Zt = $t.polyfill,
        ei = (ti.LoadPolyfills = function() {
            ti.DefineIsArray(), ti.DefineIndexOf(), ti.DefineFilter(), ti.DefinePromise()
        }, ti.DefinePromise = function() {
            window.Promise || Zt()
        }, ti.DefineIsArray = function() {
            Array.isArray || (Array.isArray = function(e) {
                return "[object Array]" === Object.prototype.toString.call(e)
            })
        }, ti.DefineIndexOf = function() {
            Array.prototype.indexOf || (Array.prototype.indexOf = function(e, t) {
                if (void 0 === t && (t = 0), void 0 === this) throw new TypeError("'this' is null or not defined");
                var i = this.length;
                if (0 === i) return -1;
                if (i <= t) return -1;
                for (var n = Math.max(0 <= t ? t : i - Math.abs(t), 0); n < i;) {
                    if (n in this && this[n] === e) return n;
                    n++
                }
                return -1
            })
        }, ti.DefineFilter = function() {
            Array.prototype.filter || (Array.prototype.filter = function(e) {
                if (void 0 === this || void 0 === this) throw new TypeError;
                var t = this.length;
                if ("function" != typeof e) throw new TypeError;
                for (var i = [], n = 2 <= arguments.length ? arguments[1] : void 0, r = 0; r < t; r++)
                    if (r in this) {
                        var o = this[r];
                        e.call(n, o, r, this) && i.push(o)
                    }
                return i
            })
        }, ti);

    function ti() {}
    var ii = function(e, t) {
            this.errorType = e, this.messages = t
        },
        ni = function(e, t, i) {
            this.environment = e, this.errors = t, this.requestId = i
        },
        ri = (oi.prototype.withMessage = function(e, t) {
            return e in this.messages || (this.messages[e] = new Array), this.messages[e].push(t), this
        }, oi.prototype.withRequestId = function(e) {
            return this.requestId = e, this
        }, oi.prototype.build = function() {
            var e = Array();
            for (var t in this.messages) null != t && e.push(new ii(t, this.messages[t]));
            return new ni(this.environment, e, this.requestId)
        }, oi);

    function oi(e) {
        this.messages = {}, this.environment = e
    }
    var si = (di.prototype.reportPending = function() {
            return this.shouldSend
        }, di.prototype.sendErrorReport = function(e, t) {
            if (this.shouldSend) {
                void 0 !== t && this.builder.withRequestId(t);
                var i = this.builder.build(),
                    n = e.buildErrorUrl();
                n += this.debug ? "?debug=1" : "";
                var r = JSON.stringify(i);
                navigator.sendBeacon && navigator.sendBeacon(n, r), this.shouldSend = !1, this.builder = new ri(di.environment)
            }
        }, di.prototype.log = function(e, t) {
            this.shouldSend = !0, this.builder.withMessage(e, t)
        }, di.environment = "PublisherTag Version " + ge, di),
        ai, ci;

    function di(e) {
        void 0 === e && (e = !1), this.builder = new ri(di.environment), this.shouldSend = !1, this.debug = e
    }

    function li(t, i) {
        try {
            return decodeURIComponent(t)
        } catch (e) {
            return void 0 !== i ? i : t
        }
    }

    function ui(e) {
        var t = document.createElement("a");
        return t.href = e, {
            protocol: t.protocol,
            host: t.host,
            hostname: t.hostname,
            pathname: "/" === t.pathname[0] ? t.pathname.slice(1) : t.pathname,
            search: t.search,
            href: t.href
        }
    }

    function pi(e, t) {
        var i = document.createElement("a");
        t && "noDecodeWholeURL" in t && t.noDecodeWholeURL ? i.href = e : i.href = decodeURIComponent(e);
        var n = t && "decodeSearchAsString" in t && t.decodeSearchAsString;
        return {
            href: i.href,
            protocol: (i.protocol || "").replace(/:$/, ""),
            hostname: i.hostname,
            port: +i.port,
            pathname: i.pathname.replace(/^(?!\/)/, "/"),
            search: n ? i.search : fi(i.search || ""),
            hash: (i.hash || "").replace(/^#/, ""),
            host: i.host || window.location.host
        }
    }

    function hi(t) {
        return Object.keys(t).map(function(e) {
            return e + "=" + t[e]
        }).join("&")
    }

    function vi(e) {
        return (e.protocol || "http") + "://" + (e.host || e.hostname + (e.port ? ":" + e.port : "")) + (e.pathname || "") + (e.search ? "?" + hi(e.search || "") : "") + (e.hash ? "#" + e.hash : "")
    }

    function fi(e) {
        return e ? e.replace(/^\?/, "").split("&").reduce(function(e, t) {
            var i = t.split("="),
                n = i[0],
                r = i[1];
            return /\[\]$/.test(n) || (e[n] = r || ""), e
        }, {}) : {}
    }

    function mi(e) {
        var t = {},
            i = e.split("?");
        if (1 < i.length)
            for (var n = 0, r = i[1].split("&"); n < r.length; n++) {
                var o = r[n].split("=");
                t[li(o[0])] = li(o[1])
            }
        return t
    }

    function gi(e) {
        try {
            return Boolean(new URL(e))
        } catch (e) {
            return !1
        }
    }
    ci = ai = ai || {}, ci[ci.InFriendlyIframe = 1] = "InFriendlyIframe", ci[ci.InUnfriendlyIframe = 2] = "InUnfriendlyIframe", ci[ci.DirectIntegration = 3] = "DirectIntegration";
    var yi = (bi.prototype.getUserContextualData = function() {
        var e, t, i, n, r, o, s, a, c, d, l, u, p, h;
        return {
            data: {
                contentLanguage: this.getContentLanguage(),
                navigatorLanguage: null === (t = null === (e = this.window) || void 0 === e ? void 0 : e.navigator) || void 0 === t ? void 0 : t.language,
                orientation: this.getOrientation(),
                windowInnerWidth: null === (i = this.window) || void 0 === i ? void 0 : i.innerWidth,
                windowInnerHeight: null === (n = this.window) || void 0 === n ? void 0 : n.innerHeight,
                pageWidth: null === (s = null === (o = null === (r = this.window) || void 0 === r ? void 0 : r.document) || void 0 === o ? void 0 : o.documentElement) || void 0 === s ? void 0 : s.scrollWidth,
                pageHeight: null === (d = null === (c = null === (a = this.window) || void 0 === a ? void 0 : a.document) || void 0 === c ? void 0 : c.documentElement) || void 0 === d ? void 0 : d.scrollHeight,
                sessionDuration: Oe.TimeSincePageLoad()
            },
            device: {
                w: null === (u = null === (l = this.window) || void 0 === l ? void 0 : l.screen) || void 0 === u ? void 0 : u.width,
                h: null === (h = null === (p = this.window) || void 0 === p ? void 0 : p.screen) || void 0 === h ? void 0 : h.height
            }
        }
    }, bi.prototype.getOrientation = function() {
        var e, t, i, n, r, o;
        return ((null === (t = null === (e = this.window) || void 0 === e ? void 0 : e.screen) || void 0 === t ? void 0 : t.orientation) || {}).type || (null === (n = null === (i = this.window) || void 0 === i ? void 0 : i.screen) || void 0 === n ? void 0 : n.mozOrientation) || (null === (o = null === (r = this.window) || void 0 === r ? void 0 : r.screen) || void 0 === o ? void 0 : o.msOrientation)
    }, bi.prototype.getContentLanguage = function() {
        var e, t, i, n, r, o = null === (i = null === (t = null === (e = this.window) || void 0 === e ? void 0 : e.document) || void 0 === t ? void 0 : t.documentElement) || void 0 === i ? void 0 : i.lang;
        if (!o && "function" == typeof(null === (r = null === (n = this.window) || void 0 === n ? void 0 : n.document) || void 0 === r ? void 0 : r.querySelector)) {
            var s = this.window.document.querySelector('meta[http-equiv="Content-Language"]');
            o = null == s ? void 0 : s.content
        }
        return o
    }, bi);

    function bi(e) {
        this.window = e
    }
    var wi = (Ci = we, t(Ti, Ci), Ti.prototype.sendEvents = function(e) {
            var t = {
                requestId: this.context.getClientSessionId(),
                events: [e]
            };
            this.context.isEligibleForCsmEvents() && this.sendEventsToBeacon(t, this.urlBuilder.buildCsmEventsUrl())
        }, Ti),
        Ci, _i, Si, Ei, Ii;

    function Ti(e) {
        var t = Ci.call(this) || this;
        return t.context = e, t
    }
    Si = _i = _i || {}, Si[Si.None = 0] = "None", Si[Si.Cookie = 1] = "Cookie", Si[Si.LocalStorage = 2] = "LocalStorage", Si[Si.Delegation = 4] = "Delegation", Ii = Ei = Ei || {}, Ii[Ii.Unknown = 0] = "Unknown", Ii[Ii.Deactivated = 1] = "Deactivated", Ii[Ii.Activated = 2] = "Activated";
    var Pi = (Ai.prototype.getSid = function() {
        return this.userDataHandlers.sid().fromAllStorages()
    }, Ai.prototype.getIdCpy = function() {
        return this.userDataHandlers.idCpy().fromAllStorages()
    }, Ai.prototype.getLocalWebId = function() {
        return this.userDataHandlers.localWebId().fromAllStorages()
    }, Ai.prototype.getOptOut = function() {
        return this.userDataHandlers.optOut().fromAllStorages()
    }, Ai.prototype.getBundle = function() {
        return this.userDataHandlers.bundle().fromAllStorages()
    }, Ai);

    function Ai(e) {
        this.userDataHandlers = e
    }
    var xi = (Ri.fromUserIdentificationData = function(e) {
        return new Ri(e.value, e.origin)
    }, Ri.fromValue = function(e) {
        return new Ri(e, _i.None)
    }, Ri.prototype.hasValue = function() {
        return "" !== String(this.value) && null !== this.value && void 0 !== this.value
    }, Ri);

    function Ri(e, t) {
        this.value = e, this.origin = t
    }
    var Di = (ki = xi, t(Oi, ki), Oi.prototype.hasValue = function() {
            return "" !== String(this.value) && null !== this.value && void 0 !== this.value
        }, Oi.prototype.saveOnAllStorages = function() {
            if (this.hasValue()) {
                var e = "boolean" == typeof this.value ? this.value ? "1" : "0" : String(this.value);
                this.storageAdapter.writeToAllStorages(this.storageKey, e, this.expirationTimeHours)
            }
        }, Oi.prototype.toJSON = function() {
            return {
                value: this.value,
                origin: this.origin
            }
        }, Oi),
        ki;

    function Oi(e, t, i, n, r) {
        var o = ki.call(this, i, n) || this;
        return o.storageKey = e, o.expirationTimeHours = t, o.storageAdapter = r, o
    }
    var Mi = (Ui.prototype.sid = function() {
        return this.createGuid(Ui.SID_COOKIE_NAME)
    }, Ui.prototype.idCpy = function() {
        return this.createGuid(Ui.IDCPY_COOKIE_NAME)
    }, Ui.prototype.localWebId = function() {
        return this.createGuid(Ui.LWID_COOKIE_NAME)
    }, Ui.prototype.optOut = function() {
        return new Fi(Boolean, Ui.OPTOUT_COOKIE_NAME, Ui.OPTOUT_RETENTION_TIME_HOUR, this.storageAdapter)
    }, Ui.prototype.bundle = function() {
        return this.createGuid(Ui.BUNDLE_COOKIE_NAME)
    }, Ui.prototype.createGuid = function(e) {
        return new Fi(String, e, Ui.GUID_RETENTION_TIME_HOUR, this.storageAdapter)
    }, Ui.SID_COOKIE_NAME = "cto_sid", Ui.IDCPY_COOKIE_NAME = "cto_idcpy", Ui.LWID_COOKIE_NAME = "cto_lwid", Ui.OPTOUT_COOKIE_NAME = "cto_optout", Ui.BUNDLE_COOKIE_NAME = "cto_bundle", Ui.GUID_RETENTION_TIME_HOUR = 9360, Ui.OPTOUT_RETENTION_TIME_HOUR = 43200, Ui);

    function Ui(e) {
        this.storageAdapter = e
    }
    var Fi = (Li.prototype.fromAllStorages = function() {
        var e = this.storageAdapter.readFromAllStorages(this.storageKey),
            t = "boolean" == typeof(new this.type).valueOf() ? "1" === e.value : e.value;
        return this.create(t, e.origin)
    }, Li.prototype.fromValue = function(e) {
        return this.create(e, _i.None)
    }, Li.prototype.removeFromAllStorages = function() {
        this.storageAdapter.removeFromAllStorages(this.storageKey)
    }, Li.prototype.create = function(e, t) {
        return new Di(this.storageKey, this.expirationTimeHours, e, t, this.storageAdapter)
    }, Li);

    function Li(e, t, i, n) {
        this.type = e, this.storageKey = t, this.expirationTimeHours = i, this.storageAdapter = n
    }
    var Bi = (Ni.prototype.getSyncframeListener = function(i, n) {
        var r = this;
        return function(e) {
            if (!r.discardMessageFromOtherFrames(e) || r.window.criteo_syncframe_state.ForceSyncframeMessageHandling) {
                var t = e.data;
                (null == t ? void 0 : t.requestId) === i && (e.stopImmediatePropagation(), r.handleSyncframeResponse(t, n), r.window.criteo_syncframe_state.firstSyncframeCompleted = !0, r.window.criteo_syncframe_state.syncframeRequested = !1, r.tryUnqueueAppendSyncframeRequests())
            }
        }
    }, Ni.prototype.userBundleHasAlreadyBeenRetrieved = function() {
        return this.userDataHandlers.bundle().fromAllStorages().hasValue()
    }, Ni.prototype.canDropSyncframe = function() {
        return !this.window.criteo_syncframe_state.syncframeRequested
    }, Ni.prototype.discardMessageFromOtherFrames = function(e) {
        return !e.data || e.origin != this.syncframeOrigin
    }, Ni.prototype.appendGumIframeIfDoesNotExist = function(e, t, i) {
        var n, r = this;
        !0 === (null === (n = this.window.criteo_syncframe_state) || void 0 === n ? void 0 : n.firstSyncframeCompleted) || this.userBundleHasAlreadyBeenRetrieved() || this.canDropSyncframe() ? this.appendGumIframe(e, t, i) : this.queueAppendSyncframeRequest(function() {
            return r.appendGumIframeIfDoesNotExist(e, t, i)
        })
    }, Ni.prototype.doOnCompletedDom = function(e) {
        var t = this;
        if (this.window.addEventListener)
            if ("complete" === this.document.readyState) e();
            else {
                var i = function() {
                    t.window.removeEventListener("load", i), t.document.removeEventListener("DOMContentLoaded", i), e()
                };
                this.window.addEventListener("load", i, !1), this.document.addEventListener("DOMContentLoaded", i, !1)
            }
    }, Ni.prototype.appendGumIframe = function(e, t, i) {
        t();
        var n = e();
        if (this.consentAllowsSyncframeToBeDropped(n.consent)) {
            this.window.addEventListener("message", this.getSyncframeListener(n.requestId, i), !0);
            var r = this.createIFrame(n);
            this.document.body.appendChild(r), this.window.criteo_syncframe_state.syncframeRequested = !0
        } else this.handleSyncframeResponse({}, i)
    }, Ni.prototype.consentAllowsSyncframeToBeDropped = function(e) {
        var t;
        return 2 !== (null == e ? void 0 : e.gdprVersion) || !0 !== (null == e ? void 0 : e.gdprApplies) || !0 === (null === (t = null == e ? void 0 : e.vendorConsents) || void 0 === t ? void 0 : t[this.criteoGlobalVendorListId])
    }, Ni.prototype.queueAppendSyncframeRequest = function(e) {
        void 0 !== this.window.criteo_syncframe_state.appendSyncframeRequestQueue && this.window.criteo_syncframe_state.appendSyncframeRequestQueue.push(e)
    }, Ni.prototype.tryUnqueueAppendSyncframeRequests = function() {
        for (var e, t, i = null === (e = this.window.criteo_syncframe_state.appendSyncframeRequestQueue) || void 0 === e ? void 0 : e.shift(); void 0 !== i;) i(), i = null === (t = this.window.criteo_syncframe_state.appendSyncframeRequestQueue) || void 0 === t ? void 0 : t.shift()
    }, Ni.prototype.createIFrame = function(e) {
        var t, i = this.document.createElement("iframe"),
            n = {
                uid: e.uid,
                lwid: e.localWebId,
                bundle: e.bundle,
                optout: e.optoutCookie,
                sid: e.secureIdCookie,
                tld: e.topLevelDomain,
                topUrl: e.topUrl,
                version: "string" == typeof e.version ? null === (t = e.version) || void 0 === t ? void 0 : t.replace(/\./g, "_") : e.version,
                cw: e.canWriteCookie,
                lsw: e.canWriteLocalStorage,
                origin: e.origin,
                pm: e.privateMode,
                rtusCallerId: e.rtusCallerId,
                requestId: e.requestId
            },
            r = [];
        return r.push("origin=" + e.origin), r.push("topUrl=" + e.topUrl), e.consent && (void 0 !== e.consent.gdprApplies && r.push("gdpr=" + (e.consent.gdprApplies ? 1 : 0)), void 0 !== e.consent.consentData && r.push("gdpr_consent=" + e.consent.consentData), void 0 !== e.consent.uspString && r.push("us_privacy=" + e.consent.uspString), void 0 !== e.consent.gppString && r.push("gpp=" + e.consent.gppString), void 0 !== e.consent.gppSectionIds && r.push("gpp_sid=" + e.consent.gppSectionIds)), e.isDebug && r.push("debug=1"), i.src = this.syncframeEndpoint + "?" + r.join("&") + "#" + JSON.stringify(n), i.width = "0", i.height = "0", i.frameBorder = "0", i.style.borderWidth = "0px", i.style.margin = "0px", i.style.display = "none", i.title = "Criteo GUM iframe", i
    }, Ni);

    function Ni(e, t, i) {
        this.criteoGlobalVendorListId = 91, this.window = e, this.document = e.document, this.userDataHandlers = new Mi(t), i = null != i ? i : "gum.criteo.com", this.syncframeOrigin = "https://" + i, this.syncframeEndpoint = "https://" + i + "/syncframe", this.window.criteo_syncframe_state || (this.window.criteo_syncframe_state = {
            syncframeRequested: !1
        }), this.window.criteo_syncframe_state.appendSyncframeRequestQueue || (this.window.criteo_syncframe_state.appendSyncframeRequestQueue = [])
    }
    var Wi = (Hi = Bi, t(qi, Hi), qi.prototype.handleSyncframeResponse = function(e, t) {
            var i;
            if (e.optout) this.deleteUserData(), this.userDataHandlers.optOut().fromValue(!0).saveOnAllStorages(), null === (i = null == t ? void 0 : t.resolve) || void 0 === i || i.call(t, "");
            else {
                if (e.uid && this.userDataHandlers.idCpy().fromValue(e.uid).saveOnAllStorages(), e.callbacks)
                    for (var n = 0, r = "string" == typeof e.callbacks ? [e.callbacks] : e.callbacks; n < r.length; n++) {
                        var o = r[n],
                            s = this.document.createElement("img");
                        s.style.display = "none", s.width = 1, s.height = 1, s.setAttribute("data-owner", "criteo-tag"), s.src = o
                    } else e.bundle && this.userDataHandlers.bundle().fromValue(e.bundle).saveOnAllStorages();
                e.removeSid ? this.userDataHandlers.sid().removeFromAllStorages() : e.sid && this.userDataHandlers.sid().fromValue(e.sid).saveOnAllStorages(), (null == t ? void 0 : t.resolve) && t.resolve(e.bundle ? e.bundle : "")
            }
        }, qi.prototype.appendGumIFrameOnCompletedDomIfItDoesNotExist = function(e, t) {
            function i() {
                return n.appendGumIframeIfDoesNotExist(function() {
                    return n.createSyncframeRequest(e(), r)
                }, function() {}, {
                    resolve: t
                })
            }
            var n = this,
                r = Math.random().toString();
            this.adapter.isPubTagIds ? i() : this.doOnCompletedDom(i)
        }, qi.prototype.createSyncframeRequest = function(e, t) {
            return {
                uid: this.userDataHandlers.idCpy().fromAllStorages().toJSON(),
                localWebId: this.userDataHandlers.localWebId().fromAllStorages().toJSON(),
                bundle: this.userDataHandlers.bundle().fromAllStorages().toJSON(),
                optoutCookie: this.userDataHandlers.optOut().fromAllStorages().toJSON(),
                secureIdCookie: this.userDataHandlers.sid().fromAllStorages().toJSON(),
                topLevelDomain: e.topLevelDomain,
                topUrl: e.topUrl,
                version: e.version,
                canWriteCookie: e.canWriteCookie,
                canWriteLocalStorage: e.canWriteLocalStorage,
                origin: this.adapter.isPubTagIds ? "publishertagids" : "publishertag",
                privateMode: void 0,
                consent: e.consent,
                rtusCallerId: void 0,
                isDebug: this.adapter.isDebug,
                requestId: t
            }
        }, qi.prototype.fetchUserData = function() {
            return new Pi(this.userDataHandlers)
        }, qi.prototype.deleteUserData = function() {
            this.userDataHandlers.idCpy().removeFromAllStorages(), this.userDataHandlers.bundle().removeFromAllStorages(), this.userDataHandlers.sid().removeFromAllStorages()
        }, qi),
        Hi;

    function qi(e, t, i) {
        void 0 === i && (i = !1);
        var n = Hi.call(this, t, e.storageAdapter, i ? "gumi.criteo.com" : "gum.criteo.com") || this;
        return n.adapter = e, n
    }
    var Gi = (zi.prototype.synchronizeCriteoUid = function(e, t) {
        var i = this,
            n = null == e ? void 0 : e.gdprConsent,
            r = null == e ? void 0 : e.ccpaIabConsent,
            o = null == e ? void 0 : e.gppConsent;
        this.syncframe.appendGumIFrameOnCompletedDomIfItDoesNotExist(function() {
            var e;
            return {
                topLevelDomain: i.getTld(),
                topUrl: encodeURIComponent(ui(i.topUrl).hostname),
                version: ge,
                canWriteCookie: i.canWriteCookies,
                canWriteLocalStorage: i.localStorageHelper.localStorageEnabled,
                consent: {
                    gdprApplies: null == n ? void 0 : n.gdprApplies,
                    consentData: null == n ? void 0 : n.consentData || "",
                    gdprVersion: null == n ? void 0 : n.version,
                    vendorConsents: null == n ? void 0 : n.vendorConsents,
                    uspString: null == r ? void 0 : r.uspString,
                    ccpaVersion: null == r ? void 0 : r.version,
                    gppString: null == o ? void 0 : o.gpp,
                    gppSectionIds: null === (e = null == o ? void 0 : o.gppSid) || void 0 === e ? void 0 : e.join(",")
                }
            }
        }, t)
    }, zi.prototype.checkCookiesAreWriteable = function() {
        var e = "cto_writeable";
        this.cookieHelper.setCookie(e, "1", 1, this.topDoc, !0);
        var t = "1" === this.cookieHelper.getCookie(e, this.topDoc);
        return this.cookieHelper.deleteCookie(e, this.topDoc, !0), t
    }, zi.prototype.writeOnAllStorages = function(e, t, i) {
        this.localStorageHelper.setItem(e, t), this.cookieHelper.setCookie(e, t, i, this.topDoc, !0)
    }, zi.prototype.getFromAllStorages = function(e) {
        var t = this.cookieHelper.getCookie(e, this.topDoc),
            i = this.localStorageHelper.getItem(e) || void 0;
        return {
            value: t || i,
            origin: (t && _i.Cookie) | (i && _i.LocalStorage)
        }
    }, zi.prototype.deleteFromAllStorage = function(e) {
        this.cookieHelper.deleteCookie(e, this.topDoc, !0), this.localStorageHelper.removeItem(e)
    }, zi.prototype.getTld = function() {
        var e = this.cookieHelper.setCookie(zi.TLD_TEST_COOKIE_NAME, "test", 1, this.topDoc, !0);
        return this.cookieHelper.deleteCookie(zi.TLD_TEST_COOKIE_NAME, this.topDoc, !0), e
    }, zi.prototype.fetchUserData = function() {
        return this.syncframe.fetchUserData()
    }, zi.prototype.deleteUserData = function() {
        this.syncframe.deleteUserData()
    }, zi.TLD_TEST_COOKIE_NAME = "cto_pub_test_tld", zi);

    function zi(e, t, i, n, r, o) {
        var s = this;
        this.topDoc = i.document, this.cookieHelper = e, this.localStorageHelper = t, this.canWriteCookies = this.checkCookiesAreWriteable(), this.topUrl = r;
        var a = !1;
        try {
            a = JSON.parse("true")
        } catch (e) {}
        this.syncframe = new Wi({
            storageAdapter: {
                readFromAllStorages: function(e) {
                    var t = s.getFromAllStorages(e);
                    return {
                        value: t.value,
                        origin: t.origin
                    }
                },
                writeToAllStorages: function(e, t, i) {
                    s.writeOnAllStorages(e, t, i)
                },
                removeFromAllStorages: function(e) {
                    s.deleteFromAllStorage(e)
                }
            },
            isPubTagIds: null != o && o,
            isDebug: n
        }, i, a)
    }
    var Vi = (ji.prototype.synchronizeCriteoUid = function(e, t, i, n) {
        var r, o = (null === (r = this.cookieSynchronizerFactory) || void 0 === r ? void 0 : r.call(this)) || new Gi(t, e, this.highestAccessibleWindowStruct.topFrame, this.debugMode, this.highestAccessibleUrl, !1),
            s = o.fetchUserData();
        i("", s.getOptOut().value, "", s.getBundle().value), o.synchronizeCriteoUid(n)
    }, ji.prototype.getServicesAndSyncCriteoUid = function(n) {
        var r = this;
        void 0 === n && (n = function(e, t, i, n) {}), this.serviceProvider.getServicesAsync(function(e) {
            var t, i;
            (null === (t = e.ccpaConsentProvider) || void 0 === t ? void 0 : t.hasUserOptOut(null === (i = e.privacies) || void 0 === i ? void 0 : i.ccpaIabConsent)) || r.synchronizeCriteoUid(e.localStorageHelper, e.cookieHelper, n, e.privacies)
        })
    }, ji.prototype.deleteCriteoUid = function() {
        var i = this;
        this.serviceProvider.getServicesAsync(function(e) {
            var t;
            ((null === (t = i.cookieSynchronizerFactory) || void 0 === t ? void 0 : t.call(i)) || new Gi(e.cookieHelper, e.localStorageHelper, i.highestAccessibleWindowStruct.topFrame, i.debugMode, i.highestAccessibleUrl, !1)).deleteUserData()
        })
    }, ji);

    function ji(e, t, i, n) {
        this.highestAccessibleWindowStruct = Ge.getHighestAccessibleWindow(e), this.highestAccessibleUrl = Ge.getHighestAccessibleUrl(this.highestAccessibleWindowStruct);
        var r = mi(this.highestAccessibleUrl);
        this.debugMode = "1" === r.pbt_debug || !1, this.debugMode && ee(X.Debug), this.cookieSynchronizerFactory = t, this.serviceProvider = i || new Ut(this.highestAccessibleWindowStruct.topFrame, void 0, void 0, void 0, n)
    }
    var Ki = (Xi.prototype.getContextFlags = function() {
        var e = "";
        return e += this.debugMode ? "&debug=1" : "", e += this.noLog ? "&nolog=1" : ""
    }, Xi.prototype.isEligibleForCsmEvents = function() {
        return this.sessionRandomId % 100 == 0
    }, Xi.prototype.getClientSessionId = function() {
        return this.clientSessionId
    }, Xi.prototype.getMetricsManager = function() {
        return this.contextMetricsManager
    }, Xi.prototype.getDisplayContext = function(e) {
        return Ge.inIframe() ? e.err ? ai.InUnfriendlyIframe : ai.InFriendlyIframe : ai.DirectIntegration
    }, Xi.prototype.synchronizeCriteoUid = function() {
        var r = this;
        this.identityHelper.getServicesAndSyncCriteoUid(function(e, t, i, n) {
            r.isOptOut = t, r.bundle = n
        })
    }, Xi.prototype.getIdfs = function() {
        return ""
    }, Xi.prototype.setIdfs = function(e) {}, Xi.prototype.setSite = function(e) {
        this.site = e
    }, Xi.prototype.getSite = function() {
        return this.site
    }, Xi.prototype.setDevice = function(e) {
        this.device = e
    }, Xi.prototype.getDevice = function() {
        return this.device
    }, Xi.prototype.setUser = function(e) {
        this.user = e
    }, Xi.prototype.getPublisherExt = function() {
        return {}
    }, Xi.prototype.getUserExtWithContextualData = function() {
        return {}
    }, Xi.prototype.getUser = function() {
        var e, t, i, n = this.user || {},
            r = this.userContextualDataManager.getUserContextualData();
        if (null == r ? void 0 : r.data) {
            var o = L(L({}, null === (e = n.ext) || void 0 === e ? void 0 : e.data), r.data);
            n.ext = L(L({}, n.ext), {
                data: o
            })
        }
        if (null == r ? void 0 : r.device) {
            var s = L(L({}, null === (t = n.ext) || void 0 === t ? void 0 : t.device), r.device);
            n.ext = L(L({}, n.ext), {
                device: s
            })
        }
        return (null === (i = this.device) || void 0 === i ? void 0 : i.sua) && (n.ext = L(L({}, n.ext), {
            sua: this.device.sua
        })), n
    }, Xi);

    function Xi(e, t, i, n, r, o, s, a) {
        void 0 === s && (s = (new Date).getUTCMilliseconds()), void 0 === a && (a = Re()), this.cloneByImpressionId = {}, this.sessionRandomId = s, this.clientSessionId = a, this.contextMetricsManager = new wi(this), this.charset = e.charset || e.characterSet || "", this.highestAccessibleWindowStruct = Ge.getHighestAccessibleWindow(t), this.displayContext = this.getDisplayContext(this.highestAccessibleWindowStruct), this.highestAccessibleUrl = Ge.getHighestAccessibleUrl(this.highestAccessibleWindowStruct);
        var c = mi(this.highestAccessibleUrl);
        this.debugMode = "1" === c.pbt_debug || !1, this.noLog = "1" === c.pbt_nolog || !1, this.remoteLogging = new si(this.debugMode), this.debugMode && ee(X.Debug), this.location = t.location, this.dising = !1, this.ct0 = void 0, this.wpdt0 = void 0, this.isAdBlocked = void 0, this.rtaVarNames = [], this.identityHelper = new Vi(t, i, n, r), this.serviceProvider = this.identityHelper.serviceProvider, this.synchronizeCriteoUid(), this.userContextualDataManager = o || new yi(t)
    }
    var Ji = function() {
        this.bids = {}, this.lineItemRanges = [], this.impIds = []
    };

    function Yi(e) {
        return "conditionalEvent" === e.name
    }
    var Qi = ($i.prototype.push = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        for (var i = 0, n = e; i < n.length; i++) {
            var r = n[i];
            this.events.push(r)
        }
        this.evalEvents()
    }, $i.prototype.evalEvents = function() {
        for (var e = 0; e < this.events.length;) {
            var t = this.events[e];
            if (Yi(t) && !t.canEval()) e++;
            else {
                var i = this.events.splice(e, 1);
                try {
                    i[0].eval(this)
                } catch (e) {
                    $.Error("An exception occurred processing an event: " + e.toString())
                }
            }
        }
    }, $i.VERSION = ge, $i);

    function $i(e) {
        var t;
        void 0 === e && (e = null === (t = window.Criteo_prebid_144 || window.Criteo) || void 0 === t ? void 0 : t.config), this.standaloneBidder = new Ji, this.events = [], this.context = new Ki(document, window, void 0, void 0, e), $.Debug("Publisher Tag loaded")
    }

    function Zi(e) {
        window.criteo_pubtag && window.criteo_pubtag.context && "serviceProvider" in window.criteo_pubtag.context || (ei.LoadPolyfills(), window.criteo_pubtag = new Qi, window.criteo_pubtag_prebid_144 = window.criteo_pubtag), window.Criteo = en(window.Criteo || {}, e), window.Criteo_prebid_144 = window.Criteo, $.Debug("Publisher Tag initialized with window.criteo_pubtag|criteo_pubtag_prebid_144, window.Criteo|Criteo_prebid_144")
    }

    function en(e, t) {
        if (tn(e) && tn(t))
            for (var i in t)
                if (tn(t[i])) {
                    if (!tn(e[i]) && void 0 !== e[i]) continue;
                    tn(e[i]) || (e[i] = {}), en(e[i], t[i])
                } else void 0 === e[i] && (e[i] = t[i]);
        return e
    }

    function tn(e) {
        return e && "object" == typeof e && !Array.isArray(e)
    }

    function nn() {
        var e, t, i, n, r, o;
        Zi(Vt({
            PubTag: {
                Adapters: {
                    Prebid: pt
                },
                DirectBidding: {
                    DirectBiddingEvent: Wt,
                    DirectBiddingSlot: De,
                    DirectBiddingUrlBuilder: ye,
                    Size: Be
                }
            },
            events: null !== (t = null === (e = window.Criteo) || void 0 === e ? void 0 : e.events) && void 0 !== t ? t : [],
            passbackEvents: null !== (n = null === (i = window.Criteo) || void 0 === i ? void 0 : i.passbackEvents) && void 0 !== n ? n : [],
            usePrebidEvents: null === (o = null === (r = window.Criteo) || void 0 === r ? void 0 : r.usePrebidEvents) || void 0 === o || o
        })), !1 !== window.Criteo.usePrebidEvents && (window.Criteo.events = jt(window.Criteo.events)), window.criteo_pubtag.context.serviceProvider.getServicesAsync(function(e) {
            Gt(e.localStorageHelper)
        })
    }
    nn(), e.DeclarePrebid = nn
}({});