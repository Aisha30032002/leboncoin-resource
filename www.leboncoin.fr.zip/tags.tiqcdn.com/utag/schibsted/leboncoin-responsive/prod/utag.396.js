//tealium universal tag - utag.396 ut4.0.202311281603, Copyright 2023 Tealium.com Inc. All Rights Reserved.
try {
    (function(id, loader) {
        var u = {};
        utag.o[loader].sender[id] = u;
        if (utag === undefined) {
            utag = {};
        }
        if (utag.ut === undefined) {
            utag.ut = {};
        }
        if (utag.ut.loader === undefined) {
            u.loader = function(o) {
                var a, b, c, l;
                a = document;
                if (o.type === "iframe") {
                    b = a.createElement("iframe");
                    b.setAttribute("height", "1");
                    b.setAttribute("width", "1");
                    b.setAttribute("style", "display:none");
                    b.setAttribute("src", o.src);
                } else if (o.type === "img") {
                    utag.DB("Attach img: " + o.src);
                    b = new Image();
                    b.src = o.src;
                    return;
                } else {
                    b = a.createElement("script");
                    b.language = "javascript";
                    b.type = "text/javascript";
                    b.async = 1;
                    b.charset = "utf-8";
                    b.src = o.src;
                }
                if (o.id) {
                    b.id = o.id;
                }
                if (typeof o.cb === "function") {
                    if (b.addEventListener) {
                        b.addEventListener("load", function() {
                            o.cb();
                        }, false);
                    } else {
                        b.onreadystatechange = function() {
                            if (this.readyState === "complete" || this.readyState === "loaded") {
                                this.onreadystatechange = null;
                                o.cb();
                            }
                        };
                    }
                }
                l = o.loc || "head";
                c = a.getElementsByTagName(l)[0];
                if (c) {
                    utag.DB("Attach to " + l + ": " + o.src);
                    if (l === "script") {
                        c.parentNode.insertBefore(b, c);
                    } else {
                        c.appendChild(b);
                    }
                }
            };
        } else {
            u.loader = utag.ut.loader;
        }
        u.ev = {
            'weborama': 1
        };
        u.initialized = false;
        u.map = {
            "departement": "qp.departement,qp.D",
            "region": "qp.region,qp.R",
            "anneemax": "qp.anneemax,qp.regdatemax",
            "offres": "qp.offres,qp.offer",
            "activites": "qp.activites,qp.jobfield",
            "anneemin": "qp.anneemin,qp.regdatemin",
            "vitesse": "qp.vitesse,qp.gearbox",
            "nrj": "qp.nrj,qp.fuel",
            "piscine": "qp.piscine,qp.swimming_pool",
            "capacitemax": "qp.capacitemax,qp.capacitymax",
            "capacitemin": "qp.capacitemin,qp.capacitymin",
            "ccmin": "qp.ccmin,qp.cubic_capacitymin",
            "ccmax": "qp.ccmax,qp.cubic_capacitymax",
            "chambremax": "qp.chambremax,qp.bedroomsmax",
            "chambremin": "qp.chambremin,qp.bedroomsmin",
            "datemax": "qp.datemax",
            "datemin": "qp.datemin",
            "etudes": "qp.etudes,qp.jobstudy",
            "fonction": "qp.fonction,qp.jobduty",
            "kmmax": "qp.kmmax,qp.mileagemax",
            "kmmin": "qp.kmmin,qp.mileagemin",
            "loyermax": "qp.loyermax,qp.pricemax",
            "loyermin": "qp.loyermin,qp.pricemin",
            "piecesmax": "qp.piecesmax,qp.roomsmax",
            "piecesmin": "qp.piecesmin,qp.roomsmin",
            "prixmax": "qp.prixmax,qp.pricemax",
            "prixmin": "qp.prixmin,qp.pricemin",
            "search": "qp.search,qp.pt1",
            "surfacemax": "qp.surfacemax,qp.squaremax",
            "surfacemin": "qp.surfacemin,qp.squaremin",
            "temps": "qp.temps,qp.jobtime",
            "nbphoto": "qp.nbphoto",
            "siren": "qp.siren",
            "experience": "qp.experience,qp.jobexp",
            "prix": "qp.prix,qp.price",
            "marque": "qp.brand,qp.marque",
            "modele": "qp.modele,qp.model",
            "km": "qp.km,qp.mileage",
            "annee": "qp.annee,qp.regdate",
            "cc": "qp.cc,qp.cubic_capacity",
            "surface": "qp.surface,qp.square",
            "loyer": "qp.loyer,qp.price",
            "pieces": "qp.pieces,qp.rooms",
            "cat": "qp.cat",
            "subcat": "qp.subcat",
            "cp": "qp.cp,qp.zipcode",
            "city": "qp.city",
            "options": "qp.options",
            "pagetype": "qp.pagetype",
            "compte": "qp.compte",
            "urgent_only": "qp.urgent_only",
            "title_only": "qp.title_only",
            "previouspage": "qp.previouspage",
            "pagenumber": "qp.pagenumber",
            "publish_date": "qp.publishdate",
            "last_update_date": "lastupdatedate",
            "race": "qp.race",
            "age": "qp.age",
            "ad_type": "qp.adtype,qp.ad_type",
            "device": "qp.device",
            "displaytype": "qp.displaytype",
            "pagename": "qp.pagename",
            "oas_departement": "qp.oasdepartement",
            "nboptions": "qp.nboptions",
            "taille": "qp.taille,qp.baby_age",
            "eventname": "qp.eventname",
            "clicknumero": "qp.clicknumero,qp.click_numero",
            "clickmail": "qp.clickmail",
            "clicked_annonce_saved": "qp.clicked_annonce_saved,qp.click_annonce_saved",
            "titre": "qp.titre,qp.title",
            "userid": "qp.userid",
            "meuble": "qp.meuble,qp.furnished",
            "ges": "qp.ges",
            "energy_rate": "qp.energy_rate",
            "animal_chips": "qp.animal_chips,qp.tattooed_animal",
            "vaccinated_animal": "qp.vaccinated_animal",
            "capacite": "qp.capacite,qp.capacity",
            "chambre": "qp.chambre,qp.bedrooms",
            "charges": "qp.charges,qp.charges_included",
            "animal_race": "qp.animal_race",
            "animal_age": "qp.animal_age",
            "animal_identification": "qp.animal_identification",
            "animal_portee": "qp.animal_portee,qp.animal_litter",
            "pointure": "qp.pointure,qp.shoe_size",
            "nature": "qp.nature,qp.animal_offer_nature",
            "clickmessage": "qp.clickmessage,qp.click_message",
            "longitude": "qp.longitude",
            "latitude": "qp.latitude",
            "rayonkm": "qp.rayonkm",
            "immo_sell_type": "qp.immo_sell_type",
            "clickachat": "qp.clickachat,qp.click_achat",
            "type_emploi": "qp.type_emploi,qp.jobcontract",
            "type_immobilier": "qp.type_immobilier,qp.real_estate_type",
            "type_animaux": "qp.type_animaux,qp.animal_type",
            "type_vetements": "qp.type_vetements,qp.clothing_type",
            "type_chaussures": "qp.type_chaussures,qp.shoe_type",
            "type_bureaux_commerces": "qp.type_bureaux_commerces,qp.lease_type",
            "clothing_tag": "qp.clothing_tag",
            "bookable": "qp.bookable",
            "clickresa": "qp.clickresa",
            "depot": "qp.depot",
            "clothing_brand_a": "qp.clothing_brand_a",
            "clothing_color_a": "qp.clothing_color_a",
            "clothing_condition_a": "qp.clothing_condition_a",
            "shoe_category_a": "qp.shoe_category_a",
            "shoe_brand_a": "qp.shoe_brand_a",
            "baby_clothing_category_a": "qp.baby_clothing_category_a",
            "baby_clothing_brand_a": "qp.baby_clothing_brand_a",
            "regdate": "qp.regdate",
            "mileage": "qp.mileage",
            "vehicle_type": "qp.vehicle_type",
            "brand": "qp.brand",
            "model": "qp.model",
            "fuel": "qp.fuel",
            "gearbox": "qp.gearbox",
            "vehicle_vsp": "qp.vehicle_vsp",
            "cubic_capacity": "qp.cubic_capacity",
            "moto_brand": "qp.brand",
            "moto_type": "qp.moto_type",
            "square": "qp.square",
            "rooms": "qp.rooms",
            "real_estate_type": "qp.real_estate_type",
            "furnished": "qp.furnished",
            "bicycle_type": "qp.bicycle_type",
            "bicycle_wheel_size": "qp.bicycle_wheel_size",
            "qp.is_rental": "qp.is_rental",
            "email_hashe": "qp.email_hashe",
            "cp.euconsent": "qp.consent_string",
            "horsepower": "qp.horsepower",
            "doors": "qp.doors",
            "vehicule_color": "qp.vehicule_color",
            "car_licence": "qp.vehicle_vsp",
            "cycle_licence": "qp.cycle_licence",
            "custom_ref": "qp.custom_ref",
            "boat_type": "qp.boat_type",
            "training_field": "qp.training_field",
            "training_type": "qp.training_type",
            "cpf": "qp.cpf",
            "training_objectif": "qp.training_objectif",
            "educational_level": "qp.educational_level",
            "concerned_public": "qp.concerned_public",
            "holidays_real_estate_type": "qp.holidays_real_estate_type",
            "pet_accepted": "qp.pet_accepted",
            "console_brand": "qp.console_brand",
            "console_model": "qp.console_model",
            "item_condition": "qp.condition,qp.item_condition",
            "video_game_type": "qp.video_game_type",
            "phone_brand": "qp.phone_brand",
            "phone_model": "qp.phone_model",
            "phone_memory": "qp.phone_memory",
            "phone_color": "qp.phone_color",
            "condition": "qp.condition,qp.item_condition",
            "bicycle_size": "qp.bicycle_size",
            "decoration_type": "qp.decoration_type",
            "furniture_material": "qp.furniture_material",
            "furniture_color": "qp.furniture_color",
            "furniture_type": "qp.furniture_type",
            "baby_clothing_brand": "qp.baby_clothing_brand",
            "baby_clothing_category": "qp.baby_clothing_category",
            "baby_equipment_brand": "qp.baby_equipment_brand",
            "baby_equipment_type": "qp.baby_equipment_type",
            "watches_jewels_material": "qp.watches_jewels_material",
            "watches_jewels_brand": "qp.watches_jewels_brand",
            "accessories_univers": "qp.accessories_univers",
            "watches_jewels_type": "qp.watches_jewels_type",
            "accessories_material": "qp.accessories_material",
            "accessories_brand": "qp.accessories_brand",
            "accessories_type": "qp.accessories_type",
            "shoe_brand": "qp.shoe_brand",
            "shoe_category": "qp.shoe_category",
            "clothing_brand": "qp.clothing_brand",
            "clothing_color": "qp.clothing_color",
            "clothing_category": "qp.clothing_tag",
            "clothing_st": "qp.clothing_st",
            "clothing_type": "qp.clothing_type",
            "formfield": "qp.training_field",
            "formtype": "qp.training_type",
            "formcpf": "qp.cpf",
            "color": "qp.vehicule_color",
            "licence": "qp.cycle_licence",
            "boattype": "qp.boat_type",
            "horsepowermin": "qp.horsepowermin",
            "horsepowermax": "qp.horsepowermax",
            "seats": "qp.seats",
            "swimming_pool": "qp.swimming_pool",
            "petaccepted": "qp.pet_accepted",
            "jobcontract": "qp.jobcontract",
            "jobduty": "qp.jobduty",
            "jobfield": "qp.jobfield",
            "jobtime": "qp.jobtime",
            "jobexp": "qp.jobexp",
            "jobstudy": "qp.jobstudy",
            "type": "qp.clothing_type",
            "lease_type": "qp.lease_type",
            "price_max": "qp.pricemax",
            "price_min": "qp.pricemin",
            "mileage_max": "qp.mileagemax",
            "mileage_min": "qp.mileagemin",
            "regdate_max": "qp.regdatemax",
            "regdate_min": "qp.regdatemin",
            "horsepower_max": "qp.horsepowermax",
            "horsepower_min": "qp.horsepowermin",
            "capacity_max": "qp.capacitymax",
            "capacity_min": "qp.capacitymin",
            "date_max": "qp.datemax",
            "date_min": "qp.datemin",
            "bedrooms_max": "qp.bedroomsmax",
            "bedrooms_min": "qp.bedroomsmin",
            "cubic_capacity_max": "qp.cubic_capacitymax",
            "cubic_capacity_min": "qp.cubic_capacitymin",
            "square_max": "qp.squaremax",
            "square_min": "qp.squaremin",
            "rooms_max": "qp.roomsmax",
            "rooms_min": "qp.roomsmin",
            "animal_type": "qp.animal_type",
            "animal_offer_nature": "qp.animal_offer_nature",
            "shoe_type": "qp.shoe_type",
            "shoe_size": "qp.shoe_size",
            "baby_age": "qp.baby_age",
            "intent": "qp.intent",
            "click_message": "qp.click_message",
            "click_numero": "qp.click_numero",
            "click_annonce_saved": "qp.click_annonce_saved",
            "click_achat": "qp.click_achat",
            "click_resa": "qp.click_resa",
            "statut_retency": "qp.statut_vendor1",
            "statut_mobsucess": "qp.statut_vendor2",
            "statut_happydemics": "qp.statut_vendor3",
            "statut_google": "qp.statut_vendor4",
            "statut_xandr": "qp.statut_vendor5",
            "statut_kairos": "qp.statut_vendor6",
            "statut_adsquare": "qp.statut_vendor7",
            "home_appliance_product": "qp.home_appliance_product",
            "home_appliance_type": "qp.home_appliance_type",
            "statut_facebook": "qp.statut_vendor8",
            "statut_snapchat": "qp.statut_vendor9",
            "u_car_brand": "qp.brand,qp.marque",
            "u_car_model": "qp.model,qp.modele",
            "qp.ldv_outside_equipment": "qp.ldv_outside_equipment",
            "usidh": "qp.usidh",
            "statut_hawk": "qp.statut_vendor10",
            "statut_linkedin": "qp.statut_vendor11",
            "children_room_furniture_product": "qp.children_room_furniture_product",
            "animal_accessories_animal_kind": "qp.animal_accessories_animal_kind",
            "table_art_product": "qp.table_art_product",
            "table_art_material": "qp.table_art_material",
            "linens_type": "qp.linens_type",
            "linens_material": "qp.linens_material",
            "hotel_grading": "qp.hotel_grading",
            "image_sound_product": "qp.image_sound_product",
            "matpro_agriculture_equipment_brand": "qp.matpro_agriculture_equipment_brand",
            "professional_equipment_horse_power_max": "qp.professional_equipment_horse_power_max",
            "professional_equipment_horse_power_min": "qp.professional_equipment_horse_power_min",
            "professional_equipment_usage_hour_max": "qp.professional_equipment_usage_hour_max",
            "professional_equipment_usage_hour_min": "qp.professional_equipment_usage_hour_min",
            "matpro_btp_equipment_brand": "qp.matpro_btp_equipment_brand",
            "matpro_btp_equipment_type": "qp.matpro_btp_equipment_type",
            "professional_equipment_weight_max": "qp.professional_equipment_weight_max",
            "professional_equipment_weight_min": "qp.professional_equipment_weight_min",
            "matpro_transport_handling_equipment_type": "qp.matpro_transport_handling_equipment_type",
            "qp.accommodation_type": "qp.accommodation_type"
        };
        u.extend = [];
        u.send = function(a, b) {
            if (u.ev[a] || u.ev.all !== undefined) {
                var c, d, e, f, i;
                u.data = {
                    "keywords": {},
                };
                for (d in utag.loader.GV(u.map)) {
                    if (b[d] !== undefined && b[d] !== "") {
                        e = u.map[d].split(",");
                        for (f = 0; f < e.length; f++) {
                            if (e[f].indexOf("keywords.") === 0 || e[f].indexOf("qp.") === 0) {
                                key = e[f].split(".");
                                u.data.keywords[key[1]] = b[d];
                            } else {
                                if (e[f].indexOf("ad.") === 0) {
                                    if (u.typeOf(b[d]) !== "array") {
                                        b[d] = [b[d]];
                                    }
                                }
                                u.data[e[f]] = b[d];
                            }
                        }
                    }
                }
                window.wamid = '2510';
                window.Wam2gamConf = {
                    token: "oUZWE9Xnvq2D",
                    idcrm: b.userid,
                    cookieless: false,
                    useXdevice: true,
                    gamTargetingAudiencesKey: "webo_audiences"
                };
                window.typ = '1';
                window.Wvar = u.data.keywords;
                (function() {
                    var w = document.createElement("script");
                    w.type = "text/javascript";
                    w.src = document.location.protocol + "//cstatic.weborama.fr/js/wam/customers/wamfactory_dpm.wildcard.min.js?rnd=" + new Date().getTime();
                    w.async = true;
                    var body = document.getElementsByTagName('script')[0];
                    body.parentNode.insertBefore(w, body);
                })();
            }
        };
        utag.o[loader].loader.LOAD(id);
    })("396", "schibsted.leboncoin-responsive");
} catch (error) {
    utag.DB(error);
}