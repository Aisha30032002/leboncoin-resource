//tealium universal tag - utag.255 ut4.0.202311281603, Copyright 2023 Tealium.com Inc. All Rights Reserved.
try {
    (function(id, loader) {
        var u = {};
        utag.o[loader].sender[id] = u;
        if (utag.ut === undefined) {
            utag.ut = {};
        }
        if (utag.ut.loader === undefined) {
            u.loader = function(o) {
                var a, b, c, l;
                a = document;
                if (o.type === "iframe") {
                    b = a.createElement("iframe");
                    b.setAttribute("height", "1");
                    b.setAttribute("width", "1");
                    b.setAttribute("style", "display:none");
                    b.setAttribute("src", o.src);
                } else if (o.type === "img") {
                    utag.DB("Attach img: " + o.src);
                    b = new Image();
                    b.src = o.src;
                    return;
                } else {
                    b = a.createElement("script");
                    b.language = "javascript";
                    b.type = "text/javascript";
                    b.async = 1;
                    b.src = o.src;
                }
                if (o.id) {
                    b.id = o.id;
                }
                if (typeof o.cb === "function") {
                    b.hFlag = 0;
                    b.onreadystatechange = function() {
                        if ((this.readyState === 'complete' || this.readyState === 'loaded') && !b.hFlag) {
                            b.hFlag = 1;
                            o.cb();
                        }
                    };
                    b.onload = function() {
                        if (!b.hFlag) {
                            b.hFlag = 1;
                            o.cb();
                        }
                    };
                }
                l = o.loc || "head";
                c = a.getElementsByTagName(l)[0];
                if (c) {
                    utag.DB("Attach to " + l + ": " + o.src);
                    if (l === "script") {
                        c.parentNode.insertBefore(b, c);
                    } else {
                        c.appendChild(b);
                    }
                }
            };
        } else {
            u.loader = utag.ut.loader;
        }
        u.ev = {
            'view': 1
        };
        u.map = {
            "departement": "u1",
            "region": "u2",
            "offres": "u5",
            "gearbox": "u7",
            "fuel": "u8",
            "search": "u25",
            "prix": "u31",
            "cat": "u38",
            "subcat": "u39",
            "city": "u41",
            "options": "u42",
            "pagetype": "u43",
            "compte": "u44",
            "urgent_only": "u45",
            "title_only": "u46",
            "pagenumber": "u47",
            "publish_date": "u48",
            "last_update_date": "u49",
            "race": "u50",
            "age": "u51",
            "ad_type": "u52",
            "device": "u53",
            "displaytype": "u54",
            "pagename": "u55",
            "nboptions": "u56",
            "eventname": "u58",
            "clickmail": "u60",
            "titre": "u62",
            "userid": "u63",
            "furnished": "u64",
            "ges": "u65",
            "energy_rate": "u66",
            "animal_chips": "u67",
            "vaccinated_animal": "u68",
            "charges": "u71",
            "animal_race": "u72",
            "animal_age": "u73",
            "animal_identification": "u74",
            "longitude": "u79",
            "latitude": "u80",
            "rayonkm": "u81",
            "immo_sell_type": "u82",
            "real_estate_type": "u85",
            "clothing_tag": "u89",
            "bookable": "u91",
            "clothing_brand_a": "u94",
            "clothing_condition_a": "u96",
            "shoe_category_a": "u97",
            "shoe_brand_a": "u98",
            "baby_clothing_category_a": "u99",
            "baby_clothing_brand_a": "u100",
            "vehicle_type": "u29",
            "clothing_st": "u93",
            "bicycle_type": "u95",
            "regdate_max": "u3",
            "regdate_min": "u6",
            "price_max": "u21",
            "price_min": "u22",
            "mileage_max": "u19",
            "mileage_min": "u20",
            "mileage": "u35",
            "regdate": "u36",
            "brand": "u33",
            "model": "u34",
            "bedrooms_max": "u13",
            "bedrooms_min": "u14",
            "bedrooms": "u70",
            "capacity_max": "u10",
            "capacity_min": "u11",
            "capacity": "u69",
            "date_max": "u15",
            "date_min": "u16",
            "swimming_pool": "u9",
            "animal_type": "u86",
            "animal_litter": "u75",
            "animal_offer_nature": "u77",
            "jobstudy": "u17",
            "jobduty": "u18",
            "jobtime": "u28",
            "jobexp": "u30",
            "jobfield": "u4",
            "jobcontract": "u84",
            "rooms_max": "u23",
            "rooms_min": "u24",
            "rooms": "u32",
            "square_max": "u26",
            "square_min": "u27",
            "cubic_capacity_min": "u12",
            "cubic_capacity": "u37",
            "clothing_type": "u87",
            "lease_type": "u88",
            "shoe_type": "u90",
            "zipcode": "u40",
            "baby_age": "u57",
            "shoe_size": "u76",
            "click_numero": "u59",
            "click_annonce_saved": "u61",
            "click_message": "u78",
            "click_achat": "u83",
            "click_resa": "u92"
        };
        u.extend = [function(a, b) {
            try {
                if (1) {
                    if (b.pagename === "listing") {
                        toSpread = b.search_filters;
                        b = Object.assign(b, toSpread);
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }];
        u.send = function(a, b) {
            if (u.ev[a] || u.ev.all !== undefined) {
                var c, d, e, f, g;
                u.data = {
                    "qsp_delim": ";",
                    "kvp_delim": "=",
                    "base_url": "",
                    "src": "9981794",
                    "type": "invmedia",
                    "cat": "lebon0",
                    "multicat": "",
                    "ord": "",
                    "cost": "",
                    "qty": 0,
                    "total_qty": 0,
                    "countertype": "standard",
                    "conversioncount": "single",
                    "order_id": "",
                    "order_subtotal": "",
                    "product_id": [],
                    "product_quantity": [],
                    "product_unit_price": []
                };
                for (c = 0; c < u.extend.length; c++) {
                    try {
                        d = u.extend[c](a, b);
                        if (d == false) return
                    } catch (e) {}
                };
                c = [];
                g = [];
                for (d in utag.loader.GV(u.map)) {
                    if (b[d] !== undefined && b[d] !== "") {
                        e = u.map[d].split(",");
                        for (f = 0; f < e.length; f++) {
                            if (/^(cat|multicat|type|src|cost|qty|countertype|conversioncount|ord|order_id|order_subtotal|product_id|product_quantity|product_unit_price)$/.test(e[f])) {
                                u.data[e[f]] = b[d];
                            } else {
                                u.data[e[f]] = b[d];
                                g.push(e[f] + u.data.kvp_delim + encodeURIComponent(b[d]))
                            }
                        }
                    }
                }
                u.data.order_id = u.data.order_id || u.data.ord || b._corder || "";
                u.data.order_subtotal = u.data.cost || u.data.order_subtotal || b._csubtotal || b._ctotal || "";
                if (u.data.product_id.length === 0 && b._cprod !== undefined) {
                    u.data.product_id = b._cprod.slice(0);
                }
                if ((u.data.qty && u.data.qty.length > 0) || (u.data.product_quantity.length === 0 && b._cquan !== undefined)) {
                    u.data.product_quantity = u.data.qty || b._cquan.slice(0);
                }
                if (u.data.product_unit_price.length === 0 && b._cprice !== undefined) {
                    u.data.product_unit_price = b._cprice.slice(0);
                }
                u.data.base_url = '//' + u.data.src + '.fls.doubleclick.net/activityi;src=' + u.data.src + ';type=' + u.data.type + ';';
                if (u.data.multicat === "") {
                    u.data.multicat_arr = [u.data.cat];
                } else {
                    u.data.multicat_arr = u.data.multicat.split(';');
                }
                if (u.data.order_id) {
                    if (u.data.conversioncount === "multi" && u.data.product_quantity.length > 0) {
                        for (f = 0; f < u.data.product_quantity.length; f++) {
                            u.data.total_qty += parseInt(u.data.product_quantity[f]);
                        }
                        u.data.qty = u.data.total_qty;
                    } else {
                        u.data.qty = 1;
                    }
                    var dc_fl_prd = [];
                    for (var i = 0; i < u.data.product_id.length; i++) {
                        var prod_num = i + 1;
                        dc_fl_prd.push("i" + prod_num + ":" + u.data.product_id[i] + "|p" + prod_num + ":" + u.data.product_unit_price[i] + "|q" + prod_num + ":" + u.data.product_quantity[i])
                    }
                    u.prd = dc_fl_prd.join('|');
                    if (u.prd) {
                        c.push("prd=" + u.prd);
                    }
                    c.push('qty=' + (u.data.qty));
                    c.push('cost=' + (u.data.order_subtotal));
                    if (g.length > 0) {
                        c.push(g.join(';'));
                    }
                    c.push('ord=' + (u.data.order_id));
                } else if (u.data.countertype === 'standard') {
                    if (g.length > 0) {
                        c.push(g.join(';'));
                    }
                    c.push('ord=' + (Math.random() * 10000000000000));
                } else if (u.data.countertype === 'unique') {
                    if (g.length > 0) {
                        c.push(g.join(';'));
                    }
                    c.push('ord=1');
                    c.push('num=' + (Math.random() * 10000000000000));
                } else {
                    if (g.length > 0) {
                        c.push(g.join(';'));
                    }
                    c.push('ord=' + (u.data.order_id ? u.data.order_id : window.utag.data['cp.utag_main_ses_id']));
                }
                for (f = 0; f < u.data.multicat_arr.length; f++) {
                    u.loader({
                        "type": "iframe",
                        "src": u.data.base_url + 'cat=' + u.data.multicat_arr[f] + ((c.length > 0) ? ';' + c.join(u.data.qsp_delim) : '') + '?',
                        "loc": "body",
                        "id": 'utag_255_iframe'
                    });
                }
            }
        };
        utag.o[loader].loader.LOAD(id);
    }('255', 'schibsted.leboncoin-responsive'));
} catch (error) {
    utag.DB(error);
}