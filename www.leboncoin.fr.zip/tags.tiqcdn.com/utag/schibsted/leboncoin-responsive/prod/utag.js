//tealium universal tag - utag.loader ut4.0.202311281603, Copyright 2023 Tealium.com Inc. All Rights Reserved.
var utag_condload = false;
window.__tealium_twc_switch = false;
try {
    (function() {
        "use strict";

        function getCookie(cname) {
            var name = cname + "=",
                ca = document.cookie.split(';'),
                i = 0,
                c;
            for (i = 0; i < ca.length; i++) {
                c = ca[i];
                while (c.charAt(0) === ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) === 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        }
        var env_cookie, sync_load, qs, env, account = "schibsted",
            profile = "leboncoin",
            a, b, tealium_domain = "//tags.tiqcdn.com",
            src;
        env_cookie = getCookie("utag_env_" + account + "_" + profile);
        sync_load = getCookie("utag_sync_load");
        qs = window.location.search || window.location.hash || "";
        env = qs.match(/(tealium_env=)(dev|qa|prod|clear)/);
        if (env === null && sync_load) {
            env_cookie = env_cookie.split("/");
            env_cookie = (env_cookie.length === 9) ? env_cookie[7] : env_cookie[6];
            env = ["", "", env_cookie];
        }
        if (((window.location.search && (window.location.search.indexOf("tealium_env=") > -1)) || sync_load || env) && !(window.utag_condload_env)) {
            if (env && env.length && env[2]) {
                if (env[2].indexOf("clear") > -1) {
                    document.cookie = "utag_env_" + account + "_" + profile + "=;path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT";
                    if (window.console) {
                        window.console.log("Custom Tealium environment CLEARED. Default environment for this page will be used.");
                    }
                    window.location.search = "";
                } else {
                    if (window.console) {
                        window.console.log("tealium environment = " + env[2]);
                    }
                    window.utag_condload_env = true;
                    window.utag_condload = true;
                    src = tealium_domain + "/utag/" + account + "/" + profile + "/" + env[2] + "/utag.js";
                    document.cookie = "utag_env_" + account + "_" + profile + "=" + src + ";path=/";
                    if (document.readyState && document.readyState === "loading") {
                        document.cookie = "utag_sync_load=true;path=/";
                        document.write("<scr" + "ipt type='text/javascript' src='" + src + "' id='utag_dynamic_load'> </scr" + "ipt>");
                    } else {
                        a = document;
                        b = a.createElement('script');
                        b.language = 'javascript';
                        b.type = 'text/javascript';
                        b.src = src;
                        a.getElementsByTagName('head')[0].appendChild(b);
                    }
                }
            }
        }
    }());
} catch (e) {
    console.log(e);
}
if (!utag_condload) {
    try {
        (function() {
            window.TEALIUM = window.TEALIUM || {};
            window.TEALIUM.CookieHandler = function() {
                var cookieFactory = {
                    "_lib": "Tealium Client Services",
                    "_author": "Kevin Thomas Faurholt",
                    "_version": "1.3",
                    "logs": {
                        "errors": []
                    },
                    "log": function(_2, _3, _4, _5) {
                        this.logs[_2].push(_3 + "::" + _4 + " : " + _5);
                    }
                };
                var add = function(_7, _8, _9) {
                    _7[_8] = _9;
                    _9.parent = _7;
                    return 1;
                };
                add(cookieFactory, "util", {
                    "version": "1.3",
                    "escape": function(_a) {
                        var _b = window.encodeURIComponent || window.escape;
                        return _b.apply(this, [_a]);
                    },
                    "unescape": function(_c) {
                        var _d = window.decodeURIComponent || window.unescape;
                        return _d.apply(this, [_c]);
                    },
                    "isEmpty": function(_e) {
                        return (!_e || 0 === _e.length || /^\s*$/.test(_e));
                    },
                    "toType": function(_f) {
                        return ({}).toString.call(_f).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
                    },
                    "toJSONString": function(obj) {
                        var _11 = this.toType,
                            _12 = [],
                            _13;
                        _13 = function(obj, _15) {
                            var _16, _17, _18, _19, _1a, _1b, _1c, _1d, _1e, _1f = [];
                            for (_18 in obj) {
                                if (obj.hasOwnProperty(_18)) {
                                    _19 = _11(obj);
                                    _1a = _11(obj[_18]);
                                    _1b = obj[_18];
                                    if (/(string|number)/.test(_1a)) {
                                        if (/string/.test(_1a)) {
                                            _1b = _1b.replace(/["]/g, function(a) {
                                                return "\\" + a;
                                            });
                                        }
                                        if (_11(obj) === "array") {
                                            _1c = {
                                                "glue": ",",
                                                "value": [_1a === "string" ? "\"" + _1b + "\"" : _1b]
                                            };
                                        } else {
                                            _1c = {
                                                "glue": ":",
                                                "key": "\"" + _18 + "\"",
                                                "value": _1a === "string" ? "\"" + _1b + "\"" : _1b
                                            };
                                        }
                                        if (_15) {
                                            _15.push(_1c);
                                        } else {
                                            _1f.push(_1c);
                                        }
                                    } else {
                                        if (/(object|array)/.test(_1a)) {
                                            _16 = _18;
                                            _17 = _11(_16);
                                            _1c = _13(obj[_18], []);
                                            if (_1c.length) {
                                                if (_19 === "array" && /^[0-9]+$/.test(_18)) {
                                                    _16 = "";
                                                } else {
                                                    if (_17 === "string") {
                                                        _16 = "\"" + _16 + "\":";
                                                    } else {
                                                        _16 += ":";
                                                    }
                                                }
                                                if (_1a === "array") {
                                                    _1c = ("[" + _1c + "]");
                                                } else {
                                                    if (_1a === "object") {
                                                        _1c = ("{" + _1c + "}");
                                                    }
                                                }
                                                _1c = (_16 + _1c);
                                                if (typeof _15 !== "undefined") {
                                                    _15.push(_1c);
                                                } else {
                                                    _1f.push(_1c);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            _1e = (_15 && _15.length) ? _15 : _1f;
                            _1d = (_15 && _15.length) ? [] : _12;
                            for (var i = 0, _22 = _1e.length; i < _22; i++) {
                                _1c = _1e[i];
                                if (_1c.key) {
                                    _1d.push(_1c.key + _1c.glue + _1c.value);
                                } else {
                                    if (_1c.glue) {
                                        _1d.push(_1c.value.join(_1c.glue));
                                    } else {
                                        _1d.push(_1c);
                                    }
                                }
                            }
                            return _1d.join(",");
                        };
                        return "{" + _13(obj) + "}";
                    },
                    "regex": {
                        "sanitize": function(str) {
                            return str.replace(/(\(|\)|\/|\\|\[|\]|\{|\}\.|\+|\*|\$)/g, function(a) {
                                return "\\" + a;
                            });
                        }
                    },
                    "Base64": {
                        "_keyStr": "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                        "encode": function(_25) {
                            var _26 = "",
                                _27, _28, _29, _2a, _2b, _2c, _2d, i = 0;
                            _25 = this._utf8_encode(_25);
                            while (i < _25.length) {
                                _27 = _25.charCodeAt(i++);
                                _28 = _25.charCodeAt(i++);
                                _29 = _25.charCodeAt(i++);
                                _2a = _27 >> 2;
                                _2b = ((_27 & 3) << 4) | (_28 >> 4);
                                _2c = ((_28 & 15) << 2) | (_29 >> 6);
                                _2d = _29 & 63;
                                if (isNaN(_28)) {
                                    _2c = _2d = 64;
                                } else {
                                    if (isNaN(_29)) {
                                        _2d = 64;
                                    }
                                }
                                _26 = _26 + this._keyStr.charAt(_2a) + this._keyStr.charAt(_2b) + this._keyStr.charAt(_2c) + this._keyStr.charAt(_2d);
                            }
                            return _26;
                        },
                        "decode": function(_2f) {
                            var _30 = "",
                                _31 = String.fromCharCode,
                                _32, _33, _34, _35, _36, _37, _38, i = 0;
                            _2f = _2f.replace(/[^A-Za-z0-9\+\/\=]/g, "");
                            while (i < _2f.length) {
                                _35 = this._keyStr.indexOf(_2f.charAt(i++));
                                _36 = this._keyStr.indexOf(_2f.charAt(i++));
                                _37 = this._keyStr.indexOf(_2f.charAt(i++));
                                _38 = this._keyStr.indexOf(_2f.charAt(i++));
                                _32 = (_35 << 2) | (_36 >> 4);
                                _33 = ((_36 & 15) << 4) | (_37 >> 2);
                                _34 = ((_37 & 3) << 6) | _38;
                                _30 = _30 + _31(_32);
                                if (_37 !== 64) {
                                    _30 = _30 + _31(_33);
                                }
                                if (_38 !== 64) {
                                    _30 = _30 + _31(_34);
                                }
                            }
                            return this._utf8_decode(_30);
                        },
                        "_utf8_encode": function(_3a) {
                            var _3b = "",
                                _3c = String.fromCharCode,
                                _3d, _3e, i;
                            _3a = _3a.replace(/\r\n/g, "\n");
                            for (i = 0, _3e = _3a.length; i < _3e; i++) {
                                _3d = _3a.charCodeAt(i);
                                if (_3d < 128) {
                                    _3b += _3c(_3d);
                                } else {
                                    if ((_3d > 127) && (_3d < 2048)) {
                                        _3b += _3c((_3d >> 6) | 192);
                                        _3b += _3c((_3d & 63) | 128);
                                    } else {
                                        _3b += _3c((_3d >> 12) | 224);
                                        _3b += _3c(((_3d >> 6) & 63) | 128);
                                        _3b += _3c((_3d & 63) | 128);
                                    }
                                }
                            }
                            return _3b;
                        },
                        "_utf8_decode": function(_40) {
                            var _41 = "",
                                _42, _43, _44, i = 0;
                            while (i < _40.length) {
                                _42 = _40.charCodeAt(i);
                                if (_42 < 128) {
                                    _41 += String.fromCharCode(_42);
                                    i++;
                                } else {
                                    if ((_42 > 191) && (_42 < 224)) {
                                        _43 = _40.charCodeAt(i + 1);
                                        _41 += String.fromCharCode(((_42 & 31) << 6) | (_43 & 63));
                                        i += 2;
                                    } else {
                                        _43 = _40.charCodeAt(i + 1);
                                        _44 = _40.charCodeAt(i + 2);
                                        _41 += String.fromCharCode(((_42 & 15) << 12) | ((_43 & 63) << 6) | (_44 & 63));
                                        i += 3;
                                    }
                                }
                            }
                            return _41;
                        }
                    }
                });
                add(cookieFactory, "cookie", {
                    "version": "1.2",
                    "domain": function() {
                        var _46 = document.domain,
                            _47 = _46.lastIndexOf(".");
                        if (/\.[0-9]{1,3}$/.test(_46)) {
                            return "";
                        }
                        if (_47 < 0) {
                            return "";
                        }
                        _47 = _46.lastIndexOf(".", _47 - 1);
                        if (-1 < _47 && _46.match(/.*[.](co|com|net|org|ltd|gov)[.][A-Za-z]*$/i)) {
                            _47 = _46.lastIndexOf(".", _47 - 1);
                        }
                        if (0 < _47) {
                            _46 = _46.substring(_47);
                        }
                        return _46.length > 5 ? _46 : "";
                    },
                    "get": function(_48) {
                        var _49 = _48 + "=",
                            _4a = [],
                            _4b, _4c = "",
                            i;
                        _4a = document.cookie.split(";");
                        for (i = 0, _4b = _4a.length; i < _4b; i++) {
                            _4c = _4a[i].replace(/^(\s|\xa0)*/, "");
                            if (_4c.indexOf(_49) === 0) {
                                return this.parent.util.unescape(_4c.substring(_49.length, _4c.length));
                                break;
                            }
                        }
                        return null;
                    },
                    "set": function(_4e, _4f, _50, _51, _52) {
                        var _53 = "",
                            _54 = "",
                            _55 = new Date(),
                            _56 = "",
                            _57 = "";
                        if (typeof _52 === "undefined") {
                            _52 = true;
                        }
                        if (_52) {
                            _4f = this.parent.util.escape(_4f);
                        }
                        if (_50) {
                            if (_50 === -1) {
                                _53 = ";expires=Thu, 01-Jan-70 00:00:01 GMT";
                            } else {
                                _55.setTime(_55.getTime() + (_50 * 24 * 60 * 60 * 1000));
                                _53 = ";expires=" + _55.toGMTString();
                            }
                        }
                        if (_51) {
                            _56 = ";path=" + _51;
                        } else {
                            _56 = ";path=/";
                        }
                        _57 = this.domain();
                        if (_57) {
                            _54 = ";domain=" + _57;
                        }
                        document.cookie = (_4e + "=" + _4f + _53 + _56 + _54);
                        return 1;
                    },
                    "remove": function(_58) {
                        return this.set(_58, "", -1, "", false);
                    }
                });
                add(cookieFactory, "subcookie", {
                    "version": "1.3",
                    "subcookieseparator": "$$/$$",
                    "keyvalueseparator": "$$:$$",
                    "define": function(_59) {
                        var _5a = 0;
                        if (_59.subcookieseparator) {
                            this.subcookieseparator = _59.subcookieseparator;
                            _5a = 1;
                        }
                        if (_59.keyvalueseparator) {
                            this.keyvalueseparator = _59.keyvalueseparator;
                            _5a = 1;
                        }
                        return _5a;
                    },
                    "get": function(_5b, _5c) {
                        var _5d = "",
                            _5e = "",
                            _5f = {},
                            _60 = [],
                            _61 = [],
                            _62 = 0,
                            i = 0;
                        _5d = this.parent.cookie.get(_5b) || "";
                        if (_5d.length) {
                            _5e = this.parent.util.regex.sanitize(this.keyvalueseparator);
                            if (new RegExp("^.+" + _5e + ".+", "g").test(_5d) === false) {
                                this.parent.log("errors", "subcookie", "get", "kv-separator not found");
                                return null;
                            }
                            _60 = _5d.split(this.subcookieseparator);
                            for (i = 0, _62 = _60.length; i < _62; i++) {
                                _61 = _60[i].split(this.keyvalueseparator);
                                _5f[_61[0]] = _61[1];
                            }
                            if (_5c) {
                                return _5f[_5c] || null;
                            }
                        }
                        return _5f;
                    },
                    "set": function(_64, _65, _66, _67, _68) {
                        var _69 = this.get(_64),
                            _6a, _6b = [];
                        if (this.parent.util.toType(_65) !== "object") {
                            this.parent.log("errors", "subcookie", "set", "argument 2 not json object");
                            return 0;
                        }
                        if (_69) {
                            for (_6a in _69) {
                                if (!(_65.hasOwnProperty(_6a))) {
                                    _65[_6a] = _69[_6a];
                                }
                            }
                        }
                        for (_6a in _65) {
                            if (_65.hasOwnProperty(_6a)) {
                                if (this.parent.util.toType(_65[_6a]) === "object") {
                                    _65[_6a] = this.parent.util.toJSONString(_65[_6a]);
                                }
                                _6b.push(_6a + this.keyvalueseparator + _65[_6a]);
                            }
                        }
                        _6b = _6b.join(this.subcookieseparator);
                        return this.parent.cookie.set(_64, _6b, _66, _67, _68);
                    },
                    "remove": function(_6c, _6d, _6e, _6f) {
                        var _70 = "",
                            _71 = [],
                            _72 = [],
                            _73 = [],
                            i;
                        _70 = this.parent.cookie.get(_6c);
                        if (!_70) {
                            return 0;
                        }
                        _71 = _70.split(this.subcookieseparator);
                        for (i = 0; i < _71.length; i++) {
                            _72 = _71[i].split(this.keyvalueseparator);
                            if (_72[0] !== _6d) {
                                _73.push(_72[0] + this.keyvalueseparator + _72[1]);
                            }
                        }
                        _73 = _73.join(this.subcookieseparator);
                        return this.parent.cookie.set(_6c, _73, _6e, _6f, false);
                    }
                });
                Object.hasOwnProperty = (function() {
                    if (Object.prototype.hasOwnProperty) {
                        return function(_75, _76) {
                            return Object.prototype.hasOwnProperty.call(_75, _76);
                        };
                    }
                    var _77 = {},
                        _78 = "__proto__";
                    if (_77[_78]) {
                        return function(_79, _7a) {
                            var _7b;
                            var _7c = _79[_78];
                            _79[_78] = null;
                            _7b = _79[_7a] ? true : false;
                            _79[_78] = _7c;
                            return _7b;
                        };
                    }
                    return function(_7d, _7e) {
                        return _7d.constructor && _7d.constructor.prototype[_7e] !== _7d[_7e];
                    };
                })();
                return cookieFactory;
            };
        })();
    } catch (e) {
        console.log(e);
    }
}
if (!utag_condload) {
    try {
        try {
            window.Xtconf = {
                xt1: '.mudah.my',
                xtLogDom: '.ati-host.net/hit.xiti',
                xtfirst: false,
                xt2: '0',
                xt3: 3650,
                xt4sec: '20',
                xt4rss: '20',
                xt4epr: '20',
                xt4erec: '20',
                xt4adi: '20',
                xt4adc: '20',
                xt4al: '20',
                xtsds: 'https://logws1344',
                xtsd: 'http://logw344',
                xtsts: 0,
                xtsite: function(x) {
                    return x + xt8
                },
                xtscript: '',
                xtpreview: false,
                xtnocookies: false,
                xtcode: '',
                xt46: '1',
                xt50: '1',
                xt48: '',
                xt54: false,
                xt58: false,
                xtdocl: false,
                xttredir: 500,
                xtkwv: 'xtmc',
                xtkwp: 'xtnp',
                idcExp: 397,
                idcType: 'fixed'
            };
            window.Xtcore = function() {
                function B(b) {
                    return "undefined" !== typeof b
                }

                function C(b) {
                    var a = typeof b;
                    if ("object" !== a || null === b) return "string" === a && (b = encodeURIComponent('"' + b + '"')), String(b);
                    var e, c, d = [],
                        g = b && b.constructor == Array;
                    for (e in b) c = b[e], a = typeof c, b.hasOwnProperty(e) && "function" !== a && ("string" === a ? c = encodeURIComponent('"' + c.replace(/[^\\]"/g, '\\"') + '"') : "object" === a && null !== c && (c = C(c)), d.push((g ? "" : encodeURIComponent('"' + e + '":')) + String(c)));
                    return (g ? "[" : "{") + String(d) + (g ? "]" : "}")
                }

                function na(b) {
                    return b.replace(/%3C/g, "<").replace(/%3E/g, ">").replace(/[<>]/g, "")
                }

                function n(b, a, e, c, d) {
                    a = 0 === d ? a : encodeURIComponent(a);
                    oa || (j.cookie = b + "=" + a + ";expires=" + e.toGMTString() + ";path=/" + c)
                }

                function m(b, f, e) {
                    var c;
                    try {
                        c = Q.location.href
                    } catch (d) {
                        c = a.location.href
                    }
                    f = null === f || !B(f) ? na(c.toLowerCase().replace(/%3d/g, "=")) : f;
                    if (0 < f.indexOf(b + "=")) {
                        f = f.substr(1);
                        b = f.substr(f.indexOf(b + "="));
                        if (2 != e) {
                            if (1 != e) try {
                                b = decodeURIComponent(b)
                            } catch (g) {
                                b = unescape(b)
                            }
                            if (f = b.match(/(\[[^\]]*\])/g)) {
                                c = "";
                                for (var l = 0, k = f.length; l < k; l++) c = f[l].substring(1, f[l].length - 1), b = b.replace(c, encodeURIComponent(c))
                            }
                        }
                        f = b.indexOf("#");
                        c = b.search(/&.[^&]+=/gi);
                        c = -1 == c ? -1 == f ? b.length : f : 0 < f && f < c ? f : c;
                        return 1 == e ? decodeURIComponent(b.substring(b.indexOf("=") + 1, c)) : 2 == e ? b.substring(b.indexOf("=") + 1, c) : b.substring(b.indexOf("=") + 1, c).replace("&", "%26")
                    }
                    return null
                }

                function D(b, a, e, c) {
                    if ((0 === pa || 3 == pa || "C" != b) && "P" != b) Ya && "0" == Y && "F" == b ? (u = u.replace("&p=" + m("p", u, 2), ""), u = u.replace("&s2=" + m("s2", u), ""), AT_hit.isPreviewOrPrerendering() || AT_hit.sendTag(b, null, null, a), Ya = !1) : AT_hit.sendTag(b, a);
                    null !== e && (B(e) && "M" != b) && ("" === c || null === c ? j.location = e : window.open(e, "xfen", "").focus())
                }

                function qa(b) {
                    b -= 100 * Math.floor(b / 100);
                    return 10 > b ? "0" + b : b
                }

                function R(b) {
                    return Math.floor(Math.random() * Math.pow(10, b))
                }
                var ra = this;
                ra.sentHits = [];
                var h = Xtconf.xt1,
                    Za = Xtconf.xtscript,
                    $a = window.xtLogDom = Xtconf.xtLogDom,
                    wb = Xtconf.xtpreview,
                    ab = Xtconf.xtfirst,
                    oa = Xtconf.xtnocookies,
                    bb = Xtconf.xtcode,
                    Y = Xtconf.xt46,
                    sa = Xtconf.xt50,
                    cb = Xtconf.xt48,
                    xb = Xtconf.xt54,
                    yb = Xtconf.xt58,
                    zb = Xtconf.xtdocl,
                    Ab = Xtconf.xt2,
                    Bb = Xtconf.xt3;
                window.xttredir = Xtconf.xttredir;
                var db = Xtconf.xtkwv,
                    eb = Xtconf.xtkwp,
                    ta = [],
                    y = [];
                y.sec = Xtconf.xt4sec;
                y.rss = Xtconf.xt4rss;
                y.epr = Xtconf.xt4epr;
                y.erec = Xtconf.xt4erec;
                y.adi = Xtconf.xt4adi;
                y.adc = Xtconf.xt4adc;
                y.al = Xtconf.xt4al;
                y.es = Xtconf.xt4epr;
                y.ad = Xtconf.xt4adi;
                var ua = [],
                    Ya = !0,
                    K = !1,
                    va = null,
                    a = window.xw = window,
                    j = window.xd = document,
                    s = navigator,
                    Cb = window.xtv = a.xtczv ? "4.6.2-" + a.xtczv : "4.6.2",
                    h = window.xt1 = a.xtdmc ? ";domain=" + a.xtdmc : "" !== h ? ";domain=" + h : "",
                    Q = a.xtnv ? a.xtnv : j,
                    Db = window.xt7 = a.xtsdi ? a.xtsdi : a.xtsd ? a.xtsd + $a : ("https:" === j.location.protocol ? Xtconf.xtsds : Xtconf.xtsd) + $a,
                    Z = a.xtsts ? a.xtsts : Xtconf.xtsts,
                    $ = "";
                if (xb) {
                    var wa = "";
                    try {
                        wa = Q.location.href
                    } catch (ac) {
                        wa = a.location.href
                    }
                    var Eb = /#.*/,
                        xa = null;
                    try {
                        xa = wa.match(Eb)[0]
                    } catch (bc) {
                        xa = null
                    }
                    $ = ($ = xa) ? "&sta=" + encodeURIComponent(na($)) : ""
                }
                "undefined" !== typeof window.ATTvTracking && window.ATTvTracking.init(a.Xtconf);
                var fb = a.xtcustom ? C(a.xtcustom) : "",
                    E = window.xt8 = a.xtsite ? a.xtsite : 0,
                    Fb = window.xt9 = a.xtn2 ? "&s2=" + a.xtn2 : "",
                    Gb = window.xt8b = (0 === E ? "" : "s=" + E) + (0 === Z ? "" : 0 === E ? "sts=" + Z : "&sts=" + Z),
                    aa = window.xtp = a.xtpage ? a.xtpage : "",
                    gb = a.xto_force ? a.xto_force.toLowerCase() : null,
                    F = "redirect" === E,
                    Hb = a.xtdi ? "&di=" + a.xtdi : "",
                    Ib = a.xtidp ? "&idpays=" + a.xtidp : "",
                    Jb = a.xtidprov ? "&idprov=" + a.xtidprov : "",
                    r = a.xtparam ? a.xtparam : "",
                    Y = a.xtnopage && "1" === a.xtnopage ? "0" : Y,
                    sa = a.xtergo && "0" === a.xtergo ? "0" : sa,
                    pa = a.scriptOnClickZone && "1" === sa ? a.scriptOnClickZone : 0,
                    Kb = "" !== bb ? "&code=" + bb : "",
                    ya = [],
                    ba = [],
                    S = [],
                    ca = [],
                    za = [],
                    I = [];
                window.xt44 = a.xtprod_load ? "&pdtl=" + a.xtprod_load : "";
                a.addEventListener ? a.addEventListener("unload", function() {}, !1) : a.attachEvent && a.attachEvent("onunload", function() {});
                j.addEventListener ? (j.addEventListener("keydown", function() {
                    K = !0
                }, !1), j.addEventListener("keyup", function() {
                    K = !1
                }, !1)) : j.attachEvent && (j.attachEvent("onkeydown", function() {
                    K = !0
                }), j.attachEvent("onkeyup", function() {
                    K = !1
                }));
                var Lb = a.roimt && 0 > r.indexOf("&roimt", 0) ? "&roimt=" + a.roimt : "",
                    Mb = 0 > r.indexOf("&mc=", 0) ? a.xtmc ? "&mc=" + a.xtmc : m(db) ? "&mc=" + m(db) : m("xtmc") ? "&mc=" + m("xtmc") : "" : "",
                    Nb = m("xtcr") ? "&mcrg=" + m("xtcr") : "",
                    Ob = a.xtac && 0 > r.indexOf("&ac=", 0) ? "&ac=" + a.xtac : "",
                    Pb = a.xtat && 0 > r.indexOf("&at=", 0) ? "&at=" + a.xtat : "",
                    hb = a.xtan && 0 > r.indexOf("&an=", 0) ? "&an=" + a.xtan : "",
                    Qb = 0 > r.indexOf("&np=", 0) ? a.xtnp ? "&np=" + a.xtnp : m(eb) ? "&np=" + m(eb) : m("xtnp") ? "&np=" + m("xtnp") : "" : "",
                    Rb = a.xtprm && 0 > r.indexOf("&x", 0) ? a.xtprm : "",
                    r = r + (Lb + Mb + Nb + Ob + ("" !== hb ? hb : Pb) + Qb + Rb + $),
                    Aa = "";
                try {
                    Aa = top.document.referrer
                } catch (cc) {
                    try {
                        Aa = Q.referrer
                    } catch (dc) {}
                }
                var da = screen,
                    G = window.xt21 = new Date,
                    ib = G.getTime() / 36E5,
                    p = window.xtf1 = function(b, a) {
                        if (oa) return null;
                        a = null !== a && B(a) ? a : "0";
                        var e = RegExp("(?:^| )" + b + "=([^;]+)").exec(j.cookie) || null;
                        if (e && (e = na(e[1]), "1" != a)) try {
                            e = decodeURIComponent(e)
                        } catch (c) {
                            e = unescape(e)
                        }
                        return e
                    };
                window.xt_addchain = function(b, a) {
                    var e = a ? a : "abmv",
                        c = !ta[e] ? 0 : ta[e];
                    c++;
                    r += "&" + e + "" + c + "=" + b;
                    ta[e] = c
                };
                "function" === typeof xt_adch && xt_adch();
                window.wck = n;
                window.xtf3 = m;
                window.xt_mvt = function(b, a, e, c, d) {
                    if (c)
                        for (var g = 1; g < c.length + 1; g++) e += "&" + (d ? d : "abmv") + g + "=" + c[g - 1];
                    D("", "&p=" + b + "&s2=" + a + "&abmvc=" + e + "&type=mvt")
                };
                window.xt_med = function(b, a, e, c, d, g, l, k) {
                    c = "F" == b && (null === c || !B(c)) ? l ? "&stc=" + C(l) : "" : "M" == b ? "&a=" + c + "&m1=" + d + "&m2=" + g + "&m3=" + l + "&m4=" + k : "&clic=" + c + (l ? "&stc=" + C(l) : "");
                    D(b, "&s2=" + a + "&p=" + e + c, d, g)
                };
                if (ab = window.xtfirst = -1 != s.userAgent.indexOf("Safari") && 0 > s.userAgent.indexOf("Chrome") || -1 != s.userAgent.indexOf("iPhone") || -1 != s.userAgent.indexOf("iPod") || -1 != s.userAgent.indexOf("iPad") || ab || a.xtidc || oa) {
                    var ea = a.xtidc,
                        Ba = p("xtidc"),
                        L = "",
                        L = ea ? ea : Ba ? Ba : (new Date).getTime() +
                        "" + R(7);
                    if ("relative" == Xtconf.idcType || ea || !Ba && !ea) {
                        var Ca = new Date;
                        Ca.setTime(Ca.getTime() + 864E5 * Xtconf.idcExp);
                        n("xtidc", L, Ca, h, 1)
                    }
                    var jb = p("xtidc"),
                        L = L + (!a.xtidc && (null === jb || jb != L) ? "-NO" : "")
                }
                window.xt_ad = function(b, f, e, c) {
                    D("AT", "&atc=" + b + "&type=AT&patc=" + a.xtpage + "&s2atc=" + a.xtn2 + (c ? "&stc=" + C(c) : ""), f, e)
                };
                window.xt_adi = function(b, a, e) {
                    D("AT", "&ati=" + b + "&type=AT", a, e)
                };
                window.xt_adc = function(b, f, e, c, d) {
                    D("AT", "&atc=" + f + "&type=AT&patc=" + a.xtpage + "&s2atc=" + a.xtn2 + (d ? "&stc=" + C(d) : ""));
                    return AT_click.do_navig(b, e, c ? "_blank" : null, !0)
                };
                window.xt_click = function(b, a, e, c, d, g, l, k) {
                    d = ("F" == a && (null === d || !B(d)) ? "" : "&clic=" + d) + (k ? "&stc=" + C(k) : "");
                    D(a, "&s2=" + e + "&p=" + c + d);
                    return AT_click.do_navig(b, g, l ? "_blank" : null, !0)
                };
                window.xt_form = function(b, a, e, c, d, g, l) {
                    d = ("F" == a && (null === d || !B(d)) ? "" : "&clic=" + d) + (l ? "&stc=" + C(l) : "");
                    D(a, "&s2=" + e + "&p=" + c + d);
                    return AT_click.do_submit(b, !0, g)
                };
                window.xt_rm = function(b, f, e, c, d, g, l, k, q, m, n, h, j, p) {
                    D(b, "&p=" + e + "&s2=" + f + "&type=" + b + "&a=" + c + "&m5=" + n + "&m6=" + h + (null !== d && "0" != d ? "&" + d : "") +
                        (null !== l && "pause" != c && "stop" != c ? "&m1=" + l + "&" + k + "&m3=" + q + "&m4=" + m + "&m7=" + j + "&m8=" + p + "&prich=" + a.xtpage + "&s2rich=" + a.xtn2 : "") + (null !== g && "0" != g && null !== l ? "&rfsh=" + g : ""));
                    d = new Date;
                    if (null !== g && "0" != g && ("play" == c || "play&buf=1" == c || "refresh" == c)) {
                        I[b] && 18E5 < d.getTime() - I[b] && (S[b] = 0);
                        if (("play" == c || "play&buf=1" == c) && !S[b]) S[b] = d.getTime() / 1E3, ca[b] = parseInt(l), c = Math.floor(g), c = 1500 < c ? 1500 : 5 > c ? 5 : c, ya[b] = c, ba[b] = c, I[b] = !1;
                        else if ("refresh" == c && ("live" == h || !ca[b] || 300 < ca[b] && 2 > 100 * ya[b] / ca[b])) c = I[b] ? za[b] : d.getTime() / 1E3 - S[b], 5 > 100 * ba[b] / (c + 30) && (ba[b] = 5 * ((c + 30) / 100)), I[b] && (I[b] = !1, S[b] = d.getTime() / 1E3 - za[b]), za[b] = c;
                        ua[b] = a.setTimeout("xt_rm('" + b + "','" + f + "','" + e + "','refresh','0','" + g + "',null,'" + k + "','" + q + "','" + m + "','" + n + "','" + h + "')", 1E3 * ba[b])
                    } else if (("pause" == c || "stop" == c) && null !== ua) a.clearTimeout(ua[b]), "stop" == c ? ya[b] = 0 : I[b] = d.getTime()
                };
                var Da = window.xtidpg = qa(G.getHours()) + "" + qa(G.getMinutes()) + "" + qa(G.getSeconds()) + "" + R(7),
                    t = 0,
                    kb = 0;
                window.xt16 = "";
                window.xt_addProduct = function(b, f, e, c, d, g) {
                    t++;
                    a.xt16 += "&pdt" + t + "=";
                    a.xt16 += b ? b + "::" : "";
                    a.xt16 += f ? f : "";
                    a.xt16 += e ? "&qte" + t + "=" + e : "";
                    a.xt16 += c ? "&mt" + t + "=" + c : "";
                    a.xt16 += d ? "&dsc" + t + "=" + d : "";
                    a.xt16 += g ? "&pcode" + t + "=" + g : ""
                };
                window.xt_rd = R;
                window.xt_addProduct_v2 = function(b, f, e, c, d, g, l, k, q) {
                    t++;
                    a.xt16 += "&pdt" + t + "=";
                    a.xt16 += b ? b + "::" : "";
                    a.xt16 += f ? f : "";
                    a.xt16 += e ? "&qte" + t + "=" + e : "";
                    a.xt16 += c ? "&mt" + t + "=" + c : "";
                    a.xt16 += d ? "&mtht" + t + "=" + d : "";
                    a.xt16 += g ? "&dsc" + t + "=" + g : "";
                    a.xt16 += l ? "&dscht" + t + "=" + l : "";
                    a.xt16 += q ? "&roimt" + t + "=" + q : "";
                    a.xt16 += k ? "&pcode" + t +
                        "=" + k : ""
                };
                window.xt_addProduct_load = function(b, f, e) {
                    f && (kb++, a.xt44 += 1 == kb ? "&pdtl=" : "|", a.xt44 += b ? b + "::" : "", a.xt44 += f, a.xt44 += e ? ";" + e : "")
                };
                "function" == typeof xt_cart ? xt_cart() : a.xt16 = "";
                window.xt_ParseUrl = function(b, a, e) {
                    AT_hit.sendTag(e ? "F" : "old", a)
                };
                window.xt_ParseUrl3 = function(b, a, e, c, d) {
                    AT_hit.sendTag("&ati=" == d ? "AT" : "PDT", a, null, "&type=" + ("&ati=" == d ? "AT" : "PDT"))
                };
                window.AT_click = {
                    id: 0,
                    objs: [],
                    elem: function(b, a, e, c, d, g, l, k) {
                        var q = {};
                        q.urlDest = d;
                        q.type = b;
                        q.n2 = a;
                        q.label = e;
                        q.typeClick = c;
                        q.target = g;
                        q.submit = !1 !== d;
                        q.redir = !B(l) ? !0 : l;
                        q.xtcust = B(k) ? "&stc=" + C(k) : "";
                        return q
                    },
                    addListener: function(b, a, e) {
                        window.addEventListener ? b.addEventListener(a, e, !1) : window.attachEvent && b.attachEvent("on" + a, e)
                    },
                    tag: function(b, a, e, c, d, g, l, k, q) {
                        if (b && "function" == typeof b.setAttribute) this.addElem(b, a, e, c, d, g, l, k, q);
                        else if ("object" == typeof b)
                            for (var m in b) b.hasOwnProperty(m) && "function" == typeof b[m].setAttribute && this.addElem(b[m], a, e, c, d, g, l, k, q)
                    },
                    addElem: function(a, f, e, c, d, g, l, k, m) {
                        this.id++;
                        a.setAttribute("data-xtclickid", this.id);
                        this.objs[this.id] = this.elem(f, e, c, d, g, l, k, m);
                        "FORM" != a.nodeName ? this.addListener(a, "click", this.on_click_submit) : this.addListener(a, "submit", this.on_click_submit)
                    },
                    on_click_submit: function(a) {
                        try {
                            var f = a.target || a.srcElement,
                                e = f.getAttribute("data-xtclickid"),
                                c = {},
                                d = "",
                                g = a.defaultPrevented,
                                l = window.AT_click;
                            if (!e)
                                for (var k = f.parentNode; k;) {
                                    if (k.getAttribute("data-xtclickid")) {
                                        e = k.getAttribute("data-xtclickid");
                                        break
                                    }
                                    k = k.parentNode
                                }
                            e && (c = l.objs[e], "AT" != c.type ? d += "&p=" + c.label + ("C" == c.type ? "&clic=" + c.typeClick : "") : "AT" == c.type && (d += "&type=AT&atc=" + c.label), d += c.xtcust, D(c.type, "&s2=" + c.n2 + d), !g && c.redir && (a.preventDefault(), "FORM" != f.nodeName ? l.do_navig(f, c.urlDest, c.target) : l.do_submit(f, null, c.submit)))
                        } catch (m) {}
                    },
                    do_navig: function(b, f, e, c) {
                        var d = null;
                        if ("A" != b.nodeName)
                            for (var g = b.parentNode; g;) {
                                if ("A" == g.nodeName) {
                                    d = g;
                                    break
                                }
                                g = g.parentNode
                            } else d = b;
                        if (d) {
                            if (d.target = e || b.target || "_self", d.href = f || b.href || d.href, !c || c && !K)
                                if (b = d.href.split('"').join('\\"'), 0 > d.href.indexOf("mailto:"))
                                    if ("_self" == d.target.toLowerCase()) {
                                        if (setTimeout('self.location.href="' + b + '"', a.xttredir), c) return !1
                                    } else if ("_top" == d.target.toLowerCase()) {
                                if (setTimeout('top.location.href="' + b + '"', a.xttredir), c) return !1
                            } else if ("_parent" == d.target.toLowerCase()) {
                                if (setTimeout('parent.location.href="' + b + '"', a.xttredir), c) return !1
                            } else return !0;
                            else if (setTimeout('AT_click.mail_to("' + b + '");', a.xttredir), c) return !1
                        } else if (f || b.href)
                            if (f = f ? f : b.href, 0 > f.indexOf("mailto:"))
                                if ("_blank" == e) setTimeout('(xw.open("' + f.split('"').join('\\"') +
                                    '","_blank")).focus();', 1);
                                else {
                                    if (setTimeout('self.location.href="' + f.split('"').join('\\"') + '"', a.xttredir), c) return !1
                                }
                        else if (setTimeout('AT_click.mail_to("' + f.split('"').join('\\"') + '");', a.xttredir), c) return !1;
                        if (c) return K = !1, !0
                    },
                    do_submit: function(a, f, e) {
                        if (e && (setTimeout(function() {
                                a.submit()
                            }, 500), f && e)) return !1
                    },
                    mail_to: function(a) {
                        window.location = a
                    }
                };
                window.AT_hit = {
                    first: !0,
                    referrer: ("acc_dir" == m("xtref") ? "" : null !== m("xtref") ? m("xtref") : "acc_dir" == p("xtref") ? "" : p("xtref") || Aa.replace(/[<>]/g, "") || "").replace(/[<>]/g, "").substring(0, 1600),
                    parse: function(a, f, e, c) {
                        var d = [""];
                        if (1600 >= f.length) d[0] = f;
                        else {
                            a = AT_hit.first && "F" == a ? Da : Da.substring(0, 6) + R(8);
                            var g = "",
                                l = "",
                                k, q = {};
                            k = [];
                            var h = 0;
                            0 <= f.indexOf("&ref=") && (g = f.substring(f.indexOf("&ref=")), f = f.replace(g, ""));
                            if (c)
                                for (var n in c)
                                    if (c.hasOwnProperty(n) && 0 <= f.indexOf("&" + n + "=") && 1600 < (l = m(n, f, 2)).length) f = f.replace("&" + n + "=" + l, ""), k = RegExp("[" + c[n] + "]", "gi"), q[n] = l.replace(/&/g, "%26").split(k);
                            k = RegExp("[" + e + "]", "gi");
                            k = f.split(k);
                            for (var j in k) k.hasOwnProperty(j) && (1600 >= d[h].length + k[j].length + 1 ? d[h] += "" !== k[j] ? "&" + k[j] : "" : (d.push(""), h++, d[h] = 1600 > k[j].length ? d[h] + ("" !== k[j] ? "&" + k[j] : "") : d[h] + ("&mherr=1&" + k[j].substring(0, 1600))));
                            for (var p in q)
                                if (q.hasOwnProperty(p)) {
                                    f = "&" + p + "=";
                                    e = !1;
                                    n = q[p].length;
                                    for (j = 0; j < n; j++) 1600 >= d[h].length + q[p][j].length + 1 ? (e || (d[h] += f, e = !0), d[h] += "" !== q[p][j] ? q[p][j] + ("stc" === p && n - 1 === j ? "" : c[p]) : "") : (d.push(f), e = !0, h++, d[h] = 1600 > q[p][j].length ? d[h] + ("" !== q[p][j] ? q[p][j] + ("stc" === p && n - 1 === j ? "" : c[p]) : "") : d[h] + ("mherr=1" + c[p]))
                                }
                            g && (1600 >= d[h].length + g.length || (d.push(""), h++), d[h] += g);
                            for (c = 0; c < d.length; c++) d[c] = "&mh=" + (c + 1) + "-" + d.length + "-" + a + d[c]
                        }
                        return d
                    },
                    sendTag: function(b, f, e, c) {
                        "undefined" != typeof window.ATTvTracking && window.ATTvTracking.update();
                        var d = [];
                        e = e || Sb + Gb;
                        e += a.xtfirst ? "&idclient=" + L : "";
                        b = b || "F";
                        f = f || u;
                        f += (c ? c : "") + "&vtag=" + Cb + AT_hit.localHour() + AT_hit.resolution() + "&rn=" + (new Date).getTime();
                        AT_hit.first && "F" == b && (f += fb && 0 > f.indexOf("&stc=") ? "&stc=" + fb : "", f += "&ref=" + AT_hit.referrer.replace(/&/g, "$"));
                        "C" === b && (f += "&pclick=" + a.xtpage + "&s2click=" + (a.xtn2 ? a.xtn2 : ""));
                        d = AT_hit.parse(b, f, "&", {
                            ati: ",",
                            atc: ",",
                            pdtl: "|",
                            stc: ",",
                            dz: "|"
                        });
                        for (f = 0; f < d.length; f++) AT_hit.loadImage(e + d[f]);
                        AT_hit.first && ("F" == b && "" !== Za) && AT_hit.loadFile("script", Za, !0, "text/javascript");
                        "F" == b && (AT_hit.first = !1)
                    },
                    loadImage: function(a) {
                        var f = new Image;
                        f.src = a;
                        ra.sentHits instanceof Array && ra.sentHits.push(a);
                        f.onload = function() {
                            f.onload = null
                        }
                    },
                    loadFile: function(a, f, e, c, d) {
                        a = document.createElement(a);
                        a.type = c;
                        a.async = e;
                        a.src = f;
                        (d || document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0] || document.getElementsByTagName("script")[0].parentNode).insertBefore(a, null)
                    },
                    localHour: function(a) {
                        a = a ? a : new Date;
                        return "&hl=" + a.getHours() + "x" + a.getMinutes() + "x" + a.getSeconds()
                    },
                    resolution: function() {
                        if (4 <= parseFloat(s.appVersion)) try {
                            var a;
                            a = "undefined" !== typeof window.devicePixelRatio ? window.devicePixelRatio : 1;
                            return "&r=" + da.width * a + "x" + da.height * a + "x" + da.pixelDepth + "x" + da.colorDepth
                        } catch (f) {}
                        return ""
                    },
                    prerenderDisplaying: function() {
                        AT_hit.first && (AT_hit.sendTag("F"), "" !== xt44 && AT_hit.sendTag("PDT", xt44, null, "&type=PDT&p=" + aa + (a.xt_pageID ? "&pid=" + a.xt_pageID + "&pchap=" + (a.xt_chap || "") + "&pidt=" + (a.xt_pageDate || "") : "")))
                    },
                    isPreviewOrPrerendering: function() {
                        return window.navigator && "preview" === window.navigator.loadPurpose && -1 != s.userAgent.indexOf("Safari") && 0 > s.userAgent.indexOf("Chrome") ? (wb && (AT_hit.sendTag("F", null, null, "&pvw=1"), "" !== xt44 && AT_hit.sendTag("PDT", xt44, null, "&type=PDT&p=" + aa + (a.xt_pageID ? "&pid=" + a.xt_pageID + "&pchap=" + (a.xt_chap || "") + "&pidt=" + (a.xt_pageDate || "") : ""))), !0) : "prerender" == j.webkitVisibilityState ? (j.addEventListener("webkitvisibilitychange", AT_hit.prerenderDisplaying, !1), !0) : !1
                    }
                };
                if (0 !== E || 0 !== Z || F) {
                    var T = "";
                    if ("" !== cb) {
                        T = p("xtvid");
                        T || (va = T = G.getTime() + "" + R(6));
                        var Ea = new Date;
                        Ea.setMinutes(Ea.getMinutes() + 30);
                        n("xtvid", T, Ea, "", 1)
                    }
                    window.xtvid = T;
                    var lb = Xtconf.xtsite("xtor"),
                        Fa = Xtconf.xtsite("xtdate"),
                        mb = Xtconf.xtsite("xtocl"),
                        Ga = Xtconf.xtsite("xtan"),
                        Ha = Xtconf.xtsite("xtat"),
                        U = Xtconf.xtsite("xtant"),
                        J = m("xtor"),
                        Ia = m("xtdt"),
                        v = m("xtan"),
                        w = m("xtat"),
                        Ja = m("an", r),
                        Ka = m("at", r),
                        nb = m("ac", r),
                        ob = p(mb),
                        La = p("xtgo"),
                        Ma = p("xtord"),
                        pb = p("xtvrn"),
                        V = null !== ob ? ob : "$",
                        Tb = "0" === La ? Ma : null,
                        Na = null !== La ? La : "0",
                        fa = null !== pb ? pb : "$",
                        qb = G.getTime() / 6E4,
                        W = null !== Ia && (m("xts") == E || F) ? 30 > qb - Ia && 0 <= qb - Ia ? "2" : "1" : Na,
                        Ub = "1" == Na ? "&pgt=" + Ma : "1" == W && null !== J ? "&pgt=" + J : "",
                        M = null !== gb ? gb : null !== J && "0" == W ? J : !F ? Tb : null,
                        M = 0 > V.indexOf("$" + M + "$") || "$" == V ? M : null,
                        A = "0" == W ? M : "2" == Na ? Ma : "2" == W ? J : null,
                        N, Oa;
                    null !== A ? (Oa = A.substring(0, A.indexOf("-")), N = y[Oa]) : N = "1";
                    if (null === N || !B(N)) N = y.ad;
                    null === v && !F && (v = p("xtanrd"));
                    null === w && !F && (w = p("xtatrd"));
                    var rb = p(Ga),
                        sb = p(Ha),
                        ga = p(U),
                        z = new Date,
                        x = window.xt29 = new Date,
                        Pa = new Date;
                    F ? z.setTime(z.getTime() + 3E4) : z.setTime(z.getTime() + 864E5 * N);
                    Pa.setTime(Pa.getTime() + 18E5);
                    x.setTime(x.getTime() + 864E5 * Bb);
                    var Qa = null !== v ? v.indexOf("-") : 0,
                        Ra = null !== w ? w.indexOf("-") : 0,
                        tb = null !== Ja ? "" : null !== v && 0 < Qa ? "&ac=" + v.substring(0, Qa) + "&ant=0&an=" + v.substring(Qa + 1, v.length) : null !== rb ? "&anc=" + rb + "&anct=" + ga : "",
                        Vb = null !== Ka ? "" : null !== w && 0 < Ra ? "&ac=" + w.substring(0, Ra) + "&ant=0&at=" + w.substring(Ra + 1, w.length) : null !== sb ? "&attc=" + sb + "&anct=" + ga : "",
                        H = 0 > fa.indexOf("$" + E + "$") ? "&vrn=1" : "",
                        Wb = null !== m("xtatc") && null === m("atc", r) ? "&atc=" + m("xtatc") : "";
                    "" !== H && n("xtvrn", 141 > fa.length ? fa + E + "$" : fa.substring(0, 141), x, h, 0);
                    H += null === M ? "" : "&xto=" + M;
                    H += ("" !== tb ? tb : Vb) + Ub + Wb;
                    null !== Ja ? (n(Ga, nb + "-" + Ja, x, h, 1), n(U, "1", x, h, 1)) : null !== v && "1" != ga && (n(Ga, v, x, h, 1), n(U, "0", x, h, 1));
                    null !== Ka ? (n(Ha, nb + "-" + Ka, x, h, 1), n(U, "1", x, h, 1)) : null !== w && "1" != ga && (n(Ha, w, x, h, 1), n(U, "0", x, h, 1));
                    var Sa = p(lb),
                        X = p(Fa),
                        X = (/[a-zA-Z]/.test(X) ? (new Date(X)).getTime() / 36E5 : parseFloat(p(Fa))) || (new Date).getTime() / 36E5,
                        Xb = 0 <= Math.floor(ib - X) ? Math.floor(ib - X) : 0,
                        H = H + (null === Sa ? "" : "&xtor=" + Sa + "&roinbh=" + Xb);
                    if (F) n("xtgo", W, z, h, 1), null !== J && n("xtord", J, z, h, 1), null !== v && n("xtanrd", v, z, h, 1), null !== w && n("xtatrd", w, z, h, 1), n("xtref", AT_hit.referrer ? AT_hit.referrer.replace(/&/g, "$") : "acc_dir", z, h, 0), a.xtloc && (Q.location = a.xtloc);
                    else {
                        null !== A && (0 > V.indexOf("$" + encodeURIComponent(A) +
                            "$") || "$" == V) && n(mb, V + A + "$", Pa, h, 1);
                        var ha = s.appName + " " + s.appVersion,
                            O = ha.indexOf("MSIE"),
                            P;
                        0 <= O ? (P = parseInt(ha.substr(O + 5)), O = !0) : (P = parseFloat(s.appVersion), O = !1);
                        var Yb = 0 <= ha.indexOf("Netscape"),
                            Zb = 0 <= ha.indexOf("Mac"),
                            Ta = 0 <= s.userAgent.indexOf("Opera"),
                            ia = "",
                            ub = "",
                            Ua = "",
                            Va = "";
                        if (O && 5 <= P && !Zb && !Ta && !F) try {
                            j.body.addBehavior("#default#clientCaps"), ia = "&cn=" + j.body.connectionType, ia += "&ul=" + j.body.UserLanguage, j.body.addBehavior("#default#homePage"), ub = j.body.isHomePage(location.href) ? "&hm=1" : "&hm=0", Va = "&re=" + j.body.offsetWidth + "x" + j.body.offsetHeight
                        } catch (ec) {} else 5 <= P && (Va = "&re=" + a.innerWidth + "x" + a.innerHeight);
                        Yb && 4 <= P || Ta ? Ua = "&lng=" + s.language : O && (4 <= P && !Ta) && (Ua = "&lng=" + s.userLanguage);
                        n("xtord", "", G, h, 1);
                        if (null !== A && (null === Sa || "1" == Ab)) n(lb, A, z, h, 1), n(Fa, G.getTime() / 36E5, z, h, 1);
                        var $b = zb ? "&docl=" + encodeURIComponent(Q.location.href.replace(/&/g, "#ec#")) : "",
                            u = Fb + "&p=" + aa + Hb + Ib + Jb + H + $b + Kb + r + ia + ub + Ua + "&idp=" + Da,
                            Wa = p("xtvalCZ", 1);
                        if (null !== Wa) {
                            var u = u + decodeURIComponent(Wa.replace(/%at1%/g, "-").replace(/%at2%/g, "_").replace(/%at3%/g, ".").replace(/%at4%/g, "!").replace(/%at5%/g, "~").replace(/%at6%/g, "*").replace(/%at7%/g, "'").replace(/%at8%/g, "(").replace(/%at9%/g, ")")).replace("&c=", "&current=").replace("&b=", "&before=").replace("&a=", "&after="),
                                Xa = new Date;
                            Xa.setTime(Xa.getTime() - 36E5);
                            n("xtvalCZ", Wa, Xa, h, 1)
                        }
                        var Sb = window.Xt_id = Db + "?",
                            ja = p("xtide");
                        if (null !== A) switch (Oa.toLowerCase()) {
                            case "erec":
                            case "epr":
                            case "es":
                                var ka = null;
                                try {
                                    var la = A.match(/(\[[^\]]*\])|([^\-]+)|(-)/g),
                                        vb = 0,
                                        ma;
                                    for (ma in la) "-" == la[ma] && vb++, 5 == vb && "-" != la[ma] && (ka = la[ma])
                                } catch (fc) {
                                    ka = null
                                }
                                null !== ka && (ja = ka, n("xtide", ja, x, "", 1))
                        }
                        u += "&jv=" + (s.javaEnabled() ? "1" : "0") + Va + xt16 + (null !== ja ? "&ide=" + ja : "");
                        va && (u += "&lnk=" + cb + "&vid=" + va);
                        "0" != Y && !AT_hit.isPreviewOrPrerendering() && (AT_hit.sendTag("F"), "" !== xt44 && AT_hit.sendTag("PDT", xt44, null, "&type=PDT&p=" + aa + (a.xt_pageID ? "&pid=" + a.xt_pageID + "&pchap=" + (a.xt_chap || "") + "&pidt=" + (a.xt_pageDate || "") : "")))
                    }
                }
                0 < pa && "function" == typeof xtNodesload && (yb ? a.addEventListener ? a.addEventListener("load", xtNodesload, !1) : a.attachEvent && a.attachEvent("onload", xtNodesload) : xtNodesload())
            };
        } catch (e) {
            console.log(e)
        }
    } catch (e) {
        console.log(e);
    }
}
if (typeof utag == "undefined" && !utag_condload) {
    var utag = {
        id: "schibsted.leboncoin-responsive",
        o: {},
        sender: {},
        send: {},
        rpt: {
            ts: {
                a: new Date()
            }
        },
        dbi: [],
        loader: {
            q: [],
            lc: 0,
            f: {},
            p: 0,
            ol: 0,
            wq: [],
            lq: [],
            bq: {},
            bk: {},
            rf: 0,
            ri: 0,
            rp: 0,
            rq: [],
            ready_q: [],
            sendq: {
                "pending": 0
            },
            run_ready_q: function() {
                for (var i = 0; i < utag.loader.ready_q.length; i++) {
                    utag.DB("READY_Q:" + i);
                    try {
                        utag.loader.ready_q[i]()
                    } catch (e) {
                        utag.DB(e)
                    };
                }
            },
            lh: function(a, b, c) {
                a = "" + location.hostname;
                b = a.split(".");
                c = (/\.co\.|\.com\.|\.org\.|\.edu\.|\.net\.|\.asn\./.test(a)) ? 3 : 2;
                return b.splice(b.length - c, c).join(".");
            },
            WQ: function(a, b, c, d, g) {
                utag.DB('WQ:' + utag.loader.wq.length);
                try {
                    if (utag.udoname && utag.udoname.indexOf(".") < 0) {
                        utag.ut.merge(utag.data, window[utag.udoname], 0);
                    }
                    if (utag.cfg.load_rules_at_wait) {
                        utag.handler.LR(utag.data);
                    }
                } catch (e) {
                    utag.DB(e)
                };
                d = 0;
                g = [];
                for (a = 0; a < utag.loader.wq.length; a++) {
                    b = utag.loader.wq[a];
                    b.load = utag.loader.cfg[b.id].load;
                    if (b.load == 4) {
                        this.f[b.id] = 0;
                        utag.loader.LOAD(b.id)
                    } else if (b.load > 0) {
                        g.push(b);
                        d++;
                    } else {
                        this.f[b.id] = 1;
                    }
                }
                for (a = 0; a < g.length; a++) {
                    utag.loader.AS(g[a]);
                }
                if (d == 0) {
                    utag.loader.END();
                }
            },
            AS: function(a, b, c, d) {
                utag.send[a.id] = a;
                if (typeof a.src == 'undefined') {
                    a.src = utag.cfg.path + ((typeof a.name != 'undefined') ? a.name : 'ut' + 'ag.' + a.id + '.js')
                }
                a.src += (a.src.indexOf('?') > 0 ? '&' : '?') + 'utv=' + (a.v ? utag.cfg.template + a.v : utag.cfg.v);
                utag.rpt['l_' + a.id] = a.src;
                b = document;
                this.f[a.id] = 0;
                if (a.load == 2) {
                    utag.DB("Attach sync: " + a.src);
                    a.uid = a.id;
                    b.write('<script id="utag_' + a.id + '" src="' + a.src + '"></scr' + 'ipt>')
                    if (typeof a.cb != 'undefined') a.cb();
                } else if (a.load == 1 || a.load == 3) {
                    if (b.createElement) {
                        c = 'utag_schibsted.leboncoin-responsive_' + a.id;
                        if (!b.getElementById(c)) {
                            d = {
                                src: a.src,
                                id: c,
                                uid: a.id,
                                loc: a.loc
                            }
                            if (a.load == 3) {
                                d.type = "iframe"
                            };
                            if (typeof a.cb != 'undefined') d.cb = a.cb;
                            utag.ut.loader(d);
                        }
                    }
                }
            },
            GV: function(a, b, c) {
                b = {};
                for (c in a) {
                    if (a.hasOwnProperty(c) && typeof a[c] != "function") b[c] = a[c];
                }
                return b
            },
            OU: function(a, b, c, d, f) {
                try {
                    if (typeof utag.data['cp.OPTOUTMULTI'] != 'undefined') {
                        c = utag.loader.cfg;
                        a = utag.ut.decode(utag.data['cp.OPTOUTMULTI']).split('|');
                        for (d = 0; d < a.length; d++) {
                            b = a[d].split(':');
                            if (b[1] * 1 !== 0) {
                                if (b[0].indexOf('c') == 0) {
                                    for (f in utag.loader.GV(c)) {
                                        if (c[f].tcat == b[0].substring(1)) c[f].load = 0
                                    }
                                } else if (b[0] * 1 == 0) {
                                    utag.cfg.nocookie = true
                                } else {
                                    for (f in utag.loader.GV(c)) {
                                        if (c[f].tid == b[0]) c[f].load = 0
                                    }
                                }
                            }
                        }
                    }
                } catch (e) {
                    utag.DB(e)
                }
            },
            RDdom: function(o) {
                var d = document || {},
                    l = location || {};
                o["dom.referrer"] = eval("document." + "referrer");
                o["dom.title"] = "" + d.title;
                o["dom.domain"] = "" + l.hostname;
                o["dom.query_string"] = ("" + l.search).substring(1);
                o["dom.hash"] = ("" + l.hash).substring(1);
                o["dom.url"] = "" + d.URL;
                o["dom.pathname"] = "" + l.pathname;
                o["dom.viewport_height"] = window.innerHeight || (d.documentElement ? d.documentElement.clientHeight : 960);
                o["dom.viewport_width"] = window.innerWidth || (d.documentElement ? d.documentElement.clientWidth : 960);
            },
            RDcp: function(o, b, c, d) {
                b = b || utag.loader.RC();
                for (d in b) {
                    if (d.match(/utag_(.*)/)) {
                        for (c in utag.loader.GV(b[d])) {
                            o["cp.utag_" + RegExp.$1 + "_" + c] = b[d][c];
                        }
                    }
                }
                for (c in utag.loader.GV((utag.cl && !utag.cl['_all_']) ? utag.cl : b)) {
                    if (c.indexOf("utag_") < 0 && typeof b[c] != "undefined") o["cp." + c] = b[c];
                }
                o["_t_visitor_id"] = o["cp.utag_main_v_id"];
                o["_t_session_id"] = o["cp.utag_main_ses_id"];
            },
            RDqp: function(o, a, b, c) {
                a = location.search + (location.hash + '').replace("#", "&");
                if (utag.cfg.lowerqp) {
                    a = a.toLowerCase()
                };
                if (a.length > 1) {
                    b = a.substring(1).split('&');
                    for (a = 0; a < b.length; a++) {
                        c = b[a].split("=");
                        if (c.length > 1) {
                            o["qp." + c[0]] = utag.ut.decode(c[1])
                        }
                    }
                }
            },
            RDmeta: function(o, a, b, h) {
                a = document.getElementsByTagName("meta");
                for (b = 0; b < a.length; b++) {
                    try {
                        h = a[b].name || a[b].getAttribute("property") || "";
                    } catch (e) {
                        h = "";
                        utag.DB(e)
                    };
                    if (utag.cfg.lowermeta) {
                        h = h.toLowerCase()
                    };
                    if (h != "") {
                        o["meta." + h] = a[b].content
                    }
                }
            },
            RDva: function(o) {
                var readAttr = function(o, l) {
                    var a = "",
                        b;
                    a = localStorage.getItem(l);
                    if (!a || a == "{}") return;
                    b = utag.ut.flatten({
                        va: JSON.parse(a)
                    });
                    utag.ut.merge(o, b, 1);
                }
                try {
                    readAttr(o, "tealium_va");
                    readAttr(o, "tealium_va_" + o["ut.account"] + "_" + o["ut.profile"]);
                } catch (e) {
                    utag.DB(e)
                }
            },
            RDut: function(o, a) {
                o["ut.domain"] = utag.cfg.domain;
                o["ut.version"] = utag.cfg.v;
                o["ut.event"] = a || "view";
                try {
                    o["ut.account"] = utag.cfg.utid.split("/")[0];
                    o["ut.profile"] = utag.cfg.utid.split("/")[1];
                    o["ut.env"] = utag.cfg.path.split("/")[6];
                } catch (e) {
                    utag.DB(e)
                }
            },
            RD: function(o, a, b, c, d) {
                utag.DB("utag.loader.RD");
                utag.DB(o);
                if (!utag.loader.rd_flag) {
                    a = (new Date()).getTime();
                    b = utag.loader.RC();
                    c = a + parseInt(utag.cfg.session_timeout);
                    d = a;
                    if (!b.utag_main) {
                        b.utag_main = {};
                    } else if (b.utag_main.ses_id && typeof b.utag_main._st != "undefined" && parseInt(b.utag_main._st) < a) {
                        delete b.utag_main.ses_id;
                    }
                    if (!b.utag_main.v_id) {
                        b.utag_main.v_id = utag.ut.vi(a);
                    }
                    if (!b.utag_main.ses_id) {
                        b.utag_main.ses_id = d + '';
                        b.utag_main._ss = b.utag_main._pn = 1;
                        b.utag_main._sn = 1 + parseInt(b.utag_main._sn || 0);
                    } else {
                        d = b.utag_main.ses_id;
                        b.utag_main._ss = 0;
                        b.utag_main._pn = 1 + parseInt(b.utag_main._pn);
                        b.utag_main._sn = parseInt(b.utag_main._sn);
                    }
                    if (isNaN(b.utag_main._sn) || b.utag_main._sn < 1) {
                        b.utag_main._sn = b.utag_main._pn = 1
                    }
                    b.utag_main._st = c + '';
                    utag.loader.SC("utag_main", {
                        "v_id": b.utag_main.v_id,
                        "_sn": b.utag_main._sn,
                        "_ss": b.utag_main._ss,
                        "_pn": b.utag_main._pn + ";exp-session",
                        "_st": c,
                        "ses_id": d + ";exp-session"
                    });
                }
                utag.loader.rd_flag = 1;
                this.RDqp(o);
                this.RDmeta(o);
                this.RDcp(o, b);
                this.RDdom(o);
                this.RDut(o);
                this.RDva(o);
            },
            RC: function(a, x, b, c, d, e, f, g, h, i, j, k, l, m, n, o, v, ck, cv, r, s, t) {
                o = {};
                b = ("" + document.cookie != "") ? (document.cookie).split("; ") : [];
                r = /^(.*?)=(.*)$/;
                s = /^(.*);exp-(.*)$/;
                t = (new Date()).getTime();
                for (c = 0; c < b.length; c++) {
                    if (b[c].match(r)) {
                        ck = RegExp.$1;
                        cv = RegExp.$2;
                    }
                    e = utag.ut.decode(cv);
                    if (typeof ck != "undefined") {
                        if (ck.indexOf("ulog") == 0 || ck.indexOf("utag_") == 0) {
                            e = cv.split("$");
                            g = [];
                            j = {};
                            for (f = 0; f < e.length; f++) {
                                try {
                                    g = e[f].split(":");
                                    if (g.length > 2) {
                                        g[1] = g.slice(1).join(":");
                                    }
                                    v = "";
                                    if (("" + g[1]).indexOf("~") == 0) {
                                        h = g[1].substring(1).split("|");
                                        for (i = 0; i < h.length; i++) h[i] = utag.ut.decode(h[i]);
                                        v = h
                                    } else v = utag.ut.decode(g[1]);
                                    j[g[0]] = v;
                                } catch (er) {
                                    utag.DB(er)
                                };
                            }
                            o[ck] = {};
                            for (f in utag.loader.GV(j)) {
                                if (j[f] instanceof Array) {
                                    n = [];
                                    for (m = 0; m < j[f].length; m++) {
                                        if (j[f][m].match(s)) {
                                            k = (RegExp.$2 == "session") ? (typeof j._st != "undefined" ? j._st : t - 1) : parseInt(RegExp.$2);
                                            if (k > t) n[m] = (x == 0) ? j[f][m] : RegExp.$1;
                                        }
                                    }
                                    j[f] = n.join("|");
                                } else {
                                    j[f] = "" + j[f];
                                    if (j[f].match(s)) {
                                        k = (RegExp.$2 == "session") ? (typeof j._st != "undefined" ? j._st : t - 1) : parseInt(RegExp.$2);
                                        j[f] = (k < t) ? null : (x == 0 ? j[f] : RegExp.$1);
                                    }
                                }
                                if (j[f]) o[ck][f] = j[f];
                            }
                        } else if (utag.cl[ck] || utag.cl['_all_']) {
                            o[ck] = e
                        }
                    }
                }
                return (a) ? (o[a] ? o[a] : {}) : o;
            },
            SC: function(a, b, c, d, e, f, g, h, i, j, k, x, v) {
                if (!a) return 0;
                if (a == "utag_main" && utag.cfg.nocookie) return 0;
                v = "";
                var date = new Date();
                var exp = new Date();
                exp.setTime(date.getTime() + (365 * 24 * 60 * 60 * 1000));
                x = exp.toGMTString();
                if (c && c == "da") {
                    x = "Thu, 31 Dec 2009 00:00:00 GMT";
                } else if (a.indexOf("utag_") != 0 && a.indexOf("ulog") != 0) {
                    if (typeof b != "object") {
                        v = b
                    }
                } else {
                    d = utag.loader.RC(a, 0);
                    for (e in utag.loader.GV(b)) {
                        f = "" + b[e];
                        if (f.match(/^(.*);exp-(\d+)(\w)$/)) {
                            g = date.getTime() + parseInt(RegExp.$2) * ((RegExp.$3 == "h") ? 3600000 : 86400000);
                            if (RegExp.$3 == "u") g = parseInt(RegExp.$2);
                            f = RegExp.$1 + ";exp-" + g;
                        }
                        if (c == "i") {
                            if (d[e] == null) d[e] = f;
                        } else if (c == "d") delete d[e];
                        else if (c == "a") d[e] = (d[e] != null) ? (f - 0) + (d[e] - 0) : f;
                        else if (c == "ap" || c == "au") {
                            if (d[e] == null) d[e] = f;
                            else {
                                if (d[e].indexOf("|") > 0) {
                                    d[e] = d[e].split("|")
                                }
                                g = (d[e] instanceof Array) ? d[e] : [d[e]];
                                g.push(f);
                                if (c == "au") {
                                    h = {};
                                    k = {};
                                    for (i = 0; i < g.length; i++) {
                                        if (g[i].match(/^(.*);exp-(.*)$/)) {
                                            j = RegExp.$1;
                                        }
                                        if (typeof k[j] == "undefined") {
                                            k[j] = 1;
                                            h[g[i]] = 1;
                                        }
                                    }
                                    g = [];
                                    for (i in utag.loader.GV(h)) {
                                        g.push(i);
                                    }
                                }
                                d[e] = g
                            }
                        } else d[e] = f;
                    }
                    h = new Array();
                    for (g in utag.loader.GV(d)) {
                        if (d[g] instanceof Array) {
                            for (c = 0; c < d[g].length; c++) {
                                d[g][c] = encodeURIComponent(d[g][c])
                            }
                            h.push(g + ":~" + d[g].join("|"))
                        } else h.push((g + ":").replace(/[\,\$\;\?]/g, "") + encodeURIComponent(d[g]))
                    }
                    if (h.length == 0) {
                        h.push("");
                        x = ""
                    }
                    v = (h.join("$"));
                }
                document.cookie = a + "=" + v + ";path=/;domain=" + utag.cfg.domain + ";expires=" + x;
                return 1
            },
            LOAD: function(a, b, c, d) {
                if (!utag.loader.cfg) {
                    return
                }
                if (this.ol == 0) {
                    if (utag.loader.cfg[a].block && utag.loader.cfg[a].cbf) {
                        this.f[a] = 1;
                        delete utag.loader.bq[a];
                    }
                    for (b in utag.loader.GV(utag.loader.bq)) {
                        if (utag.loader.cfg[a].load == 4 && utag.loader.cfg[a].wait == 0) {
                            utag.loader.bk[a] = 1;
                            utag.DB("blocked: " + a);
                        }
                        utag.DB("blocking: " + b);
                        return;
                    }
                    utag.loader.INIT();
                    return;
                }
                utag.DB('utag.loader.LOAD:' + a);
                if (this.f[a] == 0) {
                    this.f[a] = 1;
                    if (utag.cfg.noview != true) {
                        if (utag.loader.cfg[a].send) {
                            utag.DB("SENDING: " + a);
                            try {
                                if (utag.loader.sendq.pending > 0 && utag.loader.sendq[a]) {
                                    utag.DB("utag.loader.LOAD:sendq: " + a);
                                    while (d = utag.loader.sendq[a].shift()) {
                                        utag.DB(d);
                                        utag.sender[a].send(d.event, utag.handler.C(d.data));
                                        utag.loader.sendq.pending--;
                                    }
                                } else {
                                    utag.sender[a].send('view', utag.handler.C(utag.data));
                                }
                                utag.rpt['s_' + a] = 0;
                            } catch (e) {
                                utag.DB(e);
                                utag.rpt['s_' + a] = 1;
                            }
                        }
                    }
                    if (utag.loader.rf == 0) return;
                    for (b in utag.loader.GV(this.f)) {
                        if (this.f[b] == 0 || this.f[b] == 2) return
                    }
                    utag.loader.END();
                }
            },
            EV: function(a, b, c, d) {
                if (b == "ready") {
                    if (!utag.data) {
                        try {
                            utag.cl = {
                                '_all_': 1
                            };
                            utag.loader.initdata();
                            utag.loader.RD(utag.data);
                        } catch (e) {
                            utag.DB(e)
                        };
                    }
                    if ((document.attachEvent || utag.cfg.dom_complete) ? document.readyState === "complete" : document.readyState !== "loading") setTimeout(c, 1);
                    else {
                        utag.loader.ready_q.push(c);
                        var RH;
                        if (utag.loader.ready_q.length <= 1) {
                            if (document.addEventListener) {
                                RH = function() {
                                    document.removeEventListener("DOMContentLoaded", RH, false);
                                    utag.loader.run_ready_q()
                                };
                                if (!utag.cfg.dom_complete) document.addEventListener("DOMContentLoaded", RH, false);
                                window.addEventListener("load", utag.loader.run_ready_q, false);
                            } else if (document.attachEvent) {
                                RH = function() {
                                    if (document.readyState === "complete") {
                                        document.detachEvent("onreadystatechange", RH);
                                        utag.loader.run_ready_q()
                                    }
                                };
                                document.attachEvent("onreadystatechange", RH);
                                window.attachEvent("onload", utag.loader.run_ready_q);
                            }
                        }
                    }
                } else {
                    if (a.addEventListener) {
                        a.addEventListener(b, c, false)
                    } else if (a.attachEvent) {
                        a.attachEvent(((d == 1) ? "" : "on") + b, c)
                    }
                }
            },
            END: function(b, c, d, e, v, w) {
                if (this.ended) {
                    return
                };
                this.ended = 1;
                utag.DB("loader.END");
                b = utag.data;
                if (utag.handler.base && utag.handler.base != '*') {
                    e = utag.handler.base.split(",");
                    for (d = 0; d < e.length; d++) {
                        if (typeof b[e[d]] != "undefined") utag.handler.df[e[d]] = b[e[d]]
                    }
                } else if (utag.handler.base == '*') {
                    utag.ut.merge(utag.handler.df, b, 1);
                }
                utag.rpt['r_0'] = "t";
                for (var r in utag.loader.GV(utag.cond)) {
                    utag.rpt['r_' + r] = (utag.cond[r]) ? "t" : "f";
                }
                utag.rpt.ts['s'] = new Date();
                v = ".tiqcdn.com";
                w = utag.cfg.path.indexOf(v);
                if (w > 0 && b["cp.utag_main__ss"] == 1 && !utag.cfg.no_session_count) utag.ut.loader({
                    src: utag.cfg.path.substring(0, w) + v + "/ut" + "ag/tiqapp/ut" + "ag.v.js?a=" + utag.cfg.utid + (utag.cfg.nocookie ? "&nocookie=1" : "&cb=" + (new Date).getTime()),
                    id: "tiqapp"
                })
                if (utag.cfg.noview != true) utag.handler.RE('view', b, "end");
                utag.handler.INIT();
            }
        },
        DB: function(a, b) {
            if (utag.cfg.utagdb === false) {
                return;
            } else if (typeof utag.cfg.utagdb == "undefined") {
                utag.db_log = [];
                b = document.cookie + '';
                utag.cfg.utagdb = ((b.indexOf('utagdb=true') >= 0) ? true : false);
            }
            if (utag.cfg.utagdb === true) {
                var t;
                if (utag.ut.typeOf(a) == "object") {
                    t = utag.handler.C(a)
                } else {
                    t = a
                }
                utag.db_log.push(t);
                try {
                    console.log(t)
                } catch (e) {}
            }
        },
        RP: function(a, b, c) {
            if (typeof a != 'undefined' && typeof a.src != 'undefined' && a.src != '') {
                b = [];
                for (c in utag.loader.GV(a)) {
                    if (c != 'src') b.push(c + '=' + escape(a[c]))
                }
                this.dbi.push((new Image()).src = a.src + '?utv=' + utag.cfg.v + '&utid=' + utag.cfg.utid + '&' + (b.join('&')))
            }
        },
        view: function(a, c, d) {
            return this.track({
                event: 'view',
                data: a,
                cfg: {
                    cb: c,
                    uids: d
                }
            })
        },
        link: function(a, c, d) {
            return this.track({
                event: 'link',
                data: a,
                cfg: {
                    cb: c,
                    uids: d
                }
            })
        },
        track: function(a, b, c, d) {
            if (typeof a == "string") a = {
                event: a,
                data: b,
                cfg: {
                    cb: c
                }
            };
            for (d in utag.loader.GV(utag.o)) {
                try {
                    utag.o[d].handler.trigger(a.event || "view", a.data || a, a.cfg)
                } catch (e) {
                    utag.DB(e)
                };
            }
            if (a.cfg && a.cfg.cb) try {
                a.cfg.cb()
            } catch (e) {
                utag.DB(e)
            };
            return true
        },
        handler: {
            base: "",
            df: {},
            o: {},
            send: {},
            iflag: 0,
            INIT: function(a, b, c) {
                utag.DB('utag.handler.INIT');
                if (utag.initcatch) {
                    utag.initcatch = 0;
                    return
                }
                this.iflag = 1;
                a = utag.loader.q.length;
                if (a > 0) {
                    utag.DB("Loader queue");
                    for (b = 0; b < a; b++) {
                        c = utag.loader.q[b];
                        utag.handler.trigger(c.a, c.b, c.c)
                    }
                }
            },
            test: function() {
                return 1
            },
            LR: function(b) {
                utag.DB("Load Rules");
                for (var d in utag.loader.GV(utag.cond)) {
                    utag.cond[d] = false;
                }
                utag.DB(utag.data);
                utag.loader.loadrules();
                utag.DB(utag.cond);
                utag.loader.initcfg();
                utag.loader.OU();
                for (var r in utag.loader.GV(utag.cond)) {
                    utag.rpt['r_' + r] = (utag.cond[r]) ? "t" : "f";
                }
            },
            RE: function(a, b, c, d, e, f, g) {
                if (c != "alr" && !this.cfg_extend) {
                    return 0;
                }
                utag.DB("RE: " + c);
                if (c == "alr") utag.DB("All Tags EXTENSIONS");
                utag.DB(b);
                if (typeof this.extend != "undefined") {
                    g = 0;
                    for (d = 0; d < this.extend.length; d++) {
                        try {
                            e = 0;
                            if (typeof this.cfg_extend != "undefined") {
                                f = this.cfg_extend[d];
                                if (typeof f.count == "undefined") f.count = 0;
                                if (f[a] == 0 || (f.once == 1 && f.count > 0) || f[c] == 0) {
                                    e = 1
                                } else {
                                    if (f[c] == 1) {
                                        g = 1
                                    };
                                    f.count++
                                }
                            }
                            if (e != 1) {
                                this.extend[d](a, b);
                                utag.rpt['ex_' + d] = 0
                            }
                        } catch (er) {
                            utag.DB(er);
                            utag.rpt['ex_' + d] = 1;
                            utag.ut.error({
                                e: er.message,
                                s: utag.cfg.path + 'utag.js',
                                l: d,
                                t: 'ge'
                            });
                        }
                    }
                    utag.DB(b);
                    return g;
                }
            },
            trigger: function(a, b, c, d, e, f) {
                utag.DB('trigger:' + a + (c && c.uids ? ":" + c.uids.join(",") : ""));
                b = b || {};
                utag.DB(b);
                if (!this.iflag) {
                    utag.DB("trigger:called before tags loaded");
                    for (d in utag.loader.f) {
                        if (!(utag.loader.f[d] === 1)) utag.DB('Tag ' + d + ' did not LOAD')
                    }
                    utag.loader.q.push({
                        a: a,
                        b: utag.handler.C(b),
                        c: c
                    });
                    return;
                }
                utag.cfg.noview = false;
                utag.ut.merge(b, this.df, 0);
                utag.loader.RDqp(b);
                utag.loader.RDcp(b);
                utag.loader.RDdom(b);
                utag.loader.RDmeta(b);
                utag.loader.RDut(b, a);
                utag.loader.RDva(b);

                function sendTag(a, b, d) {
                    try {
                        if (typeof utag.sender[d] != "undefined") {
                            utag.DB("SENDING: " + d);
                            utag.sender[d].send(a, utag.handler.C(b));
                            utag.rpt['s_' + d] = 0;
                        } else if (utag.loader.cfg[d].load != 2 && utag.loader.cfg[d].s2s != 1) {
                            utag.loader.sendq[d] = utag.loader.sendq[d] || [];
                            utag.loader.sendq[d].push({
                                "event": a,
                                "data": utag.handler.C(b)
                            });
                            utag.loader.sendq.pending++;
                            utag.loader.AS({
                                id: d,
                                load: 1
                            });
                        }
                    } catch (e) {
                        utag.DB(e)
                    }
                }
                if (c && c.uids) {
                    this.RE(a, b, "alr");
                    for (f = 0; f < c.uids.length; f++) {
                        d = c.uids[f];
                        sendTag(a, b, d);
                    }
                } else if (utag.cfg.load_rules_ajax) {
                    this.RE(a, b, "blr");
                    utag.ut.merge(utag.data, b, 1);
                    this.LR(b);
                    this.RE(a, b, "alr");
                    for (f = 0; f < utag.loader.cfgsort.length; f++) {
                        d = utag.loader.cfgsort[f];
                        if (utag.loader.cfg[d].load && utag.loader.cfg[d].send) {
                            sendTag(a, b, d);
                        }
                    }
                } else {
                    this.RE(a, b, "alr");
                    for (d in utag.loader.GV(utag.sender)) {
                        sendTag(a, b, d);
                    }
                }
                this.RE(a, b, "end");
                utag.loader.SC("utag_main", {
                    "_st": ((new Date()).getTime() + parseInt(utag.cfg.session_timeout))
                });
            },
            C: function(a, b, c) {
                b = {};
                for (c in utag.loader.GV(a)) {
                    if (a[c] instanceof Array) {
                        b[c] = a[c].slice(0)
                    } else {
                        b[c] = a[c]
                    }
                }
                return b
            }
        },
        ut: {
            pad: function(a, b, c, d) {
                a = "" + ((a - 0).toString(16));
                d = '';
                if (b > a.length) {
                    for (c = 0; c < (b - a.length); c++) {
                        d += '0'
                    }
                }
                return "" + d + a
            },
            vi: function(t, a, b) {
                if (!utag.v_id) {
                    a = this.pad(t, 12);
                    b = "" + Math.random();
                    a += this.pad(b.substring(2, b.length), 16);
                    try {
                        a += this.pad((navigator.plugins.length ? navigator.plugins.length : 0), 2);
                        a += this.pad(navigator.userAgent.length, 3);
                        a += this.pad(document.URL.length, 4);
                        a += this.pad(navigator.appVersion.length, 3);
                        a += this.pad(screen.width + screen.height + parseInt((screen.colorDepth) ? screen.colorDepth : screen.pixelDepth), 5)
                    } catch (e) {
                        utag.DB(e);
                        a += "12345"
                    };
                    utag.v_id = a;
                }
                return utag.v_id
            },
            hasOwn: function(o, a) {
                return o != null && Object.prototype.hasOwnProperty.call(o, a)
            },
            isEmptyObject: function(o, a) {
                for (a in o) {
                    if (utag.ut.hasOwn(o, a)) return false
                }
                return true
            },
            isEmpty: function(o) {
                var t = utag.ut.typeOf(o);
                if (t == "number") {
                    return isNaN(o)
                } else if (t == "boolean") {
                    return false
                } else if (t == "string") {
                    return o.length === 0
                } else return utag.ut.isEmptyObject(o)
            },
            typeOf: function(e) {
                return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
            },
            flatten: function(o) {
                var a = {};

                function r(c, p) {
                    if (Object(c) !== c || c instanceof Array) {
                        a[p] = c;
                    } else {
                        if (utag.ut.isEmptyObject(c)) {} else {
                            for (var d in c) {
                                r(c[d], p ? p + "." + d : d);
                            }
                        }
                    }
                }
                r(o, "");
                return a;
            },
            merge: function(a, b, c, d) {
                if (c) {
                    for (d in utag.loader.GV(b)) {
                        a[d] = b[d]
                    }
                } else {
                    for (d in utag.loader.GV(b)) {
                        if (typeof a[d] == "undefined") a[d] = b[d]
                    }
                }
            },
            decode: function(a, b) {
                b = "";
                try {
                    b = decodeURIComponent(a)
                } catch (e) {
                    utag.DB(e)
                };
                if (b == "") {
                    b = unescape(a)
                };
                return b
            },
            error: function(a, b, c) {
                if (typeof utag_err != "undefined") {
                    utag_err.push(a)
                }
            },
            loader: function(o, a, b, c, l) {
                a = document;
                if (o.type == "iframe") {
                    b = a.createElement("iframe");
                    o.attrs = o.attrs || {
                        "height": "1",
                        "width": "1",
                        "style": "display:none"
                    };
                    for (l in utag.loader.GV(o.attrs)) {
                        b.setAttribute(l, o.attrs[l])
                    }
                    b.setAttribute("src", o.src);
                } else if (o.type == "img") {
                    utag.DB("Attach img: " + o.src);
                    b = new Image();
                    b.src = o.src;
                    return;
                } else {
                    b = a.createElement("script");
                    b.language = "javascript";
                    b.type = "text/javascript";
                    b.async = 1;
                    b.charset = "utf-8";
                    for (l in utag.loader.GV(o.attrs)) {
                        b[l] = o.attrs[l]
                    }
                    b.src = o.src;
                }
                if (o.id) {
                    b.id = o.id
                };
                if (typeof o.cb == "function") {
                    if (b.addEventListener) {
                        b.addEventListener("load", function() {
                            o.cb()
                        }, false);
                    } else {
                        b.onreadystatechange = function() {
                            if (this.readyState == 'complete' || this.readyState == 'loaded') {
                                this.onreadystatechange = null;
                                o.cb()
                            }
                        };
                    }
                }
                l = o.loc || "head";
                c = a.getElementsByTagName(l)[0];
                if (c) {
                    utag.DB("Attach to " + l + ": " + o.src);
                    if (l == "script") {
                        c.parentNode.insertBefore(b, c);
                    } else {
                        c.appendChild(b)
                    }
                }
            }
        }
    };
    utag.o['schibsted.leboncoin-responsive'] = utag;
    utag.cfg = {
        template: "ut4.39.",
        load_rules_ajax: true,
        load_rules_at_wait: false,
        lowerqp: false,
        session_timeout: 1800000,
        readywait: 0,
        noload: 0,
        domain: utag.loader.lh(),
        path: "//tags.tiqcdn.com/utag/schibsted/leboncoin-responsive/prod/",
        utid: "schibsted/leboncoin-responsive/202311281602"
    };
    utag.cfg.v = utag.cfg.template + "202311281603";
    utag.cond = {
        104: 0,
        105: 0,
        106: 0,
        107: 0,
        108: 0,
        109: 0,
        110: 0,
        111: 0,
        112: 0,
        113: 0,
        119: 0,
        121: 0,
        123: 0,
        124: 0,
        127: 0,
        128: 0,
        129: 0,
        130: 0,
        135: 0,
        138: 0,
        139: 0,
        140: 0,
        141: 0,
        142: 0,
        147: 0,
        148: 0,
        149: 0,
        150: 0,
        151: 0,
        152: 0,
        153: 0,
        154: 0,
        156: 0,
        157: 0,
        158: 0,
        159: 0,
        160: 0,
        162: 0,
        163: 0,
        164: 0,
        166: 0,
        167: 0,
        168: 0,
        169: 0,
        170: 0,
        171: 0,
        172: 0,
        173: 0,
        174: 0,
        176: 0,
        177: 0,
        178: 0,
        179: 0,
        180: 0,
        184: 0,
        187: 0,
        32: 0,
        77: 0,
        82: 0,
        83: 0,
        85: 0,
        89: 0,
        90: 0,
        92: 0
    };
    utag.pagevars = function(ud) {
        ud = ud || utag.data;
        try {
            ud['js_page.actiondescription'] = actiondescription
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.plateformdevice'] = plateformdevice
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.panier'] = panier
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.click_type'] = click_type
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.gdprConditionnementP1'] = gdprConditionnementP1
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.uabValue'] = uabValue
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.user_log_custom_var'] = user_log_custom_var
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.pt1'] = pt1
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.pt2'] = pt2
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.pt3'] = pt3
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.pt4'] = pt4
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.pt5'] = pt5
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.pt6'] = pt6
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.pt7'] = pt7
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.xiti_label'] = xiti_label
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.xtsite'] = xtsite
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.xtn2'] = xtn2
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.protocol'] = protocol
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.xtsd'] = xtsd
        } catch (e) {
            utag.DB(e)
        };
        try {
            ud['js_page.actiontype'] = actiontype
        } catch (e) {
            utag.DB(e)
        };
    };
    utag.loader.initdata = function() {
        try {
            utag.data = (typeof utag_data != 'undefined') ? utag_data : {};
            utag.udoname = 'utag_data';
        } catch (e) {
            utag.data = {};
            utag.DB('idf:' + e);
        }
    };
    utag.loader.loadrules = function(_pd, _pc) {
        var d = _pd || utag.data;
        var c = _pc || utag.cond;
        for (var l in utag.loader.GV(c)) {
            switch (l) {
                case '104':
                    try {
                        c[104] |= (d['cat_id'].toString().toLowerCase() == '71'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '105':
                    try {
                        c[105] |= (d['eventname'].toString().toLowerCase() == 'depository'.toLowerCase() && d['path'].toString().toLowerCase() == 'ad_insertion'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '71'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '71'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '71'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '106':
                    try {
                        c[106] |= (d['eventname'].toString().toLowerCase() == 'ad_view::detail'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '71'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '107':
                    try {
                        c[107] |= (d['cat_id'].toString().toLowerCase() == '66'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '108':
                    try {
                        c[108] |= (d['eventname'].toString().toLowerCase() == 'depository'.toLowerCase() && d['path'].toString().toLowerCase() == 'ad_insertion'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '66'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '66'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '66'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '109':
                    try {
                        c[109] |= (d['eventname'].toString().toLowerCase() == 'ad_view::detail'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '66'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '110':
                    try {
                        c[110] |= (d['cat_id'].toString().toLowerCase() == '24'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '18'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '72'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '14'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '111':
                    try {
                        c[111] |= (d['eventname'].toString().toLowerCase() == 'depository'.toLowerCase() && d['path'].toString().toLowerCase() == 'ad_insertion'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '24'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '24'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '24'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'depository'.toLowerCase() && d['path'].toString().toLowerCase() == 'ad_insertion'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '18'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '18'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '18'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'depository'.toLowerCase() && d['path'].toString().toLowerCase() == 'ad_insertion'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '72'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '72'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '72'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'depository'.toLowerCase() && d['path'].toString().toLowerCase() == 'ad_insertion'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '14'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '14'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '14'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '112':
                    try {
                        c[112] |= (d['eventname'].toString().toLowerCase() == 'p2p::payin::confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '24'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::payin::direct_confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '24'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::payin::confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '18'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::payin::direct_confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '18'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::payin::confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '72'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::payin::direct_confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '72'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::payin::confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '14'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::payin::direct_confirmation'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '14'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '113':
                    try {
                        c[113] |= (d['js_page.gdprConditionnementP1'] == '1')
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '119':
                    try {
                        c[119] |= (d['dom.url'].toString().toLowerCase().indexOf('/_vacances_/offres/'.toLowerCase()) > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '121':
                    try {
                        c[121] |= (d['event_name'].toString().toLowerCase().indexOf('ad_reply::online_booking'.toLowerCase()) > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '123':
                    try {
                        c[123] |= (d['dom.url'].toString().toLowerCase().indexOf('/recherche/?category=72&shippable=1&shipping_type=mondial_relay'.toLowerCase()) > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '124':
                    try {
                        c[124] |= (d['eventname'].toString().toLowerCase().indexOf('p2p::payin::direct_confirmation'.toLowerCase()) > -1 && d['cat_id'].toString().toLowerCase() == '72'.toLowerCase()) || (d['eventname'].toString().toLowerCase().indexOf('p2p::payin::confirmation'.toLowerCase()) > -1 && d['cat_id'].toString().toLowerCase() == '72'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '127':
                    try {
                        c[127] |= (d['eventname'].toString().toLowerCase() == 'ad_view::detail'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '66'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '128':
                    try {
                        c[128] |= (d['eventname'].toString().toLowerCase() == 'ad_reply::email::formulaire'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '66'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '129':
                    try {
                        c[129] |= (d['eventname'].toString().toLowerCase() == 'ad_view::detail'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '72'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '130':
                    try {
                        c[130] |= (d['eventname'].toString().toLowerCase() == 'ad_reply::email::formulaire'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '72'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '135':
                    try {
                        c[135] |= (d['eventname'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().toLowerCase() == 'message_sent_succeed'.toLowerCase() && d['cat_id'].toString().toLowerCase() == '71'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '138':
                    try {
                        c[138] |= (d['event_name'].toString().indexOf('contact') > -1 && d['cat_id'].toString().toLowerCase() == '66'.toLowerCase() && d['action'].toString().indexOf('display_telephone_number') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '139':
                    try {
                        c[139] |= (d['dom.pathname'].toString().indexOf('/_vacances_/offres') > -1) || (d['dom.pathname'].toString().indexOf('/recherche?category=66') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '140':
                    try {
                        c[140] |= (d['event_name'].toString().toLowerCase() == 'ad_search'.toLowerCase() && d['cat_id'].toString().indexOf('66') > -1) || (d['event_name'].toString().toLowerCase() == 'maps'.toLowerCase() && d['cat_id'].toString().indexOf('66') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '141':
                    try {
                        c[141] |= (d['event_name'].toString().indexOf('ad_view::detail') > -1 && d['cat'].toString().indexOf('vacances') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '142':
                    try {
                        c[142] |= (d['action'].toString().toLowerCase() == 'contact_click'.toLowerCase() && d['cat_id'].toString().indexOf('66') > -1) || (d['action'].toString().indexOf('display_telephone_number') > -1 && d['cat_id'].toString().indexOf('66') > -1) || (d['action'].toString().indexOf('online_booking_click') > -1 && d['cat_id'].toString().indexOf('66') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '147':
                    try {
                        c[147] |= (d['eventname'].toString().toLowerCase() == 'depository'.toLowerCase() && d['path'].toString().toLowerCase() == 'ad_insertion'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'confirmation'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '148':
                    try {
                        c[148] |= (d['eventname'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().toLowerCase() == 'display_telephone_number'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '149':
                    try {
                        c[149] |= (d['eventname'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().indexOf('message_sent_succeed') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '150':
                    try {
                        c[150] |= (d['eventname'].toString().toLowerCase() == 'p2p::adview::direct_cta_spotlight'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::adview::direct_cta_adview'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::adview::direct_cta_tabbar'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::adview::direct_cta_sticky'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '151':
                    try {
                        c[151] |= (d['eventname'].toString().toLowerCase() == 'p2p::payin::confirmation'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::payin::direct_confirmation'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '152':
                    try {
                        c[152] |= (d['eventname'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().toLowerCase() == 'display_telephone_number'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().toLowerCase() == 'display_telephone_number'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '153':
                    try {
                        c[153] |= (d['eventname'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().toLowerCase() == 'apply_click'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '154':
                    try {
                        c[154] |= (d['eventname'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().toLowerCase() == 'message_sent_succeed'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().toLowerCase() == 'message_sent_succeed'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '156':
                    try {
                        c[156] |= (d['cat_id'].toString().toLowerCase() == '71'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '157':
                    try {
                        c[157] |= (d['cat_id'].toString().toLowerCase() == '66'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '158':
                    try {
                        c[158] |= (d['cat_id'].toString().toLowerCase() == '72'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '18'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '14'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '24'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '159':
                    try {
                        c[159] |= (d['eventname'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().toLowerCase() == 'online_booking_click'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'contact'.toLowerCase() && d['action'].toString().toLowerCase() == 'dates_online_booking_click'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '160':
                    try {
                        c[160] |= (d['path'].toString().toLowerCase() == 'booking'.toLowerCase() && d['eventname'].toString().toLowerCase() == 'holidays'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'payment_confirmation'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '162':
                    try {
                        c[162] |= (d['eventname'].toString().toLowerCase() == 'depository'.toLowerCase() && d['path'].toString().toLowerCase() == 'ad_insertion'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'confirmation'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '163':
                    try {
                        c[163] |= (d['path'].toString().toLowerCase() == 'booking'.toLowerCase() && d['eventname'].toString().toLowerCase() == 'holidays'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'payment_form'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '164':
                    try {
                        c[164] |= (d['cat'].toString().toLowerCase().indexOf('mode'.toLowerCase()) > -1) || (d['cat'].toString().toLowerCase().indexOf('maison'.toLowerCase()) > -1) || (d['cat'].toString().toLowerCase().indexOf('multimedia'.toLowerCase()) > -1) || (d['cat'].toString().toLowerCase().indexOf('loisirs'.toLowerCase()) > -1) || (d['cat'].toString().toLowerCase().indexOf('emploi'.toLowerCase()) > -1) || (d['cat_id'].toString().toLowerCase() == '72'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '18'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '14'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '24'.toLowerCase()) || (d['cat_id'].toString().toLowerCase() == '71'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '166':
                    try {
                        c[166] |= (d['eventname'].toString().indexOf('contact') > -1 && d['action'].toString().indexOf('message_sent_succeed') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '167':
                    try {
                        c[167] |= (d['eventname'].toString().indexOf('contact') > -1 && d['action'].toString().indexOf('display_telephone_number') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '168':
                    try {
                        c[168] |= (d['eventname'].toString().indexOf('contact') > -1 && d['action'].toString().indexOf('apply_click') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '169':
                    try {
                        c[169] |= (d['eventname'].toString().indexOf('contact') > -1 && d['action'].toString().indexOf('online_booking_click') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '170':
                    try {
                        c[170] |= (d['page_name'].toString().indexOf('multi_apply') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '171':
                    try {
                        c[171] |= (d['cat_id'] != '14') || (d['cat_id'] != '72') || (d['cat_id'].toString().indexOf('18') > -1) || (d['cat_id'].toString().indexOf('24') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '172':
                    try {
                        c[172] |= (d['eventname'].toString().toLowerCase().indexOf('contact'.toLowerCase()) > -1 && d['action'].toString().toLowerCase() == 'display_telephone_number'.toLowerCase()) || (d['event_name'].toString().toLowerCase().indexOf('contact'.toLowerCase()) > -1 && d['action'].toString().toLowerCase() == 'apply_click'.toLowerCase()) || (d['eventname'].toString().toLowerCase().indexOf('contact'.toLowerCase()) > -1 && d['action'].toString().toLowerCase() == 'message_sent_succeed'.toLowerCase()) || (d['page_name'].toString().toLowerCase().indexOf('multi_apply'.toLowerCase()) > -1 && d['action'].toString().toLowerCase() == 'direct_contact_succeed'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '173':
                    try {
                        c[173] |= (d['page_name'].toString().toLowerCase() == 'multi_apply'.toLowerCase() && d['action'].toString().toLowerCase() == 'direct_contact_succeed'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '174':
                    try {
                        c[174] |= (d['pagetype'].toString().toLowerCase() == 'p2p'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '176':
                    try {
                        c[176] |= (d['subcat_id'].toString().indexOf('19') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '177':
                    try {
                        c[177] |= (d['subcat_id'].toString().indexOf('19') < 0)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '178':
                    try {
                        c[178] |= (d['pagetype'].toString().indexOf('accueil') > -1) || (d['pagetype'].toString().indexOf('annonce_deposer') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '179':
                    try {
                        c[179] |= (d['eventname'].toString().toLowerCase() == 'ad_view::detail'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '180':
                    try {
                        c[180] |= (d['event_name'].toString().toLowerCase() == 'ad_search'.toLowerCase() && d['pagename'].toString().indexOf('listing') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '184':
                    try {
                        c[184] |= (d['cat_id'].toString().indexOf('14') > -1)
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '187':
                    try {
                        c[187] |= (d['cat'].toString().toLowerCase().indexOf('_immobilier_'.toLowerCase()) > -1) || (d['cat_id'].toString().toLowerCase() == '8'.toLowerCase()) || (d['category_id'].toString().toLowerCase() == '8'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '32':
                    try {
                        c[32] |= (d['pagename'] == 'paid_by_credits' && d['cat'] == 'emploi') || (d['pagename'] == 'confirm_no_pay' && d['cat'] == 'emploi') || (d['pagename'] == 'endofprocess' && d['cat'] == 'emploi')
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '77':
                    try {
                        c[77] |= (d['eventname'].toString().toLowerCase() == 'depository'.toLowerCase() && d['path'].toString().toLowerCase() == 'ad_insertion'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'confirmation'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'ad_depot::D3 confirmation'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '82':
                    try {
                        c[82] |= (d['eventname'].toString().toLowerCase() == 'p2p::payin::confirmation'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::payin::direct_confirmation'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '83':
                    try {
                        c[83] |= (d['eventname'].toString().toLowerCase() == 'creation_compte_part::activation_confirmation'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'creation%20compte%20part%3A%3Aactivation%20confirmation'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'creation%20compte%20part::activation%20confirmation'.toLowerCase()) || (d['event_name'].toString().toLowerCase() == 'creation compte part::activation confirmation'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '85':
                    try {
                        c[85] |= (d['eventname'].toString().toLowerCase() == 'authent'.toLowerCase() && d['path'].toString().toLowerCase() == 'account_creation'.toLowerCase() && d['step_name'].toString().toLowerCase() == 'account_creation_confirmation'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '89':
                    try {
                        c[89] |= (d['eventname'].toString().toLowerCase() == 'p2p::adview::direct_cta_spotlight'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::adview::direct_cta_adview'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::adview::direct_cta_tabbar'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::adview::direct_cta_sticky'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '90':
                    try {
                        c[90] |= (d['eventname'].toString().toLowerCase() == 'p2p::adview::offer_cta_adview'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::adview::offer_cta_spotlight'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::adview::offer_cta_tabbar'.toLowerCase()) || (d['eventname'].toString().toLowerCase() == 'p2p::adview::offer_cta_sticky'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
                case '92':
                    try {
                        c[92] |= (d['eventname'].toString().toLowerCase() == 'ad_view::detail'.toLowerCase())
                    } catch (e) {
                        utag.DB(e)
                    };
                    break;
            }
        }
    };
    utag.pre = function() {
        utag.loader.initdata();
        utag.pagevars();
        try {
            utag.loader.RD(utag.data)
        } catch (e) {
            utag.DB(e)
        };
        utag.loader.loadrules();
    };
    utag.loader.GET = function() {
        utag.cl = {
            '_all_': 1
        };
        utag.pre();
        utag.handler.extend = [function(a, b) {
            var prop;
            if (a === "view" && b.displaytype) {
                for (prop in utag.data) {
                    if (!b[prop]) {
                        b[prop] = utag.data[prop];
                    }
                }
            }
        }, function(a, b) {
            try {
                if (1) {
                    var purposeVersion1 = "cookies";
                    var gdprConditionnementP1 = 0;
                    b['js_page.gdprConditionnementP1'] = gdprConditionnementP1;
                    if (!window.Didomi && !window.didomiState && !window.didomiState.didomiIABConsent) {
                        b['js_page.gdprConditionnementP1'] = 0;
                    } else {
                        var consentPurpose1 = Didomi.getUserConsentStatusForPurpose(purposeVersion1);
                        b['js_page.gdprConditionnementP1'] = consentPurpose1 ? 1 : 0;
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    b['js_page.uabValue'] = window.abp.toString();
                    b['uab'] = window.abp.toString();
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (b['dom.hash'].toString().indexOf('') > -1) {
                    try {
                        b['js_page.protocol'] = document.location.protocol;
                    } catch (e) {}
                }
            } catch (e) {
                utag.DB(e);
            }
        }, function(a, b, c, d, e, f, g) {
            if (1) {
                d = b['js_page.protocol'];
                if (typeof d == 'undefined') return;
                c = [{
                    'http:': 'http://logw360'
                }, {
                    'https:': 'https://logws1360'
                }];
                var m = false;
                for (e = 0; e < c.length; e++) {
                    for (f in utag.loader.GV(c[e])) {
                        if (d == f) {
                            b['js_page.xtsd'] = c[e][f];
                            m = true
                        };
                    };
                    if (m) break
                };
                if (!m) b['js_page.xtsd'] = 'http://logw360';
            }
        }, function(a, b, c, d, e, f, g) {
            if (1) {
                d = b['pagetype'];
                if (typeof d == 'undefined') return;
                c = [{
                    'accueil': '1'
                }, {
                    'recherche': '8'
                }, {
                    'annonce': '2'
                }, {
                    'recherche_automatique': '7'
                }, {
                    'annonces_sauvegardees': '7'
                }, {
                    'erreur_technique': '6'
                }, {
                    'annonce_contacter': '4'
                }, {
                    'compte': '5'
                }, {
                    'annonce_deposer': '3'
                }, {
                    'annonce_modifier': '3'
                }, {
                    'annonce_prolonger': '3'
                }, {
                    'annonce_supprimer': '3'
                }, {
                    'annonce_gerer': '3'
                }, {
                    'annonces_en_ligne': '7'
                }, {
                    'contenu': '7'
                }, {
                    'annonce_partager': '2'
                }, {
                    'annonce_signaler': '2'
                }, {
                    'connexion': '5'
                }, {
                    'deconnexion': '5'
                }, {
                    'messaging': '11'
                }, {
                    'soyouz': '10'
                }, {
                    'saved_ads': '12'
                }, {
                    'saved_search': '13'
                }, {
                    'shop_part': '14'
                }, {
                    'shop_pro': '15'
                }, {
                    'p2p': '19'
                }];
                var m = false;
                for (e = 0; e < c.length; e++) {
                    for (f in utag.loader.GV(c[e])) {
                        if (d == f) {
                            b['js_page.xtn2'] = c[e][f];
                            m = true
                        };
                    };
                    if (m) break
                };
                if (!m) b['js_page.xtn2'] = '0';
            }
        }, function(a, b) {
            try {
                if (1) {
                    b.eventname = b.eventname || b.event_name;
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b, c, d) {
            try {
                if (1) {
                    c = ['web_responsive', b['device']];
                    b['js_page.plateformdevice'] = c.join('-')
                }
            } catch (e) {
                utag.DB(e);
            }
        }, function(a, b, c, d, e, f, g) {
            if (1) {
                d = b['eventname'];
                if (typeof d == 'undefined') return;
                c = [{
                    'ad_search': 'ad_search'
                }, {
                    'shop::ad_search': 'ad_search'
                }, {
                    'shop::shop_listing': 'shop_search'
                }, {
                    'ad_view::detail': 'ad_view'
                }, {
                    'ad_view::partage::email_ami::confirmation': 'ad_share_email'
                }, {
                    'ad_view::sauvegarde::confirmation': 'ad_save'
                }, {
                    'ad_view::gerer_annonce::supprimer::confirmation': 'ad_action_deletion'
                }, {
                    'ad_view::signaler_abus::confirmation': 'ad_report'
                }, {
                    'ad_reply::telephone::voir_le_numero': 'ad_reply_phone'
                }, {
                    'ad_reply::telephone::appeler_le_vendeur': 'ad_reply_phone'
                }, {
                    'ad_reply::telephone::envoyer_sms': 'ad_reply_sms'
                }, {
                    'ad_view::gerer_annonce::modifier': 'ad_action_modify'
                }, {
                    'ad_view::gerer_annonce::supprimer': 'ad_action_deletion'
                }, {
                    'ad_view::gerer_annonce::mettre_en_avant': 'ad_action_highlight'
                }, {
                    'ad_view::gerer_annonce::remonter_en_tete_de_liste': 'ad_action_bump'
                }, {
                    'connexion': 'connexion'
                }, {
                    'deconnexion': 'deconnexion'
                }, {
                    'ad_reply::email::confirmation': 'ad_reply_email'
                }];
                var m = false;
                for (e = 0; e < c.length; e++) {
                    for (f in utag.loader.GV(c[e])) {
                        if (d == f) {
                            b['js_page.actiondescription'] = c[e][f];
                            m = true
                        };
                    };
                    if (m) break
                };
                if (!m) b['js_page.actiondescription'] = '';
            }
        }, function(a, b) {
            if (b.eventname === "ad_search" || b.eventname === "ad_view::detail" || b.eventname === "shop::ad_search" || b.eventname === "shop::shop_listing") {
                if (b.cat_id === undefined || b.cat_id === "") {
                    b.cat_id = 0;
                }
            }
        }, function(a, b) {
            if (b.eventname === "ad_search" || b.eventname === "ad_view::detail" || b.eventname === "shop::ad_search" || b.eventname === "shop::shop_listing") {
                if (b.subcat_id === undefined || b.subcat_id === "") {
                    b.subcat_id = 0;
                }
            }
        }, function(a, b) {
            if (b.eventname === "ad_view::detail" || b.eventname === "ad_reply::email::formulaire" || b.eventname === "depository") {
                if (b.options != undefined) {
                    var options = "";
                    for (var i in b.options) {
                        if (i != 0) {
                            if (b.options.hasOwnProperty(i)) {
                                if (b.options[i] === "1") {
                                    options += "|" + i;
                                }
                            }
                        }
                    }
                    if (options === "") {
                        b.options = "|sans options|";
                    } else {
                        b.options = options + "|";
                    }
                }
            } else {
                b.options = "";
            }
        }, function(a, b) {
            if (b.eventname === "ad_search" || b.eventname === "ad_view::detail") {
                if (b.offres === undefined) {
                    b.offres = "toutes"
                }
            }
        }, function(a, b) {
            if (b.eventname === "ad_search" && b.city != undefined) {
                var city = "";
                if (b.city instanceof Array) {
                    for (var i = 0; i < b.city.length; i++) {
                        city += "|" + b.city[i];
                    }
                    b.city = city + "|";
                }
            }
        }, function(a, b) {
            if (b.compte == 0) {
                b.compte = "";
            }
        }, function(a, b) {
            var utagenv = utag.cfg.path.split("/")[6];
            window.xtparam = "&utagversion=" + utag.cfg.v + "&utagjsenv=" + utagenv;
            atinternet.setParam("utagversion", utag.cfg.v);
            atinternet.setParam("utagjsenv", utagenv);
        }, function(a, b) {
            if (b.eventname === "ad_search") {
                var qs_th = location.search.split('th=')[1];
                var qs_o = location.search.split('o=')[1];
                var qs_q = location.search.split('q=')[1];
                var qs_f = location.search.split('f=')[1];
                if (b.search != undefined) {
                    window.xt_mtcl = b.search;
                }
                if (b.search === undefined && qs_th != undefined) {
                    window.xt_mtcl = "recherche_sans_mot_cle";
                }
                if (b.search === undefined && qs_o != undefined && qs_q === undefined) {
                    window.xt_mtcl = "recherche_sans_mot_cle";
                }
                window.xt_npg = b.pagenumber;
                if (window.xtparam != null) {
                    window.xtparam += "&mc=" + xt_mtcl + "&np=" + xt_npg;
                } else {
                    window.xtparam = "&mc=" + xt_mtcl + "&np=" + xt_npg;
                }
            }
        }, function(a, b) {
            if (b.eventname === "ad_view::detail") {
                var xt_cart_tmp = function() {
                    xt_addProduct_load("[ads]::[" + b.ad_type + "]::[" + b.cat + "]::[" + b.subcat + "]::[" + b.offres + "]", b.listid);
                };
                window.xt_cart = xt_cart_tmp;
            }
        }, function(a, b) {
            if (b.eventname === "ad_search") {
                window.xt_aisle = "[ads]::[" + b.ad_type + "]::[" + b.cat + "]::[" + b.subcat + "]";
                if (b.offres != undefined) {
                    window.xt_aisle += "::[" + b.offres + "]";
                }
                if (window.xtparam != null) {
                    window.xtparam += "&aisl=" + xt_aisle;
                } else {
                    window.xtparam = "&aisl=" + xt_aisle;
                }
            }
        }, function(a, b, c, d, e, f, g) {
            if (1) {
                d = b['eventname'];
                if (typeof d == 'undefined') return;
                c = [{
                    'ad_view::detail': '1'
                }, {
                    'ad_search': '2'
                }, {
                    'ad_reply::telephone::voir_le_numero': '3'
                }, {
                    'ad_reply::email::envoyer_email': '3'
                }, {
                    'ad_depot::D3_confirmation': '4'
                }, {
                    '::facture::cb': '5'
                }, {
                    '::facture::credit': '5'
                }, {
                    '::facture::hybride': '5'
                }];
                var m = false;
                for (e = 0; e < c.length; e++) {
                    for (f in utag.loader.GV(c[e])) {
                        if (d.toString().indexOf(f) > -1) {
                            b['xiti_implication_degree'] = c[e][f];
                            m = true
                        };
                    };
                    if (m) break
                };
                if (!m) b['xiti_implication_degree'] = '0';
            }
        }, function(a, b) {
            function createCookie(name, value, days) {
                if (days) {
                    var date = new Date();
                    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                    var expires = "; expires=" + date.toGMTString();
                } else {
                    var expires = "";
                }
                document.cookie = name + "=" + value + expires + "; path=/";
            }

            function readCookie(name) {
                var nameEQ = name + "=";
                var ca = document.cookie.split(';');
                for (var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
                }
                return null;
            }

            function eraseCookie(name) {
                createCookie(name, "", -1);
            }

            function logXiti(foo) {
                if (utag_data.environnement === "dev" || utag_data.environnement === "qa") {}
            }
            var my_parcours = utag_data.eventname.split("::");
            var parcours = my_parcours["0"];
            var step = my_parcours["1"];
            var moyen_paiement = my_parcours["2"];
            if (step === "preview" || step === "paiement" || step === "facture" || step === "facture_editrefused" || step === "paiement_editrefused" || step === "D1_depot_editrefused" || step === "D2_verification_editrefused") {
                logXiti("je suis bien sur une page SalesTracker");
                var mp = {
                    "CB": 1,
                    "hybride": 11,
                    "credit": 10
                };
                if (utag_data.listid) {
                    var NomCookiePanier = "panierXiti_" + utag_data.listid;
                    logXiti("le listid existe : " + utag_data.listid);
                } else {
                    var NomCookiePanier = "panierXiti";
                    logXiti("le listid n'existe pas");
                }
                logXiti("NomCookiePanier = " + NomCookiePanier);
                var idcart = "" + readCookie(NomCookiePanier);
                logXiti("idcart = " + idcart);
                if (idcart == "null") {
                    createCookie(NomCookiePanier, Math.round(new Date().getTime() / 1000.0), 0);
                    idcart = readCookie(NomCookiePanier);
                    logXiti("je dois cr�er le cookie, voici son ID :" + idcart);
                } else {
                    idcart = readCookie(NomCookiePanier);
                    logXiti("le panier existe d�j�, voici son ID :" + idcart);
                }
                var roimt = utag_data.amount_ttc;
                for (var iter = 0; iter < utag_data.nboptions; iter++) {
                    j = iter + 1;
                    if (utag_data.nboptions == "1") {
                        idcart += "&pdt" + j + "=" + utag_data.newoptions + "[" + utag_data.newoptions + "]&roimt" + j + "=" + utag_data.newoptions_amount.replace(",", ".") + "&qte" + j + "=" + utag_data.newoptions_quantity + "&mt" + j + "=" + utag_data.newoptions_amount.replace(",", ".");
                        logXiti(idcart);
                    } else {
                        idcart += "&pdt" + j + "=" + utag_data.newoptions[iter] + "[" + utag_data.newoptions[iter] + "]&roimt" + j + "=" + utag_data.newoptions_amount[iter].replace(",", ".") + "&qte" + j + "=" + utag_data.newoptions_quantity[iter] + "&mt" + j + "=" + utag_data.newoptions_amount[iter].replace(",", ".");
                    }
                }
                if (step === "facture" || step === "facture_editrefused") {
                    if (utag_data.listid != undefined) {
                        function random_cmd() {
                            var d = new Date();
                            var D = d.getDate();
                            var M = d.getMonth() + 1;
                            var Y = d.getFullYear();
                            var h = d.getHours();
                            var m = d.getMinutes();
                            var s = d.getSeconds();
                            var rdm = Y + '' + D + '' + M + '' + h + '' + m + '' + s;
                            return rdm;
                        }
                        var cmd_id = utag_data.listid + "_" + random_cmd();
                    } else {
                        var cmd_id = readCookie(NomCookiePanier);
                    }
                    idcart += "&cmd=" + cmd_id + "&roimt=" + roimt + "&mp=" + mp[moyen_paiement] + "&o1=" + parcours;
                    eraseCookie(NomCookiePanier);
                }
                if (window.xtparam != null) {
                    window.xtparam += "&idcart=" + idcart;
                } else {
                    window.xtparam = "&idcart=" + idcart;
                }
                logXiti("xtparam = " + window.xtparam);
            } else {
                logXiti("je ne suis pas sur une page SalesTracker");
                logXiti(utag_data);
            }
        }, function(a, b) {
            window.xtcustom = window.xtcustom || {};
            window.xtcustom.device = b.displaytype;
        }, function(a, b, c, d, e, f, g) {
            if (1) {
                d = b['eventname'];
                if (typeof d == 'undefined') return;
                c = [{
                    'employ': '0'
                }];
                var m = false;
                for (e = 0; e < c.length; e++) {
                    for (f in utag.loader.GV(c[e])) {
                        if (d == f) {
                            b['js_page.xtn2'] = c[e][f];
                            m = true
                        };
                    };
                    if (m) break
                };
            }
        }, function(a, b) {
            if (typeof window.innerWidth != 'undefined') {
                viewportwidth = window.innerWidth;
                viewportheight = window.innerHeight;
                if (viewportheight > viewportwidth) {
                    b.orientation = "portrait";
                } else if (viewportheight < viewportwidth) {
                    b.orientation = "landscape";
                } else if (viewportheight == viewportwidth) {
                    b.orientation = "square";
                } else {
                    b.orientation = "error";
                }
            }
        }, function(a, b) {
            try {
                utag.runonce = utag.runonce || {};
                utag.runonce.ext = utag.runonce.ext || {};
                if (typeof utag.runonce.ext[665] == 'undefined') {
                    utag.runonce.ext[665] = 1;
                    if (1) {
                        ! function(e) {
                            if (!window.pintrk) {
                                window.pintrk = function() {
                                    window.pintrk.queue.push(Array.prototype.slice.call(arguments))
                                };
                                var n = window.pintrk;
                                n.queue = [], n.version = "3.0";
                                var t = document.createElement("script");
                                t.async = !0, t.src = e;
                                var r = document.getElementsByTagName("script")[0];
                                r.parentNode.insertBefore(t, r)
                            }
                        }("https://s.pinimg.com/ct/core.js");
                        pintrk('load', '2613083218612', {
                            em: ''
                        });
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }];
        utag.handler.cfg_extend = [{
            "blr": 1,
            "id": "170",
            "alr": 0,
            "bwq": 0,
            "end": 0
        }, {
            "alr": 0,
            "bwq": 0,
            "end": 0,
            "blr": 1,
            "id": "581"
        }, {
            "id": "583",
            "blr": 1,
            "end": 0,
            "bwq": 0,
            "alr": 0
        }, {
            "alr": 1,
            "bwq": 0,
            "end": 0,
            "blr": 0,
            "id": "49"
        }, {
            "alr": 1,
            "bwq": 0,
            "end": 0,
            "blr": 0,
            "id": "50"
        }, {
            "id": "43",
            "blr": 0,
            "end": 0,
            "bwq": 0,
            "alr": 1
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 1,
            "id": "436",
            "blr": 0
        }, {
            "id": "56",
            "blr": 0,
            "end": 0,
            "bwq": 0,
            "alr": 1
        }, {
            "blr": 0,
            "id": "55",
            "alr": 1,
            "bwq": 0,
            "end": 0
        }, {
            "alr": 1,
            "bwq": 0,
            "end": 0,
            "blr": 0,
            "id": "75"
        }, {
            "blr": 0,
            "id": "79",
            "alr": 1,
            "bwq": 0,
            "end": 0
        }, {
            "id": "157",
            "blr": 0,
            "end": 0,
            "bwq": 0,
            "alr": 1
        }, {
            "id": "76",
            "blr": 0,
            "end": 0,
            "bwq": 0,
            "alr": 1
        }, {
            "id": "161",
            "blr": 0,
            "end": 0,
            "bwq": 0,
            "alr": 1
        }, {
            "blr": 0,
            "id": "81",
            "alr": 1,
            "bwq": 0,
            "end": 0
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 1,
            "id": "78",
            "blr": 0
        }, {
            "id": "60",
            "blr": 0,
            "end": 0,
            "bwq": 0,
            "alr": 1
        }, {
            "blr": 0,
            "id": "64",
            "alr": 1,
            "bwq": 0,
            "end": 0
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 1,
            "id": "59",
            "blr": 0
        }, {
            "blr": 0,
            "id": "180",
            "alr": 1,
            "bwq": 0,
            "end": 0
        }, {
            "blr": 0,
            "id": "181",
            "alr": 1,
            "bwq": 0,
            "end": 0
        }, {
            "blr": 0,
            "id": "313",
            "alr": 1,
            "bwq": 0,
            "end": 0
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 1,
            "id": "533",
            "blr": 0
        }, {
            "blr": 0,
            "id": "253",
            "alr": 1,
            "bwq": 0,
            "end": 0
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 1,
            "id": "665",
            "blr": 0
        }];
        utag.loader.initcfg = function() {
            utag.loader.cfg = {
                "43": {
                    load: 1,
                    send: 1,
                    v: 201702140833,
                    wait: 1,
                    tid: 20010
                },
                "24": {
                    load: 1,
                    send: 1,
                    v: 202311281602,
                    wait: 1,
                    tid: 1101
                },
                "27": {
                    load: 1,
                    send: 1,
                    v: 202311281602,
                    wait: 1,
                    tid: 20010
                },
                "57": {
                    load: (utag.cond[113] && utag.cond[178]),
                    send: 1,
                    v: 202311281602,
                    wait: 1,
                    tid: 20010
                },
                "94": {
                    load: 1,
                    send: 1,
                    v: 201810111222,
                    wait: 1,
                    tid: 20010
                },
                "207": {
                    load: 1,
                    send: 1,
                    v: 202103221308,
                    wait: 1,
                    tid: 20010
                },
                "203": {
                    load: utag.cond[77],
                    send: 1,
                    v: 202103221308,
                    wait: 1,
                    tid: 20010
                },
                "205": {
                    load: utag.cond[82],
                    send: 1,
                    v: 202103221308,
                    wait: 1,
                    tid: 20010
                },
                "214": {
                    load: (utag.cond[85] || utag.cond[83]),
                    send: 1,
                    v: 202103221308,
                    wait: 1,
                    tid: 20010
                },
                "212": {
                    load: utag.cond[169],
                    send: 1,
                    v: 202204071610,
                    wait: 1,
                    tid: 20010
                },
                "211": {
                    load: utag.cond[168],
                    send: 1,
                    v: 202204071610,
                    wait: 1,
                    tid: 20010
                },
                "216": {
                    load: utag.cond[166],
                    send: 1,
                    v: 202204071610,
                    wait: 1,
                    tid: 20010
                },
                "252": {
                    load: utag.cond[113],
                    send: 1,
                    v: 202103081444,
                    wait: 1,
                    tid: 4049
                },
                "255": {
                    load: utag.cond[113],
                    send: 1,
                    v: 202110121512,
                    wait: 1,
                    tid: 4001
                },
                "285": {
                    load: utag.cond[92],
                    send: 1,
                    v: 202204071610,
                    wait: 1,
                    tid: 20010
                },
                "286": {
                    load: utag.cond[167],
                    send: 1,
                    v: 202204071610,
                    wait: 1,
                    tid: 20010
                },
                "296": {
                    load: 1,
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "297": {
                    load: utag.cond[162],
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "298": {
                    load: (utag.cond[160] || utag.cond[82]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "299": {
                    load: utag.cond[152],
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "300": {
                    load: utag.cond[154],
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "301": {
                    load: (((utag.cond[158] || utag.cond[187]) && (utag.cond[113]))),
                    send: 1,
                    v: 202309131314,
                    wait: 1,
                    tid: 20010
                },
                "302": {
                    load: (((utag.cond[158] || utag.cond[187]) && (utag.cond[113]) && (utag.cond[152]))),
                    send: 1,
                    v: 202309131314,
                    wait: 1,
                    tid: 20010
                },
                "303": {
                    load: (utag.cond[164] && utag.cond[162]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "304": {
                    load: utag.cond[89],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "305": {
                    load: (utag.cond[82] && utag.cond[174]),
                    send: 1,
                    v: 202207201158,
                    wait: 1,
                    tid: 20010
                },
                "306": {
                    load: utag.cond[90],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "308": {
                    load: (((utag.cond[158] || utag.cond[187]) && (utag.cond[154]))),
                    send: 1,
                    v: 202309131314,
                    wait: 1,
                    tid: 20010
                },
                "309": {
                    load: 1,
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "311": {
                    load: utag.cond[138],
                    send: 1,
                    v: 202104291305,
                    wait: 1,
                    tid: 20010
                },
                "312": {
                    load: (utag.cond[157] && utag.cond[159]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "313": {
                    load: (utag.cond[157] && utag.cond[154]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "314": {
                    load: utag.cond[163],
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "315": {
                    load: utag.cond[156],
                    send: 1,
                    v: 202203031419,
                    wait: 1,
                    tid: 20010
                },
                "316": {
                    load: (utag.cond[156] && utag.cond[152]),
                    send: 1,
                    v: 202203031419,
                    wait: 1,
                    tid: 20010
                },
                "317": {
                    load: (utag.cond[156] && utag.cond[153]),
                    send: 1,
                    v: 202203031419,
                    wait: 1,
                    tid: 20010
                },
                "318": {
                    load: utag.cond[135],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "319": {
                    load: utag.cond[104],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "320": {
                    load: utag.cond[105],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "321": {
                    load: utag.cond[106],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "322": {
                    load: utag.cond[107],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "323": {
                    load: utag.cond[108],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "324": {
                    load: utag.cond[109],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "325": {
                    load: utag.cond[110],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "326": {
                    load: utag.cond[111],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "327": {
                    load: utag.cond[112],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "328": {
                    load: utag.cond[110],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "329": {
                    load: utag.cond[111],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "330": {
                    load: utag.cond[129],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "331": {
                    load: utag.cond[130],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "332": {
                    load: utag.cond[127],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "333": {
                    load: utag.cond[128],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 20010
                },
                "334": {
                    load: (utag.cond[32] && utag.cond[113]),
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 7117
                },
                "335": {
                    load: utag.cond[113],
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 7129
                },
                "338": {
                    load: (utag.cond[113] && utag.cond[119]),
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 4001
                },
                "339": {
                    load: (utag.cond[121] && utag.cond[113]),
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 4001
                },
                "340": {
                    load: (utag.cond[113] && utag.cond[123]),
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 4001
                },
                "341": {
                    load: (utag.cond[124] && utag.cond[113]),
                    send: 1,
                    v: 202103220944,
                    wait: 1,
                    tid: 4001
                },
                "343": {
                    load: (utag.cond[139] && utag.cond[113]),
                    send: 1,
                    v: 202105311237,
                    wait: 1,
                    tid: 3167
                },
                "344": {
                    load: (utag.cond[140] && utag.cond[113]),
                    send: 1,
                    v: 202106041306,
                    wait: 1,
                    tid: 3167
                },
                "345": {
                    load: (utag.cond[141] && utag.cond[113]),
                    send: 1,
                    v: 202106021545,
                    wait: 1,
                    tid: 3167
                },
                "346": {
                    load: (utag.cond[142] && utag.cond[113]),
                    send: 1,
                    v: 202106041358,
                    wait: 1,
                    tid: 3167
                },
                "355": {
                    load: (utag.cond[158] && utag.cond[113]),
                    send: 1,
                    v: 202304041605,
                    wait: 1,
                    tid: 20010
                },
                "356": {
                    load: (utag.cond[158] && utag.cond[147] && utag.cond[113]),
                    send: 1,
                    v: 202203031419,
                    wait: 1,
                    tid: 20010
                },
                "357": {
                    load: (utag.cond[158] && utag.cond[113] && utag.cond[148]),
                    send: 1,
                    v: 202203031419,
                    wait: 1,
                    tid: 20010
                },
                "358": {
                    load: (utag.cond[149] && utag.cond[158] && utag.cond[113]),
                    send: 1,
                    v: 202203031419,
                    wait: 1,
                    tid: 20010
                },
                "359": {
                    load: (utag.cond[150] && utag.cond[158] && utag.cond[113]),
                    send: 1,
                    v: 202203031419,
                    wait: 1,
                    tid: 20010
                },
                "360": {
                    load: (utag.cond[158] && utag.cond[151] && utag.cond[113]),
                    send: 1,
                    v: 202203031419,
                    wait: 1,
                    tid: 20010
                },
                "361": {
                    load: utag.cond[113],
                    send: 1,
                    v: 202111230950,
                    wait: 1,
                    tid: 20010
                },
                "362": {
                    load: (utag.cond[147] && utag.cond[113]),
                    send: 1,
                    v: 202111230950,
                    wait: 1,
                    tid: 20010
                },
                "363": {
                    load: (utag.cond[157] && utag.cond[160]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "365": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[171]),
                    send: 1,
                    v: 202304041605,
                    wait: 1,
                    tid: 20010
                },
                "366": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[152]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "367": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[154]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "368": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[159]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "369": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[160]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "370": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[163]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "371": {
                    load: (utag.cond[157] && utag.cond[113]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "372": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[152]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "373": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[154]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "374": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[159]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "375": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[160]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "377": {
                    load: (utag.cond[157] && utag.cond[113] && utag.cond[163]),
                    send: 1,
                    v: 202203290814,
                    wait: 1,
                    tid: 20010
                },
                "379": {
                    load: (utag.cond[156] && utag.cond[170]),
                    send: 1,
                    v: 202304041605,
                    wait: 1,
                    tid: 20010
                },
                "385": {
                    load: (utag.cond[156] && utag.cond[172] && utag.cond[113]),
                    send: 1,
                    v: 202307311456,
                    wait: 1,
                    tid: 20010
                },
                "386": {
                    load: (utag.cond[156] && utag.cond[113]),
                    send: 1,
                    v: 202207201158,
                    wait: 1,
                    tid: 20010
                },
                "389": {
                    load: (utag.cond[156] && utag.cond[113]),
                    send: 1,
                    v: 202207201158,
                    wait: 1,
                    tid: 12047
                },
                "390": {
                    load: (utag.cond[156] && utag.cond[135] && utag.cond[113]),
                    send: 1,
                    v: 202207201158,
                    wait: 1,
                    tid: 20010
                },
                "391": {
                    load: (utag.cond[156] && utag.cond[113] && utag.cond[153]),
                    send: 1,
                    v: 202207201158,
                    wait: 1,
                    tid: 20010
                },
                "392": {
                    load: (utag.cond[156] && utag.cond[113] && utag.cond[173]),
                    send: 1,
                    v: 202207201158,
                    wait: 1,
                    tid: 20010
                },
                "393": {
                    load: (utag.cond[156] && utag.cond[113] && utag.cond[152]),
                    send: 1,
                    v: 202207201158,
                    wait: 1,
                    tid: 20010
                },
                "396": {
                    load: (utag.cond[113] && utag.cond[177]),
                    send: 1,
                    v: 202311281602,
                    wait: 1,
                    tid: 20010
                },
                "397": {
                    load: (utag.cond[113] && utag.cond[176]),
                    send: 1,
                    v: 202308031338,
                    wait: 1,
                    tid: 20010
                },
                "400": {
                    load: (utag.cond[158] && utag.cond[113]),
                    send: 1,
                    v: 202211020909,
                    wait: 1,
                    tid: 3167
                },
                "401": {
                    load: (utag.cond[158] && utag.cond[113]),
                    send: 1,
                    v: 202211020909,
                    wait: 1,
                    tid: 20010
                },
                "403": {
                    load: (utag.cond[113] && utag.cond[154]),
                    send: 1,
                    v: 202307271529,
                    wait: 1,
                    tid: 20010
                },
                "404": {
                    load: (utag.cond[174] && utag.cond[113] && utag.cond[82]),
                    send: 1,
                    v: 202307271529,
                    wait: 1,
                    tid: 20010
                },
                "405": {
                    load: (utag.cond[179] && utag.cond[164] && utag.cond[113]),
                    send: 1,
                    v: 202307271529,
                    wait: 1,
                    tid: 20010
                },
                "406": {
                    load: (utag.cond[158] && utag.cond[113] && utag.cond[152]),
                    send: 1,
                    v: 202307271529,
                    wait: 1,
                    tid: 20010
                },
                "407": {
                    load: (utag.cond[164] && utag.cond[113] && utag.cond[180]),
                    send: 1,
                    v: 202211020909,
                    wait: 1,
                    tid: 20010
                },
                "412": {
                    load: (utag.cond[174] && utag.cond[113] && utag.cond[82]),
                    send: 1,
                    v: 202307311456,
                    wait: 1,
                    tid: 20010
                },
                "428": {
                    load: (((utag.cond[113]) && (utag.cond[179]) && (utag.cond[184]))),
                    send: 1,
                    v: 202304131340,
                    wait: 1,
                    tid: 20010
                },
                "432": {
                    load: (((utag.cond[113]) && (utag.cond[179]) && (utag.cond[184]))),
                    send: 1,
                    v: 202304141002,
                    wait: 1,
                    tid: 20010
                },
                "433": {
                    load: (((utag.cond[113]) && (utag.cond[151]))),
                    send: 1,
                    v: 202304141002,
                    wait: 1,
                    tid: 20010
                },
                "438": {
                    load: (((utag.cond[113]) && (utag.cond[176]))),
                    send: 1,
                    v: 202307041436,
                    wait: 1,
                    tid: 20010
                },
                "450": {
                    load: (((utag.cond[113]) && (utag.cond[187]))),
                    send: 1,
                    v: 202309131344,
                    wait: 1,
                    tid: 20010
                },
                "451": {
                    load: (((utag.cond[187]) && (utag.cond[113]) && (utag.cond[154]))),
                    send: 1,
                    v: 202309131344,
                    wait: 1,
                    tid: 20010
                },
                "452": {
                    load: (((utag.cond[152]) && (utag.cond[187]) && (utag.cond[113]))),
                    send: 1,
                    v: 202309131344,
                    wait: 1,
                    tid: 20010
                },
                "453": {
                    load: (((utag.cond[113]) && (utag.cond[158]))),
                    send: 1,
                    v: 202310311432,
                    wait: 1,
                    tid: 20010
                }
            };
            utag.loader.cfgsort = ["43", "24", "27", "57", "94", "207", "203", "205", "214", "212", "211", "216", "252", "255", "285", "286", "296", "297", "298", "299", "300", "301", "302", "303", "304", "305", "306", "308", "309", "311", "312", "313", "314", "315", "316", "317", "318", "319", "320", "321", "322", "323", "324", "325", "326", "327", "328", "329", "330", "331", "332", "333", "334", "335", "338", "339", "340", "341", "343", "344", "345", "346", "355", "356", "357", "358", "359", "360", "361", "362", "363", "365", "366", "367", "368", "369", "370", "371", "372", "373", "374", "375", "377", "379", "385", "386", "389", "390", "391", "392", "393", "396", "397", "400", "401", "403", "404", "405", "406", "407", "412", "428", "432", "433", "438", "450", "451", "452", "453"];
        }
        utag.loader.initcfg();
    }
    if (typeof utag_cfg_ovrd != 'undefined') {
        for (var i in utag.loader.GV(utag_cfg_ovrd)) utag.cfg[i] = utag_cfg_ovrd[i]
    };
    utag.loader.PINIT = function(a, b, c) {
        utag.DB("Pre-INIT");
        if (utag.cfg.noload) {
            return;
        }
        try {
            this.GET();
            if (utag.handler.RE('view', utag.data, "blr")) {
                utag.handler.LR(utag.data);
            }
        } catch (e) {
            utag.DB(e)
        };
        a = this.cfg;
        c = 0;
        for (b in this.GV(a)) {
            if (a[b].block == 1 || (a[b].load > 0 && (typeof a[b].src != 'undefined' && a[b].src != ''))) {
                a[b].block = 1;
                c = 1;
                this.bq[b] = 1;
            }
        }
        if (c == 1) {
            for (b in this.GV(a)) {
                if (a[b].block) {
                    a[b].id = b;
                    if (a[b].load == 4) a[b].load = 1;
                    a[b].cb = function() {
                        var d = this.uid;
                        utag.loader.cfg[d].cbf = 1;
                        utag.loader.LOAD(d)
                    };
                    this.AS(a[b]);
                }
            }
        }
        if (c == 0) this.INIT();
    };
    utag.loader.INIT = function(a, b, c, d, e) {
        utag.DB('utag.loader.INIT');
        if (this.ol == 1) return -1;
        else this.ol = 1;
        if (utag.cfg.noview != true) utag.handler.RE('view', utag.data, "alr");
        utag.rpt.ts['i'] = new Date();
        d = this.cfgsort;
        for (a = 0; a < d.length; a++) {
            e = d[a];
            b = this.cfg[e];
            b.id = e;
            if (b.block != 1 && b.s2s != 1) {
                if (utag.loader.bk[b.id] || ((utag.cfg.readywait || utag.cfg.noview) && b.load == 4)) {
                    this.f[b.id] = 0;
                    utag.loader.LOAD(b.id)
                } else if (b.wait == 1 && utag.loader.rf == 0) {
                    utag.DB('utag.loader.INIT: waiting ' + b.id);
                    this.wq.push(b)
                    this.f[b.id] = 2;
                } else if (b.load > 0) {
                    utag.DB('utag.loader.INIT: loading ' + b.id);
                    this.lq.push(b);
                    this.AS(b);
                }
            }
        }
        if (this.wq.length > 0) utag.loader.EV('', 'ready', function(a) {
            if (utag.loader.rf == 0) {
                utag.DB('READY:utag.loader.wq');
                utag.loader.rf = 1;
                utag.loader.WQ();
            }
        });
        else if (this.lq.length > 0) utag.loader.rf = 1;
        else if (this.lq.length == 0) utag.loader.END();
        return 1
    };
    utag.loader.EV('', 'ready', function(a) {
        if (utag.loader.efr != 1) {
            utag.loader.efr = 1;
            try {
                try {
                    if (1) {
                        var numeroButtonGoogle = '';
                        numeroButtonGoogle = document.querySelectorAll('div[data-pub-id="clicknumero"]');
                        var i;
                        if (numeroButtonGoogle) {
                            var t = [],
                                d = utag.data;
                            for (var i = 0; i < numeroButtonGoogle.length; i++) {
                                numeroButtonGoogle[i].addEventListener("click", (function(i, numeroButtonGooglebutton) {
                                    return function clickedNumeroButtonGoogle() {
                                        var delayMilliseconds = 500;
                                        if (d.ad_type == "demandes") {
                                            t.push(91);
                                        } else if (d.ad_type == "offres") {
                                            t.push(90);
                                        }
                                        setTimeout(function() {
                                            utag.link(Object.assign({
                                                'd.event_name': "ad_reply::telephone::voir_le_numero"
                                            }, utag.data), null, t);
                                            numeroButtonGoogle[i].removeEventListener("click", clickedNumeroButtonGoogle);
                                        }, delayMilliseconds);
                                    }
                                })(i, numeroButtonGoogle));
                            }
                        }
                    }
                } catch (e) {
                    utag.DB(e)
                }
            } catch (e) {
                utag.DB(e)
            };
        }
    })
    if (utag.cfg.readywait || utag.cfg.waittimer) {
        utag.loader.EV('', 'ready', function(a) {
            if (utag.loader.rf == 0) {
                utag.loader.rf = 1;
                utag.cfg.readywait = 1;
                utag.DB('READY:utag.cfg.readywait');
                setTimeout(function() {
                    utag.loader.PINIT()
                }, utag.cfg.waittimer || 1);
            }
        })
    } else {
        utag.loader.PINIT()
    }
}