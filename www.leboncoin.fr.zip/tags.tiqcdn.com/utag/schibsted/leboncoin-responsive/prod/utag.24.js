//tealium universal tag - utag.24 ut4.0.202311281603, Copyright 2023 Tealium.com Inc. All Rights Reserved.
window.xtnv = document;
window.xtsd = "";
window.xtdmc = ".leboncoin.fr";
var dom = window.document.domain;
if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.rav.proctool.leboncoin.io/.test(dom)) {
    window.xtsite = 562496;
}
if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.dev.leboncoin.lan/.test(dom)) {
    window.xtsite = 562495;
}
if (utag_data.environnement === "dev" && /[a-z]*.qa[0-9]{1}.bon-coin.net/.test(dom)) {
    window.xtsite = 562496;
}
if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.next.proctool.leboncoin.io/.test(dom)) {
    window.xtsite = 562496;
}
if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.next.ariane.leboncoin.ci/.test(dom)) {
    window.xtsite = 562496;
}
if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.rav.ariane.leboncoin.ci/.test(dom)) {
    window.xtsite = 562496;
}
if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.bon-coin.net/.test(dom)) {
    window.xtsite = 562496;
}
if (utag_data.environnement === "qa") {
    window.xtsite = 562496;
}
if (utag_data.environnement === "prod") {
    window.xtsite = 562498;
}
window.xtn2 = "";
window.xtpage = "";
window.xtdi = "";
window.xt_multc = "";
window.xt_an = "";
window.xt_ac = "";
window.xttp = "";
window.xt_ordermc = "";
window.xt_orderid = "";
try {
    if (!utag.libloader) {
        utag.libloader = function(src, handler, a, b) {
            "use strict";
            a = document;
            b = a.createElement('script');
            b.language = 'javascript';
            b.type = 'text/javascript';
            b.src = src;
            if (typeof handler === 'function') {
                b.handlerFlag = 0;
                b.onreadystatechange = function() {
                    if ((this.readyState === 'complete' || this.readyState === 'loaded') && !b.handlerFlag) {
                        b.handlerFlag = 1;
                        handler();
                    }
                };
                b.onload = function() {
                    if (!b.handlerFlag) {
                        b.handlerFlag = 1;
                        handler();
                    }
                };
                a.getElementsByTagName('head')[0].appendChild(b);
            }
        };
    }
    (function(id, loader, u) {
        "use strict";
        try {
            u = utag.o[loader].sender[id] = {};
        } catch (e) {
            u = utag.sender[id];
        }
        u.ev = {
            'view': 1
        };
        u.qsp_delim = "&";
        u.kvp_delim = "=";
        u.map = {
            "js_page.xtsite": "xtsite",
            "js_page.xtn2": "xtn2",
            "eventname": "xtpage",
            "js_page.xtsd": "xtsd",
            "store_id": "xt_an",
            "compte": "xt_ac",
            "js_page.panier": "xtidcart",
            "js_page.plateformdevice": "x1",
            "pagetype": "x3",
            "previouspage": "x4",
            "action": "x6",
            "listid": "x7",
            "adid": "x8",
            "cat_id": "x9",
            "xiti_implication_degree": "xtdi",
            "subcat_id": "x10",
            "region": "x11",
            "departement": "x12",
            "ad_type": "x13",
            "options": "x14",
            "store_id_annonceur": "x15",
            "offres": "x16",
            "path_custom_var": "x17",
            "user_log_custom_var": "x19",
            "step_name_custom_var": "x18",
            "city": "x20",
            "boutique_id": "x21",
            "displaytype": "x2"
        };
        u.extend = [function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "immo") {
                        if (typeof getATInternetTag !== 'undefined') {
                            getATInternetTag().setProp('f:file_size', b.file_size, false);
                            getATInternetTag().setProp('n:ad_listid', b.ad_listid, false);
                            getATInternetTag().setProp('n:ad_poster_id', b.ad_poster_id, false);
                            getATInternetTag().setProp('ad_poster_type', b.ad_poster_type, false);
                            getATInternetTag().setProp('f:ad_price', b.ad_price, false);
                            getATInternetTag().setProp('cat_id', b.cat_id, false);
                            getATInternetTag().setProp('lease_status', b.lease_status, false);
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.project_name;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.action;
                            b.xiti_f5 = b.action_value;
                            b.xiti_f6 = b.section_name;
                            b.xiti_f7 = b.cat_id;
                            b.xiti_f8 = b.subcat_id;
                            b.xiti_f9 = b.store_id;
                            b.xiti_f10 = b.user_id;
                            b.xiti_f11 = b.compte;
                            b.xiti_f12 = b.attachment;
                        } else {
                            b.xiti_f1 = b.project_name;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.action;
                            b.xiti_f5 = b.action_value;
                            b.xiti_f6 = b.section_name;
                            b.xiti_f7 = b.cat_id;
                            b.xiti_f8 = b.subcat_id;
                            b.xiti_f11 = b.compte;
                            b.xiti_f12 = b.attachment;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.immo_sell_type === "new" && (b.subcat_id === "undefined" || b.subcat_id === "")) {
                        b.subcat_id = "73";
                    }
                    if (b.subcat_id === "78") {
                        b.subcat_id = "9";
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.privacy_concat === undefined) {
                        b.privacy_concat = "promo_perso=" + b.tracking_privacy_consent_promo_perso + ";comm_perso=" + b.tracking_privacy_consent_comm_perso + ";cookies=" + b.tracking_privacy_consent_cookies + ";lbc_france=" + b.tracking_privacy_consent_lbcfrance + ";service_perso=" + b.tracking_privacy_consent_service_perso + ";user_exp=" + b.tracking_privacy_consent_user_exp + ";visitor_mode=" + b.tracking_privacy_consent_visitormode;
                    } else {
                        b.privacy_concat = b.privacy_concat
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    window.getATInternetTag = function() {
                        var tag;
                        if (window.ATInternet != undefined && window.ATInternet.Tracker && window.ATInternet.Tracker.instances[0]) {
                            window.ATInternet.Tracker.instances[0].setConfig("site", window.xtsite);
                            var tag = window.ATInternet.Tracker.instances[0];
                        } else {
                            var tag = new ATInternet.Tracker.Tag({
                                secure: true,
                                site: window.xtsite,
                                log: 'logw360',
                                logSSL: 'logws1360'
                            });
                        }
                        return tag;
                    }
                    window.setTrackingVisitorMode = function(visitormode) {
                        var tag = getATInternetTag();
                        localStorage.setItem('consent_mesureaudience_visitormode', visitormode);
                        if (visitormode === 'optin') {
                            tag.privacy.setVisitorOptin();
                            localStorage.setItem('consent_mesureaudience_optout', false);
                        } else if (visitormode === 'optout') {
                            tag.privacy.setVisitorOptout();
                            localStorage.setItem('consent_mesureaudience_optout', true);
                        } else {
                            tag.privacy.setVisitorMode("cnil", "exempt");
                            localStorage.setItem('consent_mesureaudience_optout', false);
                        }
                        tag.dispatch();
                    }
                    window.on_consentchanged = function() {
                        var mesureaudience_consent = Didomi.getUserConsentStatusForPurpose('mesureaudience');
                        var now = new Date();
                        if (mesureaudience_consent === true || (typeof(mesureaudience_consent) === "undefined" && now < new Date("2021-04-01T00:00:01"))) {
                            setTrackingVisitorMode('optin');
                        } else if (localStorage.getItem('consent_mesureaudience_visitormode') !== 'optout') {
                            setTrackingVisitorMode('exempt')
                        }
                    }
                    window.set_mesureaudience_optout = function() {
                        setTrackingVisitorMode('optout');
                        var transaction = Didomi.openTransaction();
                        transaction.disablePurpose('mesureaudience');
                        transaction.commit();
                    }
                    if (typeof(window.consent_tracking_inited) === 'undefined') {
                        window.didomiEventListeners = window.didomiEventListeners || [];
                        window.didomiEventListeners.push({
                            event: 'consent.changed',
                            listener: function() {
                                on_consentchanged()
                            }
                        })
                        if (localStorage.getItem('consent_mesureaudience_visitormode') == null) {
                            on_consentchanged()
                        }
                        window.consent_tracking_inited = true;
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "payment") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.previouspage;
                            b.xiti_f2 = b.step_name;
                            b.xiti_f3 = b.payment_type;
                            b.xiti_f4 = b.store_id;
                            b.xiti_f5 = b.user_account;
                            b.xiti_f6 = b.order_id;
                            b.xiti_f7 = b.user_id;
                            b.xiti_f8 = b.entry_point;
                            b.xiti_f9 = b.balance_status;
                            b.xiti_f10 = b.path;
                        } else {
                            b.xiti_f1 = b.previouspage;
                            b.xiti_f2 = b.step_name;
                            b.xiti_f3 = b.payment_type;
                            b.xiti_f5 = b.user_account;
                            b.xiti_f8 = b.entry_point;
                            b.xiti_f9 = b.balance_status;
                            b.xiti_f10 = b.path;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "search") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path !== undefined ? b.path : "";
                            b.xiti_f2 = b.step_name !== undefined ? b.step_name : "";
                            b.xiti_f3 = b.step_number !== undefined ? b.step_number : "";
                            b.xiti_f4 = b.search_keyword !== undefined ? b.search_keyword : "";
                            b.xiti_f5 = b.device !== undefined ? b.device : "";
                            b.xiti_f6 = b.store_id !== undefined ? b.store_id : "";
                            b.xiti_f7 = b.entry_point !== undefined ? b.entry_point : "";
                            b.xiti_f8 = b.cat_id !== undefined ? b.cat_id : "";
                            b.xiti_f9 = b.sub_cat_id !== undefined ? b.sub_cat_id : "";
                        } else {
                            b.xiti_f1 = b.path !== undefined ? b.path : "";
                            b.xiti_f2 = b.step_name !== undefined ? b.step_name : "";
                            b.xiti_f3 = b.step_number !== undefined ? b.step_number : "";
                            b.xiti_f4 = b.search_keyword !== undefined ? b.search_keyword : "";
                            b.xiti_f5 = b.device !== undefined ? b.device : "";
                            b.xiti_f7 = b.entry_point !== undefined ? b.entry_point : "";
                            b.xiti_f8 = b.cat_id !== undefined ? b.cat_id : "";
                            b.xiti_f9 = b.sub_cat_id !== undefined ? b.sub_cat_id : "";
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "account") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.entry_point;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.user_account;
                            b.xiti_f5 = b.error_status;
                            b.xiti_f6 = b.device;
                            b.xiti_f7 = b.store_id;
                            b.xiti_f8 = b.order_id;
                            b.xiti_f9 = b.payment_type;
                            b.xiti_f10 = b.ad_options;
                        } else {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.entry_point;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.user_account;
                            b.xiti_f5 = b.error_status;
                            b.xiti_f6 = b.device;
                            b.xiti_f9 = b.payment_type;
                            b.xiti_f10 = b.ad_options;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "partners_page") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.partenaire;
                            b.xiti_f2 = b.location;
                            b.xiti_f3 = b.action;
                            b.xiti_f4 = b.product_name;
                        } else {
                            b.xiti_f1 = b.partenaire;
                            b.xiti_f2 = b.location;
                            b.xiti_f3 = b.action;
                            b.xiti_f4 = b.product_name;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "contact") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.page_name;
                            b.xiti_f2 = b.action;
                            b.xiti_f3 = b.listid;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.price;
                            b.xiti_f11 = b.store_id_annonceur;
                            b.xiti_f12 = b.store_id;
                            b.xiti_f13 = b.immo_sell_type;
                            b.xiti_f14 = b.compte;
                            b.xiti_f15 = b.lead_total;
                            b.xiti_f16 = b.attachment;
                            b.xiti_f17 = b.type_de_contact;
                        } else {
                            b.xiti_f1 = b.page_name;
                            b.xiti_f2 = b.action;
                            b.xiti_f3 = b.listid;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.price;
                            b.xiti_f11 = b.store_id_annonceur;
                            b.xiti_f13 = b.immo_sell_type;
                            b.xiti_f14 = b.compte;
                            b.xiti_f15 = b.lead_total;
                            b.xiti_f16 = b.attachment;
                            b.xiti_f17 = b.type_de_contact;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "ratings") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.step_name;
                            b.xiti_f3 = b.question_name;
                            b.xiti_f4 = b.question_number;
                            b.xiti_f5 = b.ratings_record;
                            b.xiti_f6 = b.total_questions_nb;
                            b.xiti_f7 = b.cat_id;
                            b.xiti_f8 = b.subcat_id;
                            b.xiti_f9 = b.customer_type;
                            b.xiti_f10 = b.original_section;
                            b.xiti_f11 = b.compte;
                        } else {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.step_name;
                            b.xiti_f3 = b.question_name;
                            b.xiti_f4 = b.question_number;
                            b.xiti_f5 = b.ratings_record;
                            b.xiti_f6 = b.total_questions_nb;
                            b.xiti_f7 = b.cat_id;
                            b.xiti_f8 = b.subcat_id;
                            b.xiti_f9 = b.customer_type;
                            b.xiti_f10 = b.original_section;
                            b.xiti_f11 = b.compte;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname.startsWith("ad_reply::lien::postuler")) {
                        var opts = [];
                        if (b.options.booster != 0) {
                            opts.push("booster");
                        }
                        if (b.options.gallery != 0) {
                            opts.push("gallery");
                        }
                        if (b.options.photosup != 0) {
                            opts.push("photosup");
                        }
                        if (b.options.sub_toplist != 0) {
                            opts.push("sub_toplist");
                        }
                        if (b.options.urgent != 0) {
                            opts.push("urgent");
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.listid;
                            b.xiti_f2 = "!!pending_adid!!";
                            b.xiti_f3 = b.titre;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.prix;
                            b.xiti_f11 = b.nbphoto;
                            b.xiti_f12 = opts.join('_');
                            b.xiti_f13 = b.store_id_annonceur;
                            b.xiti_f14 = b.store_id;
                            b.xiti_f15 = b.immo_sell_type;
                            b.xiti_f16 = b.publish_date;
                            b.xiti_f17 = b.last_update_date;
                            b.xiti_f18 = b.offres
                            b.xiti_f19 = b.boutique_id;
                        } else {
                            b.xiti_f1 = b.listid;
                            b.xiti_f2 = "!!pending_adid!!";
                            b.xiti_f3 = b.titre;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.prix;
                            b.xiti_f11 = b.nbphoto;
                            b.xiti_f12 = opts.join('_');
                            b.xiti_f13 = b.store_id_annonceur;
                            b.xiti_f15 = b.immo_sell_type;
                            b.xiti_f16 = b.publish_date;
                            b.xiti_f17 = b.last_update_date;
                            b.xiti_f18 = "";
                            if (b.siren != null) {
                                b.xiti_f18 = "pro";
                            } else {
                                b.xiti_f18 = "part";
                            }
                            b.xiti_f19 = b.boutique_id;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "holidays") {
                        if (b.path === "ad_clicks") {
                            if (typeof getATInternetTag !== 'undefined') {
                                getATInternetTag().setProp('ad_poster_type', b.ad_poster_type, false);
                                getATInternetTag().setProp('n:ad_poster_id', b.ad_poster_id, false);
                            }
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.step_name;
                            b.xiti_f3 = b.step_number;
                            b.xiti_f4 = b.error_status;
                            b.xiti_f5 = b.listid;
                            b.xiti_f6 = b.cat_id;
                            b.xiti_f7 = b.subcat_id;
                            b.xiti_f8 = b.region;
                            b.xiti_f9 = b.departement;
                            b.xiti_f10 = b.city;
                            b.xiti_f11 = b.store_id;
                            b.xiti_f12 = b.original_section;
                            b.xiti_f13 = b.booking_status;
                            b.xiti_f14 = b.order_id;
                            b.xiti_f15 = b.path_type;
                            b.xiti_f16 = b.widgets;
                            b.xiti_f17 = b.user_id;
                            b.xiti_f18 = b.action;
                            b.xiti_f19 = b.action_value;
                            b.xiti_f19 = b.action_value;
                            b.xiti_f20 = b.payment_type;
                        } else {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.step_name;
                            b.xiti_f3 = b.step_number;
                            b.xiti_f4 = b.error_status;
                            b.xiti_f5 = b.listid;
                            b.xiti_f6 = b.cat_id;
                            b.xiti_f7 = b.subcat_id;
                            b.xiti_f8 = b.region;
                            b.xiti_f9 = b.departement;
                            b.xiti_f10 = b.city;
                            b.xiti_f12 = b.original_section;
                            b.xiti_f13 = b.booking_status;
                            b.xiti_f15 = b.path_type;
                            b.xiti_f16 = b.widgets;
                            b.xiti_f18 = b.action;
                            b.xiti_f19 = b.action_value;
                            b.xiti_f20 = b.payment_type;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "compte_pro") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.page_name || '';
                            b.xiti_f2 = b.activity_sector || '';
                            b.xiti_f3 = b.online_ads || '';
                            b.xiti_f4 = b.load || '';
                            b.xiti_f5 = b.pro_type || '';
                            b.xiti_f6 = b.compte || '';
                            b.xiti_f7 = b.store_id || '';
                            b.xiti_f8 = b.user_id || '';
                            b.xiti_f9 = b.section_name || '';
                            b.xiti_f10 = b.action || '';
                            b.xiti_f11 = b.action_value || '';
                            b.xiti_f12 = b.low_visible_ads || '';
                            b.xiti_f13 = b.low_attractive_ads || '';
                            b.xiti_f14 = b.nb_ads_selected || '';
                            b.xiti_f15 = b.step_name || '';
                            b.xiti_f16 = b.member_id || '';
                            b.xiti_f17 = b.lead_id_back || '';
                        } else {
                            b.xiti_f1 = b.page_name || '';
                            b.xiti_f2 = b.activity_sector || '';
                            b.xiti_f3 = b.online_ads || '';
                            b.xiti_f4 = b.load || '';
                            b.xiti_f5 = b.pro_type || '';
                            b.xiti_f6 = b.compte || '';
                            b.xiti_f9 = b.section_name || '';
                            b.xiti_f10 = b.action || '';
                            b.xiti_f11 = b.action_value || '';
                            b.xiti_f12 = b.low_visible_ads || '';
                            b.xiti_f13 = b.low_attractive_ads || '';
                            b.xiti_f14 = b.nb_ads_selected || '';
                            b.xiti_f15 = b.step_name || '';
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "mandats") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.entry_point !== undefined ? b.entry_point : "";
                            b.xiti_f2 = b.path !== undefined ? b.path : "";
                            b.xiti_f3 = b.step_name !== undefined ? b.step_name : "";
                            b.xiti_f4 = b.step_number !== undefined ? b.step_number : "";
                            b.xiti_f5 = b.error_status !== undefined ? b.error_status : "";
                            b.xiti_f6 = b.load !== undefined ? b.load : "";
                            b.xiti_f7 = b.form_id !== undefined ? b.form_id : "";
                            b.xiti_f8 = b.lead_total !== undefined ? b.lead_total : "";
                            b.xiti_f9 = b.city !== undefined ? b.city : "";
                            b.xiti_f10 = b.matching_agency !== undefined ? b.matching_agency : "";
                            b.xiti_f11 = b.uncheck_agency !== undefined ? b.uncheck_agency : "";
                            b.xiti_f12 = b.list_id !== undefined ? b.list_id : "";
                            b.xiti_f13 = b.number_promote !== undefined ? b.number_promote : "";
                            b.xiti_f14 = b.type_promote !== undefined ? b.type_promote : "";
                            b.xiti_f15 = b.position_promote !== undefined ? b.position_promote : "";
                            b.xiti_f16 = b.name_promote !== undefined ? b.name_promote : "";
                            b.xiti_f17 = b.store_id_historical !== undefined ? b.store_id_historical : "";
                            b.xiti_f18 = b.store_id_new !== undefined ? b.store_id_new : "";
                        } else {
                            b.xiti_f1 = b.entry_point !== undefined ? b.entry_point : "";
                            b.xiti_f2 = b.path !== undefined ? b.path : "";
                            b.xiti_f3 = b.step_name !== undefined ? b.step_name : "";
                            b.xiti_f4 = b.step_number !== undefined ? b.step_number : "";
                            b.xiti_f5 = b.error_status !== undefined ? b.error_status : "";
                            b.xiti_f6 = b.load !== undefined ? b.load : "";
                            b.xiti_f7 = b.form_id !== undefined ? b.form_id : "";
                            b.xiti_f8 = b.lead_total !== undefined ? b.lead_total : "";
                            b.xiti_f9 = b.city !== undefined ? b.city : "";
                            b.xiti_f10 = b.matching_agency !== undefined ? b.matching_agency : "";
                            b.xiti_f11 = b.uncheck_agency !== undefined ? b.uncheck_agency : "";
                            b.xiti_f12 = b.list_id !== undefined ? b.list_id : "";
                            b.xiti_f13 = b.number_promote !== undefined ? b.number_promote : "";
                            b.xiti_f14 = b.type_promote !== undefined ? b.type_promote : "";
                            b.xiti_f15 = b.position_promote !== undefined ? b.position_promote : "";
                            b.xiti_f16 = b.name_promote !== undefined ? b.name_promote : "";
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "pro") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.previouspage;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.step_number;
                            b.xiti_f5 = b.step_status;
                            b.xiti_f6 = b.error_status;
                            b.xiti_f7 = b.device;
                            b.xiti_f8 = b.logged_user;
                            b.xiti_f9 = b.store_id;
                            b.xiti_f10 = b.user_account;
                            b.xiti_f11 = b.cat_id;
                            b.xiti_f12 = b.subcat_id;
                            b.xiti_f13 = b.search;
                            b.xiti_f14 = b.shop_module;
                            b.xiti_f15 = b.online_store_id;
                            b.xiti_f16 = b.store_id_pro;
                            b.xiti_f18 = b.activity_sector;
                        } else {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.previouspage;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.step_number;
                            b.xiti_f5 = b.step_status;
                            b.xiti_f6 = b.error_status;
                            b.xiti_f7 = b.device;
                            b.xiti_f8 = b.logged_user;
                            b.xiti_f10 = b.user_account;
                            b.xiti_f11 = b.cat_id;
                            b.xiti_f12 = b.subcat_id;
                            b.xiti_f13 = b.search;
                            b.xiti_f14 = b.shop_module;
                            b.xiti_f15 = b.online_store_id;
                            b.xiti_f16 = b.store_id_pro;
                            b.xiti_f18 = b.activity_sector;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "employ") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.previouspage;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.step_number;
                            b.xiti_f5 = b.step_status;
                            b.xiti_f6 = b.error_status;
                            b.xiti_f7 = b.device;
                            b.xiti_f8 = b.logged_user;
                            b.xiti_f9 = b.store_id;
                            b.xiti_f10 = b.city;
                            b.xiti_f11 = b.region;
                            b.xiti_f12 = b.departement;
                            b.xiti_f13 = b.search_keyword;
                            b.xiti_f14 = b.search_result;
                            b.xiti_f15 = b.entry_point;
                            b.xiti_f16 = b.module_landing_page;
                            b.xiti_f17 = b.cat_id;
                            b.xiti_f18 = b.subcat_id;
                            b.xiti_f19 = b.activity_sector;
                            b.xiti_f20 = b.pro_type;
                        } else {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.previouspage;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.step_number;
                            b.xiti_f5 = b.step_status;
                            b.xiti_f6 = b.error_status;
                            b.xiti_f7 = b.device;
                            b.xiti_f8 = b.logged_user;
                            b.xiti_f10 = b.city;
                            b.xiti_f11 = b.region;
                            b.xiti_f12 = b.departement;
                            b.xiti_f13 = b.search_keyword;
                            b.xiti_f14 = b.search_result;
                            b.xiti_f15 = b.entry_point;
                            b.xiti_f16 = b.module_landing_page;
                            b.xiti_f17 = b.cat_id;
                            b.xiti_f18 = b.subcat_id;
                            b.xiti_f19 = b.activity_sector;
                            b.xiti_f20 = b.pro_type;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "compte_part::dashboard") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.tab !== undefined ? b.tab : "";
                            b.xiti_f2 = b.cta !== undefined ? b.cta : "";
                            b.xiti_f3 = b.cta_type !== undefined ? b.cta_type : "";
                            b.xiti_f4 = b.nb_ads_selected !== undefined ? b.nb_ads_selected : "";
                            b.xiti_f5 = b.feature !== undefined ? b.feature : "";
                            b.xiti_f6 = b.feature_value !== undefined ? b.feature_value : "";
                        } else {
                            b.xiti_f1 = b.tab !== undefined ? b.tab : "";
                            b.xiti_f2 = b.cta !== undefined ? b.cta : "";
                            b.xiti_f3 = b.cta_type !== undefined ? b.cta_type : "";
                            b.xiti_f4 = b.nb_ads_selected !== undefined ? b.nb_ads_selected : "";
                            b.xiti_f5 = b.feature !== undefined ? b.feature : "";
                            b.xiti_f6 = b.feature_value !== undefined ? b.feature_value : "";
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "ad_reply::telephone::voir_le_numero" || b.eventname === "ad_reply::telephone::voir_le_numero::sticky" || b.eventname === "ad_reply::telephone::voir_le_numero::tabbar" || b.eventname === "ad_reply::email::envoyer_email" || b.eventname === "ad_reply::email::envoyer_email::tabbar" || b.eventname === "ad_reply::email::envoyer_email::sticky" || b.eventname === "ad_reply::email::demander_adresse" || b.eventname === "ad_reply::messagerie::envoyer_message") {
                        var opts = [];
                        if (b.options.booster != 0) {
                            opts.push("booster");
                        }
                        if (b.options.gallery != 0) {
                            opts.push("gallery");
                        }
                        if (b.options.photosup != 0) {
                            opts.push("photosup");
                        }
                        if (b.options.sub_toplist != 0) {
                            opts.push("sub_toplist");
                        }
                        if (b.options.urgent != 0) {
                            opts.push("urgent");
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.listid;
                            b.xiti_f2 = "!!pending_adid!!";
                            b.xiti_f3 = b.titre;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.price;
                            b.xiti_f11 = b.nbphoto;
                            b.xiti_f12 = opts.join('_');
                            b.xiti_f13 = b.store_id_annonceur;
                            b.xiti_f14 = b.store_id;
                            b.xiti_f15 = b.immo_sell_type;
                            b.xiti_f16 = b.publish_date;
                            b.xiti_f17 = b.last_update_date;
                            b.xiti_f18 = "";
                            if (b.siren != null) {
                                b.xiti_f18 = "pro";
                            } else {
                                b.xiti_f18 = "part";
                            }
                            b.xiti_f19 = b.boutique_id;
                        } else {
                            b.xiti_f1 = b.listid;
                            b.xiti_f2 = "!!pending_adid!!";
                            b.xiti_f3 = b.titre;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.price;
                            b.xiti_f11 = b.nbphoto;
                            b.xiti_f12 = opts.join('_');
                            b.xiti_f13 = b.store_id_annonceur;
                            b.xiti_f15 = b.immo_sell_type;
                            b.xiti_f16 = b.publish_date;
                            b.xiti_f17 = b.last_update_date;
                            b.xiti_f18 = "";
                            if (b.siren != null) {
                                b.xiti_f18 = "pro";
                            } else {
                                b.xiti_f18 = "part";
                            }
                            b.xiti_f19 = b.boutique_id;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "p2p_vehicle") {
                        if (typeof getATInternetTag !== 'undefined') {
                            getATInternetTag().setProp('entry_point', b.entry_point, false);
                            getATInternetTag().setProp('n:ad_listid', b.ad_listid, false);
                            getATInternetTag().setProp('n:ad_poster_id', b.ad_poster_id, false);
                            getATInternetTag().setProp('ad_poster_type', b.ad_poster_type, false);
                            getATInternetTag().setProp('f:ad_price', b.ad_price, false);
                            getATInternetTag().setProp('funding_availability', b.funding_availability, false);
                            getATInternetTag().setProp('funding_loan_filling', b.funding_loan_filling, false);
                            getATInternetTag().setProp('cat_id', b.cat_id, false);
                            getATInternetTag().setProp('subcat_id', b.subcat_id, false);
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.step_name;
                            b.xiti_f3 = b.listid;
                            b.xiti_f4 = b.price;
                            b.xiti_f5 = b.cat_id;
                            b.xiti_f6 = b.subcat_id;
                            b.xiti_f7 = b.store_id_annonceur;
                            b.xiti_f8 = b.agreement_initiator;
                            b.xiti_f9 = b.agreement_price;
                            b.xiti_f10 = b.agreement_fee;
                            b.xiti_f11 = b.agreement_total_price;
                            b.xiti_f11 = b.agreement_price;
                            b.xiti_f12 = b.step_number;
                            b.xiti_f13 = b.step_status;
                            b.xiti_f14 = b.error_status;
                            b.xiti_f15 = b.user_id_new;
                            b.xiti_f16 = b.warranty_type;
                        } else {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.step_name;
                            b.xiti_f3 = b.listid;
                            b.xiti_f4 = b.price;
                            b.xiti_f5 = b.cat_id;
                            b.xiti_f6 = b.subcat_id;
                            b.xiti_f7 = b.store_id_annonceur;
                            b.xiti_f8 = b.agreement_initiator;
                            b.xiti_f9 = b.agreement_price;
                            b.xiti_f10 = b.agreement_fee;
                            b.xiti_f11 = b.agreement_total_price;
                            b.xiti_f11 = b.agreement_price;
                            b.xiti_f12 = b.step_number;
                            b.xiti_f13 = b.step_status;
                            b.xiti_f14 = b.error_status;
                            b.xiti_f16 = b.warranty_type;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "vehicles") {
                        if (typeof getATInternetTag !== 'undefined') {
                            getATInternetTag().setProp('entry_point', b.entry_point, false);
                            getATInternetTag().setProp('n:ad_listid', b.ad_listid, false);
                            getATInternetTag().setProp('n:ad_poster_id', b.ad_poster_id, false);
                            getATInternetTag().setProp('ad_poster_type', b.ad_poster_type, false);
                            getATInternetTag().setProp('f:ad_price', b.ad_price, false);
                            getATInternetTag().setProp('funding_availability', b.funding_availability, false);
                            getATInternetTag().setProp('funding_loan_filling', b.funding_loan_filling, false);
                            getATInternetTag().setProp('cat_id', b.cat_id, false);
                            getATInternetTag().setProp('subcat_id', b.subcat_id, false);
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.project_name;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.section_name;
                            b.xiti_f5 = b.action;
                            b.xiti_f6 = b.action_value;
                            b.xiti_f7 = b.lead_total;
                            b.xiti_f8 = b.cat_id;
                            b.xiti_f9 = b.subcat_id;
                            b.xiti_f10 = b.store_id;
                            b.xiti_f11 = b.user_id;
                        } else {
                            b.xiti_f1 = b.project_name;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.section_name;
                            b.xiti_f5 = b.action;
                            b.xiti_f6 = b.action_value;
                            b.xiti_f7 = b.lead_total;
                            b.xiti_f8 = b.cat_id;
                            b.xiti_f9 = b.subcat_id;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.offline === "1") {
                        window.xt_offline = "&cn=offline" + "&olt=" + b.olt;
                        if (window.xtparam != null) {
                            window.xtparam += window.xt_offline;
                        } else {
                            window.xtparam = window.xt_offline;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    b.previouspage = encodeURIComponent(b.previouspage);
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            if (b.parrot_enable == 0) {
                b.parrot_enable = 999;
            }
            if (b.parrot_enable == 999 & b.parrot_used == 0) {
                b.parrot_used = 999;
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.action !== undefined) {
                        b.actiondescription2 = b.action;
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "accueil") {
                        b.xiti_f1 = b.consent_comp;
                        b.xiti_f2 = b.consent_geo;

                        function getCookie(sName) {
                            var cookContent = document.cookie,
                                cookEnd, i, j;
                            var sName = sName + "=";
                            for (i = 0, c = cookContent.length; i < c; i++) {
                                j = i + sName.length;
                                if (cookContent.substring(i, j) == sName) {
                                    cookEnd = cookContent.indexOf(";", j);
                                    if (cookEnd == -1) {
                                        cookEnd = cookContent.length;
                                    }
                                    return decodeURIComponent(cookContent.substring(j, cookEnd));
                                }
                            }
                            return null;
                        }
                        var monCookieBanner = getCookie('cookieBanner');
                        if (monCookieBanner === null) {
                            monCookieBanner = 0;
                        }
                        b.xiti_f3 = monCookieBanner;
                        b.xiti_f4 = b.consent_allpurpose;
                        b.xiti_f5 = b.widgets;
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "ad_search") {
                        var searchfilters = "";
                        for (var i in b.search_filters) {
                            if (i != 0) {
                                if (b.search_filters.hasOwnProperty(i)) {
                                    searchfilters += i + "::" + b.search_filters[i] + "|";
                                }
                            }
                        }
                        var searchfilters2 = searchfilters.split('|');
                        var loc = "";
                        var loc = b.location_type + ";" + b.region + ";" + b.departement + ";" + b.city + ";" + b.shippable + ";" + b.adsearch_with_shippable_ads + ";" + b.place + ";" + b.donation + ";" + b.search_referrer_id;
                        var f1 = "";
                        if (b.cat_id !== undefined) {
                            f1 = b.cat_id;
                        } else {
                            f1 = 0;
                        }
                        var f2 = "";
                        if (b.subcat_id !== undefined) {
                            f2 = b.subcat_id;
                        }
                        var keyword = "";
                        var qs_th = location.search.split('th=')[1];
                        var qs_o = location.search.split('o=')[1];
                        var qs_q = location.search.split('q=')[1];
                        var qs_f = location.search.split('f=')[1];
                        if (b.search !== undefined) {
                            keyword = b.search;
                        }
                        if (b.search === undefined && qs_th !== undefined) {
                            keyword = "recherche_sans_mot_cle";
                        }
                        if (b.search === undefined && qs_o !== undefined && qs_q === undefined) {
                            keyword = "recherche_sans_mot_cle";
                        }
                        if (b.rayonkm !== undefined) {
                            var f20 = b.rayonkm;
                        } else {
                            var f20 = 0;
                        }
                        if (b.consent_allpurpose !== undefined) {
                            var f18 = b.consent_allpurpose;
                        } else {
                            var f18 = "";
                        }
                        if (b.parrot_used !== undefined) {
                            var f19 = b.parrot_used;
                        } else {
                            var f19 = "";
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = f1;
                            b.xiti_f2 = f2;
                            b.xiti_f3 = loc;
                            b.xiti_f4 = keyword;
                            b.xiti_f5 = b.nbresultat;
                            b.xiti_f6 = searchfilters2[0] !== undefined ? searchfilters2[0] : "";
                            b.xiti_f7 = searchfilters2[1] !== undefined ? searchfilters2[1] : "";
                            b.xiti_f8 = searchfilters2[2] !== undefined ? searchfilters2[2] : "";
                            b.xiti_f9 = searchfilters2[3] !== undefined ? searchfilters2[3] : "";
                            b.xiti_f10 = searchfilters2[4] !== undefined ? searchfilters2[4] : "";
                            b.xiti_f11 = searchfilters2[5] !== undefined ? searchfilters2[5] : "";
                            b.xiti_f12 = searchfilters2[6] !== undefined ? searchfilters2[6] : "";
                            b.xiti_f13 = searchfilters2[7] !== undefined ? searchfilters2[7] : "";
                            b.xiti_f14 = searchfilters2[8] !== undefined ? searchfilters2[8] : "";
                            b.xiti_f15 = searchfilters2[9] !== undefined ? searchfilters2[9] : "";
                            b.xiti_f16 = searchfilters2[10] !== undefined ? searchfilters2[10] : "";
                            b.xiti_f17 = searchfilters2[11] !== undefined ? searchfilters2[11] : "";
                            b.xiti_f18 = f18;
                            b.xiti_f19 = f19;
                            b.xiti_f20 = f20;
                        } else {
                            b.xiti_f1 = f1;
                            b.xiti_f2 = f2;
                            b.xiti_f3 = loc;
                            b.xiti_f4 = keyword;
                            b.xiti_f5 = b.nbresultat;
                            b.xiti_f6 = searchfilters2[0] !== undefined ? searchfilters2[0] : "";
                            b.xiti_f7 = searchfilters2[1] !== undefined ? searchfilters2[1] : "";
                            b.xiti_f8 = searchfilters2[2] !== undefined ? searchfilters2[2] : "";
                            b.xiti_f9 = searchfilters2[3] !== undefined ? searchfilters2[3] : "";
                            b.xiti_f10 = searchfilters2[4] !== undefined ? searchfilters2[4] : "";
                            b.xiti_f11 = searchfilters2[5] !== undefined ? searchfilters2[5] : "";
                            b.xiti_f12 = searchfilters2[6] !== undefined ? searchfilters2[6] : "";
                            b.xiti_f13 = searchfilters2[7] !== undefined ? searchfilters2[7] : "";
                            b.xiti_f14 = searchfilters2[8] !== undefined ? searchfilters2[8] : "";
                            b.xiti_f15 = searchfilters2[9] !== undefined ? searchfilters2[9] : "";
                            b.xiti_f16 = searchfilters2[10] !== undefined ? searchfilters2[10] : "";
                            b.xiti_f17 = searchfilters2[11] !== undefined ? searchfilters2[11] : "";
                            b.xiti_f18 = f18;
                            b.xiti_f19 = f19;
                            b.xiti_f20 = f20;
                        }
                    }
                    if (b.eventname === "ad_search") {
                        var searchfilters = "";
                        for (var i in b.search_filters) {
                            if (i != 0) {
                                if (b.search_filters.hasOwnProperty(i)) {
                                    searchfilters += i + "::" + b.search_filters[i] + "|";
                                }
                            }
                        }
                        var searchfilters2 = searchfilters.split('|');
                        var loc = "";
                        var loc = b.location_type + ";" + b.region + ";" + b.departement + ";" + b.city + ";" + b.shippable + ";" + b.adsearch_with_shippable_ads + ";" + b.place + ";" + b.donation + ";" + b.search_referrer_id;
                        var f1 = "";
                        if (b.cat_id !== undefined) {
                            f1 = b.cat_id;
                        } else {
                            f1 = 0;
                        }
                        var f2 = "";
                        if (b.subcat_id !== undefined) {
                            f2 = b.subcat_id;
                        }
                        var keyword = "";
                        var qs_th = location.search.split('th=')[1];
                        var qs_o = location.search.split('o=')[1];
                        var qs_q = location.search.split('q=')[1];
                        var qs_f = location.search.split('f=')[1];
                        if (b.search !== undefined) {
                            keyword = b.search;
                        }
                        if (b.search === undefined && qs_th !== undefined) {
                            keyword = "recherche_sans_mot_cle";
                        }
                        if (b.search === undefined && qs_o !== undefined && qs_q === undefined) {
                            keyword = "recherche_sans_mot_cle";
                        }
                        if (b.rayonkm !== undefined) {
                            var f20 = b.rayonkm;
                        } else {
                            var f20 = 0;
                        }
                        if (b.consent_allpurpose !== undefined) {
                            var f18 = b.consent_allpurpose;
                        } else {
                            var f18 = "";
                        }
                        if (b.parrot_used !== undefined) {
                            var f19 = b.parrot_used;
                        } else {
                            var f19 = "";
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = f1;
                            b.xiti_f2 = f2;
                            b.xiti_f3 = loc;
                            b.xiti_f4 = keyword;
                            b.xiti_f5 = b.nbresultat;
                            b.xiti_f6 = searchfilters2[0] !== undefined ? searchfilters2[0] : "";
                            b.xiti_f7 = searchfilters2[1] !== undefined ? searchfilters2[1] : "";
                            b.xiti_f8 = searchfilters2[2] !== undefined ? searchfilters2[2] : "";
                            b.xiti_f9 = searchfilters2[3] !== undefined ? searchfilters2[3] : "";
                            b.xiti_f10 = searchfilters2[4] !== undefined ? searchfilters2[4] : "";
                            b.xiti_f11 = searchfilters2[5] !== undefined ? searchfilters2[5] : "";
                            b.xiti_f12 = searchfilters2[6] !== undefined ? searchfilters2[6] : "";
                            b.xiti_f13 = searchfilters2[7] !== undefined ? searchfilters2[7] : "";
                            b.xiti_f14 = searchfilters2[8] !== undefined ? searchfilters2[8] : "";
                            b.xiti_f15 = searchfilters2[9] !== undefined ? searchfilters2[9] : "";
                            b.xiti_f16 = searchfilters2[10] !== undefined ? searchfilters2[10] : "";
                            b.xiti_f17 = searchfilters2[11] !== undefined ? searchfilters2[11] : "";
                            b.xiti_f18 = f18;
                            b.xiti_f19 = f19;
                            b.xiti_f20 = f20;
                        } else {
                            b.xiti_f1 = f1;
                            b.xiti_f2 = f2;
                            b.xiti_f3 = loc;
                            b.xiti_f4 = keyword;
                            b.xiti_f5 = b.nbresultat;
                            b.xiti_f6 = searchfilters2[0] !== undefined ? searchfilters2[0] : "";
                            b.xiti_f7 = searchfilters2[1] !== undefined ? searchfilters2[1] : "";
                            b.xiti_f8 = searchfilters2[2] !== undefined ? searchfilters2[2] : "";
                            b.xiti_f9 = searchfilters2[3] !== undefined ? searchfilters2[3] : "";
                            b.xiti_f10 = searchfilters2[4] !== undefined ? searchfilters2[4] : "";
                            b.xiti_f11 = searchfilters2[5] !== undefined ? searchfilters2[5] : "";
                            b.xiti_f12 = searchfilters2[6] !== undefined ? searchfilters2[6] : "";
                            b.xiti_f13 = searchfilters2[7] !== undefined ? searchfilters2[7] : "";
                            b.xiti_f14 = searchfilters2[8] !== undefined ? searchfilters2[8] : "";
                            b.xiti_f15 = searchfilters2[9] !== undefined ? searchfilters2[9] : "";
                            b.xiti_f16 = searchfilters2[10] !== undefined ? searchfilters2[10] : "";
                            b.xiti_f17 = searchfilters2[11] !== undefined ? searchfilters2[11] : "";
                            b.xiti_f18 = f18;
                            b.xiti_f19 = f19;
                            b.xiti_f20 = f20;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "ad_view::detail") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.listid;
                            b.xiti_f2 = "!!pending_adid!!";
                            b.xiti_f3 = b.titre;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.prix;
                            b.xiti_f11 = b.nbphoto;
                            b.xiti_f12 = b.options;
                            b.xiti_f13 = b.store_id_annonceur;
                            b.xiti_f14 = b.store_id;
                            b.xiti_f15 = "!!pending_creationdate!!";
                            b.xiti_f16 = b.publish_date;
                            b.xiti_f17 = b.last_update_date;
                            b.xiti_f18 = b.offres;
                            b.xiti_f19 = b.boutique_id;
                            b.xiti_f20 = b.transaction_ad_type;
                        } else {
                            b.xiti_f1 = b.listid;
                            b.xiti_f2 = "!!pending_adid!!";
                            b.xiti_f3 = b.titre;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.prix;
                            b.xiti_f11 = b.nbphoto;
                            b.xiti_f12 = b.options;
                            b.xiti_f13 = b.store_id_annonceur;
                            b.xiti_f15 = "!!pending_creationdate!!";
                            b.xiti_f16 = b.publish_date;
                            b.xiti_f17 = b.last_update_date;
                            b.xiti_f18 = b.offres;
                            b.xiti_f19 = b.boutique_id;
                            b.xiti_f20 = b.transaction_ad_type;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "authent") {
                        if (typeof getATInternetTag !== 'undefined') {
                            getATInternetTag().setProp('action', b.action, false);
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.original_section;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.previouspage;
                            b.xiti_f4 = b.step_name;
                            b.xiti_f5 = b.step_number;
                            b.xiti_f6 = b.step_status;
                            b.xiti_f7 = b.error_status;
                            b.xiti_f8 = b.device;
                            b.xiti_f9 = b.uid;
                            b.xiti_f10 = b.store_id;
                            b.xiti_f11 = b.user_account;
                            b.xiti_f12 = b.path_type;
                        } else {
                            b.xiti_f1 = b.original_section;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.previouspage;
                            b.xiti_f4 = b.step_name;
                            b.xiti_f5 = b.step_number;
                            b.xiti_f6 = b.step_status;
                            b.xiti_f7 = b.error_status;
                            b.xiti_f8 = b.device;
                            b.xiti_f11 = b.user_account;
                            b.xiti_f12 = b.path_type;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "kyc") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.step;
                            b.xiti_f17 = b.error_status;
                            b.xiti_f18 = b.compte;
                        } else {
                            b.xiti_f1 = b.path;
                            b.xiti_f2 = b.step;
                            b.xiti_f17 = b.error_status;
                            b.xiti_f18 = b.compte;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "compte_part::tableau_de_bord") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.online_ads;
                        } else {
                            b.xiti_f1 = b.online_ads;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "compte_pro::mon_activite") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.pro_activity;
                            b.xiti_f2 = b.ad_category_sector;
                            b.xiti_f3 = b.low_contact_ads;
                            b.xiti_f4 = b.low_view_ads;
                            b.xiti_f5 = b.old_ads;
                            b.xiti_f6 = b.online_ads;
                            b.xiti_f7 = b.ads_with_problems;
                            b.xiti_f8 = b.widget;
                        } else {
                            b.xiti_f1 = b.pro_activity;
                            b.xiti_f2 = b.ad_category_sector;
                            b.xiti_f3 = b.low_contact_ads;
                            b.xiti_f4 = b.low_view_ads;
                            b.xiti_f5 = b.old_ads;
                            b.xiti_f6 = b.online_ads;
                            b.xiti_f7 = b.ads_with_problems;
                            b.xiti_f8 = b.widget;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname.startsWith("p2p") && b.eventname !== "p2p_vehicle") {
                        if (typeof getATInternetTag !== 'undefined') {
                            getATInternetTag().setProp('f:items', b.items, false);
                            getATInternetTag().setProp('f:items_available', b.items_available, false);
                            getATInternetTag().setProp('project_name', b.project_name, false);
                            getATInternetTag().setProp('step_name', b.step_name, false);
                            getATInternetTag().setProp('action', b.action, false);
                            getATInternetTag().setProp('action_value', b.action_value, false);
                            getATInternetTag().setProp('path_type', b.path_type, false);
                            getATInternetTag().setProp('order_id', b.order_id, false);
                        }
                        var array = b.eventname.split('::').filter(Boolean);
                        b.eventname = array.shift();
                        var path = (path = array.shift()) !== undefined ? path : "";
                        var step = "";
                        for (var i = 0;
                            (array[i]) && (step = step.concat(array[i++])) && (i < array.length);) {
                            step = step.concat("::");
                        }
                        if (b.seller_agreement_settings !== undefined) {
                            b.xiti_f1 = path;
                            b.xiti_f2 = step;
                            b.xiti_f3 = b.listid;
                            b.xiti_f4 = b.prix;
                            b.xiti_f5 = b.cat_id;
                            b.xiti_f6 = b.subcat_id;
                            b.xiti_f7 = b.store_id_annonceur;
                            b.xiti_f8 = b.deal_initiator;
                            b.xiti_f9 = b.seller_agreement_settings.deal_price;
                            b.xiti_f10 = b.seller_agreement_settings.deal_exchange_type;
                            b.xiti_f11 = b.seller_agreement_settings.deal_delivery;
                            b.xiti_f12 = b.seller_agreement_settings.deal_delivery_costs;
                            b.xiti_f13 = b.seller_agreement_settings.deal_fee;
                            b.xiti_f14 = b.seller_agreement_settings.deal_total_price;
                            b.xiti_f15 = b.error_status;
                            b.xiti_f16 = b.payment_type;
                            b.xiti_f17 = b.original_section;
                            b.xiti_f19 = b.ad_poster_type;
                        } else {
                            b.xiti_f1 = path;
                            b.xiti_f2 = step;
                            b.xiti_f3 = b.listid;
                            b.xiti_f4 = b.prix;
                            b.xiti_f5 = b.cat_id;
                            b.xiti_f6 = b.subcat_id;
                            b.xiti_f7 = b.store_id_annonceur;
                            b.xiti_f8 = b.deal_initiator;
                            b.xiti_f15 = b.error_status;
                            b.xiti_f16 = b.payment_type;
                            b.xiti_f17 = b.original_section;
                            b.xiti_f19 = b.ad_poster_type;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "depository") {
                        if (typeof getATInternetTag !== 'undefined') {
                            getATInternetTag().setProp('path_type', b.path_type, false);
                            getATInternetTag().setProp('original_section', b.original_section, false);
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.original_section;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.previouspage;
                            b.xiti_f4 = b.step_name;
                            b.xiti_f5 = b.step_number;
                            b.xiti_f6 = b.step_status;
                            b.xiti_f7 = b.error_status;
                            b.xiti_f8 = b.device;
                            b.xiti_f9 = b.logged_user;
                            b.xiti_f10 = b.store_id;
                            b.xiti_f11 = b.cat_id;
                            b.xiti_f12 = b.subcat_id;
                            b.xiti_f13 = b.ad_params;
                            b.xiti_f14 = b.compte;
                            b.xiti_f16 = b.ad_type;
                            b.xiti_f17 = b.ad_options;
                            b.xiti_f18 = b.payment_type;
                            b.xiti_f19 = b.category_source;
                            b.xiti_f20 = b.order_id;
                        } else {
                            b.xiti_f1 = b.original_section;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.previouspage;
                            b.xiti_f4 = b.step_name;
                            b.xiti_f5 = b.step_number;
                            b.xiti_f6 = b.step_status;
                            b.xiti_f7 = b.error_status;
                            b.xiti_f8 = b.device;
                            b.xiti_f9 = b.logged_user;
                            b.xiti_f11 = b.cat_id;
                            b.xiti_f12 = b.subcat_id;
                            b.xiti_f13 = b.ad_params;
                            b.xiti_f14 = b.compte;
                            b.xiti_f16 = b.ad_type;
                            b.xiti_f17 = b.ad_options;
                            b.xiti_f18 = b.payment_type;
                            b.xiti_f19 = b.category_source;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname.startsWith("kyc::")) {
                        var array = b.eventname.split('::').filter(Boolean);
                        b.eventname = array.shift();
                        var path = (path = array.shift()) !== undefined ? path : "";
                        var step = "";
                        for (var i = 0;
                            (array[i]) && (step = step.concat(array[i++])) && (i < array.length);) {
                            step = step.concat("::");
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = path;
                            b.xiti_f2 = step;
                            b.xiti_f3 = b.listid;
                            b.xiti_f4 = b.prix;
                            b.xiti_f5 = b.cat_id;
                            b.xiti_f6 = b.subcat_id;
                            b.xiti_f7 = b.store_id_annonceur;
                            b.xiti_f8 = b.deal_initiator;
                            b.xiti_f9 = b.seller_agreement_settings.deal_price;
                            b.xiti_f10 = b.seller_agreement_settings.deal_exchange_type;
                            b.xiti_f11 = b.seller_agreement_settings.deal_delivery;
                            b.xiti_f12 = b.seller_agreement_settings.deal_delivery_costs;
                            b.xiti_f13 = b.seller_agreement_settings.deal_fee;
                            b.xiti_f14 = b.seller_agreement_settings.deal_total_price;
                            b.xiti_f15 = b.kyc_source;
                            b.xiti_f16 = b.kyc_level;
                        } else {
                            b.xiti_f1 = path;
                            b.xiti_f2 = step;
                            b.xiti_f3 = b.listid;
                            b.xiti_f4 = b.prix;
                            b.xiti_f5 = b.cat_id;
                            b.xiti_f6 = b.subcat_id;
                            b.xiti_f7 = b.store_id_annonceur;
                            b.xiti_f8 = b.deal_initiator;
                            b.xiti_f9 = b.seller_agreement_settings.deal_price;
                            b.xiti_f10 = b.seller_agreement_settings.deal_exchange_type;
                            b.xiti_f11 = b.seller_agreement_settings.deal_delivery;
                            b.xiti_f12 = b.seller_agreement_settings.deal_delivery_costs;
                            b.xiti_f13 = b.seller_agreement_settings.deal_fee;
                            b.xiti_f14 = b.seller_agreement_settings.deal_total_price;
                            b.xiti_f15 = b.kyc_source;
                            b.xiti_f16 = b.kyc_level;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "legal::privacy::consent") {
                        b.xiti_f1 = b.consent_page;
                        b.xiti_f2 = b.purpose_1;
                        b.xiti_f3 = b.purpose_2;
                        b.xiti_f4 = b.purpose_3;
                        b.xiti_f5 = b.purpose_4;
                        b.xiti_f6 = b.purpose_5;
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    b.smartXtn2 = "0";
                    if (b.pagetype === "accueil") {
                        b.smartXtn2 = "1";
                    }
                    if (b.pagetype === "annonce" || b.pagetype === "annonce_partager" || b.pagetype === "annonce_signaler") {
                        b.smartXtn2 = "2";
                    }
                    if (b.pagetype === "annonce_deposer" || b.pagetype === "annonce_modifier" || b.pagetype === "annonce_prolonger" || b.pagetype === "annonce_supprimer" || b.pagetype === "annonce_gerer") {
                        b.smartXtn2 = "3";
                    }
                    if (b.pagetype === "annonce_contacter") {
                        b.smartXtn2 = "4";
                    }
                    if (b.pagetype === "compte" || b.pagetype === "connexion" || b.pagetype === "deconnexion") {
                        b.smartXtn2 = "5";
                    }
                    if (b.pagetype === "erreur_technique") {
                        b.smartXtn2 = "6";
                    }
                    if (b.pagetype === "recherche_automatique" || b.pagetype === "annonces_sauvegardees" || b.pagetype === "annonce_en_ligne" || b.pagetype === "contenu") {
                        b.smartXtn2 = "7";
                    }
                    if (b.pagetype === "recherche") {
                        b.smartXtn2 = "8";
                    }
                    if (b.pagetype === "soyouz") {
                        b.smartXtn2 = "10";
                    }
                    if (b.pagetype === "messaging") {
                        b.smartXtn2 = "11";
                    }
                    if (b.pagetype === "saved_ads") {
                        b.smartXtn2 = "12";
                    }
                    if (b.pagetype === "saved_search") {
                        b.smartXtn2 = "13";
                    }
                    if (b.pagetype === "shop_part") {
                        b.smartXtn2 = "14";
                    }
                    if (b.pagetype === "shop_pro") {
                        b.smartXtn2 = "15";
                    }
                    if (b.pagetype === "p2p") {
                        b.smartXtn2 = "19";
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "compte_pro::ads_widget") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.activity_sector !== undefined ? b.activity_sector : "";
                            b.xiti_f2 = b.low_visible_ads !== undefined ? b.low_visible_ads : "";
                            b.xiti_f3 = b.low_attractive_ads !== undefined ? b.low_attractive_ads : "";
                            b.xiti_f4 = b.online_ads !== undefined ? b.online_ads : "";
                            b.xiti_f5 = b.tab !== undefined ? b.tab : "";
                            b.xiti_f6 = b.cta !== undefined ? b.cta : "";
                            b.xiti_f7 = b.cta_type !== undefined ? b.cta_type : "";
                            b.xiti_f8 = b.nb_ads_selected !== undefined ? b.nb_ads_selected : "";
                            b.xiti_f9 = b.feature !== undefined ? b.feature : "";
                            b.xiti_f10 = b.feature_value !== undefined ? b.feature_value : "";
                            b.xiti_f11 = b.load !== undefined ? b.load : "";
                            b.xiti_f12 = b.pro_type !== undefined ? b.pro_type : "";
                            b.xiti_f13 = b.list_id;
                            b.xiti_f14 = b.nb_ads_per_page;
                        } else {
                            b.xiti_f1 = b.activity_sector !== undefined ? b.activity_sector : "";
                            b.xiti_f2 = b.low_visible_ads !== undefined ? b.low_visible_ads : "";
                            b.xiti_f3 = b.low_attractive_ads !== undefined ? b.low_attractive_ads : "";
                            b.xiti_f4 = b.online_ads !== undefined ? b.online_ads : "";
                            b.xiti_f5 = b.tab !== undefined ? b.tab : "";
                            b.xiti_f6 = b.cta !== undefined ? b.cta : "";
                            b.xiti_f7 = b.cta_type !== undefined ? b.cta_type : "";
                            b.xiti_f8 = b.nb_ads_selected !== undefined ? b.nb_ads_selected : "";
                            b.xiti_f9 = b.feature !== undefined ? b.feature : "";
                            b.xiti_f10 = b.feature_value !== undefined ? b.feature_value : "";
                            b.xiti_f11 = b.load !== undefined ? b.load : "";
                            b.xiti_f12 = b.pro_type !== undefined ? b.pro_type : "";
                            b.xiti_f13 = b.list_id;
                            b.xiti_f14 = b.nb_ads_per_page;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "ident") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path !== undefined ? b.path : "";
                            b.xiti_f2 = b.previouspage !== undefined ? b.previouspage : "";
                            b.xiti_f3 = b.step_name !== undefined ? b.step_name : "";
                            b.xiti_f4 = b.step_number !== undefined ? b.step_number : "";
                            b.xiti_f5 = b.step_status !== undefined ? b.step_status : "";
                            b.xiti_f6 = b.device !== undefined ? b.device : "";
                            b.xiti_f7 = b.store_id !== undefined ? b.store_id : "";
                            b.xiti_f8 = b.compte !== undefined ? b.compte : "";
                            b.xiti_f9 = b.widgets !== undefined ? b.widgets : "";
                            b.xiti_f10 = b.error_status !== undefined ? b.error_status : "";
                        } else {
                            b.xiti_f1 = b.path !== undefined ? b.path : "";
                            b.xiti_f2 = b.previouspage !== undefined ? b.previouspage : "";
                            b.xiti_f3 = b.step_name !== undefined ? b.step_name : "";
                            b.xiti_f4 = b.step_number !== undefined ? b.step_number : "";
                            b.xiti_f5 = b.step_status !== undefined ? b.step_status : "";
                            b.xiti_f6 = b.device !== undefined ? b.device : "";
                            b.xiti_f8 = b.compte !== undefined ? b.compte : "";
                            b.xiti_f9 = b.widgets !== undefined ? b.widgets : "";
                            b.xiti_f10 = b.error_status !== undefined ? b.error_status : "";
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (typeof getATInternetTag !== 'undefined' && localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                        getATInternetTag().setProp('account_id', b.account_id, true);
                    }
                    if (typeof getATInternetTag !== 'undefined' && localStorage.getItem('consent_mesureaudience_visitormode') !== 'optout') {
                        getATInternetTag().setProp('experiment_name', b.experiment_name, true);
                        getATInternetTag().setProp('experiment_variant', b.experiment_variant, true);
                        getATInternetTag().setProp('experiment_application', b.experiment_application, true);
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    b.previouspage = encodeURIComponent(b.previouspage);
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (document.location.href.includes('?code=')) {
                        if (document.location.href.includes('/mes-annonces/')) {
                            xt_med("F", "0", "authent&f1=myfavorite&f2=login_lbc_connect&f3=&f4=login_confirmation_lbc_connect&f5=2&f6=final_step" + '&x1=' + b.platformdevice + '&x2=' + b.displaytype + '&x3=' + b.pagetype + '&x4=' + b.previouspage + '&x6=' + b.actiondescritpion)
                        } else {
                            xt_med("F", "0", "authent&f1=&f2=login_lbc_connect&f3=&f4=login_confirmation_lbc_connect&f5=2&f6=final_step" + '&x1=' + b.platformdevice + '&x2=' + b.displaytype + '&x3=' + b.pagetype + '&x4=' + b.previouspage + '&x6=' + b.actiondescritpion)
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    var myRefPilgo = window.document.referrer;
                    if (myRefPilgo.includes('hotel.leboncoin.fr')) {
                        if (window.pilgoTracking !== true) {
                            xt_med("F", "0", "pilgo" + '&x1=' + b.platformdevice + '&x2=' + b.displaytype + '&x3=' + b.pagetype + '&x4=' + b.previouspage + '&x6=' + b.actiondescritpion)
                            window.pilgoTracking = true;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.store_id.length > 0 || b.store_id > 0) {
                        b.user_log_custom_var = 2;
                    } else if (b.store_id === "undefined" || b.store_id === "") {
                        b.user_log_custom_var = 0;
                    } else {
                        b.user_log_custom_var = 0;
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "maps") {
                        var locations_cdv = {
                            city: b.city,
                            around_city: b.city,
                            department: b.departement,
                            department_nearby_departments: b.departement,
                            region: b.region,
                            region_nearby_regions: b.region,
                            bounding_box: undefined,
                            place: b.place
                        };
                        var locationValue_cdv = locations_cdv[b.location_type];
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.cat_id;
                            b.xiti_f2 = b.subcat_id;
                            b.xiti_f3 = locationValue_cdv;
                            b.xiti_f4 = b.location_type;
                            b.xiti_f5 = b.search;
                            b.xiti_f6 = b.nbresultat;
                            b.xiti_f7 = b.store_id_annonceur;
                            b.xiti_f8 = ((b.search_filters || {}).capacity_max) || "";
                            b.xiti_f9 = ((b.search_filters || {}).capacity_min) || "";
                            b.xiti_f10 = ((b.search_filters || {}).price_max) || "";
                            b.xiti_f11 = ((b.search_filters || {}).price_min) || "";
                            b.xiti_f12 = ((b.search_filters || {}).holidays_real_estate_type) || "";
                            b.xiti_f13 = b.rayonkm;
                            b.xiti_f14 = b.price;
                            b.xiti_f15 = b.action;
                            b.xiti_f16 = ((b.search_filters || {}).date_max) || "";
                            b.xiti_f17 = ((b.search_filters || {}).date_min) || "";
                            b.xiti_f18 = b.ad_id;
                            b.xiti_f19 = b.maps_location;
                        } else {
                            b.xiti_f1 = b.cat_id;
                            b.xiti_f2 = b.subcat_id;
                            b.xiti_f3 = locationValue_cdv;
                            b.xiti_f4 = b.location_type;
                            b.xiti_f5 = b.search;
                            b.xiti_f6 = b.nbresultat;
                            b.xiti_f7 = b.store_id_annonceur;
                            b.xiti_f8 = ((b.search_filters || {}).capacity_max) || "";
                            b.xiti_f9 = ((b.search_filters || {}).capacity_min) || "";
                            b.xiti_f10 = ((b.search_filters || {}).price_max) || "";
                            b.xiti_f11 = ((b.search_filters || {}).price_min) || "";
                            b.xiti_f12 = ((b.search_filters || {}).holidays_real_estate_type) || "";
                            b.xiti_f13 = b.rayonkm;
                            b.xiti_f14 = b.price;
                            b.xiti_f15 = b.action;
                            b.xiti_f16 = ((b.search_filters || {}).date_max) || "";
                            b.xiti_f17 = ((b.search_filters || {}).date_min) || "";
                            b.xiti_f18 = b.ad_id;
                            b.xiti_f19 = b.maps_location;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "vertical") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.project_name;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.page_name;
                            b.xiti_f5 = b.section_name;
                            b.xiti_f6 = b.action;
                            b.xiti_f7 = b.action_value;
                            b.xiti_f8 = b.request_type;
                            b.xiti_f9 = b.delivery_name;
                            b.xiti_f10 = b.user_id;
                            b.xiti_f11 = b.store_id;
                            b.xiti_f12 = b.listid;
                            b.xiti_f13 = b.online_store_id;
                            b.xiti_f14 = b.activity_sector;
                            b.xiti_f15 = b.cat_id;
                            b.xiti_f16 = b.subcat_id;
                            b.xiti_f17 = b.pro_type;
                            b.xiti_f18 = b.offres;
                            b.xiti_f19 = b.compte;
                        } else {
                            b.xiti_f1 = b.project_name;
                            b.xiti_f2 = b.path;
                            b.xiti_f3 = b.step_name;
                            b.xiti_f4 = b.page_name;
                            b.xiti_f5 = b.section_name;
                            b.xiti_f6 = b.action;
                            b.xiti_f7 = b.action_value;
                            b.xiti_f8 = b.request_type;
                            b.xiti_f9 = b.delivery_name;
                            b.xiti_f12 = b.listid;
                            b.xiti_f13 = b.online_store_id;
                            b.xiti_f14 = b.activity_sector;
                            b.xiti_f15 = b.cat_id;
                            b.xiti_f16 = b.subcat_id;
                            b.xiti_f17 = b.pro_type;
                            b.xiti_f18 = b.offres;
                            b.xiti_f19 = b.compte;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    var myRefPilgo = window.document.referrer;
                    if (myRefPilgo.includes('hotel.leboncoin.fr')) {
                        if (window.pilgoTrackingSmarttag !== true) {
                            tag.page.send({
                                name: "pilgo" + '&x1=' + b.platformdevice + '&x2=' + b.displaytype + '&x3=' + b.pagetype + '&x4=' + b.previouspage + '&x6=' + b.actiondescritpion
                            })
                            window.pilgoTrackingSmarttag = true;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "messaging") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.page_name;
                            b.xiti_f2 = b.action;
                            b.xiti_f3 = b.store_id_annonceur;
                            b.xiti_f4 = b.store_id;
                            b.xiti_f5 = b.conversation_id;
                            b.xiti_f6 = b.compte;
                            b.xiti_f7 = b.cat_id;
                            b.xiti_f8 = b.subcat_id;
                            b.xiti_f9 = b.last_message_date;
                            b.xiti_f10 = b.listid;
                        } else {
                            b.xiti_f1 = b.page_name;
                            b.xiti_f2 = b.action;
                            b.xiti_f3 = b.store_id_annonceur;
                            b.xiti_f6 = b.compte;
                            b.xiti_f7 = b.cat_id;
                            b.xiti_f8 = b.subcat_id;
                            b.xiti_f9 = b.last_message_date;
                            b.xiti_f10 = b.listid;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "ad_reply::email::confirmation" || b.eventname === "ad_reply::email::formulaire") {
                        var opts = [];
                        if (b.options.booster != 0) {
                            opts.push("booster");
                        }
                        if (b.options.gallery != 0) {
                            opts.push("gallery");
                        }
                        if (b.options.photosup != 0) {
                            opts.push("photosup");
                        }
                        if (b.options.sub_toplist != 0) {
                            opts.push("sub_toplist");
                        }
                        if (b.options.urgent != 0) {
                            opts.push("urgent");
                        }
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.listid;
                            b.xiti_f2 = "!!pending_adid!!";
                            b.xiti_f3 = b.titre;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.price;
                            b.xiti_f11 = b.nbphoto;
                            b.xiti_f12 = opts.join('_');
                            b.xiti_f13 = b.store_id_annonceur;
                            b.xiti_f14 = b.store_id;
                            b.xiti_f15 = b.immo_sell_type;
                            b.xiti_f16 = b.publish_date;
                            b.xiti_f17 = b.last_update_date;
                            b.xiti_f18 = "";
                            if (b.siren != null) {
                                b.xiti_f18 = "pro";
                            } else {
                                b.xiti_f18 = "part";
                            }
                            b.xiti_f19 = b.store_id;
                        } else {
                            b.xiti_f1 = b.listid;
                            b.xiti_f2 = "!!pending_adid!!";
                            b.xiti_f3 = b.titre;
                            b.xiti_f4 = b.cat_id;
                            b.xiti_f5 = b.subcat_id;
                            b.xiti_f6 = b.region;
                            b.xiti_f7 = b.departement;
                            b.xiti_f8 = b.city;
                            b.xiti_f9 = b.ad_type;
                            b.xiti_f10 = b.price;
                            b.xiti_f11 = b.nbphoto;
                            b.xiti_f12 = opts.join('_');
                            b.xiti_f13 = b.store_id_annonceur;
                            b.xiti_f15 = b.immo_sell_type;
                            b.xiti_f16 = b.publish_date;
                            b.xiti_f17 = b.last_update_date;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "new_real_estate") {
                        if (localStorage.getItem('consent_mesureaudience_visitormode') === 'optin') {
                            b.xiti_f1 = b.path !== undefined ? b.path : "";
                            b.xiti_f2 = b.previouspage !== undefined ? b.previouspage : "";
                            b.xiti_f3 = b.step_name !== undefined ? b.step_name : "";
                            b.xiti_f4 = b.step_number !== undefined ? b.step_number : "";
                            b.xiti_f5 = b.step_status !== undefined ? b.step_status : "";
                            b.xiti_f6 = b.request_type !== undefined ? b.request_type : "";
                            b.xiti_f7 = b.device !== undefined ? b.device : "";
                            b.xiti_f8 = b.store_id !== undefined ? b.store_id : "";
                            b.xiti_f9 = b.userid !== undefined ? b.userid : "";
                            b.xiti_f10 = b.action !== undefined ? b.action : "";
                            b.xiti_f11 = b.action_value !== undefined ? b.action_value : "";
                            b.xiti_f12 = b.section_name !== undefined ? b.section_name : "";
                            b.xiti_f13 = b.listid !== undefined ? b.listid : "";
                            b.xiti_f14 = b.cat_id !== undefined ? b.cat_id : "";
                            b.xiti_f15 = b.subcat_id !== undefined ? b.subcat_id : "";
                            b.xiti_f16 = b.page_name !== undefined ? b.page_name : "";
                        } else {
                            b.xiti_f1 = b.path !== undefined ? b.path : "";
                            b.xiti_f2 = b.previouspage !== undefined ? b.previouspage : "";
                            b.xiti_f3 = b.step_name !== undefined ? b.step_name : "";
                            b.xiti_f4 = b.step_number !== undefined ? b.step_number : "";
                            b.xiti_f5 = b.step_status !== undefined ? b.step_status : "";
                            b.xiti_f6 = b.request_type !== undefined ? b.request_type : "";
                            b.xiti_f7 = b.device !== undefined ? b.device : "";
                            b.xiti_f10 = b.action !== undefined ? b.action : "";
                            b.xiti_f11 = b.action_value !== undefined ? b.action_value : "";
                            b.xiti_f12 = b.section_name !== undefined ? b.section_name : "";
                            b.xiti_f13 = b.listid !== undefined ? b.listid : "";
                            b.xiti_f14 = b.cat_id !== undefined ? b.cat_id : "";
                            b.xiti_f15 = b.subcat_id !== undefined ? b.subcat_id : "";
                            b.xiti_f16 = b.page_name !== undefined ? b.page_name : "";
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (document.location.href.includes('?code=')) {
                        if (document.location.href.includes('/mes-annonces/')) {
                            tag.page.send({
                                name: "authent&f1=myfavorite&f2=login_lbc_connect&f3=&f4=login_confirmation_lbc_connect&f5=2&f6=final_step" + '&x1=' + b.platformdevice + '&x2=' + b.displaytype + '&x3=' + b.pagetype + '&x4=' + b.previouspage + '&x6=' + b.actiondescritpion
                            })
                        } else {
                            tag.page.send({
                                name: "authent&f1=&f2=login_lbc_connect&f3=&f4=login_confirmation_lbc_connect&f5=2&f6=final_step" + '&x1=' + b.platformdevice + '&x2=' + b.displaytype + '&x3=' + b.pagetype + '&x4=' + b.previouspage + '&x6=' + b.actiondescritpion
                            })
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (b.eventname === "ad_search" && b.shippableAds === "1" && b.nbresultat === "0") {
                        b.eventname = 'no_results::shippable_ads ';
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if ((b.eventname.startsWith("p2p") || b.eventname.startsWith("kyc") || b.event_name.startsWith("p2p") || b.event_name.startsWith("kyc")) && b.eventname !== "p2p_vehicle") {
                        var datalayer_path = utag_data;
                        datalayer_path.eventname = datalayer_path.eventname || datalayer_path.event_name;
                        if (datalayer_path.eventname.startsWith("p2p::") && datalayer_path.eventname !== "p2p_vehicle") {
                            var array_cvpath = datalayer_path.eventname.split('::').filter(Boolean);
                            var cvpath = "";
                            var cvpath = (array_cvpath[1]) !== undefined ? array_cvpath[1] : ""; {
                                b.path_custom_var = cvpath;
                            }
                        } else if (datalayer_path.eventname.startsWith("kyc::")) {
                            datalayer_path.eventname = decodeURIComponent(datalayer_path.eventname)
                            var array_cvpath = datalayer_path.eventname.split('::').filter(Boolean);
                            var cvpath = "";
                            var cvpath = (array_cvpath[1]) !== undefined ? array_cvpath[1] : ""; {
                                b.path_custom_var = cvpath;
                            }
                        }
                    } else if (b.path === undefined && b.page_name !== undefined) {
                        b.path_custom_var = b.page_name;
                    } else {
                        if (b.path === undefined) {
                            b.path_custom_var = "";
                        } else {
                            b.path_custom_var = b.path;
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    if ((b.eventname.startsWith("p2p") || b.eventname.startsWith("kyc") || b.event_name.startsWith("p2p") || b.event_name.startsWith("kyc")) && b.eventname !== "p2p_vehicle") {
                        var datalayer_step = utag_data;
                        datalayer_step.eventname = datalayer_step.eventname || datalayer_step.event_name;
                        if (datalayer_step.eventname.startsWith("p2p::") && datalayer_step.eventname !== "p2p_vehicle") {
                            var array_cvstep = datalayer_step.eventname.split('::').filter(Boolean);
                            var cvstep = "";
                            var cvstep = (array_cvstep[2]) !== undefined ? array_cvstep[2] : ""; {
                                b.step_name_custom_var = cvstep;
                            }
                        } else if (datalayer_step.eventname.startsWith("kyc::")) {
                            datalayer_step.eventname = decodeURIComponent(datalayer_step.eventname)
                            var array_cvstep = datalayer_step.eventname.split('::').filter(Boolean);
                            var cvstep = "";
                            var cvstep = (array_cvstep[2]) !== undefined ? array_cvstep[2] : ""; {
                                b.step_name_custom_var = cvstep;
                            }
                        }
                    } else {
                        if (b.step_name === undefined && b.step === undefined) {
                            b.step_name_custom_var = "";
                        } else if (b.step_name !== undefined && b.step === undefined) {
                            b.step_name_custom_var = b.step_name;
                        } else if (b.step_name === undefined && b.step !== undefined) {
                            b.step_name_custom_var = b.step;
                        } else {
                            b.step_name_custom_var = "";
                        }
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    window.trackSmarttagpage = function() {
                        window.Smarttagpage();
                    }
                    window.checkSmarttag = function() {
                        var smarttagInDom = document.querySelector('head > script[src$="598455/smarttag.js"]');
                        var smarttagIsLoaded = typeof ATInternet;
                        if (smarttagInDom && smarttagIsLoaded) {
                            return true;
                        }
                        return false;
                    }
                    window.sendSmartTagRequest = function() {
                        var dom = window.document.domain;
                        if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.rav.proctool.leboncoin.io/.test(dom)) {
                            window.xtsite = 562496;
                        }
                        if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.dev.leboncoin.lan/.test(dom)) {
                            window.xtsite = 562495;
                        }
                        if (utag_data.environnement === "dev" && /[a-z]*.qa[0-9]{1}.bon-coin.net/.test(dom)) {
                            window.xtsite = 562496;
                        }
                        if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.next.proctool.leboncoin.io/.test(dom)) {
                            window.xtsite = 562496;
                        }
                        if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.next.ariane.leboncoin.ci/.test(dom)) {
                            window.xtsite = 562496;
                        }
                        if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.rav.ariane.leboncoin.ci/.test(dom)) {
                            window.xtsite = 562496;
                        }
                        if (utag_data.environnement === "dev" && /[a-z]*.[a-z]*.bon-coin.net/.test(dom)) {
                            window.xtsite = 562496;
                        }
                        if (utag_data.environnement === "qa") {
                            window.xtsite = 562496;
                        }
                        if (utag_data.environnement === "prod") {
                            window.xtsite = 562498;
                        }
                        if (window.ATInternet != undefined && window.ATInternet.Tracker && window.ATInternet.Tracker.instances[0]) {
                            window.ATInternet.Tracker.instances[0].setConfig("site", window.xtsite);
                            var tag = window.ATInternet.Tracker.instances[0];
                        } else {
                            var tag = new ATInternet.Tracker.Tag({
                                secure: true,
                                site: window.xtsite,
                                log: 'logw360',
                                logSSL: 'logws1360'
                            });
                        }
                        tag.privacy.updateStorageDuration(395);
                        tag.privacy.extendIncludeBuffer(['exempt#s', 'exempt#p', 'exempt#s2', 'exempt#apvr', 'exempt#x1', 'exempt#x2', 'exempt#x3', 'exempt#x4', 'exempt#x6', 'exempt#x7', 'exempt#x8', 'exempt#x9', 'exempt#x10', 'exempt#x11', 'exempt#x12', 'exempt#x13', 'exempt#x14', 'exempt#x15', 'exempt#x16', 'exempt#x17', 'exempt#x18', 'exempt#x19', 'exempt#x20', 'exempt#x21', 'exempt#f1', 'exempt#f2', 'exempt#f3', 'exempt#f4', 'exempt#f5', 'exempt#f6', 'exempt#f7', 'exempt#f8', 'exempt#f9', 'exempt#f10', 'exempt#f11', 'exempt#f12', 'exempt#f13', 'exempt#f14', 'exempt#f15', 'exempt#f16', 'exempt#f17', 'exempt#f18', 'exempt#f19', 'exempt#f20', 'exempt#f21', 'exempt#stc', 'exempt#ref', 'exempt#xto', 'exempt#xtor', 'exempt#r', 'exempt#ac', 'exempt#re', 'exempt#hl', 'exempt#lng', 'exempt#idp', 'exempt#jv', 'exempt#utagversion', 'exempt#utagjsenv', 'exempt#f:file_size', 'exempt#file_size', 'exempt#n:ad_listid', 'exempt#ad_listid', 'exempt#ad_poster_type', 'exempt#ad_price', 'exempt#f:ad_price', 'exempt#n:ad_poster_id', 'exempt#ad_poster_id', 'exempt#cat_id', 'exempt#subcat_id', 'exempt#category', 'exempt#sub_category', 'exempt#entry_point', 'exempt#funding_availability', 'exempt#funding_loan_filling', 'exempt#path_type', 'exempt#action_value', 'exempt#action', 'exempt#step_name', 'exempt#project_name', 'exempt#items_available', 'exempt#f:items_available', 'exempt#f:original_section', 'exempt#original_section', 'exempt#experiment_name', 'exempt#experiment_variant', 'exempt#experiment_application']);
                        if (b.immo_sell_type === "new" && (b.subcat_id === "undefined" || b.subcat_id === "")) {
                            b.subcat_id = "73";
                        }
                        if (b.subcat_id === "78") {
                            b.subcat_id = "9";
                        }
                        tag.page.set({
                            name: b.eventname,
                            level2: b.smartXtn2
                        });
                        tag.setParam("utagversion", utag.cfg.v);
                        tag.setParam("utagjsenv", utag.cfg.path.split("/")[6]);
                        tag.customVars.set({
                            site: {
                                1: "web_responsive-" + b.device,
                                2: b.privacy_concat !== undefined ? b.privacy_concat : "",
                                3: b.pagetype !== undefined ? b.pagetype : "",
                                4: b.previouspage !== undefined ? b.previouspage : "",
                                6: b.actiondescription2 !== undefined ? b.actiondescription2 : "",
                                7: b.listid !== undefined ? b.listid : "",
                                8: b.adid !== undefined ? b.adid : "",
                                9: b.cat_id !== undefined ? b.cat_id : "",
                                10: b.subcat_id !== undefined ? b.subcat_id : "",
                                11: b.region !== undefined ? b.region : "",
                                12: b.departement !== undefined ? b.departement : "",
                                13: b.ad_type !== undefined ? b.ad_type : "",
                                14: b.options !== undefined ? b.options : "",
                                15: b.store_id_annonceur !== undefined ? b.store_id_annonceur : "",
                                16: b.offres !== undefined ? b.offres : "",
                                17: b.path_custom_var !== undefined ? b.path_custom_var : "",
                                18: b.step_name_custom_var !== undefined ? b.step_name_custom_var : "",
                                19: b.user_log_custom_var !== undefined ? b.user_log_custom_var : "",
                                20: b.city !== undefined ? b.city : "",
                                21: b.boutique_id !== undefined ? b.boutique_id : ""
                            },
                            page: {
                                1: b.xiti_f1 !== undefined ? b.xiti_f1 : "",
                                2: b.xiti_f2 !== undefined ? b.xiti_f2 : "",
                                3: b.xiti_f3 !== undefined ? b.xiti_f3 : "",
                                4: b.xiti_f4 !== undefined ? b.xiti_f4 : "",
                                5: b.xiti_f5 !== undefined ? b.xiti_f5 : "",
                                6: b.xiti_f6 !== undefined ? b.xiti_f6 : "",
                                7: b.xiti_f7 !== undefined ? b.xiti_f7 : "",
                                8: b.xiti_f8 !== undefined ? b.xiti_f8 : "",
                                9: b.xiti_f9 !== undefined ? b.xiti_f9 : "",
                                10: b.xiti_f10 !== undefined ? b.xiti_f10 : "",
                                11: b.xiti_f11 !== undefined ? b.xiti_f11 : "",
                                12: b.xiti_f12 !== undefined ? b.xiti_f12 : "",
                                13: b.xiti_f13 !== undefined ? b.xiti_f13 : "",
                                14: b.xiti_f14 !== undefined ? b.xiti_f14 : "",
                                15: b.xiti_f15 !== undefined ? b.xiti_f15 : "",
                                16: b.xiti_f16 !== undefined ? b.xiti_f16 : "",
                                17: b.xiti_f17 !== undefined ? b.xiti_f17 : "",
                                18: b.xiti_f18 !== undefined ? b.xiti_f18 : "",
                                19: b.xiti_f19 !== undefined ? b.xiti_f19 : "",
                                20: b.xiti_f20 !== undefined ? b.xiti_f20 : ""
                            }
                        });
                        tag.identifiedVisitor.set({
                            id: b.store_id !== undefined ? parseInt(b.store_id) : 0,
                            category: b.compte !== undefined ? b.compte : ""
                        });
                        if (b.customObject !== undefined) {
                            tag.page.set({
                                customObject: {
                                    device: b.customObject.device
                                }
                            });
                        }
                        if (b.eventname === "ad_search") {
                            var qs_o = "";
                            var qs_q = "";
                            var urlCourante = document.location.href;
                            if (urlCourante.includes('page=')) {
                                qs_o = urlCourante.split('page=')[1];
                                qs_o = qs_o.split('&')[0];
                            } else if (b.nbresultat === "0") {
                                qs_o = "0";
                            } else {
                                qs_o = "1";
                            }
                            if (urlCourante.includes('text=')) {
                                qs_q = urlCourante.split('text=')[1];
                                qs_q = qs_q.split('&')[0];
                            } else {
                                qs_q = "";
                            }
                        }
                        tag.internalSearch.set({
                            keyword: qs_q,
                            resultPageNumber: qs_o
                        });
                        tag.dispatch();
                    }
                    window.Smarttagpage = function() {
                        if (window.checkSmarttag()) {} else {;
                            (function() {
                                var dfltPluginCfg = {
                                    "sourceFile": "upload",
                                    "info": true
                                };
                                var dfltGlobalCfg = {
                                    "site": 598455,
                                    "log": "",
                                    "logSSL": "",
                                    "domain": "ati-host.net",
                                    "collectDomain": "logw360.ati-host.net",
                                    "collectDomainSSL": "logws1360.ati-host.net",
                                    "secure": true,
                                    "pixelPath": "/hit.xiti",
                                    "disableCookie": false,
                                    "cookieSecure": false,
                                    "cookieDomain": "",
                                    "preview": false,
                                    "plgs": ["Campaigns", "Clicks", "ClientSideUserId", "ContextVariables", "IdentifiedVisitor", "InternalSearch", "MvTesting", "Offline", "OnSiteAds", "Page", "RichMedia", "SalesTracker"],
                                    "lazyLoadingPath": "",
                                    "documentLevel": "document",
                                    "redirect": false,
                                    "activateCallbacks": true,
                                    "medium": "",
                                    "ignoreEmptyChapterValue": true,
                                    "base64Storage": false,
                                    "sendHitWhenOptOut": true
                                };
                                (function(a) {
                                    a.ATInternet = a.ATInternet || {};
                                    a.ATInternet.Tracker = a.ATInternet.Tracker || {};
                                    a.ATInternet.Tracker.Plugins = a.ATInternet.Tracker.Plugins || {}
                                })(window);
                                var Utils = function() {
                                    function a(b) {
                                        var e = typeof b;
                                        if ("object" !== e || null === b) return "string" === e && (b = '"' + b + '"'), String(b);
                                        var c, l, m = [],
                                            q = b && b.constructor === Array;
                                        for (c in b) b.hasOwnProperty(c) && (l = b[c], e = typeof l, "function" !== e && "undefined" !== e && ("string" === e ? l = '"' + l.replace(/[^\\]"/g, '\\"') + '"' : "object" === e && null !== l && (l = a(l)), m.push((q ? "" : '"' + c + '":') + String(l))));
                                        return (q ? "[" : "{") + String(m) + (q ? "]" : "}")
                                    }

                                    function d(a) {
                                        return null === a ? "" : (a + "").replace(p, "")
                                    }

                                    function g(a) {
                                        var e, c = null;
                                        return (a = d(a + "")) && !d(a.replace(k, function(a, m, b, r) {
                                            e && m && (c = 0);
                                            if (0 === c) return a;
                                            e = b || m;
                                            c += !r - !b;
                                            return ""
                                        })) ? Function("return " + a)() : null
                                    }
                                    var b = this,
                                        k = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g,
                                        p = RegExp("^[\\x20\\t\\r\\n\\f]+|((?:^|[^\\\\])(?:\\\\.)*)[\\x20\\t\\r\\n\\f]+$", "g");
                                    b.Base64 = {
                                        _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                                        encode: function(a) {
                                            var e = "",
                                                c, l, m, q, r, u, f = 0;
                                            for (a = b.Base64._utf8_encode(a); f < a.length;) c = a.charCodeAt(f++), l = a.charCodeAt(f++), m = a.charCodeAt(f++), q = c >> 2, c = (c & 3) << 4 | l >> 4, r = (l & 15) << 2 | m >> 6, u = m & 63, isNaN(l) ? r = u = 64 : isNaN(m) && (u = 64), e = e + this._keyStr.charAt(q) + this._keyStr.charAt(c) + this._keyStr.charAt(r) + this._keyStr.charAt(u);
                                            return e
                                        },
                                        decode: function(a) {
                                            var e = "",
                                                c, l, m, q, r, u = 0;
                                            for (a = a.replace(/[^A-Za-z0-9\+\/\=]/g, ""); u < a.length;) c = this._keyStr.indexOf(a.charAt(u++)), l = this._keyStr.indexOf(a.charAt(u++)), q = this._keyStr.indexOf(a.charAt(u++)), r = this._keyStr.indexOf(a.charAt(u++)), c = c << 2 | l >> 4, l = (l & 15) << 4 | q >> 2, m = (q & 3) << 6 | r, e += String.fromCharCode(c), 64 != q && (e += String.fromCharCode(l)), 64 != r && (e += String.fromCharCode(m));
                                            return e = b.Base64._utf8_decode(e)
                                        },
                                        _utf8_encode: function(a) {
                                            a = a.replace(/\r\n/g, "\n");
                                            for (var e = "", c = 0; c < a.length; c++) {
                                                var l = a.charCodeAt(c);
                                                128 > l ? e += String.fromCharCode(l) : (127 < l && 2048 > l ? e += String.fromCharCode(l >> 6 | 192) : (e += String.fromCharCode(l >> 12 | 224), e += String.fromCharCode(l >> 6 & 63 | 128)), e += String.fromCharCode(l & 63 | 128))
                                            }
                                            return e
                                        },
                                        _utf8_decode: function(a) {
                                            for (var e = "", c = 0, l, m, b; c < a.length;) l = a.charCodeAt(c), 128 > l ? (e += String.fromCharCode(l), c++) : 191 < l && 224 > l ? (m = a.charCodeAt(c + 1), e += String.fromCharCode((l & 31) << 6 | m & 63), c += 2) : (m = a.charCodeAt(c + 1), b = a.charCodeAt(c + 2), e += String.fromCharCode((l & 15) << 12 | (m & 63) << 6 | b & 63), c += 3);
                                            return e
                                        }
                                    };
                                    b.loadScript = function(a, e) {
                                        var c;
                                        e = e || function() {};
                                        c = document.createElement("script");
                                        c.type = "text/javascript";
                                        c.src = a.url;
                                        c.async = !1;
                                        c.defer = !1;
                                        c.onload = c.onreadystatechange = function(a) {
                                            a = a || window.event;
                                            if ("load" === a.type || /loaded|complete/.test(c.readyState) && (!document.documentMode || 9 > document.documentMode)) c.onload = c.onreadystatechange = c.onerror = null, e(null, a)
                                        };
                                        c.onerror = function(a, l, b) {
                                            c.onload = c.onreadystatechange = c.onerror = null;
                                            e({
                                                msg: "script not loaded",
                                                event: a
                                            })
                                        };
                                        var l = document.head || document.getElementsByTagName("head")[0];
                                        l.insertBefore(c, l.lastChild)
                                    };
                                    b.cloneSimpleObject = function e(a, l) {
                                        if ("object" !== typeof a || null === a || a instanceof Date) return a;
                                        var m = new a.constructor,
                                            b;
                                        for (b in a) a.hasOwnProperty(b) && (void 0 === b || l && void 0 === a[b] || (m[b] = e(a[b])));
                                        return m
                                    };
                                    b.jsonSerialize = function(e) {
                                        try {
                                            return "undefined" !== typeof JSON && JSON.stringify ? JSON.stringify(e) : a(e)
                                        } catch (c) {
                                            return null
                                        }
                                    };
                                    b.jsonParse = function(a) {
                                        try {
                                            return "undefined" !== typeof JSON && JSON.parse ? JSON.parse(a + "") : g(a)
                                        } catch (c) {
                                            return null
                                        }
                                    };
                                    b.arrayIndexOf = function(a, c) {
                                        return Array.indexOf ? a.indexOf(c) : function(a) {
                                            if (null == this) throw new TypeError;
                                            var c = Object(this),
                                                e = c.length >>> 0;
                                            if (0 === e) return -1;
                                            var b = 0;
                                            1 < arguments.length && (b = Number(arguments[1]), b != b ? b = 0 : 0 != b && Infinity != b && -Infinity != b && (b = (0 < b || -1) * Math.floor(Math.abs(b))));
                                            if (b >= e) return -1;
                                            for (b = 0 <= b ? b : Math.max(e - Math.abs(b), 0); b < e; b++)
                                                if (b in c && c[b] === a) return b;
                                            return -1
                                        }.apply(a, [c])
                                    };
                                    b.uuid = function() {
                                        return {
                                            v4: function() {
                                                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
                                                    var c = 16 * Math.random() | 0;
                                                    return ("x" === a ? c : c & 3 | 8).toString(16)
                                                })
                                            },
                                            num: function(a) {
                                                var c = new Date,
                                                    b = function(a) {
                                                        a -= 100 * Math.floor(a / 100);
                                                        return 10 > a ? "0" + a : String(a)
                                                    };
                                                return b(c.getHours()) + "" + b(c.getMinutes()) + "" + b(c.getSeconds()) + "" +
                                                    function(a) {
                                                        return Math.floor((9 * Math.random() + 1) * Math.pow(10, a - 1))
                                                    }(a - 6)
                                            }
                                        }
                                    };
                                    b.getObjectKeys = function(a) {
                                        var c = [],
                                            b;
                                        for (b in a) a.hasOwnProperty(b) && c.push(b);
                                        return c
                                    };
                                    b.completeFstLevelObj = function(a, c, b) {
                                        if (a) {
                                            if (c)
                                                for (var m in c) !c.hasOwnProperty(m) || a[m] && !b || (a[m] = c[m])
                                        } else a = c;
                                        return a
                                    };
                                    b.isPreview = function() {
                                        return window.navigator && "preview" === window.navigator.loadPurpose
                                    };
                                    b.isPrerender = function(a) {
                                        var c, l = !1,
                                            m = ["webkit", "ms"];
                                        if ("prerender" === document.visibilityState) c = "visibilitychange";
                                        else
                                            for (var f = 0; f < m.length; f++) "prerender" === document[m[f] + "VisibilityState"] && (c = m[f] + "visibilitychange");
                                        if ("undefined" !== typeof c) {
                                            var r = function(l) {
                                                a(l);
                                                b.removeEvtListener(document, c, r)
                                            };
                                            b.addEvtListener(document, c, r);
                                            l = !0
                                        }
                                        return l
                                    };
                                    var h = b.addEvtListener = function(a, c, b) {
                                            a.addEventListener ? a.addEventListener(c, b, !1) : a.attachEvent && a.attachEvent("on" + c, b)
                                        },
                                        f = b.removeEvtListener = function(a, c, b) {
                                            a.removeEventListener ? a.removeEventListener(c, b, !1) : a.detachEvent && a.detachEvent("on" + c, b)
                                        };
                                    b.hashcode = function(a) {
                                        var c = 0;
                                        if (0 === a.length) return c;
                                        for (var b = 0; b < a.length; b++) var m = a.charCodeAt(b),
                                            c = (c << 5) - c + m,
                                            c = c | 0;
                                        return c
                                    };
                                    b.setLocation = function(a) {
                                        var c = a.location;
                                        a = window[a.target] || window;
                                        c && (a.location.href = c)
                                    };
                                    b.dispatchCallbackEvent = function(a) {
                                        var c;
                                        if ("function" === typeof window.Event) c = new Event("ATCallbackEvent");
                                        else try {
                                            c = document.createEvent("Event"), c.initEvent && c.initEvent("ATCallbackEvent", !0, !0)
                                        } catch (b) {}
                                        c && "function" === typeof document.dispatchEvent && (c.name = a, document.dispatchEvent(c))
                                    };
                                    b.addCallbackEvent = function(a) {
                                        h(document, "ATCallbackEvent", a)
                                    };
                                    (function() {
                                        function a(c, e) {
                                            e = e || {
                                                bubbles: !1,
                                                cancelable: !1,
                                                detail: void 0
                                            };
                                            var b;
                                            try {
                                                b = document.createEvent("CustomEvent"), b.initCustomEvent(c, e.bubbles, e.cancelable, e.detail)
                                            } catch (f) {}
                                            return b
                                        }
                                        if ("function" === typeof window.CustomEvent) return window.ATCustomEvent = window.CustomEvent, !1;
                                        "function" === typeof window.Event && (a.prototype = window.Event.prototype);
                                        window.ATCustomEvent = a
                                    })();
                                    b.addOptOutEvent = function(a, c) {
                                        b.ATOptOutEvent = new ATCustomEvent("ATOptOutEvent", {
                                            detail: {
                                                name: "clientsideuserid",
                                                id: c
                                            }
                                        });
                                        h(document, "ATOptOutEvent", a)
                                    };
                                    b.removeOptOutEvent = function(a) {
                                        f(document, "ATOptOutEvent", a)
                                    };
                                    b.dispatchOptOutEvent = function(a) {
                                        b.optedOut = a;
                                        b.ATOptOutEvent = b.ATOptOutEvent || new ATCustomEvent("ATOptOutEvent", {
                                            detail: {
                                                name: "clientsideuserid",
                                                id: -1
                                            }
                                        });
                                        try {
                                            document.dispatchEvent(b.ATOptOutEvent)
                                        } catch (c) {}
                                    };
                                    b.userOptedOut = function() {
                                        b.dispatchOptOutEvent(!0)
                                    };
                                    b.userOptedIn = function() {
                                        b.dispatchOptOutEvent(!1)
                                    };
                                    b.isOptedOut = function() {
                                        if (null === b.optedOut) {
                                            var a;
                                            a: {
                                                if (a = (a = /(?:^| )atoptedout=([^;]+)/.exec(document.cookie) || null) ? decodeURIComponent(a[1]) : null)
                                                    if (a = b.jsonParse(a) || b.jsonParse(b.Base64.decode(a))) {
                                                        a = !!a.val;
                                                        break a
                                                    }
                                                a = !1
                                            }
                                            b.optedOut = a
                                        }
                                        return !!b.optedOut
                                    };
                                    b.optedOut = null;
                                    b.ATOptOutEvent = null;
                                    b.isLocalStorageAvailable = function() {
                                        try {
                                            var a = localStorage;
                                            a.setItem("__storage_test__", "__storage_test__");
                                            a.removeItem("__storage_test__");
                                            return !0
                                        } catch (c) {
                                            return !1
                                        }
                                    }
                                };
                                window.ATInternet.Utils = new Utils;
                                var BuildManager = function(a) {
                                        var d = this,
                                            g = function(a, b, c) {
                                                a = "&" + a + "=";
                                                return {
                                                    param: a,
                                                    paramSize: a.length,
                                                    str: b,
                                                    strSize: b.length,
                                                    truncate: c
                                                }
                                            },
                                            b = function(b, e) {
                                                var c = "",
                                                    l = 0,
                                                    m = !0,
                                                    f;
                                                for (f in b)
                                                    if (b.hasOwnProperty(f)) {
                                                        var r = b[f];
                                                        if (r) {
                                                            var m = !1,
                                                                u = e - l;
                                                            if (r.strSize + r.paramSize < u) c += r.param + r.str, l += r.strSize + r.paramSize, b[f] = void 0, m = !0;
                                                            else {
                                                                r.truncate ? (c += r.param + r.str.substr(0, u), b[f].str = r.str.substr(u, r.strSize - 1), b[f].strSize = b[f].str.length) : r.strSize + r.paramSize > e && (a.emit("Tracker:Hit:Build:Error", {
                                                                    lvl: "ERROR",
                                                                    msg: 'Too long parameter "' + r.param + '"',
                                                                    details: {
                                                                        value: r.str
                                                                    }
                                                                }), b[f].str = b[f].str.substr(0, e - r.paramSize - 1), b[f].strSize = b[f].str.length);
                                                                break
                                                            }
                                                        } else m = !0
                                                    }
                                                return [c, m ? null : b]
                                            },
                                            k = ["ati", "atc", "pdtl", "stc", "dz"],
                                            p = function(f, e, c) {
                                                var l = function(a) {
                                                        if (a === {}) return "";
                                                        var c = [],
                                                            e;
                                                        e = {};
                                                        var m = 0,
                                                            l = !1,
                                                            f = void 0,
                                                            q, n, d;
                                                        for (d in a)
                                                            if (a.hasOwnProperty(d)) {
                                                                var h = a[d].value;
                                                                "function" === typeof h && (h = h());
                                                                h = h instanceof Array ? h.join(a[d].options.separator || ",") : "object" === typeof h ? window.ATInternet.Utils.jsonSerialize(h) : "undefined" === typeof h ? "undefined" : h.toString();
                                                                a[d].options.encode && (h = encodeURIComponent(h));
                                                                var p = g(d, h, -1 < window.ATInternet.Utils.arrayIndexOf(k, d)),
                                                                    m = m + (p.paramSize + p.strSize);
                                                                if (a[d].options.last) 1490 < h.length && h.substr(0, 1490), q = d, n = p;
                                                                else if (e[d] = p, 1500 < e[d].paramSize + e[d].strSize && !e[d].truncate) {
                                                                    l = !0;
                                                                    f = d;
                                                                    break
                                                                }
                                                            }
                                                        q && (e[q] = n);
                                                        e = [e, m, l, f];
                                                        a = e[0];
                                                        if (e[2]) e = e[3], a = a[e], a.str = a.str.substr(0, 1450), a.strSize = 1450, m = {}, m.mherr = g("mherr", "1", !1), m[e] = a, c.push(b(m, 1500)[0]);
                                                        else if (e = b(a, 1500), null === e[1]) c = e[0];
                                                        else
                                                            for (c.push(e[0]); null !== e[1];) e = b(a, 1500), c.push(e[0]);
                                                        return c
                                                    },
                                                    m = "";
                                                a.buffer.presentInFilters(e, "hitType") || (e = a.buffer.addInFilters(e, "hitType", ["page"]));
                                                e = a.buffer.addInFilters(e, "hitType", ["all"]);
                                                var q;
                                                if (f) {
                                                    e = a.buffer.addInFilters(e, "permanent", !0);
                                                    e = a.buffer.get(e, !0);
                                                    for (q in f) f.hasOwnProperty(q) && (e[q] = {
                                                        value: f[q],
                                                        options: {}
                                                    });
                                                    m = l(e)
                                                } else
                                                    for (q in e = a.buffer.get(e, !0), m = l(e), e) e.hasOwnProperty(q) && !e[q].options.permanent && a.buffer.del(q);
                                                c && c(m)
                                            },
                                            h = function(b) {
                                                var e = a.getConfig("secure"),
                                                    c = "https:" === document.location.protocol,
                                                    l = e || c,
                                                    c = "",
                                                    c = l ? a.getConfig("logSSL") : a.getConfig("log"),
                                                    m = a.getConfig("domain"),
                                                    c = c && m ? c + "." + m : l ? a.getConfig("collectDomainSSL") : a.getConfig("collectDomain"),
                                                    l = a.getConfig("baseURL");
                                                (m = (m = a.getConfig("pixelPath")) || "/") && "/" !== m.charAt(0) && (m = "/" + m);
                                                var f = a.getConfig("site");
                                                (l || c && m) && f ? b && b(null, (l ? l : (e ? "https://" : "//") + c + m) + ("?s=" + f)) : b && b({
                                                    message: "Config error"
                                                })
                                            },
                                            f = function(a, b, c) {
                                                h(function(f, m) {
                                                    f ? c && c(f) : p(a, b, function(a) {
                                                        var b = [],
                                                            e = ATInternet.Utils.uuid().num(13);
                                                        if (a instanceof Array)
                                                            if (1 === a.length) b.push(m + "&mh=1-2-" + e + a[0]);
                                                            else
                                                                for (var f = 1; f <= a.length; f++) b.push(m + "&mh=" + f + "-" + a.length + "-" + e + a[f - 1]);
                                                        else b.push(m + a);
                                                        c && c(null, b)
                                                    })
                                                })
                                            };
                                        d.send = function(b, e, c) {
                                            f(b, e, function(b, e) {
                                                if (b) a.emit("Tracker:Hit:Build:Error", {
                                                    lvl: "ERROR",
                                                    msg: b.message,
                                                    details: {
                                                        hits: e
                                                    }
                                                }), c && c();
                                                else
                                                    for (var f = 0; f < e.length; f++) d.sendUrl(e[f], c)
                                            })
                                        };
                                        d.sendUrl = function(b, e) {
                                            var c = function(c, b, f) {
                                                return function() {
                                                    return function(l) {
                                                        a.emit(c, {
                                                            lvl: f,
                                                            details: {
                                                                hit: b,
                                                                event: l
                                                            }
                                                        });
                                                        e && e()
                                                    }
                                                }()
                                            };
                                            if (ATInternet.Utils.isOptedOut() && !a.getConfig("sendHitWhenOptOut")) c("Tracker:Hit:Sent:NoTrack", b, "INFO")();
                                            else {
                                                var f = new Image;
                                                f.onload = c("Tracker:Hit:Sent:Ok", b, "INFO");
                                                f.onerror = c("Tracker:Hit:Sent:Error", b, "ERROR");
                                                f.src = b
                                            }
                                        }
                                    },
                                    TriggersManager = function() {
                                        function a(a, b, d) {
                                            for (var f = [], n = 0; n < a.length; n++) a[n].callback(b, d), a[n].singleUse || f.push(a[n]);
                                            return f
                                        }

                                        function d(a, b, h, f) {
                                            var n = a.shift();
                                            if ("*" === n) return b["*"] = b["*"] || [], b["*"].push({
                                                callback: h,
                                                singleUse: f
                                            }), b["*"].length - 1;
                                            if (0 === a.length) return d([n, "*"], b, h, f);
                                            b["*"] = b["*"] || [];
                                            b[n] = b[n] || {};
                                            return d(a, b[n], h, f)
                                        }

                                        function g(b, d, h, f) {
                                            var n = d.shift();
                                            "*" !== n && (0 === d.length ? g(b, [n, "*"], h, f) : h[n] && (h[n]["*"] = a(h[n]["*"], b, f), g(b, d, h[n], f)))
                                        }
                                        var b = {};
                                        this.on = function(a, p, h) {
                                            h = h || !1;
                                            return d(a.split(":"), b, p, h)
                                        };
                                        this.emit = function(k, d) {
                                            b["*"] && (b["*"] = a(b["*"], k, d));
                                            g(k, k.split(":"), b, d)
                                        }
                                    },
                                    PluginsManager = function(a) {
                                        var d = {},
                                            g = {},
                                            b = 0,
                                            k = {},
                                            p = 0,
                                            h = this.unload = function(c) {
                                                d[c] ? (d[c] = void 0, a.emit("Tracker:Plugin:Unload:" + c + ":Ok", {
                                                    lvl: "INFO"
                                                })) : a.emit("Tracker:Plugin:Unload:" +
                                                    c + ":Error", {
                                                        lvl: "ERROR",
                                                        msg: "not a known plugin"
                                                    });
                                                return a
                                            },
                                            f = this.load = function(c, e) {
                                                "function" === typeof e ? "undefined" === typeof a.getConfig.plgAllowed || 0 === a.getConfig.plgAllowed.length || -1 < a.getConfig.plgAllowed.indexOf(c) ? (d[c] = new e(a), g[c] && d[c] && (g[c] = !1, b--, d[c + "_ll"] && h(c + "_ll"), 0 === b && a.emit("Tracker:Plugin:Lazyload:File:Complete", {
                                                    lvl: "INFO",
                                                    msg: "LazyLoading triggers are finished"
                                                })), a.emit("Tracker:Plugin:Load:" + c + ":Ok", {
                                                    lvl: "INFO"
                                                })) : a.emit("Tracker:Plugin:Load:" + c + ":Error", {
                                                    lvl: "ERROR",
                                                    msg: "Plugin not allowed",
                                                    details: {}
                                                }) : a.emit("Tracker:Plugin:Load:" + c + ":Error", {
                                                    lvl: "ERROR",
                                                    msg: "not a function",
                                                    details: {
                                                        obj: e
                                                    }
                                                });
                                                return a
                                            },
                                            n = this.isLazyloading = function(a) {
                                                return a ? !0 === g[a] : 0 !== b
                                            },
                                            e = function(a) {
                                                return !d[a] && !n(a) && (d[a + "_ll"] ? !0 : !1)
                                            },
                                            c = function(c) {
                                                g[c] = !0;
                                                b++;
                                                ATInternet.Utils.loadScript({
                                                    url: a.getConfig("lazyLoadingPath") + c + ".js"
                                                })
                                            },
                                            l = function(a) {
                                                return e(a) ? (c(a), !0) : !1
                                            },
                                            m = function(a) {
                                                k[a] ? k[a]++ : k[a] = 1;
                                                p++
                                            };
                                        this.isExecWaitingLazyloading = function() {
                                            return 0 !== p
                                        };
                                        a.exec = this.exec = function(b, f, l, h) {
                                            var g = null,
                                                s = function(a, c, b, e) {
                                                    c = c.split(".");
                                                    d[a] && d[a][c[0]] && (g = 1 < c.length && d[a][c[0]][c[1]] ? d[a][c[0]][c[1]].apply(d[a], b) : d[a][c[0]].apply(d[a], b));
                                                    e && e(g)
                                                },
                                                w = function(c, b, e, f) {
                                                    m(c);
                                                    a.onTrigger("Tracker:Plugin:Load:" + c + ":Ok", function() {
                                                        s(c, b, e, function(b) {
                                                            k[c]--;
                                                            p--;
                                                            0 === p && a.emit("Tracker:Plugin:Lazyload:Exec:Complete", {
                                                                lvl: "INFO",
                                                                msg: "All exec waiting for lazyloading are done"
                                                            });
                                                            f && f(b)
                                                        })
                                                    }, !0)
                                                };
                                            e(b) ? (w(b, f, l, h), c(b)) : n(b) ? w(b, f, l, h) : s(b, f, l, h)
                                        };
                                        this.waitForDependencies = function(c, b) {
                                            var e = function(a) {
                                                for (var c = {
                                                        mcount: 0,
                                                        plugins: {}
                                                    }, b = 0; b < a.length; b++) d.hasOwnProperty(a[b]) || (c.mcount++, c.plugins[a[b]] = !0);
                                                return c
                                            }(c);
                                            if (0 === e.mcount) a.emit("Tracker:Plugin:Dependencies:Loaded", {
                                                lvl: "INFO",
                                                details: {
                                                    dependencies: c
                                                }
                                            }), b();
                                            else
                                                for (var f in e.plugins) e.plugins.hasOwnProperty(f) && (a.emit("Tracker:Plugin:Dependencies:Error", {
                                                    lvl: "WARNING",
                                                    msg: "Missing plugin " + f
                                                }), a.onTrigger("Tracker:Plugin:Load:" + f, function(a, c) {
                                                    var f = a.split(":"),
                                                        m = f[3];
                                                    "Ok" === f[4] && (e.plugins[m] = !1, e.mcount--, 0 === e.mcount && b())
                                                }, !0), l(f))
                                        };
                                        this.init = function() {
                                            for (var a in ATInternet.Tracker.pluginProtos) ATInternet.Tracker.pluginProtos.hasOwnProperty(a) && f(a, ATInternet.Tracker.pluginProtos[a])
                                        }
                                    },
                                    CallbacksManager = function(a) {
                                        var d = {},
                                            g = this.load = function(b, k) {
                                                "function" === typeof k ? (new k(a), a.emit("Tracker:Callback:Load:" + b + ":Ok", {
                                                    lvl: "INFO",
                                                    details: {
                                                        obj: k
                                                    }
                                                })) : a.emit("Tracker:Callback:Load:" + b + ":Error", {
                                                    lvl: "ERROR",
                                                    msg: "not a function",
                                                    details: {
                                                        obj: k
                                                    }
                                                });
                                                return a
                                            };
                                        this.init = function() {
                                            if (a.getConfig("activateCallbacks")) {
                                                var b = a.getConfig("callbacks");
                                                (function() {
                                                    if ("undefined" !== typeof b && b.include instanceof Array)
                                                        for (var a = 0; a < b.include.length; a++) ATInternet.Callbacks && ATInternet.Callbacks.hasOwnProperty(b.include[a]) && (d[b.include[a]] = {
                                                            "function": ATInternet.Callbacks[b.include[a]]
                                                        }, ATInternet.Tracker.callbackProtos[b.include[a]] || (ATInternet.Tracker.callbackProtos[b.include[a]] = d[b.include[a]]));
                                                    else
                                                        for (a in ATInternet.Callbacks) ATInternet.Callbacks.hasOwnProperty(a) && (d[a] = {
                                                            "function": ATInternet.Callbacks[a]
                                                        }, ATInternet.Tracker.callbackProtos[a] || (ATInternet.Tracker.callbackProtos[a] = d[a]));
                                                    if ("undefined" !== typeof b && b.exclude instanceof Array)
                                                        for (a = 0; a < b.exclude.length; a++) d[b.exclude[a]] && (d[b.exclude[a]] = void 0);
                                                    for (var p in d) d.hasOwnProperty(p) && d[p] && g(p, d[p]["function"])
                                                })();
                                                ATInternet.Utils.addCallbackEvent(function(a) {
                                                    if (a.name) {
                                                        var d = !0;
                                                        "undefined" !== typeof b && (b.include instanceof Array && -1 === ATInternet.Utils.arrayIndexOf(b.include, a.name) && (d = !1), b.exclude instanceof Array && -1 !== ATInternet.Utils.arrayIndexOf(b.exclude, a.name) && (d = !1));
                                                        if (ATInternet.Callbacks && ATInternet.Callbacks.hasOwnProperty(a.name)) {
                                                            var h = {};
                                                            h[a.name] = {
                                                                "function": ATInternet.Callbacks[a.name]
                                                            };
                                                            d && g(a.name, h[a.name]["function"]);
                                                            ATInternet.Tracker.callbackProtos[a.name] || (ATInternet.Tracker.callbackProtos[a.name] = h[a.name])
                                                        }
                                                    }
                                                })
                                            }
                                        }
                                    },
                                    BufferManager = function(a) {
                                        var d = {};
                                        this.set = function(a, b, h) {
                                            h = h || {};
                                            h.hitType = h.hitType || ["page"];
                                            d[a] = {
                                                value: b,
                                                options: h
                                            }
                                        };
                                        var g = function(a, b, d) {
                                                return (a = window.ATInternet.Utils.cloneSimpleObject(a[b])) && !d ? a.value : a
                                            },
                                            b = function p(a, b) {
                                                if (!(a && b instanceof Array && a instanceof Array)) return [];
                                                if (0 === a.length) return b;
                                                var n = a[0],
                                                    e, c = [],
                                                    l = window.ATInternet.Utils.cloneSimpleObject(a);
                                                l.shift();
                                                for (var m = 0; m < b.length; m++)
                                                    if ("object" !== typeof n[1]) d[b[m]] && d[b[m]].options[n[0]] === n[1] && c.push(b[m]);
                                                    else {
                                                        e = n[1].length;
                                                        for (var q = 0; q < e; q++)
                                                            if (d[b[m]] && d[b[m]].options[n[0]] instanceof Array && 0 <= window.ATInternet.Utils.arrayIndexOf(d[b[m]].options[n[0]], n[1][q])) {
                                                                c.push(b[m]);
                                                                break
                                                            }
                                                    }
                                                return p(l, c)
                                            };
                                        this.get = function(a, h) {
                                            var f = {};
                                            if ("string" === typeof a) f = g(d, a, h);
                                            else
                                                for (var n = b(a, window.ATInternet.Utils.getObjectKeys(d)), e = 0; e < n.length; e++) f[n[e]] = g(d, n[e], h);
                                            return f
                                        };
                                        this.presentInFilters = function h(a, b) {
                                            return a && 0 !== a.length ? a[0][0] === b ? !0 : h(a.slice(1), b) : !1
                                        };
                                        this.addInFilters = function f(a, b, c, l) {
                                            if (!a || 0 === a.length) return l ? [] : [
                                                [b, c]
                                            ];
                                            var m = a[0][0],
                                                d = a[0][1];
                                            m === b && (d instanceof Array && !(-1 < window.ATInternet.Utils.arrayIndexOf(d, c[0])) && d.push(c[0]), l = !0);
                                            return [
                                                [m, d]
                                            ].concat(f(a.slice(1), b, c, l))
                                        };
                                        this.del = function(a) {
                                            d[a] = void 0
                                        };
                                        this.clear = function() {
                                            d = {}
                                        }
                                    },
                                    Tag = function(a, d, g) {
                                        d = d || {};
                                        var b = this;
                                        b.version = "5.14.0";
                                        var k = window.ATInternet.Utils.cloneSimpleObject(d);
                                        b.triggers = new TriggersManager(b);
                                        b.emit = b.triggers.emit;
                                        b.onTrigger = b.triggers.on;
                                        var p = window.ATInternet.Utils.cloneSimpleObject(dfltGlobalCfg) || {},
                                            h;
                                        for (h in a) a.hasOwnProperty(h) && (p[h] = a[h]);
                                        b.getConfig = function(a) {
                                            return p[a]
                                        };
                                        b.setConfig = function(a, d, e) {
                                            void 0 !== p[a] && e || (b.emit("Tracker:Config:Set:" + a, {
                                                lvl: "INFO",
                                                details: {
                                                    bef: p[a],
                                                    aft: d
                                                }
                                            }), p[a] = d)
                                        };
                                        b.configPlugin = function(a, d, e) {
                                            p[a] = p[a] || {};
                                            for (var c in d) d.hasOwnProperty(c) && void 0 === p[a][c] && (p[a][c] = d[c]);
                                            e && (e(p[a]), b.onTrigger("Tracker:Config:Set:" + a, function(a, c) {
                                                e(c.details.aft)
                                            }));
                                            return p[a]
                                        };
                                        b.getContext = function(a) {
                                            return k[a]
                                        };
                                        b.setContext = function(a, d) {
                                            b.emit("Tracker:Context:Set:" + a, {
                                                lvl: "INFO",
                                                details: {
                                                    bef: k[a],
                                                    aft: d
                                                }
                                            });
                                            k[a] = d
                                        };
                                        b.delContext = function(a, d) {
                                            b.emit("Tracker:Context:Deleted:" + a + ":" + d, {
                                                lvl: "INFO",
                                                details: {
                                                    key1: a,
                                                    key2: d
                                                }
                                            });
                                            if (a) k.hasOwnProperty(a) && (d ? k[a] && k[a].hasOwnProperty(d) && (k[a][d] = void 0) : k[a] = void 0);
                                            else if (d)
                                                for (var e in k) k.hasOwnProperty(e) && k[e] && k[e].hasOwnProperty(d) && (k[e][d] = void 0)
                                        };
                                        b.plugins = new PluginsManager(b);
                                        b.buffer = new BufferManager(b);
                                        b.setParam = b.buffer.set;
                                        b.getParams = function(a) {
                                            return b.buffer.get(a, !1)
                                        };
                                        b.getParam = b.buffer.get;
                                        b.delParam = b.buffer.del;
                                        b.builder = new BuildManager(b);
                                        b.sendHit = b.builder.send;
                                        b.sendUrl = b.builder.sendUrl;
                                        b.callbacks = new CallbacksManager(b);
                                        b.setParam("ts", function() {
                                            return (new Date).getTime()
                                        }, {
                                            permanent: !0,
                                            hitType: ["all"]
                                        });
                                        b.getConfig("disableCookie") && b.setParam("idclient", "Consent-NO", {
                                            permanent: !0,
                                            hitType: ["all"]
                                        });
                                        b.getConfig("medium") && b.setParam("medium", b.getConfig("medium"), {
                                            permanent: !0,
                                            hitType: ["all"]
                                        });
                                        b.plugins.init();
                                        b.callbacks.init();
                                        ATInternet.Tracker.instances.push(b);
                                        b.emit("Tracker:Ready", {
                                            lvl: "INFO",
                                            msg: "Tracker initialized",
                                            details: {
                                                tracker: b,
                                                args: {
                                                    config: a,
                                                    context: d,
                                                    callback: g
                                                }
                                            }
                                        });
                                        g && g(b)
                                    };
                                ATInternet.Tracker.Tag = Tag;
                                ATInternet.Tracker.instances = [];
                                ATInternet.Tracker.pluginProtos = {};
                                ATInternet.Tracker.addPlugin = function(a, d) {
                                    d = d || ATInternet.Tracker.Plugins[a];
                                    if (!ATInternet.Tracker.pluginProtos[a]) {
                                        ATInternet.Tracker.pluginProtos[a] = d;
                                        for (var g = 0; g < ATInternet.Tracker.instances.length; g++) ATInternet.Tracker.instances[g].plugins.load(a, d)
                                    }
                                };
                                ATInternet.Tracker.delPlugin = function(a) {
                                    if (ATInternet.Tracker.pluginProtos[a]) {
                                        ATInternet.Tracker.pluginProtos[a] = void 0;
                                        for (var d = 0; d < ATInternet.Tracker.instances.length; d++) ATInternet.Tracker.instances[d].plugins.unload(a)
                                    }
                                };
                                ATInternet.Tracker.callbackProtos = {};
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "lifetime": 30,
                                    "lastPersistence": true,
                                    "listEventsForExec": [],
                                    "domainAttribution": true,
                                    "info": true
                                };
                                var dfltGlobalCfg = {
                                    "visitLifetime": 30,
                                    "redirectionLifetime": 30
                                };
                                window.ATInternet.Tracker.Plugins.Campaigns = function(a) {
                                    a.setConfig("visitLifetime", dfltGlobalCfg.visitLifetime, !0);
                                    a.setConfig("redirectionLifetime", dfltGlobalCfg.redirectionLifetime, !0);
                                    var d = {},
                                        g, b;
                                    a.configPlugin("Campaigns", dfltPluginCfg || {}, function(a) {
                                        d = a
                                    });
                                    var k, p, h, f, n, e, c, l, m, q, r, u, z, v = function(c, b, e) {
                                            var m = null;
                                            a.plugins.exec(c, b, e, function(a) {
                                                m = a
                                            });
                                            return m
                                        },
                                        s = function(a, c) {
                                            return v("Cookies", a, c)
                                        },
                                        w = function(a, c) {
                                            return v("Utils", a, c)
                                        },
                                        y = function(a, c) {
                                            var e = s(b, [a]);
                                            if (null !== e) return "object" === typeof e && !(e instanceof Array);
                                            s(g, [a, {}, c]);
                                            return !0
                                        },
                                        B = function(c, b) {
                                            var e = a.getContext("campaigns") || {};
                                            e[c] = b;
                                            a.setContext("campaigns", e)
                                        },
                                        A = function(v) {
                                            g = "set" + (d.domainAttribution ? "" : "Private");
                                            b = "get" + (d.domainAttribution ? "" : "Private");
                                            k = s(b, [
                                                ["atredir", "gopc"]
                                            ]);
                                            p = s(b, [
                                                ["atredir", "gopc_err"]
                                            ]);
                                            h = s(b, [
                                                ["atredir", "camp"]
                                            ]);
                                            s("del", [
                                                ["atredir", "gopc"]
                                            ]);
                                            s("del", [
                                                ["atredir", "gopc_err"]
                                            ]);
                                            s("del", [
                                                ["atredir", "camp"]
                                            ]);
                                            f = s(b, [
                                                ["atsession", "histo_camp"]
                                            ]);
                                            n = s(b, [
                                                ["atreman", "camp"]
                                            ]);
                                            e = s(b, [
                                                ["atreman", "date"]
                                            ]);
                                            var t = w("getLocation", []);
                                            c = w("getQueryStringValue", ["xtor", t]);
                                            l = w("getQueryStringValue", ["xtdt", t]);
                                            m = w("getQueryStringValue", ["xts", t]);
                                            q = a.getContext("forcedCampaign");
                                            r = !!a.getConfig("redirect");
                                            if (u = c && l && m ? !0 : !1) t = (new Date).getTime() / 6E4, z = !r && m !== a.getConfig("site") || 0 > t - l || t - l >= a.getConfig("visitLifetime") ? !0 : !1;
                                            t = q || h || c;
                                            if (r && t && y("atredir", {
                                                    path: "/",
                                                    end: a.getConfig("redirectionLifetime")
                                                })) {
                                                s(g, [
                                                    ["atredir", "camp"], t
                                                ]);
                                                var A = t = !1;
                                                q || (h ? (t = k, A = p) : (u && (t = !0), z && (A = !0)));
                                                s(g, [
                                                    ["atredir", "gopc"], t
                                                ]);
                                                s(g, [
                                                    ["atredir", "gopc_err"], A
                                                ])
                                            }!r && n && (B("xtor", n), t = (new Date).getTime() / 36E5, t = Math.floor(t - e), B("roinbh", 0 <= t ? t : 0));
                                            r || (t = void 0, t = h ? k ? q || t : q || h : u ? q || t : q || c || t, f && f instanceof Array && -1 < f.indexOf(t) && (t = void 0), t && B("xto", t));
                                            if (!r && !q) {
                                                var x;
                                                h ? p && (x = h) : z && (x = c);
                                                x && B("pgt", x)
                                            }
                                            r || !(x = h ? q || h : q || c || void 0) || !q && !h && u && z || !q && h && k && p || ((!f || f instanceof Array && 0 > f.indexOf(x)) && y("atsession", {
                                                path: "/",
                                                session: 60 * a.getConfig("visitLifetime")
                                            }) && s(g, [
                                                ["atsession", "histo_camp"], f && f.push(x) ? f : [x]
                                            ]), n && !d.lastPersistence || !y("atreman", {
                                                path: "/",
                                                session: 86400 * d.lifetime
                                            }) || (s(g, [
                                                ["atreman", "camp"], x
                                            ]), s(g, [
                                                ["atreman", "date"], (new Date).getTime() / 36E5
                                            ])));
                                            a.emit("Campaigns:" + v, {
                                                lvl: "INFO"
                                            })
                                        };
                                    (function() {
                                        var c = ["Cookies", "Utils"];
                                        if (-1 === ATInternet.Utils.arrayIndexOf(a.getConfig("plgs"), "BackwardCompat")) a.plugins.waitForDependencies(c, function() {
                                            A("process2:done")
                                        });
                                        else a.onTrigger("BackCampaigns:process2:done", function(b, e) {
                                            a.plugins.waitForDependencies(c, function() {
                                                A("process1:done")
                                            })
                                        }, !0)
                                    })()
                                };
                                window.ATInternet.Tracker.addPlugin("Campaigns");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "info": true
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.Clicks = function(a) {
                                    var d = function(a) {
                                            var b = "";
                                            switch (a) {
                                                case "exit":
                                                    b = "S";
                                                    break;
                                                case "download":
                                                    b = "T";
                                                    break;
                                                case "action":
                                                    b = "A";
                                                    break;
                                                case "navigation":
                                                    b = "N"
                                            }
                                            return b
                                        },
                                        g = function(b) {
                                            var d = b.name;
                                            a.exec("Utils", "manageChapters", [b, "chapter", 3], function(a) {
                                                d = a + (d ? d : "")
                                            });
                                            return d
                                        },
                                        b = function(b) {
                                            var p = {
                                                    p: g(b),
                                                    s2: b.level2 || "",
                                                    click: d(b.type) || ""
                                                },
                                                h = a.getContext("page") || {};
                                            p.pclick = g(h);
                                            p.s2click = h.level2 || "";
                                            b.customObject && a.exec("Utils", "customObjectToString", [b.customObject], function(a) {
                                                p.stc = a
                                            });
                                            a.sendHit(p, [
                                                ["hitType", ["click"]]
                                            ], b.callback)
                                        };
                                    a.click = {};
                                    a.clickListener = this.clickListener = {};
                                    a.click.send = this.send = function(d) {
                                        var g = !0;
                                        a.plugins.exec("TechClicks", "manageClick", [d.elem, d.event], function(a) {
                                            g = a
                                        });
                                        b(d);
                                        return g
                                    };
                                    a.clickListener.send = this.clickListener.send = function(d) {
                                        if (d.elem) {
                                            var g;
                                            a.plugins.exec("TechClicks", "isFormSubmit", [d.elem], function(a) {
                                                g = a ? "submit" : "click"
                                            });
                                            ATInternet.Utils.addEvtListener(d.elem, g, function(h) {
                                                a.plugins.exec("TechClicks", "manageClick", [d.elem, h]);
                                                b(d)
                                            })
                                        }
                                    };
                                    a.click.set = this.set = function(b) {
                                        a.dispatchSubscribe("click");
                                        a.setContext("click", {
                                            name: g(b),
                                            level2: b.level2 || "",
                                            customObject: b.customObject
                                        });
                                        a.setParam("click", d(b.type) || "", {
                                            hitType: ["click"]
                                        })
                                    };
                                    a.click.onDispatch = this.onDispatch = function(b) {
                                        var d = {
                                            hitType: ["click"]
                                        };
                                        a.setParam("p", a.getContext("click").name, d);
                                        a.setParam("s2", a.getContext("click").level2, d);
                                        var h = a.getContext("click").customObject;
                                        h && a.setParam("stc", h, {
                                            hitType: ["click"],
                                            encode: !0
                                        });
                                        h = a.getContext("page") || {};
                                        a.setParam("pclick", g(h), d);
                                        a.setParam("s2click", h.level2 || "", d);
                                        a.sendHit(null, [
                                            ["hitType", ["click"]]
                                        ], b);
                                        a.setContext("click", void 0)
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("Clicks");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "clientSideMode": "required",
                                    "userIdCookieDuration": 397,
                                    "userIdExpirationMode": "fixed",
                                    "optOut": "OPT-OUT",
                                    "userIdCookieName": "atuserid",
                                    "optOutCookieName": "atoptedout",
                                    "info": true
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.ClientSideUserId = function(a) {
                                    var d = {},
                                        g = void 0,
                                        b = null,
                                        k = -1,
                                        p = !1;
                                    a.configPlugin("ClientSideUserId", dfltPluginCfg || {}, function(a) {
                                        d = a
                                    });
                                    var h = function() {
                                            g = a.getContext("userIdentifier");
                                            a.exec("Cookies", "get", ["atuserid"], function(a) {
                                                b = a
                                            })
                                        },
                                        f = function(c, e, l) {
                                            if ("relative" === d.userIdExpirationMode || "fixed" === d.userIdExpirationMode && null === b || l) {
                                                var f = new Date;
                                                f.setTime(f.getTime() + 864E5 * d.userIdCookieDuration);
                                                a.exec("Cookies", "set", [c, e, {
                                                    end: f,
                                                    path: "/"
                                                }]);
                                                a.exec("Cookies", "get", [c, !0], function(c) {
                                                    l || e === c || a.setParam("idclient", e + "-NO", {
                                                        permanent: !0,
                                                        hitType: ["all"]
                                                    })
                                                })
                                            }
                                        },
                                        n = function(c, b, e) {
                                            a.setParam("idclient", c, {
                                                permanent: !0,
                                                hitType: ["all"]
                                            });
                                            f(e, c, b)
                                        },
                                        e = function() {
                                            var c = !1,
                                                b = null,
                                                e = ATInternet.Utils.optedOut;
                                            !1 === e && (a.exec("Cookies", "del", ["atoptedout"]), a.getParam("idclient") === d.optOut && a.delParam("idclient"));
                                            a.exec("Cookies", "get", ["atoptedout", !0], function(a) {
                                                b = a
                                            });
                                            if (!0 === e || b === d.optOut) c = !0;
                                            c && (ATInternet.Utils.optedOut = !0);
                                            return c
                                        },
                                        c = function() {
                                            h();
                                            var c, l = !1;
                                            if ("required" === d.clientSideMode) {
                                                if (c = navigator.userAgent, /Safari/.test(c) && !/Chrome/.test(c) || /iPhone|iPod|iPad/.test(c)) l = !0
                                            } else "always" === d.clientSideMode && (l = !0);
                                            c = l;
                                            l = "undefined" !== typeof g;
                                            p = e();
                                            if (c || l || p) {
                                                var f = "";
                                                c = !1;
                                                var u = d.userIdCookieName;
                                                p ? (f = d.optOut, c = !0, u = d.optOutCookieName) : a.getConfig("disableCookie") ? (f = a.getParam("idclient"), c = !0) : l ? (f = g, c = !0) : f = null !== b ? b : ATInternet.Utils.uuid().v4();
                                                n(f, c, u)
                                            }
                                            a.emit("ClientSideUserId:Ready", {
                                                lvl: "INFO",
                                                details: {
                                                    clientSideMode: d.clientSideMode,
                                                    userIdCookieDuration: d.userIdCookieDuration,
                                                    userIdExpirationMode: d.userIdExpirationMode,
                                                    userIdFromContext: g,
                                                    userIdFromCookie: b,
                                                    userId: f
                                                }
                                            })
                                        },
                                        l = function(a) {
                                            a && (a = a.detail) && "clientsideuserid" === a.name && a.id === k && c()
                                        };
                                    (function() {
                                        a.plugins.waitForDependencies(["Cookies"], function() {
                                            var a = ATInternet.Utils.uuid();
                                            k = parseInt(a.num(8));
                                            ATInternet.Utils.removeOptOutEvent(l);
                                            ATInternet.Utils.addOptOutEvent(l, k);
                                            c()
                                        })
                                    })();
                                    a.clientSideUserId = {};
                                    a.clientSideUserId.set = function(a) {
                                        var c = d.userIdCookieName;
                                        p && (a = d.optOut, c = d.optOutCookieName);
                                        n(a, !0, c)
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("ClientSideUserId");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "domainAttribution": true,
                                    "info": true
                                };
                                var dfltGlobalCfg = {
                                    "redirectionLifetime": 30
                                };
                                window.ATInternet.Tracker.Plugins.ContextVariables = function(a) {
                                    var d = "",
                                        g = null,
                                        b, k = "",
                                        p = "",
                                        h = {};
                                    a.configPlugin("ContextVariables", dfltPluginCfg || {}, function(a) {
                                        h = a
                                    });
                                    a.setConfig("redirectionLifetime", dfltGlobalCfg.redirectionLifetime, !0);
                                    var f = function(c, b, e) {
                                            var f = null;
                                            a.plugins.exec(c, b, e, function(a) {
                                                f = a
                                            });
                                            return f
                                        },
                                        n = function(a, c) {
                                            return f("Utils", a, c)
                                        },
                                        e = function(c, b) {
                                            var e = null;
                                            a.plugins.exec("Cookies", c, b, function(a) {
                                                e = a
                                            });
                                            return e
                                        },
                                        c = function() {
                                            a.setParam("hl", function() {
                                                var a = new Date;
                                                return a.getHours() +
                                                    "x" + a.getMinutes() + "x" + a.getSeconds()
                                            }, {
                                                permanent: !0,
                                                hitType: ["all"]
                                            })
                                        };
                                    a.plugins.waitForDependencies(["Cookies", "Utils"], function() {
                                        k = "set" + (h.domainAttribution ? "" : "Private");
                                        p = "get" + (h.domainAttribution ? "" : "Private");
                                        var f = n("getLocation", []);
                                        d = n("getQueryStringValue", ["xtref", f]);
                                        void 0 === d && (d = "");
                                        b = a.getContext("forcedReferer");
                                        if (a.getConfig("redirect")) {
                                            var f = n("getDocumentLevel", []),
                                                f = b ? b : null !== d ? d : f.referrer || "acc_dir",
                                                m;
                                            if (m = f) {
                                                m = {
                                                    path: "/",
                                                    end: a.getConfig("redirectionLifetime")
                                                };
                                                var q = e(p, ["atredir"]);
                                                null !== q ? m = "object" === typeof q && !(q instanceof Array) : (e(k, ["atredir", {}, m]), m = !0)
                                            }
                                            m && e(k, [
                                                ["atredir", "ref"], f
                                            ])
                                        } else {
                                            g = e(p, [
                                                ["atredir", "ref"]
                                            ]);
                                            e("del", [
                                                ["atredir", "ref"]
                                            ]);
                                            a.setParam("vtag", a.version, {
                                                permanent: !0,
                                                hitType: ["all"]
                                            });
                                            a.setParam("ptag", "js", {
                                                permanent: !0,
                                                hitType: ["all"]
                                            });
                                            f = "";
                                            try {
                                                f += window.screen.width + "x" + window.screen.height + "x" + window.screen.pixelDepth + "x" + window.screen.colorDepth
                                            } catch (r) {}
                                            a.setParam("r", f, {
                                                permanent: !0,
                                                hitType: ["all"]
                                            });
                                            f = "";
                                            window.innerWidth ? f += window.innerWidth + "x" + window.innerHeight : document.body && document.body.offsetWidth && (f += document.body.offsetWidth + "x" + document.body.offsetHeight);
                                            a.setParam("re", f, {
                                                permanent: !0,
                                                hitType: ["all"]
                                            });
                                            c();
                                            a.setParam("lng", navigator.language || navigator.userLanguage, {
                                                permanent: !0,
                                                hitType: ["all"]
                                            });
                                            f = ATInternet.Utils.uuid().num(13);
                                            a.setParam("idp", f, {
                                                permanent: !0,
                                                hitType: ["page", "clickzone"]
                                            });
                                            a.setParam("jv", navigator.javaEnabled() ? "1" : "0", {
                                                hitType: ["page"]
                                            });
                                            f = n("getDocumentLevel", []);
                                            a.setParam("ref", (b ? b : "acc_dir" === d ? "" : null !== d ? d : "acc_dir" === g ? "" : g ? g : f.referrer).replace(/[<>]/g, "").substring(0, 1600).replace(/&/g, "$"), {
                                                permanent: !0,
                                                last: !0,
                                                hitType: ["page"]
                                            })
                                        }
                                        a.emit("ContextVariables:Ready", {
                                            lvl: "INFO"
                                        })
                                    })
                                };
                                window.ATInternet.Tracker.addPlugin("ContextVariables");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "storageMode": "cookie",
                                    "info": false
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.Cookies = function(a) {
                                    var d = {},
                                        g = !1;
                                    a.configPlugin("Cookies", dfltPluginCfg || {}, function(a) {
                                        d = a;
                                        "localStorage" === d.storageMode && (g = ATInternet.Utils.isLocalStorageAvailable())
                                    });
                                    var b = {},
                                        k = function(c) {
                                            return a.getConfig("base64Storage") ? ATInternet.Utils.Base64.encode(c) : encodeURIComponent(c)
                                        },
                                        p = this.getCookie = function(c) {
                                            if (!a.getConfig("disableCookie") && c && "string" === typeof c) {
                                                var b = null;
                                                g ? b = localStorage.getItem(c) : (c = RegExp("(?:^| )" + c + "=([^;]+)").exec(document.cookie) || null) && (b = c[1]);
                                                if (b) return b = a.getConfig("base64Storage") ? ATInternet.Utils.Base64.decode(b) : decodeURIComponent(b), b
                                            }
                                            return null
                                        },
                                        h = this.setCookie = function(c, b, e) {
                                            if (!a.getConfig("disableCookie") && c && "string" === typeof c && "string" === typeof b)
                                                if (g) try {
                                                    return localStorage.setItem(c, k(b)), !0
                                                } catch (f) {
                                                    return null
                                                } else {
                                                    var d = a.getConfig("cookieDomain");
                                                    c = c + "=" + k(b);
                                                    b = !1;
                                                    if (e) {
                                                        b = e.secure;
                                                        var l = e.end,
                                                            m = e.domain;
                                                        e = e.path;
                                                        "undefined" !== typeof l && ("function" === typeof l.toGMTString ? c += ";expires=" + l.toGMTString() : "number" === typeof l && (c += ";max-age=" + l.toString()));
                                                        m ? c += ";domain=" + m : d && (c += ";domain=" + d);
                                                        e && "string" === typeof e && (c += ";path=" + e)
                                                    }
                                                    d = a.getConfig("cookieSecure") || b;
                                                    document.cookie = c + (d && "boolean" === typeof d ? ";secure" : "");
                                                    return !0
                                                } else return null
                                        },
                                        f = function(a) {
                                            var c = null;
                                            (a = p(a)) && (c = ATInternet.Utils.jsonParse(a));
                                            return c
                                        },
                                        n = function(a) {
                                            return h(a.name, ATInternet.Utils.jsonSerialize(a), a.options) ? a : null
                                        },
                                        e = function(a, c, e) {
                                            var d = null;
                                            if (!e && b[a]) d = b[a];
                                            else if (d = f(a)) d.options.session && n(d), b[a] = d;
                                            return d ? c ? (a = null, !d || "object" !== typeof d.val || d.val instanceof Array || void 0 === d.val[c] || (a = d.val[c]), a) : d.val : null
                                        },
                                        c = function(a, c, e, d) {
                                            var l = null;
                                            if (c) {
                                                if (l = f(a)) d = l, !d || "object" !== typeof d.val || d.val instanceof Array ? l = null : (d.val[c] = e, l = d), l && (l = n(l))
                                            } else c = d = d || {}, d = {}, d.name = a, d.val = e, c.session && "number" === typeof c.session && (c.end = c.session), d.options = c, l = n(d);
                                            l && (b[a] = l);
                                            return l ? l.val : null
                                        },
                                        l = function(a, e) {
                                            e ? c(a, e, void 0) : (b[a] = void 0, g ? localStorage.removeItem(a) : h(a, "", {
                                                end: new Date("Thu, 01 Jan 1970 00:00:00 UTC"),
                                                path: "/"
                                            }))
                                        };
                                    a.cookies = {};
                                    var m = a.cookies.get = this.get = function(a, c) {
                                        c = c || !1;
                                        return a instanceof Array && 2 === a.length ? e(a[0], a[1], c) : e(a, void 0, c)
                                    };
                                    a.cookies.getPrivate = this.getPrivate = function(c, b) {
                                        b = b || !1;
                                        c instanceof Array ? c[0] += a.getConfig("site") : c += a.getConfig("site");
                                        return m(c, b)
                                    };
                                    var q = a.cookies.set = this.set = function(a, b, e) {
                                        return a instanceof Array ? c(a[0], a[1], b) : c(a, null, b, e)
                                    };
                                    a.cookies.setPrivate = this.setPrivate = function(c, b, e) {
                                        c instanceof Array ? c[0] += a.getConfig("site") : c += a.getConfig("site");
                                        return q(c, b, e)
                                    };
                                    var r = a.cookies.del = this.del = function(a) {
                                        return a instanceof Array ? l(a[0], a[1]) : l(a)
                                    };
                                    a.cookies.delPrivate = this.delPrivate = function(c) {
                                        c instanceof Array ? c[0] += a.getConfig("site") : c += a.getConfig("site");
                                        return r(c)
                                    };
                                    a.cookies.cacheInvalidation = this.cacheInvalidation = function() {
                                        b = {}
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("Cookies");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "lifetime": 182,
                                    "domainAttribution": true,
                                    "info": true
                                };
                                var dfltGlobalCfg = {
                                    "redirectionLifetime": 30
                                };
                                window.ATInternet.Tracker.Plugins.IdentifiedVisitor = function(a) {
                                    var d = null,
                                        g = null,
                                        b = null,
                                        k = null,
                                        p = "",
                                        h = "",
                                        f = null,
                                        n = null,
                                        e = "",
                                        c = "",
                                        l = {};
                                    a.configPlugin("IdentifiedVisitor", dfltPluginCfg || {}, function(a) {
                                        l = a
                                    });
                                    a.setConfig("redirectionLifetime", dfltGlobalCfg.redirectionLifetime, !0);
                                    var m = function(c, b, e) {
                                            var f = null;
                                            a.plugins.exec(c, b, e, function(a) {
                                                f = a
                                            });
                                            return f
                                        },
                                        q = function(a, c) {
                                            return m("Utils", a, c)
                                        },
                                        r = function(c, b) {
                                            var e = null;
                                            a.plugins.exec("Cookies", c, b, function(a) {
                                                e = a
                                            });
                                            return e
                                        },
                                        u = function(a, b) {
                                            var f = r(c, [a]);
                                            if (null !== f) return "object" === typeof f && !(f instanceof Array);
                                            r(e, [a, {}, b]);
                                            return !0
                                        },
                                        z = function(a, c) {
                                            u("atidvisitor", {
                                                path: "/",
                                                session: 86400 * l.lifetime
                                            }) && r(e, [
                                                ["atidvisitor", a], c
                                            ])
                                        },
                                        v = function(c, b) {
                                            a.setParam(c, b, {
                                                hitType: ["all"],
                                                permanent: !0
                                            });
                                            z(c, b)
                                        },
                                        s = function() {
                                            var c = function(a, c) {
                                                    /-/.test(c) ? (a.category = c.split("-")[0], a.id = c.split("-")[1]) : a.id = c
                                                },
                                                e = {
                                                    category: "",
                                                    id: ""
                                                };
                                            c(e, h || n);
                                            var l = {
                                                category: "",
                                                id: ""
                                            };
                                            c(l, p || f);
                                            l.id ? (l.category && v("ac", l.category), v("at", l.id)) : d && (a.setParam("at", d, {
                                                hitType: ["all"],
                                                permanent: !0
                                            }), b && a.setParam("ac", b, {
                                                hitType: ["all"],
                                                permanent: !0
                                            }));
                                            e.id ? (e.category && v("ac", e.category), v("an", e.id)) : g && a.setParam("anc", b + "-" + g, {
                                                hitType: ["all"],
                                                permanent: !0
                                            })
                                        };
                                    a.plugins.waitForDependencies(["Cookies", "Utils"], function() {
                                        e = "set" + (l.domainAttribution ? "" : "Private");
                                        c = "get" + (l.domainAttribution ? "" : "Private");
                                        var m = q("getLocation", []);
                                        p = q("getQueryStringValue", ["xtat", m]);
                                        h = q("getQueryStringValue", ["xtan", m]);
                                        a.getConfig("redirect") ? (p || h) && u("atredir", {
                                            path: "/",
                                            end: a.getConfig("redirectionLifetime")
                                        }) && (h && r(e, [
                                            ["atredir", "an"], h
                                        ]), p && r(e, [
                                            ["atredir", "at"], p
                                        ])) : (f = r(c, [
                                            ["atredir", "at"]
                                        ]), n = r(c, [
                                            ["atredir", "an"]
                                        ]), r("del", [
                                            ["atredir", "at"]
                                        ]), r("del", [
                                            ["atredir", "an"]
                                        ]), d = r(c, [
                                            ["atidvisitor", "at"]
                                        ]), g = r(c, [
                                            ["atidvisitor", "an"]
                                        ]), b = r(c, [
                                            ["atidvisitor", "ac"]
                                        ]), k = r(c, [
                                            ["atidvisitor", "vrn"]
                                        ]), s(), m = "-" + a.getConfig("site") + "-", RegExp(m).test(k) || (k = (k || "") + m, z("vrn", k), m = a.getContext("page") || {}, m.vrn = 1, a.setContext("page", m)));
                                        a.emit("IdentifiedVisitor:Ready", {
                                            lvl: "INFO",
                                            details: {
                                                cookieRedirectTextual: f,
                                                cookieRedirectNumeric: n,
                                                cookieTextual: d,
                                                cookieNumeric: g,
                                                cookieCategory: b,
                                                cookieVrn: k
                                            }
                                        })
                                    });
                                    a.identifiedVisitor = {};
                                    a.identifiedVisitor.set = this.set = function(a) {
                                        var c = a.id;
                                        a = a.category;
                                        "number" === typeof c ? v("an", c.toString()) : v("at", c);
                                        "undefined" !== typeof a && v("ac", a)
                                    };
                                    a.identifiedVisitor.unset = this.unset = function() {
                                        for (var c = ["an", "at", "ac"], b = 0; b < c.length; b++) a.exec("Cookies", "del", [
                                            ["atidvisitor", c[b]]
                                        ]), a.delParam(c[b]);
                                        a.delParam("anc")
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("IdentifiedVisitor");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "urlKeyword": "",
                                    "urlResultPageNumber": "",
                                    "urlResultPosition": "",
                                    "info": true
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.InternalSearch = function(a) {
                                    var d = {};
                                    a.configPlugin("InternalSearch", dfltPluginCfg || {}, function(a) {
                                        d = a
                                    });
                                    var g = function(b) {
                                        var d = {
                                            np: "undefined" !== typeof b.resultPageNumber ? b.resultPageNumber : "1",
                                            click: "IS"
                                        };
                                        b.hasOwnProperty("keyword") && (d.mc = b.keyword);
                                        b.hasOwnProperty("resultPosition") && (d.mcrg = b.resultPosition);
                                        a.sendHit(d, [
                                            ["hitType", ["InternalSearch"]]
                                        ], b.callback)
                                    };
                                    a.internalSearch = {};
                                    a.internalSearch.set = this.set = function(b) {
                                        var d = {},
                                            g = d;
                                        b.hasOwnProperty("keyword") && (g.keyword = b.keyword);
                                        g = d;
                                        b.hasOwnProperty("resultPageNumber") && (g.resultPageNumber = b.resultPageNumber);
                                        b = a.getContext("InternalSearch") || {};
                                        d = ATInternet.Utils.completeFstLevelObj(d, b);
                                        "undefined" === typeof d.resultPageNumber && (d.resultPageNumber = "1");
                                        a.setContext("InternalSearch", d)
                                    };
                                    a.internalSearch.send = this.send = function(b) {
                                        var d = !0;
                                        a.plugins.exec("TechClicks", "manageClick", [b.elem, b.event], function(a) {
                                            d = a
                                        });
                                        g(b);
                                        return d
                                    };
                                    a.plugins.waitForDependencies(["Utils"], function() {
                                        var b;
                                        if (d.urlKeyword) {
                                            var g = document.location.href;
                                            b = {};
                                            a.plugins.exec("Utils", "getQueryStringValue", [d.urlKeyword, g], function(p) {
                                                p && (b.keyword = p);
                                                d.urlResultPageNumber && a.plugins.exec("Utils", "getQueryStringValue", [d.urlResultPageNumber, g], function(a) {
                                                    b.resultPageNumber = a || "1"
                                                })
                                            })
                                        }
                                        b && a.setContext("InternalSearch", b);
                                        a.emit("InternalSearch:Ready", {
                                            lvl: "INFO",
                                            details: {
                                                config: {
                                                    urlKeyword: d.urlKeyword,
                                                    urlResultPageNumber: d.urlResultPageNumber
                                                },
                                                url: g,
                                                data: b
                                            }
                                        })
                                    })
                                };
                                window.ATInternet.Tracker.addPlugin("InternalSearch");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "info": true
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.MvTesting = function(a) {
                                    var d = 0,
                                        g = function(a, b) {
                                            var d = "";
                                            a.hasOwnProperty(b) && (d = a[b], d = void 0 === d ? "" : d + "");
                                            return d
                                        },
                                        b = function(a) {
                                            for (var b in a)
                                                if (a.hasOwnProperty(b)) return !1;
                                            return !0
                                        },
                                        k = function(a) {
                                            return "object" === typeof a && !(a instanceof Array)
                                        },
                                        p = function(b) {
                                            var d = b.name;
                                            a.exec("Utils", "manageChapters", [b, "chapter", 3], function(a) {
                                                d = a + (d ? d : "")
                                            });
                                            return d
                                        };
                                    a.mvTesting = {};
                                    a.mvTesting.set = function(d) {
                                        if (k(d) && !b(d)) {
                                            a.dispatchSubscribe("mvTesting");
                                            var f = g(d, "test"),
                                                n = g(d, "waveId");
                                            d = g(d, "creation");
                                            a.setParam("abmvc", f + "-" + n + "-" + d, {
                                                hitType: ["mvtesting"]
                                            })
                                        }
                                    };
                                    a.mvTesting.add = function(h) {
                                        if (k(h) && !b(h)) {
                                            a.dispatchSubscribe("mvTesting");
                                            var f = g(h, "variable");
                                            h = g(h, "version");
                                            d++;
                                            a.setParam("abmv" + d, f + "-" + h, {
                                                hitType: ["mvtesting"]
                                            })
                                        }
                                    };
                                    a.mvTesting.onDispatch = function(b) {
                                        var d = a.getContext("page") || {};
                                        a.setParam("p", p(d), {
                                            hitType: ["mvtesting"]
                                        });
                                        a.setParam("s2", d.level2 || "", {
                                            hitType: ["mvtesting"]
                                        });
                                        a.setParam("type", "mvt", {
                                            hitType: ["mvtesting"]
                                        });
                                        a.sendHit(null, [
                                            ["hitType", ["mvtesting"]]
                                        ], b)
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("MvTesting");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "storageCapacity": 1,
                                    "storageMode": "required",
                                    "timeout": 500,
                                    "info": true
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.Offline = function(a) {
                                    var d = {};
                                    a.configPlugin("Offline", dfltPluginCfg || {}, function(a) {
                                        d = a
                                    });
                                    var g = function() {
                                            var a = localStorage.getItem("ATOffline"),
                                                c = {
                                                    hits: [],
                                                    length: 0
                                                };
                                            if (a) {
                                                var b = ATInternet.Utils.jsonParse(a) || {
                                                    hits: []
                                                };
                                                c.hits = b.hits;
                                                c.length = a.length
                                            }
                                            return c
                                        },
                                        b = function(a) {
                                            try {
                                                localStorage.setItem("ATOffline", ATInternet.Utils.jsonSerialize(a))
                                            } catch (c) {}
                                        },
                                        k = function() {
                                            return g().hits
                                        },
                                        p = function(a) {
                                            if (a) {
                                                a = a.split(/&ref=\.*/i);
                                                var c = "&cn=offline&olt=" + String(Math.floor((new Date).getTime() /
                                                    1E3));
                                                a = a[0] + c + "&ref=" + (a[1] || "")
                                            }
                                            return a
                                        },
                                        h = function(a) {
                                            var c = g(),
                                                f = a.length,
                                                m = !0;
                                            if (4 * ((c.length || 11) + f) > 1048576 * d.storageCapacity) {
                                                var m = !1,
                                                    h = c.hits.shift();
                                                if ("undefined" !== typeof h)
                                                    for (var m = !0, r = h.length; r < f;)
                                                        if (h = c.hits.shift(), "undefined" !== typeof h) r += h.length;
                                                        else {
                                                            m = !1;
                                                            break
                                                        }
                                            }
                                            m && (c.hits.push(a), b({
                                                hits: c.hits
                                            }))
                                        },
                                        f = function(e, c) {
                                            if (navigator.onLine) {
                                                var l = k();
                                                if (0 < l.length) {
                                                    var m = l.shift();
                                                    b({
                                                        hits: l
                                                    });
                                                    a.onTrigger("Tracker:Hit:Sent:Ok", function() {
                                                        f(e, c)
                                                    }, !0);
                                                    a.onTrigger("Tracker:Hit:Sent:Error", function() {
                                                        f(e, c)
                                                    }, !0);
                                                    a.sendUrl(m)
                                                } else if (e) {
                                                    var g = null;
                                                    a.plugins.exec("Utils", "getQueryStringValue", ["a", e], function(a) {
                                                        g = a
                                                    });
                                                    g ? setTimeout(function() {
                                                        a.sendUrl(e, c)
                                                    }, d.timeout) : a.sendUrl(e, c)
                                                }
                                            } else e && (h(p(e)), c && c())
                                        },
                                        n = function(b) {
                                            a.builder.sendUrl = function(a, d) {
                                                b || !navigator.onLine ? (h(p(a)), d && d()) : f(a, d)
                                            }
                                        };
                                    a.offline = {};
                                    a.offline.getLength = function() {
                                        return 4 * g().length
                                    };
                                    a.offline.remove = function() {
                                        b({
                                            hits: []
                                        })
                                    };
                                    a.offline.get = k;
                                    a.offline.send = function() {
                                        f(null, null)
                                    };
                                    a.plugins.waitForDependencies(["Utils"], function() {
                                        var b = ATInternet.Utils.isLocalStorageAvailable(),
                                            c = navigator.onLine;
                                        b && "undefined" !== typeof c && ("required" === d.storageMode ? n(!1) : "always" === d.storageMode && n(!0));
                                        a.emit("Offline:Ready", {
                                            lvl: "INFO",
                                            details: {
                                                isLocalStorageAvailable: b,
                                                storageMode: d.storageMode,
                                                isOnline: c
                                            }
                                        })
                                    })
                                };
                                window.ATInternet.Tracker.addPlugin("Offline");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "info": true
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.OnSiteAds = function(a) {
                                    var d = "",
                                        g = function(c) {
                                            var b = c.name;
                                            a.exec("Utils", "manageChapters", [c, "chapter", 3], function(a) {
                                                b = a + (b ? b : "")
                                            });
                                            return b
                                        },
                                        b = function(a, b) {
                                            return a[b] ? a[b] : ""
                                        },
                                        k = function(a, e) {
                                            var d = b(a, e);
                                            if (d) {
                                                var f = b(a, "prefix");
                                                if (d.campaignId) {
                                                    var f = f || "PUB",
                                                        r = b(d, "campaignId"),
                                                        g = b(d, "creation"),
                                                        h = b(d, "variant"),
                                                        n = b(d, "format"),
                                                        k = b(d, "generalPlacement"),
                                                        p = b(d, "detailedPlacement"),
                                                        y = b(d, "advertiserId"),
                                                        d = b(d, "url");
                                                    return f + "-" + r + "-" + g + "-" + h + "-" + n + "-" + k + "-" +
                                                        p + "-" + y + "-" + d
                                                }
                                                if (d.adId) return f = f || "INT", r = b(d, "adId"), g = b(d, "format"), d = b(d, "productId"), f + "-" + r + "-" + g + "||" + d
                                            }
                                            return ""
                                        },
                                        p = function(c) {
                                            var b = a.getContext("page") || {};
                                            a.sendHit({
                                                atc: k(c, "click"),
                                                type: "AT",
                                                patc: g(b),
                                                s2atc: b.level2 || "",
                                                stc: c.customObject || ""
                                            }, [
                                                ["hitType", ["onSiteAdsClick"]]
                                            ], c.callback)
                                        },
                                        h = function(c) {
                                            a.sendHit({
                                                ati: k(c, "impression"),
                                                type: "AT",
                                                stc: c.customObject || ""
                                            }, [
                                                ["hitType", ["onSiteAdsImpression"]]
                                            ], c.callback)
                                        },
                                        f = function(c, b) {
                                            var e = a.buffer.get("ati", !0) || {};
                                            e.value = "string" === typeof e.value ? [e.value] : e.value || [];
                                            e.options = e.options || {
                                                hitType: [b, "page"]
                                            };
                                            e.value.push(c);
                                            a.buffer.set("ati", e.value, e.options)
                                        },
                                        n = function(c, b) {
                                            c.click ? a.setParam("atc", k(c, "click"), {
                                                hitType: [b, "page"]
                                            }) : c.impression && a.setParam("ati", k(c, "impression"), {
                                                hitType: [b, "page"]
                                            });
                                            if (c.customObject) {
                                                a.setContext("onsiteads", {
                                                    customObject: c.customObject
                                                });
                                                var e = a.getContext("page") || {};
                                                e.customObject = ATInternet.Utils.completeFstLevelObj(e.customObject, c.customObject, !1);
                                                a.setContext("page", e)
                                            }
                                            a.dispatchSubscribe("onSiteAds")
                                        };
                                    a.selfPromotion = this.selfPromotion = {};
                                    a.publisher = this.publisher = {};
                                    a.publisher.set = this.publisher.set = function(a) {
                                        n(a, "publisher")
                                    };
                                    a.selfPromotion.set = this.selfPromotion.set = function(a) {
                                        n(a, "selfPromotion")
                                    };
                                    a.publisher.add = this.publisher.add = function(c) {
                                        f(k(c, "impression"), "publisher");
                                        a.dispatchSubscribe("onSiteAds")
                                    };
                                    a.selfPromotion.add = this.selfPromotion.add = function(c) {
                                        f(k(c, "impression"), "selfPromotion");
                                        a.dispatchSubscribe("onSiteAds")
                                    };
                                    var e = this.advertEvent = function(c) {
                                        var b = !0;
                                        a.exec("TechClicks", "manageClick", [c.elem, c.event], function(a) {
                                            b = a
                                        });
                                        c.click ? p(c) : c.impression && h(c);
                                        return b
                                    };
                                    a.publisher.send = this.publisher.send = function(a) {
                                        return e(a)
                                    };
                                    a.selfPromotion.send = this.selfPromotion.send = function(a) {
                                        return e(a)
                                    };
                                    a.onSiteAds = {};
                                    a.onSiteAds.onDispatch = this.onDispatch = function(c) {
                                        if (!a.dispatchSubscribed("page")) {
                                            var b = a.getContext("page") || {};
                                            a.setParam("type", "AT", {
                                                hitType: ["publisher", "selfPromotion"]
                                            });
                                            a.getParam("atc") && (a.setParam("patc", g(b), {
                                                hitType: ["publisher", "selfPromotion"]
                                            }), a.setParam("s2atc", b.level2 || "", {
                                                hitType: ["publisher", "selfPromotion"]
                                            }));
                                            (b = a.getContext("onsiteads")) && b.customObject && a.setParam("stc", b.customObject, {
                                                encode: !0,
                                                hitType: ["publisher", "selfPromotion"]
                                            });
                                            a.sendHit(null, [
                                                ["hitType", ["publisher", "selfPromotion"]]
                                            ], c)
                                        }
                                    };
                                    a.plugins.waitForDependencies(["Utils", "TechClicks"], function() {
                                        d = document.location.href;
                                        a.plugins.exec("Utils", "getQueryStringValue", ["xtatc", d], function(c) {
                                            c && a.setParam("atc", c, {
                                                hitType: ["publisher", "selfPromotion", "page"]
                                            })
                                        });
                                        a.emit("OnSiteAds:Ready", {
                                            lvl: "INFO",
                                            details: {
                                                href: d
                                            }
                                        })
                                    })
                                };
                                window.ATInternet.Tracker.addPlugin("OnSiteAds");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "info": true
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.Page = function(a) {
                                    var d = ["pageId", "chapterLabel", "update"],
                                        g = ["pid", "pchap", "pidt"],
                                        b = ["page", "site"],
                                        k = ["f", "x"],
                                        p = function(c) {
                                            var b = c.name;
                                            a.exec("Utils", "manageChapters", [c, "chapter", 3], function(a) {
                                                b = a + (b ? b : "")
                                            });
                                            return b
                                        },
                                        h = function(a, c, b) {
                                            c ? a = c : a || "undefined" === typeof b || (a = b);
                                            return a
                                        },
                                        f = function(a, c, b) {
                                            c.hasOwnProperty(b) && (a[b] = h(a[b], c[b]))
                                        },
                                        n = function(c) {
                                            if (!ATInternet.Utils.isPreview() || a.getConfig("preview")) ATInternet.Utils.isPrerender(function(a) {
                                                c(a)
                                            }) || c()
                                        },
                                        e = function(c, e, d) {
                                            if (e)
                                                for (var f = 0; f < b.length; f++)
                                                    if (e.hasOwnProperty(b[f]) && e[b[f]])
                                                        for (var l in e[b[f]]) e[b[f]].hasOwnProperty(l) && (d ? c[k[f] + l] = e[b[f]][l] : a.setParam(k[f] + l, e[b[f]][l]))
                                        },
                                        c = function(c, b, e) {
                                            if (b) {
                                                a.exec("Utils", "manageChapters", [b, "chapter", 3], function(a) {
                                                    a && (b.chapterLabel = a.replace(/::$/gi, ""))
                                                });
                                                for (var f = 0; f < g.length; f++) b.hasOwnProperty(d[f]) && (e ? c[g[f]] = b[d[f]] : a.setParam(g[f], b[d[f]]))
                                            }
                                        },
                                        l = function(c, b, e) {
                                            if (b && b.keywords instanceof Array) {
                                                var d = b.keywords.length;
                                                if (0 < d) {
                                                    for (var f = "", l = 0; l < d; l++) f += "[" + b.keywords[l] + "]" + (l < d - 1 ? "|" : "");
                                                    e ? c.tag = f : a.setParam("tag", f)
                                                }
                                            }
                                        },
                                        m = function(c, b, e) {
                                            if (b) {
                                                var d, f = function(a) {
                                                    return a ? a : "0"
                                                };
                                                d = "" + (f(b.category1) + "-");
                                                d += f(b.category2) + "-";
                                                d += f(b.category3);
                                                e ? c.ptype = d : a.setParam("ptype", d)
                                            }
                                        },
                                        q = function(c, b, e) {
                                            if (b)
                                                for (var d in b) b.hasOwnProperty(d) && "undefined" !== typeof b[d] && (e ? c[d] = b[d] : a.setParam(d, b[d]))
                                        };
                                    a.customVars = this.customVars = {};
                                    a.customVars.set = this.customVars.set = function(c) {
                                        var b = a.getContext("page") || {},
                                            e = b.customVars;
                                        if (e) {
                                            if (c)
                                                for (var d in c) c.hasOwnProperty(d) && (e[d] = ATInternet.Utils.completeFstLevelObj(e[d], c[d], !0))
                                        } else e = c;
                                        b.customVars = e;
                                        a.setContext("page", b)
                                    };
                                    a.dynamicLabel = this.dynamicLabel = {};
                                    a.dynamicLabel.set = this.dynamicLabel.set = function(c) {
                                        var b = a.getContext("page") || {};
                                        b.dynamicLabel = ATInternet.Utils.completeFstLevelObj(b.dynamicLabel, c, !0);
                                        a.setContext("page", b)
                                    };
                                    a.tags = this.tags = {};
                                    a.tags.set = this.tags.set = function(c) {
                                        var b = a.getContext("page") || {};
                                        b.tags = ATInternet.Utils.completeFstLevelObj(b.tags, c, !0);
                                        a.setContext("page", b)
                                    };
                                    a.customTreeStructure = this.customTreeStructure = {};
                                    a.customTreeStructure.set = this.customTreeStructure.set = function(c) {
                                        var b = a.getContext("page") || {};
                                        b.customTreeStructure = ATInternet.Utils.completeFstLevelObj(b.customTreeStructure, c, !0);
                                        a.setContext("page", b)
                                    };
                                    a.page = {};
                                    a.page.reset = this.reset = function() {
                                        a.setContext("page", void 0)
                                    };
                                    a.page.set = this.set = function(c) {
                                        a.dispatchSubscribe("page");
                                        var b = a.getContext("page") || {};
                                        b.name = h(b.name, c.name, "");
                                        b.level2 = h(b.level2, c.level2, "");
                                        f(b, c, "chapter1");
                                        f(b, c, "chapter2");
                                        f(b, c, "chapter3");
                                        b.customObject = ATInternet.Utils.completeFstLevelObj(b.customObject, c.customObject, !0);
                                        a.setContext("page", b)
                                    };
                                    a.page.send = this.send = function(b) {
                                        var d = {
                                                p: p(b),
                                                s2: b.level2 || ""
                                            },
                                            g = !0,
                                            k = b.customObject;
                                        if (k) {
                                            var s = a.getParam("stc", !0);
                                            if (s && s.options.permanent) {
                                                var w = s.options.hitType || [],
                                                    y = ATInternet.Utils.arrayIndexOf;
                                                if (-1 !== y(w, "page") || -1 !== y(w, "all")) k = ATInternet.Utils.completeFstLevelObj(s.value || {}, k, !0)
                                            }
                                            a.exec("Utils", "customObjectToString", [k], function(a) {
                                                d.stc = a
                                            })
                                        }
                                        k = a.getContext("page") || {};
                                        k.vrn && (d.vrn = k.vrn, k.vrn = void 0, a.setContext("page", k));
                                        s = a.getContext("InternalSearch") || {};
                                        "undefined" != typeof s.keyword && (d.mc = ATInternet.Utils.cloneSimpleObject(s.keyword), "undefined" != typeof s.resultPageNumber && (d.np = ATInternet.Utils.cloneSimpleObject(s.resultPageNumber)), a.setContext("InternalSearch", void 0));
                                        ATInternet.Utils.isPreview() && a.getConfig("preview") && (d.pvw = 1);
                                        e(d, b.customVars, !0);
                                        c(d, b.dynamicLabel, !0);
                                        l(d, b.tags, !0);
                                        m(d, b.customTreeStructure, !0);
                                        s = a.getContext("campaigns") || {};
                                        q(d, s, !0);
                                        a.setContext("campaigns", void 0);
                                        a.exec("TechClicks", "manageClick", [b.elem, b.event], function(a) {
                                            g = a
                                        });
                                        n(function() {
                                            a.sendHit(d, null, b.callback)
                                        });
                                        k.name = h(k.name, b.name, "");
                                        k.level2 = h(k.level2, b.level2, "");
                                        f(k, b, "chapter1");
                                        f(k, b, "chapter2");
                                        f(k, b, "chapter3");
                                        a.setContext("page", k);
                                        return g
                                    };
                                    a.page.onDispatch = this.onDispatch = function(b) {
                                        var d = a.getContext("page") || {},
                                            f = a.getContext("InternalSearch") || {};
                                        a.setParam("p", p(d));
                                        a.setParam("s2", d.level2 || "");
                                        d.vrn && (a.setParam("vrn", d.vrn), d.vrn = void 0, a.setContext("page", d));
                                        "undefined" != typeof f.keyword && (a.setParam("mc", ATInternet.Utils.cloneSimpleObject(f.keyword)), "undefined" != typeof f.resultPageNumber && a.setParam("np", ATInternet.Utils.cloneSimpleObject(f.resultPageNumber)), a.setContext("InternalSearch", void 0));
                                        ATInternet.Utils.isPreview() && a.getConfig("preview") && a.setParam("pvw", 1);
                                        e(null, d.customVars, !1);
                                        c(null, d.dynamicLabel, !1);
                                        l(null, d.tags, !1);
                                        m(null, d.customTreeStructure, !1);
                                        f = a.getContext("campaigns") || {};
                                        q(null, f, !1);
                                        a.setContext("campaigns", void 0);
                                        var d = d.customObject,
                                            g = [
                                                ["hitType", ["page"]]
                                            ];
                                        if (d)
                                            if (f = a.getParam("stc", !0)) {
                                                var h = f.options.hitType || [],
                                                    k = ATInternet.Utils.arrayIndexOf,
                                                    k = -1 !== k(h, "page") || -1 !== k(h, "all"),
                                                    h = f.options.permanent;
                                                k ? (k = ATInternet.Utils.cloneSimpleObject(f), k.value = ATInternet.Utils.completeFstLevelObj(k.value || {}, d, !0), a.setParam("stc", k.value, {
                                                    encode: !0
                                                }), n(function() {
                                                    a.sendHit(null, g, b)
                                                }), h && a.setParam("stc", f.value, f.options)) : (a.setParam("stc", d, {
                                                    encode: !0
                                                }), n(function() {
                                                    a.sendHit(null, g, b)
                                                }), a.setParam("stc", f.value, f.options))
                                            } else a.setParam("stc", d, {
                                                encode: !0
                                            }), n(function() {
                                                a.sendHit(null, g, b)
                                            });
                                        else n(function() {
                                            a.sendHit(null, g, b)
                                        })
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("Page");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "info": true
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.RichMedia = function(a) {
                                    var d = function(a, b) {
                                            var e = parseInt(a, 10);
                                            return e ? Math.max(e, b) : 0
                                        },
                                        g = new function() {
                                            this._timeout = {};
                                            this.setTimeout = function(c, b, e) {
                                                this._timeout[c] = this._timeout[c] || {};
                                                this._timeout[c][b] && window.clearTimeout(this._timeout[c][b]);
                                                this._timeout[c][b] = window.setTimeout(function() {
                                                    a.richMedia.send({
                                                        action: "refresh",
                                                        playerId: c,
                                                        mediaLabel: b
                                                    })
                                                }, 1E3 * e)
                                            };
                                            this.setTimeoutObject = function(c, b, e, f) {
                                                this._timeout[c] = this._timeout[c] || {};
                                                if ("undefined" === typeof this._timeout[c][b]) {
                                                    var g = [],
                                                        h;
                                                    for (h in e) e.hasOwnProperty(h) && g.push({
                                                        delay: d(h, 0),
                                                        refresh: d(e[h], 5)
                                                    });
                                                    g.sort(function(a, b) {
                                                        return a.delay < b.delay ? -1 : a.delay > b.delay ? 1 : 0
                                                    });
                                                    this._timeout[c][b] = {
                                                        arrObj: g,
                                                        arrObjSave: ATInternet.Utils.cloneSimpleObject(g)
                                                    }
                                                }
                                                e = this._timeout[c][b];
                                                if (0 < e.arrObj.length && (g = e.arrObj[0].delay, h = e.arrObj[0].refresh, "number" === typeof g && "number" === typeof h && 0 < h)) {
                                                    e[g] = e[g] || {};
                                                    var k = void 0;
                                                    "undefined" !== typeof e.arrObj[1] && (k = e.arrObj[1].delay);
                                                    var n = 0;
                                                    "undefined" === typeof k ? n = 1 : "number" === typeof e[g].num ? n = "refresh" === f ? Math.max(e[g].num - 1, 0) : e[g].num : "number" === typeof k && (n = Math.floor(60 * (k - g) / h) - 1);
                                                    e[g].num = n;
                                                    e[g].timeout && window.clearTimeout(e[g].timeout);
                                                    0 < n ? e[g].timeout = window.setTimeout(function() {
                                                        a.richMedia.send({
                                                            action: "refresh",
                                                            playerId: c,
                                                            mediaLabel: b
                                                        })
                                                    }, 1E3 * h) : (e[g].num = void 0, e[g].timeout = void 0, e.arrObj.splice(0, 1), window.setTimeout(function() {
                                                        a.richMedia.send({
                                                            action: "refresh",
                                                            playerId: c,
                                                            mediaLabel: b
                                                        })
                                                    }, 1E3 * h));
                                                    this._timeout[c][b] = e
                                                }
                                            };
                                            this.clearTimeout = function(a, b, e) {
                                                this._timeout[a] = this._timeout[a] || {};
                                                if ("object" === typeof this._timeout[a][b]) {
                                                    for (var d in this._timeout[a][b])
                                                        if (this._timeout[a][b].hasOwnProperty(d)) {
                                                            var f = this._timeout[a][b][d].num;
                                                            "undefined" !== typeof f && 0 < f && (this._timeout[a][b][d].timeout && window.clearTimeout(this._timeout[a][b][d].timeout), this._timeout[a][b][d].timeout = void 0)
                                                        }
                                                    e && (this._timeout[a][b].arrObj = ATInternet.Utils.cloneSimpleObject(this._timeout[a][b].arrObjSave))
                                                } else this._timeout[a][b] && window.clearTimeout(this._timeout[a][b])
                                            };
                                            this.removePlayer = function(b) {
                                                for (var e in this._timeout[b]) this._timeout[b].hasOwnProperty(e) && (this.clearTimeout(b, e, !1), a.richMedia.send({
                                                    action: "stop",
                                                    playerId: b,
                                                    mediaLabel: e
                                                }));
                                                this._timeout[b] = {}
                                            };
                                            this.removeAll = function() {
                                                for (var a in this._timeout) this._timeout.hasOwnProperty(a) && this.removePlayer(a);
                                                this._timeout = {}
                                            }
                                        },
                                        b = new function() {
                                            this._media = function() {
                                                this.type = void 0;
                                                this.plyr = 0;
                                                this.clnk = this.s2 = void 0;
                                                this.p = "";
                                                this.m9 = this.m6 = this.m5 = this.m1 = this.rfsh = this.buf = this.a = void 0
                                            };
                                            this._mediaAll = {};
                                            this.setMediaProperty = function(a, b, e, d) {
                                                this._mediaAll[a] = this._mediaAll[a] || {};
                                                this._mediaAll[a][b] = this._mediaAll[a][b] || new this._media;
                                                this._mediaAll[a][b][e] = d
                                            };
                                            this.getMediaProperty = function(a, b, e) {
                                                if (this._mediaAll[a] && this._mediaAll[a][b]) return this._mediaAll[a][b][e]
                                            };
                                            this.removePlayer = function(a) {
                                                this._mediaAll[a] = {}
                                            };
                                            this.removeAll = function() {
                                                this._mediaAll = {}
                                            }
                                        },
                                        k = function(b, e, d) {
                                            var f = b[d] || "";
                                            a.exec("Utils", "manageChapters", [b, e, 3], function(a) {
                                                f = a + f
                                            });
                                            return f
                                        },
                                        p = function(a, b, e, d) {
                                            var f = a[b];
                                            "boolean" === typeof a[b] && (f = a[b] ? d : e);
                                            return f
                                        },
                                        h = function(a) {
                                            var b = 0;
                                            /^(\-|\+)?([0-9]+)$/.test(a) && (b = Number(a));
                                            return b
                                        },
                                        f = function(a, e, d, f, g) {
                                            e = b.getMediaProperty(e, d, f);
                                            "undefined" !== typeof e && (a[f] = g ? encodeURIComponent(e) : e)
                                        },
                                        n = function(a, b, e) {
                                            "undefined" !== typeof e && (a[b] = e)
                                        },
                                        e = function(a, e, d, f) {
                                            "undefined" !== typeof f && b.setMediaProperty(a, e, d, f)
                                        };
                                    a.richMedia = {};
                                    a.richMedia.add = this.add = function(a) {
                                        a = a || {};
                                        var b = h(a.playerId),
                                            d = k(a, "mediaTheme", "mediaLabel"),
                                            f = p(a, "isEmbedded", "int", "ext");
                                        e(b, d, "plyr", b);
                                        e(b, d, "type", a.mediaType);
                                        e(b, d, "s2", a.mediaLevel2);
                                        e(b, d, "p", d);
                                        e(b, d, "clnk", a.linkedContent || a.previousMedia);
                                        e(b, d, "a", a.action);
                                        e(b, d, "rfsh", a.refreshDuration);
                                        e(b, d, "m1", a.duration);
                                        e(b, d, "m5", f);
                                        e(b, d, "m6", a.broadcastMode);
                                        e(b, d, "m9", a.webdomain)
                                    };
                                    a.richMedia.remove = this.remove = function(a) {
                                        g.removePlayer(a);
                                        b.removePlayer(a)
                                    };
                                    a.richMedia.removeAll = this.removeAll = function() {
                                        g.removeAll();
                                        b.removeAll()
                                    };
                                    a.richMedia.send = this.send = function(c) {
                                        c = c || {};
                                        var e = h(c.playerId),
                                            m = k(c, "mediaTheme", "mediaLabel"),
                                            q = {};
                                        q.plyr = e;
                                        q.p = m;
                                        c.action && (q.a = c.action);
                                        f(q, e, m, "type", !1);
                                        f(q, e, m, "s2", !1);
                                        f(q, e, m, "m1", !1);
                                        f(q, e, m, "m5", !1);
                                        f(q, e, m, "m6", !1);
                                        if ("play" === q.a || "info" === q.a) {
                                            c = p(c, "isBuffering", "0", "1");
                                            n(q, "buf", c);
                                            c = a.getContext("page") || {};
                                            var r = k(c, "chapter", "name") || void 0;
                                            n(q, "prich", r);
                                            n(q, "s2rich", c.level2 || void 0);
                                            f(q, e, m, "clnk", !1);
                                            f(q, e, m, "m9", !0)
                                        }
                                        a.sendHit(q, [
                                            ["hitType", ["richmedia"]]
                                        ]);
                                        "pause" === q.a ? g.clearTimeout(e, m, !1) : "stop" === q.a && g.clearTimeout(e, m, !0);
                                        if ("play" === q.a || "refresh" === q.a) c = b.getMediaProperty(e, m, "rfsh"), "object" === typeof c ? g.setTimeoutObject(e, m, c, q.a) : (q = d(c, 5), 0 !== q && g.setTimeout(e, m, q))
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("RichMedia");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "info": true
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.SalesTracker = function(a) {
                                    var d = 0,
                                        g = function(b, d, e) {
                                            b.hasOwnProperty(e) && (b = b[e], a.setParam(d, void 0 === b ? "" : b + "", {
                                                hitType: ["page"]
                                            }))
                                        },
                                        b = function(a) {
                                            for (var b in a)
                                                if (a.hasOwnProperty(b)) return !1;
                                            return !0
                                        },
                                        k = function(a) {
                                            return "object" === typeof a && !(a instanceof Array)
                                        },
                                        p = function(b) {
                                            var d = b.productId ? b.productId : "",
                                                e = b.category ? b.category + "::" : "";
                                            a.exec("Utils", "manageChapters", [b, "category", 6], function(a) {
                                                a && (e = a)
                                            });
                                            return e + d
                                        },
                                        h = function(b) {
                                            var d = "";
                                            a.exec("Utils", "manageChapters", [b, "category", 6], function(a) {
                                                a && (d = a)
                                            });
                                            d += b.productId;
                                            b = a.getContext("product") || {};
                                            b.viewedProducts ? b.viewedProducts.push(d) : b.viewedProducts = [d];
                                            a.setContext("product", b)
                                        };
                                    a.order = this.order = {};
                                    a.cart = this.cart = {};
                                    a.aisle = this.aisle = {};
                                    a.salesTracker = {};
                                    a.product = this.product = {};
                                    a.order.set = this.order.set = function(d) {
                                        var h = !1;
                                        if (k(d) && !b(d)) {
                                            h = !0;
                                            a.dispatchSubscribe("page");
                                            a.dispatchSubscribe("salesTracker");
                                            g(d, "cmd", "orderId");
                                            g(d, "roimt", "turnover");
                                            g(d, "st", "status");
                                            "boolean" === typeof d.newCustomer ? a.setParam("newcus", d.newCustomer ? "1" : "0", {
                                                hitType: ["page"]
                                            }) : d.newCustomer && "undefined" === typeof a.getParams("newcus") && a.setParam("newcus", "0", {
                                                hitType: ["page"]
                                            });
                                            var e = d.amount;
                                            k(e) && (g(e, "mtht", "amountTaxFree"), g(e, "mtttc", "amountTaxIncluded"), g(e, "tax", "taxAmount"));
                                            e = d.delivery;
                                            k(e) && (g(e, "fp", "shippingFeesTaxIncluded"), g(e, "fpht", "shippingFeesTaxFree"), g(e, "dl", "deliveryMethod"));
                                            g(d, "mp", "paymentMethod");
                                            e = d.discount;
                                            k(e) && (g(e, "dsc", "discountTaxIncluded"), g(e, "dscht", "discountTaxFree"), g(e, "pcd", "promotionalCode"));
                                            "boolean" === typeof d.confirmationRequired ? a.setParam("tp", d.confirmationRequired ? "pre1" : "", {
                                                hitType: ["page"]
                                            }) : d.confirmationRequired && "undefined" === typeof a.getParams("tp") && a.setParam("tp", "", {
                                                hitType: ["page"]
                                            });
                                            d = d.orderCustomVariables;
                                            if (d instanceof Array)
                                                for (e = 0; e < d.length; e++) g(d, "o" + (e + 1), e)
                                        }
                                        return h
                                    };
                                    a.cart.set = this.cart.set = function(d) {
                                        var h = !1;
                                        k(d) && !b(d) && (h = !0, a.dispatchSubscribe("page"), a.dispatchSubscribe("salesTracker"), g(d, "idcart", "cartId"), "boolean" === typeof d.isBasketPage ? "pre1" !== a.getParams("tp") && a.setParam("tp", d.isBasketPage ? "cart" : "", {
                                            hitType: ["page"]
                                        }) : d.isBasketPage && "undefined" === typeof a.getParams("tp") && a.setParam("tp", "", {
                                            hitType: ["page"]
                                        }));
                                        return h
                                    };
                                    a.cart.add = this.cart.add = function(f) {
                                        var h = !1;
                                        if (k(f) && !b(f) && (h = !0, f = f.product, k(f))) {
                                            d++;
                                            var e = d,
                                                c = p(f);
                                            a.setParam("pdt" + e, c, {
                                                hitType: ["page"]
                                            });
                                            g(f, "qte" + e, "quantity");
                                            g(f, "mt" + e, "unitPriceTaxIncluded");
                                            g(f, "mtht" + e, "unitPriceTaxFree");
                                            g(f, "dsc" + e, "discountTaxIncluded");
                                            g(f, "dscht" + e, "discountTaxFree");
                                            g(f, "pcode" + e, "promotionalCode")
                                        }
                                        return h
                                    };
                                    a.aisle.set = this.aisle.set = function(d) {
                                        var g = !1;
                                        if (k(d) && !b(d)) {
                                            g = !0;
                                            a.dispatchSubscribe("page");
                                            var e = "";
                                            a.exec("Utils", "manageChapters", [d, "level", 6], function(a) {
                                                e = a
                                            });
                                            e = e.replace(/::$/gi, "");
                                            a.setParam("aisl", e, {
                                                hitType: ["page"]
                                            })
                                        }
                                        return g
                                    };
                                    a.product.add = this.product.add = function(d) {
                                        var g = !1,
                                            e;
                                        if (e = k(d))
                                            if (e = !b(d)) {
                                                a: {
                                                    e = ["productId"];
                                                    for (var c = 0; c < e.length; c++)
                                                        if (void 0 === d[e[c]]) {
                                                            e = !0;
                                                            break a
                                                        }
                                                    e = !1
                                                }
                                                e = !e
                                            }
                                        e && (g = !0, h(d), a.dispatchSubscribe("salesTracker"));
                                        return g
                                    };
                                    a.salesTracker.onDispatch = this.onDispatch = function(b) {
                                        a.getParams("cmd");
                                        a.getParams("idcart") || "cart" !== a.getParams("tp") && a.getParams("tp");
                                        var d = a.getContext("product");
                                        d && d.viewedProducts && 0 < d.viewedProducts.length && (a.setParam("pdtl", d.viewedProducts.join("|"), {
                                            hitType: ["product"]
                                        }), a.setParam("type", "pdt", {
                                            hitType: ["product"]
                                        }), a.sendHit(null, [
                                            ["hitType", ["product"]]
                                        ], b))
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("SalesTracker");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "clicksAutoManagementEnabled": true,
                                    "clicksAutoManagementTimeout": 500,
                                    "info": false
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.TechClicks = function(a) {
                                    var d, g;
                                    a.configPlugin("TechClicks", dfltPluginCfg || {}, function(a) {
                                        d = a.clicksAutoManagementEnabled;
                                        g = a.clicksAutoManagementTimeout
                                    });
                                    this.deactivateAutoManagement = function() {
                                        d = !1
                                    };
                                    var b = function(a) {
                                            switch (a.target) {
                                                case "_top":
                                                    window.top.location.href = a.url;
                                                    break;
                                                case "_parent":
                                                    window.parent.location.href = a.url;
                                                    break;
                                                default:
                                                    window.location.href = a.url
                                            }
                                        },
                                        k = function(a) {
                                            var c = a.timeout;
                                            a.mailto ? setTimeout(function() {
                                                window.location.href = a.mailto
                                            }, c) : a.form ? setTimeout(function() {
                                                a.form.submit()
                                            }, c) : a.url && setTimeout(function() {
                                                b({
                                                    url: a.url,
                                                    target: a.target
                                                })
                                            }, c)
                                        },
                                        p = function(d) {
                                            for (var c, f = "_self", h = d.timeoutonly; d;) {
                                                if (d.href && 0 === d.href.indexOf("http")) {
                                                    c = d.href.split('"').join('\\"');
                                                    f = d.target ? d.target : f;
                                                    break
                                                }
                                                d = d.parentNode
                                            }
                                            if (c) {
                                                if (!h) a.onTrigger("Tracker:Hit:Sent:Ok", function() {
                                                    b({
                                                        url: c,
                                                        target: f
                                                    })
                                                });
                                                k({
                                                    url: c,
                                                    target: f,
                                                    timeout: g
                                                })
                                            }
                                        },
                                        h = function(b) {
                                            var c = b;
                                            for (b = c.timeoutonly; c && "FORM" !== c.nodeName;) c = c.parentNode;
                                            if (c) {
                                                if (!b) a.onTrigger("Tracker:Hit:Sent:Ok", function() {
                                                    c.submit()
                                                });
                                                k({
                                                    form: c,
                                                    timeout: g
                                                })
                                            }
                                        },
                                        f = function(b) {
                                            var c = b;
                                            for (b = c.timeoutonly; c && !(c.href && 0 <= c.href.indexOf("mailto:"));) c = c.parentNode;
                                            if (c) {
                                                if (!b) a.onTrigger("Tracker:Hit:Sent:Ok", function() {
                                                    window.location.href = c.href
                                                });
                                                k({
                                                    mailto: c.href,
                                                    timeout: g
                                                })
                                            }
                                        },
                                        n = function(a) {
                                            for (; a;) {
                                                if (a.href) {
                                                    if (0 <= a.href.indexOf("mailto:")) return "mailto";
                                                    if (0 === a.href.indexOf("http")) return "redirection"
                                                } else if ("FORM" === a.nodeName) return "form";
                                                a = a.parentNode
                                            }
                                            return ""
                                        };
                                    this.manageClick = function(a, b) {
                                        var g = !0;
                                        if (d && a) {
                                            var k;
                                            a: {
                                                for (k = a; k;) {
                                                    if ("function" === typeof k.getAttribute && ("_blank" === k.getAttribute("target") || "no" === k.getAttribute("data-atclickmanagement"))) {
                                                        k = !0;
                                                        break a
                                                    }
                                                    k = k.parentNode
                                                }
                                                k = a;
                                                for (var q = window.location.href, r; k;) {
                                                    if ((r = k.href) && 0 <= r.indexOf("#") && q.substring(0, 0 <= q.indexOf("#") ? q.indexOf("#") : q.length) === r.substring(0, r.indexOf("#"))) {
                                                        k = !0;
                                                        break a
                                                    }
                                                    k = k.parentNode
                                                }
                                                k = !1
                                            }
                                            q = n(a);
                                            if (!k && q) switch (q) {
                                                case "mailto":
                                                    f(a);
                                                    g = !1;
                                                    break;
                                                case "form":
                                                    h(a);
                                                    g = !1;
                                                    break;
                                                case "redirection":
                                                    p(a), g = !1
                                            }
                                        }
                                        b && (k = b.defaultPrevented, "function" === typeof b.isDefaultPrevented && (k = b.isDefaultPrevented()), k || b.preventDefault && b.preventDefault());
                                        return g
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("TechClicks");
                            }).call(window);;
                            (function() {
                                var dfltPluginCfg = {
                                    "info": false
                                };
                                var dfltGlobalCfg = {};
                                window.ATInternet.Tracker.Plugins.Utils = function(a) {
                                    var d = this,
                                        g = {};
                                    d.getQueryStringValue = function(a, b) {
                                        var d = window.ATInternet.Utils.hashcode(b).toString();
                                        if (!g[d]) {
                                            g[d] = {};
                                            var f = RegExp("[&#?]{1}([^&=#?]*)=([^&#]*)?", "g"),
                                                n = f.exec(b);
                                            if (null !== n)
                                                for (; null !== n;) g[d][n[1]] = n[2], n = f.exec(b)
                                        }
                                        return g[d].hasOwnProperty(a) ? g[d][a] : null
                                    };
                                    d.customObjectToString = function(a) {
                                        return encodeURIComponent(window.ATInternet.Utils.jsonSerialize(a))
                                    };
                                    d.manageChapters = function(b, d, g) {
                                        var f = a.getConfig("ignoreEmptyChapterValue"),
                                            n = "";
                                        if (b) {
                                            g = parseInt(g, 10);
                                            for (var e = 1; e < g + 1; e++) var c = b[d + e] || "",
                                                n = f ? n + (c ? c + "::" : "") : n + (b.hasOwnProperty(d + e) ? c + "::" : "")
                                        }
                                        return n
                                    };
                                    d.getDocumentLevel = function() {
                                        var b = a.getConfig("documentLevel");
                                        if (0 > b.indexOf(".")) return window[b] || document;
                                        b = b.split(".");
                                        return window[b[0]][b[1]] || document
                                    };
                                    d.getLocation = function() {
                                        return d.getDocumentLevel().location.href
                                    };
                                    a.dispatchIndex = {};
                                    a.dispatchStack = [];
                                    a.dispatchEventFor = {};
                                    var b = 0;
                                    a.dispatchSubscribe = function(b) {
                                        return a.dispatchIndex[b] ? !1 : (a.dispatchStack.push(b), a.dispatchIndex[b] = !0)
                                    };
                                    a.dispatchSubscribed = function(b) {
                                        return !0 === a.dispatchIndex[b]
                                    };
                                    a.addSpecificDispatchEventFor = function(d) {
                                        return a.dispatchEventFor[d] ? !1 : (a.dispatchEventFor[d] = !0, b++, !0)
                                    };
                                    a.processSpecificDispatchEventFor = function(d) {
                                        a.dispatchEventFor[d] && (a.dispatchEventFor[d] = !1, b--, 0 === b && (a.dispatchEventFor = {}, a.emit("Tracker:Plugin:SpecificEvent:Exec:Complete", {
                                            lvl: "INFO"
                                        })))
                                    };
                                    a.dispatch = function(d) {
                                        var g = function() {
                                                for (var b = "", g = null; 0 < a.dispatchStack.length;) b = a.dispatchStack.pop(), 0 === a.dispatchStack.length && (g = d), a[b].onDispatch(g);
                                                a.dispatchIndex = {};
                                                a.delContext(void 0, "customObject")
                                            },
                                            h = function() {
                                                if (a.plugins.isExecWaitingLazyloading()) a.onTrigger("Tracker:Plugin:Lazyload:Exec:Complete", function() {
                                                    g()
                                                }, !0);
                                                else g()
                                            };
                                        if (0 === b) h();
                                        else a.onTrigger("Tracker:Plugin:SpecificEvent:Exec:Complete", function() {
                                            h()
                                        }, !0)
                                    };
                                    a.dispatchRedirect = function(b) {
                                        var d = !0,
                                            g = null;
                                        b && (b.elem && (b.elem.timeoutonly = !0, a.plugins.exec("TechClicks", "manageClick", [b.elem, b.event], function(a) {
                                            d = a
                                        })), g = b.callback);
                                        a.dispatch(g);
                                        return d
                                    }
                                };
                                window.ATInternet.Tracker.addPlugin("Utils");
                            }).call(window);
                            if (typeof window.ATInternet.onTrackerLoad === 'function') {
                                window.ATInternet.onTrackerLoad();
                            }
                            console.log('chagement manuel du smarttag');
                        }
                        window.sendSmartTagRequest();
                    }
                }
            } catch (e) {
                utag.DB(e)
            }
        }];
        u.send = function(a, b) {
            if (u.ev[a] || u.ev.all !== undefined) {
                var par = [],
                    d, e, f, c = 0;
                for (c = 0; c < u.extend.length; c++) {
                    try {
                        d = u.extend[c](a, b);
                        if (d == false) return
                    } catch (e) {}
                };
                window.trackSmarttagpage();
                window.xt_multc = "";
                window.xt_ordermc = "";
                for (d in utag.loader.GV(u.map)) {
                    if (b[d] !== undefined && b[d] !== "") {
                        e = u.map[d].split(",");
                        for (f = 0; f < e.length; f++) {
                            if (e[f].match(/x[0-9]+/)) {
                                window.xt_multc += '&' + e[f] + '=' + b[d];
                            } else if (e[f].match(/o[0-6]/)) {
                                window.xt_ordermc += '&' + e[f] + '=' + b[d];
                            } else {
                                window[e[f]] = b[d];
                            }
                        }
                    }
                }
                if (window.xt_an === '') {
                    window.xt_an = b._ccustid;
                }
                utag.DB(par);
                par.push('ac=' + window.xt_ac + '&an=' + window.xt_an + window.xt_multc);
                if (b._corder || window.xt_orderid) {
                    if (b._ctax === '') {
                        b._ctax = '0';
                    }
                    if (b._cship === '') {
                        b._cship = '0';
                    }
                    if (window.xt_orderid === undefined || window.xt_orderid === "") {
                        window.xt_orderid = b._corder;
                    }
                    par.push("cmd=" + window.xt_orderid);
                    if (window.xt_newcus === undefined) {
                        window.xt_newcus = "1";
                    }
                    par.push("newcus=" + window.xt_newcus);
                    if (window.xt_roimt === undefined) {
                        window.xt_roimt = b._ctotal;
                    }
                    par.push("roimt=" + window.xt_roimt);
                    if (window.xt_totalTF === undefined) {
                        window.xt_totalTF = b._csubtotal;
                    }
                    par.push("mtht=" + window.xt_totalTF);
                    if (window.xt_totalATI === undefined) {
                        window.xt_totalATI = b._ctotal;
                    }
                    par.push("mtttc=" + window.xt_totalATI);
                    if (window.xt_shipATI === undefined) {
                        window.xt_shipATI = (parseInt(b._cship, 10) + parseInt(b._ctax, 10)).toString();
                    }
                    par.push("fp=" + window.xt_shipATI);
                    if (window.xt_shipTF === undefined) {
                        window.xt_shipTF = b._cship;
                    }
                    par.push("fpht=" + window.xt_shipTF);
                    if (window.xt_tax === undefined) {
                        window.xt_tax = b._ctax;
                    }
                    par.push("tax=" + window.xt_tax);
                    if (window.xt_paym === undefined) {
                        window.xt_paym = "1";
                    }
                    par.push("mp=" + window.xt_paym);
                    if (window.xt_status === undefined) {
                        window.xt_status = "1";
                    }
                    par.push("st=" + window.xt_status);
                    if (window.xt_delivery === undefined) {
                        window.xt_delivery = "1";
                    }
                    par.push("dl=" + window.xt_delivery);
                    if (window.xt_promocode === undefined) {
                        window.xt_promocode = b._cpromo;
                    }
                    par.push("pcd=" + window.xt_promocode);
                    if (window.xt_discountATI === undefined) {
                        window.xt_discountATI = parseInt(b._ctax, 10).toString();
                    }
                    par.push("dsc=" + window.xt_discountATI);
                    if (window.xt_discountTF === undefined) {
                        window.xt_discountTF = "0";
                    }
                    par.push("dscht=" + window.xt_discountTF);
                    if (window.xtidcart === undefined) {
                        window.xtidcart = b['cp.utag_main_ses_id'];
                    }
                    par.push("idcart=" + window.xtidcart + window.xt_ordermc);
                }
                if (window.xttp === 'cart' || (typeof b._cprod != "undefined" && b._cprod.length > 0)) {
                    window.xt_cart = function() {
                        var _cprod = b._cprod ? b._cprod.slice(0) : [];
                        var _ccat = b._ccat ? b._ccat.slice(0) : [];
                        var _cquan = b._cquan ? b._cquan.slice(0) : [];
                        var _cprice = b._cprice ? b._cprice.slice(0) : [];
                        var _cpdisc = b._cpdisc ? b._cpdisc.slice(0) : [];
                        for (var d = 0; d < _cprod.length; d++) {
                            xt_addProduct_v2(_ccat[d], _cprod[d], _cquan[d], _cprice[d], _cprice[d], _cpdisc[d], _cpdisc[d])
                        }
                    };
                }
                if (window.xtparam !== undefined && window.xtparam !== null) {
                    window.xtparam += '&' + par.join(u.qsp_delim);
                } else {
                    window.xtparam = '&' + par.join(u.qsp_delim);
                }
            }
        };
        try {
            utag.o[loader].loader.LOAD(id);
        } catch (e) {
            utag.loader.LOAD(id);
        }
    }('24', 'schibsted.leboncoin-responsive'));
} catch (e) {
    utag.DB(e);
}