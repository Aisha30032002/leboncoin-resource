if (!window['googleNDT_']) {
    window['googleNDT_'] = (new Date()).getTime();
}(function() {
    window.googleAltLoader = 3;
    var sffeData_ = {
        service_host: "www.google.com",
        hash: "16427810514005872862",
        packages: "search",
        module: "ads",
        version: "3",
        m: {
            cei: "17301383",
            ah: true,
            uatm: 500,
            ecfc2: true,
            llrm: 1000,
            lldl: "bS5zZWFycy5jb20=",
            abf: {
                "_enableLazyLoading": true,
                "_fixCtcLinksOnIos": true,
                "_googEnableQup": true,
                "_switchGwsRequestToUseAdsenseDomain": true,
                "_useServerProvidedDomain": true,
                "_waitOnConsentForFirstPartyCookie": true,
                "enableEnhancedTargetingRsonc": true,
                "enableNonblockingSasCookie": true
            },
            mdp: 1800000,
            ssdl: "YXBwc3BvdC5jb20sYmxvZ3Nwb3QuY29tLGJyLmNvbSxjby5jb20sY2xvdWRmcm9udC5uZXQsZXUuY29tLGhvcHRvLm9yZyxpbi5uZXQsdHJhbnNsYXRlLmdvb2csdWsuY29tLHVzLmNvbSx3ZWIuYXBw",
            rsm: 0,
            cdh: ""
        }
    };
    var m;

    function aa(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }
    var ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function ca(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var ea = ca(this);

    function fa(a, b) {
        if (b) a: {
            var c = ea;a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) break a;
                c = c[e]
            }
            a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && ba(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    }
    fa("Symbol", function(a) {
        function b(f) {
            if (this instanceof b) throw new TypeError("Symbol is not a constructor");
            return new c(d + (f || "") + "_" + e++, f)
        }

        function c(f, g) {
            this.Pd = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.Pd
        };
        var d = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            e = 0;
        return b
    });
    fa("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = ea[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ha(aa(this))
                }
            })
        }
        return a
    });

    function ha(a) {
        a = {
            next: a
        };
        a[Symbol.iterator] = function() {
            return this
        };
        return a
    }

    function ia(a) {
        return a.raw = a
    }

    function n(a) {
        var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: aa(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function ka(a) {
        if (!(a instanceof Array)) {
            a = n(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    }
    var la = "function" == typeof Object.create ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        ma;
    if ("function" == typeof Object.setPrototypeOf) ma = Object.setPrototypeOf;
    else {
        var na;
        a: {
            var oa = {
                    a: !0
                },
                pa = {};
            try {
                pa.__proto__ = oa;
                na = pa.a;
                break a
            } catch (a) {}
            na = !1
        }
        ma = na ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var qa = ma;

    function ra(a, b) {
        a.prototype = la(b.prototype);
        a.prototype.constructor = a;
        if (qa) qa(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Gf = b.prototype
    }

    function sa() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }
    fa("Promise", function(a) {
        function b(g) {
            this.B = 0;
            this.Pa = void 0;
            this.ya = [];
            this.td = !1;
            var h = this.cc();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        }

        function c() {
            this.W = null
        }

        function d(g) {
            return g instanceof b ? g : new b(function(h) {
                h(g)
            })
        }
        if (a) return a;
        c.prototype.dd = function(g) {
            if (null == this.W) {
                this.W = [];
                var h = this;
                this.ed(function() {
                    h.Ie()
                })
            }
            this.W.push(g)
        };
        var e = ea.setTimeout;
        c.prototype.ed = function(g) {
            e(g, 0)
        };
        c.prototype.Ie = function() {
            for (; this.W && this.W.length;) {
                var g = this.W;
                this.W = [];
                for (var h =
                        0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.Zd(l)
                    }
                }
            }
            this.W = null
        };
        c.prototype.Zd = function(g) {
            this.ed(function() {
                throw g;
            })
        };
        b.prototype.cc = function() {
            function g(l) {
                return function(q) {
                    k || (k = !0, l.call(h, q))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.rf),
                reject: g(this.Jc)
            }
        };
        b.prototype.rf = function(g) {
            if (g === this) this.Jc(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof b) this.Af(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = null != g;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.qf(g) : this.rd(g)
            }
        };
        b.prototype.qf = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.Jc(k);
                return
            }
            "function" == typeof h ? this.Bf(h, g) : this.rd(g)
        };
        b.prototype.Jc = function(g) {
            this.Hd(2, g)
        };
        b.prototype.rd = function(g) {
            this.Hd(1, g)
        };
        b.prototype.Hd = function(g, h) {
            if (0 != this.B) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.B);
            this.B = g;
            this.Pa = h;
            2 === this.B && this.zf();
            this.Je()
        };
        b.prototype.zf = function() {
            var g = this;
            e(function() {
                if (g.hf()) {
                    var h = ea.console;
                    "undefined" !== typeof h && h.error(g.Pa)
                }
            }, 1)
        };
        b.prototype.hf = function() {
            if (this.td) return !1;
            var g = ea.CustomEvent,
                h = ea.Event,
                k = ea.dispatchEvent;
            if ("undefined" === typeof k) return !0;
            "function" === typeof g ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof h ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = ea.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.Pa;
            return k(g)
        };
        b.prototype.Je = function() {
            if (null != this.ya) {
                for (var g =
                        0; g < this.ya.length; ++g) f.dd(this.ya[g]);
                this.ya = null
            }
        };
        var f = new c;
        b.prototype.Af = function(g) {
            var h = this.cc();
            g.cb(h.resolve, h.reject)
        };
        b.prototype.Bf = function(g, h) {
            var k = this.cc();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        b.prototype.then = function(g, h) {
            function k(p, r) {
                return "function" == typeof p ? function(x) {
                    try {
                        l(p(x))
                    } catch (u) {
                        q(u)
                    }
                } : r
            }
            var l, q, t = new b(function(p, r) {
                l = p;
                q = r
            });
            this.cb(k(g, l), k(h, q));
            return t
        };
        b.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        b.prototype.cb = function(g,
            h) {
            function k() {
                switch (l.B) {
                    case 1:
                        g(l.Pa);
                        break;
                    case 2:
                        h(l.Pa);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.B);
                }
            }
            var l = this;
            null == this.ya ? f.dd(k) : this.ya.push(k);
            this.td = !0
        };
        b.resolve = d;
        b.reject = function(g) {
            return new b(function(h, k) {
                k(g)
            })
        };
        b.race = function(g) {
            return new b(function(h, k) {
                for (var l = n(g), q = l.next(); !q.done; q = l.next()) d(q.value).cb(h, k)
            })
        };
        b.all = function(g) {
            var h = n(g),
                k = h.next();
            return k.done ? d([]) : new b(function(l, q) {
                function t(x) {
                    return function(u) {
                        p[x] = u;
                        r--;
                        0 == r && l(p)
                    }
                }
                var p = [],
                    r = 0;
                do p.push(void 0), r++, d(k.value).cb(t(p.length - 1), q), k = h.next(); while (!k.done)
            })
        };
        return b
    });
    var ta = "function" == typeof Object.assign ? Object.assign : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
        }
        return a
    };
    fa("Object.assign", function(a) {
        return a || ta
    });

    function ua(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    }
    fa("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = ua(this, b, "endsWith");
            b += "";
            void 0 === c && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; 0 < e && 0 < c;)
                if (d[--c] != b[--e]) return !1;
            return 0 >= e
        }
    });
    fa("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    fa("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = ua(this, b, "startsWith");
            b += "";
            var e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });

    function va(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    }
    fa("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return va(this, function(b) {
                return b
            })
        }
    });
    fa("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push(b[d]);
            return c
        }
    });
    fa("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    fa("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    fa("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== ua(this, b, "includes").indexOf(b, c || 0)
        }
    });
    fa("Array.prototype.values", function(a) {
        return a ? a : function() {
            return va(this, function(b, c) {
                return c
            })
        }
    });
    fa("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return "number" === typeof b && isNaN(b)
        }
    });
    fa("Math.imul", function(a) {
        return a ? a : function(b, c) {
            b = Number(b);
            c = Number(c);
            var d = b & 65535,
                e = c & 65535;
            return d * e + ((b >>> 16 & 65535) * e + d * (c >>> 16 & 65535) << 16 >>> 0) | 0
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var v = this || self;

    function wa(a) {
        var b = typeof a;
        b = "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null";
        return "array" == b || "object" == b && "number" == typeof a.length
    }

    function xa(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }

    function ya(a, b) {
        a = a.split(".");
        var c = v;
        a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = b
    }

    function za(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.Gf = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.fg = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    }

    function Aa(a) {
        return a
    };
    var Ba = null,
        Ca = null,
        Da = null,
        Ea = null,
        Fa = null;

    function Ga() {
        var a = {};
        return window.ad_json ? window.ad_json : "undefined" != typeof ad_json && ad_json ? ad_json : a
    }

    function Ha(a) {
        Ba || (Ba = Ga().gd || null);
        return Ba && Ba[a] || {}
    }

    function Ia() {
        this.data = Ha("ff")
    }

    function w() {
        var a = Ca;
        a || (a = new Ia, Ga().gd && (Ca = a));
        return a
    }
    Ia.prototype.P = function() {
        return !!this.data.dlrcp
    };

    function Ka() {
        this.data = Ha("cd")
    }

    function La() {
        var a = Da;
        a || (a = new Ka, Ga().gd && (Da = a));
        return a
    }

    function Ma(a) {
        return a.data.pid || ""
    }
    Ka.prototype.xa = function() {
        return !!this.data.r
    };

    function Na() {
        this.data = Ha("pc")
    }

    function Oa() {
        var a = Ea;
        a || (a = new Na, Ga().gd && (Ea = a));
        return a
    }

    function Pa(a) {
        return !!a.data.cgna
    }

    function Sa() {
        this.data = Ha("dc")
    }

    function Ta() {
        var a = Fa;
        a || (a = new Sa, Ga().gd && (Fa = a));
        return a
    };
    var Ua;

    function Va(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = null;
                c()
            }
        }
    };
    var Wa = Array.prototype.indexOf ? function(a, b) {
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        Xa = Array.prototype.forEach ? function(a, b) {
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        },
        Ya = Array.prototype.filter ? function(a, b) {
            return Array.prototype.filter.call(a,
                b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = [], e = 0, f = "string" === typeof a ? a.split("") : a, g = 0; g < c; g++)
                if (g in f) {
                    var h = f[g];
                    b.call(void 0, h, g, a) && (d[e++] = h)
                }
            return d
        };

    function Za(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function $a(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = d;
        return b
    };
    var ab;

    function bb() {
        if (void 0 === ab) {
            var a = null,
                b = v.trustedTypes;
            if (b && b.createPolicy) try {
                a = b.createPolicy("goog#html", {
                    createHTML: Aa,
                    createScript: Aa,
                    createScriptURL: Aa
                })
            } catch (c) {
                v.console && v.console.error(c.message)
            }
            ab = a
        }
        return ab
    };

    function eb(a) {
        this.Hc = a
    }
    eb.prototype.toString = function() {
        return this.Hc + ""
    };
    eb.prototype.Ia = !0;
    eb.prototype.Ha = function() {
        return this.Hc.toString()
    };

    function fb(a, b) {
        a = gb.exec(hb(a).toString());
        var c = a[3] || "";
        return ib(a[1] + jb("?", a[2] || "", b) + jb("#", c))
    }

    function hb(a) {
        return a instanceof eb && a.constructor === eb ? a.Hc : "type_error:TrustedResourceUrl"
    }
    var gb = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        kb = {};

    function ib(a) {
        var b = bb();
        a = b ? b.createScriptURL(a) : a;
        return new eb(a, kb)
    }

    function jb(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var lb = String.prototype.trim ? function(a) {
            return a.trim()
        } : function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        mb = /&/g,
        nb = /</g,
        ob = />/g,
        pb = /"/g,
        qb = /'/g,
        rb = /\x00/g,
        sb = /[\x00&<>"']/;

    function vb(a) {
        this.Gc = a
    }
    vb.prototype.toString = function() {
        return this.Gc.toString()
    };
    vb.prototype.Ia = !0;
    vb.prototype.Ha = function() {
        return this.Gc.toString()
    };

    function wb(a) {
        return a instanceof vb && a.constructor === vb ? a.Gc : "type_error:SafeUrl"
    }
    var xb = {};

    function yb(a) {
        this.Fc = a;
        this.Ia = !0
    }
    yb.prototype.Ha = function() {
        return this.Fc
    };
    yb.prototype.toString = function() {
        return this.Fc.toString()
    };

    function zb(a) {
        this.Ec = a;
        this.Ia = !0
    }
    zb.prototype.toString = function() {
        return this.Ec.toString()
    };
    zb.prototype.Ha = function() {
        return this.Ec
    };
    var Ab, Bb;
    a: {
        for (var Cb = ["CLOSURE_FLAGS"], Db = v, Eb = 0; Eb < Cb.length; Eb++)
            if (Db = Db[Cb[Eb]], null == Db) {
                Bb = null;
                break a
            }
        Bb = Db
    }
    var Fb = Bb && Bb[610401301];
    Ab = null != Fb ? Fb : !1;

    function Gb() {
        var a = v.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Hb, Ib = v.navigator;
    Hb = Ib ? Ib.userAgentData || null : null;

    function Jb(a) {
        return Ab ? Hb ? Hb.brands.some(function(b) {
            return (b = b.brand) && -1 != b.indexOf(a)
        }) : !1 : !1
    }

    function y(a) {
        return -1 != Gb().indexOf(a)
    };

    function Kb() {
        return Ab ? !!Hb && 0 < Hb.brands.length : !1
    }

    function Lb() {
        return Kb() ? Jb("Chromium") : (y("Chrome") || y("CriOS")) && !(Kb() ? 0 : y("Edge")) || y("Silk")
    };
    var Mb = {};

    function Nb(a) {
        this.Dc = a;
        this.Ia = !0
    }
    Nb.prototype.Ha = function() {
        return this.Dc.toString()
    };
    Nb.prototype.toString = function() {
        return this.Dc.toString()
    };

    function Ob(a) {
        return a instanceof Nb && a.constructor === Nb ? a.Dc : "type_error:SafeHtml"
    }

    function Pb(a) {
        a instanceof Nb || (a = "object" == typeof a && a.Ia ? a.Ha() : String(a), sb.test(a) && (-1 != a.indexOf("&") && (a = a.replace(mb, "&amp;")), -1 != a.indexOf("<") && (a = a.replace(nb, "&lt;")), -1 != a.indexOf(">") && (a = a.replace(ob, "&gt;")), -1 != a.indexOf('"') && (a = a.replace(pb, "&quot;")), -1 != a.indexOf("'") && (a = a.replace(qb, "&#39;")), -1 != a.indexOf("\x00") && (a = a.replace(rb, "&#0;"))), a = Qb(a));
        return a
    }

    function Qb(a) {
        var b = bb();
        a = b ? b.createHTML(a) : a;
        return new Nb(a, Mb)
    }
    var Rb = new Nb(v.trustedTypes && v.trustedTypes.emptyHTML || "", Mb);
    var Sb = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = Ob(Rb);
        return !b.parentElement
    });

    function Tb(a) {
        return decodeURIComponent(a.replace(/\+/g, " "))
    };

    function Ub(a) {
        return function() {
            a.onload = a.onerror = null
        }
    }

    function Vb(a) {
        var b = new Image;
        b.onload = b.onerror = Ub(b);
        b.src = a
    }

    function Wb() {
        return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ Date.now()).toString(36)
    };

    function Zb(a) {
        if (null != a) return a
    }

    function $b() {
        return "object" === typeof sffeData_ ? sffeData_ : {}
    }

    function ac(a, b) {
        b = b || $b();
        return Zb(b[a])
    }

    function bc(a) {
        var b = cc();
        b = b || $b();
        a = b[a];
        return null != a ? a : void 0
    }

    function dc(a, b) {
        b = b || $b();
        return !!b[a]
    }

    function cc() {
        return $b().m || {}
    }

    function z(a) {
        return dc(a, cc().abf)
    };
    var ec = window.navigator ? window.navigator.userAgent : "";

    function fc() {
        var a = gc(hc);
        return -1 !== a ? 67 < a : !0
    }
    var hc = /Firefox\/(\d+)\./,
        ic = /Version\/(\d+)\..*Safari/,
        jc = /Chrome\/(\d+)\./,
        kc = /(?:iPhone|iPod|iPad).*AppleWebKit\/(\d+)(?!.*Version)/;

    function gc(a) {
        a = (a = a.exec(ec)) ? a[1] : "";
        return 0 < a.length && (a = parseInt(a, 10)) ? a : -1
    }

    function lc() {
        return /Chrome|CriOS/i.test(ec)
    }

    function mc() {
        var a = ec.toLowerCase();
        return -1 != a.indexOf("series60") || -1 != a.indexOf("series 60")
    };
    var nc = null;

    function oc() {
        nc || (nc = pc());
        return nc
    }

    function pc() {
        function a(c, d, e, f, g) {
            f = dc("ah", cc()) ? f : g;
            if ("" !== (ac("cdh", cc()) || "")) return f + (ac("cdh", cc()) || "");
            if (z("_switchGwsRequestToUseAdsenseDomain")) return f + e;
            e = z("_switchGwsRequestToUseCookielessDomain");
            g = lc() && z("_switchGwsRequestToUseCookielessDomainChrome");
            return z("_enableMcmExperiment") || e || g ? f + d : f + c
        }
        var b = Zb(v.gwsBase_);
        return b || (b = ac("gws_host")) ? b : (b = ac("service_host")) ? a(b, "afs.googlesyndication.com", "www.adsensecustomsearchads.com", "https://", "//") : a("//www.google.com", "//afs.googlesyndication.com",
            "www.adsensecustomsearchads.com", "https:", "")
    };

    function qc(a) {
        this.M = [];
        this.jc = [];
        a = a.split("#");
        this.od = a[0];
        this.ic = a[1] || "";
        this.xb = 7950
    }

    function A(a, b, c, d) {
        (c || 0 === c || !1 === c) && (d ? a.M : a.jc).push([encodeURIComponent(b), encodeURIComponent("" + c)])
    }

    function rc(a) {
        for (var b = a.od, c = -1 !== a.od.indexOf("?"), d = 0; d < a.jc.length; d++) {
            var e = (c ? "&" : "?") + a.jc[d].join("=");
            e.length + b.length <= a.xb && (b += e, c = !0)
        }
        for (e = d = 0; e < a.M.length; e++) d += a.M[e][0].length;
        d = a.xb - b.length - d - 2 * a.M.length;
        var f = Math.floor(d / a.M.length);
        if (1 <= f)
            for (e = 0; e < a.M.length; e++) {
                var g = a.M[e][1];
                f = g.length > f ? g.substring(0, f) : g;
                b += (c ? "&" : "?") + a.M[e][0] + "=" + f;
                d -= f.length;
                f = Math.floor(d / (a.M.length - e - 1));
                c = !0
            } else
                for (d = 0; d < a.M.length; d++) a.M[d][0].length + 3 + b.length <= a.xb && (b += (c ? "&" : "?") +
                    a.M[d].join("="), c = !0);
        b = b.substring(0, a.xb);
        b = b.replace(/%\w?$/, "");
        0 < a.ic.length && (b += "#" + a.ic);
        return b
    };
    var sc = .01 > Math.random(),
        tc = null;

    function uc(a) {
        this.Oe = Wb;
        this.ia = Vb;
        this.Ic = La().data.qi || "";
        this.Gb = "";
        this.client = a || "unknown"
    }

    function vc() {
        tc || (tc = new uc(null));
        return tc
    }

    function wc(a) {
        var b = z("useCookielessHostForPingback");
        b = ((void 0 === b ? 0 : b) ? "https://afs.googlesyndication.com" : oc()) + "/afs/gen_204";
        b = new qc(b);
        var c = a.client;
        "unknown" === c && Ma(La()) && (c = Ma(La()));
        A(b, "client", c);
        A(b, "output", "uds_ads_only");
        A(b, "zx", a.Oe());
        a.Ic && A(b, "aqid", a.Ic);
        a.Gb && A(b, "psid", a.Gb);
        return b
    }

    function xc(a, b, c) {
        var d = wc(a);
        A(d, "pbt", b);
        A(d, "adbx", c.left);
        A(d, "adby", c.top);
        A(d, "adbh", c.height);
        A(d, "adbw", c.width);
        A(d, "adbah", c.Wa);
        A(d, "adbn", c.he);
        A(d, "eawp", c.Fe);
        A(d, "errv", c.se);
        A(d, "csala", c.df);
        A(d, "lle", c.Mf ? 1 : 0);
        A(d, "ifv", c.We ? 1 : 0);
        A(d, "hpt", c.Pe ? 1 : 0);
        a.ia(rc(d))
    }

    function yc(a, b, c) {
        var d = wc(a);
        A(d, "pbt", "tp");
        A(d, "errm", b);
        A(d, "emsg", c, !0);
        a.ia(rc(d))
    }

    function zc(a, b) {
        var c = wc(a);
        A(c, "pbt", b);
        a.ia(rc(c))
    };
    var Ac = {};

    function Bc() {
        var a = (579967862).toString();
        this.bf = "ads." + Cc;
        this.te = a;
        this.vd = "google.ads.search.Ads: ";
        this.Ne = vc()
    }
    Bc.prototype.log = function(a, b) {
        if (!0 === window.IS_GOOGLE_AFS_IFRAME_ && window.parent == window) return !1;
        a = xa(a) ? a.message : a;
        var c = a + b;
        if (!Ac[c]) {
            Ac[c] = !0;
            c = this.Ne;
            var d = this.bf,
                e = this.te,
                f = wc(c);
            A(f, "pbt", "er");
            A(f, "errt", d);
            A(f, "errv", e);
            A(f, "errm", b);
            A(f, "emsg", a, !0);
            c.ia(rc(f));
            return !0
        }
        return !1
    };

    function B(a, b) {
        return function() {
            var c = Array.prototype.slice.call(arguments, 0) || [];
            try {
                return a.apply(this, c)
            } catch (e) {
                "string" === typeof e && (e = {
                    message: e
                });
                c = e.message;
                var d = -1 == c.indexOf(C.vd);
                d && C.log(e, b);
                throw d ? C.vd + c : c;
            }
        }
    }

    function E(a) {
        return "google.ads.search.Ads: " + a
    }

    function F(a, b) {
        return B(a, b)
    }
    var Dc = ac("packages"),
        Cc = "unknown";
    null != Dc && (Cc = Dc);
    var C = new Bc;
    var Ec;
    a: {
        var Fc = window.parent;
        try {
            Ec = Fc.postMessage ? Fc : Fc.document.postMessage ? Fc.document : null;
            break a
        } catch (a) {}
        Ec = null
    }
    var Gc = Ec,
        Hc = {},
        Ic = F(function() {
            for (var a = n($a(Hc)), b = a.next(); !b.done; b = a.next()) b = b.value, Hc.hasOwnProperty(b) && (Hc[b].jb() || delete Hc[b])
        }, "fsCDI"),
        Jc = !1,
        Lc = F(function() {
            Jc || (Jc = !0, window.setInterval(Ic, 500), window.addEventListener("message", Kc))
        }, "fsIL");

    function Mc(a, b) {
        this.Nc = a;
        this.B = {};
        this.Va = b;
        Hc[this.Nc] = this;
        Lc()
    }

    function Nc(a, b) {
        return a.B.hasOwnProperty(b) ? a.B[b].value : null
    }

    function Oc(a, b) {
        return a.B.hasOwnProperty(b) ? a.B[b].value : null
    }

    function Pc(a, b, c, d) {
        a.B.hasOwnProperty(b) || (a.B[b] = c());
        c = a.B[b];
        c.Rb = d || function() {};
        null != c.value && c.Rb(a, a.Nc, b, c.value)
    }
    Mc.prototype.jb = function() {
        return !!(this.Va && this.Va.parentNode && this.Va.contentWindow)
    };
    var Wc = {};

    function Xc() {
        this.value = null;
        this.Rb = function() {};
        this.qa = !1
    }
    m = Xc.prototype;
    m.sa = function() {};
    m.Sa = function() {};
    m.Na = function() {};
    m.Ga = function() {};
    m.kc = function(a) {
        return this.value == a
    };

    function Yc() {
        Xc.call(this)
    }
    ra(Yc, Xc);
    Yc.prototype.sa = function(a, b) {
        return !!b
    };
    Yc.prototype.Sa = function() {
        return this.value ? "t" : "f"
    };
    Yc.prototype.Na = function(a) {
        return "t" == a
    };
    Yc.prototype.Ga = function() {
        return 0
    };
    Yc.j = function() {
        return new Yc
    };

    function Zc() {
        Xc.call(this)
    }
    ra(Zc, Xc);
    Zc.prototype.sa = function(a, b) {
        var c = parseInt(b, 10);
        a = a + " = " + b;
        if (isNaN(c)) return C.log(a, "sIGVVnn"), null;
        9007199254740991 < c && (C.log(a, "sIGVVtl"), c = 9007199254740991);
        0 > c && (C.log(a, "sIGVVts"), c = 0);
        return c
    };
    Zc.prototype.Sa = function() {
        return this.value + ""
    };
    Zc.prototype.Na = function(a) {
        return parseInt(a, 10)
    };
    Zc.prototype.Ga = function() {
        return 1
    };
    Zc.j = function() {
        return new Zc
    };

    function $c() {
        Xc.call(this)
    }
    ra($c, Xc);
    $c.prototype.sa = function(a, b) {
        return b ? b.toString() : ""
    };
    $c.prototype.Sa = function() {
        return this.value ? encodeURIComponent(this.value) : ""
    };
    $c.prototype.Na = function(a) {
        return Tb(a)
    };
    $c.prototype.Ga = function() {
        return 2
    };
    $c.j = function() {
        return new $c
    };

    function ad() {
        Xc.call(this)
    }
    ra(ad, Xc);
    m = ad.prototype;
    m.sa = function(a, b) {
        return b ? b : null
    };
    m.Sa = function() {
        return this.value ? encodeURIComponent(JSON.stringify(this.value)) : ""
    };
    m.Na = function(a) {
        return a ? JSON.parse(Tb(a)) : null
    };
    m.Ga = function() {
        return 3
    };
    m.kc = function(a) {
        var b = JSON.stringify(this.value);
        a = JSON.stringify(a);
        return b === a
    };
    ad.j = function() {
        return new ad
    };
    var bd = {},
        cd = (bd[0] = Yc.j, bd[1] = Zc.j, bd[2] = $c.j, bd[3] = ad.j, bd);

    function dd(a, b, c) {
        Wc.hasOwnProperty(a) || (Wc[a] = c());
        c = Wc[a];
        a = c.sa(a, b);
        null == a || c.kc(a) || (c.value = a, c.qa = !0)
    }

    function Kc(a) {
        if (a = a || window.event)
            for (var b = n($a(Hc)), c = b.next(); !c.done; c = b.next())
                if (c = Hc[c.value], c.jb() && a.source == c.Va.contentWindow) {
                    if ((a = a.data) && a.split && (a = a.split(","), "FSXDC" == a[0])) {
                        for (b = 1; b < a.length; b++) {
                            var d = a[b].split(":"),
                                e = Tb(d[0]),
                                f = cd[parseInt(d[1], 10)];
                            c.B.hasOwnProperty(e) || (c.B[e] = f());
                            d = c.B[e].Na(d[2]);
                            c.B.hasOwnProperty(e) || (c.B[e] = f());
                            f = c.B[e];
                            d = f.sa(e, d);
                            null != d && f.value != d && (f.value = d, f.qa = !0)
                        }
                        a = n($a(c.B));
                        for (b = a.next(); !b.done; b = a.next()) b = b.value, f = c.B[b], f.qa &&
                            (f.qa = !1, f.Rb(c, c.Nc, b, f.value))
                    }
                    break
                }
    }
    Mc.prototype.jb = B(Mc.prototype.jb, "fsiHVI");
    var ed = F(function() {
        if (Gc) {
            for (var a = [], b = n($a(Wc)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = Wc[c];
                if (d.qa) {
                    var e = d.Sa();
                    a.push([encodeURIComponent(c), d.Ga(), e].join(":"));
                    d.qa = !1
                }
            }
            0 != a.length && Gc.postMessage(["FSXDC"].concat(a).join(","), "*")
        }
    }, "fsSC");

    function fd(a, b) {
        dd(a, b, Zc.j)
    }

    function gd(a, b) {
        dd(a, b, Yc.j)
    };

    function hd(a, b) {
        for (var c = n(Object.keys(b)), d = c.next(); !d.done; d = c.next()) d = d.value, a[d] = {}, Object.assign(a[d], b[d])
    }

    function id(a, b) {
        b = n(b);
        for (var c = b.next(); !c.done; c = b.next()) c = c.value, a.hasOwnProperty(c), a[c].xc = !0
    };

    function jd() {
        var a = kd;
        this.Ma = 8;
        this.La = Math.floor(a)
    }
    jd.prototype.H = function() {
        return this.Ma + "px - " + this.La + "px"
    };
    jd.prototype.D = function(a) {
        a = parseInt(a, 10);
        return isNaN(a) ? null : Math.max(this.Ma, Math.min(this.La, a))
    };
    jd.prototype.G = function(a) {
        return this.D(a)
    };

    function ld(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    }
    m = ld.prototype;
    m.clone = function() {
        return new ld(this.x, this.y)
    };
    m.kc = function(a) {
        return a instanceof ld && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    m.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    m.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    m.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    m.translate = function(a, b) {
        a instanceof ld ? (this.x += a.x, this.y += a.y) : (this.x += Number(a), "number" === typeof b && (this.y += b));
        return this
    };
    m.scale = function(a, b) {
        this.x *= a;
        this.y *= "number" === typeof b ? b : a;
        return this
    };

    function md(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    m = md.prototype;
    m.clone = function() {
        return new md(this.top, this.right, this.bottom, this.left)
    };
    m.contains = function(a) {
        return this && a ? a instanceof md ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    m.expand = function(a, b, c, d) {
        xa(a) ? (this.top -= a.top, this.right += a.right, this.bottom += a.bottom, this.left -= a.left) : (this.top -= a, this.right += Number(b), this.bottom += Number(c), this.left -= Number(d));
        return this
    };
    m.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    m.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    m.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    m.translate = function(a, b) {
        a instanceof ld ? (this.left += a.x, this.right += a.x, this.top += a.y, this.bottom += a.y) : (this.left += a, this.right += a, "number" === typeof b && (this.top += b, this.bottom += b));
        return this
    };
    m.scale = function(a, b) {
        b = "number" === typeof b ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };

    function nd(a) {
        nd[" "](a);
        return a
    }
    nd[" "] = function() {};
    var od = Kb() ? !1 : y("Opera"),
        pd = Kb() ? !1 : y("Trident") || y("MSIE"),
        qd = y("Edge"),
        rd = y("Gecko") && !(-1 != Gb().toLowerCase().indexOf("webkit") && !y("Edge")) && !(y("Trident") || y("MSIE")) && !y("Edge"),
        sd = -1 != Gb().toLowerCase().indexOf("webkit") && !y("Edge");

    function td() {
        var a = v.document;
        return a ? a.documentMode : void 0
    }
    var ud;
    a: {
        var vd = "",
            wd = function() {
                var a = Gb();
                if (rd) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (qd) return /Edge\/([\d\.]+)/.exec(a);
                if (pd) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (sd) return /WebKit\/(\S+)/.exec(a);
                if (od) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();wd && (vd = wd ? wd[1] : "");
        if (pd) {
            var xd = td();
            if (null != xd && xd > parseFloat(vd)) {
                ud = String(xd);
                break a
            }
        }
        ud = vd
    }
    var yd = ud,
        zd;
    if (v.document && pd) {
        var Ad = td();
        zd = Ad ? Ad : parseInt(yd, 10) || void 0
    } else zd = void 0;
    var Bd = zd;

    function Cd(a, b) {
        this.width = a;
        this.height = b
    }
    m = Cd.prototype;
    m.clone = function() {
        return new Cd(this.width, this.height)
    };
    m.aspectRatio = function() {
        return this.width / this.height
    };
    m.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    m.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    m.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    m.scale = function(a, b) {
        this.width *= a;
        this.height *= "number" === typeof b ? b : a;
        return this
    };

    function Dd(a) {
        return a ? new Ed(Fd(a)) : Ua || (Ua = new Ed)
    }

    function Gd(a, b, c) {
        var d = document;
        c = c || d;
        var e = a && "*" != a ? String(a).toUpperCase() : "";
        if (c.querySelectorAll && c.querySelector && (e || b)) return c.querySelectorAll(e + (b ? "." + b : ""));
        if (b && c.getElementsByClassName) {
            a = c.getElementsByClassName(b);
            if (e) {
                c = {};
                for (var f = d = 0, g; g = a[f]; f++) e == g.nodeName && (c[d++] = g);
                c.length = d;
                return c
            }
            return a
        }
        a = c.getElementsByTagName(e || "*");
        if (b) {
            c = {};
            for (f = d = 0; g = a[f]; f++) {
                e = g.className;
                var h;
                if (h = "function" == typeof e.split) h = 0 <= Wa(e.split(/\s+/), b);
                h && (c[d++] = g)
            }
            c.length = d;
            return c
        }
        return a
    }

    function Hd(a) {
        a = a.document;
        a = "CSS1Compat" == a.compatMode ? a.documentElement : a.body;
        return new Cd(a.clientWidth, a.clientHeight)
    }

    function Id(a) {
        return a.scrollingElement ? a.scrollingElement : sd || "CSS1Compat" != a.compatMode ? a.body || a.documentElement : a.documentElement
    }

    function Jd(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!wa(f) || xa(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (xa(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                Xa(g ? Za(f) : f, d)
            }
        }
    }

    function Kd(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function Fd(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    }

    function Ed(a) {
        this.S = a || v.document || document
    }
    m = Ed.prototype;
    m.getElementsByTagName = function(a, b) {
        return (b || this.S).getElementsByTagName(String(a))
    };
    m.createElement = function(a) {
        return Kd(this.S, a)
    };
    m.createTextNode = function(a) {
        return this.S.createTextNode(String(a))
    };
    m.appendChild = function(a, b) {
        a.appendChild(b)
    };
    m.append = function(a, b) {
        Jd(Fd(a), a, arguments)
    };
    m.canHaveChildren = function(a) {
        if (1 != a.nodeType) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    m.removeNode = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    m.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function Ld(a, b) {
        a: {
            var c = Fd(a);
            if (c.defaultView && c.defaultView.getComputedStyle && (c = c.defaultView.getComputedStyle(a, null))) {
                c = c[b] || c.getPropertyValue(b) || "";
                break a
            }
            c = ""
        }
        return c || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    }

    function Md(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function Nd(a) {
        if (pd && !(8 <= Number(Bd))) return a.offsetParent;
        var b = Fd(a),
            c = Ld(a, "position"),
            d = "fixed" == c || "absolute" == c;
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (11 == a.nodeType && a.host && (a = a.host), c = Ld(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" == c || "relative" == c)) return a;
        return null
    }

    function Od(a) {
        var b = Fd(a),
            c = new ld(0, 0);
        var d = b ? Fd(b) : document;
        d = !pd || 9 <= Number(Bd) || "CSS1Compat" == Dd(d).S.compatMode ? d.documentElement : d.body;
        if (a == d) return c;
        a = Md(a);
        d = Dd(b).S;
        b = Id(d);
        d = d.parentWindow || d.defaultView;
        b = pd && d.pageYOffset != b.scrollTop ? new ld(b.scrollLeft, b.scrollTop) : new ld(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }

    function Pd(a) {
        if (1 == a.nodeType) return a = Md(a), new ld(a.left, a.top);
        a = a.changedTouches ? a.changedTouches[0] : a;
        return new ld(a.clientX, a.clientY)
    }

    function Qd(a) {
        var b = Rd;
        if ("none" != Ld(a, "display")) return b(a);
        var c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }

    function Rd(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = sd && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = Md(a), new Cd(a.right - a.left, a.bottom - a.top)) : new Cd(b, c)
    };

    function Sd(a) {
        var b = a.indexOf("#");
        return 0 > b ? a : a.slice(0, b)
    }
    var Td = /#|$/;

    function Ud(a, b) {
        var c = a.search(Td);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return Tb(a.slice(d, -1 !== e ? e : 0))
    };
    var Vd = {},
        Wd = (Vd.ads = 0, Vd.plas = 1, Vd.relatedsearch = 3, Vd),
        Xd = !window.IS_GOOGLE_AFS_IFRAME_ || Oa().data.cglfa ? 8 : 6,
        kd = !window.IS_GOOGLE_AFS_IFRAME_ || Oa().data.cglfa ? 24 : 16,
        Yd = new jd,
        Zd = {
            content: "c",
            query: "q",
            domain: "d"
        };

    function $d(a, b, c) {
        if (!b.g) return c;
        c = b.g.D(c);
        if (null == c && !b.C) throw E(a + " has an invalid value. Valid input values: [" + b.g.H() + "].");
        return c
    }

    function ae(a) {
        return /^(?:(?:slave-\d+(?:-(?:a|b))?)|(?:master-(?:a|b)))-\d+$/.test(a)
    }

    function be(a) {
        return (a = a.match(/slave-(\d+)-/)) ? parseInt(a[1], 10) + 1 : 1
    }

    function ce(a, b, c) {
        for (var d = [], e, f = 0; e = c[f]; f++) e = new qc(e), A(e, a, b), d.push(rc(e));
        return d
    }

    function de(a, b) {
        a = Sd(a);
        if ((a = a.match(new RegExp("[?&]" + b + "=([^&]*)"))) && a[1]) try {
            return Tb(a[1])
        } catch (c) {}
        return null
    }

    function ee(a) {
        a = Sd(a);
        var b = {};
        a.replace(/[?&]+([^=&]+)=?([^&]*)/gi, function(c, d, e) {
            try {
                b[Tb(d)] = Tb(e)
            } catch (f) {}
        });
        return b
    }

    function fe() {
        var a = void 0 === a ? window.location.href : a;
        var b = z("_enableLazyLoading"),
            c = ac("lldl", cc());
        return b && c && (c = new RegExp("(" + atob(c).replace(/,/g, ")|(") + ")"), a.match(c)) ? !1 : !!("IntersectionObserver" in window && b)
    }

    function ge(a, b, c) {
        b = void 0 === b ? 0 : b;
        c = void 0 === c ? null : c;
        var d = new md(0, Infinity, Infinity, 0);
        for (var e = Dd(a), f = e.S.body, g = e.S.documentElement, h = Id(e.S), k = a; k = Nd(k);)
            if (!(pd && 0 == k.clientWidth || sd && 0 == k.clientHeight && k == f) && k != f && k != g && "visible" != Ld(k, "overflow")) {
                var l = Od(k),
                    q = new ld(k.clientLeft, k.clientTop);
                l.x += q.x;
                l.y += q.y;
                d.top = Math.max(d.top, l.y);
                d.right = Math.min(d.right, l.x + k.clientWidth);
                d.bottom = Math.min(d.bottom, l.y + k.clientHeight);
                d.left = Math.max(d.left, l.x)
            }
        f = h.scrollLeft;
        h = h.scrollTop;
        d.left = Math.max(d.left, f);
        d.top = Math.max(d.top, h);
        e = e.S;
        e = Hd(e.parentWindow || e.defaultView || window);
        d.right = Math.min(d.right, f + e.width);
        d.bottom = Math.min(d.bottom, h + e.height);
        d = 0 <= d.top && 0 <= d.left && d.bottom > d.top && d.right > d.left ? d : null;
        e = new ld(a.offsetLeft, a.offsetTop);
        a = Qd(a);
        e = new md(e.y, e.x + a.width, e.y + a.height, e.x);
        null != c && (b = -Math.abs(a.height * c));
        return !!(d && d.left <= e.right + b && e.left <= d.right + b && d.top <= e.bottom + b && e.top <= d.bottom + b)
    }

    function he() {
        return null !== document.getElementById("ssrab")
    };
    var ie = {};

    function je(a) {
        var b = {
                names: [],
                frames: []
            },
            c;
        for (c in ie) {
            var d = ke(c, a);
            null == d ? delete ie[c] : (b.names.push(c), b.frames.push(d))
        }
        return b
    }
    je = B(je, "cFr");

    function ke(a, b) {
        if (le) return le(a, b);
        if (a == b.name) return window;
        try {
            var c = window.parent.frames[a + "|" + window.name];
            if (c) return c
        } catch (d) {}
        try {
            return window.parent.frames[a] || null
        } catch (d) {}
        return null
    }
    ke = B(ke, "gFBN");
    var le = null,
        me = je,
        ne = ke;

    function oe(a, b, c) {
        c = void 0 === c ? [] : c;
        this.frameWidth = a;
        this.frameHeight = b;
        this.Wa = c
    };

    function pe(a, b, c) {
        var d = !1;
        a.addEventListener(b, c);
        a.addEventListener(b, function() {
            d || (a.removeEventListener(b, c), d = !0)
        })
    };

    function qe() {
        var a, b;
        return {
            promise: new Promise(function(c, d) {
                a = c;
                b = d
            }),
            resolve: a,
            reject: b
        }
    }

    function re(a, b) {
        var c = qe();
        a.setTimeout(function() {
            c.resolve(b)
        }, 0);
        return c.promise
    }

    function se(a, b) {
        var c = qe();
        window.setTimeout(function() {
            c.resolve(b)
        }, a);
        return c.promise
    }

    function te(a) {
        var b = [],
            c = 0,
            d = a.length;
        return new Promise(function(e, f) {
            if (d)
                for (var g = {
                        ua: 0
                    }; g.ua < d; g = {
                        ua: g.ua
                    }, g.ua++) Promise.resolve(a[g.ua]).then(function(h) {
                    return function(k) {
                        b[h.ua] = k;
                        c += 1;
                        c === d && e(b)
                    }
                }(g)).catch(function(h) {
                    f(h)
                });
            else e(b)
        })
    };
    var ue = null;

    function ve() {
        if (null != ue) return ue;
        var a = document.createElement("div");
        a.style.width = "1px";
        a.style.height = "1px";
        a.style.border = "1px solid black";
        a.style.padding = "1px";
        a.style.visibility = "hidden";
        document.body.appendChild(a);
        var b = a.offsetWidth;
        document.body.removeChild(a);
        return ue = 5 == b
    }

    function we(a) {
        return parseFloat(a.replace("px", "")) || 0
    }

    function xe(a, b) {
        var c = b ? a.offsetHeight : a.offsetWidth;
        b = b ? ["Top", "Bottom"] : ["Right", "Left"];
        var d = !1;
        var e = ve() ? ["margin"] : ["border", "margin", "padding"];
        var f = e.length,
            g = b.length,
            h = document.defaultView;
        if (h && h.getComputedStyle && (h = h.getComputedStyle(a))) {
            d = !0;
            for (var k = 0; k < f; k++)
                for (var l = 0; l < g; l++) c += we(h.getPropertyValue([e[k], b[l].toLowerCase()].join("-")))
        }
        if (!d && (a = a.currentStyle)) {
            if (!ve())
                for (d = 0; d < g; d++) c += we(a[["border", b[d], "Width"].join("")]);
            for (d = 0; d < f; d++)
                if ("border" != e[d])
                    for (h = 0; h <
                        g; h++) c += we(a[[e[d], b[h]].join("")])
        }
        return c
    };

    function ye(a) {
        if (ze) return ze(a);
        var b = me(a);
        if (w().data.eiell) Ae(b);
        else return De(b.frames).then(function() {
            Ae(b)
        })
    }
    ye = B(ye, "sPH");
    var ze = null;

    function Ee(a) {
        try {
            return xe(a.document.documentElement, !0)
        } catch (b) {
            return null
        }
    }
    Ee = B(Ee, "gBH");

    function Fe(a) {
        try {
            var b = a.document.getElementById("adBlock");
            return xe(b, !1)
        } catch (c) {
            return null
        }
    }
    Fe = B(Fe, "gBW");

    function Ge(a) {
        var b = [];
        a = n(a.document.getElementsByTagName("img"));
        for (var c = a.next(); !c.done; c = a.next()) {
            var d = b,
                e = d.push;
            c = c.value;
            var f = qe();
            c.complete ? f.resolve() : (pe(c, "load", f.resolve), pe(c, "error", f.resolve));
            e.call(d, f.promise)
        }
        return te(b)
    }
    Ge = B(Ge, "gFH_wfip");

    function Ae(a) {
        for (var b = 0; b < a.frames.length; b++) {
            var c = a.frames[b];
            if (z("_optimizeFrameMeasurement")) {
                var d = c.document.documentElement;
                d = new Cd(d.offsetWidth, d.offsetHeight);
                c = He(c);
                c = new oe(d.width, d.height, c)
            } else {
                d = Ee(c);
                var e = Fe(c);
                Ie(c, d, e) ? c = new oe(1, 1) : (c = He(c), c = new oe(e, d, c))
            }
            d = {};
            c = (d.fw = c.frameWidth, d.fh = c.frameHeight, d.ah = c.Wa, d);
            dd(a.names[b] + ".fs", c, ad.j)
        }
        ed()
    }

    function De(a) {
        for (var b = [], c = 0; c < a.length; c++) b.push(Ge(a[c]));
        return Promise.race([Promise.all(b), se(500, "timedOutWaitingForImages")])
    }
    De = B(De, "gFH");
    var He = F(function(a) {
        var b = [];
        a = n(z("_enableUnifiedMudskipperIframe") ? a.document.querySelectorAll(".clicktrackedAd_js") : a.document.querySelectorAll(".si101"));
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, c = z("_optimizeFrameMeasurement") ? (new Cd(c.offsetWidth, c.offsetHeight)).height : xe(c, !0), b.push(c);
        return b
    }, "gAHIF");

    function Ie(a, b, c) {
        return ("number" == typeof b && 16 > b || "number" == typeof c && 16 > c) && (a = a.document.getElementById("adBlock")) && "" != a.innerHTML ? !0 : !1
    }
    Ie = B(Ie, "iCSI");
    var Je = ye;
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    var Ke = "function" === typeof URL;

    function Le(a) {
        if (a instanceof vb) a = wb(a);
        else {
            b: if (Ke) {
                try {
                    var b = new URL(a)
                } catch (c) {
                    b = "https:";
                    break b
                }
                b = b.protocol
            } else c: {
                b = document.createElement("a");
                try {
                    b.href = a
                } catch (c) {
                    b = void 0;
                    break c
                }
                b = b.protocol;b = ":" === b || "" === b ? "https:" : b
            }
            a = "javascript:" !== b ? a : void 0
        }
        return a
    };

    function Me(a) {
        var b = sa.apply(1, arguments);
        if (0 === b.length) return ib(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return ib(c)
    };

    function Ne(a, b) {
        b = b[a];
        b || (C.log("frameOptions is undefined for " + a, "fAU"), b = {});
        return b
    }
    Ne = B(Ne, "gFO");

    function Oe(a) {
        return function(b, c) {
            return "undefined" == typeof a[b] ? c || null : a[b]
        }
    }

    function Pe(a) {
        return function(b, c) {
            if (a.hasOwnProperty(b)) {
                b = a[b].split(",");
                for (var d = 0; d < b.length; d++)
                    if (b[d] == c) return !0;
                return !1
            }
            return !0
        }
    }

    function Qe(a) {
        return (a = a.width) && "auto" != a ? a : "100%"
    }

    function Re(a) {
        var b = {
            ta: !1,
            Yc: null,
            hd: null
        };
        a.verticalSpacing && (a = a.verticalSpacing / 2, b.ta = !0, b.Yc = Math.floor(a), b.hd = Math.ceil(a));
        return b
    }

    function Se(a) {
        if (a.fontSizeTitle) return a.fontSizeTitle;
        a = Ta();
        return a.data.hm || a.data.t ? 18 : null
    }
    var Te = Ne;
    !y("Android") || Lb();
    Lb();
    y("Safari") && (Lb() || (Kb() ? 0 : y("Coast")) || (Kb() ? 0 : y("Opera")) || (Kb() ? 0 : y("Edge")) || (Kb() ? Jb("Microsoft Edge") : y("Edg/")) || Kb() && Jb("Opera"));
    Math.max.apply(Math, ka(Object.values({
        Vf: 1,
        Tf: 2,
        Sf: 4,
        Yf: 8,
        Xf: 16,
        Wf: 32,
        Nf: 64,
        ag: 128,
        Rf: 256,
        Qf: 512,
        Uf: 1024,
        Of: 2048,
        Zf: 4096,
        Pf: 8192
    })));
    Object.freeze({});
    var Ue = /<[^>]*>|&[^;]+;/g;

    function Ve(a, b) {
        return b ? a.replace(Ue, "") : a
    }
    var We = RegExp("[A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]"),
        Xe = RegExp("^[^A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]*[\u0591-\u06ef\u06fa-\u08ff\u200f\ud802-\ud803\ud83a-\ud83b\ufb1d-\ufdff\ufe70-\ufefc]"),
        Ye = /^http:\/\/.*/,
        Ze = /\s+/,
        $e = /[\d\u06f0-\u06f9]/;
    var af = {},
        bf = {},
        cf = {},
        df = {},
        ef = {};

    function ff() {
        throw Error("Do not instantiate directly");
    }
    ff.prototype.R = null;
    ff.prototype.toString = function() {
        return this.content
    };
    ff.prototype.Jd = function() {
        if (this.N !== af) throw Error("Sanitized content was not of kind HTML.");
        return Qb(this.toString())
    };

    function gf() {
        ff.call(this)
    }
    za(gf, ff);
    gf.prototype.N = af;

    function hf() {
        ff.call(this)
    }
    za(hf, ff);
    hf.prototype.N = bf;
    hf.prototype.R = 1;

    function jf() {
        ff.call(this)
    }
    za(jf, ff);
    jf.prototype.N = cf;
    jf.prototype.R = 1;

    function kf() {
        ff.call(this)
    }
    za(kf, ff);
    kf.prototype.N = df;
    kf.prototype.R = 1;

    function lf() {
        ff.call(this)
    }
    za(lf, ff);
    lf.prototype.N = ef;
    lf.prototype.R = 1;

    function mf(a, b) {
        return null != a && a.N === b
    };

    function nf(a) {
        if (null != a) switch (a.R) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function of (a) {
        return mf(a, af) ? a : a instanceof Nb ? G(Ob(a).toString()) : G(String(String(a)).replace(pf, qf), nf(a))
    }

    function rf(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c) {
            return new b(String(c))
        }
    }
    var G = function(a) {
            function b(c) {
                this.content = c
            }
            b.prototype = a.prototype;
            return function(c, d) {
                c = new b(String(c));
                void 0 !== d && (c.R = d);
                return c
            }
        }(gf),
        sf = rf(kf),
        tf = rf(lf);

    function uf(a) {
        var b = [],
            c;
        for (c in a) b.push(c);
        return b
    }

    function vf(a) {
        if (null == a) throw Error("unexpected null value");
        return a
    }

    function H(a, b) {
        return a && b && a.Xe && b.Xe ? a.N !== b.N ? !1 : a.toString() === b.toString() : a instanceof ff && b instanceof ff ? a.N != b.N ? !1 : a.toString() == b.toString() : a == b
    }

    function I(a) {
        return a instanceof ff ? !!a.content : !!a
    }

    function wf(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c) {
            return (c = String(c)) ? new b(c) : ""
        }
    }
    var xf = function(a) {
            function b(c) {
                this.content = c
            }
            b.prototype = a.prototype;
            return function(c, d) {
                c = String(c);
                if (!c) return "";
                c = new b(c);
                void 0 !== d && (c.R = d);
                return c
            }
        }(gf),
        yf = wf(jf),
        zf = wf(hf),
        Af = wf(kf),
        Bf = wf(lf);

    function Cf(a) {
        return a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>")
    }

    function J(a) {
        if (mf(a, af)) {
            var b = String;
            a = String(a.content).replace(Df, "").replace(Ef, "&lt;");
            b = b(a).replace(Ff, qf)
        } else b = String(a).replace(pf, qf);
        return b
    }

    function Gf(a) {
        mf(a, df) ? a = a.content : (a = String(a), a = Hf.test(a) ? a : "zSoyz");
        return a
    }

    function If(a) {
        mf(a, df) && (a = a.content);
        return (a && !a.startsWith(" ") ? " " : "") + a
    }

    function Jf(a) {
        mf(a, bf) || mf(a, cf) ? a = Kf(a) : a instanceof vb ? a = Kf(wb(a)) : a instanceof eb ? a = Kf(hb(a).toString()) : (a = String(a), a = Lf.test(a) ? a.replace(Mf, Nf) : "about:invalid#zSoyz");
        return a
    }

    function Of(a) {
        mf(a, bf) || mf(a, cf) ? a = Kf(a) : a instanceof vb ? a = Kf(wb(a)) : a instanceof eb ? a = Kf(hb(a).toString()) : (a = String(a), a = Pf.test(a) ? a.replace(Mf, Nf) : "about:invalid#zSoyz");
        return a
    }

    function K(a) {
        mf(a, ef) ? a = Cf(a.content) : null == a ? a = "" : a instanceof yb ? a = Cf(a instanceof yb && a.constructor === yb ? a.Fc : "type_error:SafeStyle") : a instanceof zb ? a = Cf(a instanceof zb && a.constructor === zb ? a.Ec : "type_error:SafeStyleSheet") : (a = String(a), a = Qf.test(a) ? a : "zSoyz");
        return a
    }
    var Rf = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\v": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    };

    function qf(a) {
        return Rf[a]
    }
    var Sf = {
        "\x00": "\\0 ",
        "\b": "\\8 ",
        "\t": "\\9 ",
        "\n": "\\a ",
        "\v": "\\b ",
        "\f": "\\c ",
        "\r": "\\d ",
        '"': "\\22 ",
        "&": "\\26 ",
        "'": "\\27 ",
        "(": "\\28 ",
        ")": "\\29 ",
        "*": "\\2a ",
        "/": "\\2f ",
        ":": "\\3a ",
        ";": "\\3b ",
        "<": "\\3c ",
        "=": "\\3d ",
        ">": "\\3e ",
        "@": "\\40 ",
        "\\": "\\5c ",
        "{": "\\7b ",
        "}": "\\7d ",
        "\u0085": "\\85 ",
        "\u00a0": "\\a0 ",
        "\u2028": "\\2028 ",
        "\u2029": "\\2029 "
    };

    function Tf(a) {
        return Sf[a]
    }
    var Uf = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\v": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    };

    function Nf(a) {
        return Uf[a]
    }
    var pf = /[\x00\x22\x26\x27\x3c\x3e]/g,
        Ff = /[\x00\x22\x27\x3c\x3e]/g,
        Vf = /[\x00\x08-\x0d\x22\x26-\x2a\/\x3a-\x3e@\\\x7b\x7d\x85\xa0\u2028\u2029]/g,
        Mf = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        Qf = /^(?!-*(?:expression|(?:moz-)?binding))(?:(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|(?:calc|cubic-bezier|drop-shadow|hsl|hsla|hue-rotate|invert|linear-gradient|max|min|rgb|rgba|rotate|rotateZ|translate|translate3d|translateX|translateY|var)\((?:[-\u0020\t,+.!#%_0-9a-zA-Z]|(?:calc|cubic-bezier|drop-shadow|hsl|hsla|hue-rotate|invert|linear-gradient|max|min|rgb|rgba|rotate|rotateZ|translate|translate3d|translateX|translateY|var)\([-\u0020\t,+.!#%_0-9a-zA-Z]+\))+\)|[-+]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:e-?[0-9]+)?(?:[a-z]{1,4}|%)?|!important)(?:\s*[,\u0020]\s*|$))*$/i,
        Lf =
        /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i,
        Pf = /^[^&:\/?#]*(?:[\/?#]|$)|^https?:|^ftp:|^data:image\/[a-z0-9+-]+;base64,[a-z0-9+\/]+=*$|^blob:/i,
        Hf = /^(?!on|src|(?:action|archive|background|cite|classid|codebase|content|data|dsync|href|http-equiv|longdesc|style|usemap)\s*$)(?:[a-z0-9_$:-]*)$/i;

    function Kf(a) {
        return String(a).replace(Mf, Nf)
    }
    var Df = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
        Ef = /</g;
    /*
     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    function Wf(a, b) {
        b = b || Dd();
        if (a && a.Kc) b = a.Kc();
        else {
            b = b.createElement("DIV");
            a: if (xa(a)) {
                if (a.Jd && (a = a.Jd(), a instanceof Nb)) {
                    var c = a;
                    break a
                }
                c = Pb("zSoyz")
            } else c = Pb(String(a));
            a = b;
            if (Sb())
                for (; a.lastChild;) a.removeChild(a.lastChild);
            a.innerHTML = Ob(c)
        }
        return 1 == b.childNodes.length && (a = b.firstChild, 1 == a.nodeType) ? a : b
    }
    var Xf = {};

    function Yf(a) {
        var b = a.xa,
            c = a.Ve,
            d = a.Ze,
            e = a.je,
            f = a.Lf,
            g = a.Xd,
            h = a.xe,
            k = a.ye,
            l = a.ve,
            q = a.we,
            t = a.ue,
            p = a.fontFamily,
            r = a.Ke,
            x = a.Me,
            u = a.Le,
            D = a.Hf,
            L = a.If,
            da = a.vf,
            Z = a.wf,
            Ja = a.uf,
            cb = a.xf,
            Qa = a.tf,
            W = a.gf,
            X = a.Qd,
            Qc = a.de,
            Xb = a.ee,
            Yb = a.ge,
            Rc = a.ce,
            M = a.Wd,
            tb = a.Rd,
            T = a.Sd,
            U = a.Ud,
            ja = a.Td,
            Sc = a.Vd,
            Tc = a.ef,
            Uc = a.og,
            Be = a.pg,
            Ng = a.be,
            ub = a.type,
            Ra = a.ze,
            Vc = a.Re,
            db = a.Qe,
            Ce = a.Ue,
            Og = a.re,
            vj = a.qe;
        a = a.P;
        var wj = f.ta ? "padding-top:" + K(f.Yc) + "px; padding-bottom:" + K(f.hd) + "px;" : c || d ? "padding:7px 0;" : "";
        var xj = u ? K(u) : d ? "15" : "13";
        e = "<style>#response_debug_output{max-height:500px; overflow:auto;}body{" +
            (c ? "-webkit-text-size-adjust:100%;" : "") + "color:" + (h ? K(h) : "#000") + "; font-family:" + (Uc ? "'" + String(Uc).replace(Vf, Tf) + "'," : "") + (p ? K(p) : "arial") + ", sans-serif; font-size:" + (c || d ? "14" : "12") + "px; width:" + K(e) + "; padding:0px; margin:0px;" + (I(q) && (I(Xb) || I(X)) ? "padding-right:2px;" : "") + (Ce && b ? "direction:rtl;" : "") + "}body{-webkit-tap-highlight-color:rgba(0,0,0,0); -webkit-tap-highlight-color:transparent;}a{-webkit-tap-highlight-color:initial;}.ad{padding:2px 0; margin:0px; word-wrap:break-word;" + wj + (g ? "border-bottom:1px solid " +
                K(g) + ";" : "") + "}" + (I(Qa) && (!Ce || I(ub) && "relatedsearch" == ub) ? "." + K("a_") + ":hover{background-color:" + K(Qa) + ";}" : "") + ".ad.f{" + (f.ta ? "padding-top:2px;" : "") + "}.ad.fr{" + (f.ta ? "padding-top:2px;" : "") + "}.ad.l{" + (f.ta ? "padding-bottom:2px;" : "") + (g ? "border-bottom:0px;" : "") + "}.ad.lr{" + (f.ta ? "padding-bottom:2px;" : "") + "}#adBlock b{" + (vj || Ce ? "" : "font-weight:normal;") + "}.ad span{_width:99%;}#adBlock{background:#FFF none repeat scroll 0 0; margin:0; padding:0;" + (l ? "background-color:" + K(l) + ";" : "") + (I(q) && I(Qc) ? "border-left:1px solid " +
                K(q) + ";" : "") + (I(q) && I(Xb) ? "border-right:1px solid " + K(q) + ";" : "") + (I(q) && I(Yb) ? "border-top:1px solid " + K(q) + ";" : "") + (I(q) && I(Rc) ? "border-bottom:1px solid " + K(q) + ";" : "") + "}#adBlock h2{font-size:" + xj + "px; font-weight:normal;" + (Ng ? "padding-bottom:" + K(Ng) + "px;" : "padding:0;") + "margin:0;" + (I(r) || I(Be) ? "font-family:" + (Be ? "'" + String(Be).replace(Vf, Tf) + "'," : "") + (r ? K(r) + "," : "") + " sans-serif;" : "") + "}#adBlock span.lhHeader{margin:3px 4px 0;}#adBlock h2 a, #adBlock h2{color:" + (t ? K(t) : "#676767") + "; text-decoration:none;}." +
            K("c_") + "{color:" + K(k) + ";}." + K("c_") + "{" + (x ? "font-size:" + K(x) + "px;" : "") + "font-weight:" + (D ? "bold" : "normal") + ";}." + K("c_") + "{" + (L ? "display:inline-block;" : "") + "line-height:" + (Tc ? K(Tc) + "px" : "1.4em") + ";" + (W ? "text-decoration:none;" : "") + "margin:0; padding:0;}" + (cb ? "." + K("c_") + ":hover {text-decoration:underline;}a{text-decoration:none;}" : "") + "h2 a:hover{color:" + (t ? K(t) : "#676767") + "; text-decoration:none; font-weight:normal; background-color:transparent;}a:hover{" + (da ? "font-weight:bold;" : "") + (Z ? "color:" + K(Z) +
                ";" : "") + (Ja ? "background-color:" + K(Ja) + ";" : "") + "}";
        f = b ? "right" : "left";
        b = b ? "left" : "right";
        I(ub) && "relatedsearch" == ub && !a ? (ub = db ? "text-align:" + ("right" == f && "left" == db ? "right" : "right" == f && "right" == db ? "left" : K(db)) + ";" : "", Ra = Ra ? I(Vc) && I(db) ? "center" == db ? "padding-right:" + K(Math.floor(Ra / 2)) + "px; padding-left:" + K(Math.floor(Ra / 2)) + "px;" : "right" == db ? "padding-" + K(f) + ":" + K(Ra) + "px;" : "padding-" + K(b) + ":" + K(Ra) + "px;" : "padding-right:" + K(Ra) + "px;" : "", g = ".radlinkC{" + (I(Vc) && x < u ? "padding:" + K(1 + (u - x)) + "px 4px;" : "padding:1px 4px;") +
            "word-break:break-word;}.col{" + ub + (Vc ? "border-" + K(b) + ":1px solid " + K(g) + ";" : "") + "vertical-align:top;" + Ra + "}" + (Vc ? "#adBlock h2{float:" + K(f) + "; line-height:1.4em; vertical-align:top;" + (x >= u ? "padding:" + K(3 + (x - u)) + "px 4px;" : "padding:3px 4px;") + "}.ad{border-bottom:none;}.col.l{border-" + K(b) + ":none;}" : "#adBlock h2{text-align:" + K(f) + ";}")) : g = "";
        U = (I(M) && I(tb) && Og ? ".adIcon{visibility:visible; width:" + K(M) + "px; height:" + K(tb) + "px; border:none; float:" + K(f) + "; margin-" + K(f) + ":" + K(null != U ? U : 0) + "px; margin-" +
            K(b) + ":" + K(null != ja ? ja : 4) + "px; margin-top:" + K(null != T ? T : 4) + "px; margin-bottom:" + K(null != Sc ? Sc : 0) + "px;}.adD, ." + K("a_") + "{display:block; overflow:hidden;}" : "") + (c ? ".adD{clear:" + K(b) + ";}" : "") + g;
        c = c || d ? tf("body{font-family:" + (Uc ? "'" + String(Uc).replace(Vf, Tf) + "'," : "") + (p ? K(p) + "," : "") + '"Roboto","Helvetica Neue",arial,sans-serif;}.ad{margin:0; padding:0;}.' + K("c_") + "{line-height:" + (Tc ? K(Tc) : "20") + "px; margin:0;}td{padding:0px;}.adStd{clear:none;}" + (I(M) && I(tb) && I(Og) ? ".adIcon{margin-top:" + K(null != T ? T : 0) +
            "px; margin-bottom:" + K(null != Sc ? Sc : 0) + "px; margin-" + K(f) + ":0px;}" : "") + ".adStd{clear:none;}") : "";
        return G(e + (U + c + "</style>"))
    };

    function Zf(a) {
        return a ? a : Ta().data.hm || Ta().data.t ? "#bdbdbd" : null
    }

    function $f(a, b) {
        function c(l) {
            return (l = d(l)) ? tf(l) : void 0
        }
        var d = Oe(b),
            e = Pe(b),
            f = d("type") || "ads",
            g = Oa(),
            h = Ta(),
            k = "#0000CC";
        if (h.data.hm || h.data.t) k = "#1a0dab";
        k = d("colorTitleLink", k);
        b = {
            xa: La().xa(),
            je: Qe(b),
            Lf: Re(b),
            Xd: Zf(d("colorAdSeparator")),
            hg: 20,
            xe: d("colorText"),
            ye: k,
            ve: d("colorBackground"),
            we: d("colorBorder"),
            ue: d("colorAttribution"),
            fontFamily: c("fontFamily"),
            Ke: c("fontFamilyAttribution"),
            Me: Se(b) || d("fontSizeTitle"),
            Le: d("fontSizeAttribution"),
            Hf: d("titleBold"),
            If: !h.data.hm,
            vf: d("rolloverLinkBold"),
            wf: d("rolloverLinkColor"),
            uf: d("rolloverLinkBackgroundColor"),
            xf: d("rolloverLinkUnderline"),
            tf: d("rolloverAdBackgroundColor"),
            gf: d("noTitleUnderline"),
            dg: e("adBorderSelections", "left"),
            Qd: e("adBorderSelections", "right"),
            eg: e("adBorderSelections", "top"),
            cg: e("adBorderSelections", "bottom"),
            de: e("borderSelections", "left"),
            ee: e("borderSelections", "right"),
            ge: e("borderSelections", "top"),
            ce: e("borderSelections", "bottom"),
            ef: d("lineHeightTitle"),
            be: d("attributionSpacingBelow"),
            Ue: !1,
            Ve: !!h.data.hm,
            Ze: !!h.data.t,
            re: !!g.data.cucai,
            qe: !!g.data.cgab,
            P: w().P()
        };
        d("adIconUrl") && !w().P() && (b.Wd = d("adIconWidth"), b.Rd = d("adIconHeight"), b.Sd = d("adIconSpacingAbove"), b.Ud = d("adIconSpacingBefore"), b.Td = d("adIconSpacingAfter"), b.Vd = d("adIconSpacingBelow"));
        "relatedsearch" !== f || w().P() || (b.type = "relatedsearch", b.ze = d("columnSpacing"), b.Re = d("horizontalFlow"), b.Qe = d("horizontalAlignment"));
        f = Yf(b);
        ag(f, a)
    }

    function ag(a, b) {
        b.appendChild(Wf(a))
    };
    var bg = /^((https?):)?\/\/afs.googleusercontent.com\//;

    function cg(a, b, c) {
        if (bg.test(b))
            for (b.startsWith("http:") && c ? b = "https:" + b.substring(5) : b.startsWith("//") && (b = (c ? "https:" : "") + b), c = 0; c < a.length; c++) a[c].adIconUrl = b
    }
    var dg = cg = B(cg, "aiIID");

    function eg() {};

    function fg(a, b) {
        a.addEventListener("click", function(c) {
            2 !== c.button && b(c)
        })
    };

    function gg(a) {
        var b = "https" == window.location.protocol;
        a = a.clicktrackUrl;
        return Oa().data.ct && wa(a) ? Ya(a, function(c) {
            return !(0 == c.indexOf("http:") && b)
        }) : []
    }

    function hg(a, b) {
        a = a.getElementsByTagName("a");
        for (var c = 0; c < a.length; c++) {
            var d = a[c];
            (d.hasAttribute ? d.hasAttribute("data-notrack") : d.getAttribute("data-notrack")) || fg(d, function() {
                for (var e = [], f = n(b), g = f.next(); !g.done; g = f.next()) g = new qc(g.value), A(g, "nc", [Math.round(9E6 * Math.random()), (new Date).getTime()].join("")), e.push(rc(g));
                if (window.navigator.sendBeacon)
                    for (e = n(e), g = e.next(); !g.done; g = e.next()) window.navigator.sendBeacon(g.value);
                else
                    for (e = n(e), f = e.next(); !f.done; f = e.next()) Vb(f.value)
            })
        }
    }

    function ig(a, b, c) {
        if (Oa().data.ct && (a = gg(a), 0 < a.length))
            if (Oa().data.alct) {
                c = ce("block", "" + c, a);
                var d = he() ? "clicktrackedAd_js" : "b_";
                a = Za(Gd("div", d, b));
                a = a.concat(Za(Gd("tr", d, b)));
                a = a.concat(Za(Gd("li", d, b)));
                var e;
                for (b = 0; e = a[b]; b++) d = c, d = ce("ad", "" + (b + 1), d), hg(e, d)
            } else hg(b, a)
    };
    var jg = F(function(a, b) {
        var c = a.resultsPageBaseUrl,
            d = a.resultsPageQueryParam,
            e = b[0] && b[0].adtype;
        b = n(b);
        for (var f = b.next(); !f.done; f = b.next()) {
            f = f.value;
            e && (f = f[e]);
            var g = f.st,
                h = f.afdt;
            if (null != g && null != h) {
                if (!c) throw E("resultsPageBaseUrl needs to be set.");
                var k = new qc(c);
                A(k, d, g);
                A(k, "rsToken", h);
                null != a.personalizedAds && A(k, "pcsa", "" + a.personalizedAds);
                f.l = rc(k);
                f.u = rc(k)
            }
        }
    }, "fRSCL");

    function kg() {
        var a = {
            Kf: !!w().data.esrs
        };
        a = a || {};
        var b = a.Kf;
        return G("<style" + (a.kg ? ' data-permanent="true"' : "") + ">body{-webkit-text-size-adjust:100%; font-family:arial,sans-serif; margin:0;}div{" + lg(0) + "max-width:100%;}span:last-child, div:last-child{" + lg(1) + "}." + K("x_") + "{" + lg(1) + "}." + K("j_") + ">span:last-child, ." + K("j_") + ">div:last-child, ." + K("y_") + ", ." + K("y_") + ":last-child{" + lg(0) + "}." + K("l_") + "{-ms-overflow-style:none; scrollbar-width:none;}." + K("l_") + "::-webkit-scrollbar{display:none;}a{text-decoration:none; text-transform:none; color:inherit; display:inline-block;}span{" +
            lg(0) + "display:inline-block; overflow:hidden; text-transform:none;}img{border:none; max-width:100%; max-height:100%;}." + K("i_") + "{display:-ms-flexbox; display:-webkit-box; display:-webkit-flex; display:flex;" + mg("flex-start") + "box-sizing:border-box; overflow:hidden;}." + K("u_") + "{position:relative; display:inline-block;" + (b ? "width:100%; height:100%;" : "") + "}." + K("w_") + "{position:absolute; top:0; left:0; height:100%;" + (b ? "background-repeat:repeat-x;" : "background-repeat:no-repeat; background-size:auto 100%;") +
            "}." + K("v_") + "{display:block;" + (b ? "height:100%; background-size:20% 100%; background-repeat:repeat-x;" : "") + "}." + K("t_") + "{" + ng() + "}." + K("q_") + "{box-sizing:border-box; max-width:100%; max-height:100%; overflow:hidden;" + ng() + "}." + K("n_") + "{-ms-flex-negative:1; text-overflow:ellipsis; white-space:nowrap;}." + K("p_") + "{-ms-flex-negative:1; max-width: 100%;}." + K("m_") + "{overflow:hidden;}." + K("o_") + "{white-space:nowrap;}." + K("z_") + "{cursor:pointer;}." + K("aa_") + "{display:none; position:absolute; z-index:1;}." +
            K("k_") + ">div:not(." + K("aa_") + ") {display:-webkit-inline-box; display:-moz-inline-box; display:-ms-inline-flexbox; display:-webkit-inline-flex; display:inline-flex; vertical-align:middle;}." + K("k_") + ".topAlign>div{vertical-align:top;}." + K("k_") + ".centerAlign>div{vertical-align:middle;}." + K("k_") + ".bottomAlign>div{vertical-align:bottom;}." + K("k_") + ">span, ." + K("k_") + ">a, ." + K("k_") + ">img, ." + K("k_") + "{display:inline; vertical-align:middle;}.si101:nth-of-type(5n+1) > .si141{border-left: #1f8a70 7px solid;}.rssAttrContainer ~ .si101:nth-of-type(5n+2) > .si141{border-left: #1f8a70 7px solid;}.si101:nth-of-type(5n+3) > .si141{border-left: #bedb39 7px solid;}.rssAttrContainer ~ .si101:nth-of-type(5n+4) > .si141{border-left: #bedb39 7px solid;}.si101:nth-of-type(5n+5) > .si141{border-left: #ffe11a 7px solid;}.rssAttrContainer ~ .si101:nth-of-type(5n+6) > .si141{border-left: #ffe11a 7px solid}.si101:nth-of-type(5n+2) > .si141{border-left: #fd7400 7px solid;}.rssAttrContainer ~ .si101:nth-of-type(5n+3) > .si141{border-left: #fd7400 7px solid;}.si101:nth-of-type(5n+4) > .si141{border-left: #004358 7px solid;}.rssAttrContainer ~ .si101:nth-of-type(5n+5) > .si141{border-left: #004358 7px solid;}." +
            K("ba_") + "{cursor:pointer;}.si130{display:inline; text-transform:inherit;}." + K("r_") + "{position: relative;}</style>")
    }

    function ng() {
        return tf("display:-ms-flexbox; display:-webkit-box; display:-webkit-flex; display:flex;" + mg("center") + og("center"))
    }

    function pg(a, b) {
        var c = "",
            d = b ? "right" : "left";
        b = b ? "left" : "right";
        for (var e = uf(a), f = e.length, g = 0; g < f; g++) {
            var h = e[g];
            switch (xa(h) ? h.toString() : h) {
                case "fw":
                    c += "font-weight:";
                    h = a.fw;
                    switch (xa(h) ? h.toString() : h) {
                        case 1:
                            c += "100";
                            break;
                        case 2:
                            c += "400";
                            break;
                        case 4:
                            c += "500";
                            break;
                        case 3:
                            c += "700";
                            break;
                        case 0:
                            c += "400"
                    }
                    break;
                case "bac":
                    c += "background-color:" + K(a.bac);
                    break;
                case "br":
                    c += "border-radius:" + K(a.br) + "px";
                    break;
                case "bw":
                    c += "border:" + K(a.bw) + "px solid " + K(a.boc);
                    break;
                case "ff":
                    c += "font-family:" +
                        K(a.ff) + ",arial,sans-serif;";
                    break;
                case "fs":
                    c += "font-size:" + K(a.fs) + "px";
                    break;
                case "h":
                    c += "height:" + K(a.h) + (-1 != ("" + vf(a.h)).indexOf("%") ? "" : "px");
                    break;
                case "i":
                    c += "font-style:" + K(H(a.i, !0) ? "italic" : "normal");
                    break;
                case "lh":
                    c += "line-height:" + K(a.lh) + "px";
                    break;
                case "maxh":
                    c += "max-height:" + K(a.maxh) + "px";
                    break;
                case "maxw":
                    c += "max-width:" + K(a.maxw) + "px";
                    break;
                case "mb":
                    c += "margin-bottom:" + K(a.mb) + "px";
                    break;
                case "minh":
                    c += "min-height:" + K(a.minh) + "px";
                    break;
                case "minw":
                    c += "min-width:" + K(a.minw) +
                        "px";
                    break;
                case "ml":
                    c += "margin-" + K(d) + ":" + K(a.ml) + "px";
                    break;
                case "mr":
                    c += "margin-" + K(b) + ":" + K(a.mr) + "px";
                    break;
                case "mt":
                    c += "margin-top:" + K(a.mt) + "px";
                    break;
                case "op":
                    c += "opacity:" + K(a.op);
                    break;
                case "pb":
                    c += "padding-bottom:" + K(a.pb) + "px";
                    break;
                case "pl":
                    c += "padding-" + K(d) + ": " + K(a.pl) + "px";
                    break;
                case "pr":
                    c += "padding-" + K(b) + ": " + K(a.pr) + "px";
                    break;
                case "pt":
                    c += "padding-top:" + K(a.pt) + "px";
                    break;
                case "tc":
                    c += "color:" + K(a.tc);
                    break;
                case "u":
                    c += "text-decoration:" + K(a.u ? "underline" : "none");
                    break;
                case "st":
                    c +=
                        "text-decoration:" + K(a.st ? "line-through" : "none");
                    break;
                case "po":
                    h = a.po;
                    var k = d,
                        l = b;
                    h = tf((h.t ? K() + "top:" + K(h.t) + "px;" : "") + (h.r ? K() + K(l) + ":" + K(h.r) + "px;" : "") + (h.b ? K() + "bottom:" + K(h.b) + "px;" : "") + (h.l ? K() + K(k) + ":" + K(h.l) + "px;" : ""));
                    c += h + "position:absolute";
                    break;
                case "bos":
                    h = a.bos;
                    k = "";
                    l = h;
                    for (var q = l.length, t = 0; t < q; t++) {
                        var p = l[t];
                        k += K(p.xo) + "px " + K(p.yo) + "px " + (p.br ? K(p.br) + "px " + (p.sr ? K(p.sr) + "px " : "") : "") + K(p.sc) + (t != h.length - 1 ? "," : "")
                    }
                    h = tf(k);
                    h = Bf("" + h);
                    h = tf("-webkit-box-shadow:" + K(h) + "; -moz-box-shadow:" +
                        K(h) + "; -ms-box-shadow:" + K(h) + "; box-shadow:" + K(h) + ";");
                    c += h;
                    break;
                case "w":
                    c += "width:" + K(a.w) + (-1 != ("" + vf("" + a.w)).indexOf("%") ? "; -ms-flex-negative:1;" + lg(1) : "px");
                    break;
                case "tt":
                    switch (c += "text-transform:", h = a.tt, xa(h) ? h.toString() : h) {
                        case 1:
                            c += "uppercase";
                            break;
                        default:
                            c += "initial"
                    }
            }
            c += ";"
        }
        return tf(c)
    }

    function lg(a) {
        return tf("-webkit-box-flex:" + K(a) + " 0; -webkit-flex-shrink:" + K(a) + "; flex-shrink:" + K(a) + ";")
    }

    function mg(a) {
        var b = "-ms-flex-align:",
            c = "" + (0 == ("" + vf(a)).indexOf("flex-") ? K(("" + vf(a)).substring(5)) : K(a));
        c = Bf(c);
        b += K(c) + "; -webkit-box-align:" + K(c) + "; -webkit-align-items:" + K(a) + "; align-items:" + K(a) + ";";
        return tf(b)
    }

    function og(a) {
        var b = "-ms-flex-pack:",
            c = "" + (0 == ("" + vf(a)).indexOf("flex-") ? K(("" + vf(a)).substring(5)) : K(a));
        c = Bf(c);
        b += K(c) + "; -webkit-box-pack:" + K(c) + "; -webkit-justify-content:" + K(a) + "; justify-content:" + K(a) + ";";
        return tf(b)
    };

    function qg(a) {
        var b = [];
        a = n(a.s || []);
        for (var c = a.next(); !c.done; c = a.next()) {
            c = c.value;
            var d = c.r;
            d && d.hasOwnProperty("ff") && (d.ff = tf(d.ff));
            (d = c.hr) && d.hasOwnProperty("ff") && (d.ff = tf(d.ff));
            b.push({
                className: c.sk,
                rules: c.r || {},
                kb: c.hr || {}
            })
        }
        a = La().xa();
        var e = "<style>";
        c = b.length;
        for (d = 0; d < c; d++) {
            var f = b[d];
            if (I(f.rules) && 0 < uf(f.rules).length) {
                var g = "." + K(f.className) + "{" + pg(f.rules, a) + "}";
                var h = f.rules;
                h = tf(I(h.iss) && I(h.iss.bc) && I(h.iss.o) ? "." + K(f.className) + " > ." + K("s_") + "{background-color:" + K(h.iss.bc) +
                    "; opacity:" + K(h.iss.o) + "; bottom:0; top:0; right:0; left:0; position:absolute;}" : "");
                g += h
            } else g = "";
            e += g + (I(f.kb) && 0 < uf(f.kb).length ? "." + K(f.className) + ":hover{" + pg(f.kb, a) + "}" : "")
        }
        return G(e + "</style>")
    };

    function rg(a, b) {
        if (!a) return !1;
        if (3 == a.nodeType && a.nodeValue && (b && (a.nodeValue += " ..."), 4 < a.nodeValue.length)) {
            b = a.nodeValue;
            var c = a.nodeValue.length - 1;
            b.length > c && (b = b.substring(0, c - 3) + "...");
            a.nodeValue = b;
            return !1
        }
        c = a.textContent || a.innerText;
        if (!c || c.length <= (b ? 0 : 4)) return a.parentNode.removeChild(a), !0;
        for (b = rg(a.lastChild, b); b;) b = rg(a.lastChild, b);
        return !1
    }

    function sg(a, b) {
        if (!(0 >= b)) {
            for (var c = a.innerHTML.length; 0 < c && a.offsetHeight > b; c--)
                for (var d = a, e = rg(d.lastChild, !1); e;) e = rg(d.lastChild, e);
            a.offsetHeight > b && (a.textContent = "")
        }
    };
    var tg = 1;

    function ug(a, b, c) {
        if (!c) return null;
        if ("." == c[0]) return b[c.substring(1)];
        c = n(c.split("."));
        for (b = c.next(); !b.done; b = c.next()) {
            b = b.value;
            if (null == a) return null;
            if (Array.isArray(a)) {
                b = parseInt(b, 10);
                if (isNaN(b)) return null;
                a = a[b]
            } else if (xa(a) && a.hasOwnProperty(b)) a = a[b];
            else return null
        }
        return a
    };
    var vg = null;

    function wg(a, b, c) {
        var d = "A" === c.tagName ? c : c.querySelector("a");
        b.addEventListener("click", function(e) {
            xg(a, b, c);
            yg(e)
        });
        b.addEventListener("keydown", function(e) {
            if (32 == e.keyCode || 13 == e.keyCode) xg(a, b, c), yg(e), d && d.focus()
        });
        a.addEventListener("click", zg);
        a.addEventListener("scroll", zg);
        b.setAttribute("role", "button");
        b.setAttribute("tabindex", 0);
        d && b.setAttribute("aria-label", c.textContent)
    }

    function yg(a) {
        a.stopPropagation ? a.stopPropagation() : (a.cancelBubble = !0, a.returnValue = !1)
    }

    function xg(a, b, c) {
        vg && vg != c && (vg.style.display = "none", vg = null);
        if (c.style.display && "none" != c.style.display) c.style.display = "none", vg = null;
        else {
            a.appendChild(c);
            var d = Pd(b),
                e = Qd(b),
                f = Qd(c),
                g = Qd(a),
                h = Pd(a),
                k = d.x + a.scrollLeft - h.x;
            d = d.y + a.scrollTop - h.y;
            switch (b.getAttribute("data-position")) {
                case "over":
                    b = e.width / 2 - f.width / 2;
                    e = e.height / 2 - f.height / 2;
                    break;
                default:
                    b = e.width / 2 - f.width / 2, e = e.height
            }
            h = a.scrollTop;
            var l = a.scrollTop + g.height - f.height - 10;
            c.style.left = Math.min(Math.max(Math.round(k + b), a.scrollLeft),
                a.scrollLeft + g.width - f.width - 10) + "px";
            c.style.top = Math.min(Math.max(Math.round(d + e), h), l) + "px";
            c.style.display = "block";
            vg = c
        }
    }

    function zg() {
        vg && (vg.style.display = "none", vg = null)
    };

    function Ag(a) {
        var b = a.orientation,
            c = a.id,
            d = a.O,
            e = a.Yd,
            f = a.overflow,
            g = a.Ae,
            h = a.ne,
            k = a.Ye,
            l = a.href,
            q = "",
            t = H(e, 0) || H(e, 1) || H(e, 2),
            p = H(e, 6) || H(e, 7) || H(e, 8),
            r = H(e, 3) || H(e, 4) || H(e, 5);
        c = (c ? 'id="' + J(c) + '"' : "") + ' class="' + J("i_") + (d ? " " + J(d) : "") + (H(f, 3) ? " " + J("j_") : "");
        H(g, 4) && (c += " " + J("k_") + " ", c += J(t ? "topAlign" : p ? "centerAlign" : r ? "bottomAlign" : ""));
        c += (H(f, 4) ? " " + J("j_") + " " + J("l_") : "") + '"' + (h ? ' data-drop="true"' : "");
        g = "-ms-flex-direction:";
        h = "" + K(0 == b ? "row" : "column");
        h = Bf(h);
        g += K(h) + "; -webkit-box-orient:" +
            K(0 == b ? "horizontal" : "vertical") + "; -webkit-flex-direction:" + K(h) + "; flex-direction:" + K(h) + ";";
        g = Bf(g);
        h = null != e ? og(H(e, 0) || H(e, 3) || H(e, 9) || H(e, 6) ? "flex-start" : H(e, 1) || H(e, 4) || H(e, 10) || H(e, 7) ? "center" : H(e, 2) || H(e, 5) || H(e, 11) || H(e, 8) ? "flex-end" : "") : "";
        h = Bf("" + h);
        e = null != e ? mg(t ? "flex-start" : r ? "flex-end" : p ? "center" : H(e, 9) || H(e, 10) || H(e, 11) ? "stretch" : "") : "";
        e = Bf("" + e);
        t = "";
        switch (f) {
            case 2:
                t += "-ms-flex-wrap:wrap; -webkit-flex-wrap:wrap; flex-wrap:wrap;";
                break;
            case 3:
            case 4:
                t += "overflow-" + K(0 == b ? "x" : "y") +
                    ":auto; -webkit-overflow-scrolling: touch; scroll-behavior: smooth;"
        }
        b = Bf(t);
        c += ' style="' + J(K(g)) + J(K(h)) + J(K(e)) + J(K(b)) + (k ? "position:relative;" : "") + '"';
        k = Af(c);
        q += l ? "<a" + If(Bg(a)) + If(Gf(k)) + "></a>" : "<div" + If(Gf(k)) + "></div>";
        return G(q)
    }

    function Cg(a) {
        a = a || {};
        var b = a.id,
            c = a.text,
            d = a.O,
            e = a.jf,
            f = a.Jf,
            g = a.href,
            h = a.Bd,
            k = "",
            l = null != e ? 'data-lines="' + J(e) + '"' + (null != f ? ' data-truncate="' + J(f) + '"' : ' data-truncate="0"') : "";
        l = Af(l);
        f = H(e, 1) ? "m_ " + (H(f, 0) ? "n_" : "o_") : "p_";
        c = (I(e) && 1 < e ? "<span" + If(Gf(l)) + ' style="display: -webkit-box; -webkit-box-orient: vertical; overflow: hidden; -webkit-line-clamp: ' + J(K(e)) + '; ">' : "") + of (null != c ? c : "") + (I(e) && 1 < e ? "</span>" : "");
        c = xf(c);
        k += g ? "<a" + (b ? ' id="' + J(b) + '"' : "") + ' class="' + J(f) + " " + J(null != d ? d : "") + '"' +
            (I(e) && 1 < e ? "" : If(Gf(l))) + (h ? ' data-pingback-type="' + J(h) + '"' : "") + If(Bg(a)) + ">" + c + "</a>" : "<span" + (b ? ' id="' + J(b) + '"' : "") + (I(e) && 1 < e ? "" : If(Gf(l))) + (h ? ' data-pingback-type="' + J(h) + '"' : "") + ' class="' + J(f) + " " + J(null != d ? d : "") + '">' + c + "</span>";
        return G(k)
    }

    function Dg(a) {
        var b = a.src,
            c = a.id,
            d = a.Te,
            e = a.ariaHidden,
            f = a.O,
            g = a.href,
            h = a.Bd,
            k = a.Ge,
            l = "";
        c = (c ? 'id="' + J(c) + '"' : "") + (e ? ' aria-hidden="true" tabindex="-1"' : "") + ' class="' + J("q_") + (f ? " " + J(f) : "") + (k ? " " + J("r_") : "") + '"';
        c = Af(c);
        b = '<img src="' + J(Of(b)) + '"' + (h ? ' data-pingback-type="' + J(h) + '"' : "") + (d ? ' aria-label="' + J(d) + '"' : "") + ">";
        b = xf(b);
        d = '<div class="' + J("s_") + '"></div>';
        d = xf(d);
        l += g ? "<a" + If(Bg(a)) + If(Gf(c)) + ">" + (k ? d : "") + b + "</a>" : "<div" + If(Gf(c)) + ">" + (k ? d : "") + b + "</div>";
        return G(l)
    }

    function Eg(a) {
        var b = a.mf,
            c = a.nf,
            d = a.id,
            e = a.Cf,
            f = a.Df,
            g = a.lg,
            h = a.mg,
            k = a.ng,
            l = a.O,
            q = a.href,
            t = a.ha,
            p = a.Qc,
            r = a.fc,
            x = a.width,
            u = a.height,
            D = null != k ? k : "";
        k = Math.max(Math.min(b, 5), 0);
        a = I(a.He) && !e && !f;
        d = "<div" + (d ? ' id="' + J(d) + '"' : "") + ' class="' + J("t_") + (l ? " " + J(l) : "") + '"' + (a ? ' style="width:' + J(K(null != x ? x : "")) + ";height:" + J(K(null != u ? u : "")) + ';"' : "") + '><div class="' + J("u_") + '">';
        e = "" + Jf((g ? "" : D) + (null != e ? e : "/images/afs/sr-star-off.png"));
        e = zf(e);
        g = yf("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 21 19'><polygon fill='%23dadce0' points='10,15.27 16.18,19 14.54,11.97 20,7.24 12.81,6.63 10,0 7.19,6.63 0,7.24 5.46,11.97 3.82,19'/></svg>");
        d += a ? '<div style="background-image: url(' + J(Of(g)) + ')" class="' + J("v_") + '" role="none"></div>' : '<img src="' + J(Of(e)) + '" class="' + J("v_") + '" role="none"/>';
        f = "" + Jf((h ? "" : D) + (null != f ? f : "/images/afs/sr-star-on.png"));
        f = zf(f);
        h = yf("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 21 19'><polygon fill='%23fbbc04' points='10,15.27 16.18,19 14.54,11.97 20,7.24 12.81,6.63 10,0 7.19,6.63 0,7.24 5.46,11.97 3.82,19'/></svg>");
        d += '<div class="' + J("w_") + '" style="background-image: url(' +
            J(Of(a ? h : f)) + ");";
        a ? (b = 20 / 105 * k * 100 + 1 / 105 * Math.max(Math.floor(k), 0) * 100, d = d + "background-size: " + (J(K(2E3 / b)) + "% 100%; width: " + J(K(b)) + "%")) : d += "width: " + J(K(20 * Math.max(Math.min(b, 5), 0))) + "%";
        d += '" role="img"' + (c ? ' aria-label="' + J(c) + '"' : ' aria-hidden="true"') + "></div></div></div>";
        c = c = {
            href: q,
            ha: t,
            Qc: p,
            fc: r,
            Be: xf(d)
        };
        q = c.Be;
        c = G(c.href ? "<a" + If(Bg(c)) + ">" + of (q) + "</a>" : of (q));
        return G("" + c)
    }

    function Bg(a) {
        a = a || {};
        var b = a.ha,
            c = a.Qc,
            d = a.fc,
            e = a.Ce;
        a = 'href="' + J(Jf(a.href)) + '"' + (d ? ' data-notrack="true"' : "") + (null != c ? ' data-nb="' + J(c) + '"' : "") + (b ? ' target="' + J(b) + '"' : "");
        null != e ? (e = sf(H(null == e ? null : e.as, "true") ? 'attributionsrc=""' : 'attributionsrc="' + J(null == e ? null : e.as) + '"'), e = If(e)) : e = "";
        return sf(a + e)
    };

    function Fg() {
        this.De = Dd();
        this.Hb = null
    }
    Fg.prototype.Kc = function(a, b) {
        var c = this.Hb ? this.Hb.getData() : {},
            d = this.De;
        return Wf(a(b || Xf, c), d)
    };
    Fg.prototype.Ed = function(a) {
        a = a({}, this.Hb ? this.Hb.getData() : {});
        return String(a)
    };

    function Gg(a) {
        if (!a) return {};
        var b = {};
        a = n(a);
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, b[c.sk] = {
            rules: c.r,
            kb: c.hr
        };
        return b
    }
    var Hg = new Fg,
        Ig = {},
        Jg = (Ig[2] = "x_", Ig[3] = "y_", Ig);

    function Kg(a, b, c, d, e, f) {
        function g(x, u, D) {
            var L = "adBlock" == x.dbk,
                da = d ? "_blank" : "_top";
            u = {
                id: L ? "adBlock" : u,
                O: (x.sk || "") + " " + (void 0 === D ? "" : D),
                ha: da
            };
            x.pb && (u.Bd = x.pb.pbt);
            D = "ctc" === x.dbk;
            var Z = "ctc.bt" === x.dbk;
            if (q || D || Z) "" === (w().data.ctclt || "") ? (u.ha = "_self", !/i(Phone|Pad);/i.test(ec) || lc() && 98 < gc(jc) || (u.ha = da)) : u.ha = w().data.ctclt || "";
            t && (u.ha = "_top");
            D = x.dbk ? ug(c, b, x.dbk) : void 0;
            Z = x.acc && x.acc.alt ? ug(c, b, x.acc.alt) : void 0;
            var Ja = x.acc && x.acc.ah,
                cb = ug(c, b, "bcala");
            if (x.dbk && !D && !L || x.hnk && null !=
                ug(c, b, x.hnk)) return null;
            da = null;
            var Qa = 0;
            if (x.ac) {
                var W = x.ac[0],
                    X = W.act,
                    Qc = W.dbk ? ug(c, b, W.dbk) : void 0,
                    Xb = W.en,
                    Yb = void 0,
                    Rc = void 0;
                switch (X) {
                    case 0:
                        u.href = Qc;
                        u.fc = !!W.nm;
                        u.Qc = W.nb;
                        u.Ce = cb;
                        break;
                    case 3:
                        u.O += " z_";
                        Rc = "aa_";
                        Yb = "e" + tg++;
                        u.id || (u.id = "e" + tg++);
                        l.push({
                            Se: u.id,
                            ke: Yb
                        });
                        break;
                    case 5:
                        if (Qa = parseInt(Qc, 10)) u.O += " ba_"
                }
                Xb && (da = g(Xb, Yb, Rc))
            }
            X = null;
            cb = x.nt;
            W = x.lr || {};
            X = (h[x.sk] || {}).rules || {};
            switch (cb) {
                case 0:
                    D = W.o;
                    null == D && (D = 0);
                    u.orientation = D;
                    u.Yd = W.a;
                    u.ne = 1 == W.t;
                    u.overflow = W.ov;
                    u.Ae = W.cf;
                    u.Ye = W.ap && !X.po;
                    X = Ag;
                    break;
                case 1:
                    u.text = G(D);
                    u.jf = W.nl;
                    u.Jf = W.t;
                    X = Cg;
                    break;
                case 2:
                    u.src = X.sfc && "svg" == D.substr(-3) ? D + "?c=" + encodeURIComponent(X.sfc) : D;
                    u.Ge = "iss" in X && "bc" in X.iss && "o" in X.iss;
                    u.Te = Z;
                    u.ariaHidden = Ja;
                    X = Dg;
                    break;
                case 4:
                    "string" == typeof D && (D = parseFloat(D));
                    if ("number" != typeof D || isNaN(D)) return null;
                    u.Cf = X.bu;
                    u.Df = X.fu;
                    u.mf = D;
                    u.nf = Z;
                    u.He = !!w().data.esrs;
                    La().data.insr && 2 == k ? (u.width = "177px", u.height = "32px") : (u.width = "61px", u.height = "11px");
                    X = Eg;
                    break;
                default:
                    return null
            }
            if (D = Jg[W.sb]) u.O +=
                " " + D;
            var M = Hg.Kc(X, u);
            x.hasOwnProperty("hne") && r[x.hne].push(M);
            if (L) {
                var tb = F(function() {
                    for (var T = n(r[1]), U = T.next(); !U.done; U = T.next()) {
                        U = U.value;
                        var ja = !1;
                        "auto" === M.style.overflowX ? ja = 0 !== M.scrollLeft : "auto" === M.style.overflowY && (ja = 0 !== M.scrollTop);
                        U.style.visibility = ja ? "visible" : "hidden"
                    }
                    T = n(r[2]);
                    for (U = T.next(); !U.done; U = T.next()) U = U.value, ja = !0, "auto" === M.style.overflowX ? ja = Math.abs(M.scrollLeft) !== M.scrollWidth - M.clientWidth : "auto" === M.style.overflowY && (ja = M.scrollTop !== M.scrollHeight -
                        M.clientHeight), U.style.visibility = ja ? "visible" : "hidden"
                }, "hneSc");
                F(function() {
                    e && (M.addEventListener("scroll", tb), e.addEventListener("resize", tb))
                }, "hneAsc")()
            }
            Qa && M.addEventListener("click", function() {
                var T = M.ownerDocument.getElementById("adBlock");
                "auto" === T.style.overflowX ? T.scrollLeft += Qa : "auto" === T.style.overflowY && (T.scrollTop += Qa);
                T = 0 > Qa ? "cblc" : "cbrc";
                var U = vc();
                if (sc) {
                    var ja = wc(U);
                    A(ja, "pbt", "ui");
                    A(ja, "emsg", T);
                    U.ia(rc(ja))
                }
            });
            x = x.ch;
            if (0 == cb && x && 0 < x.length) {
                L = !1;
                for (u = 0; u < x.length; u++) D =
                    g(x[u]), null != D && (L = !0, M.appendChild(D));
                if (!L) return null
            }
            return da ? (x = document.createDocumentFragment(), x.appendChild(M), x.appendChild(da), x) : M
        }
        d = void 0 === d ? !1 : d;
        e = void 0 === e ? null : e;
        f = void 0 === f ? [] : f;
        var h = Gg(a.s),
            k = a.at,
            l = [],
            q = !!ug(c, b, "ctc.cott"),
            t = !!ug(c, b, "ctd"),
            p = {},
            r = (p[1] = [], p[2] = [], p);
        p = "e" + tg++;
        a = g(a.l || {}, p, f.join(" "));
        a || (a = document.createElement("span"), a.id = p);
        return {
            rootElement: a,
            Od: l,
            yf: p
        }
    }

    function Lg(a, b) {
        function c(t) {
            var p = t.style.wordWrap,
                r = t.style.whiteSpace;
            t.style.whiteSpace = "nowrap";
            t.style.wordWrap = "normal";
            var x = t.offsetHeight;
            t.style.whiteSpace = r;
            t.style.wordWrap = p;
            return x
        }

        function d(t, p) {
            var r = 0 == t.childElementCount;
            p = p && "true" == t.getAttribute("data-drop");
            if (r || p) r = t.parentNode, r.removeChild(t), t.id != b && d(r, p)
        }
        a = a.querySelectorAll("[data-lines]");
        for (var e = a.length - 1; 0 <= e; e--) {
            var f = a[e],
                g = f.parentNode,
                h = parseInt(f.getAttribute("data-lines"), 10),
                k = parseInt(f.getAttribute("data-truncate"),
                    10);
            if (1 != h || 0 != k) {
                var l = f.getBoundingClientRect(),
                    q = g.getBoundingClientRect();
                l = q.left > l.left || q.right < l.right;
                0 !== k || fc() ? 1 === k && (k = 1 < h ? c(f) : void 0, (1 == h ? f.offsetWidth < f.scrollWidth : 1 < h && f.offsetHeight / k > h) || l) && (g.removeChild(f), d(g, !0)) : (g = c(f), (1 < h && f.offsetHeight / g > h || l) && sg(f, (g + 1) * h))
            }
        }
    }

    function Mg(a, b) {
        b = n(b);
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            c = a.document.getElementById(d.ke);
            d = a.document.getElementById(d.Se);
            c && d && wg(a.document.getElementById("adBlock"), d, c)
        }
    };

    function Pg(a) {
        a = a || {};
        return G(Qg(a.Oa, "googNoAds"))
    }

    function Qg(a, b) {
        return G('<div style="display:none;"' + (b ? ' id="_' + J(b) + "_" + J(null != a ? a : "unknown_pubId") + '"' : "") + "></div>")
    };

    function Rg(a) {
        var b = a.url;
        a = a.Uc;
        this.Ib = b;
        this.Ta = a;
        a = /[?&]dsh=1(&|$)/.test(b);
        this.rb = !a && /[?&]ae=1(&|$)/.test(b);
        this.ud = !a && /[?&]ae=2(&|$)/.test(b);
        if ((this.ma = /[?&]adurl=([^&]*)/.exec(b)) && this.ma[1]) {
            try {
                var c = decodeURIComponent(this.ma[1])
            } catch (d) {
                c = null
            }
            this.Mb = c
        }
    }

    function Sg(a, b) {
        return a.rb && a.Mb || a.ud ? 1 == b ? a.rb ? a.Mb : Tg(a, "&dct=1") : 2 == b ? Tg(a, "&ri=2") : Tg(a, "&ri=16") : a.Ib
    }

    function Tg(a, b) {
        return a.ma ? a.Ib.slice(0, a.ma.index) + b + a.Ib.slice(a.ma.index) : a.Ib + b
    }

    function Ug(a) {
        a = a.Ta;
        var b = encodeURIComponent,
            c = "";
        a.platform && (c += "&uap=" + b(a.platform));
        a.platformVersion && (c += "&uapv=" + b(a.platformVersion));
        a.uaFullVersion && (c += "&uafv=" + b(a.uaFullVersion));
        a.architecture && (c += "&uaa=" + b(a.architecture));
        a.model && (c += "&uam=" + b(a.model));
        a.bitness && (c += "&uab=" + b(a.bitness));
        a.fullVersionList && (c += "&uafvl=" + b(a.fullVersionList.map(function(d) {
            return b(d.brand) + ";" + b(d.version)
        }).join("|")));
        "undefined" !== typeof a.wow64 && (c += "&uaw=" + Number(a.wow64));
        return c
    };
    var Vg = /^((market|itms|intent|itms-appss):\/\/)/i;
    var Wg = "alternate author bookmark canonical cite help icon license next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function Xg(a, b) {
        a.src = hb(b);
        var c, d;
        (c = (b = null == (d = (c = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : d.call(c, "script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", c)
    };

    function Yg(a) {
        var b = Qb("<!doctype html><html><head></head><body></body></html>");
        a.write(Ob(b))
    };

    function Zg() {
        var a = this,
            b = {}.jg;
        this.Ta = null;
        b && navigator.userAgentData && navigator.userAgentData.getHighEntropyValues && (b = navigator.userAgentData.getHighEntropyValues("platform platformVersion uaFullVersion architecture model bitness fullVersionList wow64".split(" "))) && b.then(function(c) {
            a.Ta = c
        })
    }
    Zg.prototype.handle = function(a) {
        if (a.hasAttribute("data-ohref")) var b = a.getAttribute("data-ohref");
        else b = a.href, a.setAttribute("data-ohref", b);
        var c = b;
        var d = {
            Uc: this.Ta
        };
        d = new Rg({
            url: c,
            Uc: (void 0 === d ? {} : d).Uc
        });
        if (d.rb && d.Mb || d.ud)
            if (navigator.sendBeacon) {
                c = navigator;
                var e = c.sendBeacon,
                    f = "&act=1&ri=1";
                d.rb && d.Ta && (f += Ug(d));
                d = e.call(c, Tg(d, f), "") ? Sg(d, 1) : Sg(d, 2)
            } else d = Sg(d, 0);
        else d = c;
        d = d instanceof vb || !Vg.test(d) ? d : new vb(d, xb);
        b != d && (b = Le(d), void 0 !== b && (a.href = b))
    };
    var $g = F(function(a) {
        (new Zg).handle(a)
    }, "mDS");
    var ah = /([?|&]{1}nm=)([\d]{1,})/,
        bh = /(\?|&)clkt=-?[\d]*/g,
        ch = /(\?|&)bg=[^&]*/g,
        dh = /(\?|&)nx=-?[\d]+/g,
        eh = /(\?|&)ny=-?[\d]+/g;

    function fh(a) {
        return function() {
            for (var b = 0; b < a.length; b++) {
                var c = a[b];
                if (c.Ba) {
                    var d = c.element.href,
                        e = d.match(ah);
                    e ? 3 == e.length && (d = d.replace(ah, e[1] + (parseInt(e[2], 10) + 1))) : d += (-1 == d.indexOf("?") ? "?" : "&") + "nm=1";
                    gh(c, d)
                }
            }
        }
    }

    function hh(a) {
        return function() {
            if (a.yc) {
                var b = "&clkt=" + ((new Date).getTime() - a.yc),
                    c = a.element.href;
                c = c.replace(bh, "");
                gh(a, c + b)
            }
        }
    }

    function ih(a) {
        return function(b) {
            a.yc = (new Date).getTime();
            var c = Od(a.element),
                d = Math.round(b.clientX - c.x);
            b = Math.round(b.clientY - c.y);
            c = a.element.href;
            c = c.replace(dh, "");
            c = c.replace(eh, "");
            gh(a, c + ("&nx=" + d) + ("&ny=" + b))
        }
    }

    function jh(a) {
        return function() {
            var b = a.element.ownerDocument;
            if (b = (b.defaultView || b.parentWindow).csabg) {
                b = "&bg=" + b.pc();
                var c = a.element.href;
                c = c.replace(ch, "");
                gh(a, c + b)
            }
        }
    }

    function kh(a) {
        a.Ba && (a.element.addEventListener("mouseover", fh([a])), a.element.addEventListener("mousedown", ih(a)));
        var b = hh(a),
            c = jh(a);
        fg(a.element, function(d) {
            fd(".aCS", Date.now());
            ed();
            a.Ba && (b(d), c(d));
            try {
                $g(a.element)
            } catch (e) {}
        })
    }

    function lh(a, b, c) {
        return -1 == a.indexOf(b) && 16334 > a.length + b.length && (a += b + encodeURIComponent(c), 16334 < a.length) ? a.substring(0, 16334) : a
    }

    function mh(a, b) {
        pe(a.element, "mousedown", function() {
            try {
                var c = xe(b, !0);
                var d = xe(b, !1)
            } catch (f) {}
            if (c && d) {
                var e = a.element.href;
                e = lh(e, "&is=", [d, c].join("x"));
                gh(a, e)
            }
        })
    }

    function nh(a, b, c) {
        for (var d = 0; d < a.length; d++) {
            var e = a[d];
            kh(e);
            if (e.Ba && void 0 !== e.nd) {
                var f = "&nb=" + (e.nd || ""),
                    g = e.element.href;
                g = g.replace(oh, "");
                g = -1 == g.indexOf("?") ? g + f.replace(/^&/, "?") : g + f;
                gh(e, g)
            }
            e.Ba && (mh(e, c), f = La().data.ru || null) && (g = e.element.href, g = lh(g, "&rurl=", f), gh(e, g))
        }
        0 < a.length && b.addEventListener("mouseover", fh(a))
    };

    function ph(a, b) {
        this.nd = b;
        this.Ba = !0;
        this.element = a;
        this.yc = null
    }

    function gh(a, b) {
        16384 < b.length || (a = a.element, b = Le(b), void 0 !== b && (a.href = b))
    }
    var oh = /[&\?]nb=\d/;
    var qh = {
            nt: 0,
            sk: "si128"
        },
        rh = {
            nt: 0,
            sk: "si177"
        };

    function sh(a) {
        var b = [];
        a = n(a.s || []);
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, "si128" != c.sk && "si177" != c.sk || !c.r || (c.r.bac && b.push(c), c.r.h && !c.r.h.includes("%") && 1 < parseInt(c.r.h, 10) && b.push(c));
        return 1 === b.length ? b[0] : b.find(function(d) {
            return "si128" === d.sk
        }) || null
    }

    function th(a, b, c, d, e, f, g) {
        f = void 0 === f ? [] : f;
        g = void 0 === g ? null : g;
        this.ae = nh;
        this.la = [];
        this.Nb = [];
        this.Ya = null;
        this.L = e;
        this.Ff = Wf(qg(b));
        var h = sh(b);
        null != h && (this.Ya = Kg({
            s: [h],
            l: "si128" === h.sk ? qh : rh
        }, {}, {}).rootElement, this.Ya.removeAttribute("id"));
        a = n(a);
        for (var k = a.next(); !k.done; k = a.next()) k = k.value, this.la.push(Kg(b, c, k[k.adtype], d, e, ["b_"]));
        this.bd = b.at;
        this.sf = c;
        this.kf = d;
        this.Tb = g;
        a: if (d = f, this.Ya)
            if (h = ((h || {}).r || {}).rsi) b = h;
            else {
                c = h = !1;
                if (4 == this.bd)
                    for (b = n(b.s || []), d = b.next(); !d.done; d =
                        b.next())
                        if (d = d.value, "si101" === d.sk) {
                            if ("100%" !== d.r.w) {
                                b = [];
                                break a
                            }
                        } else {
                            if ("si144" === d.sk) {
                                c = h = !0;
                                break
                            }
                        }
                else h = d.includes(2), c = d.includes(3);
                b = [];
                for (d = 0; d < this.la.length - 1; d++) b.push(d);
                h && b.unshift(-1);
                c && b.push(this.la.length - 1)
            }
        else b = [];
        this.Gd = b
    }

    function uh(a, b) {
        var c = a.L.document.head,
            d = b.parentNode;
        c.appendChild(a.Ff);
        var e = b;
        a.Tb && (c.appendChild(Wf(qg(a.Tb))), e = Kg(a.Tb, a.sf, {}, a.kf, a.L), c = e.rootElement, a.Nb = e.Od, d.replaceChild(c, b), e = d.querySelector("#adBlock"), e.setAttribute("aria-label", document.title), e.setAttribute("role", "region"));
        b = 0;
        for (d = -1; d < a.la.length; d++) 0 <= d && e.appendChild(a.la[d].rootElement), b < a.Gd.length && a.Gd[b] === d && (e.appendChild(a.Ya.cloneNode(!0)), b++);
        a = a = {
            Oa: Ma(La()),
            Za: a.bd
        };
        b = a.Oa;
        d = "";
        switch (a.Za) {
            case 1:
                d +=
                    Qg(b, "googAFS");
                break;
            case 2:
                d += Qg(b, "googAFShPLAs");
                break;
            default:
                d += Qg()
        }
        a = G(d);
        a = Wf(a);
        e.appendChild(a);
        a.setAttribute("data-render-complete", !0);
        return e
    }
    th.prototype.Ed = function(a) {
        var b = this,
            c = null,
            d = qe();
        if ("MutationObserver" in window) return (new MutationObserver(function(e, f) {
            e = n(e);
            for (var g = e.next(); !g.done; g = e.next()) "data-render-complete" == g.value.attributeName && (d.resolve(c), f.disconnect())
        })).observe(a.parentElement, {
            subtree: !0,
            attributes: !0,
            attributeFilter: ["data-render-complete"]
        }), c = uh(this, a), d.promise.then(function(e) {
            return re(b.L, e)
        }).then(function(e) {
            vh(b, e, b.L);
            return e
        });
        c = uh(this, a);
        this.L.setTimeout(function() {
            vh(b, c, b.L);
            La().data.icv2 &&
                "requestAnimationFrame" in b.L ? b.L.requestAnimationFrame(function() {
                    d.resolve(c)
                }) : d.resolve(c)
        }, 0);
        return d.promise
    };

    function vh(a, b, c) {
        for (var d = [], e = n(b.querySelectorAll("a[href]")), f = e.next(); !f.done; f = e.next())
            if (f = f.value, "true" != f.getAttribute("data-notrack")) {
                var g = f.getAttribute("data-nb") || void 0;
                d.push(new ph(f, g))
            }
        e = n(b.querySelectorAll("[data-pingback-type]"));
        f = e.next();
        for (g = {}; !f.done; g = {
                hb: g.hb
            }, f = e.next()) g.hb = f.value, g.hb.addEventListener("click", function(h) {
            return function() {
                zc(vc(), h.hb.getAttribute("data-pingback-type"))
            }
        }(g));
        e = n(b.querySelectorAll(".b_"));
        for (f = e.next(); !f.done; f = e.next()) f.value.setAttribute("data-bg",
            "true");
        a.ae(d, b, c.document.body);
        d = n(a.la);
        for (e = d.next(); !e.done; e = d.next()) e = e.value, Mg(c, e.Od || []), Lg(b, e.yf);
        0 < a.Nb.length && Mg(c, a.Nb)
    };
    var xh = F(function(a, b, c, d, e, f) {
            c = void 0 === c ? !1 : c;
            d = void 0 === d ? nh : d;
            e = void 0 === e ? wg : e;
            f = void 0 === f ? Lg : f;
            for (var g = n(b.querySelectorAll("[data-wta-bubble]")), h = g.next(); !h.done; h = g.next()) {
                h = h.value;
                var k = h.getAttribute("data-wta-bubble");
                if (k) {
                    var l = a.document.getElementById(k);
                    if (!l) throw Error("Could not find element with id: " + k);
                    e(b, h, l)
                }
            }
            e = n(b.querySelectorAll("[data-pingback-type]"));
            g = e.next();
            for (h = {}; !g.done; h = {
                    ib: h.ib
                }, g = e.next()) h.ib = g.value, h.ib.addEventListener("click", function(q) {
                return function() {
                    zc(vc(),
                        q.ib.getAttribute("data-pingback-type"))
                }
            }(h));
            e = n(b.querySelectorAll("[data-set-target]"));
            for (g = e.next(); !g.done; g = e.next()) g = g.value, c && (g.target = "_blank"), g.removeAttribute("data-set-target");
            c = n(b.querySelectorAll(".clicktrackedAd_js"));
            for (e = c.next(); !e.done; e = c.next()) e = e.value, e.setAttribute("data-bg", "true"), f(b, e.id);
            f = [];
            c = n(b.querySelectorAll("a[href]"));
            for (e = c.next(); !e.done; e = c.next()) e = e.value, "true" !== e.getAttribute("data-notrack") && (g = e.getAttribute("data-nb") || void 0, f.push(new ph(e,
                g)));
            d(f, b, b);
            wh(a, b)
        }, "aPRS"),
        wh = F(function(a, b) {
            var c = b.querySelectorAll("[data-ad-container]");
            if (!(1 > c.length)) {
                var d = c[0],
                    e = b.querySelectorAll('[data-hide-node-event="SCROLL_BEGIN"]'),
                    f = b.querySelectorAll('[data-hide-node-event="SCROLL_END"]');
                c = 0 < e.length || 0 < f.length;
                var g = function() {
                    for (var l = Math.abs(Math.round(d.scrollLeft)), q = Math.round(d.scrollTop), t = n(e), p = t.next(); !p.done; p = t.next()) {
                        p = p.value;
                        var r = !1;
                        "auto" === d.style.overflowX ? r = 0 !== l : "auto" === d.style.overflowY && (r = 0 !== q);
                        p.style.visibility =
                            r ? "visible" : "hidden"
                    }
                    t = n(f);
                    for (p = t.next(); !p.done; p = t.next()) p = p.value, r = !0, "auto" === d.style.overflowX ? r = l !== d.scrollWidth - d.clientWidth : "auto" === d.style.overflowY && (r = q !== d.scrollHeight - d.clientHeight), p.style.visibility = r ? "visible" : "hidden"
                };
                c && (d.addEventListener("scroll", g), "function" === typeof ResizeObserver ? (new ResizeObserver(g)).observe(d) : a.addEventListener("resize", g));
                a = n(b.querySelectorAll("[data-scroll-displacement]"));
                var h = a.next();
                for (b = {}; !h.done; b = {
                        Qa: b.Qa
                    }, h = a.next()) {
                    h = h.value;
                    var k = h.getAttribute("data-scroll-displacement");
                    if (k) {
                        b.Qa = Number(k);
                        if (isNaN(b.Qa)) throw Error("Scroll Displacement is not a number: " + k);
                        h.addEventListener("click", function(l) {
                            return function() {
                                "auto" === d.style.overflowX ? d.scrollLeft += l.Qa : "auto" === d.style.overflowY && (d.scrollTop += l.Qa)
                            }
                        }(b))
                    }
                }
                c && g()
            }
        }, "aSH");

    function yh(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    };

    function zh(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Ah(a, b) {
        for (var c = 0; 50 > c; ++c) {
            try {
                var d = !(!a.frames || !a.frames[b])
            } catch (g) {
                d = !1
            }
            if (d) return a;
            a: {
                try {
                    var e = a.parent;
                    if (e && e != a) {
                        var f = e;
                        break a
                    }
                } catch (g) {}
                f = null
            }
            if (!(a = f)) break
        }
        return null
    }

    function Bh(a) {
        a = void 0 === a ? document : a;
        return a.createElement("img")
    };

    function Ch(a, b, c) {
        c = void 0 === c ? document : c;
        var d = Dd(c).createElement("SCRIPT");
        d.type = "text/javascript";
        b && (void 0 !== d.onreadystatechange ? d.onreadystatechange = function() {
            if ("complete" == d.readyState || "loaded" == d.readyState) try {
                b && b()
            } catch (f) {}
        } : d.onload = b);
        Xg(d, ib(null === a ? "null" : void 0 === a ? "undefined" : a));
        var e = c.getElementsByTagName("head")[0];
        if (e) try {
            v.setTimeout(function() {
                e.appendChild(d)
            }, 0)
        } catch (f) {}
    };

    function Dh(a, b, c) {
        var d = this;
        this.Ef = b;
        this.Ee = c;
        this.fa = "0";
        this.ld = null;
        this.L = a;
        this.ra = null;
        a && a.document && "complete" === a.document.readyState ? this.fb() : pe(a, "load", function() {
            return d.fb()
        })
    }
    m = Dh.prototype;
    m.fb = function() {
        var a = this;
        if (!this.ra) {
            var b = (new Ed(this.L.document)).createElement("IFRAME");
            b.frameBorder = "0";
            b.style.height = 0;
            b.style.width = 0;
            b.style.position = "absolute";
            this.ra = b;
            this.L.document.body && (this.L.document.body.appendChild(b), this.ra.contentDocument ? this.Bb() : pe(this.ra, "load", function() {
                return a.Bb()
            }))
        }
    };
    m.Bb = function() {
        var a = this,
            b = this.ra;
        b && (b = b.contentDocument ? b.contentDocument : b.contentWindow ? b.contentWindow.document : null) && (this.fa = "1", b.open(), Yg(b), b.close(), Ch(this.Ef, function() {
            return a.Xb()
        }, b))
    };
    m.Xb = function() {
        var a = this.ra;
        if (a)
            if (a = a.contentWindow, this.fa = "", a.botguard)
                if (a = a.botguard.bg) try {
                    this.ld = new a(this.Ee)
                } catch (b) {
                    this.fa = "5"
                } else this.fa = "3";
                else this.fa = "2"
    };
    m.pc = function() {
        if (this.fa) return this.fa;
        var a = this.ld;
        if (!a) return "5";
        if (!a.invoke) return "4";
        var b = "";
        try {
            a.invoke(function(c) {
                b = c
            })
        } catch (c) {
            return "6"
        }
        return "string" !== typeof b || 0 == b.length ? "6" : 3 > b.length ? "7" : 2550 < b.length ? "8" : b
    };
    m.fb = B(Dh.prototype.fb, "BGcI");
    m.Bb = B(Dh.prototype.Bb, "BGpI");
    m.Xb = B(Dh.prototype.Xb, "BGcBV");
    m.pc = B(Dh.prototype.pc, "BGgBR");

    function Eh(a) {
        var b = {};
        a = n(a);
        for (var c = a.next(); !c.done; c = a.next()) {
            c = c.value;
            var d = c.at;
            b[d] = b[d] || {};
            if (c.c) {
                b[d].containerMap = b[d].containerMap || {};
                for (var e = n(c.c), f = e.next(); !f.done; f = e.next()) b[d].containerMap[f.value] = c
            } else b[d]["default"] = c
        }
        this.Sc = b
    }

    function Fh(a, b, c) {
        var d = Gh[b];
        if (!a.Sc[d]) return null;
        b = a.Sc[d]["default"];
        return (a = a.Sc[d].containerMap) ? a[c] || b : b
    }
    var Hh = {},
        Gh = (Hh[0] = 1, Hh[3] = 2, Hh[2] = 4, Hh);
    var Ih = F(function(a) {
        if (!a) return {};
        var b = {};
        a = n(a);
        for (var c = a.next(); !c.done; c = a.next()) {
            var d = c.value;
            c = d.n;
            d = d.v;
            "t" === d ? b[c] = !0 : "f" !== d && (b[c] = d)
        }
        return b
    }, "cJCTM");
    var Jh = ia(["https://fonts.googleapis.com/css?family=", ""]),
        Kh = document;

    function Lh(a) {
        var b = !!w().data.arbwf,
            c = a;
        b && (c = a.map(function(d) {
            return d + ":400,700"
        }));
        a = Me(Jh, c.join("|"));
        (b = w().data.fd || null) && (a = fb(a, {
            display: b
        }));
        return a
    }

    function Mh() {
        this.nc = La().data.wftl || [];
        this.Ld = 0 < this.nc.length ? Lh(this.nc) : null;
        this.Ka = null;
        this.pd = !1
    }

    function Nh(a, b) {
        if (a.Ld) try {
            var c = b.document,
                d = c.createElement("link");
            a: {
                var e = a.Ld;
                if (e instanceof eb) d.href = hb(e).toString();
                else {
                    if (-1 === Wg.indexOf("stylesheet")) throw Error('TrustedResourceUrl href attribute required with rel="stylesheet"');
                    var f = Le(e);
                    if (void 0 === f) break a;
                    d.href = f
                }
                d.rel = "stylesheet"
            }
            c.head.appendChild(d)
        } catch (g) {
            a.Ka = g
        }
    }

    function Oh(a) {
        if (!a.pd && Kh.fonts && "function" == typeof Kh.fonts.load) {
            a.pd = !0;
            a = n(a.nc);
            for (var b = a.next(), c = {}; !b.done; c = {
                    vb: c.vb
                }, b = a.next()) {
                b = b.value;
                var d = "",
                    e = b.split(":");
                2 === e.length && (b = e[0], "700" === e[1] && (d = "bold "));
                !(0 <= b.indexOf(" ")) || b.startsWith("'") && b.endsWith("'") || (b = "'" + b + "'");
                c.vb = d + "12px " + b;
                Kh.fonts.load(c.vb).catch(function(f) {
                    return function(g) {
                        C.log((g instanceof Error ? g.message : String(g)) + " - " + f.vb, "mffl")
                    }
                }(c))
            }
        }
    };
    var Ph = null,
        Qh = {
            ads: 0,
            rss: 2,
            pbs: 3,
            ad_data: 8,
            sbs: 5
        },
        Rh = {
            text_ads: 0,
            pla_npack: 3,
            related_search: 2
        },
        Sh = {
            statusAdult: "s.aDULT",
            statusFaillisted: "s.fL",
            statusTrademark: "s.tM",
            statusNeedsReview: "s.nR"
        },
        Th = {},
        Uh = !1;

    function Vh(a) {
        !Ph && a.name && (Ph = (a = a.name.match(/master-(\d+)/)) && a[1] ? a[1] : null);
        Ph || (Ph = -1);
        return Ph
    }
    Vh = B(Vh, "gMN");

    function Wh(a) {
        var b = "master-" + Vh(a);
        return ne(b, a)
    }
    Wh = B(Wh, "gMI");

    function Xh(a, b, c) {
        try {
            if (a.document.getElementsByTagName("html")) {
                var d = a.document.getElementsByTagName("html")[0];
                d && (!d.lang && b && (d.lang = b), !d.dir && c && (d.dir = c))
            }
        } catch (e) {}
    }
    Xh = B(Xh, "sSILD");

    function Yh(a, b) {
        try {
            if (void 0 !== b) {
                var c = a.document.createElement("meta");
                c.httpEquiv = "origin-trial";
                c.content = b;
                a.document.head.appendChild(c)
            }
        } catch (d) {}
    }
    Yh = B(Yh, "sOTOF");

    function Zh(a, b) {
        var c = {};
        a = n(a);
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, c[d.k] = d.v;
        b = n(b);
        for (d = b.next(); !d.done; d = b.next()) a = d.value, c[a.k] = a.v;
        return c
    }

    function $h(a, b, c, d, e, f, g, h, k, l, q) {
        function t(u) {
            var D = be(b);
            ig(h, u, D);
            a.requestAnimationFrame && a.requestAnimationFrame(function() {
                u.style.transform = "rotateZ(0deg)"
            })
        }
        var p = Zh(g.r || [], k.r || []),
            r = (f = 2 === d[0].type) ? !1 : "_blank" == h.linkTarget,
            x = kg();
        ag(x, a.document.head);
        d = new th(d, k, p, r, a, q, l);
        "iev" in k && gd(b + ".eV", k.iev);
        ai(g, b);
        c = d.Ed(c).then(function(u) {
            t(u);
            return u
        });
        f && h.relatedSearchUseResultCallback && (c = c.then(function(u) {
            bi(u, e);
            return u
        }));
        return c
    }
    $h = B($h, "fSA");

    function ci(a, b, c, d, e, f, g, h) {
        La().xa() && (a.document.dir = "rtl");
        a = d[0].type;
        2 !== a || w().P() || (e = g.rs_attr.t, h.horizontalFlow && (e += ":"), e && (e = G('<h2 id=\'attrHeader\'><span class="lhHeader" id="attribution"><a target="_blank">' + of (e) + "</a></span></h2>"), ag(e, c)));
        $f(c, h);
        w().P() || ai(g, b);
        di(d, c, h, f, a);
        b = be(b);
        ig(h, c, b)
    }
    ci = B(ci, "fA");

    function ei(a, b, c, d, e, f) {
        Xh(a, e, f);
        fi(a);
        Nh(c, a);
        Oh(c);
        a = a.document.head;
        null !== b && a.appendChild(b.cloneNode(!0));
        a.appendChild(d)
    }
    ei = B(ei, "pSRS");

    function gi(a, b, c, d, e, f, g, h) {
        if (b in Th) {
            var k = null;
            try {
                k = a.document.getElementById("adBlock"), ie[b] = !0
            } catch (t) {}
            if (null != k) {
                k.setAttribute("aria-label", document.title);
                k.setAttribute("role", "region");
                if (c) {
                    for (var l = document.createDocumentFragment(); c.firstElementChild;) l.appendChild(c.firstElementChild);
                    k.appendChild(l)
                }
                var q = k;
                "requestAnimationFrame" in a ? a.requestAnimationFrame(function() {
                    d(a, q, f)
                }) : d(a, q, f);
                c = be(b);
                l = Te(b, e);
                ig(l, k, c);
                g && l.relatedSearchUseResultCallback && bi(k, e);
                h.bg && (e = new Dh(a,
                    h.bg.i, h.bg.p), a.csabg = e);
                delete Th[b]
            }
        }
    }
    gi = B(gi, "pSRAH");

    function hi(a, b) {
        a = ne(a, b);
        if (null == a) return null;
        b = null;
        try {
            b = a.document.getElementById("adBlock")
        } catch (c) {}
        return null == b ? null : a
    }
    hi = B(hi, "gFIAB");

    function ii(a, b, c, d, e, f) {
        var g = document.getElementById("ssrab"),
            h = Vh(a),
            k = Oa(),
            l = new Mh,
            q = [],
            t = document.getElementById("ssr-boilerplate");
        if (0 < ji().length) {
            null !== document.getElementById("ssrf") || Nh(l, window);
            Oh(l);
            var p = "master-" + h,
                r = Te(p, a);
            gi(window, p, null, xh, a, "_blank" == r.linkTarget, "relatedsearch" === r.type, c)
        }
        for (p = 0; p < g.childElementCount;) {
            r = g.children[p];
            var x = r.id.split("-");
            p += 1;
            if (!(2 > x.length)) {
                var u = x.shift();
                if ("ssrad" === u || "ssrs" === u || "ssrsb" == u) {
                    x.push(h.toString());
                    x = x.join("-");
                    var D =
                        Te(x, a),
                        L = "_blank" == D.linkTarget,
                        da = "relatedsearch" === D.type,
                        Z = hi(x, a);
                    if (null == Z) q.push(x);
                    else if (g.removeChild(r), --p, "ssrs" === u) ei(Z, t, l, r, d, e, f);
                    else if ("ssrad" === u) gi(Z, x, r, xh, a, L, da, c);
                    else if ("ssrsb" === u) {
                        r = null;
                        try {
                            r = Z.document.getElementById("adBlock")
                        } catch (cb) {}
                        null != r && (ci(Z, x, r, c.sbs, a, b, c, D), ie[x] = !0, delete Th[x])
                    }
                }
            }
        }
        for (var Ja in Th) 0 > q.indexOf(Ja) && (gd(Ja + ".hA", !1), Pa(k) && fd(Ja + ".aC", 0), delete Th[Ja]);
        0 == q.length && document.body.removeChild(g);
        ed();
        l.Ka && C.log(l.Ka, "lwf2")
    }
    ii = B(ii, "pSRA");

    function ki(a, b, c) {
        var d = Wh(a);
        if (d) {
            var e = d.document.documentElement.lang;
            var f = d.document.documentElement.dir;
            d.document.querySelector("head") && fi(d)
        }
        var g = (d = c.at) && 0 < d.length ? new Eh(d) : void 0,
            h = (d = c.act) ? new Eh(d) : void 0,
            k = Object.keys(Th).slice(),
            l = new Mh;
        d = [];
        if (he()) ii(a, b, c, e, f, "A4TVD0oDoRUnBZgYDdNVARYIPSmJgySEsYdPANRrrgQ7QitPsOty0eZIBsjlHFFJwDFU/8QmnRF2kL5xb4RP9Q4AAACEeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGUuY29tOjQ0MyIsImZlYXR1cmUiOiJQcml2YWN5U2FuZGJveEFkc0FQSXMiLCJleHBpcnkiOjE2OTUxNjc5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"), d.push(Promise.resolve());
        else
            for (var q in Th) {
                var t = Th[q],
                    p = t[0].type,
                    r = ne(q, a);
                if (null != r) {
                    Xh(r, e, f);
                    Yh(r, void 0);
                    var x = null;
                    try {
                        x = r.document.getElementById("adBlock")
                    } catch (Z) {}
                    if (null != x) {
                        x.setAttribute("aria-label", document.title);
                        x.setAttribute("role", "region");
                        w().data.icelae && fi(r);
                        Nh(l, r);
                        Oh(l);
                        var u = 2 == p,
                            D = 5 == p,
                            L = Te(q, a),
                            da = null;
                        g && Fh(g, p, L.container) ? (da = Fh(g, p, L.container), p = h ? Fh(h, p, L.container) : null, u && jg(L, t), u = li(q, k), da = $h(r, q, x, t, a, b, c, L, da, p, u)) : (D || C.log(p, "unxLRB"), da = Promise.resolve(), ci(r, q, x, t, a, b,
                            c, L));
                        c.bg && (t = new Dh(r, c.bg.i, c.bg.p), r.csabg = t);
                        d.push(da);
                        ie[q] = !0;
                        delete Th[q]
                    }
                }
            }
        l.Ka && C.log(l.Ka, "lwf2");
        if (w().data.epte)
            for (b = n(k), c = b.next(); !c.done; c = b.next()) c = ne(c.value, a), null != c && mi(c);
        return te(d).then(function() {
            var Z = z("_optimizeFrameMeasurement");
            ni(a, !!g || Z, Z)
        })
    }
    ki = B(ki, "mPAASH");
    var oi = "function" === typeof ResizeObserver,
        pi = null;

    function ni(a, b, c) {
        function d() {
            var e = me(a).frames;
            if (oi) {
                pi && pi.disconnect();
                var f = c;
                pi = new ResizeObserver(function() {
                    f ? f = !1 : Je(a)
                });
                var g = n(e);
                for (e = g.next(); !e.done; e = g.next()) pi.observe(e.value.document.body)
            } else
                for (g = n(e), e = g.next(); !e.done; e = g.next()) e.value.onresize = function() {
                    Je(a)
                }
        }
        c || d();
        b ? Je(a) : setTimeout(function() {
            Je(a)
        }, 0);
        c && setTimeout(d, 0)
    }

    function li(a, b) {
        var c = a.split("-");
        a = a.split("-");
        c.splice(c.length - 1, 0, "a");
        c = c.join("-");
        a.splice(a.length - 1, 0, "b");
        a = a.join("-");
        var d = [];
        b.includes(c) && d.push(2);
        b.hasOwnProperty(a) && d.push(3);
        return d
    }

    function qi(a, b, c) {
        var d = Math.max.apply(Math, a);
        a = Math.min.apply(Math, a);
        if (d - a > Xd)
            for (d = 0; d < b.length; d++) c[b[d]] = null;
        return c
    }
    qi = B(qi, "pBDF");

    function ri(a, b) {
        for (var c = {}, d = !1, e = [], f = [], g = n(Object.keys(a)), h = g.next(); !h.done; h = g.next())
            if (h = h.value, h in b) {
                var k = b[h],
                    l = a[h];
                "undefined" != typeof l && (l = $d(h, k, l), null != l && (c[h] = l, k.g == Yd && (e.push(l), f.push(h)), d = !0))
            }
        0 < e.length && (c = qi(e, f, c));
        return d ? c : null
    }
    ri = B(ri, "vO");

    function si(a, b) {
        return (ae(a) || /^master-\d+$/.test(a)) && "object" == typeof b
    }
    si = B(si, "iPABO");

    function ti(a) {
        try {
            if (!a) throw Error("Null, undefined or empty window.name.");
            var b = JSON.parse(a)
        } catch (d) {
            var c = d.message;
            a && (c = "Invalid window.name: " + a.split(",")[0]);
            C.log(c, "pNAO")
        }
        return b || {}
    }
    ti = B(ti, "pNAO");

    function ui(a, b) {
        var c = {},
            d;
        for (d in a) {
            var e = a[d];
            "name" == d ? c[d] = ae(e) || /^master-\d+$/.test(e) ? e : null : si(d, e) && (e = ri(e, b), c[d] = e, Th[d] = [])
        }
        return c
    }
    ui = B(ui, "vNAO");

    function vi(a, b, c, d) {
        var e = b.horizontalFlow ? -1 : b.columns;
        if (2 <= e && !(0 >= e)) {
            for (var f = [], g = 0, h = 0; h < e; h++)
                for (var k = Math.ceil((a.length - g) / (e - h)), l = 0; l < k; l++) f[l * e + h] = a[g++];
            a = f
        }
        f = void 0 === d ? !1 : d;
        d = !b.horizontalFlow;
        b = void 0 === f ? !1 : f;
        f = n(a);
        for (g = f.next(); !g.done; g = f.next()) g = g.value, g.t = G(g.t);
        if (c.Cd && 1 == e) {
            b = a.length;
            d = c.Cd.split(",");
            e = [];
            for (f = 0; f < b; f++) e.push(d[f % d.length]);
            b = c.af;
            h = '<div class="' + J("d_") + '">';
            c = a.length;
            for (d = 0; d < c; d++) {
                f = a[d];
                g = void 0;
                k = '<div class="' + J("e_") + '" style="border-' +
                    (b ? "right" : "left") + "-color: " + J(K(e[d])) + '"><a href="' + J(Jf(f.l)) + '" class="' + J("c_") + ' popstripeRs" data-notrack="true" target="_top">' + (f.furl ? '<div class="' + J("f_") + '"><img src="' + J(Of(f.furl)) + '" class="' + J("g_") + '"></div>' : "");
                var q = f.t;
                l = G;
                if (0 < ("" + vf("" + q)).length) {
                    var t = void 0;
                    var p = q;
                    var r = nf(p);
                    if (null != r) p = r;
                    else {
                        t = t || null != p && p.N === af;
                        var x = r = 0,
                            u = !1;
                        t = Ve(p + "", t).split(Ze);
                        for (var D = 0; D < t.length; D++) {
                            var L = t[D];
                            Xe.test(Ve(L)) ? (r++, x++) : Ye.test(L) ? u = !0 : We.test(Ve(L)) ? x++ : $e.test(L) && (u = !0)
                        }
                        r = 0 == x ? u ? 1 : 0 : .4 < r / x ? -1 : 1;
                        null != p && void 0 !== p.R && (p.R = r);
                        p = r
                    }
                    q = '<span dir="' + (0 > p ? "rtl" : "ltr") + '">' + of (q) + "</span>"
                } else q = "";
                l = l(q);
                h += k + l + '<div class="' + J("h_") + '" style="background-image: url(' + J(Of(null != (g = f.adIconUrl) ? g : "//www.gstatic.com/domainads/images/chevron-white.png")) + ')"></div></a></div>'
            }
            a = G(h + "</div>")
        } else {
            f = '<table cellspacing="0" cellpadding="0"' + (2 <= e || d ? ' width="100%"' : "") + "><tbody><tr>";
            c = a.length;
            for (d = 0; d < c; d++) g = a[d], f += (0 != d && 0 < e && 0 == d % e ? "</tr><tr>" : "") + '<td class="col' +
                (d == a.length - 1 ? " l" : "") + '"' + (2 <= e ? ' width="' + J(100 / e) + '%"' : "") + ">", h = 0 > e || 2 <= e && d < e, h = '<div class="ad' + (0 == d ? " f" : "") + (h ? " fr" : "") + (d == a.length - 1 ? " l" : "") + (!h && 2 <= e && d >= a.length - (a.length % e ? a.length % e : e) ? " lr" : "") + '"><div class="' + J("a_") + " " + J("b_") + ' radlinkC">', k = g, k = G(k.adIconUrl ? '<img class="adIcon" src="' + J(Of(k.adIconUrl)) + '"/>' : ""), h = h + k + '<div class="adD">', b ? (k = zf("" + Jf(g.l)), g = xf("" + of (g.t)), g = G('<div class="adStd"><a href="' + J(Jf(k)) + '" class="radlinkButtonLink" data-notrack="true" target="_top">' +
                    G('<span style="height:20px;line-height:20px;width:20px;margin-right:5px"><svg class="radlinkSvg" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path></svg></span>') + g + "</a></div>")) : (k = zf("" + Jf(g.l)), g = xf("" + of (g.t)), g = G('<div class="adStd"><a href="' + J(Jf(k)) +
                    '" class="' + J("c_") + '" data-notrack="true" target="_top">' + g + "</a></div>")), f += h + g + "</div></div></div></td>";
            a = G(f + "</tr></tbody></table>")
        }
        return a
    }
    vi = B(vi, "cRSN");

    function di(a, b, c, d, e) {
        if (!(0 >= a.length)) {
            var f = null;
            if (Oa().data.cucai && !w().P()) {
                var g = "https:" === window.location.protocol;
                null != c.adIconUrl && 0 < c.adIconHeight && 0 < c.adIconWidth && dg(a, c.adIconUrl, g)
            }
            w().P() || jg(c, a);
            d = {
                af: La().xa(),
                Cd: d.popstripeRs
            };
            if (2 === e && !w().P()) f = vi(a, c, d);
            else if (5 === e) {
                d = c.resultsPageBaseUrl;
                if (!d) throw E("resultsPageBaseUrl needs to be set for searchbox blocks.");
                f = a[0].afdt;
                a = a[0].label;
                e = ee(d);
                null != c.personalizedAds && (e.pcsa = "" + c.personalizedAds);
                c = '<div class="adStd"><form action="' +
                    J(Jf(d)) + '" target="_top" method="get" accept-charset="UTF-8">';
                d = uf(e);
                g = d.length;
                for (var h = 0; h < g; h++) {
                    var k = d[h];
                    c += '<input type="hidden" name="' + J(k) + '" value="' + J(e[k]) + '"/>'
                }
                c += '<table class="sb-table" cellspacing="0" cellpadding="0"><tbody><tr><td class="sbi-td"><input class="sbi" type="text" name="query" maxlength="63" title="Enter a search" autocomplete="off"/></td><td><input class="sbb" type="submit" value="' + (a ? J(a) : "Search") + '"/></td></tr></tbody></table><input type="hidden" name="afdToken" value="' +
                    J(f) + '"/><input type="hidden" name="search" value="1"/></form></div>';
                f = G(c)
            }
            c = c = {
                Oa: Ma(La())
            };
            c = G(Qg(c.Oa, "googAFS"));
            ag(c, b);
            f && ag(f, b)
        }
    }
    di = B(di, "cAN");

    function wi(a, b, c) {
        var d = xi(a),
            e = Vh(b),
            f = Oa(),
            g = La(),
            h = w();
        g.data.qi && dd("qi", g.data.qi || null, $c.j);
        var k = g.data.eawp || null;
        k && dd("eawp", k, $c.j);
        (h = !!h.data.sbn) && gd("sbn", h);
        h = !1;
        if (!he())
            for (k = 0; k < d.length; k++) {
                var l = d[k].adtype,
                    q = void 0 != l,
                    t = d[k],
                    p = t.fn;
                p.startsWith("slave-0") && (Uh = !0);
                p = p + "-" + e;
                Th[p] || (C.log(p, "pAJ2"), Th[p] = []);
                Th[p].push(t);
                q && (t = t[l], h = !0)
            }
        if (he()) {
            b = document.getElementById("ssrab");
            b = n(b.children);
            for (g = b.next(); !g.done; g = b.next()) {
                g = g.value;
                var r = g.id.split("-");
                if (!(2 > r.length) &&
                    "ssrad" === r.shift()) {
                    r.push(e.toString());
                    r = r.join("-");
                    var x = parseInt(g.getAttribute("data-num-ads"), 10) || 0;
                    gd(r + ".hA", 0 < x);
                    Pa(f) && fd(r + ".aC", x);
                    yi([g], r);
                    ai(a, r)
                }
            }
            b = ji();
            0 < b.length && (g = "master-" + e, r = b.reduce(function(D, L) {
                return D + parseInt(L.getAttribute("data-num-ads"), 10)
            }, 0), gd(g + ".hA", 0 < r), Pa(f) && fd(g + ".aC", r), yi(b, g), ai(a, g))
        } else
            for (r in Th)
                if (a = Th[r], d = a.length, 0 < d && !h && (k = a[0], 3 == k.type && (d = k.plas ? k.plas.length : 0)), Uh && /^master-\d+$/.test(r)) 0 < d && C.log(a.length, "pAJ3"), delete Th[r];
                else if (gd(r +
                ".hA", 0 < d), Pa(f) && fd(r + ".aC", d), 1 > d) {
            if (a = ne(r, b)) try {
                (x = a.document.getElementById("adBlock")) && ag(Pg({
                    Oa: Ma(g)
                }), x)
            } catch (D) {}
            delete Th[r]
        }
        for (var u in Sh) c[u] && gd(Sh[u], !0);
        (u = c.statusErrorCode) && fd("s.eC", parseInt(u, 10));
        gd("s.b", !!c.statusBlocked);
        La().data.isi && gd("s.iSI", !0);
        Pa(f) && gd("aD." + e, !0);
        ed()
    }
    wi = B(wi, "pAJ");

    function xi(a) {
        var b = [],
            c;
        for (c in Qh) {
            var d = a[c];
            if (d) {
                for (var e = Qh[c], f = 0; f < d.length; f++) d[f].type = "ad_data" == c ? Rh[d[f].adtype] : e;
                b = b.concat(d)
            }
        }
        return b
    }
    xi = B(xi, "cAA");

    function zi(a) {
        return Ih(a)
    }
    zi = B(zi, "cPATO");

    function Ai(a, b, c) {
        oi && z("_optimizeFrameMeasurement") || (window.sPH = function() {
            Je(a)
        });
        window.mPAASH = function() {
            ki(a, b, c)
        };
        return ki(a, b, c)
    }
    Ai = B(Ai, "sCFC");

    function Bi(a, b) {
        var c = Ga(),
            d = zi(c.caps),
            e = ui(b, a);
        wi(c, e, d);
        a = Ai(e, d, c);
        Ta().data.hm && window.addEventListener("message", function(f) {
            f = f.data.split(":");
            2 == f.length && "orientation" == f[0] && Je(e)
        });
        return a
    }
    Bi = B(Bi, "raa");

    function Ci(a, b) {
        Di();
        return Bi(a.yb, b)
    }
    Ci = B(Ci, "init");

    function ji() {
        var a = document.getElementById("adBlock"),
            b = a.querySelector("#ssrad-master"),
            c = a.querySelectorAll('[id^="ssrad-master-"]');
        a = [];
        b && a.push(b);
        b = n(c);
        for (c = b.next(); !c.done; c = b.next())(c = c.value) && a.push(c);
        return a
    }

    function bi(a, b) {
        a = n(a.getElementsByTagName("a"));
        for (var c = a.next(), d = {}; !c.done; d = {
                Cb: d.Cb,
                Db: d.Db
            }, c = a.next()) c = c.value, d.Cb = Ud(c.href, encodeURIComponent(b[b.name].resultsPageQueryParam)), d.Db = Ud(c.href, encodeURIComponent("rsToken")), d.Cb && d.Db ? (c.setAttribute("target", "_self"), c.href = "#", c.addEventListener("click", function(e) {
            return e.preventDefault()
        }), fg(c, function(e) {
            return function() {
                dd("rsrc", {
                    q: e.Cb,
                    rsToken: e.Db,
                    uid: Date.now()
                }, ad.j);
                ed()
            }
        }(d))) : C.log("Could not parse query or rsToken from url: " +
            c.href, "rRHWC")
    }
    bi = B(bi, "rRHWC");

    function Di() {
        dd("it", document.title, $c.j);
        ed()
    }
    Di = B(Di, "setTitle");

    function mi(a) {
        function b(d, e) {
            return {
                type: d,
                touches: e
            }
        }

        function c(d) {
            var e = {},
                f;
            for (f in d) "target" !== f && (e[f] = d[f]);
            return e
        }
        a.document.addEventListener("touchstart", function(d) {
            var e = [].concat(ka(d.touches)).map(function(f) {
                return c(f)
            });
            window.parent.postMessage(b(d.type, e), "*")
        });
        a.document.addEventListener("touchmove", function(d) {
            var e = [].concat(ka(d.touches)).map(function(f) {
                return c(f)
            });
            window.parent.postMessage(b(d.type, e), "*")
        });
        a.document.addEventListener("touchend", function(d) {
            var e = [].concat(ka(d.touches)).map(function(f) {
                return c(f)
            });
            window.parent.postMessage(b(d.type, e), "*")
        });
        a.document.addEventListener("touchcancel", function(d) {
            var e = [].concat(ka(d.touches)).map(function(f) {
                return c(f)
            });
            window.parent.postMessage(b(d.type, e), "*")
        })
    }
    mi = B(mi, "pTETPP");

    function fi(a) {
        var b = document.createElement("meta");
        b.httpEquiv = "origin-trial";
        b.content = "A4TVD0oDoRUnBZgYDdNVARYIPSmJgySEsYdPANRrrgQ7QitPsOty0eZIBsjlHFFJwDFU/8QmnRF2kL5xb4RP9Q4AAACEeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGUuY29tOjQ0MyIsImZlYXR1cmUiOiJQcml2YWN5U2FuZGJveEFkc0FQSXMiLCJleHBpcnkiOjE2OTUxNjc5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9";
        a.document.head.appendChild(b)
    }
    fi = B(fi, "aNCOT");

    function yi(a, b) {
        var c = null;
        a = n(a);
        for (var d = a.next(); !d.done; d = a.next())
            if (d = d.value, d.hasAttribute("data-is-ev") && (d = parseInt(d.getAttribute("data-is-ev"), 10), null === c || d > c)) c = d;
        null !== c && gd(b + ".eV", 1 === c)
    }
    yi = B(yi, "sIEVFS");

    function ai(a, b) {
        "tp" in a && dd(b + ".ptp", a.tp, ad.j)
    }
    ai = B(ai, "sPTP");

    function Ei(a, b) {
        this.ea = a;
        this.ub = b
    }
    Ei.prototype.H = function() {
        var a = this.ea.H() + " (one by itself, or multiple in an Array";
        this.ub && (a += " with fewer than " + (this.ub + 1) + " elements");
        return a + ")"
    };
    Ei.prototype.D = function(a) {
        a = Array.isArray(a) ? a : [a];
        if (this.ub && a.length > this.ub) return null;
        for (var b = [], c = 0; c < a.length; c++) {
            var d = this.ea.D(a[c]);
            if (null == d) return null;
            b.push(d)
        }
        return 0 == b.length ? null : b
    };
    Ei.prototype.G = function(a) {
        a = this.D(a);
        return null == a || 1 > a.length ? null : this.ea.G(a[0])
    };

    function Fi() {}
    Fi.prototype.H = function() {
        return "true, false"
    };
    Fi.prototype.D = function(a) {
        return 0 === a || 1 === a ? 1 === a : "true" == a || "on" == a || 1 == a ? !0 : "false" == a || "off" == a || !1 === a ? !1 : null
    };
    Fi.prototype.G = function(a) {
        a = this.D(a);
        return null == a ? null : a ? 1 : 0
    };
    var N = new Fi;

    function O(a, b) {
        this.Ma = Math.ceil(a);
        this.La = Math.floor(b)
    }
    O.prototype.H = function() {
        return this.Ma + " - " + this.La
    };
    O.prototype.D = function(a) {
        a = parseInt(a, 10);
        return a >= this.Ma && a <= this.La ? a : null
    };
    O.prototype.G = function(a) {
        return this.D(a)
    };

    function Gi() {}
    Gi.prototype.H = function() {
        return "A function"
    };
    Gi.prototype.D = function(a) {
        return "function" === typeof a ? !0 : !1
    };
    Gi.prototype.G = function() {
        return null
    };
    var Hi = new Gi;
    var Ii = /#(.)(.)(.)/;

    function Ji(a) {
        if (!Ki.test(a)) throw Error("'" + a + "' is not a valid hex color");
        4 == a.length && (a = a.replace(Ii, "#$1$1$2$2$3$3"));
        return a.toLowerCase()
    }
    var Ki = /^#(?:[0-9a-f]{3}){1,2}$/i,
        Li = /^(?:rgb)?\((0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2})\)$/i;
    var Mi = {
        black: "#000000",
        blue: "#0000ff",
        darkorange: "#ff8c00",
        darkred: "#8b0000",
        fuchsia: "#ff00ff",
        gray: "#808080",
        green: "#008000",
        grey: "#808080",
        orange: "#ffa500",
        red: "#ff0000",
        royalblue: "#4169e1",
        skyblue: "#87ceeb",
        white: "#ffffff",
        whitesmoke: "#f5f5f5",
        yellow: "#ffff00"
    };

    function Ni(a) {
        this.cd = a
    }
    Ni.prototype.H = function() {
        var a = "A hexadecimal color string";
        this.cd && (a += " or 'transparent'");
        return a
    };
    Ni.prototype.D = function(a) {
        var b = lb("" + a).toLowerCase();
        if (this.cd && "transparent" == b) return "transparent";
        if (Mi[b]) return Mi[b];
        a = null;
        try {
            a = Ji("#" == b.charAt(0) ? b : "#" + b)
        } catch (q) {}
        if (!a) try {
            a: {
                var c = b.match(Li);
                if (c) {
                    var d = Number(c[1]),
                        e = Number(c[2]),
                        f = Number(c[3]);
                    if (0 <= d && 255 >= d && 0 <= e && 255 >= e && 0 <= f && 255 >= f) {
                        var g = [d, e, f];
                        break a
                    }
                }
                g = []
            }
            if (!g.length) throw Error(b + " is not a valid RGB color");
            var h = g[0],
                k = g[1],
                l = g[2];h = Number(h);k = Number(k);l = Number(l);
            if (h != (h & 255) || k != (k & 255) || l != (l & 255)) throw Error('"(' +
                h + "," + k + "," + l + '") is not a valid RGB color');k = h << 16 | k << 8 | l;a = 16 > h ? "#" + (16777216 | k).toString(16).slice(1) : "#" + k.toString(16)
        }
        catch (q) {}
        return a
    };
    Ni.prototype.G = function() {
        return null
    };
    var Oi = new Ni(!1),
        Pi = new Ni(!0);

    function Qi(a) {
        this.ea = a
    }
    Qi.prototype.H = function() {
        return this.ea.H() + " (one or more, comma separated)"
    };
    Qi.prototype.D = function(a) {
        a = Ri(a);
        for (var b = [], c = 0; c < a.length; c++) {
            var d = this.ea.D(a[c]);
            null != d && b.push(d)
        }
        return 0 == b.length ? null : b.join(",")
    };
    Qi.prototype.G = function(a) {
        a = Ri(a);
        for (var b = 0; b < a.length; b++) {
            var c = this.ea.G(a[b]);
            if (null != c) return c
        }
        return null
    };

    function Ri(a) {
        if ("string" !== typeof a) return [];
        a = a.split(",");
        for (var b = [], c = 0; c < a.length; c++) b.push(lb(a[c]));
        return b
    };

    function Si(a, b) {
        b = void 0 === b ? 0 : b;
        this.Vc = a;
        this.Wc = {};
        for (a = 0; a < this.Vc.length; a++) {
            var c = this.Vc[a];
            this.Wc[c.toLowerCase()] = new Ti(c, b + a)
        }
    }
    Si.prototype.H = function() {
        return this.Vc.join(", ") + " (case insensitive)"
    };

    function Ui(a, b) {
        if (!b || "string" !== typeof b) return Vi;
        b = b.toLowerCase();
        return a.Wc.hasOwnProperty(b) ? a.Wc[b] : Vi
    }
    Si.prototype.D = function(a) {
        return Ui(this, a).lf
    };
    Si.prototype.G = function(a) {
        return Ui(this, a).id
    };

    function Ti(a, b) {
        this.lf = a;
        this.id = b
    }
    var Vi = new Ti(null, null);
    var Wi = /^\d+px$/i,
        Xi = /^\d+%$/,
        Yi = /^[0-9]+\.[0-9]{1,}$/;

    function Zi() {}
    Zi.prototype.H = function() {
        return "Width in px (e.g. '500px') or 'auto'"
    };
    Zi.prototype.D = function(a) {
        var b = $i(a);
        return null != b ? b + "px" : "string" !== typeof a || "auto" != a && !Xi.test(a) ? null : a
    };
    Zi.prototype.G = function(a) {
        return $i(a)
    };

    function $i(a) {
        var b;
        (b = "number" === typeof a) || (b = "string" === typeof a && (!/[^0-9]/.test(a) || Yi.test(a) || Wi.test(a)));
        return b ? (a = parseInt(a, 10), isNaN(a) ? null : a) : null
    }
    var aj = new Zi;

    function bj() {}
    bj.prototype.H = function() {
        return "A string"
    };
    bj.prototype.D = function(a) {
        return "string" === typeof a ? a : null
    };
    bj.prototype.G = function() {
        return null
    };
    var cj = new bj;
    var dj = /^[0-9a-zA-Z]*$/;

    function ej() {}
    ej.prototype.G = function() {
        return null
    };
    ej.prototype.H = function() {
        return "A style id"
    };
    ej.prototype.D = function(a) {
        return ("string" === typeof a || "number" === typeof a && !Number.isNaN(a)) && dj.test(a) ? "" + a : null
    };

    function fj() {}
    fj.prototype.H = function() {
        return "An http(s) url"
    };
    fj.prototype.D = function(a) {
        return "string" === typeof a && gj.test(a) ? a : null
    };
    fj.prototype.G = function() {
        return null
    };
    var gj = /^((https?):)?\/\/([a-zA-Z0-9~!@#\$&\*\(\)_\+\-=:;',\.\?\/%]*)$/,
        hj = new fj;
    var ij = new O(2, 400),
        jj = new O(0, 400),
        kj = new O(8, 50),
        lj = new Qi(new Si("verdana;arial;tahoma;times new roman;georgia;trebuchet ms;meiryo;ms gothic;roboto;helvetica neue".split(";"), 1)),
        mj = new Qi(new Si(["right", "left", "top", "bottom"])),
        P = {},
        nj = (P.adsafe = {
                g: new Si(["off", "low", "med", "high"]),
                zc: !0
            }, P.adtest = {
                g: N,
                zc: !0
            }, P.adTest = {
                g: N,
                zc: !0
            }, P.clicktrackUrl = {
                g: new Ei(hj)
            }, P.container = {
                g: cj
            }, P.styleId = {
                g: new ej
            }, P.personalizedAds = {
                g: N
            }, P.personalisedAds = {
                g: N
            }, P.adpage = {}, P.adPage = {}, P.adsResponseCallback = {}, P.bgresponse = {}, P.channel = {}, P.cmpSdkId = {}, P.container = {}, P.cref = {}, P.cx = {}, P.deb = {}, P.debug = {}, P.domainName = {}, P.e = {}, P.expflags = {}, P.fakeads = {}, P.fcap = {}, P.fexp = {}, P.forceEx = {}, P.gcsc = {}, P.gdprApplies = {}, P.iframeHeightCallback = {}, P.jsSrc = {}, P.masterNumber = {}, P.ms = {}, P.noAdLoadedCallback = {}, P.number = {}, P.propertyCode = {}, P.pubId = {}, P.query = {}, P.role = {}, P.rowkeyV2 = {}, P.sbsignals = {}, P.settingsId = {}, P.slaveNumber = {}, P.source = {}, P.source_ip = {}, P.tcString = {}, P.uideb = {}, P.userAgent = {}, P.usPrivacy = {},
            P.uuld = {}, P.sct = {}, P.sc_status = {}, P.adLoadedCallback = {
                g: Hi
            }, P.adRequestUrlParams = {
                g: cj
            }, P.hl = {
                g: cj
            }, P.cpp = {}, P.adfiliateWp = {
                g: cj
            }, P.hotswaps = {}, P),
        Q = {},
        oj = (Q.colorText = {
            g: Oi,
            C: !0,
            A: !0
        }, Q.colorTitleLink = {
            g: Oi,
            C: !0,
            A: !0
        }, Q.colorBorder = {
            g: Oi,
            C: !0,
            A: !0
        }, Q.colorAttribution = {
            g: Oi,
            A: !0
        }, Q.fontFamily = {
            g: lj,
            C: !0,
            A: !0
        }, Q.fontFamilyAttribution = {
            g: lj,
            A: !0
        }, Q.titleBold = {
            g: N,
            C: !0,
            A: !0
        }, Q.rolloverLinkBold = {
            g: N,
            C: !0,
            A: !0
        }, Q.rolloverLinkColor = {
            g: Oi,
            C: !0,
            A: !0
        }, Q.rolloverLinkBackgroundColor = {
            g: Oi,
            C: !0,
            A: !0
        }, Q.rolloverLinkUnderline = {
            g: N,
            C: !0,
            A: !0
        }, Q.noTitleUnderline = {
            g: N,
            A: !0
        }, Q.adBorderSelections = {
            g: mj,
            A: !0
        }, Q.borderSelections = {
            g: mj,
            A: !0
        }, Q.position = {
            g: new Si(["top", "right", "bottom"])
        }, Q.cseGoogleHosting = {
            g: new Si(["full", "iframe", "partner"])
        }, Q.adIconUrl = {
            g: hj,
            A: !0
        }, Q.adIconWidth = {
            g: ij,
            A: !0
        }, Q.adIconHeight = {
            g: ij,
            A: !0
        }, Q.adIconSpacingAbove = {
            g: jj,
            C: !0,
            A: !0
        }, Q.adIconSpacingBefore = {
            g: jj,
            A: !0
        }, Q.adIconSpacingAfter = {
            g: jj,
            A: !0
        }, Q.adIconSpacingBelow = {
            g: jj,
            A: !0
        }, Q.lineHeightTitle = {
            g: kj,
            A: !0
        }, Q.waitForAds = {
            g: N
        }, Q.heightConstrained = {
            g: N,
            ca: "hc"
        }, Q.width = {
            g: aj,
            ca: "wi",
            C: !0
        }, Q.attributionSpacingBelow = {
            g: new O(0, 40),
            A: !0
        }, Q.resultsPageBaseUrl = {
            g: hj
        }, Q.columns = {
            g: new O(1, 20),
            Y: 1
        }, Q.columnSpacing = {
            g: new O(2, 100)
        }, Q.horizontalFlow = {
            g: N
        }, Q.horizontalAlignment = {
            g: new Si(["center", "left", "right"]),
            Y: "left"
        }, Q.resultsPageQueryParam = {
            g: cj,
            Y: "query"
        }, Q.rurlOverride = {
            g: cj
        }, Q.terms = {
            g: cj
        }, Q.kw = {
            g: cj
        }, Q.referrerAdCreative = {
            g: cj
        }, Q.relatedSearchResultClickedCallback = {
            g: Hi
        }, Q.relatedSearchUseResultCallback = {
            g: N
        }, Q.adstyle = {}, Q.afdToken = {}, Q.attmas = {}, Q.gcs = {}, Q.gcse_nc = {}, Q.gl = {}, Q.glp = {}, Q.gm = {}, Q.gr = {}, Q.ie = {}, Q.maxTermLength = {}, Q.maxTop = {}, Q.minTop = {}, Q.numRepeated = {}, Q.oe = {}, Q.queryContext = {}, Q.queryLink = {}, Q.referrer = {}, Q.relatedSearches = {}, Q.visibleUrlsCallback = {}, Q);

    function pj() {}
    pj.prototype.H = function() {
        return "A web font"
    };
    pj.prototype.D = function(a) {
        return "string" !== typeof a || /[^a-zA-Z0-9 ]/.test(a) ? null : a
    };
    pj.prototype.G = function() {
        return null
    };
    var qj = new pj;
    var rj = new O(8, kd),
        sj = {},
        tj = (sj.type = {
            g: new Si(["ads", "textads", "relatedsearch", "searchbox", "dynamic"])
        }, sj.linkTarget = {
            g: new Si(["_top", "_blank"]),
            Y: "_blank",
            C: !0
        }, sj.verticalSpacing = {
            g: new O(2, 24)
        }, sj.fontSizeTitle = {
            g: Yd,
            C: !0,
            Y: 18
        }, sj.fontSizeAttribution = {
            g: Yd,
            C: !0,
            Y: 13
        }, sj),
        R = {},
        uj = (R.colorAdSeparator = {
            g: Oi,
            A: !0
        }, R.rolloverAdBackgroundColor = {
            g: Pi,
            C: !0
        }, R.colorBackground = {
            g: Pi,
            C: !0
        }, R.hideSearchInputBorder = {
            g: N
        }, R.hideSearchButtonBorder = {
            g: N
        }, R.colorSearchBox = {
            g: Pi
        }, R.colorSearchButton = {
            g: Pi
        }, R.colorSearchButtonText = {
            g: Pi
        }, R.widthSearchInput = {
            g: new O(1, 1E3),
            C: !0
        }, R.widthSearchButton = {
            g: new O(100, 1E3),
            C: !0
        }, R.fontSizeSearchInput = {
            g: rj
        }, R.fontSizeSearchButton = {
            g: rj
        }, R.heightSearchInput = {
            g: new O(1, 50)
        }, R.heightSearchButton = {
            g: new O(1, 50)
        }, R.colorSearchButtonBorder = {
            g: Pi
        }, R.widthSearchButtonBorder = {
            g: new O(0, 5)
        }, R.radiusSearchInputBorder = {
            g: new O(0, 20)
        }, R.attributionBold = {
            g: N
        }, R.attributionUppercase = {
            g: N
        }, R.titleUppercase = {
            g: N
        }, R.webFontFamily = {
            g: qj
        }, R.webFontFamilyAttribution = {
            g: qj
        }, R.uiOptimize = {
            g: N
        }, R.ui_optimize = {
            g: N
        }, R.adBorderWidth = {
            g: new O(0, 20)
        }, R.relatedSearchTargeting = {
            g: new Si($a(Zd || []))
        }, R.domainRegistrant = {}, R.domainSessionToken = {}, R.languageCode = {}, R.pageLoadedCallback = {}, R.size = {}, R.hostChannel = {}, R.hostPubId = {}, R),
        yj = {};
    hd(yj, nj);
    hd(yj, oj);
    hd(yj, tj);
    hd(yj, uj);
    id(yj, [
        ["container"], "role"
    ]);
    var zj = {
        yb: yj
    };
    var Aj = {},
        Bj = (Aj.rolloverAdBackgroundColor = {
            g: Oi,
            C: !0,
            A: !0
        }, Aj.colorBackground = {
            g: Oi,
            C: !0,
            A: !0
        }, Aj.verticalSpacing = {
            g: new O(2, 34)
        }, Aj.type = {
            g: new Si(["ads", "relatedsearch"])
        }, Aj.fontSizeTitle = {
            g: Yd,
            C: !0,
            A: !0
        }, Aj.fontSizeAttribution = {
            g: Yd,
            C: !0,
            A: !0
        }, Aj.linkTarget = {
            g: new Si(["_top", "_blank"]),
            Y: "_top",
            C: !0
        }, Aj),
        Cj = {};
    hd(Cj, nj);
    hd(Cj, oj);
    hd(Cj, Bj);
    id(Cj, ["query", ["container"], "role"]);
    var Dj = {
        yb: Cj
    };
    var Ej = {},
        Fj = (Ej.disableCarousel = {
            g: N,
            ca: "dc"
        }, Ej.enableInteractive = {
            g: N,
            ca: "ei"
        }, Ej.height = {
            g: new O(0, 1E4),
            ca: "he"
        }, Ej.merchantFilter = {}, Ej.priceCurrency = {}, Ej.priceMax = {}, Ej.priceMin = {}, Ej.promoted = {}, Ej.testgl = {}, Ej.textColorPalette = {}, Ej.theme = {}, Ej),
        Gj = {},
        Hj = (Gj.width = {
            g: new O(0, 1E4),
            ca: "wi"
        }, Gj.linkTarget = {
            g: new Si(["_top", "_blank"]),
            Y: "_top",
            C: !0
        }, Gj.type = {
            g: new Si(["plas"])
        }, Gj),
        Ij = {};
    hd(Ij, Hj);
    hd(Ij, nj);
    hd(Ij, Fj);
    id(Ij, [
        ["container"],
        ["height"],
        ["width"], "query", "role"
    ]);
    var Jj = {
        yb: Ij,
        Za: "plas"
    };

    function Kj() {
        var a = window.AFS_AD_REQUEST_RETURN_TIME_;
        a && dd("irt", a + "|" + Date.now(), $c.j);
        a = ti(window.name);
        switch ((a[a.name] || {}).type) {
            case "plas":
                Ci(Jj, a);
                break;
            default:
                Ci(Dj, a)
        }
        setTimeout(function() {
            try {
                var b = document.getElementById("response_debug_output");
                if (b) {
                    var c = document.getElementById("adBlock");
                    c && (b.parentNode.removeChild(b), 0 == c.childNodes.length ? c.appendChild(b) : c.insertBefore(b, c.childNodes[0]))
                }
            } catch (d) {}
        }, 0)
    }
    window.IS_GOOGLE_AFS_IFRAME_ && Kj();

    function Lj(a, b) {
        b = void 0 === b ? {} : b;
        this.Ea = a;
        this.oa = null;
        this.zd = {};
        this.le = 0;
        this.Ob = null;
        var c;
        this.timeoutMs = null != (c = b.timeoutMs) ? c : 500
    }
    ra(Lj, eg);

    function Mj(a) {
        var b;
        return "function" === typeof(null == (b = a.Ea) ? void 0 : b.__uspapi) || null != a.Ca()
    }

    function Nj(a, b) {
        var c = {};
        if (Mj(a)) {
            var d = Va(function() {
                b(c)
            });
            Oj(a, function(e, f) {
                f && (c = e);
                d()
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    }

    function Oj(a, b) {
        var c;
        "function" === typeof(null == (c = a.Ea) ? void 0 : c.__uspapi) ? (a = a.Ea.__uspapi, a("getUSPData", 1, b)) : a.Ca() && (Pj(a), c = ++a.le, a.zd[c] = b, a.oa && (b = {}, a.oa.postMessage((b.__uspapiCall = {
            command: "getUSPData",
            version: 1,
            callId: c
        }, b), "*")))
    }
    Lj.prototype.Ca = function() {
        return this.oa ? this.oa : this.oa = Ah(this.Ea, "__uspapiLocator")
    };

    function Pj(a) {
        a.Ob || (a.Ob = function(b) {
            try {
                var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__uspapiReturn;
                var d;
                null == (d = a.zd) || d[c.callId](c.returnValue, c.success)
            } catch (e) {}
        }, yh(a.Ea, "message", a.Ob))
    };
    var Rj = F(function() {
        var a = bc("uatm"),
            b = null != a ? a : 5;
        a = new Lj(window);
        return Mj(a) ? (a = Qj(a), Promise.race([a, se(b, 4)]).then(function(c) {
            return 2 === c ? {
                Ab: !1,
                da: c
            } : 4 === c ? (console.warn("Reached" + b + "ms timeout and before USP response was received."), {
                Ab: !1,
                da: c
            }) : 6 === c ? {
                Ab: !1,
                da: c
            } : {
                Ab: !0,
                da: c
            }
        })) : null
    }, "gCAD");

    function Qj(a) {
        function b(d) {
            d && "string" === typeof d.uspString ? c.resolve(Sj(d.uspString)) : c.resolve(3)
        }
        var c = qe();
        try {
            Nj(a, b)
        } catch (d) {
            c.resolve(6), console.warn("USP returned error status: " + d)
        }
        return c.promise
    }

    function Sj(a) {
        if (/^[1-9][nyNY\-][nyNY][nyNY\-]$/.test(a)) {
            var b = a.charAt(2);
            if (/^Y|y/.test(b)) return 2;
            if (/^N|n/.test(b)) return 1
        }
        if ("1---" === a) return 5;
        b = "3:" + a;
        console.warn("CCPA US Privacy string " + a + " is malformed and personalization intent was unable to be fetched.");
        return b
    };

    function Tj() {}
    Tj.prototype.Fa = function() {
        return oc()
    };
    Tj.prototype.sd = function(a) {
        return new qc(this.Fa(a) + "/afs/ads")
    };
    Tj.prototype.wd = function() {
        return !1
    };

    function Uj(a, b, c, d) {
        this.Nd = a;
        this.Ub = b;
        this.Xa = c;
        this.xd = d;
        this.Kb = !1;
        this.lc = 0
    }

    function Vj(a, b, c, d) {
        d = void 0 === d ? {} : d;
        a.Nd--;
        a.Kb = a.Kb || b;
        c > a.lc && (a.lc = c);
        if (0 == a.Nd)
            if (a.Kb) {
                if (a.Xa) {
                    b = void 0;
                    switch (a.lc) {
                        case 2:
                            b = !0;
                            break;
                        case 1:
                            b = !1
                    }
                    try {
                        a.Xa(a.Ub, !0, b, d)
                    } catch (e) {}
                }
            } else {
                if (a.xd) try {
                    a.xd(a.Ub, !1, void 0, d)
                } catch (e) {}
                if (a.Xa) try {
                    a.Xa(a.Ub, !1, void 0, d)
                } catch (e) {}
            }
    };

    function Wj() {
        if (z("_afsRsCookieless") || z("_switchGwsRequestToUseCookielessDomain") || z("_switchGwsRequestToUseCookielessDomainChrome") || z("_enableMcmExperiment")) return 0;
        if ("number" === typeof v.experimentId_) return v.experimentId_;
        var a = "object" === typeof testingData_ ? testingData_.experimentMod : bc("rsm") || 0;
        v.experimentId_ = 0;
        if (0 === a) return v.experimentId_;
        var b = "object" === typeof testingData_ ? testingData_.timeId : (new Date).getTime().toString(),
            c = "object" === typeof testingData_ ? testingData_.layerId :
            17301273,
            d = 3735928559 ^ c;
        c ^= 1103547991;
        for (var e = 0, f; e < b.length; e++) f = b.charCodeAt(e), d = Math.imul(d ^ f, 2654435761), c = Math.imul(c ^ f, 1597334677);
        d = Math.imul(d ^ d >>> 16, 2246822507);
        d ^= Math.imul(c ^ c >>> 13, 3266489909);
        c = Math.imul(c ^ c >>> 16, 2246822507);
        c ^= Math.imul(d ^ d >>> 13, 3266489909);
        b = (4294967296 * (2097151 & c) + (d >>> 0)) % 1E3;
        b < a ? v.experimentId_ = "object" === typeof testingData_ ? testingData_.experimentId : 17301368 : b >= 1E3 - a && (v.experimentId_ = "object" === typeof testingData_ ? testingData_.controlId : 17301367);
        return v.experimentId_
    };
    var Xj = window;

    function Yj(a, b) {
        a && null !== b && b != b.top && (b = b.top);
        try {
            return Hd(b || window).round()
        } catch (c) {
            return new Cd(-12245933, -12245933)
        }
    };

    function S(a, b, c, d, e, f, g, h, k, l) {
        l = void 0 === l ? [] : l;
        this.J = a;
        this.ba = this.aa = this.Z = 0;
        this.options = {};
        this.container = null;
        this.ga = void 0 === k ? 1 : k;
        this.Ra = c;
        this.T = h || [];
        this.yd = e || null;
        this.Ja = this.jd = this.bb = !1;
        this.U = new uc(null);
        this.Rc = this.wa = this.Da = this.Kd = "";
        this.qb = this.I = !1;
        this.qd = "";
        this.ab = new qc("");
        this.ka = l;
        this.Lc = this.va = this.lb = 0;
        this.pf = d;
        this.Aa = null;
        this.Zc = [];
        this.na = {};
        this.ja = this.tb = null;
        this.vc(b, f, g, h)
    }
    m = S.prototype;
    m.Wb = function(a) {
        if (this.I) return "n0";
        var b = this.aa,
            c = this.Z,
            d = this.ba;
        null != a && (b += "minTop" in a ? a.minTop : 0, c += "maxTop" in a ? a.maxTop : 0, d += "rhs" in a ? a.rhs : 0);
        if (c && b > c) throw E("Cannot request more minTop ads than maxTop.");
        return (0 < d ? "n" + d : "") + (0 < c ? "p" + c : "") + (0 < b ? "a" + b : "")
    };
    m.Zb = function(a, b) {
        a = this.X(a);
        b && 0 < b.length && (b.splice(0, 0, a), a = b.join("|"));
        return a
    };
    m.X = function(a) {
        this.ba = a.number || 0;
        this.aa = a.minTop;
        this.Z = a.maxTop;
        this.ba || this.aa || this.Z || (this.ba = 2);
        if (this.ba && (this.Z || this.aa)) throw E("Cannot request standard and top ads in the same ad block.");
        if (this.I && 0 != a.slaveNumber && !a.firstTextAdBlock && (this.Z || this.aa)) throw E("Only the first ad block can have top ads.");
        var b;
        this.Z || this.aa ? b = "p" : this.ba && (b = "n");
        return "" + b + (this.Z || this.aa || this.ba || 0)
    };
    m.Md = function() {};

    function Zj() {
        var a;
        return !(null == (a = document.featurePolicy) || !a.allowsFeature("attribution-reporting"))
    }
    m.Xc = function(a, b, c) {
        var d = {};
        a.settingsId && !a.styleId && (a.styleId = a.settingsId);
        delete a.settingsId;
        a.hasOwnProperty("personalisedAds") && (a.hasOwnProperty("personalizedAds") ? a.personalizedAds = a.personalisedAds && a.personalizedAds : a.personalizedAds = a.personalisedAds);
        a.hasOwnProperty("personalizedAds") && delete a.personalisedAds;
        a.referrerAdCreative && (a.kw ? console.warn("Cannot set both referrerAdCreative and kw, ignoring referrerAdCreative") : a.kw = a.referrerAdCreative, delete a.referrerAdCreative);
        a.cmpSdkId &&
            !a.tcString && (a.tcString = "tcunavailable");
        1 == a.gdprApplies ? a.gdprApplies = !0 : 0 == a.gdprApplies && (a.gdprApplies = !1);
        if (a.usPrivacy) {
            var e = Sj(a.usPrivacy);
            a.cpp = e;
            2 === e && (d.personalizedAds = !1)
        }!0 === a.plasInCarousel ? d.plasInCarousel = 1 : !1 === a.plasInCarousel && (d.plasInCarousel = 0);
        "plas" == a.type && a.styleId && (this.J.width.xc = !1, this.J.height.xc = !1);
        e = n(Object.keys(this.J));
        for (var f = e.next(); !f.done; f = e.next()) {
            f = f.value;
            if (this.J[f].xc && ("query" == f && (null == a[f] || "" == a[f]) || "query" != f && !a[f])) throw E("Missing option '" +
                f + "'.");
            "undefined" != typeof a[f] && null != a[f] && (d[f] = a[f])
        }
        a.rurlOverride && (console.warn("adtest is enabled when an rurlOverride value is provided"), d.adtest = "on");
        if (e = de(v.location.href, "google_afsexp")) d.afsexp = e, d.adtest = "on", console.warn("adtest is enabled when google_afsexp is used");
        this.I = "m" != a.role;
        this.Qb(d);
        this.I || (e = de(window.location.href, "rsToken")) && (d.afdToken = e);
        d.adLoadedCallback = a.adLoadedCallback || a.callback || null;
        d.oe = d.oe || "UTF-8";
        d.ie = d.ie || "UTF-8";
        d.number = ak(d.number);
        d.minTop =
            ak(d.minTop);
        d.maxTop = ak(d.maxTop);
        d.fexp = (d.fexp ? d.fexp + "," : "") + (d.gcsc ? "20606" : "21404");
        (e = ac("cei", cc()) || "") && (d.fexp += "," + e);
        ac("jbd1", cc()) && (d.fexp += ",17301217"); - 1 != this.Ra.Fa(d.pubId).indexOf("afs.googlesyndication") && (d.fexp += ",17301248");
        17301367 === Wj() && (d.fexp += ",17301367");
        17301368 === Wj() && (d.fexp += ",17301368");
        void 0 != d.forceEx && ("MostLaunches" === d.forceEx ? (d.e = "MostLaunches", delete d.forceEx) : d.e || (d.e = "OnlyForcedExperiments"));
        d.gcsc && "top" == a.position && (d.maxTop = a.number, d.number =
            null);
        d.format = this.I ? this.X(d) : this.Zb(d, b);
        this.qd = d.format;
        d.ads = this.Wb(c);
        d.nocache = [Math.floor(1E3 * Math.random()), Date.now()].join("");
        d.num = "0";
        d.output = this.Ra.rc();
        if (this.Ra.wd()) try {
            d.domainName || (d.domainName = window.document.domain), d.domainName = d.domainName.substring(0, 80)
        } catch (g) {} else delete d.domainName;
        d.gcsc && (d.source = "gcsc");
        d.v = "3";
        "string" !== typeof d.pubId && (d.pubId = "" + d.pubId);
        0 == d.pubId.indexOf("partner-") && (d.pubId = d.pubId.substring(8));
        "undefined" !== typeof d.hostPubId &&
            (d.hostPubId = String(d.hostPubId).replace(/^partner-/, ""));
        d = bk(d);
        !d.titleBold || !0 !== d.titleBold && 1 != d.titleBold ? d.titleBold && delete d.titleBold : d.titleBold = 1;
        this.Md(d);
        return d
    };
    m.Bc = function(a) {
        var b = [],
            c;
        for (c in a) a.hasOwnProperty(c) && c in this.J && this.J[c].ca && b.push(ck(a[c], this.J[c]));
        return b.join("")
    };
    m.za = function(a, b) {
        var c = [],
            d;
        for (d in a) !(a.hasOwnProperty(d) && d in this.J && this.J[d].ca) || d in b && b[d] == a[d] || c.push(ck(a[d], this.J[d]));
        return c.join("")
    };
    m.dc = function(a, b, c) {
        var d = b.filter(function(f) {
            return 1 === f.ga
        });
        if (0 == d.length) return this.za(a, {}) + "-";
        c.pubId = a.pubId;
        c = bk(c);
        b = this.Bc(c);
        var e = [];
        e.push(this.za(a, c));
        a = n(d);
        for (d = a.next(); !d.done; d = a.next()) d = d.value, d.options.slaveNumber && 0 != d.options.slaveNumber && e.push(this.za(d.options, c));
        return [b, e.join("-")].join("-")
    };

    function dk(a) {
        return a.options && a.options.type ? "searchbox" === a.options.type : !1
    }

    function ek(a) {
        var b;
        return null != (b = a.options) && b.type ? "relatedsearch" === a.options.type : !1
    }
    m.Yb = function(a, b) {
        var c = /^[A-Za-z]+[\w\-:\.]*$/,
            d = [];
        this.qb || dk(this) || (a = a.container, d.push(c.test(a) ? a : ""));
        b = n(b);
        for (a = b.next(); !a.done; a = b.next()) a = a.value, dk(a) || 1 !== a.ga || (a = a.options.container, d.push(c.test(a) ? a : ""));
        return d.join("|")
    };
    m.ec = function(a) {
        var b = this.Ra.sd(a.pubId);
        this.Lb(a, b);
        3 == window.googleAltLoader ? A(b, "bsl", 8) : 4 == window.googleAltLoader && A(b, "bsl", 10);
        A(b, "pac", fk(a));
        if (!this.I) {
            var c = void 0 === c ? window : c;
            var d = void 0 === d ? document : d;
            var e = void 0 === e ? new Date : e;
            var f = c;
            f = void 0 === f ? Xj : f;
            try {
                var g = f.history.length
            } catch (l) {
                g = 0
            }
            A(b, "u_his", g);
            A(b, "u_tz", -e.getTimezoneOffset());
            A(b, "dt", e.getTime());
            A(b, "u_w", c.screen.width);
            A(b, "u_h", c.screen.height);
            e = Yj(!0, c);
            A(b, "biw", e.width);
            A(b, "bih", e.height);
            c.top != c && (e =
                Yj(!1, c), A(b, "isw", e.width), A(b, "ish", e.height));
            d.body ? (e = !c.scrollY && "CSS1Compat" != d.compatMode, d = new Cd(e ? d.body.scrollWidth : d.body.offsetWidth, e ? d.body.scrollHeight : d.body.offsetHeight)) : d = new Cd(-1, -1);
            A(b, "psw", d.width);
            A(b, "psh", d.height);
            if (c.top == c) var h = 0;
            else {
                c = c.top;
                try {
                    var k;
                    if (k = !!c && null != c.location.href) b: {
                        try {
                            nd(c.foo);
                            k = !0;
                            break b
                        } catch (l) {}
                        k = !1
                    }
                    h = k
                } catch (l) {
                    h = !1
                }
                h = h ? 1 : 2
            }
            A(b, "frm", h)
        }
        A(b, "cl", 579967862);
        A(b, "uio", this.Kd);
        A(b, "cont", this.Yb(this.options, this.T));
        A(b, "jsv", (579967862).toString(), !0);
        a.rurlOverride ? A(b, "rurl", a.rurlOverride, !0) : (h = window.location.href, 0 == h.indexOf("about:") && window.location.ancestorOrigins && window.location.ancestorOrigins.length && 0 < window.location.ancestorOrigins.length && (h = window.location.ancestorOrigins[0]), A(b, "rurl", h, !0));
        A(b, gk.referer, document.referrer, !0);
        a.referrer && A(b, "optref", a.referrer, !0);
        void 0 !== Object.getOwnPropertyDescriptor(document, "referrer") && (a = this.U, h = wc(a), A(h, "pbt", "ri"), A(h, "emsg", "rm"), a.ia(rc(h)));
        A(b, "jsid", "csa");
        lc() && Zj() &&
            A(b, "nfp", "1");
        return b
    };
    m.Lb = function(a, b) {
        for (var c in a)
            if (a.hasOwnProperty(c) && gk.hasOwnProperty(c)) {
                var d = gk[c],
                    e = a[c];
                "clkwd" == d && (e = "t");
                "type" == d && (e = Wd[a[c]]);
                "domainSessionToken" == c && "afdToken" in a && d == gk.afdToken || A(b, d, e)
            }
    };
    m.F = function() {
        var a = [];
        "m" == this.options.role || void 0 === this.options.slaveNumber ? a.push("master") : (a.push("slave"), a.push(this.options.slaveNumber));
        2 == this.ga ? a.push("a") : 3 == this.ga && a.push("b");
        a.push(this.options.masterNumber);
        return a.join("-")
    };
    m.qc = function(a, b, c, d) {
        var e = {};
        e.name = b;
        a = c.concat([a]);
        b = d.concat([b]);
        for (d = 0; d < a.length; d++) {
            c = b[d];
            var f = void 0,
                g = a[d],
                h = this.J,
                k = {};
            for (f in h)
                if (h.hasOwnProperty(f) && !h[f].zc) {
                    var l = g[f],
                        q = h[f].Y;
                    "undefined" == typeof l || "container" == f && "object" == typeof l ? "undefined" != typeof q && (k[f] = q) : k[f] = l
                }
            e[c] = k
        }
        return JSON.stringify(e)
    };
    m.oc = function(a, b, c, d) {
        this.lb = Date.now();
        document.getElementById(a) && C.log("iframe: " + a + ". pubId: " + d + ". ", "dI");
        d = Kd(document, "IFRAME");
        d.frameBorder = "0";
        d.marginWidth = "0";
        d.marginHeight = "0";
        d.vspace = 0;
        d.hspace = 0;
        d.setAttribute("allowTransparency", "true");
        d.scrolling = "no";
        d.style.visibility = "hidden";
        d.width = "100%";
        d.style.height = "0px";
        d.style.display = "block";
        d.name = b;
        d.id = a;
        d.src = c;
        fe() ? (d.dataset.observe = this.options.masterNumber, this.I || (d.setAttribute("data-ad-src", c), d.src = "about:blank")) : this.va =
            this.lb;
        2 === this.ga && 1 <= this.container.childElementCount ? this.container.insertBefore(d, this.container.children[0]) : 1 === this.ga && 2 === this.container.childElementCount ? this.container.insertBefore(d, this.container.children[1]) : this.container.appendChild(d);
        try {
            d.contentWindow.name = b
        } catch (e) {}
        w().data.icelae && Zj() && d.setAttribute("allow", "attribution-reporting");
        return d
    };
    m.Sb = function(a) {
        var b = window.innerWidth < window.innerHeight;
        if (this.Ja && !b || !this.Ja && b) {
            this.Ja = b;
            try {
                a.contentWindow.postMessage("orientation:" + (this.Ja ? "portrait" : "landscape"), "*")
            } catch (c) {}
        }
    };
    m.uc = function(a, b, c, d) {
        var e = this,
            f = this.oc(a, b, c, d);
        this.I || (this.wc(f), this.Ja = window.innerWidth < window.innerHeight, window.addEventListener("resize", function() {
            return e.Sb(f)
        }))
    };
    m.Cc = function() {
        var a = {},
            b;
        for (b in this.options) this.options.hasOwnProperty(b) && (a[b] = this.options[b]);
        a.ads = "n0";
        a[""] = "";
        a.slaveNumber = "0";
        a.role = "s";
        a = hk(this.J, a, Date.now(), void 0, void 0, void 0, void 0, 1, this.ka);
        V[a.F()] = a;
        this.T.splice(0, 0, a);
        a = document.createElement("div");
        document.body.appendChild(a);
        a.style.height = "0px";
        a.style.visibility = "hidden";
        this.options.container = a;
        this.qb = this.options.preload = !0;
        this.ka = []
    };
    m.vc = function(a, b, c, d) {
        this.options = this.Xc(a, b, c, d);
        this.U.client = this.options.pubId;
        this.U.Gb = this.options.styleId || "";
        !z("_forceJsPreloadForDebugging") && this.gb() || this.I || !document.body || this.Cc();
        this.Kd = null == this.yd ? "" : this.dc(this.options, this.T, this.yd);
        this.wa = this.Da = this.F();
        this.ab.ic = encodeURI(this.Da);
        if (1 === this.ga && !z("_enableUnifiedMudskipperIframe"))
            for (this.Aa = new Uj(this.ka.length + 1, this.options.container, this.options.adLoadedCallback, this.options.noAdLoadedCallback), a = n(this.ka),
                b = a.next(); !b.done; b = a.next()) b.value.Aa = this.Aa;
        if (!this.I) {
            vc().client = this.options.pubId;
            vc().Gb = this.options.styleId || "";
            a = [];
            b = [];
            for (c = 0; c < this.T.length; c++) a.push(this.T[c].F()), b.push(this.T[c].options);
            this.wa = this.qc(this.options, this.Da, b, a)
        }
    };
    m.eb = function() {
        var a = this,
            b = qe(),
            c = F(function() {
                if (!a.gb()) return !1;
                a.Fb(a.options.container);
                if (a.options.width && !a.qb) {
                    if ("plas" == a.options.type && void 0 != a.J.width && null == a.J.width.g.D(a.options.width)) throw E("width " + a.options.width + " is invalid.");
                    "auto" == a.options.width ? a.container.style.width = "100%" : ik(a.options.width) && (a.container.style.width = a.options.width)
                }
                for (var f = n([].concat(a.ka, a)), g = f.next(); !g.done; g = f.next()) {
                    g = g.value;
                    g.Fb(a.options.container);
                    var h = g.Ra.Fa(a.options.pubId);
                    h = new qc(h + "/afs/ads/i/iframe.html");
                    g.ab = (g.I ? h : null) || g.ec(g.options);
                    g.Rc = rc(g.ab)
                }
                if (!a.I && a.options.hasOwnProperty("tcString") && 0 < a.options.tcString.length && !a.Rc.includes(gk.tcString + "=")) throw yc(a.U, "tl", "TC string of length " + a.options.tcString.length + " does not fit in URL"), E("A transparency consent string was collected but is too long to fit in the CSA ad request URL. No ads are being requested.");
                a.container.textContent = "";
                if (!z("_enableUnifiedMudskipperIframe"))
                    for (f = n(a.ka), g = f.next(); !g.done; g =
                        f.next()) g.value.wb();
                a.wb();
                b.resolve(a);
                return !0
            }, "cI_mA");
        if (!c()) var d = Date.now(),
            e = window.setInterval(function() {
                if (c()) clearInterval(e);
                else if (6E4 < Date.now() - d) throw clearInterval(e), E('container "' + a.options.container + '" does not exist.');
            }, 5);
        return b.promise
    };
    m.wb = function() {
        this.ab && this.uc(this.Da, this.wa, this.Rc, this.options.pubId)
    };
    m.Tc = function(a) {
        var b = this;
        if (this.jd) {
            var c = this.F(),
                d = document.getElementById(c);
            setTimeout(function() {
                return b.Eb(d, c, a, !0)
            }, 1500)
        }
    };
    m.wc = function(a) {
        var b = this,
            c = "" + this.options.masterNumber,
            d = new Mc(c, a);
        Pc(d, "aD." + c, Yc.j, jk);
        Pc(d, "qi", $c.j, function(g, h, k, l) {
            g = n([].concat(b.T, b));
            for (h = g.next(); !h.done; h = g.next()) h.value.U.Ic = l || ""
        });
        Pc(d, "eawp", $c.j);
        Pc(d, "it", $c.j, function(g, h, k, l) {
            a.title = l
        });
        Pc(d, ".aCS", Zc.j, function(g, h, k, l) {
            kk(b, l)
        });
        var e = null;
        this.qb || (e = this.F(), Pc(d, e + ".hA", Yc.j, lk), Pc(d, e + ".fs", ad.j, mk), Pc(d, e + ".w", Zc.j, function(g, h, k, l) {
            nk(g, h, k, l)
        }), Pc(d, e + ".aC", Zc.j));
        Pc(d, "v." + c, $c.j, ok);
        var f = this.options.relatedSearchResultClickedCallback;
        this.options.relatedSearchUseResultCallback && f && Pc(d, "rsrc", ad.j, function(g, h, k, l) {
            try {
                f(l.q, l.rsToken)
            } catch (q) {}
        });
        c = n(this.T);
        for (e = c.next(); !e.done; e = c.next()) e = e.value.F(), Pc(d, e + ".hA", Yc.j, lk), Pc(d, e + ".fs", ad.j, mk), Pc(d, e + ".aC", Zc.j)
    };

    function kk(a, b) {
        a.tb = b;
        if (!a.ja) {
            var c = ["mousemove", "mousedown", "scroll", "keydown", "touchstart"];
            a.ja = function() {
                if (a.tb) {
                    var e = Date.now() - a.tb;
                    if (e <= (bc("mdp") || 0)) {
                        var f = a.U,
                            g = wc(f);
                        A(g, "pbt", "cd");
                        A(g, "csacd", e);
                        f.ia(rc(g));
                        a.tb = null
                    }
                }
                if (a.ja) {
                    e = n(c);
                    for (f = e.next(); !f.done; f = e.next()) document.body.removeEventListener(f.value, a.ja);
                    a.ja = null
                }
            };
            b = n(c);
            for (var d = b.next(); !d.done; d = b.next()) document.body.addEventListener(d.value, a.ja)
        }
    }
    m.Ac = function(a) {
        if (!this.bb) {
            this.bb = !0;
            if (z("_enableUnifiedMudskipperIframe")) {
                var b = this.options.container,
                    c = this.options.noAdLoadedCallback,
                    d = this.options.adLoadedCallback;
                if (c) try {
                    c(b, !1, void 0, this.na)
                } catch (e) {}
                if (d) try {
                    d(b, !1, void 0, this.na)
                } catch (e) {}
            } else Vj(this.Aa, !1, 0, this.na);
            Oc(a, "sbn") && (b = this.F(), c = document.getElementById(b), this.Lc = Date.now(), this.Eb(c, b, a, !1))
        }
    };
    m.Pc = function(a, b) {
        var c = gc(ic),
            d = gc(kc);
        /Mobile/i.test(ec) && (0 < c || 0 < d) ? (a.style.width = "1px", a.style.minWidth = "100%", a.removeAttribute("width")) : a.width = "100%";
        a.style.visibility = 0 < b ? "visible" : "hidden";
        a.style.height = b + "px";
        this.container.style.height = "auto"
    };
    m.Oc = function(a) {
        this.container.style.width = a + "px";
        var b = gc(ic),
            c = gc(kc);
        if (0 < b || 0 < c)
            if (b = document.getElementById(this.F())) b.style.width = a + "px", b.removeAttribute("width")
    };

    function pk(a) {
        if (fe() && !a.I) {
            var b = '[data-observe="' + a.options.masterNumber + '"]',
                c = function() {
                    var l = document.getElementById(a.F()),
                        q = ib(l.getAttribute("data-ad-src"));
                    l.src = hb(q).toString();
                    a.va = Date.now();
                    q = n(a.T);
                    for (var t = q.next(); !t.done; t = q.next()) t.value.va = a.va;
                    l.removeAttribute("data-ad-src")
                },
                d = bc("llrm") || 0,
                e = ek(a);
            e = z("_enableLLIDM") || z("_enableLLIDMRSOnly") && e;
            for (var f = n(document.querySelectorAll("iframe" + b)), g = f.next(); !g.done; g = f.next())
                if (g = g.value, null == g.offsetParent || ge(g, e ? d :
                        0)) {
                    c();
                    return
                }
            var h = document.querySelectorAll("iframe" + b),
                k = new IntersectionObserver(function(l) {
                    if (l.find(function(t) {
                            return 0 < t.intersectionRatio
                        })) {
                        c();
                        l = n(h);
                        for (var q = l.next(); !q.done; q = l.next()) k.unobserve(q.value)
                    }
                }, {
                    rootMargin: "0px 0px " + d + "px 0px",
                    threshold: 0
                });
            b = n(h);
            for (g = b.next(); !g.done; g = b.next()) d = g.value, k.observe(d), d.setAttribute("data-lle", "1")
        }
    }
    m.ob = function(a) {
        return ge(a, 0, .3)
    };
    m.Eb = function(a, b, c, d) {
        var e = this,
            f = Od(a),
            g = {
                top: f.y,
                left: f.x,
                height: a.offsetHeight,
                width: a.offsetWidth,
                Wa: this.Zc.join(","),
                he: b,
                Fe: Nc(c, "eawp"),
                se: (579967862).toString(),
                Mf: a.hasAttribute("data-lle"),
                We: this.ob(a),
                Pe: null != this.options.clicktrackUrl
            };
        if (b = qk(this, c)) g.df = b;
        if (d) {
            xc(this.U, "bs", g);
            var h = null;
            h = setInterval(F(function() {
                e.ob(a) && (xc(e.U, "bv", g), clearInterval(h))
            }, "sPIV"), 500)
        } else xc(this.U, "bn", g)
    };

    function qk(a, b) {
        if (b = Nc(b, "irt")) {
            var c = b.split("|");
            b = parseInt(c[0], 10);
            c = parseInt(c[1], 10);
            var d = a.lb - a.pf,
                e = a.va - a.lb;
            a.I && (e = Math.max(0, e));
            return [d, e, b - a.va, c - b, a.Lc - c].join("|")
        }
        return null
    }
    m.Mc = function(a, b) {
        var c = this.F(),
            d = document.getElementById(c);
        if (d) {
            var e = a.frameHeight;
            this.Zc = a.Wa;
            this.Pc(d, e);
            if (!this.bb && 0 < e) {
                this.Lc = Date.now();
                this.jd = this.bb = !0;
                this.Tc(b);
                var f;
                a = null != (f = Oc(b, c + ".eV")) ? f : void 0;
                c += ".ptp";
                if (b = b.B.hasOwnProperty(c) ? b.B[c].value : null) this.na.termPositions = b;
                if (z("_enableUnifiedMudskipperIframe")) {
                    if (b = this.options.adLoadedCallback) {
                        c = this.options.container;
                        try {
                            b(c, !0, a, this.na)
                        } catch (g) {}
                    }
                } else b = 0, !0 === a ? b = 2 : !1 === a && (b = 1), Vj(this.Aa, !0, b, this.na)
            }
        }
    };
    m.gb = function() {
        var a = this.options.container;
        return "string" == typeof a ? (a = document.getElementById(a), !!a) : "string" == typeof a.innerHTML ? !0 : !1
    };
    m.Fb = function(a) {
        this.container = "string" == typeof a ? document.getElementById(a) : a
    };
    m.Qb = function(a) {
        a.hasOwnProperty("resultsPageBaseUrl") && (a.resultsPageBaseUrl = rk(a.resultsPageBaseUrl));
        var b = a.relatedSearchTargeting;
        b in Zd && (a.rs_tt = Zd[b])
    };
    var ck = F(function(a, b) {
        var c = b.ca;
        a = b.g.G(a);
        return null != a && ik(a) ? sk.hasOwnProperty(c) ? a ? c.charAt(0) + c.charAt(1).toUpperCase() : c : c + a : ""
    }, "gPFO");

    function ak(a) {
        try {
            var b = parseInt(a, 10);
            return !isNaN(b) && 0 <= b ? b : 0
        } catch (c) {
            return 0
        }
    }

    function ik(a) {
        a = parseInt(a, 10);
        return !isNaN(a) && 0 <= a
    }
    var bk = F(function(a) {
            for (var b = ["fontSizeTitle", "fontSizeAttribution"], c = 0; c < b.length; c++) {
                var d = b[c];
                if (a[d]) {
                    var e = "string" == typeof a[d] ? parseInt(a[d].replace("px", ""), 10) : a[d];
                    e = e > kd ? kd : e;
                    e = 8 > e ? 8 : e;
                    a[d] = e + "px"
                }
            }
            return a
        }, "vFS"),
        tk = /^\/{3,}/,
        rk = F(function(a) {
            return a && a.startsWith("//") ? document.location.protocol + a.replace(tk, "//") : a
        }, "rRP"),
        fk = F(function(a) {
            a = a.fexp || "";
            return a.includes("17300001") ? 1 : a.includes("17300002") ? 2 : 0
        }, "gPPV"),
        Y = {},
        gk = (Y.adPage = "adpage", Y.adpage = "adpage", Y.ads = "ad", Y.adsafe =
            "adsafe", Y.adstyle = "adstyle", Y.adtest = "adtest", Y.afdToken = "afdt", Y.afsexp = "afsexp", Y.allwcallad = "allwcallad", Y.bgresponse = "bgresponse", Y.channel = "channel", Y.cont = "cont", Y.cref = "cref", Y.cx = "cx", Y.deb = "deb", Y.debug = "debug", Y.domainName = "domain_name", Y.e = "e", Y.expflags = "expflags", Y.fakeads = "fakeads", Y.fcap = "fcap", Y.fexp = "fexp", Y.forceEx = "expid", Y.format = "format", Y.gcs = "gcs", Y.gcse_nc = "gcse_nc", Y.gl = "gl", Y.glp = "glp", Y.gm = "gm", Y.gr = "gr", Y.hl = "hl", Y.hostChannel = "hchannel", Y.hostPubId = "hclient", Y.ie = "ie",
            Y.jsSrc = "csa_js_src", Y.languageCode = "hl", Y.maxTermLength = "max_radlink_len", Y.ms = "ms", Y.nocache = "nocache", Y.num = "num", Y.numRepeated = "adrep", Y.oe = "oe", Y.output = "output", Y.plasInCarousel = "pla_carousel", Y.preload = "preload", Y.priceCurrency = "pfcrncy", Y.priceMax = "pfmax", Y.priceMin = "pfmin", Y.pubId = "client", Y.query = "q", Y.queryContext = "qry_ctxt", Y.queryLink = "qry_lnk", Y.referer = "referer", Y.role = "r", Y.rowkeyV2 = "rowkeyV2", Y.rs_tt = "rs_tt", Y.rurl = "rurl", Y.safe = "safe", Y.sbsignals = "sbsignals", Y.source = "source", Y.source_ip =
            "source_ip", Y.styleId = "psid", Y.textColorPalette = "tcpal", Y.theme = "theme", Y.type = "type", Y.uideb = "uideb", Y.userAgent = "useragent", Y.uuld = "uuld", Y.v = "v", Y.adfiliateWp = "adfwp", Y.cpp = "cpp", Y.hotswaps = "hotswaps", Y.resultsPageBaseUrl = "rpbu", Y.resultsPageQueryParam = "rpqp", Y.personalizedAds = "pcsa", Y.attmas = "attmas", Y.cmpSdkId = "iab_cmpSdkId", Y.gdprApplies = "iab_gdprApplies", Y.tcString = "iab_tcString", Y.sc_status = "sc_status", Y.sct = "sct", Y.uiOptimize = "uiopt", Y.ui_optimize = "uiopt", Y.domainRegistrant = "swp", Y.domainSessionToken =
            "afdt", Y.kw = "kw", Y.terms = "terms", Y),
        sk = {
            hc: 1
        };
    m = S.prototype;
    m.Wb = B(S.prototype.Wb, "cAA");
    m.Zb = B(S.prototype.Zb, "cFAM");
    m.X = B(S.prototype.X, "cFA");
    m.Xc = B(S.prototype.Xc, "vASDO");
    m.Bc = B(S.prototype.Bc, "oTPP");
    m.za = B(S.prototype.za, "oTBP");
    m.Yb = B(S.prototype.Yb, "cCP");
    m.dc = B(S.prototype.dc, "cUIP");
    m.ec = B(S.prototype.ec, "cU");
    m.Lb = B(S.prototype.Lb, "aOTU");
    m.F = B(S.prototype.F, "gFN");
    m.qc = B(S.prototype.qc, "gFNAOAJ");
    m.oc = B(S.prototype.oc, "gAI");
    m.Sb = B(S.prototype.Sb, "cO");
    m.uc = B(S.prototype.uc, "iAI");
    m.Cc = B(S.prototype.Cc, "pM");
    m.vc = B(S.prototype.vc, "i");
    m.eb = B(S.prototype.eb, "cI");
    m.wb = B(S.prototype.wb, "mA");
    m.Tc = B(S.prototype.Tc, "tSP");
    m.wc = B(S.prototype.wc, "iFS");
    m.Ac = B(S.prototype.Ac, "nNA");
    m.Pc = B(S.prototype.Pc, "sIH");
    m.Oc = B(S.prototype.Oc, "sCW");
    m.Eb = B(S.prototype.Eb, "sP");
    m.Mc = B(S.prototype.Mc, "rIS");
    m.gb = B(S.prototype.gb, "dCE");
    m.Fb = B(S.prototype.Fb, "sC");
    m.Qb = B(S.prototype.Qb, "cVASDO");
    m.ob = B(S.prototype.ob, "iIV");

    function uk() {}
    ra(uk, Tj);
    uk.prototype.sd = function(a) {
        a = this.Fa(a).replace("www.google", "cse.google");
        return new qc(a + "/cse_v2/ads")
    };
    uk.prototype.rc = function() {
        return "uds_ads_only"
    };

    function vk() {}
    ra(vk, Tj);
    vk.prototype.rc = function() {
        return "uds_ads_only"
    };
    var wk = {
        g: new Ei(Oi, 5)
    };

    function xk(a, b, c, d, e, f, g, h, k, l) {
        l = void 0 === l ? [] : l;
        S.call(this, a, b, c, d, e, f, g, h, void 0 === k ? 1 : k, l)
    }
    ra(xk, S);
    xk.prototype.Md = function(a) {
        if (a.textColorPalette) {
            var b = a.textColorPalette;
            Array.isArray(b) || (b = [b]);
            b = $d("textColorPalette", wk, b);
            for (var c = 0; c < b.length; c++) try {
                var d = b[c];
                b[c] = Ji("#" == d.charAt(0) ? d : "#" + d).substr(1)
            } catch (e) {}
            a.textColorPalette = b.join(",")
        }
        "on" == a.adtest && a.testgl && (a.gl = a.testgl, a.glp = "1")
    };
    xk.prototype.X = function(a) {
        return a.number ? "n" + a.number : ""
    };

    function yk(a, b, c, d, e, f, g, h, k, l) {
        l = void 0 === l ? [] : l;
        S.call(this, a, b, c, d, e, f, g, h, void 0 === k ? 1 : k, l)
    }
    ra(yk, S);
    yk.prototype.X = function(a) {
        var b = a.relatedSearches;
        b || 0 === b || (b = a.number) || 0 === b || (b = 10);
        return "r" + b
    };
    yk.prototype.X = B(yk.prototype.X, "cFA_RS");

    function zk() {}
    ra(zk, Tj);
    zk.prototype.Fa = function(a) {
        var b = 17301368 === Wj(),
            c = z("_afsRsCookieless");
        return (b || c) && null != a && -1 === a.indexOf("dp-") ? "https://syndicatedsearch.goog" : oc()
    };
    zk.prototype.rc = function() {
        return "afd_ads"
    };
    zk.prototype.wd = function() {
        return !0
    };
    var hk = F(function(a, b, c, d, e, f, g, h, k) {
        function l() {}
        k = void 0 === k ? [] : k;
        b.relatedSearches ? b.type = "relatedsearch" : b.type || (b.type = "ads");
        var q = new vk,
            t = null;
        switch (b.type) {
            case "relatedsearch":
                l = yk;
                t = new zk;
                break;
            case "ads":
            case "textads":
                b.type = "ads";
                l = S;
                t = b.gcsc ? new uk : q;
                break;
            case "plas":
                l = xk;
                t = new vk;
                break;
            case "searchbox":
                break;
            default:
                throw E("invalid block type: " + b.type);
        }
        return new l(a, b, t, c, d, e, f, g, void 0 === h ? 1 : h, k)
    }, "nAB");

    function Ak(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = Bh(a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = Wa(g, e);
                    0 <= h && Array.prototype.splice.call(g, h, 1)
                }
                e.removeEventListener && e.removeEventListener("load", f, !1);
                e.removeEventListener && e.removeEventListener("error", f, !1)
            };
            yh(e, "load", f);
            yh(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }

    function Bk(a) {
        var b = void 0 === b ? !1 : b;
        var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
        zh(a, function(d, e) {
            if (d || 0 === d) c += "&" + e + "=" + encodeURIComponent("" + d)
        });
        Ck(c, b)
    }

    function Ck(a, b) {
        var c = window;
        b = void 0 === b ? !1 : b;
        var d = void 0 === d ? !1 : d;
        c.fetch ? (b = {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
            eventSourceEligible: "true",
            triggerEligible: "false"
        } : b.headers = {
            "Attribution-Reporting-Eligible": "event-source"
        }), c.fetch(a, b)) : Ak(c, a, void 0 === b ? !1 : b, void 0 === d ? !1 : d)
    };

    function Dk(a) {
        void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
        void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
        return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
    }

    function Ek(a, b) {
        b = void 0 === b ? {} : b;
        this.Ua = a;
        this.pa = null;
        this.Ad = {};
        this.me = 0;
        var c;
        this.Id = null != (c = b.timeoutMs) ? c : 500;
        var d;
        this.kd = null != (d = b.gg) ? d : !1;
        this.Pb = null
    }
    ra(Ek, eg);
    Ek.prototype.addEventListener = function(a) {
        function b(g, h) {
            clearTimeout(f);
            g ? (d = g, d.internalErrorState = Dk(d), d.internalBlockOnErrors = c.kd, h && 0 === d.internalErrorState || (d.tcString = "tcunavailable", h || (d.internalErrorState = 3))) : (d.tcString = "tcunavailable", d.internalErrorState = 3);
            a(d)
        }
        var c = this,
            d = {
                internalBlockOnErrors: this.kd
            },
            e = Va(function() {
                return a(d)
            }),
            f = 0; - 1 !== this.Id && (f = setTimeout(function() {
            d.tcString = "tcunavailable";
            d.internalErrorState = 1;
            e()
        }, this.Id));
        try {
            Fk(this, "addEventListener", b)
        } catch (g) {
            d.tcString =
                "tcunavailable", d.internalErrorState = 3, f && (clearTimeout(f), f = 0), e()
        }
    };
    Ek.prototype.removeEventListener = function(a) {
        a && a.listenerId && Fk(this, "removeEventListener", null, a.listenerId)
    };

    function Fk(a, b, c, d) {
        c || (c = function() {});
        if ("function" === typeof a.Ua.__tcfapi) a = a.Ua.__tcfapi, a(b, 2, c, d);
        else if (a.Ca()) {
            Gk(a);
            var e = ++a.me;
            a.Ad[e] = c;
            a.pa && (c = {}, a.pa.postMessage((c.__tcfapiCall = {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }, c), "*"))
        } else c({}, !1)
    }
    Ek.prototype.Ca = function() {
        return this.pa ? this.pa : this.pa = Ah(this.Ua, "__tcfapiLocator")
    };

    function Gk(a) {
        a.Pb || (a.Pb = function(b) {
            try {
                var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                a.Ad[c.callId](c.returnValue, c.success)
            } catch (d) {}
        }, yh(a.Ua, "message", a.Pb))
    }

    function Hk(a) {
        if (!1 === a.gdprApplies) return !0;
        void 0 === a.internalErrorState && (a.internalErrorState = Dk(a));
        return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (Bk({
            e: String(a.internalErrorState)
        }), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
    };

    function Ik(a) {
        if (!Hk(a)) return !1;
        if (!1 === a.gdprApplies || "tcunavailable" === a.tcString) return !0;
        var b = void 0 === b ? "755" : b;
        b: {
            if (a.publisher && a.publisher.restrictions) {
                var c = a.publisher.restrictions["1"];
                if (void 0 !== c) {
                    c = c[void 0 === b ? "755" : b];
                    break b
                }
            }
            c = void 0
        }
        0 === c ? b = !1 : a.purpose && a.vendor ? (c = a.vendor.consents, (b = !(!c || !c[void 0 === b ? "755" : b])) && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : b && (b = a.purpose.consents, b = !(!b || !b["1"]))) : b = !0;
        return b ? !0 : (console.warn(E("TC string lacks purpose 1 consent for Google (GVL ID: 755). CSA ads will not be requested until consent is given. TC string: " +
            a.tcString)), !1)
    }
    var Jk = F(function(a) {
        var b = new Ek(window, {
            timeoutMs: -1
        });
        if ("function" === typeof b.Ua.__tcfapi || null != b.Ca()) {
            var c = qe(),
                d = 0;
            d = setTimeout(function() {
                d = 0;
                console.warn(E("No response received from CMP after 10 seconds. CSA ads have not been requested."))
            }, 1E4);
            b.addEventListener(function(e) {
                d && (clearTimeout(d), d = 0);
                if (Ik(e)) {
                    if (0 !== e.internalErrorState) {
                        var f = new uc(a);
                        switch (e.internalErrorState) {
                            case 1:
                                yc(f, "to", JSON.stringify(e));
                                console.warn(E("Reached timeout before a response was received from CMP."));
                                break;
                            case 2:
                                yc(f, "it", JSON.stringify(e));
                                console.warn(E("Invalid types in received tcData."));
                                break;
                            case 3:
                                yc(f, "er", JSON.stringify(e)), console.warn(E("CMP returned error status."))
                        }
                    }
                    b.removeEventListener(e);
                    c.resolve({
                        tcString: e.tcString,
                        gdprApplies: e.gdprApplies
                    })
                }
            });
            return c.promise
        }
        return null
    }, "gTAD");
    var Kk = ia(["https://partner.googleadservices.com/gampad/cookie.js"]);

    function Lk(a, b) {
        var c = a.createElement("script");
        Xg(c, b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function Mk(a, b, c, d, e) {
        this.name = a;
        this.value = b;
        this.mc = c;
        this.path = void 0 === d ? null : d;
        this.domain = void 0 === e ? null : e
    }

    function Nk(a) {
        this.K = a;
        this.Vb = 0;
        this.Fd = null
    }

    function Ok(a, b) {
        if (!b.name || !b.value || !b.mc) throw "Setting a cookie must include cookie name and value and expiration.";
        var c = b.name + "=" + b.value,
            d = "",
            e = "",
            f = "";
        b.path && (d = ";path=" + b.path);
        var g = b.domain;
        if (g) {
            a: if (z("_useServerProvidedDomain")) {
                if (e = ac("ssdl", cc()))
                    if (e = new RegExp("(" + atob(e).replace(/,/g, ")|(") + ")"), g.match(e)) {
                        e = !1;
                        break a
                    }
                e = !0
            } else e = !1;e = ";domain=" + (e ? g : a.K.location.hostname)
        }
        b.mc && (f = ";expires=" + b.mc);
        a.K.document.cookie = c + f + d + e
    }

    function Pk(a, b) {
        if (!b) return Promise.resolve({
            cookie: null,
            status: 4
        });
        var c = b._cookies_[0];
        if (!c) return Promise.resolve({
            cookie: null,
            status: 4
        });
        b = c._value_;
        c = new Mk("__gsas", b, (new Date(1E3 * c._expires_)).toUTCString(), c._path_, c._domain_);
        try {
            Ok(a, c)
        } catch (d) {
            return Promise.resolve({
                cookie: null,
                status: 7
            })
        }
        return Promise.resolve({
            cookie: b,
            status: 3
        })
    }

    function Qk(a) {
        if (0 === a.Vb) {
            a: {
                try {
                    var b = new Date;
                    b.setTime(b.getTime() + 36E5);
                    Ok(a, new Mk("GoogleAdServingTest", "Good", b.toUTCString()))
                } catch (d) {
                    b = !1;
                    break a
                }
                if (b = "Good" === Rk(a, "GoogleAdServingTest")) {
                    var c = new Mk("GoogleAdServingTest", "Good", (new Date(0)).toUTCString());
                    try {
                        Ok(a, c)
                    } catch (d) {
                        b = !1
                    }
                }
            }
            a.Vb = b ? 2 : 1
        }
        return 2 === a.Vb
    }

    function Rk(a, b) {
        if ("string" === typeof a.K.document.cookie) {
            var c = new RegExp("^\\s*" + b + "=(.*)");
            if (a = a.K.document.cookie.split(";").find(function(d) {
                    return null != d.match(c)
                })) return a.match(c)[1]
        }
    }

    function Sk(a, b) {
        b = {
            domain: a.K.location.hostname,
            client: b || "undefined",
            product: "SAS",
            callback: "__sasCookie"
        };
        if (a.K != a.K.parent && !b.domain) {
            var c = a.K.parent && a.K.parent.location && a.K.parent.location.hostname;
            b.domain = a.K.location.ancestorOrigins && a.K.location.ancestorOrigins[0] || c
        }
        var d = fb(Me(Kk), b);
        return new Promise(function(e) {
            a.K.__sasCookie = function(f) {
                Pk(a, a.Fd ? a.Fd : f).then(function(g) {
                    e(g)
                })
            };
            Lk(a.K.document, d)
        })
    }
    var Tk = F(function(a) {
            return null == a ? null : Qk(a) ? (a = Rk(a, "__gsas")) ? {
                V: 6,
                cookie: a
            } : null : {
                V: 0,
                cookie: null
            }
        }, "sasCkeErr"),
        Uk = F(function(a) {
            var b = new Nk(window);
            return Qk(b) ? Sk(b, a).then(function(c) {
                return {
                    V: c.status,
                    cookie: c.cookie
                }
            }) : Promise.resolve({
                V: 0,
                cookie: null
            })
        }, "scErr");
    var Vk = null;

    function Wk(a, b, c) {
        a ? (b.cookie = a.cookie, b.V = a.V) : (Vk = Uk(c), Vk.then(function(d) {
            b.cookie = d.cookie;
            b.V = d.V
        }))
    }
    var Xk = F(function(a, b, c) {
        c = void 0 === c ? window : c;
        var d = [Rj(), Jk(a)],
            e, f, g = -1 !== (null == (e = c.location) ? void 0 : null == (f = e.host) ? void 0 : f.indexOf("startpage")),
            h = null;
        e = z("enableNonblockingSasCookie");
        var k = null != d[1] && b;
        g || !e || k || (h = Tk(new Nk(c)));
        var l = {
            da: void 0,
            md: void 0,
            tcString: void 0,
            gdprApplies: void 0,
            V: void 0,
            cookie: void 0
        };
        g || !e || k || Wk(h, l, a);
        return d.every(function(q) {
            return null == q
        }) ? l : te(d).then(function(q) {
            for (var t = 0; t < q.length; t++) {
                var p = q[t];
                if (p) switch (t) {
                    case 0:
                        l.da = p.da;
                        l.md = p.Ab;
                        break;
                    case 1:
                        l.tcString = p.tcString, l.gdprApplies = p.gdprApplies
                }
            }!k || null == l.tcString && null == l.gdprApplies || (h = Tk(new Nk(c)), Wk(h, l, a));
            return l
        }).catch(function(q) {
            C.log(q, "usdPrErr")
        })
    }, "usdErr");

    function Yk(a) {
        for (var b = new Zk, c = a[0], d = !1, e = 1; e < a.length; e++) {
            var f = new $k,
                g = void 0,
                h = void 0,
                k = a[e];
            for (h in k) k.hasOwnProperty(h) && (f.options[h] = k[h]);
            for (g in c) c.hasOwnProperty(g) && (f.options[g] = c[g]);
            d || (f.options.type || f.options.relatedSearches) && "ads" !== f.options.type && "textads" !== f.options.type || (d = f.options.firstTextAdBlock = !0);
            f.options.relatedSearches ? b.Dd.push(f) : b.Jb.push(f)
        }
        for (var l in c) c.hasOwnProperty(l) && (b.zb[l] = c[l]);
        return b
    }

    function $k() {
        this.options = {}
    }

    function Zk() {
        this.zb = {};
        this.Jb = [];
        this.Dd = []
    };
    var al = "clicktrackUrl container iframeHeightCallback linkTarget pubId query settingsId styleId waitForAds".split(" ");

    function bl(a) {
        if (2 > a.length) throw E("No options specified.");
        return a[1] instanceof Array ? [a[0]].concat(a[1]) : Array.prototype.slice.call(a, 0)
    }
    bl = B(bl, "ppata");

    function cl(a, b) {
        var c = b.da,
            d = b.md,
            e = b.tcString,
            f = b.gdprApplies,
            g = b.V;
        b = b.cookie;
        null != c && (a.cpp = c);
        !1 === d && (a.personalizedAds = !1);
        e && (a.tcString = e);
        null != f && (a.gdprApplies = f);
        null != g && (a.sc_status = g);
        b && (a.sct = b)
    }
    cl = B(cl, "aUDTA");

    function dl(a, b, c, d) {
        c = void 0 === c ? null : c;
        var e = a.yb;
        d = d || Date.now();
        b = bl(b);
        if (b[0] && !mc()) {
            a.Za && (b[0].type = a.Za);
            c && cl(b[0], c);
            a = Yk(b);
            var f = {},
                g = {};
            c = function(k) {
                k = n($a(k));
                for (var l = k.next(); !l.done; l = k.next()) {
                    l = l.value;
                    var q = e[l];
                    q && q.A && (f[l] = !0);
                    q || "firstTextAdBlock" === l || (g[l] = !0)
                }
            };
            c(a.zb);
            b = n(a.Jb);
            for (var h = b.next(); !h.done; h = b.next()) c(h.value.options);
            c = $a(f);
            0 < c.length && console.warn("The following CSA option(s) were ignored due to being overridden by native style controls: " + c);
            c = $a(g);
            0 < c.length && console.warn("The following CSA option(s) are unsupported: " + c);
            b = el(e, a.zb, a.Jb, d, {});
            c = fl;
            b && b.then(function(k) {
                pk(k)
            });
            d = el(e, a.zb, a.Dd, d);
            fl != c && d && d.then(function(k) {
                pk(k)
            })
        }
    }
    dl = B(dl, "aasi");

    function el(a, b, c, d) {
        if (0 == c.length) return null;
        var e = [],
            f = [],
            g = {
                maxTop: 0,
                minTop: 0,
                rhs: 0
            };
        fl++;
        for (var h = c.length - 1; 0 <= h; h--) {
            var k = c[h].options;
            k.adTest && !k.adtest && (k.adtest = k.adTest);
            delete k.adTest;
            var l = gl.location.href.includes("ampproject.net"),
                q = [];
            if (k.firstTextAdBlock && !l && !z("_enableUnifiedMudskipperIframe")) {
                l = {};
                for (var t = n(al), p = t.next(); !p.done; p = t.next()) p = p.value, l[p] = k[p];
                l.role = "s";
                l.masterNumber = fl;
                0 < h && (l.slaveNumber = h);
                t = hk(a, l, d, void 0, void 0, void 0, void 0, 2);
                l = hk(a, l, d, void 0,
                    void 0, void 0, void 0, 3);
                f.unshift(l);
                f.unshift(t);
                q.push(t);
                q.push(l);
                V[t.F()] = t;
                V[l.F()] = l
            }
            0 === h ? (k.role = "m", k.masterNumber = fl, k = hk(a, k, d, b, e, g, f, 1, q), V[k.F()] = k) : (k.role = "s", k.slaveNumber = h, k.masterNumber = fl, k = hk(a, k, d, void 0, void 0, void 0, void 0, 1, q), e.unshift(k.qd), f.unshift(k), g.maxTop += k.Z, g.minTop += k.aa, g.rhs += k.ba, V[k.F()] = k)
        }
        a = "master-" + fl;
        for (var r in V) ae(r) && (V[r].wa += "|" + V[a].wa);
        for (c = c.length - 1; 0 <= c; c--) r = ["slave", c, fl].join("-"), V.hasOwnProperty(r) && V[r].eb();
        c = null;
        V.hasOwnProperty(a) ?
            c = V[a].eb() : C.log("Missing ad block for " + a, "cAFOMM");
        return c
    }
    el = B(el, "cAFO");

    function lk(a, b, c, d) {
        d || V[c.split(".")[0]].Ac(a)
    }
    lk = B(lk, "hAC");
    var hl = {};

    function mk(a, b, c, d) {
        b = d.fw;
        var e = d.fh;
        d = d.ah;
        d = "number" === typeof b && "number" === typeof e && d instanceof Array ? new oe(b, e, d) : null;
        if (null != d && (c = c.split(".")[0], b = V[c], b.Mc(d, a), b.options && b.options.iframeHeightCallback && (a = b.container.offsetHeight, hl[c] != a))) {
            hl[c] = a;
            try {
                b.options.iframeHeightCallback(a)
            } catch (f) {}
        }
    }
    mk = B(mk, "hC");

    function nk(a, b, c, d) {
        a = V[c.split(".")[0]];
        gl.getComputedStyle && a instanceof xk && (b = parseInt(gl.getComputedStyle(a.container || document.body).width, 10), d == b && /Mobile/i.test(ec) && d--);
        a.Oc(d)
    }
    nk = B(nk, "wC");

    function il(a, b) {
        var c = {},
            d;
        for (d in V)
            if (V.hasOwnProperty(d)) {
                var e = V[d];
                e.options && e.options.masterNumber == b && "string" == typeof e.options.container && (e = e.options.container, c[e] = (c[e] || 0) + a.B[d + ".aC"].value)
            }
        return c
    }
    il = B(il, "gAC");

    function jk(a, b) {
        var c = V["master-" + b];
        if (c && c.options && c.options.adsResponseCallback) {
            a = il(a, b);
            try {
                c.options.adsResponseCallback(a)
            } catch (d) {}
        }
    }
    jk = B(jk, "aCC");

    function ok(a, b, c, d) {
        if ((a = V["master-" + b]) && a.options && a.options.visibleUrlsCallback) {
            d = d ? d.split("|") : [];
            try {
                a.options.visibleUrlsCallback(d)
            } catch (e) {}
        }
    }
    ok = B(ok, "vUC");
    var fl = 0,
        V = {},
        gl = window;
    var jl = dl;

    function kl(a) {
        ll(arguments)
    }
    var ml = {},
        nl = (ml.ads = Dj, ml.plas = Jj, ml.relatedsearch = zj, ml),
        pl = F(function() {
            var a = window._googCsa ? window._googCsa.q || [] : [],
                b = (window._googCsa || {}).t;
            ya("_googCsa", function() {
                ol(arguments)
            });
            for (var c = 0; c < a.length; c++) ol(a[c], b)
        }, "cmps"),
        ol = F(function(a, b) {
            if (a && !(1 > a.length))
                if (nl.hasOwnProperty(a[0])) {
                    var c = nl[a[0]],
                        d;
                    a = (d = 3 == a.length ? [a[1], a[2]] : [a[1], Array.prototype.slice.call(a, 2)], d[0]) || {};
                    a = Xk(a.pubId || "", !!a.gcsc || !1, window);
                    a instanceof Promise ? a.then(function(e) {
                        jl(c, d, e, b)
                    }) : jl(c, d, a, b)
                } else if ("jsLoadedCallback" ==
                a[0]) try {
                a[1]()
            } catch (e) {}
        }, "cmpe"),
        ll = F(function(a) {
            var b = a && a[0] || {};
            b = Xk(b.pubId || "", !!b.gcsc || !1, window);
            b instanceof Promise ? b.then(function(c) {
                jl(Dj, a, c)
            }) : jl(Dj, a, b)
        }, "iAAPR");
    window.IS_GOOGLE_AFS_IFRAME_ || window.google && window.google.ads && window.google.ads.search && window.google.ads.search.Ads || (ya("google.ads.search.Ads", kl), pl());
})();