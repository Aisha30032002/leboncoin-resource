(function(sttc) {
    var window = this;
    if (window.googletag && googletag.evalScripts) {
        googletag.evalScripts();
    }
    if (window.googletag && googletag._loaded_) return;
    var p, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        da = ca(this),
        ea = "function" === typeof Symbol && "symbol" === typeof Symbol("x"),
        t = {},
        fa = {},
        u = function(a, b, c) {
            if (!c || null != a) {
                c = fa[b];
                if (null == c) return a[b];
                c = a[c];
                return void 0 !== c ? c : a[b]
            }
        },
        w = function(a, b, c) {
            if (b) a: {
                var d = a.split(".");a = 1 === d.length;
                var e = d[0],
                    f;!a && e in t ? f = t : f = da;
                for (e = 0; e < d.length - 1; e++) {
                    var g = d[e];
                    if (!(g in f)) break a;
                    f = f[g]
                }
                d = d[d.length - 1];c = ea && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? ba(t, d, {
                    configurable: !0,
                    writable: !0,
                    value: b
                }) : b !== c && (void 0 === fa[d] && (a = 1E9 * Math.random() >>> 0, fa[d] = ea ? da.Symbol(d) : "$jscp$" + a + "$" + d), ba(f, fa[d], {
                    configurable: !0,
                    writable: !0,
                    value: b
                })))
            }
        };
    w("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.g = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    w("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, t.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = da[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ha(aa(this))
                }
            })
        }
        return a
    }, "es6");
    var ha = function(a) {
            a = {
                next: a
            };
            a[u(t.Symbol, "iterator")] = function() {
                return this
            };
            return a
        },
        ia = function(a) {
            return a.raw = a
        },
        x = function(a) {
            var b = "undefined" != typeof t.Symbol && u(t.Symbol, "iterator") && a[u(t.Symbol, "iterator")];
            if (b) return b.call(a);
            if ("number" == typeof a.length) return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        y = function(a) {
            if (!(a instanceof Array)) {
                a = x(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        z = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        ja = ea && "function" == typeof u(Object, "assign") ? u(Object, "assign") : function(a, b) {
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) z(d, e) && (a[e] = d[e])
            }
            return a
        };
    w("Object.assign", function(a) {
        return a || ja
    }, "es6");
    var ka = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        la;
    if (ea && "function" == typeof Object.setPrototypeOf) la = Object.setPrototypeOf;
    else {
        var na;
        a: {
            var oa = {
                    a: !0
                },
                pa = {};
            try {
                pa.__proto__ = oa;
                na = pa.a;
                break a
            } catch (a) {}
            na = !1
        }
        la = na ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var qa = la,
        B = function(a, b) {
            a.prototype = ka(b.prototype);
            a.prototype.constructor = a;
            if (qa) qa(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.pb = b.prototype
        },
        ra = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    w("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    }, "es6");
    w("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.g = (e += Math.random() + 1).toString();
                if (g) {
                    g = x(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!z(g, d)) {
                var k = new b;
                ba(g, d, {
                    value: k
                })
            }
            if (!z(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.g] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && z(g, d) ? g[d][this.g] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && z(g, d) && z(g[d], this.g)
        };
        f.prototype.delete = function(g) {
            return c(g) && z(g, d) && z(g[d], this.g) ? delete g[d][this.g] : !1
        };
        return f
    }, "es6");
    w("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !u(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(x([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = u(k, "entries").call(k),
                        m = l.next();
                    if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (n) {
                    return !1
                }
            }()) return a;
        var b = new t.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = x(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.s ? l.s.value = k : (l.s = {
                next: this[1],
                C: this[1].C,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.s), this[1].C.next = l.s, this[1].C = l.s, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.s && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.s.C.next = h.s.next, h.s.next.C = h.s.C, h.s.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].C = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).s
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).s) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = u(this, "entries").call(this), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        c.prototype[u(t.Symbol, "iterator")] = u(c.prototype, "entries");
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && z(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var n = m[h];
                        if (k !== k && n.key !== n.key || k === n.key) return {
                            id: l,
                            list: m,
                            index: h,
                            s: n
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    s: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return ha(function() {
                    if (l) {
                        for (; l.head != h[1];) l = l.C;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.C = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    w("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || Infinity === b || -Infinity === b || 0 === b) return b;
            var c = Math.floor(Math.abs(b));
            return 0 > b ? -c : c
        }
    }, "es6");
    w("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) z(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    w("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    w("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || u(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    var sa = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    w("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== sa(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    w("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !u(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(x([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = u(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.g = new t.Map;
            if (c) {
                c = x(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.g.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.g.set(c, c);
            this.size = this.g.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.g.delete(c);
            this.size = this.g.size;
            return c
        };
        b.prototype.clear = function() {
            this.g.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.g.has(c)
        };
        b.prototype.entries = function() {
            return u(this.g, "entries").call(this.g)
        };
        b.prototype.values = function() {
            return u(this.g, "values").call(this.g)
        };
        b.prototype.keys = u(b.prototype, "values");
        b.prototype[u(t.Symbol, "iterator")] = u(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.g.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    w("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    w("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    }, "es6");
    w("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return u(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    w("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return u(Number, "isInteger").call(Number, b) && Math.abs(b) <= u(Number, "MAX_SAFE_INTEGER")
        }
    }, "es6");
    var ta = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[u(t.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    w("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return ta(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    w("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return ta(this, function(b) {
                return b
            })
        }
    }, "es6");
    w("Array.prototype.values", function(a) {
        return a ? a : function() {
            return ta(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    w("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                f = "undefined" != typeof t.Symbol && u(t.Symbol, "iterator") && b[u(t.Symbol, "iterator")];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    w("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) z(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    w("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = sa(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    w("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = sa(this, null, "repeat");
            if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    w("globalThis", function(a) {
        return a || da
    }, "es_2020");
    w("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = sa(this, null, "padStart");
            b -= d.length;
            c = void 0 !== c ? String(c) : " ";
            return (0 < b && c ? u(c, "repeat").call(c, Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    }, "es8");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var C = this || self,
        va = function(a, b) {
            var c = ua("CLOSURE_FLAGS");
            a = c && c[a];
            return null != a ? a : b
        },
        ua = function(a) {
            a = a.split(".");
            for (var b = C, c = 0; c < a.length; c++)
                if (b = b[a[c]], null == b) return null;
            return b
        },
        xa = function(a, b, c) {
            a = a.split(".");
            c = c || C;
            a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
            for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        };

    function ya(a) {
        C.setTimeout(function() {
            throw a;
        }, 0)
    };
    var za = function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        Ia = function(a) {
            if (!Ba.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(Ca, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(Da, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(Ea, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(Fa, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(Ga, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(Ha, "&#0;"));
            return a
        },
        Ca = /&/g,
        Da = /</g,
        Ea = />/g,
        Fa = /"/g,
        Ga = /'/g,
        Ha = /\x00/g,
        Ba = /[\x00&<>"']/,
        Ka = function(a, b) {
            var c = 0;
            a = za(String(a)).split(".");
            b = za(String(b)).split(".");
            for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
                var f = a[e] || "",
                    g = b[e] || "";
                do {
                    f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                    g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                    if (0 == f[0].length && 0 == g[0].length) break;
                    c = Ja(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || Ja(0 == f[2].length, 0 == g[2].length) || Ja(f[2], g[2]);
                    f = f[3];
                    g = g[3]
                } while (0 == c)
            }
            return c
        },
        Ja = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        };
    var La = va(610401301, !1),
        Ma = va(572417392, va(1, !0));
    var Na, Oa = C.navigator;
    Na = Oa ? Oa.userAgentData || null : null;

    function Pa(a) {
        return La ? Na ? Na.brands.some(function(b) {
            return (b = b.brand) && -1 != b.indexOf(a)
        }) : !1 : !1
    }

    function F(a) {
        var b;
        a: {
            if (b = C.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return -1 != b.indexOf(a)
    };

    function Qa() {
        return La ? !!Na && 0 < Na.brands.length : !1
    }

    function Ra() {
        return Qa() ? Pa("Chromium") : (F("Chrome") || F("CriOS")) && !(Qa() ? 0 : F("Edge")) || F("Silk")
    };
    var Sa = function(a, b) {
            Array.prototype.forEach.call(a, b, void 0)
        },
        Ta = function(a, b) {
            return Array.prototype.map.call(a, b, void 0)
        };

    function Ua(a, b) {
        a: {
            for (var c = "string" === typeof a ? a.split("") : a, d = a.length - 1; 0 <= d; d--)
                if (d in c && b.call(void 0, c[d], d, a)) {
                    b = d;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    };
    var Va = function(a) {
        Va[" "](a);
        return a
    };
    Va[" "] = function() {};
    var Wa = Qa() ? !1 : F("Trident") || F("MSIE");
    !F("Android") || Ra();
    Ra();
    F("Safari") && (Ra() || (Qa() ? 0 : F("Coast")) || (Qa() ? 0 : F("Opera")) || (Qa() ? 0 : F("Edge")) || (Qa() ? Pa("Microsoft Edge") : F("Edg/")) || Qa() && Pa("Opera"));
    var Xa = {},
        Ya = null,
        $a = function(a) {
            var b = [];
            Za(a, function(c) {
                b.push(c)
            });
            return b
        },
        Za = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = Ya[l];
                    if (null != m) return m;
                    if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            ab();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        ab = function() {
            if (!Ya) {
                Ya = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    Xa[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === Ya[f] && (Ya[f] = e)
                    }
                }
            }
        };
    var bb = "undefined" !== typeof Uint8Array,
        cb = !Wa && "function" === typeof btoa;

    function db() {
        return "function" === typeof BigInt
    }
    var eb = !Ma,
        fb = !Ma;
    var G = 0,
        gb = 0;

    function hb(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = x(ib(c, a)), b = c.next().value, a = c.next().value, c = b);
        G = c >>> 0;
        gb = a >>> 0
    }

    function jb(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (2097151 >= b) var c = "" + (4294967296 * b + a);
        else db() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + 6777216 * c + 6710656 * b, c += 8147497 * b, b *= 2, 1E7 <= a && (c += Math.floor(a / 1E7), a %= 1E7), 1E7 <= c && (b += Math.floor(c / 1E7), c %= 1E7), c = b + kb(c) + kb(a));
        return c
    }

    function kb(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function lb() {
        var a = G,
            b = gb;
        b & 2147483648 ? db() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = x(ib(a, b)), a = b.next().value, b = b.next().value, a = "-" + jb(a, b)) : a = jb(a, b);
        return a
    }

    function ib(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };

    function mb(a) {
        return Array.prototype.slice.call(a)
    };
    var H = "function" === typeof t.Symbol && "symbol" === typeof(0, t.Symbol)() ? (0, t.Symbol)() : void 0,
        nb = H ? function(a, b) {
            a[H] |= b
        } : function(a, b) {
            void 0 !== a.A ? a.A |= b : Object.defineProperties(a, {
                A: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };

    function ob(a) {
        var b = I(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = mb(a)), J(a, b | 1))
    }
    var pb = H ? function(a, b) {
        a[H] &= ~b
    } : function(a, b) {
        void 0 !== a.A && (a.A &= ~b)
    };

    function K(a, b, c) {
        return c ? a | b : a & ~b
    }
    var I = H ? function(a) {
            return a[H] | 0
        } : function(a) {
            return a.A | 0
        },
        L = H ? function(a) {
            return a[H]
        } : function(a) {
            return a.A
        },
        J = H ? function(a, b) {
            a[H] = b
        } : function(a, b) {
            void 0 !== a.A ? a.A = b : Object.defineProperties(a, {
                A: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };

    function qb() {
        var a = [];
        nb(a, 1);
        return a
    }

    function rb(a, b) {
        J(b, (a | 0) & -14591)
    }

    function sb(a, b) {
        J(b, (a | 34) & -14557)
    }

    function tb(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var ub = {},
        vb = {};

    function wb(a) {
        return !(!a || "object" !== typeof a || a.kb !== vb)
    }

    function xb(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    var yb, zb = !Ma;

    function Ab(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        var d = I(a);
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? u(b, "includes").call(b, c) : b.has(c)))) return !1;
        J(a, d | 1);
        return !0
    }
    var Bb, Cb = [];
    J(Cb, 55);
    Bb = Object.freeze(Cb);

    function Db(a) {
        if (a & 2) throw Error();
    };
    var Eb = function(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Fb;

    function Gb(a) {
        if (Fb) throw Error("");
        Fb = a
    }

    function Hb(a) {
        if (Fb) try {
            Fb(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function Ib() {
        var a = Jb();
        Fb ? C.setTimeout(function() {
            Hb(a)
        }, 0) : ya(a)
    }

    function Kb(a) {
        a = Error(a);
        Eb(a, "warning");
        Hb(a);
        return a
    }

    function Jb() {
        var a = Error();
        Eb(a, "incident");
        return a
    };

    function Lb(a) {
        if (null != a && "boolean" !== typeof a) {
            var b = typeof a;
            throw Error("Expected boolean but got " + ("object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null") + ": " + a);
        }
        return a
    }
    var Mb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Nb(a) {
        var b = typeof a;
        return "number" === b ? u(Number, "isFinite").call(Number, a) : "string" !== b ? !1 : Mb.test(a)
    }

    function Ob(a) {
        null != a && (u(Number, "isFinite").call(Number, a) || Ib());
        return a
    }

    function Pb(a) {
        if ("number" !== typeof a) throw Kb("int32");
        u(Number, "isFinite").call(Number, a) || Ib();
        return a
    }

    function Qb(a) {
        return null == a ? a : Pb(a)
    }

    function Rb(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return a
    }

    function Sb(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return a
    }

    function Tb(a) {
        if (null == a) var b = a;
        else {
            b = !!b;
            if (!Nb(a)) throw Kb("int64");
            "string" === typeof a ? b = Ub(a, b) : b ? (a = u(Math, "trunc").call(Math, a), !b || u(Number, "isSafeInteger").call(Number, a) ? b = String(a) : (b = String(a), Vb(b) || (hb(a), b = lb()))) : b = Wb(a)
        }
        return b
    }

    function Vb(a) {
        return "-" === a[0] ? 20 > a.length ? !0 : 20 === a.length && -922337 < Number(a.substring(0, 7)) : 19 > a.length ? !0 : 19 === a.length && 922337 > Number(a.substring(0, 6))
    }

    function Wb(a) {
        return a = u(Math, "trunc").call(Math, a)
    }

    function Ub(a, b) {
        var c = u(Math, "trunc").call(Math, Number(a));
        if (u(Number, "isSafeInteger").call(Number, c)) return String(c);
        c = a.indexOf("."); - 1 !== c && (a = a.substring(0, c));
        if (b && !Vb(a)) {
            if (16 > a.length) hb(Number(a));
            else if (db()) a = BigInt(a), G = Number(a & BigInt(4294967295)) >>> 0, gb = Number(a >> BigInt(32) & BigInt(4294967295));
            else {
                b = +("-" === a[0]);
                gb = G = 0;
                c = a.length;
                for (var d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), gb *= 1E6, G = 1E6 * G + d, 4294967296 <= G && (gb += u(Math, "trunc").call(Math, G / 4294967296), gb >>>= 0, G >>>= 0);
                b && (b = x(ib(G, gb)), a = b.next().value, b = b.next().value, G = a, gb = b)
            }
            a = lb()
        }
        return a
    }

    function Xb(a) {
        if ("string" !== typeof a) throw Error();
        return a
    }

    function M(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    }

    function Yb(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function Zb(a, b, c) {
        if (null != a && "object" === typeof a && a.Y === ub) return a;
        if (Array.isArray(a)) {
            var d = I(a),
                e = d;
            0 === e && (e |= c & 32);
            e |= c & 2;
            e !== d && J(a, e);
            return new b(a)
        }
    }
    var $b = "function" === typeof t.Symbol && "symbol" === typeof(0, t.Symbol)() ? (0, t.Symbol)() : "di";
    var ac;

    function bc(a, b) {
        ac = b;
        a = new a(b);
        ac = void 0;
        return a
    }

    function N(a, b, c) {
        null == a && (a = ac);
        ac = void 0;
        if (null == a) {
            var d = 96;
            c ? (a = [c], d |= 512) : a = [];
            b && (d = d & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error();
            d = I(a);
            if (d & 64) return a;
            d |= 64;
            if (c && (d |= 512, c !== a[0])) throw Error();
            a: {
                c = d;
                if (d = a.length) {
                    var e = d - 1;
                    if (xb(a[e])) {
                        c |= 256;
                        b = e - (+!!(c & 512) - 1);
                        if (1024 <= b) throw Error();
                        d = c & -16760833 | (b & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    b = Math.max(b, d - (+!!(c & 512) - 1));
                    if (1024 < b) throw Error();
                    d = c & -16760833 | (b & 1023) << 14
                } else d = c
            }
        }
        J(a, d);
        return a
    };

    function cc(a, b) {
        return dc(b)
    }

    function dc(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return zb || !Ab(a, void 0, 9999) ? a : void 0;
                    if (bb && null != a && a instanceof Uint8Array) {
                        if (cb) {
                            for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                            b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                            a = btoa(b)
                        } else {
                            void 0 === b && (b = 0);
                            ab();
                            b = Xa[b];
                            c = Array(Math.floor(a.length / 3));
                            d = b[64] || "";
                            for (var e = 0, f = 0; e < a.length - 2; e += 3) {
                                var g = a[e],
                                    h = a[e + 1],
                                    k = a[e + 2],
                                    l = b[g >> 2];
                                g = b[(g & 3) << 4 | h >> 4];
                                h = b[(h & 15) << 2 | k >> 6];
                                k = b[k & 63];
                                c[f++] = l + g + h + k
                            }
                            l = 0;
                            k = d;
                            switch (a.length - e) {
                                case 2:
                                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                                case 1:
                                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
                            }
                            a = c.join("")
                        }
                        return a
                    }
                }
        }
        return a
    };

    function ec(a, b, c) {
        a = mb(a);
        var d = a.length,
            e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (var f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    }

    function fc(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && I(a) & 1 ? void 0 : f && I(a) & 2 ? a : gc(a, b, c, void 0 !== d, e, f);
            else if (xb(a)) {
                var g = {},
                    h;
                for (h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = fc(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function gc(a, b, c, d, e, f) {
        var g = d || c ? I(a) : 0;
        d = d ? !!(g & 32) : void 0;
        a = mb(a);
        for (var h = 0; h < a.length; h++) a[h] = fc(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    }

    function hc(a) {
        return a.Y === ub ? a.toJSON() : dc(a)
    };

    function ic(a, b, c) {
        c = void 0 === c ? sb : c;
        if (null != a) {
            if (bb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = I(a);
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (J(a, (d | 34) & -12293), a) : gc(a, ic, d & 4 ? sb : c, !0, !1, !0)
            }
            a.Y === ub && (c = a.i, d = L(c), a = d & 2 ? a : bc(a.constructor, jc(c, d, !0)));
            return a
        }
    }

    function jc(a, b, c) {
        var d = c || b & 2 ? sb : rb,
            e = !!(b & 32);
        a = ec(a, b, function(f) {
            return ic(f, e, d)
        });
        nb(a, 32 | (c ? 2 : 0));
        return a
    }

    function kc(a) {
        var b = a.i,
            c = L(b);
        return c & 2 ? bc(a.constructor, jc(b, c, !1)) : a
    };
    Object.freeze({});
    var mc = function(a, b) {
            a = a.i;
            return lc(a, L(a), b)
        },
        lc = function(a, b, c, d) {
            if (-1 === c) return null;
            if (c >= tb(b)) {
                if (b & 256) return a[a.length - 1][c]
            } else {
                var e = a.length;
                if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
                b = c + (+!!(b & 512) - 1);
                if (b < e) return a[b]
            }
        },
        P = function(a, b, c) {
            var d = a.i,
                e = L(d);
            Db(e);
            O(d, e, b, c);
            return a
        };

    function O(a, b, c, d, e) {
        var f = tb(b);
        if (c >= f || e) {
            e = b;
            if (b & 256) f = a[a.length - 1];
            else {
                if (null == d) return e;
                f = a[f + (+!!(b & 512) - 1)] = {};
                e |= 256
            }
            f[c] = d;
            e !== b && J(a, e);
            return e
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    }

    function nc(a, b, c, d) {
        var e = b & 2,
            f = lc(a, b, c);
        Array.isArray(f) || (f = Bb);
        var g = !(d & 2);
        d = !(d & 1);
        var h = !!(b & 32),
            k = I(f);
        0 !== k || !h || e || g ? k & 1 || (k |= 1, J(f, k)) : (k |= 33, J(f, k));
        e ? (a = !1, k & 2 || (nb(f, 34), a = !!(4 & k)), (d || a) && Object.freeze(f)) : (e = !!(2 & k) || !!(2048 & k), d && e ? (f = mb(f), d = 1, h && !g && (d |= 32), J(f, d), O(a, b, c, f)) : g && k & 32 && !e && pb(f, 32));
        return f
    }

    function oc(a, b, c) {
        var d = void 0;
        d = void 0 === d ? 2 : d;
        a = a.i;
        var e = L(a);
        2 & e && (d = 1);
        var f = nc(a, e, b, 1);
        e = L(a);
        var g = I(f),
            h = g,
            k = !!(2 & g),
            l = !!(4 & g),
            m = k && l;
        if (!(4 & g)) {
            l && (f = mb(f), h = 0, g = pc(g, e, !1), k = !!(2 & g), e = O(a, e, b, f));
            for (var n = l = 0; l < f.length; l++) {
                var r = c(f[l]);
                null != r && (f[n++] = r)
            }
            n < l && (f.length = n);
            c = K(g, 4096, !1);
            g = c = K(c, 8192, !1);
            g = K(g, 20, !0)
        }
        m || ((c = 1 === d) && (g = K(g, 2, !0)), g !== h && J(f, g), (c || k) && Object.freeze(f));
        2 === d && k && (f = mb(f), g = pc(g, e, !1), J(f, g), O(a, e, b, f));
        return f
    }

    function qc(a, b, c, d) {
        var e = a.i,
            f = L(e);
        Db(f);
        if (null == c) return O(e, f, b), a;
        var g = I(c),
            h = g,
            k = !!(2 & g) || Object.isFrozen(c),
            l = !k && !1;
        if (!(4 & g))
            for (g = 21, k && (c = mb(c), h = 0, g = pc(g, f, !0)), k = 0; k < c.length; k++) c[k] = d(c[k]);
        l && (g = K(g, 2, !0));
        g !== h && J(c, g);
        l && Object.freeze(c);
        O(e, f, b, c);
        return a
    }

    function Q(a, b, c, d) {
        var e = a.i,
            f = L(e);
        Db(f);
        O(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
        return a
    }
    var sc = function(a, b, c, d) {
            var e = a.i,
                f = L(e);
            Db(f);
            (c = rc(e, f, c)) && c !== b && null != d && (f = O(e, f, c));
            O(e, f, b, d);
            return a
        },
        tc = function(a, b, c) {
            a = a.i;
            return rc(a, L(a), b) === c ? c : -1
        },
        uc = function(a, b) {
            a = a.i;
            return rc(a, L(a), b)
        };

    function rc(a, b, c) {
        for (var d = 0, e = 0; e < c.length; e++) {
            var f = c[e];
            null != lc(a, b, f) && (0 !== d && (b = O(a, b, d)), d = f)
        }
        return d
    }
    var vc = function(a, b, c, d) {
            a = a.i;
            var e = L(a),
                f = lc(a, e, c, d);
            b = Zb(f, b, e);
            b !== f && null != b && O(a, e, c, b, d);
            return b
        },
        wc = function(a, b) {
            (a = vc(a, b, 1, !1)) ? b = a: (a = b[$b]) ? b = a : (a = new b, nb(a.i, 34), b = b[$b] = a);
            return b
        },
        R = function(a, b, c) {
            var d = void 0 === d ? !1 : d;
            b = vc(a, b, c, d);
            if (null == b) return b;
            a = a.i;
            var e = L(a);
            if (!(e & 2)) {
                var f = kc(b);
                f !== b && (b = f, O(a, e, c, b, d))
            }
            return b
        },
        S = function(a, b, c) {
            a = a.i;
            var d = L(a),
                e = !!(2 & d),
                f = e ? 1 : 2,
                g = 1 === f;
            f = 2 === f;
            var h = !!(2 & d) && f,
                k = nc(a, d, c, 3);
            d = L(a);
            var l = I(k),
                m = !!(2 & l),
                n = !!(4 & l),
                r = !!(32 & l),
                q = m && n || !!(2048 & l);
            if (!n) {
                var A = k,
                    v = d,
                    D = !!(2 & l);
                D && (v = K(v, 2, !0));
                for (var E = !D, ma = !0, Aa = 0, wa = 0; Aa < A.length; Aa++) {
                    var Ac = Zb(A[Aa], b, v);
                    if (Ac instanceof b) {
                        if (!D) {
                            var Yd = !!(I(Ac.i) & 2);
                            E && (E = !Yd);
                            ma && (ma = Yd)
                        }
                        A[wa++] = Ac
                    }
                }
                wa < Aa && (A.length = wa);
                l = K(l, 4, !0);
                l = K(l, 16, ma);
                l = K(l, 8, E);
                J(A, l);
                m && !h && (Object.freeze(k), q = !0)
            }
            b = l;
            h = !!(8 & l) || g && !k.length;
            if (!e && !h) {
                q && (k = mb(k), q = !1, b = 0, l = pc(l, d, !1), d = O(a, d, c, k));
                e = k;
                h = l;
                for (m = 0; m < e.length; m++) A = e[m], l = kc(A), A !== l && (e[m] = l);
                h = K(h, 8, !0);
                l = h = K(h, 16, !e.length)
            }
            q || (g ? l = K(l, !k.length || 16 & l && (!n || r) ? 2 : 2048, !0) : l = K(l, 32, !1), l !== b && J(k, l), g && (Object.freeze(k), q = !0));
            f && q && (k = mb(k), l = pc(l, d, !1), J(k, l), O(a, d, c, k));
            return k
        },
        xc = function(a, b, c) {
            null == c && (c = void 0);
            return P(a, b, c)
        },
        yc = function(a, b, c, d) {
            null == d && (d = void 0);
            return sc(a, b, c, d)
        },
        zc = function(a, b, c) {
            var d = a.i,
                e = L(d);
            Db(e);
            if (null == c) return O(d, e, b), a;
            for (var f = I(c), g = f, h = !!(2 & f) || !!(2048 & f), k = h || Object.isFrozen(c), l = !k && !1, m = !0, n = !0, r = 0; r < c.length; r++) {
                var q = c[r];
                h || (q = !!(I(q.i) & 2), m && (m = !q), n && (n = q))
            }
            h || (f = K(f, 5, !0), f = K(f, 8, m), f = K(f, 16, n), l && (f = K(f, n ? 2 : 2048, !0)), f !== g && (k && (c = mb(c), f = pc(f, e, !0)), J(c, f)), l && Object.freeze(c));
            O(d, e, b, c);
            return a
        };

    function pc(a, b, c) {
        a = K(a, 2, !!(2 & b));
        a = K(a, 32, !!(32 & b) && c);
        return a = K(a, 2048, !1)
    }

    function Bc(a, b) {
        return null != a ? a : b
    }
    var Cc = function(a, b) {
            a = mc(a, b);
            return Bc(null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0, !1)
        },
        Dc = function(a, b) {
            var c = void 0 === c ? 0 : c;
            return Bc(Rb(mc(a, b)), c)
        },
        Ec = function(a, b) {
            var c = void 0 === c ? 0 : c;
            return Bc(Sb(mc(a, b)), c)
        },
        Fc = function(a, b) {
            var c = void 0 === c ? 0 : c;
            a = mc(a, b);
            var d;
            null == a ? d = a : Nb(a) ? "number" === typeof a ? d = Wb(a) : d = Ub(a, !1) : d = void 0;
            return Bc(d, c)
        },
        Gc = function(a, b) {
            var c = void 0 === c ? 0 : c;
            a = a.i;
            var d = L(a),
                e = lc(a, d, b);
            var f = null == e ? e : "number" === typeof e || "NaN" === e || "Infinity" === e || "-Infinity" === e ? Number(e) : void 0;
            null != f && f !== e && O(a, d, b, f);
            return Bc(f, c)
        },
        T = function(a, b) {
            return Bc(Yb(mc(a, b)), "")
        },
        U = function(a, b) {
            return Bc(mc(a, b), 0)
        };
    var V = function(a, b, c) {
        this.i = N(a, b, c)
    };
    V.prototype.toJSON = function() {
        if (yb) var a = Hc(this, this.i, !1);
        else a = gc(this.i, hc, void 0, void 0, !1, !1), a = Hc(this, a, !0);
        return a
    };
    var Ic = function(a) {
        yb = !0;
        try {
            return JSON.stringify(a.toJSON(), cc)
        } finally {
            yb = !1
        }
    };
    V.prototype.Y = ub;

    function Hc(a, b, c) {
        var d = a.constructor.m,
            e = L(c ? a.i : b),
            f = tb(e),
            g = !1;
        if (d && zb) {
            if (!c) {
                b = mb(b);
                var h;
                if (b.length && xb(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            u(Object, "assign").call(Object, b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            h = L(a.i);
            a = tb(h);
            h = +!!(h & 512) - 1;
            for (var k, l, m = 0; m < d.length; m++)
                if (l = d[m], l < a) {
                    l += h;
                    var n = f[l];
                    null == n ? f[l] = c ? Bb : qb() : c && n !== Bb && ob(n)
                } else k || (n = void 0, f.length && xb(n = f[f.length - 1]) ? k = n : f.push(k = {})), n = k[l], null == k[l] ? k[l] = c ? Bb : qb() : c && n !== Bb && ob(n)
        }
        k = b.length;
        if (!k) return b;
        var r;
        if (xb(f = b[k - 1])) {
            a: {
                var q = f;c = {};a = !1;
                for (var A in q)
                    if (Object.prototype.hasOwnProperty.call(q, A)) {
                        h = q[A];
                        if (Array.isArray(h)) {
                            m = h;
                            if (!fb && Ab(h, d, +A) || !eb && wb(h) && 0 === h.size) h = null;
                            h != m && (a = !0)
                        }
                        null != h ? c[A] = h : a = !0
                    }
                if (a) {
                    for (var v in c) {
                        q = c;
                        break a
                    }
                    q = null
                }
            }
            q != f && (r = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            A = k - 1;
            f = b[A];
            if (!(null == f || !fb && Ab(f, d, A - e) || !eb && wb(f) && 0 === f.size)) break;
            var D = !0
        }
        if (!r && !D) return b;
        var E;
        g ? E = b : E = Array.prototype.slice.call(b, 0, k);
        b = E;
        g && (b.length = k);
        q && b.push(q);
        return b
    };

    function Jc() {
        var a = !W(Kc).g,
            b = Lc();
        if (!a) throw Error(b && b() || String(a));
    }
    var Mc = void 0;

    function Lc() {
        var a = Mc;
        Mc = void 0;
        return a
    };

    function Nc(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                nb(b, 32);
                b = bc(a, b)
            }
            return b
        }
    };
    var Oc = function(a) {
        this.i = N(a)
    };
    B(Oc, V);
    Oc.m = [6, 4];
    var Pc = function(a) {
        this.i = N(a)
    };
    B(Pc, V);
    var Qc = Nc(Pc);
    Pc.m = [4, 5, 6];
    var Tc = function(a, b) {
        this.h = a === Rc && b || "";
        this.j = Sc
    };
    Tc.prototype.G = !0;
    Tc.prototype.g = function() {
        return this.h
    };
    var Uc = function(a) {
            return a instanceof Tc && a.constructor === Tc && a.j === Sc ? a.h : "type_error:Const"
        },
        Sc = {},
        Rc = {};
    var Vc = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var Wc = function(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    };

    function Xc(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    var Yc = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var Zc = {},
        $c = function(a) {
            this.h = a;
            this.G = !0
        };
    $c.prototype.toString = function() {
        return this.h.toString()
    };
    $c.prototype.g = function() {
        return this.h.toString()
    };
    var ad = function(a) {
        this.h = a
    };
    ad.prototype.toString = function() {
        return this.h + ""
    };
    ad.prototype.G = !0;
    ad.prototype.g = function() {
        return this.h.toString()
    };
    var bd = function(a) {
            return a instanceof ad && a.constructor === ad ? a.h : "type_error:TrustedResourceUrl"
        },
        cd = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        dd = {},
        ed = function(a, b, c) {
            if (null == c) return b;
            if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
            for (var d in c)
                if (Object.prototype.hasOwnProperty.call(c, d)) {
                    var e = c[d];
                    e = Array.isArray(e) ? e : [e];
                    for (var f = 0; f < e.length; f++) {
                        var g = e[f];
                        null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                    }
                }
            return b
        };
    var fd = function(a) {
        this.h = a
    };
    fd.prototype.toString = function() {
        return this.h.toString()
    };
    fd.prototype.G = !0;
    fd.prototype.g = function() {
        return this.h.toString()
    };
    var gd = /^data:(.*);base64,[a-z0-9+\/]+=*$/i,
        hd = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
        id = {},
        jd = new fd("about:invalid#zClosurez", id);
    var kd = {},
        ld = function(a) {
            this.h = a;
            this.G = !0
        };
    ld.prototype.g = function() {
        return this.h.toString()
    };
    ld.prototype.toString = function() {
        return this.h.toString()
    };
    var md = function(a) {
            return a instanceof ld && a.constructor === ld ? a.h : "type_error:SafeHtml"
        },
        nd = function(a) {
            return a instanceof ld ? a : new ld(Ia("object" == typeof a && a.G ? a.g() : String(a)), kd)
        },
        rd = function(a, b) {
            var c = {
                    src: a
                },
                d = {};
            a = {};
            for (var e in c) Object.prototype.hasOwnProperty.call(c, e) && (a[e] = c[e]);
            for (var f in d) Object.prototype.hasOwnProperty.call(d, f) && (a[f] = d[f]);
            if (b)
                for (var g in b)
                    if (Object.prototype.hasOwnProperty.call(b, g)) {
                        e = g.toLowerCase();
                        if (e in c) throw Error("");
                        e in d && delete a[e];
                        a[g] = b[g]
                    }
            var h;
            b = "";
            if (a)
                for (k in a)
                    if (Object.prototype.hasOwnProperty.call(a, k)) {
                        if (!od.test(k)) throw Error("");
                        c = a[k];
                        if (null != c) {
                            g = k;
                            if (c instanceof Tc) c = Uc(c);
                            else {
                                if ("style" == g.toLowerCase()) throw Error("");
                                if (/^on/i.test(g)) throw Error("");
                                if (g.toLowerCase() in pd)
                                    if (c instanceof ad) c = bd(c).toString();
                                    else if (c instanceof fd) c = c instanceof fd && c.constructor === fd ? c.h : "type_error:SafeUrl";
                                else if ("string" === typeof c) c instanceof fd || (c = "object" == typeof c && c.G ? c.g() : String(c), hd.test(c) ? c = new fd(c, id) : (c = String(c), c = c.replace(/(%0A|%0D)/g, ""), c = c.match(gd) ? new fd(c, id) : null)), c = (c || jd).g();
                                else throw Error("");
                            }
                            c.G && (c = c.g());
                            g = g + '="' + Ia(String(c)) + '"';
                            b += " " + g
                        }
                    }
            var k = "<script" + b;
            null == h ? h = [] : Array.isArray(h) || (h = [h]);
            !0 === Yc.script ? k += ">" : (h = qd(h), k += ">" + md(h).toString() + "\x3c/script>");
            return new ld(k, kd)
        },
        td = function(a) {
            var b = nd(sd),
                c = [],
                d = function(e) {
                    Array.isArray(e) ? e.forEach(d) : (e = nd(e), c.push(md(e).toString()))
                };
            a.forEach(d);
            return new ld(c.join(md(b).toString()), kd)
        },
        qd = function(a) {
            return td(Array.prototype.slice.call(arguments))
        },
        od = /^[a-zA-Z0-9-]+$/,
        pd = {
            action: !0,
            cite: !0,
            data: !0,
            formaction: !0,
            href: !0,
            manifest: !0,
            poster: !0,
            src: !0
        },
        sd = new ld(C.trustedTypes && C.trustedTypes.emptyHTML || "", kd);
    var vd = function() {
            a: {
                var a = C.document;
                if (a.querySelector && (a = a.querySelector("script[nonce]")) && (a = a.nonce || a.getAttribute("nonce")) && ud.test(a)) break a;a = ""
            }
            return a
        },
        ud = /^[\w+/_-]+[=]{0,2}$/;
    var wd = function() {
        return La && Na ? !Na.mobile && (F("iPad") || F("Android") || F("Silk")) : F("iPad") || F("Android") && !F("Mobile") || F("Silk")
    };
    var xd = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        yd = function(a) {
            return a ? decodeURI(a) : a
        },
        zd = /#|$/,
        Ad = function(a, b) {
            var c = a.search(zd);
            a: {
                var d = 0;
                for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                    var f = a.charCodeAt(d - 1);
                    if (38 == f || 63 == f)
                        if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                    d += e + 1
                }
                d = -1
            }
            if (0 > d) return null;
            e = a.indexOf("&", d);
            if (0 > e || e > c) e = c;
            d += b.length + 1;
            return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
        };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function Bd(a, b) {
        a.src = bd(b);
        var c, d;
        (c = (b = null == (d = (c = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : d.call(c, "script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", c)
    };

    function Cd(a, b) {
        a.write(md(b))
    };
    var Dd = function(a) {
            try {
                var b;
                if (b = !!a && null != a.location.href) a: {
                    try {
                        Va(a.foo);
                        b = !0;
                        break a
                    } catch (c) {}
                    b = !1
                }
                return b
            } catch (c) {
                return !1
            }
        },
        Ed = function(a) {
            var b = void 0 === b ? !1 : b;
            var c = void 0 === c ? C : c;
            for (var d = 0; c && 40 > d++ && (!b && !Dd(c) || !a(c));) a: {
                try {
                    var e = c.parent;
                    if (e && e != c) {
                        c = e;
                        break a
                    }
                } catch (f) {}
                c = null
            }
        },
        Fd = function(a) {
            var b = a;
            Ed(function(c) {
                b = c;
                return !1
            });
            return b
        },
        Gd = function(a) {
            return Dd(a.top) ? a.top : null
        },
        Hd = function() {
            if (!t.globalThis.crypto) return Math.random();
            try {
                var a = new Uint32Array(1);
                t.globalThis.crypto.getRandomValues(a);
                return a[0] / 65536 / 65536
            } catch (b) {
                return Math.random()
            }
        },
        Id = function(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        },
        Jd = function(a) {
            var b = a.length;
            if (0 == b) return 0;
            for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
            return 0 < c ? c : 4294967296 + c
        },
        Kd = /^(-?[0-9.]{1,30})$/,
        Ld = Vc(function() {
            return (La && Na ? Na.mobile : !wd() && (F("iPod") || F("iPhone") || F("Android") || F("IEMobile"))) ? 2 : wd() ? 1 : 0
        });

    function Md(a, b) {
        if (a.length && b.head) {
            a = x(a);
            for (var c = a.next(); !c.done; c = a.next())
                if ((c = c.value) && b.head) {
                    var d = Nd("META");
                    b.head.appendChild(d);
                    d.httpEquiv = "origin-trial";
                    d.content = c
                }
        }
    }
    var Od = function(a) {
            if ("number" !== typeof a.goog_pvsid) try {
                var b = Object,
                    c = b.defineProperty,
                    d = void 0;
                d = void 0 === d ? Math.random : d;
                var e = Math.floor(d() * Math.pow(2, 52));
                c.call(b, a, "goog_pvsid", {
                    value: e,
                    configurable: !1
                })
            } catch (f) {}
            return Number(a.goog_pvsid) || -1
        },
        Nd = function(a, b) {
            b = void 0 === b ? document : b;
            return b.createElement(String(a).toLowerCase())
        };

    function Pd(a) {
        var b = ra.apply(1, arguments);
        if (0 === b.length) return new ad(a[0], dd);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return new ad(c, dd)
    }

    function Qd(a, b) {
        var c = bd(a).toString();
        if (/#/.test(c)) throw Error("");
        var d = /\?/.test(c) ? "&" : "?";
        b.forEach(function(e, f) {
            e = e instanceof Array ? e : [e];
            for (var g = 0; g < e.length; g++) {
                var h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return new ad(c, dd)
    };
    var Rd = {
        ab: 0,
        Za: 1,
        Wa: 2,
        Ra: 3,
        Xa: 4,
        Sa: 5,
        Ya: 6,
        Ua: 7,
        Va: 8,
        Qa: 9,
        Ta: 10,
        bb: 11
    };
    var Sd = {
        eb: 0,
        fb: 1,
        cb: 2
    };
    var Td = function(a) {
        this.i = N(a)
    };
    B(Td, V);
    Td.prototype.getVersion = function() {
        return Dc(this, 2)
    };
    Td.m = [3];

    function Ud(a) {
        return $a(2 > (a.length + 3) % 4 ? a + "A" : a).map(function(b) {
            return (p = b.toString(2), u(p, "padStart")).call(p, 8, "0")
        }).join("")
    }

    function Vd(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        return parseInt(a, 2)
    }

    function Wd(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function Xd(a) {
        var b = Ud(a + "A"),
            c = Vd(b.slice(0, 6));
        a = Vd(b.slice(6, 12));
        var d = new Td;
        c = Q(d, 1, Qb(c), 0);
        a = Q(c, 2, Qb(a), 0);
        b = b.slice(12);
        c = Vd(b.slice(0, 12));
        d = [];
        for (var e = b.slice(12).replace(/0+$/, ""), f = 0; f < c; f++) {
            if (0 === e.length) throw Error("Found " + f + " of " + c + " sections [" + d + "] but reached end of input [" + b + "]");
            var g = 0 === Vd(e[0]);
            e = e.slice(1);
            var h = Zd(e, b),
                k = 0 === d.length ? 0 : d[d.length - 1];
            k = Wd(h) + k;
            e = e.slice(h.length);
            if (g) d.push(k);
            else {
                g = Zd(e, b);
                h = Wd(g);
                for (var l = 0; l <= h; l++) d.push(k + l);
                e = e.slice(g.length)
            }
        }
        if (0 < e.length) throw Error("Found " + c + " sections [" + d + "] but has remaining input [" + e + "], entire input [" + b + "]");
        return qc(a, 3, d, Pb)
    }

    function Zd(a, b) {
        var c = a.indexOf("11");
        if (-1 === c) throw Error("Expected section bitstring but not found in [" + a + "] part of [" + b + "]");
        return a.slice(0, c + 2)
    };
    var $d = function(a) {
        this.i = N(a)
    };
    B($d, V);
    $d.prototype.getVersion = function() {
        return Dc(this, 1)
    };
    var ae = function(a) {
        this.i = N(a)
    };
    B(ae, V);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    var be = "a".charCodeAt(),
        ce = Xc(Rd),
        de = Xc(Sd);
    var ee = function(a) {
        this.i = N(a)
    };
    B(ee, V);
    var fe = function() {
            var a = new ee;
            return Q(a, 1, Tb(0), "0")
        },
        ge = function(a) {
            var b = Fc(a, 1);
            a = Dc(a, 2);
            return new Date(1E3 * b + a / 1E6)
        };
    var he = function(a) {
            if (/[^01]/.test(a)) throw Error("Input bitstring " + a + " is malformed!");
            this.h = a;
            this.g = 0
        },
        ke = function(a) {
            var b = X(a, 16);
            return !0 === !!X(a, 1) ? (a = ie(a), a.forEach(function(c) {
                if (c > b) throw Error("ID " + c + " is past MaxVendorId " + b + "!");
            }), a) : je(a, b)
        },
        ie = function(a) {
            for (var b = X(a, 12), c = []; b--;) {
                var d = !0 === !!X(a, 1),
                    e = X(a, 16);
                if (d)
                    for (d = X(a, 16); e <= d; e++) c.push(e);
                else c.push(e)
            }
            c.sort(function(f, g) {
                return f - g
            });
            return c
        },
        je = function(a, b, c) {
            for (var d = [], e = 0; e < b; e++)
                if (X(a, 1)) {
                    var f = e + 1;
                    if (c && -1 === c.indexOf(f)) throw Error("ID: " + f + " is outside of allowed values!");
                    d.push(f)
                }
            return d
        },
        X = function(a, b) {
            if (a.g + b > a.h.length) throw Error("Requested length " + b + " is past end of string.");
            var c = a.h.substring(a.g, a.g + b);
            a.g += b;
            return parseInt(c, 2)
        };
    var me = function(a, b) {
            try {
                var c = $a(a.split(".")[0]).map(function(e) {
                        return (p = e.toString(2), u(p, "padStart")).call(p, 8, "0")
                    }).join(""),
                    d = new he(c);
                c = {};
                c.tcString = a;
                c.gdprApplies = !0;
                d.g += 78;
                c.cmpId = X(d, 12);
                c.cmpVersion = X(d, 12);
                d.g += 30;
                c.tcfPolicyVersion = X(d, 6);
                c.isServiceSpecific = !!X(d, 1);
                c.useNonStandardStacks = !!X(d, 1);
                c.specialFeatureOptins = le(je(d, 12, de), de);
                c.purpose = {
                    consents: le(je(d, 24, ce), ce),
                    legitimateInterests: le(je(d, 24, ce), ce)
                };
                c.purposeOneTreatment = !!X(d, 1);
                c.publisherCC = String.fromCharCode(be + X(d, 6)) + String.fromCharCode(be + X(d, 6));
                c.vendor = {
                    consents: le(ke(d), b),
                    legitimateInterests: le(ke(d), b)
                };
                return c
            } catch (e) {
                return null
            }
        },
        le = function(a, b) {
            var c = {};
            if (Array.isArray(b) && 0 !== b.length) {
                b = x(b);
                for (var d = b.next(); !d.done; d = b.next()) d = d.value, c[d] = -1 !== a.indexOf(d)
            } else
                for (a = x(a), d = a.next(); !d.done; d = a.next()) c[d.value] = !0;
            delete c[0];
            return c
        };
    var ne = function(a) {
        this.i = N(a)
    };
    B(ne, V);

    function oe(a, b) {
        var c = function(d) {
            var e = {};
            return [(e[d.ya] = d.ua, e)]
        };
        return JSON.stringify([a.filter(function(d) {
            return d.W
        }).map(c), b.toJSON(), a.filter(function(d) {
            return !d.W
        }).map(c)])
    }
    var pe = function(a, b) {
        var c = new ne;
        a = Q(c, 1, Ob(a), 0);
        b = Q(a, 2, M(b), "");
        a = b.i;
        c = L(a);
        this.l = c & 2 ? b : bc(b.constructor, jc(a, c, !0))
    };
    var qe = function(a) {
        this.i = N(a)
    };
    B(qe, V);
    var re = function(a) {
        this.i = N(a)
    };
    B(re, V);
    var se = function(a, b) {
            return Q(a, 1, Ob(b), 0)
        },
        te = function(a, b) {
            return Q(a, 2, Ob(b), 0)
        };
    var ue = function(a) {
        this.i = N(a)
    };
    B(ue, V);
    var ve = [1, 2];
    var we = function(a) {
        this.i = N(a)
    };
    B(we, V);
    var xe = function(a, b) {
            return xc(a, 1, b)
        },
        ye = function(a, b) {
            return zc(a, 2, b)
        },
        ze = function(a, b) {
            return qc(a, 4, b, Pb)
        },
        Ae = function(a, b) {
            return zc(a, 5, b)
        },
        Be = function(a, b) {
            return Q(a, 6, Ob(b), 0)
        };
    we.m = [2, 4, 5];
    var Ce = function(a) {
        this.i = N(a)
    };
    B(Ce, V);
    Ce.m = [5];
    var De = [1, 2, 3, 4];
    var Ee = function(a) {
        this.i = N(a)
    };
    B(Ee, V);
    Ee.m = [2, 3];
    var Fe = function(a) {
        this.i = N(a)
    };
    B(Fe, V);
    Fe.prototype.getTagSessionCorrelator = function() {
        return Fc(this, 2)
    };
    var He = function(a) {
            var b = new Fe;
            return yc(b, 4, Ge, a)
        },
        Ge = [4, 5, 7, 8];
    var Ie = function(a) {
        this.i = N(a)
    };
    B(Ie, V);
    Ie.m = [3];
    var Je = function(a) {
        this.i = N(a)
    };
    B(Je, V);
    Je.m = [4, 5];
    var Ke = function(a) {
        this.i = N(a)
    };
    B(Ke, V);
    Ke.prototype.getTagSessionCorrelator = function() {
        return Fc(this, 1)
    };
    Ke.m = [2];
    var Le = function(a) {
        this.i = N(a)
    };
    B(Le, V);
    var Me = [4, 6];
    var Ne = function() {
        pe.apply(this, arguments)
    };
    B(Ne, pe);
    var Oe = function() {
        Ne.apply(this, arguments)
    };
    B(Oe, Ne);
    Oe.prototype.Oa = function() {
        this.F.apply(this, y(ra.apply(0, arguments).map(function(a) {
            return {
                W: !0,
                ya: 2,
                ua: a.toJSON()
            }
        })))
    };
    Oe.prototype.Z = function() {
        this.F.apply(this, y(ra.apply(0, arguments).map(function(a) {
            return {
                W: !0,
                ya: 4,
                ua: a.toJSON()
            }
        })))
    };
    var Pe = function(a, b) {
        if (t.globalThis.fetch) t.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var Qe = function(a, b, c, d, e, f, g, h) {
        Oe.call(this, a, b);
        this.N = c;
        this.L = d;
        this.J = e;
        this.H = f;
        this.K = g;
        this.j = h;
        this.g = [];
        this.h = null;
        this.o = !1
    };
    B(Qe, Oe);
    var Re = function(a) {
        null !== a.h && (clearTimeout(a.h), a.h = null);
        if (a.g.length) {
            var b = oe(a.g, a.l);
            a.L(a.N + "?e=1", b);
            a.g = []
        }
    };
    Qe.prototype.F = function() {
        var a = ra.apply(0, arguments),
            b = this;
        this.K && 65536 <= oe(this.g.concat(a), this.l).length && Re(this);
        this.j && !this.o && (this.o = !0, this.j.g(function() {
            Re(b)
        }));
        this.g.push.apply(this.g, y(a));
        this.g.length >= this.H && Re(this);
        this.g.length && null === this.h && (this.h = setTimeout(function() {
            Re(b)
        }, this.J))
    };
    var Se = function(a, b, c, d, e, f) {
        Qe.call(this, a, b, "https://pagead2.googlesyndication.com/pagead/ping", Pe, void 0 === c ? 1E3 : c, void 0 === d ? 100 : d, (void 0 === e ? !1 : e) && !!t.globalThis.fetch, f)
    };
    B(Se, Qe);
    var Te = function(a) {
            this.g = a;
            this.defaultValue = !1
        },
        Ue = function(a) {
            this.g = a;
            this.defaultValue = 0
        };
    var Ve = new Te(501898423),
        We = new Te(579875511),
        Xe = new Te(547249510),
        Ye = new Te(537116804),
        Ze = new Ue(523264412),
        $e = new Ue(24),
        af = new function(a, b) {
            b = void 0 === b ? [] : b;
            this.g = a;
            this.defaultValue = b
        }(1934, ["As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "A/ERL66fN363FkXxgDc6F1+ucRUkAhjEca9W3la6xaLnD2Y1lABsqmdaJmPNaUKPKVBRpyMKEhXYl7rSvrQw+AkAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A6OdGH3fVf4eKRDbXb4thXA4InNqDJDRhZ8U533U/roYjp4Yau0T3YSuc63vmAs/8ga1cD0E3A7LEq6AXk1uXgsAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"]);
    var bf = new Te(203);
    var cf = function(a) {
        this.i = N(a)
    };
    B(cf, V);
    var df = function(a) {
        this.i = N(a)
    };
    B(df, V);
    var ef = function(a) {
        this.i = N(a)
    };
    B(ef, V);
    var ff = function(a) {
        this.i = N(a)
    };
    B(ff, V);
    var gf = Nc(ff);
    ff.m = [7];
    var hf = function(a) {
        this.g = a || {
            cookie: ""
        }
    };
    hf.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.mb;
            d = c.nb || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.Ia
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    hf.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.g.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = za(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    hf.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    hf.prototype.clear = function() {
        for (var a = (this.g.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = za(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) c = b[a], this.get(c), this.set(c, "", {
            Ia: 0,
            path: void 0,
            domain: void 0
        })
    };

    function jf(a) {
        a = kf(a);
        try {
            var b = a ? gf(a) : null
        } catch (c) {
            b = null
        }
        return b ? R(b, ef, 4) || null : null
    }

    function kf(a) {
        a = (new hf(a)).get("FCCDCF", "");
        if (a)
            if (u(a, "startsWith").call(a, "%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };
    var lf = function(a) {
            this.g = a;
            this.h = null
        },
        nf = function(a) {
            a.__uspapiPostMessageReady || mf(new lf(a))
        },
        mf = function(a) {
            a.h = function(b) {
                var c = "string" === typeof b.data;
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__uspapiCall;
                e && "getUSPData" === e.command && a.g.__uspapi(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__uspapiReturn = {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                    return f
                })
            };
            a.g.addEventListener("message", a.h);
            a.g.__uspapiPostMessageReady = !0
        };
    [].concat(y(new t.Map([
        [8, "usca"],
        [9, "usva"],
        [10, "usco"],
        [12, "usct"],
        [11, "usut"]
    ]))).sort(function(a, b) {
        return a[0] - b[0]
    }).map(function(a) {
        return a[1]
    });
    var of = new $d, pf = Q( of , 1, Qb(1), 0), qf = new ae;
    xc(qf, 1, pf);
    Xc(Rd).map(function(a) {
        return Number(a)
    });
    Xc(Sd).map(function(a) {
        return Number(a)
    });
    var rf = function(a) {
            this.g = a;
            this.h = null
        },
        tf = function(a) {
            a.__tcfapiPostMessageReady || sf(new rf(a))
        },
        sf = function(a) {
            a.h = function(b) {
                var c = "string" == typeof b.data;
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__tcfapiCall;
                !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.g.__tcfapi(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__tcfapiReturn = "removeEventListener" === e.command ? {
                        success: f,
                        callId: e.callId
                    } : {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                    return f
                }, e.parameter)
            };
            a.g.addEventListener("message", a.h);
            a.g.__tcfapiPostMessageReady = !0
        };
    var uf = function(a) {
        this.i = N(a)
    };
    B(uf, V);
    var vf = function(a) {
        this.i = N(a)
    };
    B(vf, V);
    var wf = Nc(vf);
    vf.m = [2];

    function xf(a, b, c) {
        function d(m) {
            if (10 > m.length) return null;
            var n = g(m.slice(0, 4));
            n = h(n);
            m = g(m.slice(6, 10));
            m = k(m);
            return "1" + n + m + "N"
        }

        function e(m) {
            if (10 > m.length) return null;
            var n = g(m.slice(0, 6));
            n = h(n);
            m = g(m.slice(6, 10));
            m = k(m);
            return "1" + n + m + "N"
        }

        function f(m) {
            if (12 > m.length) return null;
            var n = g(m.slice(0, 6));
            n = h(n);
            m = g(m.slice(8, 12));
            m = k(m);
            return "1" + n + m + "N"
        }

        function g(m) {
            for (var n = [], r = 0, q = 0; q < m.length / 2; q++) n.push(Vd(m.slice(r, r + 2))), r += 2;
            return n
        }

        function h(m) {
            return m.every(function(n) {
                return 1 === n
            }) ? "Y" : "N"
        }

        function k(m) {
            return m.some(function(n) {
                return 1 === n
            }) ? "Y" : "N"
        }
        if (0 === a.length) return null;
        a = a.split(".");
        if (2 < a.length) return null;
        a = Ud(a[0]);
        var l = Vd(a.slice(0, 6));
        a = a.slice(6);
        if (1 !== l) return null;
        switch (b) {
            case 8:
                return d(a);
            case 10:
            case 12:
            case 9:
                return e(a);
            case 11:
                return c ? f(a) : null;
            default:
                return null
        }
    };
    var yf = function(a, b) {
        var c = a.document,
            d = function() {
                if (!a.frames[b])
                    if (c.body) {
                        var e = Nd("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var Bf = function(a, b) {
            this.g = a;
            this.o = b;
            var c;
            b = kf(this.g.document);
            try {
                var d = b ? gf(b) : null
            } catch (e) {
                d = null
            }(b = d) ? (d = R(b, df, 5) || null, b = null != (c = S(b, cf, 7)) ? c : [], c = zf(b), c = {
                oa: d,
                ra: c
            }) : c = {
                oa: null,
                ra: null
            };
            d = c;
            c = Af(this, d.ra);
            d = d.oa;
            null != d && null != Yb(mc(d, 2)) && 0 !== T(d, 2).length ? (b = void 0 !== vc(d, ee, 1, !1) ? R(d, ee, 1) : fe(), d = {
                M: T(d, 2),
                T: ge(b)
            }) : d = null;
            this.l = d && c ? c.T > d.T ? c.M : d.M : d ? d.M : c ? c.M : null;
            this.h = (c = jf(a.document)) && null != Yb(mc(c, 1)) ? T(c, 1) : null;
            this.j = (a = jf(a.document)) && null != Yb(mc(a, 2)) ? T(a, 2) : null
        },
        Ff = function(a) {
            var b = Cf(We);
            a !== a.top || a.__uspapi || a.frames.__uspapiLocator || (a = new Bf(a, b), Df(a), Ef(a))
        },
        Df = function(a) {
            !a.l || a.g.__uspapi || a.g.frames.__uspapiLocator || (a.g.__uspapiManager = "fc", yf(a.g, "__uspapiLocator"), xa("__uspapi", function() {
                return a.H.apply(a, y(ra.apply(0, arguments)))
            }, a.g), nf(a.g))
        };
    Bf.prototype.H = function(a, b, c) {
        "function" === typeof c && "getUSPData" === a && c({
            version: 1,
            uspString: this.l
        }, !0)
    };
    var zf = function(a) {
            a = u(a, "find").call(a, function(b) {
                return 13 === U(b, 1)
            });
            if (null == a ? 0 : null != Yb(mc(a, 2))) try {
                return wf(T(a, 2))
            } catch (b) {}
            return null
        },
        Af = function(a, b) {
            if (null == b || null == Yb(mc(b, 1)) || 0 === T(b, 1).length || 0 == S(b, uf, 2).length) return null;
            var c = T(b, 1);
            try {
                var d = Xd(c.split("~")[0]);
                var e = u(c, "includes").call(c, "~") ? c.split("~").slice(1) : []
            } catch (f) {
                return null
            }
            b = S(b, uf, 2).reduce(function(f, g) {
                return Fc(Gf(f), 1) > Fc(Gf(g), 1) ? f : g
            });
            d = oc(d, 3, Rb).indexOf(Dc(b, 1));
            return -1 === d || d >= e.length ? null : {
                M: xf(e[d], Dc(b, 1), a.o),
                T: ge(Gf(b))
            }
        },
        Gf = function(a) {
            return void 0 !== vc(a, ee, 2, !1) ? R(a, ee, 2) : fe()
        },
        Ef = function(a) {
            !a.h || a.g.__tcfapi || a.g.frames.__tcfapiLocator || (a.g.__tcfapiManager = "fc", yf(a.g, "__tcfapiLocator"), a.g.__tcfapiEventListeners = a.g.__tcfapiEventListeners || [], xa("__tcfapi", function() {
                return a.F.apply(a, y(ra.apply(0, arguments)))
            }, a.g), tf(a.g))
        };
    Bf.prototype.F = function(a, b, c, d) {
        d = void 0 === d ? null : d;
        if ("function" === typeof c)
            if (b && (2.1 < b || 1 >= b)) c(null, !1);
            else switch (b = this.g.__tcfapiEventListeners, a) {
                case "getTCData":
                    !d || Array.isArray(d) && d.every(function(e) {
                        return "number" === typeof e
                    }) ? c(Hf(this, d, null), !0) : c(null, !1);
                    break;
                case "ping":
                    c({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.1",
                        cmpVersion: 2,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    a = b.push(c);
                    c(Hf(this, null, a - 1), !0);
                    break;
                case "removeEventListener":
                    b[d] ? (b[d] = null, c(!0)) : c(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    c(null, !1)
            }
    };
    var Hf = function(a, b, c) {
        if (!a.h) return null;
        b = me(a.h, b);
        b.addtlConsent = null != a.j ? a.j : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    };
    var If = function(a) {
        return "string" === typeof a
    };
    var Jf = function(a, b) {
        var c = void 0 === c ? {} : c;
        this.error = a;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror";
        this.meta = c
    };
    var Kf = null;
    var Lf = function(a) {
        this.i = N(a)
    };
    B(Lf, V);
    Lf.m = [2, 8];
    var Mf = [3, 4, 5],
        Nf = [6, 7];

    function Of(a) {
        return null != a ? !a : a
    }

    function Pf(a, b) {
        for (var c = !1, d = 0; d < a.length; d++) {
            var e = a[d]();
            if (e === b) return e;
            null == e && (c = !0)
        }
        if (!c) return !b
    }

    function Qf(a, b) {
        var c = S(a, Lf, 2);
        if (!c.length) return Rf(a, b);
        a = U(a, 1);
        if (1 === a) return Of(Qf(c[0], b));
        c = Ta(c, function(d) {
            return function() {
                return Qf(d, b)
            }
        });
        switch (a) {
            case 2:
                return Pf(c, !1);
            case 3:
                return Pf(c, !0)
        }
    }

    function Rf(a, b) {
        var c = uc(a, Mf);
        a: {
            switch (c) {
                case 3:
                    var d = U(a, tc(a, Mf, 3));
                    break a;
                case 4:
                    d = U(a, tc(a, Mf, 4));
                    break a;
                case 5:
                    d = U(a, tc(a, Mf, 5));
                    break a
            }
            d = void 0
        }
        if (d && (b = (b = b[c]) && b[d])) {
            try {
                var e = b.apply(null, y(oc(a, 8, Yb)))
            } catch (f) {
                return
            }
            b = U(a, 1);
            if (4 === b) return !!e;
            if (5 === b) return null != e;
            if (12 === b) a = T(a, tc(a, Nf, 7));
            else a: {
                switch (c) {
                    case 4:
                        a = Gc(a, tc(a, Nf, 6));
                        break a;
                    case 5:
                        a = T(a, tc(a, Nf, 7));
                        break a
                }
                a = void 0
            }
            if (null != a) {
                if (6 === b) return e === a;
                if (9 === b) return null != e && 0 === Ka(String(e), a);
                if (null != e) switch (b) {
                    case 7:
                        return e < a;
                    case 8:
                        return e > a;
                    case 12:
                        return If(a) && If(e) && (new RegExp(a)).test(e);
                    case 10:
                        return null != e && -1 === Ka(String(e), a);
                    case 11:
                        return null != e && 1 === Ka(String(e), a)
                }
            }
        }
    }

    function Sf(a, b) {
        return !a || !(!b || !Qf(a, b))
    };
    var Tf = function(a) {
        this.i = N(a)
    };
    B(Tf, V);
    Tf.m = [4];
    var Uf = function(a) {
        this.i = N(a)
    };
    B(Uf, V);
    var Vf = function(a) {
        this.i = N(a)
    };
    B(Vf, V);
    var Wf = Nc(Vf);
    Vf.m = [5];
    var Xf = [1, 2, 3, 6, 7];
    var Yf = function(a, b, c) {
            var d = void 0 === d ? new Se(6, "unknown", b) : d;
            this.o = a;
            this.l = c;
            this.h = d;
            this.g = [];
            this.j = 0 < a && Hd() < 1 / a
        },
        $f = function(a, b, c, d, e, f) {
            if (a.j) {
                var g = te(se(new re, b), c);
                b = Be(ye(xe(Ae(ze(new we, d), e), g), a.g.slice()), f);
                b = He(b);
                a.h.Z(Zf(a, b));
                if (1 === f || 3 === f || 4 === f && !a.g.some(function(h) {
                        return U(h, 1) === U(g, 1) && U(h, 2) === c
                    })) a.g.push(g), 100 < a.g.length && a.g.shift()
            }
        },
        ag = function(a, b, c, d) {
            if (a.j && a.l) {
                var e = new Ee;
                b = zc(e, 2, b);
                c = zc(b, 3, c);
                d && Q(c, 1, Qb(d), 0);
                d = new Fe;
                d = yc(d, 7, Ge, c);
                a.h.Z(Zf(a, d))
            }
        },
        bg = function(a, b, c, d) {
            if (a.j) {
                var e = new qe;
                b = P(e, 1, Qb(b));
                c = P(b, 2, Qb(c));
                d = P(c, 3, Ob(d));
                c = new Fe;
                d = yc(c, 8, Ge, d);
                a.h.Z(Zf(a, d))
            }
        },
        Zf = function(a, b) {
            var c = Date.now();
            c = u(Number, "isFinite").call(Number, c) ? Math.round(c) : 0;
            b = Q(b, 1, Tb(c), "0");
            c = Od(window);
            b = Q(b, 2, Tb(c), "0");
            return Q(b, 6, Tb(a.o), "0")
        };
    var W = function(a) {
        var b = "V";
        if (a.V && a.hasOwnProperty(b)) return a.V;
        b = new a;
        return a.V = b
    };
    var cg = function() {
        var a = {};
        this.u = (a[3] = {}, a[4] = {}, a[5] = {}, a)
    };
    var dg = /^true$/.test("false");

    function eg(a, b) {
        switch (b) {
            case 1:
                return U(a, tc(a, Xf, 1));
            case 2:
                return U(a, tc(a, Xf, 2));
            case 3:
                return U(a, tc(a, Xf, 3));
            case 6:
                return U(a, tc(a, Xf, 6));
            default:
                return null
        }
    }

    function fg(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return Cc(a, 1);
            case 7:
                return T(a, 3);
            case 2:
                return Gc(a, 2);
            case 3:
                return T(a, 3);
            case 6:
                return oc(a, 4, Yb);
            default:
                return null
        }
    }
    var gg = Vc(function() {
        if (!dg) return {};
        try {
            var a;
            var b = void 0 === b ? window : b;
            try {
                var c = b.sessionStorage
            } catch (e) {
                c = null
            }
            var d = null == (a = c) ? void 0 : a.getItem("GGDFSSK");
            if (d) return JSON.parse(d)
        } catch (e) {}
        return {}
    });

    function hg(a, b, c, d) {
        var e = d = void 0 === d ? 0 : d,
            f, g;
        W(ig).j[e] = null != (g = null == (f = W(ig).j[e]) ? void 0 : f.add(b)) ? g : (new t.Set).add(b);
        e = gg();
        if (null != e[b]) return e[b];
        b = jg(d)[b];
        if (!b) return c;
        b = Wf(JSON.stringify(b));
        b = kg(b);
        a = fg(b, a);
        return null != a ? a : c
    }

    function kg(a) {
        var b = W(cg).u;
        if (b) {
            var c = Ua(S(a, Uf, 5), function(f) {
                return Sf(R(f, Lf, 1), b)
            });
            if (c) {
                var d;
                return null != (d = R(c, Tf, 2)) ? d : null
            }
        }
        var e;
        return null != (e = R(a, Tf, 4)) ? e : null
    }
    var ig = function() {
        this.h = {};
        this.l = [];
        this.j = {};
        this.g = new t.Map
    };

    function lg(a, b, c) {
        return !!hg(1, a, void 0 === b ? !1 : b, c)
    }

    function mg(a, b, c) {
        b = void 0 === b ? 0 : b;
        a = Number(hg(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function ng(a, b, c) {
        b = void 0 === b ? "" : b;
        a = hg(3, a, b, c);
        return "string" === typeof a ? a : b
    }

    function og(a, b, c) {
        b = void 0 === b ? [] : b;
        a = hg(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function jg(a) {
        return W(ig).h[a] || (W(ig).h[a] = {})
    }

    function pg(a, b) {
        var c = jg(b);
        Id(a, function(d, e) {
            return c[e] = d
        })
    }

    function qg(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        var f = [],
            g = [];
        Sa(b, function(h) {
            var k = jg(h);
            Sa(a, function(l) {
                var m = uc(l, Xf),
                    n = eg(l, m);
                if (n) {
                    var r, q, A;
                    var v = null != (A = null == (r = W(ig).g.get(h)) ? void 0 : null == (q = r.get(n)) ? void 0 : q.slice(0)) ? A : [];
                    a: {
                        r = new Ce;
                        switch (m) {
                            case 1:
                                sc(r, 1, De, Ob(n));
                                break;
                            case 2:
                                sc(r, 2, De, Ob(n));
                                break;
                            case 3:
                                sc(r, 3, De, Ob(n));
                                break;
                            case 6:
                                sc(r, 4, De, Ob(n));
                                break;
                            default:
                                m = void 0;
                                break a
                        }
                        qc(r, 5, v, Pb);m = r
                    }
                    if (v = m) {
                        var D;
                        v = !(null == (D = W(ig).j[h]) || !D.has(n))
                    }
                    v && f.push(m);
                    if (D = m) {
                        var E;
                        D = !(null == (E = W(ig).g.get(h)) || !E.has(n))
                    }
                    D && g.push(m);
                    e || (E = W(ig), E.g.has(h) || E.g.set(h, new t.Map), E.g.get(h).has(n) || E.g.get(h).set(n, []), d && E.g.get(h).get(n).push(d));
                    k[n] = l.toJSON()
                }
            })
        });
        (f.length || g.length) && ag(c, f, g, null != d ? d : void 0)
    }

    function rg(a, b) {
        var c = jg(b);
        Sa(a, function(d) {
            var e = Wf(JSON.stringify(d)),
                f = uc(e, Xf);
            (e = eg(e, f)) && (c[e] || (c[e] = d))
        })
    }

    function sg() {
        return Ta(u(Object, "keys").call(Object, W(ig).h), function(a) {
            return Number(a)
        })
    }

    function tg(a) {
        var b = W(ig).l;
        0 <= Array.prototype.indexOf.call(b, a, void 0) || pg(jg(4), a)
    };

    function Y(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function ug(a, b, c) {
        return b[a] || c
    }

    function vg(a) {
        Y(5, lg, a);
        Y(6, mg, a);
        Y(7, ng, a);
        Y(8, og, a);
        Y(13, rg, a);
        Y(15, tg, a)
    }

    function wg(a) {
        Y(4, function(b) {
            W(cg).u = b
        }, a);
        Y(9, function(b, c) {
            var d = W(cg);
            null == d.u[3][b] && (d.u[3][b] = c)
        }, a);
        Y(10, function(b, c) {
            var d = W(cg);
            null == d.u[4][b] && (d.u[4][b] = c)
        }, a);
        Y(11, function(b, c) {
            var d = W(cg);
            null == d.u[5][b] && (d.u[5][b] = c)
        }, a);
        Y(14, function(b) {
            for (var c = W(cg), d = x([3, 4, 5]), e = d.next(); !e.done; e = d.next()) e = e.value, u(Object, "assign").call(Object, c.u[e], b[e])
        }, a)
    }

    function xg(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };
    var yg = function() {};
    yg.prototype.h = function() {};
    yg.prototype.g = function() {
        return []
    };
    var zg = function(a, b, c) {
        a.h = function(d, e) {
            ug(2, b, function() {
                return []
            })(d, c, e)
        };
        a.g = function() {
            return ug(3, b, function() {
                return []
            })(c)
        }
    };

    function Ag(a, b) {
        try {
            var c = a.split(".");
            a = C;
            for (var d = 0, e; null != a && d < c.length; d++) e = a, a = a[c[d]], "function" === typeof a && (a = e[c[d]]());
            var f = a;
            if (typeof f === b) return f
        } catch (g) {}
    }
    var Bg = {},
        Cg = {},
        Dg = {},
        Eg = {},
        Fg = (Eg[3] = (Bg[8] = function(a) {
            try {
                return null != ua(a)
            } catch (b) {}
        }, Bg[9] = function(a) {
            try {
                var b = ua(a)
            } catch (c) {
                return
            }
            if (a = "function" === typeof b) b = b && b.toString && b.toString(), a = "string" === typeof b && -1 != b.indexOf("[native code]");
            return a
        }, Bg[10] = function() {
            return window === window.top
        }, Bg[6] = function(a) {
            var b = W(yg).g();
            return 0 <= Array.prototype.indexOf.call(b, Number(a), void 0)
        }, Bg[27] = function(a) {
            a = Ag(a, "boolean");
            return void 0 !== a ? a : void 0
        }, Bg[60] = function(a) {
            try {
                return !!C.document.querySelector(a)
            } catch (b) {}
        }, Bg[69] = function(a) {
            var b = C.document;
            b = void 0 === b ? document : b;
            var c;
            return !(null == (c = b.featurePolicy) || !(p = c.features(), u(p, "includes")).call(p, a))
        }, Bg[70] = function(a) {
            var b = C.document;
            b = void 0 === b ? document : b;
            var c;
            return !(null == (c = b.featurePolicy) || !(p = c.allowedFeatures(), u(p, "includes")).call(p, a))
        }, Bg), Eg[4] = (Cg[3] = function() {
            return Ld()
        }, Cg[6] = function(a) {
            a = Ag(a, "number");
            return void 0 !== a ? a : void 0
        }, Cg), Eg[5] = (Dg[2] = function() {
            return window.location.href
        }, Dg[3] = function() {
            try {
                return window.top.location.hash
            } catch (a) {
                return ""
            }
        }, Dg[4] = function(a) {
            a = Ag(a, "string");
            return void 0 !== a ? a : void 0
        }, Dg), Eg);

    function Gg() {
        var a = void 0 === a ? C : a;
        return a.ggeac || (a.ggeac = {})
    };
    var Hg = function(a) {
        this.i = N(a)
    };
    B(Hg, V);
    Hg.prototype.getId = function() {
        return Dc(this, 1)
    };
    Hg.m = [2];
    var Ig = function(a) {
        this.i = N(a)
    };
    B(Ig, V);
    Ig.m = [2];
    var Jg = function(a) {
        this.i = N(a)
    };
    B(Jg, V);
    Jg.m = [2];
    var Kg = function(a) {
        this.i = N(a)
    };
    B(Kg, V);
    var Lg = function(a) {
        this.i = N(a)
    };
    B(Lg, V);
    Lg.m = [1, 4, 2, 3];

    function Mg(a) {
        var b = {};
        return Ng((b[0] = new t.Map, b[1] = new t.Map, b[2] = new t.Map, b), a)
    }

    function Ng(a, b) {
        for (var c = new t.Map, d = x(u(a[1], "entries").call(a[1])), e = d.next(); !e.done; e = d.next()) {
            var f = x(e.value);
            e = f.next().value;
            f = f.next().value;
            f = f[f.length - 1];
            c.set(e, f.xa + f.va * f.wa)
        }
        b = x(b);
        for (d = b.next(); !d.done; d = b.next())
            for (d = d.value, e = x(S(d, Ig, 2)), f = e.next(); !f.done; f = e.next())
                if (f = f.value, 0 !== S(f, Hg, 2).length) {
                    var g = Ec(f, 8);
                    if (U(f, 4) && !U(f, 13)) {
                        var h = void 0;
                        g = null != (h = c.get(U(f, 4))) ? h : 0;
                        h = Ec(f, 1) * S(f, Hg, 2).length;
                        c.set(U(f, 4), g + h)
                    }
                    h = [];
                    for (var k = 0; k < S(f, Hg, 2).length; k++) {
                        var l = {
                            xa: g,
                            va: Ec(f, 1),
                            wa: S(f, Hg, 2).length,
                            Ja: k,
                            qa: U(d, 1),
                            O: f,
                            D: S(f, Hg, 2)[k]
                        };
                        h.push(l)
                    }
                    Og(a[2], U(f, 10), h) || Og(a[1], U(f, 4), h) || Og(a[0], S(f, Hg, 2)[0].getId(), h)
                }
        return a
    }

    function Og(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        var d;
        (d = a.get(b)).push.apply(d, y(c));
        return !0
    };

    function Pg(a) {
        a = void 0 === a ? Hd() : a;
        return function(b) {
            return Jd(b + " + " + a) % 1E3
        }
    };
    var Qg = [12, 13, 20],
        Rg = function(a, b, c, d) {
            d = void 0 === d ? {} : d;
            var e = void 0 === d.U ? !1 : d.U;
            d = void 0 === d.Ma ? [] : d.Ma;
            this.I = a;
            this.B = c;
            this.l = {};
            this.U = e;
            a = {};
            this.g = (a[b] = [], a[4] = [], a);
            this.h = {};
            this.j = {};
            var f;
            if (null === Kf) {
                Kf = "";
                try {
                    b = "";
                    try {
                        b = C.top.location.hash
                    } catch (g) {
                        b = C.location.hash
                    }
                    b && (Kf = (f = b.match(/\bdeid=([\d,]+)/)) ? f[1] : "")
                } catch (g) {}
            }
            if (f = Kf)
                for (f = x(f.split(",") || []), b = f.next(); !b.done; b = f.next())(b = Number(b.value)) && (this.h[b] = !0);
            d = x(d);
            for (f = d.next(); !f.done; f = d.next()) this.h[f.value] = !0
        },
        Tg = function(a, b, c, d) {
            var e = [],
                f;
            if (f = 9 !== b) a.l[b] ? f = !0 : (a.l[b] = !0, f = !1);
            if (f) return $f(a.B, b, c, e, [], 4), e;
            f = u(Qg, "includes").call(Qg, b);
            for (var g = [], h = W(cg).u, k = [], l = x([0, 1, 2]), m = l.next(); !m.done; m = l.next()) {
                m = m.value;
                for (var n = x(u(a.I[m], "entries").call(a.I[m])), r = n.next(); !r.done; r = n.next()) {
                    var q = x(r.value);
                    r = q.next().value;
                    q = q.next().value;
                    var A = r,
                        v = q;
                    r = new ue;
                    q = v.filter(function(wa) {
                        return wa.qa === b && !!a.h[wa.D.getId()] && Sf(R(wa.O, Lf, 3), h) && Sf(R(wa.D, Lf, 3), h)
                    });
                    if (q.length)
                        for (r = x(q), v = r.next(); !v.done; v = r.next()) k.push(v.value.D);
                    else if (!a.U) {
                        q = void 0;
                        2 === m ? (q = d[1], sc(r, 2, ve, Ob(A))) : q = d[0];
                        var D = void 0,
                            E = void 0;
                        q = null != (E = null == (D = q) ? void 0 : D(String(A))) ? E : 2 === m && 1 === U(v[0].O, 11) ? void 0 : d[0](String(A));
                        if (void 0 !== q) {
                            A = x(v);
                            for (v = A.next(); !v.done; v = A.next())
                                if (v = v.value, v.qa === b) {
                                    D = q - v.xa;
                                    var ma = v;
                                    E = ma.va;
                                    var Aa = ma.wa;
                                    ma = ma.Ja;
                                    0 <= D && D < E * Aa && D % Aa === ma && Sf(R(v.O, Lf, 3), h) && Sf(R(v.D, Lf, 3), h) && (D = U(v.O, 13), 0 !== D && void 0 !== D && (E = a.j[String(D)], void 0 !== E && E !== v.D.getId() ? bg(a.B, a.j[String(D)], v.D.getId(), D) : a.j[String(D)] = v.D.getId()), k.push(v.D))
                                }
                            0 !== uc(r, ve) && (Q(r, 3, Qb(q), 0), g.push(r))
                        }
                    }
                }
            }
            d = x(k);
            for (k = d.next(); !k.done; k = d.next()) k = k.value, l = k.getId(), e.push(l), Sg(a, l, f ? 4 : c), qg(S(k, Vf, 2), f ? sg() : [c], a.B, l);
            $f(a.B, b, c, e, g, 1);
            return e
        },
        Sg = function(a, b, c) {
            a.g[c] || (a.g[c] = []);
            a = a.g[c];
            u(a, "includes").call(a, b) || a.push(b)
        },
        Ug = function(a, b) {
            b = b.map(function(c) {
                return new Jg(c)
            }).filter(function(c) {
                return !u(Qg, "includes").call(Qg, U(c, 1))
            });
            a.I = Ng(a.I, b)
        },
        Vg = function(a, b) {
            Y(1, function(c) {
                a.h[c] = !0
            }, b);
            Y(2, function(c, d, e) {
                return Tg(a, c, d, e)
            }, b);
            Y(3, function(c) {
                return (a.g[c] || []).concat(a.g[4])
            }, b);
            Y(12, function(c) {
                return void Ug(a, c)
            }, b);
            Y(16, function(c, d) {
                return void Sg(a, c, d)
            }, b)
        };
    var Wg = function() {
        var a = {};
        this.h = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.g = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.o = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.j = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.l = function() {}
    };

    function Cf(a) {
        return W(Wg).h(a.g, a.defaultValue)
    };
    var Xg = function() {
            this.g = function() {}
        },
        Yg = function(a, b) {
            a.g = ug(14, b, function() {})
        };

    function Zg(a) {
        W(Xg).g(a)
    };
    var $g, ah, bh, ch, dh, eh;

    function fh(a) {
        var b = a.Da,
            c = a.u,
            d = a.config,
            e = void 0 === a.Aa ? Gg() : a.Aa,
            f = void 0 === a.na ? 0 : a.na,
            g = void 0 === a.B ? new Yf(null != (ch = null == ($g = R(b, Kg, 5)) ? void 0 : Fc($g, 2)) ? ch : 0, null != (dh = null == (ah = R(b, Kg, 5)) ? void 0 : Fc(ah, 4)) ? dh : 0, null != (eh = null == (bh = R(b, Kg, 5)) ? void 0 : Cc(bh, 3)) ? eh : !1) : a.B;
        a = void 0 === a.I ? Mg(S(b, Jg, 2)) : a.I;
        e.hasOwnProperty("init-done") ? (ug(12, e, function() {})(S(b, Jg, 2).map(function(h) {
            return h.toJSON()
        })), ug(13, e, function() {})(S(b, Vf, 1).map(function(h) {
            return h.toJSON()
        }), f), c && ug(14, e, function() {})(c), gh(f, e)) : (Vg(new Rg(a, f, g, d), e), vg(e), wg(e), xg(e), gh(f, e), qg(S(b, Vf, 1), [f], g, void 0, !0), dg = dg || !(!d || !d.hb), Zg(Fg), c && Zg(c))
    }

    function gh(a, b) {
        var c = b = void 0 === b ? Gg() : b;
        zg(W(yg), c, a);
        hh(b, a);
        a = b;
        Yg(W(Xg), a);
        W(Wg).l()
    }

    function hh(a, b) {
        var c = W(Wg);
        c.h = function(d, e) {
            return ug(5, a, function() {
                return !1
            })(d, e, b)
        };
        c.g = function(d, e) {
            return ug(6, a, function() {
                return 0
            })(d, e, b)
        };
        c.o = function(d, e) {
            return ug(7, a, function() {
                return ""
            })(d, e, b)
        };
        c.j = function(d, e) {
            return ug(8, a, function() {
                return []
            })(d, e, b)
        };
        c.l = function() {
            ug(15, a, function() {})(b)
        }
    };
    var ih = ia(["(a=0)=>{let b;const c=null ?? 1;}"]);
    var jh = ia(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]),
        kh = function() {
            var a = void 0 === a ? "jserror" : a;
            var b = void 0 === b ? .01 : b;
            var c = void 0 === c ? Pd(jh) : c;
            this.j = a;
            this.h = b;
            this.g = c
        };

    function lh(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = Nd("IMG", a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = Array.prototype.indexOf.call(g, e, void 0);
                    0 <= h && Array.prototype.splice.call(g, h, 1)
                }
                e.removeEventListener && e.removeEventListener("load", f, !1);
                e.removeEventListener && e.removeEventListener("error", f, !1)
            };
            Wc(e, "load", f);
            Wc(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }
    var nh = function(a) {
            var b = void 0 === b ? !1 : b;
            var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=gpt_inv_ver";
            Id(a, function(d, e) {
                if (d || 0 === d) c += "&" + e + "=" + encodeURIComponent("" + d)
            });
            mh(c, b)
        },
        mh = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : lh(c, a, void 0 === b ? !1 : b, void 0 === d ? !1 : d)
        };

    function oh(a) {
        a = void 0 === a ? C : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    var ph = function(a, b) {
            b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
            2048 > b.length && b.push(a)
        },
        qh = function(a, b) {
            var c = oh(b);
            c && ph({
                label: a,
                type: 9,
                value: c
            }, b)
        },
        rh = function(a, b, c) {
            var d = !1;
            d = void 0 === d ? !1 : d;
            var e = window,
                f = "undefined" !== typeof queueMicrotask;
            return function() {
                d && f && queueMicrotask(function() {
                    e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                    e.google_rum_task_id_counter += 1
                });
                var g = oh(),
                    h = 3;
                try {
                    var k = b.apply(this, arguments)
                } catch (l) {
                    h = 13;
                    if (!c) throw l;
                    c(a, l)
                } finally {
                    e.google_measure_js_timing && g && ph(u(Object, "assign").call(Object, {}, {
                        label: a.toString(),
                        value: g,
                        duration: (oh() || 0) - g,
                        type: h
                    }, d && f && {
                        taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                    }), e)
                }
                return k
            }
        },
        sh = function(a, b) {
            return rh(a, b, function(c, d) {
                var e = new kh;
                var f = void 0 === f ? e.h : f;
                var g = void 0 === g ? e.j : g;
                Math.random() > f || (d.error && d.meta && d.id || (d = new Jf(d, {
                    context: c,
                    id: g
                })), C.google_js_errors = C.google_js_errors || [], C.google_js_errors.push(d), C.error_rep_loaded || (f = C.document, c = Nd("SCRIPT", f), Bd(c, e.g), (e = f.getElementsByTagName("script")[0]) && e.parentNode && e.parentNode.insertBefore(c, e), C.error_rep_loaded = !0))
            })
        };

    function Z(a, b) {
        return null == b ? "&" + a + "=null" : "&" + a + "=" + Math.floor(b)
    }

    function th(a, b) {
        return "&" + a + "=" + b.toFixed(3)
    }

    function uh() {
        var a = new t.Set;
        var b = window.googletag;
        b = (null == b ? 0 : b.apiReady) ? b : void 0;
        try {
            if (!b) return a;
            for (var c = b.pubads(), d = x(c.getSlots()), e = d.next(); !e.done; e = d.next()) a.add(e.value.getSlotId().getDomId())
        } catch (f) {}
        return a
    }

    function vh(a) {
        a = a.id;
        return null != a && (uh().has(a) || u(a, "startsWith").call(a, "google_ads_iframe_") || u(a, "startsWith").call(a, "aswift"))
    }

    function wh(a, b, c) {
        if (!a.sources) return !1;
        switch (xh(a)) {
            case 2:
                var d = yh(a);
                if (d) return c.some(function(f) {
                    return zh(d, f)
                });
                break;
            case 1:
                var e = Ah(a);
                if (e) return b.some(function(f) {
                    return zh(e, f)
                })
        }
        return !1
    }

    function xh(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(function(b) {
            return b.previousRect && b.currentRect
        });
        if (1 <= a.length) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function Ah(a) {
        return Bh(a, function(b) {
            return b.currentRect
        })
    }

    function yh(a) {
        return Bh(a, function(b) {
            return b.previousRect
        })
    }

    function Bh(a, b) {
        return a.sources.reduce(function(c, d) {
            d = b(d);
            return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function zh(a, b) {
        var c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
    }
    var Ch = function() {
            var a = {
                pa: !0
            };
            a = void 0 === a ? {
                pa: !1
            } : a;
            this.j = this.h = this.P = this.N = this.H = 0;
            this.ja = this.ga = Number.NEGATIVE_INFINITY;
            this.g = [];
            this.K = {};
            this.da = 0;
            this.J = Infinity;
            this.ba = this.ea = this.fa = this.ha = this.ma = this.o = this.la = this.S = this.l = 0;
            this.ca = !1;
            this.R = this.L = this.F = 0;
            this.B = null;
            this.ia = !1;
            this.aa = function() {};
            var b = document.querySelector("[data-google-query-id]");
            this.ka = b ? b.getAttribute("data-google-query-id") : null;
            this.za = a
        },
        Dh, Eh, Hh = function() {
            var a = new Ch;
            if (Cf(bf)) {
                var b = window;
                if (!b.google_plmetrics && window.PerformanceObserver) {
                    b.google_plmetrics = !0;
                    b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                    a.za.pa && b.push("event");
                    b = x(b);
                    for (var c = b.next(); !c.done; c = b.next()) {
                        c = c.value;
                        var d = {
                            type: c,
                            buffered: !0
                        };
                        "event" === c && (d.durationThreshold = 40);
                        Fh(a).observe(d)
                    }
                    Gh(a)
                }
            }
        },
        Fh = function(a) {
            a.B || (a.B = new PerformanceObserver(sh(640, function(b) {
                Ih(a, b)
            })));
            return a.B
        },
        Gh = function(a) {
            var b = sh(641, function() {
                    var d = document;
                    2 === (d.prerendering ? 3 : {
                        visible: 1,
                        hidden: 2,
                        prerender: 3,
                        preview: 4,
                        unloaded: 5
                    }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] || 0) && Jh(a)
                }),
                c = sh(641, function() {
                    return void Jh(a)
                });
            document.addEventListener("visibilitychange", b);
            document.addEventListener("pagehide", c);
            a.aa = function() {
                document.removeEventListener("visibilitychange", b);
                document.removeEventListener("pagehide", c);
                Fh(a).disconnect()
            }
        },
        Jh = function(a) {
            if (!a.ia) {
                a.ia = !0;
                Fh(a).takeRecords();
                var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
                window.LayoutShift && (b += th("cls", a.H), b += th("mls", a.N), b += Z("nls", a.P), window.LayoutShiftAttribution && (b += th("cas", a.o), b += Z("nas", a.ha), b += th("was", a.ma)), b += th("wls", a.S), b += th("tls", a.la));
                window.LargestContentfulPaint && (b += Z("lcp", a.fa), b += Z("lcps", a.ea));
                window.PerformanceEventTiming && a.ca && (b += Z("fid", a.ba));
                window.PerformanceLongTaskTiming && (b += Z("cbt", a.F), b += Z("mbt", a.L), b += Z("nlt", a.R));
                for (var c = 0, d = x(document.getElementsByTagName("iframe")), e = d.next(); !e.done; e = d.next()) vh(e.value) && c++;
                b += Z("nif", c);
                c = window.google_unique_id;
                b += Z("ifi", "number" === typeof c ? c : 0);
                c = W(yg).g();
                b += "&eid=" + encodeURIComponent(c.join());
                b += "&top=" + (C === C.top ? 1 : 0);
                b += a.ka ? "&qqid=" + encodeURIComponent(a.ka) : Z("pvsid", Od(C));
                window.googletag && (b += "&gpt=1");
                c = Math.min(a.g.length - 1, Math.floor((a.B ? a.da : performance.interactionCount || 0) / 50));
                0 <= c && (c = a.g[c].latency, 0 <= c && (b += Z("inp", c)));
                window.fetch(b, {
                    keepalive: !0,
                    credentials: "include",
                    redirect: "follow",
                    method: "get",
                    mode: "no-cors"
                });
                a.aa()
            }
        },
        Kh = function(a, b, c, d) {
            if (!b.hadRecentInput) {
                a.H += Number(b.value);
                Number(b.value) > a.N && (a.N = Number(b.value));
                a.P += 1;
                if (c = wh(b, c, d)) a.o += b.value, a.ha++;
                if (5E3 < b.startTime - a.ga || 1E3 < b.startTime - a.ja) a.ga = b.startTime, a.h = 0, a.j = 0;
                a.ja = b.startTime;
                a.h += b.value;
                c && (a.j += b.value);
                a.h > a.S && (a.S = a.h, a.ma = a.j, a.la = b.startTime + b.duration)
            }
        },
        Ih = function(a, b) {
            var c = Dh !== window.scrollX || Eh !== window.scrollY ? [] : Lh,
                d = Mh();
            b = x(b.getEntries());
            for (var e = b.next(), f = {}; !e.done; f = {
                    v: f.v
                }, e = b.next()) switch (f.v = e.value, e = f.v.entryType, e) {
                case "layout-shift":
                    Kh(a, f.v, c, d);
                    break;
                case "largest-contentful-paint":
                    e = f.v;
                    a.fa = Math.floor(e.renderTime || e.loadTime);
                    a.ea = e.size;
                    break;
                case "first-input":
                    e = f.v;
                    a.ba = Number((e.processingStart - e.startTime).toFixed(3));
                    a.ca = !0;
                    a.g.some(function(g) {
                        return function(h) {
                            return u(h, "entries").some(function(k) {
                                return g.v.duration === k.duration && g.v.startTime === k.startTime
                            })
                        }
                    }(f)) || Nh(a, f.v);
                    break;
                case "longtask":
                    e = Math.max(0, f.v.duration - 50);
                    a.F += e;
                    a.L = Math.max(a.L, e);
                    a.R += 1;
                    break;
                case "event":
                    Nh(a, f.v);
                    break;
                default:
                    throw Error("unexpected value " + e + "!");
            }
        },
        Nh = function(a, b) {
            Oh(a, b);
            var c = a.g[a.g.length - 1],
                d = a.K[b.interactionId];
            if (d || 10 > a.g.length || b.duration > c.latency) d ? (u(d, "entries").push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
                id: b.interactionId,
                latency: b.duration,
                entries: [b]
            }, a.K[b.id] = b, a.g.push(b)), a.g.sort(function(e, f) {
                return f.latency - e.latency
            }), a.g.splice(10).forEach(function(e) {
                delete a.K[e.id]
            })
        },
        Oh = function(a, b) {
            b.interactionId && (a.J = Math.min(a.J, b.interactionId), a.l = Math.max(a.l, b.interactionId), a.da = a.l ? (a.l - a.J) / 7 + 1 : 0)
        },
        Mh = function() {
            var a = u(Array, "from").call(Array, document.getElementsByTagName("iframe")).filter(vh),
                b = [].concat(y(uh())).map(function(c) {
                    return document.getElementById(c)
                }).filter(function(c) {
                    return null !== c
                });
            Dh = window.scrollX;
            Eh = window.scrollY;
            return Lh = [].concat(y(a), y(b)).map(function(c) {
                return c.getBoundingClientRect()
            })
        },
        Lh = [];
    var Ph = function(a) {
        this.i = N(a)
    };
    B(Ph, V);
    Ph.prototype.getVersion = function() {
        return T(this, 2)
    };
    var Qh = function(a) {
        this.i = N(a)
    };
    B(Qh, V);
    var Rh = function(a, b) {
            return P(a, 2, M(b))
        },
        Sh = function(a, b) {
            return P(a, 3, M(b))
        },
        Th = function(a, b) {
            return P(a, 4, M(b))
        },
        Uh = function(a, b) {
            return P(a, 5, M(b))
        },
        Vh = function(a, b) {
            return P(a, 9, M(b))
        },
        Wh = function(a, b) {
            return zc(a, 10, b)
        },
        Xh = function(a, b) {
            return P(a, 11, Lb(b))
        },
        Yh = function(a, b) {
            return P(a, 1, M(b))
        },
        Zh = function(a, b) {
            return P(a, 7, Lb(b))
        };
    Qh.m = [10, 6];
    var $h = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function ai(a) {
        var b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    }

    function bi(a) {
        var b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    }

    function ci(a) {
        if (!bi(a)) return null;
        var b = ai(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues($h).then(function(c) {
            null != b.uach || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function di(a) {
        var b;
        return Xh(Wh(Uh(Rh(Yh(Th(Zh(Vh(Sh(new Qh, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), (null == (b = a.fullVersionList) ? void 0 : b.map(function(c) {
            var d = new Ph;
            d = P(d, 1, M(c.brand));
            return P(d, 2, M(c.version))
        })) || []), a.wow64 || !1)
    }

    function ei(a) {
        var b, c;
        return null != (c = null == (b = ci(a)) ? void 0 : b.then(function(d) {
            return di(d)
        })) ? c : null
    };

    function fi(a, b) {
        var c = {};
        b = (c[0] = Pg(b.Ka), c);
        W(yg).h(a, b)
    };
    var gi = {},
        hi = (gi[253] = !1, gi[246] = [], gi[150] = "", gi[221] = !1, gi[36] = /^true$/.test("false"), gi[172] = null, gi[260] = void 0, gi[251] = null, gi),
        Kc = function() {
            this.g = !1
        };

    function ii(a) {
        W(Kc).g = !0;
        return hi[a]
    }

    function ji(a, b) {
        W(Kc).g = !0;
        hi[a] = b
    };
    var ki = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;

    function li(a) {
        return a ? !ki.test(a.src) : !0
    };

    function mi(a) {
        var b = a.Ha,
            c = a.Pa,
            d = a.Ga,
            e = a.Ca,
            f = a.Ea,
            g = li(a.sa);
        a = {};
        var h = {},
            k = {};
        return k[3] = (a[3] = function() {
            return !g
        }, a[59] = function() {
            var l = ra.apply(0, arguments),
                m = u(l, "includes"),
                n = String,
                r;
            var q = void 0 === q ? window : q;
            var A;
            q = null != (A = null == (r = yd(q.location.href.match(xd)[3] || null)) ? void 0 : r.split(".")) ? A : [];
            r = 2 > q.length ? null : "uk" === q[q.length - 1] ? 3 > q.length ? null : Jd(q.splice(q.length - 3).join(".")) : Jd(q.splice(q.length - 2).join("."));
            return m.call(l, n(r))
        }, a[61] = function() {
            return d
        }, a[63] = function() {
            return d || ".google.ch" === f
        }, a[73] = function(l) {
            return u(c, "includes").call(c, Number(l))
        }, a), k[4] = (h[1] = function() {
            return e
        }, h[4] = function() {
            if (Kd.test("0")) {
                var l = Number("0");
                l = isNaN(l) ? null : l
            } else l = null;
            return l || 0
        }, h[13] = function() {
            return b || 0
        }, h), k[5] = {}, k
    };

    function ni(a, b) {
        var c = new Lg(ii(246));
        if (!S(c, Vf, 1).length && S(a, Vf, 1).length) {
            var d = S(a, Vf, 1);
            zc(c, 1, d)
        }!S(c, Jg, 2).length && S(a, Jg, 2).length && (d = S(a, Jg, 2), zc(c, 2, d));
        void 0 === vc(c, Kg, 5, !1) && void 0 !== vc(a, Kg, 5, !1) && (a = R(a, Kg, 5), xc(c, 5, a));
        fh({
            Da: c,
            u: mi(b),
            na: 2
        })
    };

    function oi(a, b, c, d, e) {
        a = a.location.host;
        var f = Ad(b.src, "domain");
        b = Ad(b.src, "network-code");
        if (a || f || b) {
            var g = {};
            a && (g.ippd = a);
            f && (g.pppd = f);
            b && (g.pppnc = b);
            W(Wg).g(Ze.g, Ze.defaultValue) && (g.ppc_eid = W(Wg).g(Ze.g, Ze.defaultValue).toString());
            a = g
        } else a = void 0;
        if (a) {
            c = [c ? new Tc(Rc, "https://pagead2.googlesyndication.com") : new Tc(Rc, "https://securepubads.g.doubleclick.net"), new Tc(Rc, "/pagead/ppub_config")];
            f = "";
            for (b = 0; b < c.length; b++) f += Uc(c[b]);
            c = cd.exec(bd(new ad(f, dd)).toString());
            f = c[3] || "";
            c = new ad(c[1] + ed("?", c[2] || "", a) + ed("#", f), dd);
            pi(c, d, e)
        } else e(new t.globalThis.Error("no provided or inferred data"))
    }

    function pi(a, b, c) {
        var d = new t.globalThis.XMLHttpRequest;
        d.open("GET", a.toString(), !0);
        d.withCredentials = !1;
        d.onload = function() {
            300 > d.status ? (qh("13", window), b(204 === d.status ? "" : d.responseText)) : c(new t.globalThis.Error("resp:" + d.status))
        };
        d.onerror = function() {
            return void c(new t.globalThis.Error("s:" + d.status + " rs:" + d.readyState))
        };
        d.send()
    };
    var qi = function() {
            this.l = [];
            this.j = []
        },
        ti = function(a, b, c, d, e) {
            if (Fd(b) === Gd(b) && c) {
                ri(a);
                var f = null == e ? void 0 : T(wc(e, Oc), 1);
                f && f.length && u(b.location.hostname, "includes").call(b.location.hostname, f) ? si(a, void 0, e) : oi(b.top, c, d, function(g) {
                    return void si(a, g)
                }, function(g) {
                    si(a, void 0, void 0, g)
                })
            }
        },
        ri = function(a) {
            ii(260);
            ji(260, function(b) {
                void 0 !== a.g || a.h ? b(a.g, a.h) : a.l.push(b)
            })
        },
        si = function(a, b, c, d) {
            a.g = null != b ? b : null == c ? void 0 : Ic(c);
            a.o = c;
            !a.o && a.g && a.j.length && (a.o = Qc(a.g));
            a.h = d;
            b = x(a.l);
            for (c = b.next(); !c.done; c = b.next()) c = c.value, c(a.g, a.h);
            b = x(a.j);
            for (c = b.next(); !c.done; c = b.next()) c = c.value, c(a.o, a.h);
            a.l.length = 0;
            a.j.length = 0
        };
    var ui = function(a) {
        this.i = N(a)
    };
    B(ui, V);
    var vi = Nc(ui);
    ui.m = [10];
    var xi = function() {
            return [].concat(y(u(wi, "values").call(wi))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        wi = new t.Map;

    function yi(a, b, c) {
        if (a.Na) {
            c = c.error && c.meta && c.id ? c.error : c;
            var d = new Le,
                e = new Ke;
            try {
                var f = Od(window);
                Q(e, 1, Tb(f), "0")
            } catch (r) {}
            try {
                var g = W(yg).g();
                qc(e, 2, g, Pb)
            } catch (r) {}
            try {
                Q(e, 3, M(window.document.URL), "")
            } catch (r) {}
            f = xc(d, 2, e);
            g = new Je;
            b = Q(g, 1, Ob(b), 0);
            try {
                var h = If(null == c ? void 0 : c.name) ? c.name : "Unknown error";
                Q(b, 2, M(h), "")
            } catch (r) {}
            try {
                var k = If(null == c ? void 0 : c.message) ? c.message : "Caught " + c;
                Q(b, 3, M(k), "")
            } catch (r) {}
            try {
                var l = If(null == c ? void 0 : c.stack) ? c.stack : Error().stack;
                l && qc(b, 4, l.split(/\n\s*/), Xb)
            } catch (r) {}
            h = xc(f, 1, b);
            k = new Ie;
            try {
                Q(k, 1, M(a.X || a.ta), "")
            } catch (r) {}
            try {
                var m = xi();
                Q(k, 2, Qb(m), 0)
            } catch (r) {}
            try {
                var n = [].concat(y(u(wi, "keys").call(wi)));
                qc(k, 3, n, Xb)
            } catch (r) {}
            yc(h, 4, Me, k);
            Q(h, 5, Tb(a.Ba), "0");
            a.La.Oa(h)
        }
    };

    function zi(a, b) {
        try {
            var c = Lc();
            if (!If(a)) {
                var d = c ? c() + "\n" : "";
                throw Error(d + String(a));
            }
            return vi(a)
        } catch (e) {
            return yi(b, 838, e), new ui
        }
    };

    function Ai() {
        var a;
        return null != (a = C.googletag) ? a : C.googletag = {
            cmd: []
        }
    }

    function Bi(a, b) {
        var c = Ai();
        c.hasOwnProperty(a) || (c[a] = b)
    };
    var Ci = ia(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl", ".js"]),
        Di = ia(["https://pagead2.googlesyndication.com/gpt/pubads_impl_", ".js"]),
        Ei = ia(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl", ".js"]),
        Fi = ia(["https://securepubads.g.doubleclick.net/gpt/pubads_impl_", ".js"]);

    function Gi() {
        var a = "undefined" === typeof sttc ? void 0 : sttc,
            b = Hi();
        Gb(function(v) {
            yi(b, 1189, v)
        });
        var c = Ai(),
            d = zi(a, b);
        Jc();
        u(Object, "assign").call(Object, hi, c._vars_);
        c._vars_ = hi;
        d && (Cc(d, 3) && ji(36, !0), Cc(d, 5) && ji(221, !0), T(d, 6) && ji(150, T(d, 6)));
        var e = wc(d, Lg),
            f = {
                Ga: Cc(d, 5),
                Ha: Dc(d, 2),
                Pa: oc(d, 10, Rb),
                Ca: Dc(d, 7),
                Ea: T(d, 6)
            };
        a = R(d, Pc, 9);
        d = Dc(d, 8);
        var g, h = null != (g = c.fifWin) ? g : window,
            k = h.document;
        g = c.fifWin ? window : h;
        Bi("_loaded_", !0);
        d = Ii(b, d);
        Bi("cmd", []);
        var l, m = null != (l = Ji(k)) ? l : Ki(k);
        Li(e, h, u(Object, "assign").call(Object, {}, {
            sa: m
        }, f), d);
        try {
            Hh()
        } catch (v) {}
        qh("1", h);
        l = Mi(d, m);
        e = !1;
        if (!Ni(k)) {
            f = "gpt-impl-" + Math.random();
            try {
                Cd(k, rd(l, {
                    id: f,
                    nonce: vd()
                }))
            } catch (v) {}
            k.getElementById(f) && (Cf(Ve) ? e = !0 : c._loadStarted_ = !0)
        }
        if (Cf(Ve) ? !e : !c._loadStarted_) {
            var n = Nd("SCRIPT");
            Bd(n, l);
            n.async = !0;
            k = c.fifWin ? g.document : k;
            l = k.body;
            e = k.documentElement;
            var r, q, A = null != (q = null != (r = k.head) ? r : l) ? q : e;
            "complete" !== g.document.readyState && c.fifWin ? Wc(g, "load", function() {
                return void A.appendChild(n)
            }) : A.appendChild(n);
            Cf(Ve) || (c._loadStarted_ = !0)
        }
        if (g === g.top) try {
            Ff(g)
        } catch (v) {
            yi(d, 1209, v)
        }
        ti(new qi, g, m, Oi(m), a)
    }

    function Hi() {
        return {
            ta: "1",
            X: "m202311150101",
            Ka: Od(window),
            La: new Se(11, "m202311150101"),
            Na: .01 > Hd(),
            Ba: 100,
            ob: .1 > Hd(),
            lb: 10
        }
    }

    function Ii(a, b) {
        var c = new Tc(Rc, "1");
        var d = a.X;
        /m\d+/.test(d) ? d = Number(d.substring(1)) : (d && nh({
            mjsv: d
        }), d = void 0);
        return u(Object, "assign").call(Object, {}, a, {
            gb: c,
            ib: d,
            jb: new Tc(Rc, "m202311150101"),
            Fa: b
        })
    }

    function Ji(a) {
        return (a = a.currentScript) ? a : null
    }

    function Ki(a) {
        var b;
        a = x(null != (b = a.scripts) ? b : []);
        for (b = a.next(); !b.done; b = a.next())
            if (b = b.value, u(b.src, "includes").call(b.src, "/tag/js/gpt")) return b;
        return null
    }

    function Mi(a, b) {
        var c = a.ta,
            d = a.X;
        a = a.Fa;
        var e = "";
        if (Cf(Ye))
            if (e = "", Cf(Xe)) e = "_fy2012";
            else {
                var f;
                if (f = a && 2012 < a && !vd()) {
                    var g = ih[0];
                    g = new $c(g, Zc);
                    try {
                        var h = window,
                            k = g instanceof $c && g.constructor === $c ? g.h : "type_error:SafeScript";
                        h.eval(k) === k && h.eval(k.toString());
                        f = !0
                    } catch (l) {
                        f = !1
                    }
                }
                f && (e = "_fy" + a)
            }
        b = Oi(b) ? d ? Pd(Ci, d, e) : Pd(Di, c) : d ? Pd(Ei, d, e) : Pd(Fi, c);
        return (c = W(Wg).g($e.g, $e.defaultValue)) ? Qd(b, new t.Map([
            ["cb", c]
        ])) : b
    }

    function Li(a, b, c, d) {
        ji(172, c.sa);
        ni(a, c);
        fi(12, d);
        fi(5, d);
        (a = ei(b)) && a.then(function(e) {
            return void ji(251, Ic(e))
        });
        Md(W(Wg).j(af.g, af.defaultValue), b.document)
    }

    function Ni(a) {
        var b = Ji(a);
        return "complete" === a.readyState || "loaded" === a.readyState || !(null == b || !b.async)
    }

    function Oi(a) {
        return !(null == a || !a.src) && "pagead2.googlesyndication.com" === yd(a.src.match(xd)[3] || null)
    };
    try {
        Gi()
    } catch (a) {
        try {
            yi(Hi(), 420, a)
        } catch (b) {}
    };
}).call(this.googletag && googletag.fifWin ? googletag.fifWin.parent : this, "[[[[577837147,null,null,[1]],[577939489,null,null,[1]],[null,7,null,[null,0.1]],[476475256,null,null,[1]],[null,427198696,null,[null,1]],[571050247,null,null,[1]],[570864697,null,null,[1]],[null,null,null,[],null,489560439],[null,null,null,[],null,505762507],[null,1921,null,[null,72]],[null,1920,null,[null,12]],[null,426169222,null,[null,1000]],[null,1916,null,[null,0.001]],[null,377289019,null,[null,10000]],[580185501,null,null,[1]],[576957572,null,null,[1]],[null,529,null,[null,20]],[null,573282293,null,[null,0.01]],[549005203,null,null,[1]],[576976418,null,null,[1]],[null,447000223,null,[null,0.01]],[360245597,null,null,[1]],[45401685,null,null,[1]],[551365509,null,null,[1]],[561164161,null,null,[1]],[null,550718589,null,[null,250],[[[3,[[4,null,15,null,null,null,null,[\"22814497764\"]],[4,null,15,null,null,null,null,[\"6581\"]],[4,null,15,null,null,null,null,[\"18190176\"]],[4,null,15,null,null,null,null,[\"21881754602\"]],[4,null,15,null,null,null,null,[\"6782\"]],[4,null,15,null,null,null,null,[\"309565630\"]],[4,null,15,null,null,null,null,[\"22306534072\"]],[4,null,15,null,null,null,null,[\"7229\"]],[4,null,15,null,null,null,null,[\"28253241\"]],[4,null,15,null,null,null,null,[\"1254144\"]],[4,null,15,null,null,null,null,[\"21732118914\"]],[4,null,15,null,null,null,null,[\"5441\"]],[4,null,15,null,null,null,null,[\"162717810\"]],[4,null,15,null,null,null,null,[\"51912183\"]],[4,null,15,null,null,null,null,[\"23202586\"]],[4,null,15,null,null,null,null,[\"44520695\"]],[4,null,15,null,null,null,null,[\"1030006\"]],[4,null,15,null,null,null,null,[\"21830601346\"]],[4,null,15,null,null,null,null,[\"23081961\"]],[4,null,15,null,null,null,null,[\"21880406607\"]],[4,null,15,null,null,null,null,[\"93656639\"]],[4,null,15,null,null,null,null,[\"1020351\"]],[4,null,15,null,null,null,null,[\"5931321\"]],[4,null,15,null,null,null,null,[\"3355436\"]],[4,null,15,null,null,null,null,[\"22106840220\"]],[4,null,15,null,null,null,null,[\"22875833199\"]],[4,null,15,null,null,null,null,[\"32866417\"]],[4,null,15,null,null,null,null,[\"8095840\"]],[4,null,15,null,null,null,null,[\"71161633\"]],[4,null,15,null,null,null,null,[\"22668755367\"]],[4,null,15,null,null,null,null,[\"6177\"]],[4,null,15,null,null,null,null,[\"147246189\"]],[4,null,15,null,null,null,null,[\"22152718\"]],[4,null,15,null,null,null,null,[\"21751243814\"]],[4,null,15,null,null,null,null,[\"22013536576\"]],[4,null,15,null,null,null,null,[\"4444\"]],[4,null,15,null,null,null,null,[\"44890869\"]],[4,null,15,null,null,null,null,[\"248415179\"]],[4,null,15,null,null,null,null,[\"5293\"]],[4,null,15,null,null,null,null,[\"21675937462\"]],[4,null,15,null,null,null,null,[\"21726375739\"]],[4,null,15,null,null,null,null,[\"1002212\"]],[4,null,15,null,null,null,null,[\"6718395\"]]]],[null,500]]]],[531615531,null,null,null,[[[3,[[4,null,15,null,null,null,null,[\"22814497764\"]],[4,null,15,null,null,null,null,[\"6581\"]],[4,null,15,null,null,null,null,[\"18190176\"]],[4,null,15,null,null,null,null,[\"21881754602\"]],[4,null,15,null,null,null,null,[\"6782\"]],[4,null,15,null,null,null,null,[\"309565630\"]],[4,null,15,null,null,null,null,[\"22306534072\"]],[4,null,15,null,null,null,null,[\"7229\"]],[4,null,15,null,null,null,null,[\"28253241\"]],[4,null,15,null,null,null,null,[\"1254144\"]],[4,null,15,null,null,null,null,[\"21732118914\"]],[4,null,15,null,null,null,null,[\"5441\"]],[4,null,15,null,null,null,null,[\"162717810\"]],[4,null,15,null,null,null,null,[\"51912183\"]],[4,null,15,null,null,null,null,[\"23202586\"]],[4,null,15,null,null,null,null,[\"44520695\"]],[4,null,15,null,null,null,null,[\"1030006\"]],[4,null,15,null,null,null,null,[\"21830601346\"]],[4,null,15,null,null,null,null,[\"23081961\"]],[4,null,15,null,null,null,null,[\"21880406607\"]],[4,null,15,null,null,null,null,[\"93656639\"]],[4,null,15,null,null,null,null,[\"1020351\"]],[4,null,15,null,null,null,null,[\"5931321\"]],[4,null,15,null,null,null,null,[\"3355436\"]],[4,null,15,null,null,null,null,[\"22106840220\"]],[4,null,15,null,null,null,null,[\"22875833199\"]],[4,null,15,null,null,null,null,[\"32866417\"]],[4,null,15,null,null,null,null,[\"8095840\"]],[4,null,15,null,null,null,null,[\"71161633\"]],[4,null,15,null,null,null,null,[\"22668755367\"]],[4,null,15,null,null,null,null,[\"6177\"]],[4,null,15,null,null,null,null,[\"147246189\"]],[4,null,15,null,null,null,null,[\"22152718\"]],[4,null,15,null,null,null,null,[\"21751243814\"]],[4,null,15,null,null,null,null,[\"22013536576\"]],[4,null,15,null,null,null,null,[\"4444\"]],[4,null,15,null,null,null,null,[\"44890869\"]],[4,null,15,null,null,null,null,[\"248415179\"]],[4,null,15,null,null,null,null,[\"5293\"]],[4,null,15,null,null,null,null,[\"21675937462\"]],[4,null,15,null,null,null,null,[\"21726375739\"]],[4,null,15,null,null,null,null,[\"1002212\"]],[4,null,15,null,null,null,null,[\"6718395\"]]]],[1]]]],[null,532520346,null,[null,120]],[557870754,null,null,[1]],[null,553562174,null,[null,10]],[31077334,null,null,[1]],[null,398776877,null,[null,60000]],[null,374201269,null,[null,60000]],[null,371364213,null,[null,60000]],[null,376149757,null,[null,0.0025]],[574948950,null,null,[1]],[570764855,null,null,[1]],[null,null,579921177,[null,null,\"control_1\\\\\\\\.\\\\\\\\d\"]],[null,570764854,null,[null,50]],[560793105,null,null,[1]],[568657332,null,null,[1]],[377936516,null,null,[1]],[null,null,2,[null,null,\"1-0-40\"]],[null,506394061,null,[null,100]],[526684968,null,null,[1]],[568353453,null,null,[1]],[null,null,null,[],null,489],[392065905,null,null,null,[[[4,null,68],[1]]]],[null,360245595,null,[null,500]],[45397804,null,null,[1]],[580311360,null,null,[1]],[45398607,null,null,[1]],[null,397316938,null,[null,1000]],[563462360,null,null,[1]],[555237688,null,null,[],[[[2,[[4,null,70,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,27,null,null,null,null,[\"isSecureContext\"]]]]]],[1]]]],[555237686,null,null,[]],[507033477,null,null,[1]],[552803605,null,null,[1]],[null,514795754,null,[null,2]],[564724551,null,null,null,[[[12,null,null,null,4,null,\"Chrome\\\\\/((?!10\\\\d)(?!11[0-6])\\\\d{3,})\",[\"navigator.userAgent\"]],[1]]]],[567489814,null,null,[1]],[45415915,null,null,[1]],[564852646,null,null,[1]],[null,null,null,[null,null,null,[\"As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ\/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX\/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A\/ERL66fN363FkXxgDc6F1+ucRUkAhjEca9W3la6xaLnD2Y1lABsqmdaJmPNaUKPKVBRpyMKEhXYl7rSvrQw+AkAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A6OdGH3fVf4eKRDbXb4thXA4InNqDJDRhZ8U533U\/roYjp4Yau0T3YSuc63vmAs\/8ga1cD0E3A7LEq6AXk1uXgsAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934],[485990406,null,null,[]]],[[3,[[null,[[1337,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]],[84,null,null,[1]],[188,null,null,[1]]]]]],[1000,[[31072561]],[2,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[12,null,null,null,4,null,\"FLEDGE_GAM_EXTERNAL_TESTER\",[\"navigator.userAgent\"]]]]],[1,[[31075124,[[null,514795754,null,[null,4]]]]],[4,null,74,null,null,null,null,[\"1585821863\",\"3976716532\"]],59],[10,[[31078017],[31078018]]],[1000,[[31078988,null,[4,null,6,null,null,null,null,[\"31078986\"]]]],[4,null,8,null,null,null,null,[\"__gpp\"]],88,null,null,null,null,null,null,null,null,9],[1000,[[31078989,null,[4,null,6,null,null,null,null,[\"31078987\"]]]],[4,null,8,null,null,null,null,[\"__gpp\"]],88,null,null,null,null,null,null,null,null,9],[null,[[31078990,[[540043576,null,null,[1]]]]]],[10,[[31079632],[31079633],[31079634,[[null,514795754,null,[null,4]]]]],[2,[[4,null,9,null,null,null,null,[\"fetch\"]],[4,null,9,null,null,null,null,[\"navigator.getInterestGroupAdAuctionData\"]],[1,[[12,null,null,null,4,null,\"Chrome\\\\\/115\",[\"navigator.userAgent\"]]]],[1,[[4,null,63]]],[1,[[4,null,74,null,null,null,null,[\"1585821863\",\"3976716532\"]]]]]],59],[1000,[[31079785,null,[4,null,6,null,null,null,null,[\"31079783\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],101,null,null,null,null,null,null,null,null,15],[1000,[[31079786,null,[4,null,6,null,null,null,null,[\"31079784\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],101,null,null,null,null,null,null,null,null,15],[1000,[[31079793,null,[4,null,6,null,null,null,null,[\"31079791\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],101,null,null,null,null,null,null,null,null,15],[1000,[[31079794,null,[4,null,6,null,null,null,null,[\"31079792\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],101,null,null,null,null,null,null,null,null,15],[null,[[44798283,[[null,514795754,null,[null,4]]]]],[2,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[1,[[4,null,63]]]]],59],[1,[[44807746],[44807747,[[547020083,null,null,[1]]]],[44807748,[[547020083,null,null,[1]]]]]],[10,[[44808652],[44808653,[[561694963,null,null,[1]]]]]],[null,[[676982960],[676982998]]]]],[12,[[40,[[21065724],[21065725,[[203,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71],[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]],[1000,[[31078663,null,[2,[[4,null,70,null,null,null,null,[\"browsing-topics\"]],[4,null,8,null,null,null,null,[\"document.browsingTopics\"]]]]]]],[1000,[[31078664,null,[2,[[4,null,69,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,70,null,null,null,null,[\"browsing-topics\"]]]]]]]]],[1000,[[31078665,null,[2,[[4,null,8,null,null,null,null,[\"navigator.runAdAuction\"]],[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]],[1000,[[31078666,null,[2,[[4,null,69,null,null,null,null,[\"join-ad-interest-group\"]],[1,[[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]]]],[1000,[[31078667,null,[2,[[4,null,69,null,null,null,null,[\"run-ad-auction\"]],[1,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]]]]]]]]],[1000,[[31078668,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[1000,[[31078669,null,[2,[[4,null,69,null,null,null,null,[\"attribution-reporting\"]],[1,[[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]]]],[1000,[[31078670,null,[4,null,70,null,null,null,null,[\"shared-storage\"]]]]],[1000,[[31078671,null,[2,[[4,null,69,null,null,null,null,[\"shared-storage\"]],[1,[[4,null,70,null,null,null,null,[\"shared-storage\"]]]]]]]]]]],[5,[[50,[[31067420],[31067421,[[360245597,null,null,[]]]],[31077191],[44776367],[44804780],[44806358]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[100,[[31077976],[31077978,[[null,564509649,null,[null,2]]]]]],[1000,[[31078015,null,[2,[[2,[[8,null,null,1,null,-1],[7,null,null,1,null,10]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[1000,[[31078016,null,[2,[[2,[[8,null,null,1,null,9],[7,null,null,1,null,20]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[50,[[31078986],[31078987,[[540043576,null,null,[1]]]]]],[10,[[31079088],[44776366],[44779256]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[50,[[31079233],[31079234,[[570864697,null,null,[]]]]],null,98],[50,[[31079239],[31079240,[[571050247,null,null,[]]]]],null,97],[50,[[31079665],[31079666,[[579191270,null,null,[1]]]]]],[1,[[31079732],[31079733]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[100,[[31079760],[31079761,[[null,578655462,null,[null,20]]]]]],[50,[[31079783],[31079784,[[570764855,null,null,[]]]]],null,100],[1,[[31079791],[31079792,[[578725095,null,null,[1]]]]],null,100],[50,[[31079795],[31079796,[[360245597,null,null,[]]]]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[1000,[[31079807,[[null,24,null,[null,31079807]]],[6,null,null,13,null,31079807]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31079808,[[null,24,null,[null,31079808]]],[6,null,null,13,null,31079808]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[10,[[31079827],[31079828,[[573236024,null,null,[1]]]]]],[10,[[31079829],[31079830,[[579875511,null,null,[1]]]]]],[10,[[31079831],[31079832,[[568657331,null,null,[1]]]]]],[1000,[[31079856,[[null,24,null,[null,31079856]]],[6,null,null,13,null,31079856]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31079857,[[null,24,null,[null,31079857]]],[6,null,null,13,null,31079857]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[20,[[44808666],[44808667,[[45420038,null,null,[1]]]]]]]],[25,[[10,[[31068825],[31068826,[[null,462420536,null,[null,0.1]]]]]]]],[2,[[50,[[31078659,[[561164161,null,null,[]],[531615531,null,null,[]]]],[31078660]],null,null,null,null,null,300,null,102],[10,[[31078978],[31078979]],null,null,null,null,null,400,null,102],[50,[[31079575],[31079576]],null,null,null,null,null,500,null,102]]],[4,[[null,[[44714449,[[null,7,null,[null,1]]]],[676982961,[[null,7,null,[null,0.4]],[212,null,null,[1]]]],[676982996,[[null,7,null,[null,1]]]]],null,78]]]],null,null,[null,1000,1,1000]],null,null,null,null,\".google.co.in\",57,2021,[[\"leboncoin.fr\",null,\"https:\/\/www.leboncoin.fr\/recherche?category=9\\u0026text=immeuble%20de%20rapport\\u0026locations=Savigny-sur-Orge_91600__48.67545_2.35363_3047_100000\",null,null,[\"103997693\",\"22060069514\",\"22206232440\",\"23328537\",\"78858720\"]],[],[],[31079527]]]")