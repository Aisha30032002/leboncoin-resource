(function(_) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    var ca, ea, ha, ja, na, qa, sa, va, ua, wa, xa, Aa, Ba, Ca, Ea, Fa, Ka, La, Ma, Na, Pa, Ya, eb, gb, ib, kb, ob, rb, ub, vb, Cb, Eb, Gb, Ib, Jb, Ob, Qb, Pb, Rb, Sb, Kb, Tb, Xb, Yb, $b, ac, cc, dc, ec, fc, hc, ic, oc, pc, qc, sc, tc, vc, zc, uc, Bc, Dc, Ec, Gc, Jc, Kc, Lc, Mc, Nc, Pc, Uc, Vc, Wc, Sc, Yc, Rc, Qc, Zc, $c, ad, bd, cd, dd, ed, hd, gd, jd, kd, ld, nd, qd, ud, vd, wd, yd, xd, Ed, Gd, Fd, Id, Hd, Jd, Ld, td, Qd, Rd, Vd, Xd, Yd, be, ee, fe, ge, he, ke, le, Wd, me, ne, pe, qe, re, ve, we, xe, te, De, ue, Ee, Ie, Ke, Me, Oe, Pe, Qe, Ze, $e, bf, cf, df, ef, ff, hf, kf, lf, of , pf, qf, tf, vf, xf, zf, Bf, Cf, Ff, Gf, Hf, If, Mf, Nf, Pf, Qf, Tf, Vf, Wf, Xf, Yf, ag, dg, eg, gg, kg, ig, og, pg, qg, mg, ng, rg, sg, tg, wg, xg, Bg, Eg, Lg, Mg, Pg, Tg, Xg, $g, bh, dh, eh, fh, gh, hh, ih, kh, nh, oh, uh, Bh, Eh, Gh, L, Hh, Nh, Lh, ci, ei, gi, hi, mi, pi, yi, Bi, Di, Ci, Ki, Li, Mi, Ni, Ei, Oi, Fi, Qi, Ri, Ti, Ui, Wi, Vi, Yi, cj, aj, dj, mj, pj, hj, ij, qj, tj, rj, wj, xj, yj, Bj, Cj, Hj, Ij, Tj, Zj, Xj, Yj, ek, ik, kk, lk, mk, ok, sk, Bk, vk, pk, Kk, Ik, Jk, Mk, Ok, Rk, P, Tk, Uk, Vk, Xk, Zk, $k, gl, hl, kl, ll, ql, sl, tl, xl, Bl, Cl, Dl, Fl, Jl, Ol, Ql, Rl, Wl, Xl, am, bm, cm, gm, $l, im, jm, km, mm, pm, rm, sm, tm, um, wm, xm, zm, Bm, Cm, Am, Gm, Hm, Lm, Mm, Om, Wm, Ym, $m, cn, bn, an, ln, on, pn, qn, rn, vn, xn, Bn, Fn, Gn, Hn, Kn, Nn, Mn, Qn, Wn, Xn, Zn, io, go, lo, oo, $n, zo, Ao, Do, Co, Fo, Ho, Jo, Lo, No, To, Yo, Zo, bp, ep, cp, dp, gp, hp, ip, lp, mp, np, op, qp, sp, yp, zp, Ap, Bp, Ep, Fp, Gp, Hp, Ip, Kp, Lp, Mp, Qp, $p, Tp, cq, fq, nq, gq, hq, eq, qq, tq, vq, wq, yq, Eq, Hq, Jq, Kq, Pq, Rq, Tq, Wq, ra, Xq, Yq, $q, Zq, ar, br, dr, fr, gr, ir, kr, or, lr, pr, qr, sr, tr, ur, vr, wr, xr, Fr, Gr, Hr, Ir, Or, Rr, Tr, Ur, Vr, Yr, ys, Fs, Gs, Ks, Ls, tt, wt, Et, zt, Bt, Ht, Gt, Jt, Lt, Kt, Nt, Vt, Zt, eu, ju, lu, mu, nu, pu, qu, ru, su, uu, vu, wu, Du, Eu, Fu, nb, Hu, Ku, Iu, Ju, Lu, Mu;
    ca = function(a) {
        return function() {
            return _.aa[a].apply(this, arguments)
        }
    };
    ea = function(a) {
        return a ? a.passive && da() ? a : a.capture || !1 : !1
    };
    ha = function(a, b) {
        b = _.fa(a, b);
        var c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    };
    _.ia = function(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };
    ja = function(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    };
    na = function(a) {
        for (var b = 0, c = 0, d = {}; c < a.length;) {
            var e = a[c++],
                f = _.ka(e) ? "o" + _.ma(e) : (typeof e).charAt(0) + e;
            Object.prototype.hasOwnProperty.call(d, f) || (d[f] = !0, a[b++] = e)
        }
        a.length = b
    };
    qa = function(a, b) {
        a.sort(b || _.oa)
    };
    sa = function(a) {
        for (var b = ra, c = Array(a.length), d = 0; d < a.length; d++) c[d] = {
            index: d,
            value: a[d]
        };
        var e = b || _.oa;
        qa(c, function(f, g) {
            return e(f.value, g.value) || f.index - g.index
        });
        for (b = 0; b < a.length; b++) a[b] = c[b].value
    };
    va = function(a, b) {
        if (!_.ta(a) || !_.ta(b) || a.length != b.length) return !1;
        for (var c = a.length, d = ua, e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    };
    _.oa = function(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    };
    ua = function(a, b) {
        return a === b
    };
    wa = function(a, b) {
        for (var c = {}, d = 0; d < a.length; d++) {
            var e = a[d],
                f = b.call(void 0, e, d, a);
            void 0 !== f && (c[f] || (c[f] = [])).push(e)
        }
        return c
    };
    xa = function(a) {
        for (var b = [], c = 0; c < arguments.length; c++) {
            var d = arguments[c];
            if (Array.isArray(d))
                for (var e = 0; e < d.length; e += 8192)
                    for (var f = xa.apply(null, ja(d, e, e + 8192)), g = 0; g < f.length; g++) b.push(f[g]);
            else b.push(d)
        }
        return b
    };
    Aa = function(a, b) {
        for (var c in a) b.call(void 0, a[c], c, a)
    };
    Ba = function(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    Ca = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return c
    };
    Ea = function(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Da.length; f++) c = Da[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    Fa = function() {
        var a = _.t.navigator;
        return a && (a = a.userAgent) ? a : ""
    };
    Ka = function(a) {
        return Ha ? Ia ? Ia.brands.some(function(b) {
            return (b = b.brand) && _.Ja(b, a)
        }) : !1 : !1
    };
    La = function(a) {
        return _.Ja(Fa(), a)
    };
    Ma = function() {
        return Ha ? !!Ia && 0 < Ia.brands.length : !1
    };
    Na = function() {
        return Ma() ? Ka("Chromium") : (La("Chrome") || La("CriOS")) && !(Ma() ? 0 : La("Edge")) || La("Silk")
    };
    Pa = function(a) {
        return new Oa(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    };
    _.Wa = function(a) {
        var b = void 0 === b ? Sa : b;
        a: if (b = void 0 === b ? Sa : b, !(a instanceof _.Ta)) {
            for (var c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d instanceof Oa && d.Pk(a)) {
                    a = Ua(a);
                    break a
                }
            }
            a = void 0
        }
        return a || _.Va
    };
    Ya = function(a) {
        for (var b = _.Xa.apply(1, arguments), c = [a[0]], d = 0; d < b.length; d++) c.push(String(b[d])), c.push(a[d + 1]);
        return Ua(c.join(""))
    };
    _.$a = function(a) {
        a: if (Za) {
            try {
                var b = new URL(a)
            } catch (c) {
                b = "https:";
                break a
            }
            b = b.protocol
        } else b: {
            b = document.createElement("a");
            try {
                b.href = a
            } catch (c) {
                b = void 0;
                break b
            }
            b = b.protocol;b = ":" === b || "" === b ? "https:" : b
        }
        if ("javascript:" !== b) return a
    };
    _.cb = function(a) {
        return a instanceof _.Ta ? _.ab(a) : _.$a(a)
    };
    _.db = function(a) {
        throw Error("unexpected value " + a + "!");
    };
    eb = function(a) {
        var b, c, d = null == (c = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : c.call(b, "script[nonce]");
        (b = d ? d.nonce || d.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };
    gb = function(a, b) {
        a.textContent = _.fb(b);
        eb(a)
    };
    ib = function(a, b) {
        a.src = _.hb(b);
        eb(a)
    };
    kb = function(a) {
        var b = window,
            c = !0;
        c = void 0 === c ? !1 : c;
        new _.v.Promise(function(d, e) {
            function f() {
                g.onload = null;
                g.onerror = null;
                var h;
                null == (h = g.parentElement) || h.removeChild(g)
            }
            var g = b.document.createElement("script");
            g.onload = function() {
                f();
                d()
            };
            g.onerror = function() {
                f();
                e(void 0)
            };
            g.type = "text/javascript";
            ib(g, a);
            c && "complete" !== b.document.readyState ? _.jb(b, "load", function() {
                b.document.body.appendChild(g)
            }) : b.document.body.appendChild(g)
        })
    };
    ob = function(a) {
        var b, c, d, e, f, g;
        return _.lb(function(h) {
            switch (h.j) {
                case 1:
                    return b = "https://pagead2.googlesyndication.com/getconfig/sodar?sv=200&tid=" + a.j + ("&tv=" + a.o + "&st=") + a.Yc, c = void 0, h.m = 2, h.yield(mb(b), 4);
                case 4:
                    c = h.o;
                    h.j = 3;
                    h.m = 0;
                    break;
                case 2:
                    nb(h);
                case 3:
                    if (!c) return h.return(void 0);
                    d = a.Dd || c.sodar_query_id;
                    e = void 0 !== c.rc_enable && a.m ? c.rc_enable : "n";
                    f = void 0 === c.bg_snapshot_delay_ms ? "0" : c.bg_snapshot_delay_ms;
                    g = void 0 === c.is_gen_204 ? "1" : c.is_gen_204;
                    return d && c.bg_hash_basename && c.bg_binary ? h.return({
                        context: a.A,
                        yj: c.bg_hash_basename,
                        xj: c.bg_binary,
                        Uk: a.j + "_" + a.o,
                        Dd: d,
                        Yc: a.Yc,
                        Ie: e,
                        jf: f,
                        Ge: g
                    }) : h.return(void 0)
            }
        })
    };
    rb = function(a) {
        var b;
        return _.lb(function(c) {
            if (1 == c.j) return c.yield(ob(a), 2);
            if (b = c.o) {
                var d = "sodar2";
                d = void 0 === d ? "sodar2" : d;
                var e = window,
                    f = e.GoogleGcLKhOms;
                f && "function" === typeof f.push || (f = e.GoogleGcLKhOms = []);
                var g = {};
                f.push((g._ctx_ = b.context, g._bgv_ = b.yj, g._bgp_ = b.xj, g._li_ = b.Uk, g._jk_ = b.Dd, g._st_ = b.Yc, g._rc_ = b.Ie, g._dl_ = b.jf, g._g2_ = b.Ge, g));
                if (f = e.GoogleDX5YKUSk) e.GoogleDX5YKUSk = void 0, f[1]();
                d = pb(qb, {
                    basename: d
                });
                kb(d)
            }
            return c.return(b)
        })
    };
    ub = function(a) {
        var b = !1;
        b = void 0 === b ? !1 : b;
        if (sb) {
            if (b && /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(a)) throw Error("Found an unpaired surrogate");
            a = (tb || (tb = new TextEncoder)).encode(a)
        } else {
            for (var c = 0, d = new Uint8Array(3 * a.length), e = 0; e < a.length; e++) {
                var f = a.charCodeAt(e);
                if (128 > f) d[c++] = f;
                else {
                    if (2048 > f) d[c++] = f >> 6 | 192;
                    else {
                        if (55296 <= f && 57343 >= f) {
                            if (56319 >= f && e < a.length) {
                                var g = a.charCodeAt(++e);
                                if (56320 <= g && 57343 >= g) {
                                    f = 1024 * (f - 55296) + g - 56320 + 65536;
                                    d[c++] = f >> 18 | 240;
                                    d[c++] = f >> 12 & 63 | 128;
                                    d[c++] = f >> 6 & 63 | 128;
                                    d[c++] = f & 63 | 128;
                                    continue
                                } else e--
                            }
                            if (b) throw Error("Found an unpaired surrogate");
                            f = 65533
                        }
                        d[c++] = f >> 12 | 224;
                        d[c++] = f >> 6 & 63 | 128
                    }
                    d[c++] = f & 63 | 128
                }
            }
            a = c === d.length ? d : d.subarray(0, c)
        }
        return a
    };
    vb = function(a) {
        _.t.setTimeout(function() {
            throw a;
        }, 0)
    };
    Cb = function(a) {
        if (!yb) return Ab(a);
        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    };
    Eb = function(a) {
        return Db[a] || ""
    };
    Gb = function(a) {
        return Fb && null != a && a instanceof Uint8Array
    };
    Ib = function(a) {
        if (a !== Hb) throw Error("illegal external caller");
    };
    Jb = function() {
        return "function" === typeof BigInt
    };
    Ob = function(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = _.z(Kb(c, a)), b = c.next().value, a = c.next().value, c = b);
        Lb = c >>> 0;
        Mb = a >>> 0
    };
    Qb = function(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (2097151 >= b) var c = "" + (4294967296 * b + a);
        else Jb() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + 6777216 * c + 6710656 * b, c += 8147497 * b, b *= 2, 1E7 <= a && (c += Math.floor(a / 1E7), a %= 1E7), 1E7 <= c && (b += Math.floor(c / 1E7), c %= 1E7), c = b + Pb(c) + Pb(a));
        return c
    };
    Pb = function(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    };
    Rb = function() {
        var a = Lb,
            b = Mb;
        b & 2147483648 ? Jb() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = _.z(Kb(a, b)), a = b.next().value, b = b.next().value, a = "-" + Qb(a, b)) : a = Qb(a, b);
        return a
    };
    Sb = function(a) {
        if (16 > a.length) Ob(Number(a));
        else if (Jb()) a = BigInt(a), Lb = Number(a & BigInt(4294967295)) >>> 0, Mb = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            var b = +("-" === a[0]);
            Mb = Lb = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), Mb *= 1E6, Lb = 1E6 * Lb + d, 4294967296 <= Lb && (Mb += _.A(Math, "trunc").call(Math, Lb / 4294967296), Mb >>>= 0, Lb >>>= 0);
            b && (b = _.z(Kb(Lb, Mb)), a = b.next().value, b = b.next().value, Lb = a, Mb = b)
        }
    };
    Kb = function(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    Tb = function(a) {
        return Array.prototype.slice.call(a)
    };
    Xb = function(a) {
        var b = Vb(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = Tb(a)), Wb(a, b | 1))
    };
    Yb = function(a, b, c) {
        return c ? a | b : a & ~b
    };
    $b = function() {
        var a = [];
        Zb(a, 1);
        return a
    };
    ac = function(a) {
        Zb(a, 34);
        return a
    };
    cc = function(a) {
        Zb(a, 32);
        return a
    };
    dc = function(a, b) {
        Wb(b, (a | 0) & -14591)
    };
    ec = function(a, b) {
        Wb(b, (a | 34) & -14557)
    };
    fc = function(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    hc = function(a) {
        return !(!a || "object" !== typeof a || a.Wk !== gc)
    };
    ic = function(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    };
    oc = function(a, b, c) {
        if (null != a)
            if ("string" === typeof a) a = a ? new mc(a, Hb) : nc();
            else if (a.constructor !== mc)
            if (Gb(a)) {
                var d;
                c ? d = 0 == a.length ? nc() : new mc(a, Hb) : d = a.length ? new mc(new Uint8Array(a), Hb) : nc();
                a = d
            } else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    };
    pc = function(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        var d = Vb(a);
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? _.A(b, "includes").call(b, c) : b.has(c)))) return !1;
        Wb(a, d | 1);
        return !0
    };
    qc = function(a) {
        if (a & 2) throw Error();
    };
    sc = function(a) {
        if (rc) throw Error("");
        rc = a
    };
    tc = function(a) {
        if (rc) try {
            rc(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    };
    vc = function() {
        var a = uc();
        rc ? _.t.setTimeout(function() {
            tc(a)
        }, 0) : vb(a)
    };
    zc = function(a) {
        a = Error(a);
        yc(a, "warning");
        tc(a);
        return a
    };
    uc = function() {
        var a = Error();
        yc(a, "incident");
        return a
    };
    _.Ac = function(a) {
        if (null != a && "number" !== typeof a) throw Error("Value of float/double field must be a number, found " + typeof a + ": " + a);
        return a
    };
    Bc = function(a) {
        if (null == a) return a;
        if ("number" === typeof a || "NaN" === a || "Infinity" === a || "-Infinity" === a) return Number(a)
    };
    Dc = function(a) {
        if ("boolean" !== typeof a) throw Error("Expected boolean but got " + Cc(a) + ": " + a);
        return a
    };
    Ec = function(a) {
        if (null == a || "boolean" === typeof a) return a;
        if ("number" === typeof a) return !!a
    };
    Gc = function(a) {
        var b = typeof a;
        return "number" === b ? _.A(Number, "isFinite").call(Number, a) : "string" !== b ? !1 : Fc.test(a)
    };
    Jc = function(a) {
        _.A(Number, "isFinite").call(Number, a) || vc();
        return a
    };
    Kc = function(a) {
        return a
    };
    Lc = function(a) {
        if ("number" !== typeof a) throw zc("int32");
        _.A(Number, "isFinite").call(Number, a) || vc();
        return a
    };
    Mc = function(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return a
    };
    Nc = function(a) {
        if ("number" !== typeof a) throw zc("uint32");
        _.A(Number, "isFinite").call(Number, a) || vc();
        return a
    };
    _.Oc = function(a) {
        return null == a ? a : Nc(a)
    };
    Pc = function(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return a
    };
    _.Tc = function(a, b) {
        b = !!b;
        if (!Gc(a)) throw zc("int64");
        return "string" === typeof a ? Qc(a, b) : b ? Rc(a, b) : Sc(a, !1)
    };
    Uc = function(a) {
        return null == a ? a : _.Tc(a)
    };
    Vc = function(a) {
        return "-" === a[0] ? !1 : 20 > a.length ? !0 : 20 === a.length && 184467 > Number(a.substring(0, 6))
    };
    Wc = function(a) {
        return "-" === a[0] ? 20 > a.length ? !0 : 20 === a.length && -922337 < Number(a.substring(0, 7)) : 19 > a.length ? !0 : 19 === a.length && 922337 > Number(a.substring(0, 6))
    };
    Sc = function(a, b) {
        a = _.A(Math, "trunc").call(Math, a);
        if (b && !_.A(Number, "isSafeInteger").call(Number, a)) {
            Ob(a);
            b = Lb;
            var c = Mb;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, 0 == b && (c = c + 1 >>> 0);
            b = 4294967296 * c + (b >>> 0);
            a = a ? -b : b
        }
        return a
    };
    Yc = function(a) {
        return a = _.A(Math, "trunc").call(Math, a)
    };
    Rc = function(a, b) {
        a = _.A(Math, "trunc").call(Math, a);
        !b || _.A(Number, "isSafeInteger").call(Number, a) ? a = String(a) : (b = String(a), Wc(b) ? a = b : (Ob(a), a = Rb()));
        return a
    };
    Qc = function(a, b) {
        var c = _.A(Math, "trunc").call(Math, Number(a));
        if (_.A(Number, "isSafeInteger").call(Number, c)) return String(c);
        c = a.indexOf("."); - 1 !== c && (a = a.substring(0, c));
        b && (Wc(a) || (Sb(a), a = Rb()));
        return a
    };
    Zc = function(a, b) {
        var c = _.A(Math, "trunc").call(Math, Number(a));
        if (_.A(Number, "isSafeInteger").call(Number, c) && (!b || 0 <= c)) return String(c);
        b = a.indexOf("."); - 1 !== b && (a = a.substring(0, b));
        Vc(a) || (Sb(a), a = Qb(Lb, Mb));
        return a
    };
    $c = function(a) {
        if (null == a) return a;
        if (Gc(a)) {
            var b;
            "number" === typeof a ? b = Sc(a, !1) : b = Qc(a, !1);
            return b
        }
    };
    ad = function(a, b) {
        b = void 0 === b ? !1 : b;
        if (null == a) return a;
        if (Gc(a)) return "string" === typeof a ? Qc(a, b) : b ? Rc(a, b) : Sc(a, b)
    };
    bd = function(a) {
        var b = !!b;
        if (!Gc(a)) throw zc("uint64");
        "string" === typeof a ? b = Zc(a, b) : b ? (a = _.A(Math, "trunc").call(Math, a), !b || 0 <= a && _.A(Number, "isSafeInteger").call(Number, a) ? b = String(a) : (b = String(a), Vc(b) || (Ob(a), b = Qb(Lb, Mb)))) : b = Yc(a);
        return b
    };
    cd = function(a) {
        if ("string" !== typeof a) throw Error();
        return a
    };
    dd = function(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    };
    ed = function(a) {
        return null == a || "string" === typeof a ? a : void 0
    };
    hd = function(a, b, c, d) {
        if (null != a && "object" === typeof a && a.jg === fd) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? gd(b) : new b : void 0;
        var e = c = Vb(a);
        0 === e && (e |= d & 32);
        e |= d & 2;
        e !== c && Wb(a, e);
        return new b(a)
    };
    gd = function(a) {
        var b = a[id];
        if (b) return b;
        b = new a;
        ac(b.D);
        return a[id] = b
    };
    jd = function(a) {
        return a
    };
    kd = function(a, b, c) {
        if (b) return Dc(a);
        var d;
        return null != (d = Ec(a)) ? d : c ? !1 : void 0
    };
    ld = function(a, b, c) {
        if (b) return cd(a);
        var d;
        return null != (d = ed(a)) ? d : c ? "" : void 0
    };
    nd = function(a, b) {
        md = b;
        a = new a(b);
        md = void 0;
        return a
    };
    qd = function(a) {
        switch (typeof a) {
            case "boolean":
                return od || (od = [0, void 0, !0]);
            case "number":
                return 0 < a ? void 0 : 0 === a ? pd || (pd = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return a
        }
    };
    _.B = function(a, b, c) {
        null == a && (a = md);
        md = void 0;
        if (null == a) {
            var d = 96;
            c ? (a = [c], d |= 512) : a = [];
            b && (d = d & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error();
            d = Vb(a);
            if (d & 64) return a;
            d |= 64;
            if (c && (d |= 512, c !== a[0])) throw Error();
            a: {
                c = d;
                if (d = a.length) {
                    var e = d - 1;
                    if (ic(a[e])) {
                        c |= 256;
                        b = e - (+!!(c & 512) - 1);
                        if (1024 <= b) throw Error();
                        d = c & -16760833 | (b & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    b = Math.max(b, d - (+!!(c & 512) - 1));
                    if (1024 < b) throw Error();
                    d = c & -16760833 | (b & 1023) << 14
                } else d = c
            }
        }
        Wb(a, d);
        return a
    };
    ud = function(a, b, c, d, e, f) {
        a = hd(a, d, c, f);
        e && (a = td(a));
        return a
    };
    vd = function(a) {
        return a
    };
    wd = function(a) {
        return [a, this.get(a)]
    };
    yd = function(a, b) {
        return xd(b)
    };
    xd = function(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return zd || !pc(a, void 0, 9999) ? a : void 0;
                    if (Gb(a)) return Cb(a);
                    if (a instanceof mc) return Ad(a);
                    if (a instanceof Bd) return a = Cd(a), Dd || 0 !== a.length ? a : void 0
                }
        }
        return a
    };
    Ed = function(a, b, c) {
        a = Tb(a);
        var d = a.length,
            e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (var f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    };
    Gd = function(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && Vb(a) & 1 ? void 0 : f && Vb(a) & 2 ? a : Fd(a, b, c, void 0 !== d, e, f);
            else if (ic(a)) {
                var g = {},
                    h;
                for (h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = Gd(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    };
    Fd = function(a, b, c, d, e, f) {
        var g = d || c ? Vb(a) : 0;
        d = d ? !!(g & 32) : void 0;
        a = Tb(a);
        for (var h = 0; h < a.length; h++) a[h] = Gd(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    };
    Id = function(a) {
        return Gd(a, Hd, void 0, void 0, !1, !1)
    };
    Hd = function(a) {
        return a.jg === fd ? a.toJSON() : a instanceof Bd ? Cd(a, Id) : xd(a)
    };
    Jd = function(a, b, c) {
        c = void 0 === c ? ec : c;
        if (null != a) {
            if (Fb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = Vb(a);
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (Wb(a, (d | 34) & -12293), a) : Fd(a, Jd, d & 4 ? ec : c, !0, !1, !0)
            }
            a.jg === fd ? (c = a.D, d = Kd(c), a = d & 2 ? a : nd(a.constructor, Ld(c, d, !0))) : a instanceof Bd && (c = ac(Md(a, Jd)), a = new Bd(c, a.sf, a.Ed, a.Tg));
            return a
        }
    };
    _.Nd = function(a) {
        var b = a.D;
        return nd(a.constructor, Ld(b, Kd(b), !1))
    };
    Ld = function(a, b, c) {
        var d = c || b & 2 ? ec : dc,
            e = !!(b & 32);
        a = Ed(a, b, function(f) {
            return Jd(f, e, d)
        });
        Zb(a, 32 | (c ? 2 : 0));
        return a
    };
    td = function(a) {
        var b = a.D,
            c = Kd(b);
        return c & 2 ? nd(a.constructor, Ld(b, c, !1)) : a
    };
    _.Od = function(a) {
        var b = a.D,
            c = Kd(b);
        return c & 2 ? a : nd(a.constructor, Ld(b, c, !0))
    };
    Qd = function(a, b, c) {
        if (!(4 & b)) return !0;
        if (null == c) return !1;
        0 === c && (4096 & b || 8192 & b) && 5 > (a.constructor[Pd] = (a.constructor[Pd] | 0) + 1) && vc();
        return 0 === c ? !1 : !(c & b)
    };
    Rd = function(a, b, c, d, e) {
        var f = fc(b);
        if (c >= f || e) {
            e = b;
            if (b & 256) f = a[a.length - 1];
            else {
                if (null == d) return e;
                f = a[f + (+!!(b & 512) - 1)] = {};
                e |= 256
            }
            f[c] = d;
            e !== b && Wb(a, e);
            return e
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    };
    Vd = function(a, b, c, d, e) {
        var f = b & 2,
            g = Sd(a, b, c, e);
        Array.isArray(g) || (g = Td);
        var h = !(d & 2);
        d = !(d & 1);
        var k = !!(b & 32),
            l = Vb(g);
        0 !== l || !k || f || h ? l & 1 || (l |= 1, Wb(g, l)) : (l |= 33, Wb(g, l));
        f ? (a = !1, l & 2 || (ac(g), a = !!(4 & l)), (d || a) && Object.freeze(g)) : (f = !!(2 & l) || !!(2048 & l), d && f ? (g = Tb(g), d = 1, k && !h && (d |= 32), Wb(g, d), Rd(a, b, c, g, e)) : h && l & 32 && !f && Ud(g, 32));
        return g
    };
    Xd = function(a, b, c, d, e, f, g) {
        e = void 0 === e ? 2 : e;
        var h = a.D,
            k = Kd(h);
        2 & k && (e = 1);
        f = !!f;
        var l = Vd(h, k, b, 1 | (f ? 2 : 0), d);
        k = Kd(h);
        var m = Vb(l),
            n = m,
            p = !!(2 & m),
            r = !!(4 & m),
            w = p && r;
        if (Qd(a, m, g)) {
            r && (l = Tb(l), n = 0, m = Wd(m, k, f), p = !!(2 & m), k = Rd(h, k, b, l, d));
            for (r = a = 0; a < l.length; a++) {
                var u = c(l[a]);
                null != u && (l[r++] = u)
            }
            r < a && (l.length = r);
            m = Yb(m, 4096, !1);
            m = Yb(m, 8192, !1);
            m = Yb(m, 20, !0);
            g && (m = Yb(m, g, !0))
        }
        w || ((g = 1 === e) && (m = Yb(m, 2, !0)), m !== n && Wb(l, m), (g || p) && Object.freeze(l));
        2 === e && p && (l = Tb(l), m = Wd(m, k, f), Wb(l, m), Rd(h, k, b, l, d));
        var x;
        f ? x = l : x = l;
        return x
    };
    Yd = function(a) {
        return oc(a, !0, !0)
    };
    be = function(a) {
        return oc(a, !0, !1)
    };
    ee = function() {
        var a;
        return null != (a = ce) ? a : ce = new Bd(ac([]), void 0, void 0, void 0, de)
    };
    fe = function(a, b, c, d, e, f) {
        var g = b & 2;
        a: {
            var h = c,
                k = b & 2;c = !1;
            if (null == h) {
                if (k) {
                    a = ee();
                    break a
                }
                h = []
            } else if (h.constructor === Bd) {
                if (0 == (h.ce & 2) || k) {
                    a = h;
                    break a
                }
                h = Md(h)
            } else Array.isArray(h) ? c = !!(Vb(h) & 2) : h = [];
            if (k) {
                if (!h.length) {
                    a = ee();
                    break a
                }
                c || (c = !0, ac(h))
            } else if (c) {
                c = !1;
                k = Tb(h);
                for (h = 0; h < k.length; h++) {
                    var l = k[h] = Tb(k[h]);
                    Array.isArray(l[1]) && (l[1] = ac(l[1]))
                }
                h = k
            }
            c || (Vb(h) & 64 ? Ud(h, 32) : 32 & b && cc(h));f = new Bd(h, e, ld, f);Rd(a, b, d, f, !1);a = f
        }
        if (null == a) return a;
        !g && e && (a.Dj = !0);
        return a
    };
    ge = function(a, b, c) {
        a = a.D;
        var d = Kd(a);
        return fe(a, d, Sd(a, d, b), b, void 0, c)
    };
    he = function(a, b, c) {
        a = a.D;
        var d = Kd(a);
        return fe(a, d, Sd(a, d, b), b, c)
    };
    _.ie = function(a, b, c, d) {
        var e = a.D,
            f = Kd(e);
        qc(f);
        if (null == c) return Rd(e, f, b), a;
        var g = Vb(c),
            h = g,
            k = !!(2 & g) || Object.isFrozen(c),
            l = !k && !1;
        if (Qd(a, g))
            for (g = 21, k && (c = Tb(c), h = 0, g = Wd(g, f, !0)), k = 0; k < c.length; k++) c[k] = d(c[k]);
        l && (g = Yb(g, 2, !0));
        g !== h && Wb(c, g);
        l && Object.freeze(c);
        Rd(e, f, b, c);
        return a
    };
    _.je = function(a, b, c, d) {
        var e = a.D,
            f = Kd(e);
        qc(f);
        Rd(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
        return a
    };
    ke = function(a, b, c) {
        for (var d = 0, e = 0; e < c.length; e++) {
            var f = c[e];
            null != Sd(a, b, f) && (0 !== d && (b = Rd(a, b, d)), d = f)
        }
        return d
    };
    le = function(a, b, c, d, e, f, g) {
        var h = 1 === e;
        e = 2 === e;
        f = !!f;
        var k = !!(2 & b) && e,
            l = Vd(a, b, d, 3);
        b = Kd(a);
        var m = Vb(l),
            n = !!(2 & m),
            p = !!(4 & m),
            r = !!(32 & m),
            w = n && p || !!(2048 & m);
        if (!p) {
            var u = l,
                x = b,
                y;
            (y = !!(2 & m)) && (x = Yb(x, 2, !0));
            for (var C = !y, D = !0, E = 0, J = 0; E < u.length; E++) {
                var M = hd(u[E], c, !1, x);
                if (M instanceof c) {
                    if (!y) {
                        var K = !!(Vb(M.D) & 2);
                        C && (C = !K);
                        D && (D = K)
                    }
                    u[J++] = M
                }
            }
            J < E && (u.length = J);
            m = Yb(m, 4, !0);
            m = Yb(m, 16, D);
            m = Yb(m, 8, C);
            Wb(u, m);
            n && !k && (Object.freeze(l), w = !0)
        }
        c = m;
        k = !!(8 & m) || h && !l.length;
        if (g && !k) {
            w && (l = Tb(l), w = !1, c = 0, m = Wd(m, b, f), b = Rd(a, b, d, l));
            g = l;
            k = m;
            for (n = 0; n < g.length; n++) u = g[n], m = td(u), u !== m && (g[n] = m);
            k = Yb(k, 8, !0);
            m = k = Yb(k, 16, !g.length)
        }
        w || (h ? m = Yb(m, !l.length || 16 & m && (!p || r) ? 2 : 2048, !0) : f || (m = Yb(m, 32, !1)), m !== c && Wb(l, m), h && (Object.freeze(l), w = !0));
        e && w && (l = Tb(l), m = Wd(m, b, f), Wb(l, m), Rd(a, b, d, l));
        return l
    };
    Wd = function(a, b, c) {
        a = Yb(a, 2, !!(2 & b));
        a = Yb(a, 32, !!(32 & b) && c);
        return a = Yb(a, 2048, !1)
    };
    me = function(a, b, c, d) {
        a = a.D;
        var e = Kd(a);
        qc(e);
        b = le(a, e, c, b, 2);
        c = null != d ? d : new c;
        b.push(c);
        Vb(c.D) & 2 ? Ud(b, 8) : Ud(b, 16);
        return c
    };
    ne = function(a, b) {
        return null != a ? a : b
    };
    pe = function(a, b, c) {
        var d = a.constructor.ca,
            e = Kd(c ? a.D : b),
            f = fc(e),
            g = !1;
        if (d && zd) {
            if (!c) {
                b = Tb(b);
                var h;
                if (b.length && ic(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            _.A(Object, "assign").call(Object, b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            h = Kd(a.D);
            a = fc(h);
            h = +!!(h & 512) - 1;
            for (var k, l, m = 0; m < d.length; m++)
                if (l = d[m], l < a) {
                    l += h;
                    var n = f[l];
                    null == n ? f[l] = c ? Td : $b() : c && n !== Td && Xb(n)
                } else k || (n = void 0, f.length && ic(n = f[f.length - 1]) ? k = n : f.push(k = {})), n = k[l], null == k[l] ? k[l] = c ? Td : $b() : c && n !== Td && Xb(n)
        }
        k = b.length;
        if (!k) return b;
        var p;
        if (ic(f = b[k - 1])) {
            a: {
                var r = f;c = {};a = !1;
                for (var w in r)
                    if (Object.prototype.hasOwnProperty.call(r, w)) {
                        h = r[w];
                        if (Array.isArray(h)) {
                            m = h;
                            if (!oe && pc(h, d, +w) || !Dd && hc(h) && 0 === h.size) h = null;
                            h != m && (a = !0)
                        }
                        null != h ? c[w] = h : a = !0
                    }
                if (a) {
                    for (var u in c) {
                        r = c;
                        break a
                    }
                    r = null
                }
            }
            r != f && (p = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            w = k - 1;
            f = b[w];
            if (!(null == f || !oe && pc(f, d, w - e) || !Dd && hc(f) && 0 === f.size)) break;
            var x = !0
        }
        if (!p && !x) return b;
        var y;
        g ? y = b : y = Array.prototype.slice.call(b, 0, k);
        b = y;
        g && (b.length = k);
        r && b.push(r);
        return b
    };
    qe = function(a, b) {
        if (null == b) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        Zb(b, 128);
        return nd(a, cc(b))
    };
    re = function(a, b, c) {
        a[b] = c
    };
    ve = function(a) {
        var b = a[se];
        if (!b) {
            var c = te(a);
            b = function(d, e) {
                return ue(d, e, c)
            };
            a[se] = b
        }
        return b
    };
    we = function(a) {
        return a.j
    };
    xe = function(a, b) {
        var c, d, e = a.j;
        return function(f, g, h) {
            return e(f, g, h, d || (d = te(b).j), c || (c = ve(b)))
        }
    };
    te = function(a) {
        var b = a[ye];
        if (b) return b;
        b = a[ye] = {};
        var c = we,
            d = xe;
        var e = void 0 === e ? re : e;
        b.j = qd(a[0]);
        var f = 0,
            g = a[++f];
        g && g.constructor === Object && (b.gk = g, g = a[++f], "function" === typeof g && (b.m = g, b.o = a[++f], g = a[++f]));
        for (var h = {}; Array.isArray(g) && "number" === typeof g[0] && 0 < g[0];) {
            for (var k = 0; k < g.length; k++) h[g[k]] = g;
            g = a[++f]
        }
        for (k = 1; void 0 !== g;) {
            "number" === typeof g && (k += g, g = a[++f]);
            var l = void 0;
            if (g instanceof ze) var m = g;
            else m = Ae, f--;
            if (m.ej) {
                g = a[++f];
                l = a;
                var n = f;
                "function" == typeof g && (g = g(), l[n] = g);
                l = g
            }
            g = a[++f];
            n = k + 1;
            "number" === typeof g && 0 > g && (n -= g, g = a[++f]);
            for (; k < n; k++) {
                var p = h[k];
                e(b, k, l ? d(m, l, p) : c(m, p))
            }
        }
        Be in a && ye in a && (a.length = 0);
        return b
    };
    De = function(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.gk)
            if (c = c[b]) {
                c = Array.isArray(c) ? c[0] instanceof ze ? c : [Ce, c] : [c, void 0];
                var d = c[0].j;
                if (c = c[1]) {
                    var e = ve(c),
                        f = te(c).j;
                    c = (c = a.o) ? c(f, e) : function(g, h, k) {
                        return d(g, h, k, f, e)
                    }
                } else c = d;
                return a[b] = c
            }
    };
    ue = function(a, b, c) {
        for (var d = Kd(a), e = +!!(d & 512) - 1, f = a.length, g = f + (d & 256 ? -1 : 0), h = d & 512 ? 1 : 0; h < g; h++) {
            var k = a[h];
            if (null != k) {
                var l = h - e,
                    m = De(c, l);
                m && m(b, k, l)
            }
        }
        if (d & 256) {
            a = a[f - 1];
            for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (d = +n, _.A(Number, "isNaN").call(Number, d) || (e = a[n], null != e && (f = De(c, d)) && f(b, e, d)))
        }
    };
    Ee = function(a) {
        return new ze(a, !1)
    };
    Ie = function(a, b, c) {
        a: if (null != b) {
            if (Gc(b)) {
                if ("string" === typeof b) {
                    b = Qc(b, !1);
                    break a
                }
                if ("number" === typeof b) {
                    b = Sc(b, !1);
                    break a
                }
            }
            b = void 0
        }null != b && ("string" === typeof b && Fe(b), null != b && (Ge(a.j, 8 * c), "number" === typeof b ? (a = a.j, Ob(b), He(a, Lb, Mb)) : (c = Fe(b), He(a.j, c.o, c.j))))
    };
    Ke = function(a, b, c, d, e) {
        b = b instanceof _.F ? b.D : Array.isArray(b) ? _.B(b, d[0], d[1]) : void 0;
        if (null != b) {
            Ge(a.j, 8 * c + 2);
            c = a.j.end();
            Je(a, c);
            c.push(a.o);
            e(b, a);
            e = c.pop();
            for (e = a.o + a.j.length() - e; 127 < e;) c.push(e & 127 | 128), e >>>= 7, a.o++;
            c.push(e);
            a.o++
        }
    };
    Me = function(a) {
        var b = Le;
        Le = void 0;
        if (!a) throw Error(b && b() || String(a));
    };
    Oe = function(a) {
        return function() {
            var b = new Ne;
            ue(this.D, b, te(a));
            Je(b, b.j.end());
            for (var c = new Uint8Array(b.o), d = b.m, e = d.length, f = 0, g = 0; g < e; g++) {
                var h = d[g];
                c.set(h, f);
                f += h.length
            }
            b.m = [c];
            return c
        }
    };
    Pe = function(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = nd(a, cc(b))
            }
            return b
        }
    };
    Qe = function(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    };
    _.Ve = function(a) {
        var b = _.Xa.apply(1, arguments);
        if (0 === b.length) return Ue(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Ue(c)
    };
    _.We = function(a, b) {
        var c = _.hb(a).toString();
        if (/#/.test(c)) throw Error("");
        var d = /\?/.test(c) ? "&" : "?";
        b.forEach(function(e, f) {
            e = e instanceof Array ? e : [e];
            for (var g = 0; g < e.length; g++) {
                var h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return Ue(c)
    };
    Ze = function(a) {
        return new _.Xe(JSON.stringify(a).replace(/</g, "\\u003C"), Ye)
    };
    $e = function(a) {
        a = void 0 === a ? _.t : a;
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch (e) {}
        var c, d;
        return (null == (c = b) ? 0 : c.pageViewId) && (null == (d = b) ? 0 : d.canonicalUrl) ? b : null
    };
    bf = function(a) {
        return af(2 > (a.length + 3) % 4 ? a + "A" : a).map(function(b) {
            return (_.G = b.toString(2), _.A(_.G, "padStart")).call(_.G, 8, "0")
        }).join("")
    };
    cf = function(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        return parseInt(a, 2)
    };
    df = function(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };
    ef = function(a, b) {
        var c = a.indexOf("11");
        if (-1 === c) throw Error("Expected section bitstring but not found in [" + a + "] part of [" + b + "]");
        return a.slice(0, c + 2)
    };
    ff = function(a, b) {
        var c = function(d) {
            var e = {};
            return [(e[d.Zc] = d.Pc, e)]
        };
        return JSON.stringify([a.filter(function(d) {
            return d.vc
        }).map(c), b.toJSON(), a.filter(function(d) {
            return !d.vc
        }).map(c)])
    };
    hf = function(a, b, c, d, e, f) {
        try {
            var g = a.j,
                h = _.gf("SCRIPT", g);
            h.async = !0;
            ib(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", function() {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", function() {
                0 < c ? hf(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (k) {
            f()
        }
    };
    kf = function(a, b, c, d) {
        c = void 0 === c ? function() {} : c;
        d = void 0 === d ? function() {} : d;
        hf(jf(a), b, 0, !1, c, d)
    };
    lf = function(a) {
        return a[_.A(_.v.Symbol, "iterator")]()
    }; of = function(a) {
        var b = mf(nf(a.location.href));
        a = b.get("fcconsent");
        b = b.get("fc");
        return "alwaysshow" === b ? b : "alwaysshow" === a ? a : null
    };
    pf = function(a) {
        var b = ["ab", "gdpr", "consent", "ccpa", "monetization"];
        return (a = mf(nf(a.location.href)).get("fctype")) && -1 !== b.indexOf(a) ? a : null
    };
    qf = function(a) {
        a && "function" == typeof a.wa && a.wa()
    };
    tf = function(a) {
        a = rf(a.data.__fciReturn);
        return {
            payload: a,
            yg: _.sf(a, 1)
        }
    };
    vf = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = _.gf("IMG", a.document);
        if (c || d) {
            var g = function(h) {
                c && c(h);
                d && ha(a.google_image_requests, f);
                _.uf(f, "load", g);
                _.uf(f, "error", g)
            };
            _.jb(f, "load", g);
            _.jb(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    };
    xf = function() {
        var a = wf;
        return function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        }
    };
    zf = function() {
        var a = yf;
        return function(b) {
            return b instanceof a
        }
    };
    Bf = function(a) {
        return function(b) {
            if (!Af(b)) return !1;
            for (var c = _.z(_.A(Object, "entries").call(Object, a)), d = c.next(); !d.done; d = c.next()) {
                var e = _.z(d.value);
                d = e.next().value;
                e = e.next().value;
                if (!(d in b)) {
                    if (!0 === e.Hn) continue;
                    return !1
                }
                if (!e(b[d])) return !1
            }
            return !0
        }
    };
    Cf = function() {
        return function(a) {
            return Array.isArray(a)
        }
    };
    Ff = function() {
        return function(a) {
            return Df(a) ? a.every(function(b) {
                return Ef(b)
            }) : !1
        }
    };
    Gf = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            yg: b.__uspapiReturn.callId
        }
    };
    Hf = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            yg: b.__gppReturn.callId
        }
    };
    If = function(a) {
        return !a || 1 === a.length && -1 === a[0]
    };
    Mf = function(a, b) {
        b = void 0 === b ? window : b;
        if (Lf(a)) try {
            return b.localStorage
        } catch (c) {}
        return null
    };
    Nf = function(a) {
        return "null" !== a.origin
    };
    Pf = function(a, b, c) {
        b = Lf(b) && Nf(c) ? c.document.cookie : null;
        return null === b ? null : (new Of({
            cookie: b
        })).get(a) || ""
    };
    Qf = function(a, b, c) {
        return b[a] || c
    };
    Tf = function(a) {
        _.Rf(Sf).m(a)
    };
    _.Uf = function() {
        return _.Rf(Sf).A()
    };
    Vf = function(a, b) {
        b = void 0 === b ? document : b;
        var c;
        return !(null == (c = b.featurePolicy) || !(_.G = c.allowedFeatures(), _.A(_.G, "includes")).call(_.G, a))
    };
    Wf = function(a, b, c) {
        return !!(a && "runAdAuction" in b && b.runAdAuction instanceof Function && Vf("run-ad-auction", c))
    };
    Xf = function(a, b) {
        return !!(a && "browsingTopics" in b && b.browsingTopics instanceof Function && Vf("browsing-topics", b))
    };
    Yf = function(a, b, c) {
        c = void 0 === c ? b.document : c;
        return !!(a && "sharedStorage" in b && b.sharedStorage && Vf("shared-storage", c))
    };
    ag = function(a) {
        a = void 0 === a ? _.Zf() : a;
        return function(b) {
            return _.$f(b + " + " + a) % 1E3
        }
    };
    _.H = function(a) {
        return _.Rf(bg).o(a.j, a.defaultValue)
    };
    _.cg = function(a) {
        return _.Rf(bg).m(a.j, a.defaultValue)
    };
    dg = function(a) {
        return _.Rf(bg).A(a.j, a.defaultValue)
    };
    eg = function(a) {
        return _.Rf(bg).J(a.j, a.defaultValue)
    };
    gg = function(a) {
        _.Rf(fg).j(a)
    };
    kg = function() {
        if (void 0 === b) {
            var a = void 0 === a ? _.t : a;
            var b = a.ggeac || (a.ggeac = {})
        }
        a = b;
        hg(_.Rf(Sf), a);
        ig(b);
        jg(_.Rf(fg), b);
        _.Rf(bg).j()
    };
    ig = function(a) {
        var b = _.Rf(bg);
        b.o = function(c, d) {
            return Qf(5, a, function() {
                return !1
            })(c, d, 2)
        };
        b.m = function(c, d) {
            return Qf(6, a, function() {
                return 0
            })(c, d, 2)
        };
        b.A = function(c, d) {
            return Qf(7, a, function() {
                return ""
            })(c, d, 2)
        };
        b.J = function(c, d) {
            return Qf(8, a, function() {
                return []
            })(c, d, 2)
        };
        b.j = function() {
            Qf(15, a, function() {})(2)
        }
    };
    og = function(a, b, c, d) {
        var e = new _.lg,
            f = "",
            g = function(k) {
                try {
                    var l = "object" === typeof k.data ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (_.uf(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
                } catch (m) {}
            },
            h = mg(a);
        return h ? (_.jb(a, "message", g), f = c(h), e.promise) : (c = ng(a)) ? (f = String(Math.floor(2147483647 * _.Zf())), _.jb(a, "message", g), b(c, f), e.promise) : null
    };
    pg = function(a) {
        return og(a, function(b, c) {
            var d, e;
            return void(null == (d = null != (e = b.getGmaQueryInfo) ? e : b.getGmaSig) ? void 0 : d.postMessage(c))
        }, function(b) {
            return b.getQueryInfo()
        }, function(b) {
            return b.signal
        })
    };
    qg = function(a) {
        return !!mg(a) || !!ng(a)
    };
    mg = function(a) {
        var b;
        if ("function" === typeof(null == (b = a.gmaSdk) ? void 0 : b.getQueryInfo)) return a.gmaSdk
    };
    ng = function(a) {
        var b, c, d, e, f, g;
        if ("function" === typeof(null == (b = a.webkit) ? void 0 : null == (c = b.messageHandlers) ? void 0 : null == (d = c.getGmaQueryInfo) ? void 0 : d.postMessage) || "function" === typeof(null == (e = a.webkit) ? void 0 : null == (f = e.messageHandlers) ? void 0 : null == (g = f.getGmaSig) ? void 0 : g.postMessage)) return a.webkit.messageHandlers
    };
    rg = function(a) {
        var b, c;
        return null != (c = (_.G = ["pbjs"].concat(null != (b = a._pbjsGlobals) ? b : []).map(function(d) {
            return a[d]
        }), _.A(_.G, "find")).call(_.G, function(d) {
            return Array.isArray(null == d ? void 0 : d.que)
        })) ? c : null
    };
    sg = function(a) {
        var b = a.match(/\/?([0-9]+)(?:,[0-9]+)?((?:\/.+?)+?)(?:\/*)$/);
        return 3 !== (null == b ? void 0 : b.length) ? a : "/" + b[1] + b[2]
    };
    tg = function(a, b, c) {
        var d, e;
        return null != (e = null != (d = null == b ? void 0 : b.get((void 0 === c ? 0 : c) ? sg(a) : a)) ? d : null == b ? void 0 : b.get(_.$f(a))) ? e : 0
    };
    wg = function(a, b, c) {
        var d, e, f, g, h;
        return _.lb(function(k) {
            if (1 == k.j) return d = c ? a.filter(function(l) {
                return !l.Vb
            }) : a, k.yield(_.v.Promise.all(d.map(function(l) {
                return l.Cb.promise
            })), 2);
            if (a.length === d.length) return k.return();
            e = a.filter(function(l) {
                return l.Vb
            });
            if (_.H(ug)) {
                f = _.z(b);
                for (g = f.next(); !g.done; g = f.next()) h = g.value, vg(h);
                return k.yield(_.v.Promise.all(e.map(function(l) {
                    return l.Cb.promise
                })), 0)
            }
            return k.yield(_.v.Promise.race([_.v.Promise.all(e.map(function(l) {
                return l.Cb.promise
            })), new _.v.Promise(function(l) {
                return void setTimeout(l, c)
            })]), 0)
        })
    };
    xg = function(a, b, c, d) {
        try {
            if (a.setAttribute("data-google-query-id", c), !d) {
                null != b.googletag || (b.googletag = {
                    cmd: []
                });
                var e;
                b.googletag.queryIds = null != (e = b.googletag.queryIds) ? e : [];
                b.googletag.queryIds.push(c);
                500 < b.googletag.queryIds.length && b.googletag.queryIds.shift()
            }
        } catch (f) {}
    };
    _.yg = function(a) {
        return a.innerHeight >= a.innerWidth
    };
    _.Ag = function(a) {
        var b = _.zg(a);
        a = a.innerWidth;
        return b && a ? b / a : 0
    };
    Bg = function(a, b, c) {
        b = void 0 === b ? 420 : b;
        return (a = _.zg(a, void 0 === c ? !1 : c)) ? a > b ? 32768 : 320 > a ? 65536 : 0 : 16384
    };
    Eg = function(a) {
        return (a = _.Ag(a)) ? 1.05 < a ? 262144 : .95 > a ? 524288 : 0 : 131072
    };
    _.Fg = function(a) {
        a = a.document;
        var b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    };
    _.Gg = function(a) {
        return _.Fg(a).clientHeight
    };
    _.zg = function(a, b) {
        var c = _.Fg(a).clientWidth;
        return (void 0 === b ? 0 : b) ? c * _.Hg(a) : c
    };
    _.Ig = function(a, b) {
        var c = _.Fg(a);
        return b ? (a = _.Gg(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    };
    _.Jg = function(a) {
        return void 0 === a.pageYOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    };
    _.Kg = function(a) {
        var b = a.kf,
            c = a.se,
            d = a.Qe,
            e = a.lf,
            f = a.te;
        a = a.Re;
        for (var g = [], h = 0; h < a; h++)
            for (var k = 0; k < d; k++) {
                var l = d - 1,
                    m = a - 1;
                g.push({
                    x: b + (0 === l ? 0 : k / l) * (c - b),
                    y: e + (0 === m ? 0 : h / m) * (f - e)
                })
            }
        return g
    };
    Lg = function(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };
    _.Rg = function(a) {
        var b = a.ka,
            c = a.mg,
            d = a.Le,
            e = a.bh,
            f = a.Ka,
            g = a.Fj,
            h = a.mm;
        a = 0;
        try {
            a |= b !== b.top ? 512 : 0;
            var k = Math.min(b.screen.width || 0, b.screen.height || 0);
            a |= k ? 320 > k ? 8192 : 0 : 2048;
            a |= b.navigator && Mg(b.navigator.userAgent) ? 1048576 : 0;
            if (c) {
                k = a;
                var l = b.innerHeight;
                var m = ((void 0 === h ? 0 : h) ? _.Hg(b) * l : l) >= c;
                var n = k | (m ? 0 : 1024)
            } else n = a | (_.yg(b) ? 0 : 8);
            a = n;
            a |= Bg(b, d, h);
            h || (a |= Eg(b))
        } catch (p) {
            a |= 32
        }
        switch (e) {
            case 2:
                c = f;
                c = void 0 === c ? null : c;
                d = _.Kg({
                    kf: 0,
                    se: b.innerWidth,
                    Qe: 3,
                    lf: 0,
                    te: Math.min(Math.round(b.innerWidth / 320 * 50), Ng) + 15,
                    Re: 3
                });
                null != Og(Pg(b, c), d) && (a |= 16777216);
                break;
            case 1:
                c = f, c = void 0 === c ? null : c, d = b.innerWidth, e = b.innerHeight, n = Math.min(Math.round(b.innerWidth / 320 * 50), Ng) + 15, m = _.Kg({
                    kf: 0,
                    se: d,
                    Qe: 3,
                    lf: e - n,
                    te: e,
                    Re: 3
                }), 25 < n && m.push({
                    x: d - 25,
                    y: e - 25
                }), null != Og(Pg(b, c), m) && (a |= 16777216)
        }
        g && null != _.Qg(b, void 0 === f ? null : f) && (a |= 16777216);
        return a
    };
    Mg = function(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    };
    _.Qg = function(a, b) {
        b = void 0 === b ? null : b;
        var c = a.innerHeight;
        c = _.Kg({
            kf: 0,
            se: a.innerWidth,
            Qe: 10,
            lf: c - 66,
            te: c,
            Re: 10
        });
        return Og(Pg(a, b), c)
    };
    Pg = function(a, b) {
        return new _.Sg(a, {
            Ah: Tg(a, void 0 === b ? null : b)
        })
    };
    Tg = function(a, b) {
        if (b = void 0 === b ? null : b) {
            var c = b;
            return function(d, e, f) {
                var g, h;
                _.Ug(c, "ach_evt", {
                    tn: d.tagName,
                    id: null != (g = d.getAttribute("id")) ? g : "",
                    cls: null != (h = d.getAttribute("class")) ? h : "",
                    ign: String(f),
                    pw: a.innerWidth,
                    ph: a.innerHeight,
                    x: e.x,
                    y: e.y
                }, !0, 1)
            }
        }
    };
    _.Vg = function(a) {
        a = void 0 === a ? _.t : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    };
    _.Wg = function(a) {
        a = void 0 === a ? _.t : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    Xg = function(a, b) {
        b = void 0 === b ? _.t : b;
        var c, d;
        return (null == (c = b.performance) ? void 0 : null == (d = c.timing) ? void 0 : d[a]) || 0
    };
    _.Yg = function(a) {
        a = void 0 === a ? _.t : a;
        var b = Math.min(Xg("domLoading", a) || Infinity, Xg("domInteractive", a) || Infinity);
        return Infinity === b ? Math.max(Xg("responseEnd", a), Xg("navigationStart", a)) : b
    };
    $g = function(a, b) {
        b = void 0 === b ? [] : b;
        var c = Date.now();
        return _.Zg(b, function(d) {
            return c - d < 1E3 * a
        })
    };
    bh = function(a, b) {
        try {
            var c = a.getItem("__lsv__");
            if (!c) return [];
            try {
                var d = JSON.parse(c)
            } catch (e) {}
            if (!Array.isArray(d) || _.ah(d, function(e) {
                    return !_.A(Number, "isInteger").call(Number, e)
                })) return a.removeItem("__lsv__"), [];
            d = $g(b, d);
            d.length || null == a || a.removeItem("__lsv__");
            return d
        } catch (e) {
            return null
        }
    };
    dh = function(a, b) {
        return null !== _.ch(a, function(c) {
            return c.nodeType === Node.ELEMENT_NODE && b.has(c)
        }, !0)
    };
    eh = function(a, b) {
        return _.ch(a, function(c) {
            return c.nodeType === Node.ELEMENT_NODE && "fixed" === b.getComputedStyle(c, null).position
        }, !0)
    };
    fh = function(a) {
        return Math.round(10 * Math.round(a / 10))
    };
    gh = function(a) {
        return a.position + "-" + fh(a.ha) + "x" + fh(a.na) + "-" + fh(a.scrollY + a.Tc) + "Y"
    };
    hh = function(a) {
        return "f-" + gh({
            position: a.position,
            Tc: a.Tc,
            scrollY: 0,
            ha: a.ha,
            na: a.na
        })
    };
    ih = function(a, b) {
        a = Math.min(null != a ? a : Infinity, null != b ? b : Infinity);
        return Infinity !== a ? a : 0
    };
    kh = function(a, b, c) {
        var d = _.jh(c.ka).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.min(e.bottom + 10, c.na),
                    g = Math.max(e.left - 10, 0),
                    h = Math.min(e.right + 10, c.ha),
                    k = .3 * c.ha;
                for (e = Math.max(e.top - 10, 0); e <= f; e += 10) {
                    if (0 < h && g < k) {
                        var l = hh({
                            position: "left",
                            Tc: e,
                            ha: c.ha,
                            na: c.na
                        });
                        b.set(l, ih(b.get(l), g))
                    }
                    if (g < c.ha && h > c.ha - k) {
                        l = hh({
                            position: "right",
                            Tc: e,
                            ha: c.ha,
                            na: c.na
                        });
                        var m = c.ha - h;
                        b.set(l, ih(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    };
    _.mh = function(a) {
        if (1200 > a.ha || 650 > a.na) return null;
        var b = _.jh(a.ka).sideRailAvailableSpace;
        if (!a.Qh) {
            var c = {
                    ka: a.ka,
                    ha: a.ha,
                    na: a.na,
                    hc: a.hc
                },
                d = "f-" + fh(c.ha) + "x" + fh(c.na);
            if (!b.has(d)) {
                b.set(d, 0);
                _.jh(c.ka).sideRailProcessedFixedElements.clear();
                d = new _.v.Set([].concat(_.lh(_.A(Array, "from").call(Array, c.ka.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]"))), _.lh(c.hc)));
                for (var e = c.ka, f = [], g = _.z(e.document.querySelectorAll("*")), h = g.next(); !h.done; h = g.next()) {
                    h = h.value;
                    var k = e.getComputedStyle(h, null);
                    "fixed" === k.position && "none" !== k.display && "hidden" !== k.visibility && f.push(h)
                }
                e = _.z(f);
                for (f = e.next(); !f.done; f = e.next()) f = f.value, dh(f, d) || kh(f, b, c)
            }
        }
        c = [];
        e = .9 * a.na;
        f = _.Jg(a.ka);
        g = d = (a.na - e) / 2;
        h = e / 7;
        for (k = 0; 8 > k; k++) {
            var l = c,
                m = l.push;
            var n = g;
            var p = a.position,
                r = {
                    ka: a.ka,
                    ha: a.ha,
                    na: a.na,
                    hc: a.hc
                },
                w = hh({
                    position: p,
                    Tc: n,
                    ha: r.ha,
                    na: r.na
                }),
                u = gh({
                    position: p,
                    Tc: n,
                    scrollY: f,
                    ha: r.ha,
                    na: r.na
                });
            if (!b.has(u)) {
                var x = "left" === p ? 20 : r.ha - 20,
                    y = x;
                p = .3 * r.ha / 5 * ("left" === p ? 1 : -1);
                for (var C = 0; 6 > C; C++) {
                    var D = Lg(r.ka.document, {
                            x: Math.round(y),
                            y: Math.round(n)
                        }),
                        E = dh(D, r.hc),
                        J = eh(D, r.ka);
                    if (!E && null !== J) {
                        kh(J, b, r);
                        b.delete(u);
                        break
                    }
                    E || (E = D.offsetHeight >= .25 * r.na, E = D.offsetWidth >= .9 * r.ha && E);
                    if (E) b.set(u, Math.round(Math.abs(y - x) + 20));
                    else if (y !== x) y -= p, p /= 2;
                    else {
                        b.set(u, 0);
                        break
                    }
                    y += p
                }
            }
            n = ih(b.get(w), b.get(u));
            m.call(l, n);
            g += h
        }
        b = a.Gi;
        f = a.position;
        e = Math.round(e / 8);
        d = Math.round(d);
        g = a.minWidth;
        a = a.minHeight;
        l = [];
        h = _.A(Array(c.length), "fill").call(Array(c.length), 0);
        for (k = 0; k < c.length; k++) {
            for (; 0 !== l.length && c[l[l.length - 1]] >= c[k];) l.pop();
            h[k] = 0 === l.length ? 0 : l[l.length - 1] + 1;
            l.push(k)
        }
        l = [];
        m = c.length - 1;
        k = _.A(Array(c.length), "fill").call(Array(c.length), 0);
        for (n = m; 0 <= n; n--) {
            for (; 0 !== l.length && c[l[l.length - 1]] >= c[n];) l.pop();
            k[n] = 0 === l.length ? m : l[l.length - 1] - 1;
            l.push(n)
        }
        l = null;
        for (m = 0; m < c.length; m++)
            if (n = {
                    position: f,
                    width: Math.round(c[m]),
                    height: Math.round((k[m] - h[m] + 1) * e),
                    offsetY: d + h[m] * e
                }, r = n.width >= g && n.height >= a, 0 === b && r) {
                l = n;
                break
            } else 1 === b && r && (!l || n.width * n.height > l.width * l.height) && (l = n);
        return l
    };
    nh = function(a) {
        var b = a.split("/");
        return "/" === a.charAt(0) && 2 <= b.length ? b[1] : "/" !== a.charAt(0) && 1 <= b.length ? b[0] : ""
    };
    oh = function() {
        var a = Date.now();
        return _.A(Number, "isFinite").call(Number, a) ? Math.round(a) : 0
    };
    uh = function(a) {
        var b = new ph;
        var c = oh();
        b = _.qh(b, 1, c);
        b = _.qh(b, 2, a.pvsid);
        b = _.rh(b, 3, a.xb || a.eb);
        c = _.Uf();
        b = _.ie(b, 4, c, Lc);
        b = _.qh(b, 5, a.Vh);
        a = _.rh(b, 12, a.Lf);
        var d;
        if (b = null == (d = _.v.globalThis.performance) ? void 0 : d.memory) {
            d = new sh;
            try {
                _.qh(d, 1, b.jsHeapSizeLimit)
            } catch (e) {}
            try {
                _.qh(d, 2, b.totalJSHeapSize)
            } catch (e) {}
            try {
                _.qh(d, 3, b.usedJSHeapSize)
            } catch (e) {}
        } else d = void 0;
        d && _.th(a, 10, d);
        return a
    };
    Bh = function(a) {
        var b = _.Yg();
        if (a.Bc) {
            var c = a.Qa,
                d = c.Ac,
                e = uh(a),
                f = new vh;
            b = _.qh(f, 2, b);
            f = new wh;
            f = _.xh(f, 1, a.Bc);
            f = _.yh(f, 2, a.Vh);
            f = _.xh(f, 3, a.Ji);
            f = _.yh(f, 4, a.Uh);
            f = _.xh(f, 5, a.Hg);
            a = _.yh(f, 6, a.Pf);
            a = _.th(b, 3, a);
            e = _.zh(e, 6, Ah, a);
            d.call(c, e)
        }
    };
    Eh = function(a) {
        if (!a.Bc) return function() {};
        var b = oh();
        a.Qa.Ac(Ch(uh(a)));
        return function() {
            var c = a.Qa,
                d = c.Ac,
                e = uh(a);
            var f = new Dh;
            var g = oh() - b;
            f = _.qh(f, 1, g);
            e = _.zh(e, 14, Ah, f);
            return void d.call(c, e)
        }
    };
    Gh = function(a) {
        var b = void 0 === b ? _.Zf() : b;
        a.Ol && (.25 > b ? Fh(a.Qa, {
            step: 1,
            tf: "ONE"
        }) : .5 > b ? Fh(a.Qa, {
            step: 2,
            tf: "TWO"
        }) : .75 > b ? Fh(a.Qa, {
            step: 3,
            tf: "THREE"
        }) : Fh(a.Qa, {
            step: 6,
            tf: "SIX"
        }))
    };
    L = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        return function() {
            var e = _.Xa.apply(0, arguments),
                f = Hh(a, b, c, d).apply(this, e);
            try {
                var g = e.length;
                if (a.Bc && a.Ji) {
                    var h = a.Qa,
                        k = h.Ac,
                        l = uh(a);
                    var m = _.qh(l, 5, a.Uh);
                    var n = new Ih;
                    var p = _.I(n, 1, b);
                    var r = _.yh(p, 2, g);
                    var w = _.zh(m, 9, Ah, r);
                    k.call(h, w)
                }
            } catch (u) {}
            return f
        }
    };
    Hh = function(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        return function() {
            var e = _.Xa.apply(0, arguments),
                f = void 0,
                g = !1,
                h = null,
                k = _.Rf(Jh);
            try {
                var l = _.H(Kh);
                l && k && (h = k.start(b.toString(), 3));
                f = c.apply(this, e);
                g = !0;
                l && k && k.end(h)
            } catch (m) {
                try {
                    if (g) Lh.call(this, a, 110, m);
                    else if (Lh.call(this, a, b, m), !d) throw m;
                } catch (n) {
                    if (_.Mh(h), !g && !d) throw m;
                }
            }
            return f
        }
    };
    Nh = function(a, b, c, d) {
        return Hh(a, b, c, void 0 === d ? !1 : d)()
    };
    Lh = function(a, b, c) {
        if (a.Hg) {
            c = _.Oh(c) ? c.error : c;
            var d = new Ph,
                e = new Qh;
            try {
                var f = _.Rh(window);
                _.qh(e, 1, f)
            } catch (p) {}
            try {
                var g = _.Uf();
                _.ie(e, 2, g, Lc)
            } catch (p) {}
            try {
                _.rh(e, 3, window.document.URL)
            } catch (p) {}
            f = _.th(d, 2, e);
            g = new Sh;
            b = _.I(g, 1, b);
            try {
                var h = Ef(null == c ? void 0 : c.name) ? c.name : "Unknown error";
                _.rh(b, 2, h)
            } catch (p) {}
            try {
                var k = Ef(null == c ? void 0 : c.message) ? c.message : "Caught " + c;
                _.rh(b, 3, k)
            } catch (p) {}
            try {
                var l = Ef(null == c ? void 0 : c.stack) ? c.stack : Error().stack;
                l && _.Uh(b, 4, l.split(/\n\s*/))
            } catch (p) {}
            h = _.th(f, 1, b);
            k = new Vh;
            try {
                _.rh(k, 1, a.xb || a.eb)
            } catch (p) {}
            try {
                var m = Wh();
                _.yh(k, 2, m)
            } catch (p) {}
            try {
                var n = [].concat(_.lh(_.A(Xh, "keys").call(Xh)));
                _.Uh(k, 3, n)
            } catch (p) {}
            _.zh(h, 4, Yh, k);
            _.qh(h, 5, a.Pf);
            a.Qa.Kl(h)
        }
    };
    ci = function(a, b, c) {
        var d, e;
        return null != (e = null == (d = _.A(a, "find").call(a, function(f) {
            f = _.Zh(f, $h, 1);
            return ai(f, 1) <= b && ai(f, 2) <= c
        })) ? void 0 : _.bi(d, $h, 2)) ? e : null
    };
    ei = function(a, b, c) {
        return "number" === typeof b && "number" === typeof c && _.bi(a, di, 6).length ? ci(_.bi(a, di, 6), b, c) : _.bi(a, $h, 5)
    };
    gi = function(a) {
        var b = void 0 === b ? window : b;
        var c = null;
        b.top === b && (b = fi(!1, b), c = ei(a, b.width, b.height));
        null != c || (c = ei(a));
        return null == c ? [] : c.map(function(d) {
            return _.N(d, 3) ? "fluid" : [ai(d, 1), ai(d, 2)]
        })
    };
    hi = function(a) {
        var b = [],
            c = !1;
        a = _.z(gi(a));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, Array.isArray(d) ? b.push(d.join("x")) : "fluid" === d ? c = !0 : b.push(d);
        c && b.unshift("320x50");
        return b.join("|")
    };
    _.ki = function(a) {
        _.Rf(ii).j = !0;
        return ji[a]
    };
    mi = function(a) {
        var b = a.document;
        return li(a) ? b.URL : b.referrer
    };
    pi = function(a) {
        try {
            return ni(a, window.top)
        } catch (b) {
            return new _.oi(-12245933, -12245933)
        }
    };
    yi = function(a) {
        if (!a) return null;
        var b, c;
        a.getBoundingClientRect ? (a = _.vi(wi, a), a = new _.xi(a.right - a.left, a.bottom - a.top)) : a = null;
        return null != (c = null == (b = a) ? void 0 : b.floor()) ? c : null
    };
    Bi = function(a, b) {
        for (var c = {}, d = _.z(_.A(Object, "keys").call(Object, b)), e = d.next(); !e.done; e = d.next()) {
            e = e.value;
            var f = _.Nd(b[e]),
                g = _.Rf(zi),
                h = g.j.get(e);
            null == h ? h = ++_.Rf(Jh).m : g.j.delete(e);
            _.Ai(f, 20, _.Oc(h));
            c[e] = f
        }
        return {
            W: _.Nd(a),
            R: c
        }
    };
    Di = function() {
        for (var a = "", b = _.z(Ci()), c = b.next(); !c.done; c = b.next()) c = c.value, 15 >= c && (a += "0"), a += c.toString(16);
        return a
    };
    Ci = function() {
        var a;
        if ("function" === typeof(null == (a = window.crypto) ? void 0 : a.getRandomValues)) return a = new Uint8Array(16), window.crypto.getRandomValues(a), a;
        a = window;
        var b;
        if ("function" === typeof(null == (b = a.msCrypto) ? void 0 : b.getRandomValues)) return b = new Uint8Array(16), a.msCrypto.getRandomValues(b), b;
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(255 * Math.random());
        return a
    };
    Ki = function(a, b, c, d) {
        var e = Ei(b, a) || Fi(b, a);
        if (!e) return null;
        var f = pi(e),
            g = e === Fi(b, a),
            h = Gi(function() {
                var p = g ? Fi(b, a) : e;
                return p && Hi(p, window)
            }),
            k = function(p) {
                var r;
                return null == (r = h()) ? void 0 : r.getPropertyValue(p)
            };
        c = gi(c)[0];
        var l = !1;
        Array.isArray(c) && (l = d ? g : 0 === f.x && "center" === k("text-align"));
        l && (f.x += Math.round(Math.max(0, (g ? e.clientWidth : e.parentElement.clientWidth) - Number(c[0])) / 2));
        if (g) {
            var m;
            f.y += Math.round(Math.min(null != (m = Ii(k("padding-top"))) ? m : 0, e.clientHeight));
            if (!l) {
                d = e.clientWidth;
                var n;
                f.x += Math.round(Math.min(null != (n = Ii(k("padding-left"))) ? n : 0, d))
            }
        }
        return f && Ji(e) ? f : new _.oi(-12245933, -12245933)
    };
    Li = function(a, b, c, d) {
        var e = Fi(a, c),
            f = "none" === (null == e ? void 0 : e.style.display);
        f && (e.style.display = "block");
        a = Ki(c, a, b, d);
        f && (e.style.display = "none");
        return a
    };
    Mi = function(a) {
        return "google_ads_iframe_" + a.toString()
    };
    Ni = function(a) {
        return Mi(a) + "__container__"
    };
    Ei = function(a, b) {
        var c;
        return (null == (c = Fi(a, b)) ? void 0 : c.querySelector('[id="' + Ni(a) + '"]')) || null
    };
    Oi = function(a, b) {
        var c, d;
        return null != (d = null == (c = Ei(a, b)) ? void 0 : c.querySelector('iframe[id="' + Mi(a) + '"]')) ? d : null
    };
    Fi = function(a, b) {
        b = void 0 === b ? document : b;
        return Pi().m.get(a) || b.getElementById(a.getDomId())
    };
    Qi = function(a) {
        return Math.round(Number(Ii(a)))
    };
    Ri = function(a) {
        var b = a.parentElement;
        return !b || 1 >= b.children.length ? !1 : _.A(Array, "from").call(Array, b.children).some(function(c) {
            return c !== a && !(_.G = ["script", "style"], _.A(_.G, "includes")).call(_.G, c.tagName.toLowerCase())
        })
    };
    Ti = function(a, b, c) {
        for (var d = 100; a && a !== b && --d;) _.Si(a, c), a = a.parentElement
    };
    Ui = function(a, b, c, d, e) {
        _.Si(a, {
            "margin-left": "0px",
            "margin-right": "0px"
        });
        var f = {},
            g = "rtl" === d.direction,
            h = ((e && -12245933 !== e.width ? e.width : b.innerWidth) - c) / 2;
        d = function() {
            var k = a.getBoundingClientRect().left;
            return g ? h - k : k - h
        };
        b = d();
        return 0 !== b ? (c = function(k) {
            g ? f["margin-right"] = k + "px" : f["margin-left"] = k + "px"
        }, c(-b), _.Si(a, f), d = d(), 0 !== d && b !== d && (c(b / (d - b) * b), _.Si(a, f)), !0) : !1
    };
    Wi = function(a, b, c, d, e, f, g, h, k, l) {
        window.setTimeout(function() {
            var m = hi(d);
            if (window.IntersectionObserver) {
                var n, p = null != (n = Oi(c, b)) ? n : Fi(c, b);
                m = Vi(a, b, c, e, f, g, m, h, k, l, p);
                (new window.IntersectionObserver(m, {
                    threshold: .98
                })).observe(p)
            }
        }, 500)
    };
    Vi = function(a, b, c, d, e, f, g, h, k, l, m) {
        var n = window.location && "#flexibleAdSlotTest" === window.location.hash ? 1 : _.cg(Xi);
        return Hh(a, 459, function(p, r) {
            (p = null == p ? void 0 : p[0]) && Yi(a, b, c, d, e, f, g, h, k, l, r, m, p, n)
        })
    };
    Yi = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        var w = p.boundingClientRect,
            u = p.intersectionRatio,
            x = window.innerWidth,
            y = w.left,
            C = w.right,
            D = 0 > y + 2,
            E = 0 < C - (x + 2);
        (.98 <= u || D || E) && Zi(k, function(J) {
            m.unobserve(n);
            var M = D || E;
            var K = new $i;
            aj(n, M) && K.set(10);
            if (void 0 !== h && Ri(n)) {
                var X, ba = null == (X = Fi(c, b)) ? void 0 : X.parentElement,
                    la;
                X = ba ? null == (la = Hi(ba, window)) ? void 0 : la.width : void 0;
                h !== X && K.set(16)
            }
            M ? (K.set(8), M = bj(K)) : M = cj(b, c, u, K);
            la = dj(c, n, f);
            K = la.Mk;
            la = la.Ok;
            ej(J, a);
            fj(J, "qid", l);
            fj(J, "iu", c.getAdUnitPath());
            fj(J, "e", String(M));
            D && fj(J, "ofl", String(y));
            E && fj(J, "ofr", String(C - x));
            fj(J, "ret", e + "x" + f);
            fj(J, "req", g);
            fj(J, "bm", String(d));
            fj(J, "efh", Number(K));
            fj(J, "stk", Number(la));
            fj(J, "ifi", gj(window))
        }, r)
    };
    cj = function(a, b, c, d) {
        var e = Oi(b, a) || Fi(b, a);
        try {
            var f = e.getBoundingClientRect(),
                g = f.left,
                h = f.top,
                k = f.width,
                l = f.height,
                m = Fi(b, a),
                n = Hi(m, window);
            if ("hidden" === n.visibility || "none" === n.display) return bj(d);
            var p = Qi(n.getPropertyValue("border-top-width") || 0) + 1;
            b = g + k;
            f = h + l;
            c = (1 - c) * l;
            var r = a.elementsFromPoint(g + p + 2, h + c + p);
            var w = a.elementsFromPoint(b - p - 2, h + c + p);
            var u = a.elementsFromPoint(b - p - 2, f - c - p);
            var x = a.elementsFromPoint(g + p + 2, f - c - p);
            var y = a.elementsFromPoint(b / 2, f - c - p)
        } catch (D) {
            return d.set(1), bj(d)
        }
        if (!(r && r.length && w && w.length && u && u.length && x && x.length && y && y.length)) return d.set(7), bj(d);
        a = function(D, E) {
            for (var J = !1, M = 0; M < D.length; M++) {
                var K = D[M];
                if (J) {
                    var X = Hi(K, window);
                    if ("hidden" !== X.visibility && !hj(K) && !C(e, K)) {
                        d.set(E);
                        "absolute" === X.position && d.set(11);
                        break
                    }
                } else e === K && (J = !0)
            }
        };
        ij(e) && d.set(9);
        var C = function(D, E) {
            return jj(D, E) || jj(E, D)
        };
        g = r[0];
        e === g || C(e, g) || hj(g) || d.set(2);
        g = w[0];
        e === g || C(e, g) || hj(g) || d.set(3);
        g = u[0];
        e === g || C(e, g) || hj(g) || d.set(4);
        g = x[0];
        e === g || C(e, g) || hj(g) || d.set(5);
        if (hj(e)) return bj(d);
        a(r, 12);
        a(w, 13);
        a(u, 14);
        a(x, 15);
        a(y, 6);
        return bj(d)
    };
    aj = function(a, b) {
        var c = !1,
            d = !1;
        return kj(a, function(e, f) {
            d = d || "scroll" === e.overflowX || "auto" === e.overflowX;
            c = c || "flex" === e.display;
            return b && c && d || "listbox" === f.role
        })
    };
    dj = function(a, b, c) {
        var d = (a = Fi(a)) && Hi(a, window),
            e = d ? "absolute" !== d.position : !0,
            f = !1,
            g = a && a.parentElement,
            h = !1;
        lj(b, function(k) {
            var l = k.style;
            if (e)
                if (h || (h = k === g)) e = mj(k, _.t, -1, -1);
                else {
                    l = l && l.height;
                    var m = (l && _.A(l, "endsWith").call(l, "px") ? Qi(l) : 0) >= c;
                    !l || m || "string" === typeof l && _.A(nj, "includes").call(nj, l) || (e = !1)
                }
            f || (k = Hi(k, _.t), "sticky" !== k.position && "fixed" !== k.position) || (f = !0);
            return !(f && !e)
        }, 100);
        return {
            Mk: e,
            Ok: f
        }
    };
    mj = function(a, b, c, d) {
        var e = a.style;
        return (null == e ? 0 : e.height) && !_.A(nj, "includes").call(nj, e.height) || (null == e ? 0 : e.maxHeight) && !_.A(oj, "includes").call(oj, e.maxHeight) || pj(a, b.document, function(f) {
            var g = f.style.height;
            f = f.style.getPropertyValue("max-height");
            return !!g && !_.A(nj, "includes").call(nj, g) || !!f && !_.A(oj, "includes").call(oj, f)
        }, c, d) ? !1 : !0
    };
    pj = function(a, b, c, d, e) {
        b = b.styleSheets;
        if (!b) return !1;
        var f = a.matches || a.msMatchesSelector;
        d = -1 === d ? Infinity : d;
        e = -1 === e ? Infinity : e;
        for (var g = 0; g < Math.min(b.length, d); ++g) {
            var h = null;
            try {
                var k = b[g],
                    l = null;
                try {
                    l = k.cssRules || k.rules
                } catch (D) {
                    if (15 == D.code) throw D.styleSheet = k, D;
                }
                h = l
            } catch (D) {
                continue
            }
            l = void 0;
            if (null != (l = h) && l.length)
                for (l = 0; l < Math.min(h.length, e); ++l) try {
                    var m = h[l],
                        n, p = c;
                    if (!(n = f.call(a, m.selectorText) && p(m))) a: {
                        var r = void 0;p = a;
                        var w = c,
                            u = e,
                            x = null != (r = m.cssRules) ? r : [];
                        for (r = 0; r < Math.min(x.length, u); r++) {
                            var y = x[r],
                                C = w;
                            if (f.call(p, y.selectorText) && C(y)) {
                                n = !0;
                                break a
                            }
                        }
                        n = !1
                    }
                    if (n) return !0
                } catch (D) {}
        }
        return !1
    };
    hj = function(a) {
        return kj(a, function(b) {
            return "fixed" === b.position || "sticky" === b.position
        })
    };
    ij = function(a) {
        return kj(a, function(b) {
            var c;
            return (_.G = ["left", "right"], _.A(_.G, "includes")).call(_.G, null != (c = b["float"]) ? c : b.cssFloat)
        })
    };
    qj = function(a) {
        return "number" === typeof a || "string" === typeof a
    };
    tj = function(a) {
        a = rj(a);
        return _.sj(a)
    };
    rj = function(a) {
        return null === a ? "null" : void 0 === a ? "undefined" : a
    };
    wj = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? {} : d;
        var e = uj.j();
        0 === e.j && (e.j = .001 > Math.random() ? 2 : 1);
        2 === e.j && (e = {}, vj(_.A(Object, "assign").call(Object, {}, (e.c = String(a), e.pc = String(_.Rh(window)), e.em = c, e.lid = b, e.eids = _.Uf().join(), e), d), "esp"))
    };
    xj = function() {
        var a = window;
        var b = void 0 === b ? function() {} : b;
        return new _.v.Promise(function(c) {
            var d = function() {
                c(b());
                _.uf(a, "load", d)
            };
            _.jb(a, "load", d)
        })
    };
    yj = function(a) {
        var b = [],
            c = RegExp("^_GESPSK-(.+)$");
        try {
            for (var d = 0; d < a.length; d++) {
                var e = (c.exec(a.key(d)) || [])[1];
                e && b.push(e)
            }
        } catch (f) {}
        return b
    };
    Bj = function(a, b) {
        return _.bi(a, zj, 2).some(function(c) {
            return _.Aj(c, 1) === b && null != _.Aj(c, 2)
        })
    };
    Cj = function(a, b) {
        return _.bi(a, zj, 2).some(function(c) {
            return _.Aj(c, 1) === b && null != _.Aj(c, 2)
        })
    };
    Hj = function(a, b, c, d) {
        if (b)
            for (var e = _.z(yj(b)), f = e.next(), g = {}; !f.done; g = {
                    oc: g.oc
                }, f = e.next())
                if (g.oc = f.value, (f = Dj().get(g.oc, b).Cc) && !Cj(a, g.oc)) {
                    var h = Ej(f);
                    if (2 !== h && 3 !== h) {
                        h = !1;
                        if (c) {
                            var k = /^(\d+)$/.exec(g.oc);
                            if (k && !(h = _.A(c.split(","), "includes").call(c.split(","), k[1]))) continue;
                            if (!h && !c.split(",").some(function(l) {
                                    return function(m) {
                                        var n;
                                        return null == d ? void 0 : null == (n = d.get(m)) ? void 0 : n.has(l.oc)
                                    }
                                }(g))) continue
                        }
                        Fj(f, 9, h);
                        h = _.Aj(f, 2);
                        Gj(a, 2, zj, f);
                        f = {};
                        wj(19, g.oc, null, (f.hs = h ? "1" : "0", f))
                    }
                }
    };
    Ij = function(a) {
        return "string" === typeof a ? a : a instanceof Error ? a.message : null
    };
    Tj = function(a, b, c, d, e) {
        var f, g, h, k, l, m, n, p, r, w, u, x, y;
        return _.lb(function(C) {
            return 1 == C.j ? (f = new Jj, g = new Kj(a, c, e), O(f, g), O(f, new Lj(g.v, void 0, d, e)), h = new Mj(g.l, e), O(f, h), k = new Nj(h.l, e), O(f, k), l = new Oj(b, k.l, e), O(f, l), O(f, new Lj(l.v, void 0, d, e)), m = new Pj(l.l, l.G, 300, 1E3, e), O(f, m), O(f, new Lj(m.l, void 0, d, e)), n = new Qj(e), O(f, n), p = new Rj(n.output, k.v, e), O(f, p), r = new Oj(b, p.l, e), O(f, r), w = new Lj(r.l, void 0, d, e), O(f, w), Sj(f), y = a, C.yield(m.l.promise, 2)) : C.return({
                id: y,
                collectorGeneratedData: null != (x = null == (u = C.o) ? void 0 : _.Aj(u, 2)) ? x : null
            })
        })
    };
    Zj = function(a, b, c, d) {
        var e = {};
        e = void 0 === e ? Uj : e;
        Vj() !== Wj(window) ? wj(16, "") : Xj(a, "encryptedSignalProviders", c) && Xj(a, "secureSignalProviders", c) || (wj(38, ""), Yj(a, "encryptedSignalProviders", b, e, c, d), Yj(a, "secureSignalProviders", b, e, c, function() {}))
    };
    Xj = function(a, b, c) {
        if (void 0 === a[b] || a[b] instanceof Array) return !1;
        a[b].addErrorHandler(c);
        return !0
    };
    Yj = function(a, b, c, d, e, f) {
        var g, h = new ak(null != (g = a[b]) ? g : [], c, "secureSignalProviders" === b, f, d);
        a[b] = new bk(h);
        h.addErrorHandler(e)
    };
    ek = function(a, b) {
        var c = new Jj,
            d = new Qj(b);
        a = new ck(d.output, a, b);
        dk(c, [d, a]);
        Sj(c)
    };
    ik = function(a, b, c, d, e) {
        var f = b.toString();
        if (fk.has(f)) return null;
        fk.add(f);
        f = new Jj;
        a = new Kj(a, c, e);
        var g = new Lj(a.v, c, d, e),
            h = new gk(a.l, e),
            k = new Mj(h.l, e);
        b = new hk(k.l, b, e);
        c = new Lj(b.l, c, d, e);
        dk(f, [a, g, h, k, b, c]);
        Sj(f);
        return f
    };
    kk = function(a, b, c) {
        c = void 0 === c ? jk : c;
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), "complete" === a.document.readyState ? c(a, b) : _.jb(a, "load", function() {
            return void c(a, b)
        }))
    };
    lk = function(a) {
        try {
            var b, c;
            return (null != (c = null == (b = a.top) ? void 0 : b.frames) ? c : {}).google_ads_top_frame
        } catch (d) {}
        return null
    };
    mk = function(a) {
        var b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    };
    ok = function(a) {
        if (a === a.top || _.nk(a.top)) return _.v.Promise.resolve({
            status: 4
        });
        var b = lk(a);
        if (!b) return _.v.Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && mk(a.document.referrer)) return _.v.Promise.resolve({
            status: 3
        });
        var c = new _.lg;
        a = new MessageChannel;
        a.port1.onmessage = function(d) {
            "__goog_top_url_resp" === d.data.msgType && c.resolve({
                re: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    sk = function(a, b) {
        var c = pk(a);
        return c.messageChannelSendRequestFn ? _.v.Promise.resolve(c.messageChannelSendRequestFn) : new _.v.Promise(function(d) {
            function e(k) {
                return h.j(k).then(function(l) {
                    return l.data
                })
            }
            var f = _.gf("IFRAME");
            f.style.display = "none";
            f.name = "goog_topics_frame";
            b && (f.credentialless = !0);
            f.src = _.hb(qk).toString();
            var g = (new URL(qk.toString())).origin,
                h = rk({
                    destination: a,
                    nb: f,
                    origin: g,
                    ub: "goog:gRpYw:doubleclick"
                });
            h.j("goog:topics:frame:handshake:ack").then(function(k) {
                "goog:topics:frame:handshake:ack" === k.data && d(e)
            });
            c.messageChannelSendRequestFn = e;
            a.document.documentElement.appendChild(f)
        })
    };
    Bk = function(a, b, c, d) {
        var e = {
            skipTopicsObservation: _.H(tk),
            includeBuyerTopics: _.H(uk)
        };
        e = void 0 === e ? {} : e;
        var f = vk(d),
            g = f.ie,
            h = f.he;
        b = pk(b);
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e.skipTopicsObservation,
            includeBuyerTopics: e.includeBuyerTopics
        }).then(function(k) {
            var l = h;
            if (k instanceof Uint8Array) l || (l = !(g instanceof Uint8Array && va(k, g)));
            else if (xf()(k)) l || (l = k !== g);
            else return c.tb(989, Error(JSON.stringify(k))), 7;
            if (l && d) try {
                var m = new wk;
                var n = _.xk(m, 2, _.Vg());
                k instanceof Uint8Array ? yk(n, 1, zk, oc(k, !1, !1)) : yk(n, 3, zk, null == k ? k : Jc(k));
                d.setItem("goog:cached:topics", Ak(n))
            } catch (p) {}
            return k
        }), b.getTopicsPromise = a);
        return g && !h ? _.v.Promise.resolve(g) : b.getTopicsPromise
    };
    vk = function(a) {
        if (!a) return {
            ie: null,
            he: !0
        };
        try {
            var b = a.getItem("goog:cached:topics");
            if (!b) return {
                ie: null,
                he: !0
            };
            var c = Ck(b),
                d = Dk(c, zk);
            switch (d) {
                case 0:
                    var e = null;
                    break;
                case 1:
                    e = Ek(Fk(c, Gk(c, zk, 1)));
                    break;
                case 3:
                    e = _.Hk(c, Gk(c, zk, 3), 0);
                    break;
                default:
                    _.db(d)
            }
            var f = _.sf(c, 2) + 6048E5 < _.Vg();
            return {
                ie: e,
                he: f
            }
        } catch (g) {
            return {
                ie: null,
                he: !0
            }
        }
    };
    pk = function(a) {
        var b;
        return null != (b = a.google_tag_topics_state) ? b : a.google_tag_topics_state = {}
    };
    Kk = function(a) {
        if (Na()) {
            var b = a.document.documentElement.lang;
            Ik(a) ? Jk(_.Rh(a), !0, "", b) : (new MutationObserver(function(c, d) {
                Ik(a) && (Jk(_.Rh(a), !1, b, a.document.documentElement.lang), d.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    };
    Ik = function(a) {
        var b, c;
        a = null == (b = a.document) ? void 0 : null == (c = b.documentElement) ? void 0 : c.classList;
        return !!((null == a ? 0 : a.contains("translated-rtl")) || (null == a ? 0 : a.contains("translated-ltr")))
    };
    Jk = function(a, b, c, d) {
        vj({
            ptt: "17",
            pvsid: "" + a,
            ibatl: String(b),
            pl: c,
            nl: d
        }, "translate-event")
    };
    Mk = function(a) {
        var b = "";
        Lk(function(c) {
            if (c === c.top) return !0;
            var d;
            if (null == (d = c.document) ? 0 : d.referrer) b = c.document.referrer;
            return !1
        }, !1, !1, a);
        return b
    };
    Ok = function(a) {
        var b = Nk(a, 500, 300);
        var c = a.navigator;
        var d = c.userAgent;
        var e = c.platform;
        c = c.product;
        !/Win|Mac|Linux|iPad|iPod|iPhone/.test(e) && /^Opera/.test(d) ? d = !1 : /Win/.test(e) && /Trident/.test(d) && 11 <= a.document.documentMode ? d = !0 : (a = (/WebKit\/(\d+)/.exec(d) || [0, 0])[1], e = (/rv:(\d+\.\d+)/.exec(d) || [0, 0])[1], d = !a && "Gecko" === c && 27 <= e && !/ rv: 1\.8([^.] |\.0) /.test(d) || 536 <= a ? !0 : !1);
        return d && !b
    };
    Rk = function(a, b) {
        var c = Pk.get(a);
        c || (b = c = b(), Qk.set(b, a), Pk.set(a, b));
        return c
    };
    P = function(a) {
        return function() {
            return new Sk(a, [].concat(_.lh(_.Xa.apply(0, arguments))))
        }
    };
    Tk = function(a) {
        return "[" + a.map(function(b) {
            return "string" === typeof b ? "'" + b + "'" : Array.isArray(b) ? Tk(b) : String(b)
        }).join(", ") + "]"
    };
    Uk = function(a, b) {
        b = Tk(b);
        b = b.substring(1, b.length - 1);
        return new Sk(96, [a, b])
    };
    Vk = function(a) {
        return (_.G = "rewardedSlotReady rewardedSlotGranted rewardedSlotClosed slotAdded slotRequested slotResponseReceived slotRenderEnded slotOnload slotVisibilityChanged impressionViewable gameManualInterstitialSlotReady gameManualInterstitialSlotClosed".split(" "), _.A(_.G, "includes")).call(_.G, a) ? a : null
    };
    Xk = function(a, b, c) {
        return Rk(c, function() {
            return new Wk(a, b, c)
        })
    };
    Zk = function(a, b, c) {
        return Rk(c, function() {
            return new Yk(a, b, c)
        })
    };
    $k = function(a, b, c, d) {
        "string" === typeof a ? b.setClickUrl(a) : Q(d, Uk("Slot.setClickUrl", [a]), c)
    };
    gl = function(a, b, c, d, e) {
        if ("string" !== typeof a || al(a)) Q(e, Uk("Slot.setTargeting", [a, b]), c);
        else {
            var f = [];
            Array.isArray(b) ? f = b : _.ta(b) ? f = _.A(Array, "from").call(Array, b) : b && (f = [b]);
            f = f.map(String);
            (b = (_.G = bl(d), _.A(_.G, "find")).call(_.G, function(g) {
                return _.Aj(g, 1) === a
            })) ? cl(b, f): (b = cl(dl(new el, a), f), Gj(d, 9, el, b));
            e.info(fl(a, f.join(), d.getAdUnitPath()), c)
        }
    };
    hl = function(a, b, c, d) {
        if (null != a && "object" === typeof a)
            for (var e = _.z(_.A(Object, "keys").call(Object, a)), f = e.next(); !f.done; f = e.next()) f = f.value, gl(f, a[f], b, c, d);
        else d.error(Uk("Slot.updateTargetingFromMap", [a]), b)
    };
    kl = function(a, b, c, d) {
        return "string" !== typeof a ? (Q(d, Uk("Slot.getTargeting", [a]), b), []) : (b = (_.G = bl(c), _.A(_.G, "find")).call(_.G, function(e) {
            return _.Aj(e, 1) === a
        })) ? _.jl(b, 2).slice() : []
    };
    ll = function(a) {
        return bl(a).map(function(b) {
            return _.R(b, 1)
        })
    };
    ql = function(a, b, c, d) {
        if (void 0 === a) _.Ai(c, 9), d.info(ml(b.getAdUnitPath()), b);
        else {
            var e = bl(c),
                f = _.A(e, "findIndex").call(e, function(g) {
                    return _.Aj(g, 1) === a
                });
            0 > f ? Q(d, nl(a, b.getAdUnitPath()), b) : (e.splice(f, 1), _.ol(c, 9, e), d.info(pl(a, b.getAdUnitPath()), b))
        }
    };
    sl = function(a, b, c) {
        return Rk(c, function() {
            return new rl(a, b, c, c.j)
        })
    };
    tl = function(a) {
        return _.A(Object, "assign").call(Object, {}, a, _.A(Object, "fromEntries").call(Object, _.A(Object, "entries").call(Object, a).map(function(b) {
            b = _.z(b);
            var c = b.next().value;
            return [b.next().value, c]
        })))
    };
    xl = function() {
        var a = {},
            b = tl(ul);
        a.OutOfPageFormat = b;
        b = tl(vl);
        a.TrafficSource = b;
        b = tl(wl);
        a.Taxonomy = b;
        return a
    };
    Bl = function(a, b, c, d, e) {
        if ("string" === typeof a && a.length && void 0 !== yl()[a] && "string" === typeof b) {
            var f = (_.G = c.Ma(), _.A(_.G, "find")).call(_.G, function(g) {
                return _.Aj(g, 1) === a
            });
            f ? cl(f, [b]) : (f = zl(dl(new el, a), b), Gj(c, 14, el, f));
            e.info(Al(a, String(b), d))
        } else Q(e, Uk("PubAdsService.set", [a, b]))
    };
    Cl = function(a, b, c) {
        return "string" !== typeof a ? (Q(c, Uk("PubAdsService.get", [a])), null) : (b = (b = (_.G = b.Ma(), _.A(_.G, "find")).call(_.G, function(d) {
            return _.Aj(d, 1) === a
        })) && _.jl(b, 2)) ? b[0] : null
    };
    Dl = function(a) {
        return a.Ma().map(function(b) {
            return _.R(b, 1)
        })
    };
    Fl = function() {
        for (var a = dg(El) || "0-0-0", b = a.split("-").map(function(e) {
                return Number(e)
            }), c = ["1", "0", "40"].map(function(e) {
                return Number(e)
            }), d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "1-0-40"
    };
    Jl = function() {
        if (Gl) return Gl;
        for (var a = eg(Hl), b = [], c = 0; c < a.length; c += 2) Il(a[c], a[c + 1], b);
        return Gl = b.join("&")
    };
    Ol = function(a, b) {
        if (!b || !_.ka(b)) return null;
        var c = !1,
            d = new Kl;
        _.Ll(b, function(e, f) {
            var g = !1;
            switch (f) {
                case "allowOverlayExpansion":
                    "boolean" === typeof e ? Fj(d, 1, b.allowOverlayExpansion) : c = g = !0;
                    break;
                case "allowPushExpansion":
                    "boolean" === typeof e ? Fj(d, 2, b.allowPushExpansion) : c = g = !0;
                    break;
                case "sandbox":
                    !0 === e ? Fj(d, 3, b.sandbox) : c = g = !0;
                    break;
                default:
                    g = !0
            }
            g && a.error(Ml("setSafeFrameConfig", Nl(b), f, Nl(e)))
        });
        return c ? null : d
    };
    Ql = function(a) {
        var b = new Kl;
        a = _.z(a);
        for (var c = a.next(); !c.done; c = a.next())
            if (c = c.value) null != Pl(c, 1) && Fj(b, 1, _.N(c, 1)), null != Pl(c, 2) && Fj(b, 2, _.N(c, 2)), null != Pl(c, 3) && Fj(b, 3, _.N(c, 3));
        return b
    };
    Rl = function(a, b) {
        var c = {};
        b = (c[0] = ag(b.pvsid), c);
        return _.Rf(Sf).o(a, b)
    };
    Wl = function(a, b) {
        var c;
        return null == (c = _.Sl(a, "__gads", b)) ? void 0 : _.A(c.split(":"), "find").call(c.split(":"), function(d) {
            return 0 === d.indexOf("ID=")
        })
    };
    Xl = function(a, b, c, d) {
        (c = Wl(c, d)) ? (d = {}, b = (d[0] = ag(b.pvsid), d[1] = ag(c), d), _.Rf(Sf).o(a, b)) : Rl(a, b)
    };
    am = function(a) {
        var b = a.key,
            c = a.value,
            d = a.Da,
            e = a.serviceName,
            f = a.Ql,
            g = a.ab,
            h = a.T;
        a = a.context;
        var k = null;
        "string" === typeof c ? k = [c] : Array.isArray(c) ? k = c : _.ta(c) && (k = _.A(Array, "from").call(Array, c));
        var l = "string" === typeof b && !al(b);
        k = k && xa(k);
        var m, n = null != (m = null == k ? void 0 : k.every(function(p) {
            return "string" === typeof p
        })) ? m : !1;
        if (l && n) {
            c = k;
            m = (_.G = _.bi(d, el, 2), _.A(_.G, "find")).call(_.G, function(p) {
                return _.Aj(p, 1) === b
            });
            if ("gpt-beta" === b) {
                if (f) {
                    Q(h, Yl(c.join()));
                    return
                }
                if (m) {
                    Q(h, Zl(c.join()));
                    return
                }
                c = $l(c, g, a)
            }
            m ? cl(m, c) : (f = cl(dl(new el, b), c), Gj(d, 2, el, f));
            h.info(fl(b, c.join(), e))
        } else Q(h, Uk("PubAdsService.setTargeting", [b, c]))
    };
    bm = function(a, b, c) {
        return "string" !== typeof a ? (Q(c, Uk("PubAdsService.getTargeting", [a])), []) : (b = (_.G = _.bi(b, el, 2), _.A(_.G, "find")).call(_.G, function(d) {
            return _.Aj(d, 1) === a
        })) ? _.jl(b, 2).slice() : []
    };
    cm = function(a) {
        return _.bi(a, el, 2).map(function(b) {
            return _.R(b, 1)
        })
    };
    gm = function(a, b, c, d) {
        if (void 0 === a) _.Ai(b, 2), d.info(dm(c));
        else if ("gpt-beta" === a) Q(d, em(a));
        else {
            var e = _.bi(b, el, 2),
                f = _.A(e, "findIndex").call(e, function(g) {
                    return _.Aj(g, 1) === a
                });
            0 > f ? Q(d, nl(a, c)) : (e.splice(f, 1), _.ol(b, 2, e), d.info(fm(a, c)))
        }
    };
    $l = function(a, b, c) {
        var d = [];
        a = _.z(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            b.j = e;
            var f = Rl(9, c);
            1 === f.length && (d.push(e), d.push(e + "-" + f[0]))
        }
        return d
    };
    im = function() {
        var a, b, c;
        return "pagead2.googlesyndication.com" === (null != (c = hm.exec(null != (b = null == (a = _.ki(172)) ? void 0 : a.src) ? b : "")) ? c : [])[1]
    };
    jm = function(a) {
        return a + 'Correlator has been deprecated. Please see the Google Ad Manager help page on "Pageviews in GPT" for more information: https://support.google.com/admanager/answer/183281?hl=en'
    };
    km = function(a, b) {
        var c = b.j;
        return a.map(function(d) {
            return _.A(c, "find").call(c, function(e) {
                return e.j === d
            })
        }).filter(zf())
    };
    mm = function() {
        Object.defineProperty(window, "google_DisableInitialLoad", {
            get: function() {
                lm();
                return !0
            },
            set: function() {
                lm()
            },
            configurable: !0
        })
    };
    pm = function(a, b, c, d, e, f) {
        var g = nm(f, a, b, d, e, void 0, !0);
        f = g.slotId;
        g = g.Da;
        if (!f || !g) return Q(b, Uk("PubAdsService.definePassback", [d, e])), null;
        Fj(g, 17, !0);
        c.slotAdded(f, g);
        return {
            ni: sl(a, b, new om(a, f, c)),
            Da: g
        }
    };
    rm = function(a, b, c, d, e) {
        return Rk(c, function() {
            return new qm(a, b, c, d, e)
        })
    };
    sm = function(a, b, c, d, e) {
        "string" !== typeof a || "string" !== typeof b || void 0 === yl()[a] ? Q(e, Uk("Slot.set", [a, b]), c) : (c = (_.G = d.Ma(), _.A(_.G, "find")).call(_.G, function(f) {
            return _.Aj(f, 1) === a
        })) ? cl(c, [b]) : (b = zl(dl(new el, a), b), Gj(d, 3, el, b))
    };
    tm = function(a, b, c, d) {
        return "string" !== typeof a ? (Q(d, Uk("Slot.get", [a]), b), null) : (b = (b = (_.G = c.Ma(), _.A(_.G, "find")).call(_.G, function(e) {
            return _.Aj(e, 1) === a
        })) && _.jl(b, 2)) ? b[0] : null
    };
    um = function(a) {
        return a.Ma().map(function(b) {
            return _.R(b, 1)
        })
    };
    wm = function(a) {
        return Array.isArray(a) && 2 === a.length ? a.every(vm) : "fluid" === a
    };
    xm = function(a) {
        return Array.isArray(a) && 2 === a.length && vm(a[0]) && vm(a[1])
    };
    zm = function(a) {
        if (Array.isArray(a)) {
            var b = new $h;
            b = _.Ai(b, 1, _.Oc(a[0]));
            a = _.Ai(b, 2, _.Oc(a[1]))
        } else a = ym();
        return a
    };
    Bm = function(a) {
        var b = [];
        if (Am(a)) b.push(zm(a));
        else if (Array.isArray(a)) {
            a = _.z(a);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, Am(c) ? b.push(zm(c)) : va(c, ["fluid"]) && b.push(ym())
        }
        return b
    };
    Cm = function(a) {
        var b = void 0 === b ? window : b;
        if (!a) return [];
        if (!a.length) {
            var c, d;
            null == (c = b.console) || null == (d = c.warn) || d.call(c, "Invalid GPT fixed size specification: " + JSON.stringify(a))
        }
        return Bm(a)
    };
    Am = function(a) {
        return _.H(Dm) ? Array.isArray(a) && 2 === a.length ? a.every(Em) : "fluid" === a : Array.isArray(a) && 1 < a.length ? "number" === typeof a[0] && "number" === typeof a[1] : "fluid" === a
    };
    Gm = function(a) {
        if (!Array.isArray(a) || 2 !== a.length) throw new Fm("Each mapping entry must be an array of size 2");
        var b = a[0];
        if (!xm(b)) throw new Fm("Size must be an array of two non-negative integers");
        var c = new $h;
        c = _.Ai(c, 1, _.Oc(b[0]));
        b = _.Ai(c, 2, _.Oc(b[1]));
        if (Array.isArray(a[1]) && 0 === a[1].length) a = [];
        else if (a = Bm(a[1]), 0 === a.length) throw new Fm("At least one slot size must be present");
        c = new di;
        b = _.th(c, 1, b);
        return _.ol(b, 2, a)
    };
    Hm = function() {
        var a;
        return null != (a = _.t.googletag) ? a : _.t.googletag = {
            cmd: []
        }
    };
    Lm = function(a, b) {
        _.H(Im) ? (_.Ai(a, 28), null !== b && Af(b) && _.A(Object, "hasOwn").call(Object, b, "enabled") && (b = b.enabled, Jm(b) && (b = Km(b), _.th(a, 28, b)))) : void 0 === b || null === b ? _.Ai(a, 28) : (b = b.enabled, Jm(b) ? (b = Km(b), _.th(a, 28, b)) : void 0 !== b && null !== b || _.Ai(a, 28))
    };
    Mm = function(a, b) {
        if (!b) return [];
        var c = [];
        b = _.z((_.G = ge(b, 26, ld), _.A(_.G, "values")).call(_.G));
        for (var d = b.next(); !d.done; d = b.next()) {
            d = d.value;
            try {
                c.push(JSON.parse(d))
            } catch (e) {
                Lh(a, 1023, e)
            }
        }
        return c
    };
    Om = function(a, b, c) {
        return Rk(c, function() {
            return new Nm(a, b, c)
        })
    };
    Wm = function(a, b, c, d, e, f, g) {
        var h = new Jj,
            k = new Pm(a, g);
        O(h, k);
        e = new Qm(a, d, e);
        O(h, e);
        e = new Rm(a, b, d, f, k.ib);
        O(h, e);
        g = new Sm(a, b, c, d, g, f, k.ib);
        O(h, g);
        if (_.H(Tm)) {
            b = new Um(a, b, c, d, f, k.ib);
            O(h, b);
            var l = b.l
        }
        a = new Vm(a, k.ib, g.l, e.l, l);
        O(h, a);
        Sj(h);
        return {
            ib: a.output,
            Ga: h
        }
    };
    Ym = function(a, b) {
        return Rk(b, function() {
            return new Xm(a, b)
        })
    };
    $m = function(a, b, c) {
        var d = Hh(a, 77, function() {
            var e = b.cmd;
            if (!e || Array.isArray(e)) {
                var f = new Zm(c);
                b.cmd = Ym(a, f);
                null != e && e.length && f.push.apply(f, e)
            }
        });
        b.fifWin && "complete" !== document.readyState ? _.jb(window, "load", function() {
            return window.setTimeout(d, 0)
        }) : d()
    };
    cn = function(a) {
        var b = window;
        "complete" === _.t.document.readyState ? Nh(a, 94, function() {
            Hm()._pubconsole_disable_ || null !== an(b) && bn(a, b)
        }) : _.jb(_.t, "load", Hh(a, 94, function() {
            Hm()._pubconsole_disable_ || null !== an(b) && bn(a, b)
        }))
    };
    bn = function(a, b) {
        b = void 0 === b ? _.t : b;
        if (!dn) {
            var c = new en("gpt_pubconsole_loaded");
            ej(c, a);
            fj(c, "param", String(an(b)));
            fj(c, "api", String(fn));
            gn(c);
            _.hn(b.document, jn);
            dn = !0
        }
    };
    an = function(a) {
        var b = mi(a),
            c;
        return null != (c = (_.G = ["google_debug", "dfpdeb", "google_console", "google_force_console", "googfc"], _.A(_.G, "find")).call(_.G, function(d) {
            return null !== kn(b, d)
        })) ? c : null
    };
    ln = function() {
        Hm()._pubconsole_disable_ = !0
    };
    on = function() {
        mn && (Hm().console.openConsole(nn), nn = void 0, mn = !1)
    };
    pn = function(a) {
        switch (Number(a)) {
            case 0:
                return "";
            case 1:
                return "Out-of-page creative";
            case 2:
            case 3:
                return "Anchor";
            case 5:
                return "Interstitial";
            case 6:
                return "Shoppit";
            case 7:
                return "Game Manual Interstitial";
            case 4:
                return "Rewarded";
            case 8:
            case 9:
                return "Side Rail";
            default:
                return ""
        }
    };
    qn = function(a, b) {
        b = void 0 === b ? null : b;
        var c = [];
        a && (c.push(_.Aj(a, 1)), c.push(hi(a)), c.push(_.Aj(a, 2)));
        if (b) {
            a = [];
            for (var d = 0; b && 25 > d; b = b.parentNode, ++d) 9 === b.nodeType ? a.push("") : a.push(b.id);
            (b = a.join()) && c.push(b)
        }
        return c.length ? _.$f(c.join(":")).toString() : "0"
    };
    rn = function(a) {
        if (!_.nk(a)) return -1;
        a = a.pageYOffset;
        return 0 > a ? -1 : a
    };
    vn = function(a, b, c, d, e) {
        if (_.H(sn)) {
            var f = void 0,
                g = Hh(a.context, b, e);
            _.jb(c, d, g) && (f = function() {
                return void _.uf(c, d, g)
            }, _.tn(a, f));
            return f
        }
        return null != (f = un(a, b, c, d, e)) ? f : void 0
    };
    xn = function(a) {
        a = (_.nk(a.top) ? a.top : a).AMP;
        return "object" === typeof a && !!wn(a, function(b, c) {
            return !/^inabox/i.test(c)
        })
    };
    Bn = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        var p = {
                Aa: new yn,
                La: new yn,
                fe: new yn,
                Nh: new yn
            },
            r = new Jj;
        b = new zn(a, b, c.width, k, l, n);
        O(r, b);
        a = new An(a, d, e, f, h, k, g, b.C, b.v, m, n, p.Aa, p.La, p.fe, p.Nh);
        O(r, a);
        Sj(r);
        return {
            Ga: r,
            Mg: p
        }
    };
    Fn = function(a, b, c, d, e, f, g, h, k, l, m) {
        var n = window,
            p = {
                Pd: new Cn
            },
            r = new Jj,
            w = new Dn(a, n, e);
        O(r, w);
        a = new En(a, n.document, c, d, b, g, e, f, h, k, w.output, l, m, p.Pd);
        O(r, a);
        Sj(r);
        return {
            Ga: r,
            Mg: p
        }
    };
    Gn = function(a, b, c, d) {
        var e = _.gf("DIV");
        e.id = b;
        e.name = b;
        b = e.style;
        b.border = "0pt none";
        c && (b.margin = "auto", b.textAlign = "center");
        d && (c = Array.isArray(d), b.width = c ? d[0] + "px" : "100%", b.height = c ? d[1] + "px" : "0%");
        a.appendChild(e);
        return e
    };
    Hn = function(a) {
        return "sticky" === (null == a ? void 0 : a.position) || "fixed" === (null == a ? void 0 : a.position)
    };
    Kn = function(a, b, c) {
        var d = new _.v.Map;
        a = _.z(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            var f = b[e.getDomId()];
            f = In(f, Jn, 28) ? _.Zh(f, Jn, 28) : _.Zh(c, Jn, 34);
            var g = void 0;
            d.set(e, (null == (g = f) ? 0 : null != Pl(g, 1)) ? _.N(f, 1) ? 2 : 1 : 0)
        }
        return d
    };
    Nn = function(a, b, c) {
        var d, e, f = [],
            g = [];
        a = _.z(a);
        for (d = a.next(); !d.done; d = a.next())
            if (d = d.value, 1 === b.get(d)) f.push(null), g.push(null);
            else {
                var h = c,
                    k = Fi(d);
                d = Ln((null == k ? void 0 : k.parentElement) && Hi(k.parentElement, h) || null);
                if (!d || 1 === d[0] && 1 === d[3]) {
                    var l = e = d = void 0,
                        m = null != (l = null == k ? void 0 : k.parentElement) ? l : null;
                    l = null != (e = yi(m)) ? e : new _.xi(0, 0);
                    Mn(l, m, h, 100);
                    e = null != (d = yi(k)) ? d : new _.xi(0, 0);
                    Mn(e, k, h, 1); - 1 === l.height && (e.height = -1);
                    d = l;
                    d = d.width + "x" + d.height;
                    e = e.width + "x" + e.height
                } else e = d = "-1x-1";
                f.push(d);
                g.push(e)
            }
        return {
            dl: f,
            Ul: g
        }
    };
    Mn = function(a, b, c, d) {
        try {
            var e;
            if (!(e = !b)) {
                var f;
                if (!(f = !On(b, c, d))) {
                    a: {
                        do {
                            var g = Hi(b, c);
                            if (g && "fixed" == g.position) {
                                var h = !1;
                                break a
                            }
                        } while (b = b.parentElement);h = !0
                    }
                    f = !h
                }
                e = f
            }
            e && (a.height = -1)
        } catch (k) {
            a.width = -1, a.height = -1
        }
    };
    Qn = function(a, b, c) {
        var d = 0 !== (0, _.Pn)(),
            e = fi(!0, c, d).width,
            f = [],
            g = [],
            h = [];
        if (null !== c && c != c.top) {
            var k = fi(!1, c).width;
            (-12245933 === e || -12245933 === k || k < e) && h.push(8)
        } - 12245933 !== e && (1.5 * e < c.document.documentElement.scrollWidth ? h.push(10) : d && 1.5 * c.outerWidth < e && h.push(10));
        a = _.z(a);
        for (d = a.next(); !d.done; d = a.next())
            if (k = d.value, 1 === b.get(k)) f.push(null), g.push(null);
            else {
                d = new $i;
                var l = Fi(k);
                k = 0;
                var m = !1,
                    n = !1,
                    p = !1;
                if (l) {
                    for (var r = 0, w = l; w && 100 > r; r++, w = w.parentElement) {
                        var u = Hi(w, c);
                        if (u) {
                            var x = u,
                                y = x.display,
                                C = x.overflowX;
                            if ("visible" !== x.overflowY && (d.set(2), (x = yi(w)) && (k = k ? Math.min(k, x.width) : x.width), d.get(9))) break;
                            Hn(u) && d.set(9);
                            "none" === y && d.set(7);
                            "IFRAME" === w.nodeName && (u = parseInt(u.width, 10), u < e && (d.set(8), k = k ? Math.min(u, k) : u));
                            n || (n = "scroll" === C || "auto" === C);
                            m || (m = "flex" === y);
                            p || (p = "listbox" === w.role)
                        } else d.set(3)
                    }
                    if (!p) {
                        if (m = n && m) l = l.getBoundingClientRect().left, m = l > e || 0 > l;
                        p = m
                    }
                    p && d.set(11)
                } else d.set(1);
                l = _.z(h);
                for (m = l.next(); !m.done; m = l.next()) d.set(m.value);
                f.push(bj(d));
                g.push(k)
            }
        return {
            qk: f,
            cl: g
        }
    };
    Wn = function(a, b, c, d, e) {
        if (null != b && b.size) {
            var f, g;
            e = null != (g = null != (f = null == e ? void 0 : e.adUnits) ? f : null == a ? void 0 : a.adUnits) ? g : [];
            a = _.z(e);
            g = a.next();
            for (f = {}; !g.done; f = {
                    cf: f.cf
                }, g = a.next()) {
                e = g.value;
                g = e.code;
                e = e.bids;
                var h = void 0;
                if (g && null != (h = e) && h.length && (g = tg(g, b), f.cf = g / 1E6, !(0 >= g))) {
                    h = void 0;
                    e = _.z(null != (h = e) ? h : []);
                    var k = e.next();
                    for (h = {}; !k.done; h = {
                            Db: h.Db,
                            Yf: h.Yf
                        }, k = e.next()) k = k.value, h.Yf = "function" === typeof k.getFloor ? k.getFloor : void 0, h.Db = Rn(Sn(Tn(new Un, 4), g), c), k.getFloor = function(l, m) {
                        return function(n) {
                            4 === _.Hk(l.Db, 1, 0) && Tn(l.Db, 1);
                            var p, r = null == (p = l.Yf) ? void 0 : p.apply(this, [n]);
                            n = c ? r || {} : {
                                currency: "USD",
                                floor: m.cf
                            };
                            return null != r && r.floor ? (null == r ? 0 : r.currency) && "USD" !== r.currency ? (1 === _.Hk(l.Db, 1, 0) && (n = Sn(Tn(l.Db, 6), 1E6 * r.floor), Vn(n, 3, r.currency)), r) : (r.floor || 0) > m.cf ? (1 === _.Hk(l.Db, 1, 0) && Sn(Tn(l.Db, 5), 1E6 * r.floor), r) : n : n
                        }
                    }(h, f), d.set(k.getFloor, h.Db)
                }
            }
        }
    };
    Xn = function(a, b) {
        var c = a.que,
            d = function() {
                var e;
                null == a || null == (e = a.requestBids) || e.before.call(b, function(f, g) {
                    return Hm().pbjs_hooks.push({
                        context: b,
                        nextFunction: f,
                        requestBidsConfig: g
                    })
                }, 0)
            };
        (null == c ? 0 : c.hasOwnProperty("push")) ? null == c || c.push(d): null == c || c.unshift(d)
    };
    Zn = function(a, b) {
        return Rk(b, function() {
            return new Yn(a, b)
        })
    };
    io = function(a, b, c, d, e) {
        var f = e.getBidResponsesForAdUnitCode;
        if (f) {
            var g, h, k, l = null != (k = null == (g = f(b.getDomId())) ? void 0 : g.bids) ? k : null == (h = f(b.getAdUnitPath())) ? void 0 : h.bids;
            if (null != l && l.length && (g = l.filter(function(p) {
                    var r = p.adId;
                    return p.auctionId !== c && d.some(function(w) {
                        return (_.G = _.jl(w, 2), _.A(_.G, "includes")).call(_.G, r)
                    })
                }), g.length)) {
                var m, n;
                f = null == (m = e.adUnits) ? void 0 : null == (n = _.A(m, "find").call(m, function(p) {
                    p = p.code;
                    return p === b.getAdUnitPath() || p === b.getDomId()
                })) ? void 0 : n.mediaTypes;
                m = _.z(g);
                for (n = m.next(); !n.done; n = m.next()) n = n.value, g = $n(n, d, f), g = ao(a, bo(Fj(co(eo(new fo, n.bidder), 1), 6, !0), g)), go(n.bidder, e, g), "number" === typeof n.timeToRespond && ho(g, n.timeToRespond)
            }
        }
    };
    go = function(a, b, c) {
        for (var d = []; a && !_.A(d, "includes").call(d, a);) {
            d.unshift(a);
            var e = void 0,
                f = void 0;
            a = null == (e = b) ? void 0 : null == (f = e.aliasRegistry) ? void 0 : f[a]
        }
        _.Uh(c, 10, d)
    };
    lo = function(a, b, c) {
        null != jo(a, 3) || (c === b.getAdUnitPath() ? _.ko(a, 3, 1) : c === b.getDomId() && _.ko(a, 3, 2))
    };
    oo = function(a, b, c, d, e, f, g) {
        f = f.get(null != g ? g : function() {
            return null
        });
        1 !== (null == f ? void 0 : _.Hk(f, 1, 0)) && _.th(b, 5, f);
        In(a, Un, 5) || (f ? 1 === _.Hk(f, 1, 0) ? mo(a, f) : mo(a, Sn(Tn(Rn(new Un, e), 1), tg(c, d, _.H(no)))) : mo(a, Tn(Rn(new Un, e), tg(c, d, _.H(no)) ? 2 : 3)))
    };
    $n = function(a, b, c) {
        var d = a.cpm,
            e = a.originalCpm,
            f = a.currency,
            g = a.originalCurrency,
            h = a.dealId,
            k = a.adserverTargeting,
            l = a.bidder,
            m = a.adUnitCode,
            n = a.adId,
            p = a.mediaType,
            r = a.height;
        a = a.width;
        var w = new po;
        "number" === typeof d && (_.xk(w, 2, Math.round(1E6 * d)), g && g !== f || (d = Math.round(1E6 * Number(e)), isNaN(d) || d === _.sf(w, 2) || _.xk(w, 8, d)));
        "string" === typeof f && Vn(w, 3, f);
        (_.G = ["string", "number"], _.A(_.G, "includes")).call(_.G, typeof h) && qo(w, ro(new so, String(h)));
        if ("object" === typeof k)
            for (b = _.A(Object, "fromEntries").call(Object, b.map(function(y) {
                    return [_.Aj(y, 1), _.jl(y, 2)]
                })), f = _.z(["", "_" + l]), h = f.next(); !h.done; h = f.next()) {
                h = h.value;
                d = [];
                e = _.z(_.A(Object, "entries").call(Object, k));
                for (g = e.next(); !g.done; g = e.next()) {
                    g = _.z(g.value);
                    var u = g.next().value;
                    g = g.next().value;
                    u = (u + h).slice(0, 20);
                    var x = void 0;
                    if (null != (x = b[u]) && x.length)
                        if (b[u][0] === String(g)) d.push(u);
                        else {
                            d = [];
                            break
                        }
                }
                to(w, _.jl(w, 4).concat(d))
            }
        switch (p || "banner") {
            case "banner":
                _.ko(w, 5, 1);
                break;
            case "native":
                _.ko(w, 5, 2);
                Zi("hbyg_nat", function(y) {
                    fj(y, "pub_url", document.URL);
                    fj(y, "b", l);
                    fj(y, "auc", null != m ? m : "");
                    fj(y, "hmt", Number(!!c));
                    var C;
                    fj(y, "hat", Number(!!(null == c ? 0 : null == (C = c.native) ? 0 : C.adTemplate)))
                }, _.cg(uo));
                break;
            case "video":
                _.ko(w, 5, 3)
        }
        _.A(Number, "isFinite").call(Number, r) && _.A(Number, "isFinite").call(Number, a) && vo(w, wo(xo(new yo, Math.round(a)), Math.round(r)));
        "string" === typeof n && Vn(w, 1, n);
        return w
    };
    zo = function(a, b) {
        var c = new _.v.Map,
            d = function(k) {
                var l = c.get(k);
                l || (l = {}, c.set(k, l));
                return l
            },
            e = [];
        a = _.z(a);
        for (var f = a.next(); !f.done; f = a.next()) {
            f = f.value;
            var g = f.args,
                h = f.eventType;
            f = f.elapsedTime;
            "bidTimeout" === h && e.push.apply(e, _.lh(g));
            switch (h) {
                case "bidRequested":
                    if (g.auctionId !== b) continue;
                    if (!Array.isArray(g.bids)) continue;
                    g = _.z(g.bids);
                    for (h = g.next(); !h.done; h = g.next())
                        if (h = h.value.bidId) d(h).requestTime = f;
                    break;
                case "noBid":
                    g.auctionId === b && g.bidId && (d(g.bidId).El = f)
            }
        }
        d = new _.v.Map;
        a = _.z(_.A(c, "entries").call(c));
        for (f = a.next(); !f.done; f = a.next()) g = _.z(f.value), f = g.next().value, h = g.next().value, g = h.requestTime, h = h.El, g && h && d.set(f, {
            latency: h - g,
            Rh: !1
        });
        e = _.z(e);
        for (a = e.next(); !a.done; a = e.next())
            if (f = a.value, a = f.bidId, f = f.auctionId, a && f === b && (a = d.get(a))) a.Rh = !0;
        return d
    };
    Ao = function(a, b) {
        for (var c = new $i, d = 0; d < a.length; d++) c.set(a.length - d - 1, b(a[d]));
        return bj(c)
    };
    Do = function(a, b, c) {
        c = void 0 === c ? {} : c;
        var d = void 0 === c.rd ? "" : c.rd;
        c = void 0 === c.Ba ? "," : c.Ba;
        if (_.H(Bo)) return Co(a, b);
        var e = !1;
        a = a.map(function(f) {
            f = b(f);
            e || (e = !!f);
            return String(f || d)
        });
        return e ? a.join(c) : null
    };
    Co = function(a, b) {
        return a.map(function(c) {
            return b(c)
        })
    };
    Fo = function(a, b, c, d, e, f, g) {
        if (f) {
            var h = {
                    Kg: new yn
                },
                k = new Jj;
            a = new Eo(a, b, c, d, e, f, g, h);
            O(k, a);
            Sj(k);
            return {
                vj: h,
                Ga: k
            }
        }
    };
    Ho = function(a, b, c, d, e) {
        if (b && !(.01 < Math.random())) {
            var f = new Jj;
            O(f, new Go(a, c, b.Rb, d, e));
            Sj(f)
        }
    };
    Jo = function(a, b) {
        var c;
        return !(null != (c = Io(b, 22)) ? !c : !_.N(a, 15))
    };
    Lo = function(a) {
        var b;
        var c = new Ko;
        c = _.qh(c, 2, a.pvsid);
        c = _.rh(c, 3, a.eb);
        c = _.rh(c, 6, a.Lf);
        var d = null != (b = a.Dn) ? b : _.Vg();
        b = _.qh(c, 1, d);
        c = _.Uf();
        b = _.ie(b, 4, c, Lc);
        a.payload && (c = a.payload(), _.th(b, 7, c));
        a.ff && _.qh(b, 5, a.ff);
        return b
    };
    No = function(a, b, c, d) {
        for (var e = _.z(_.A(Object, "entries").call(Object, Mo)), f = e.next(); !f.done; f = e.next()) {
            var g = _.z(f.value);
            f = g.next().value;
            g = g.next().value;
            b & f && Q(a, g(String(c), d))
        }
    };
    To = function(a, b, c) {
        a.Ll && a.Qa.Hi(Lo(_.A(Object, "assign").call(Object, {}, a, {
            ff: a.bl,
            payload: function() {
                var d = new Oo;
                var e = d.D;
                var f = Kd(e),
                    g = ke(e, f, Po),
                    h = Qo(d, Ro, 1);
                g && 1 !== g && Rd(e, f, g);
                e = _.So(h, 1, b);
                _.So(e, 2, c);
                return d
            }
        })))
    };
    Yo = function(a, b, c) {
        c = void 0 === c ? null : c;
        b = (void 0 === b ? 0 : b) ? 604800 : -1;
        if (!(0 < b) || c && Lf(c)) {
            c = c ? Mf(c) : null;
            var d = !1,
                e = _.H(_.Uo);
            d = void 0 === d ? !1 : d;
            e = void 0 === e ? !1 : e;
            var f = 0;
            try {
                f |= a !== a.top ? 512 : 0;
                var g;
                if (!(g = !a.navigator)) {
                    var h = a.navigator;
                    g = "brave" in h && "isBrave" in h.brave || !1
                }
                f |= g || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
                f |= Bg(a, 2500, e);
                e || (f |= Eg(a));
                0 < b && (d ? c && Vo(c) || (f |= 4194304) : !_.Wo(_.Xo(c, b)) && (f |= 134217728))
            } catch (k) {
                f |= 32
            }
            a = f
        } else a = 4194304;
        return a
    };
    Zo = function(a) {
        switch (a) {
            case 4:
                return 11;
            case 2:
                return 2;
            case 3:
                return 1;
            case 5:
                return 8;
            case 6:
                return 42;
            case 7:
                return 10;
            case 8:
                return 3;
            case 9:
                return 4
        }
    };
    bp = function(a, b, c) {
        a = Zo(a);
        if (!a) return null;
        if (10 === a) return 0;
        var d = 0;
        if (!(_.G = [11, 10], _.A(_.G, "includes")).call(_.G, a)) {
            d |= b !== b.top ? 512 : 0;
            var e = _.jh(b);
            e = 26 !== a && 27 !== a && 40 !== a && 41 !== a && 10 !== a && e.adCount ? 1 == a || 2 == a ? !(!e.adCount[1] && !e.adCount[2]) : (e = e.adCount[a]) ? 1 <= e : !1 : !1;
            e && (d |= 64);
            if (d) return d
        }
        if (2 === a || 1 === a) {
            var f = {
                ka: b,
                Le: _.$o,
                bh: c ? a : void 0,
                mm: _.H(_.ap)
            };
            0 === (0, _.Pn)() && (f.Le = 3E3, f.mg = 650);
            d |= _.Rg(f)
        } else if (8 === a) d |= Yo(b);
        else if (3 === a || 4 === a) {
            e = a;
            e = void 0 === e ? null : e;
            c = b !== b.top ? 512 : 0;
            Mg(null == (f = b.navigator) ? void 0 : f.userAgent) && (c |= 1048576);
            f = b.innerWidth;
            1200 > f && (c |= 65536);
            var g = b.innerHeight;
            650 > g && (c |= 2097152);
            e && 0 === c && (e = 3 === e ? "left" : "right", (f = _.mh({
                ka: b,
                Qh: !0,
                Gi: 1,
                position: e,
                ha: f,
                na: g,
                hc: new _.v.Set,
                minWidth: 120,
                minHeight: 500
            })) ? _.jh(b).sideRailPlasParam.set(e, f.width + "x" + f.height + "_" + String(e).charAt(0)) : c |= 16);
            d |= c
        } else 11 !== a && 42 !== a && (d |= 32);
        d || (b = _.jh(b), b.adCount = b.adCount || {}, b.adCount[a] = b.adCount[a] + 1 || 1);
        return d
    };
    ep = function(a, b, c, d) {
        var e = d.uh,
            f = d.adUnitPath;
        d = void 0 === d.qb ? !1 : d.qb;
        return "string" === typeof f && f.length && (null == e || "string" === typeof e || "number" === typeof e && cp(e)) ? dp(a, b, f, c, {
            Kb: "string" === typeof e ? e : void 0,
            format: "number" === typeof e ? e : 1,
            qb: d
        }) : (b.error(Uk("googletag.defineOutOfPageSlot", [f, e])), null)
    };
    cp = function(a) {
        switch (a) {
            case 6:
                return !0;
            case 7:
                return !0;
            default:
                return !!wn(ul, function(b) {
                    return b === a
                })
        }
    };
    dp = function(a, b, c, d, e) {
        var f = e.format;
        b = d.add(a, b, c, [1, 1], {
            Kb: e.Kb,
            format: f,
            qb: e.qb
        });
        a = b.slotId;
        b = b.Da;
        a && b && (_.ko(b, 15, f), _.tn(a, function() {
            var g = window,
                h = Zo(f);
            if (h) {
                g = _.jh(g);
                var k = g.adCount && g.adCount[h];
                k && (g.adCount[h] = k - 1)
            }
        }));
        return null != a ? a : null
    };
    gp = function(a, b, c, d, e, f, g, h) {
        var k = new Jj;
        a = new fp(a, b, c, d, e, f, g, h);
        O(k, a);
        Sj(k);
        return k
    };
    hp = function(a, b) {
        var c;
        return !(null != (c = Io(a, 11)) ? !c : !_.N(b, 10))
    };
    ip = function(a, b, c, d) {
        if (a = Fi(a, b)) {
            var e;
            if (c = null != (e = Io(c, 24)) ? e : _.N(d, 30)) c = a.getBoundingClientRect(), d = c.top, e = c.bottom, 0 === c.height ? c = !1 : (c = _.t.innerHeight, c = 0 < e && e < c || 0 < d && d < c);
            c || (a.style.display = "none")
        }
    };
    lp = function(a, b) {
        var c = b.L,
            d = b.P;
        b = b.V;
        a = _.z(a.X);
        for (var e = a.next(); !e.done; e = a.next())
            if (e = e.value, _.jp(c, e)) {
                var f = d,
                    g = f.W;
                f = f.R[e.getDomId()];
                hp(f, g) && ip(e, b, f, g);
                kp(c, e);
                var h = void 0,
                    k = void 0;
                null != (h = null != (k = Io(f, 10)) ? k : _.N(g, 11)) && h && ip(e, b, f, g)
            }
        return {}
    };
    mp = function(a, b, c, d) {
        Q(a, Ml("googletag.setConfig.commerce", Nl(b), c, Nl(d)))
    };
    np = function(a) {
        return "string" === typeof a && 0 < a.length && 5E3 > a.length
    };
    op = function(a) {
        if (!Array.isArray(a) || 0 === a.length) return !1;
        var b = a.length - 1;
        return a.every(function(c) {
            if ("string" !== typeof c || 0 === c.length) return !1;
            b += c.length;
            return 5E3 < b ? !1 : !0
        })
    };
    qp = function(a, b, c) {
        var d = new Jj;
        a = new pp(a, b, c);
        O(d, a);
        Sj(d)
    };
    sp = function(a, b) {
        var c, d, e, f, g;
        return _.lb(function(h) {
            c = a;
            d = c.rc;
            e = b;
            f = e.Ic;
            return (null != (g = d) ? g : f.rc()) ? h.return(rp(f)) : h.return(null)
        })
    };
    yp = function(a, b, c) {
        var d = window,
            e = new Jj;
        d = new tp(d);
        _.S(e, d);
        c = new up(a, d, c, _.ki(150));
        O(e, c);
        _.H(vp) ? (a = new wp(879, sp, {
            rc: b ? c.tc : void 0
        }, {
            Ic: d,
            Jn: !!b
        }, void 0, e.v.j), a = O(e, a).output) : (a = new xp(a, d, b, c.tc), a = O(e, a).l);
        Sj(e);
        return {
            tc: c.tc,
            Dh: a,
            Ga: e
        }
    };
    zp = function(a) {
        if (61440 >= a.length) return {
            url: a,
            ah: 0
        };
        var b = a;
        61440 < b.length && (b = b.substring(0, 61432), b = b.replace(/%\w?$/, ""), b = b.replace(/&[^=]*=?$/, ""), b += "&trunc=1");
        return {
            url: b,
            ah: a.length - b.length + 8
        }
    };
    Ap = function(a, b) {
        b = void 0 === b ? window : b;
        return b.location ? b.URLSearchParams ? (a = (new URLSearchParams(b.location.search)).get(a), (null == a ? 0 : a.length) ? a : null) : (a = (new RegExp("[?&]" + a + "=([^&]*)")).exec(b.location.search)) ? decodeURIComponent(a[1]) : null : null
    };
    Bp = function(a, b) {
        b = void 0 === b ? window : b;
        return !!Ap(a, b)
    };
    Ep = function(a, b) {
        var c = "";
        if (a) c = "_fy2012";
        else {
            if (a = b && 2012 < b) a = !_.Cp("script[nonce]");
            if (a) {
                var d = new _.Xe(Dp[0], Ye);
                try {
                    var e = window,
                        f = _.fb(d);
                    e.eval(f) === f && e.eval(f.toString());
                    a = !0
                } catch (g) {
                    a = !1
                }
            }
            a && (c = "_fy" + b)
        }
        return c
    };
    Fp = function(a) {
        var b, c;
        return null != (c = null == (b = _.A(a, "find").call(a, function(d) {
            return "page_url" === _.Aj(d, 1)
        })) ? void 0 : _.jl(b, 2)[0]) ? c : null
    };
    Gp = function(a) {
        var b = a.indexOf("google_preview=", a.lastIndexOf("?")),
            c = a.indexOf("&", b); - 1 === c && (c = a.length - 1, --b);
        return a.substring(0, b) + a.substring(c + 1, a.length)
    };
    Hp = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        Lk(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    Ip = function(a, b) {
        var c = b.R;
        return !!Fp(b.W.Ma()) || a.some(function(d) {
            return null !== Fp(c[d.getDomId()].Ma())
        })
    };
    Kp = function() {
        var a = void 0 === a ? window : a;
        Jp = _.Vg(a)
    };
    Lp = function(a, b) {
        var c = _.gf("DIV");
        c.id = a;
        c.textContent = b;
        _.Si(c, {
            height: "24px",
            "line-height": "24px",
            "text-align": "center",
            "vertical-align": "middle",
            color: "white",
            "background-color": "black",
            margin: "0",
            "font-family": "Roboto",
            "font-style": "normal",
            "font-weight": "500",
            "font-size": "11px",
            "letter-spacing": "0.08em"
        });
        return c
    };
    Mp = function(a, b) {
        if ("undefined" !== typeof IntersectionObserver) return new IntersectionObserver(b, {
            rootMargin: a + "%"
        })
    };
    Qp = function(a, b, c, d, e) {
        var f = void 0 === f ? _.v.globalThis.IntersectionObserver : f;
        if (!b) return {
            gg: e
        };
        var g = null != Np(b, 1) ? null != Op(b) && 0 !== (0, _.Pn)() ? Np(b, 1) * Op(b) : Np(b, 1) : null;
        if (null == g) return {
            gg: e
        };
        b = new Jj;
        a = new Pp(a, d, c, g, e, f);
        O(b, a);
        Sj(b);
        return {
            gg: a.output,
            Sk: b
        }
    };
    $p = function(a, b, c, d, e) {
        var f = window,
            g = new Jj,
            h = O(g, new Rp(a, b, Sp, function(m) {
                return Tp("i-adframe-load", m.detail.data)
            })),
            k = O(g, new Rp(a, b, Sp, function(m) {
                return Tp("i-dismiss", m.detail.data)
            }));
        h = 0 < _.cg(Up) ? O(g, new Vp(a, h.output, void 0)).output : h.output;
        h = O(g, new Wp(a, b, c, h));
        O(g, new Xp(a, f, d, e, h.output));
        if (f.top === f) var l = O(g, new Yp(a, f, h.output)).output;
        O(g, new Zp(a, b, c, h.output, k.output, l));
        return g
    };
    Tp = function(a, b) {
        try {
            var c = JSON.parse(b);
            return "sth" === c.googMsgType && c.msg_type === a
        } catch (d) {}
        return !1
    };
    cq = function(a, b, c) {
        return new aq(c, a, Sp, function(d) {
            d = d.detail.data;
            try {
                var e = JSON.parse(d);
                if ("rewarded" === e.type && e.message === b) return e
            } catch (f) {}
            return null
        })
    };
    fq = function(a, b, c) {
        if ("object" === typeof a && null !== a && _.A(Object, "keys").call(Object, a).some(function(d) {
                return (_.G = _.A(Object, "values").call(Object, dq), _.A(_.G, "includes")).call(_.G, Number(d))
            })) return !0;
        eq("taxonomies", a, b, c);
        return !1
    };
    nq = function(a, b, c, d) {
        if (gq(_.A(b, "values"), d, b)) {
            var e = hq(a, _.A(b, "values"), d, b);
            e.size && (b = (_.G = _.bi(c, iq, 1), _.A(_.G, "find")).call(_.G, function(f) {
                return _.Hk(f, 1, 0) === a
            }), e = [].concat(_.lh(e)), b ? jq(b, e) : kq(c, jq(lq(new iq, a), e)), d.info(mq(Nl(e), Nl(a))))
        }
    };
    gq = function(a, b, c) {
        if (Array.isArray(a)) return !0;
        eq("taxonomyData.values", a, b, c);
        return !1
    };
    hq = function(a, b, c, d) {
        if (!Ff()(b)) return eq("taxonomyData.values", b, c, d), new _.v.Set;
        d = new _.v.Set;
        var e = !1;
        b = _.z(b);
        for (var f = b.next(); !f.done; f = b.next()) {
            f = f.value;
            if (10 <= d.size) {
                e = !0;
                break
            }
            d.add(f)
        }
        e && Q(c, oq(Nl(a), Nl(10)));
        return d
    };
    eq = function(a, b, c, d) {
        Q(c, Ml("googletag.setConfig.pps", Nl(d), a, Nl(b)))
    };
    qq = function(a) {
        return pq.has(a)
    };
    tq = function(a, b) {
        if (3 === _.rq(b)) {
            var c = {
                    Kd: new Cn
                },
                d = new Jj;
            O(d, new sq(a, b, c.Kd));
            Sj(d);
            return {
                Ga: d,
                ol: c
            }
        }
    };
    vq = function(a, b, c, d, e, f) {
        if (b) {
            var g = {
                    zg: new yn
                },
                h = new Jj;
            O(h, new uq(a, b, c, g, d, e, f));
            Sj(h);
            return {
                Ga: h,
                df: g
            }
        }
    };
    wq = function(a) {
        var b = function() {
            return a.Reflect.construct(a.HTMLElement, [], this.constructor)
        };
        b.prototype = a.HTMLElement.prototype;
        b.prototype.constructor = b;
        _.A(Object, "setPrototypeOf").call(Object, b, a.HTMLElement);
        return b
    };
    yq = function(a, b) {
        var c = _.cg(xq);
        Math.random() <= c && vj(b, a)
    };
    Eq = function(a, b, c) {
        var d = {};
        if (!c) return b.error(zq("missing data-rendering attribute")), d;
        try {
            var e = Aq(Bq(c))
        } catch (k) {}
        var f;
        (null == (f = e) ? 0 : In(f, Cq, 1)) ? (b = _.I(new Dq, 4, 1), b = _.I(b, 2, 7), a = _.rh(b, 3, a.xb || a.eb), b = _.Zh(e, Cq, 1), a = _.th(a, 5, b), a = _.xh(a, 6, !0), d.Vl = a) : b.error(zq("invalid data-rendering attribute"));
        var g;
        d.Cl = null == (g = e) ? void 0 : _.R(g, 2);
        var h;
        d.Af = null == (h = e) ? void 0 : _.R(h, 3);
        return d
    };
    Hq = function(a, b) {
        var c = kn(b, "ai");
        if (!c || 0 === c.length) return _.v.Promise.resolve(b);
        var d = Fq();
        if (null == d ? 0 : d.gmaSdk) {
            if (c = d.gmaSdk.getClickSignalsWithTimeout ? d.gmaSdk.getClickSignalsWithTimeout(c, 200) : d.gmaSdk.getClickSignals(c)) return _.v.Promise.resolve(b.replace("?", "?ms=" + encodeURIComponent(c) + "&"))
        } else {
            var e, f;
            if (null == d ? 0 : null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaClickSignals) {
                e = new _.lg;
                var g = e.resolve;
                e = e.promise;
                Gq(d.webkit.messageHandlers.getGmaClickSignals, {
                    click_string: c
                }, function(h) {
                    g(b.replace("?", "?" + h + "&"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return Hh(a, h, k)
                });
                return e
            }
        }
        return _.v.Promise.resolve(b)
    };
    Jq = function(a, b, c, d) {
        var e, f, g;
        return _.lb(function(h) {
            e = b.getBoundingClientRect();
            f = {};
            g = d.replace("?", _.Iq("", (f.nx = Math.floor(c.clientX - e.x), f.ny = Math.floor(c.clientY - e.y), f.dim = Math.floor(e.width) + "x" + Math.floor(e.height), f)) + "&");
            return h.return(Hq(a, g))
        })
    };
    Kq = function(a, b, c) {
        var d;
        if (null == c ? 0 : null == (d = c.gmaSdk) ? 0 : d.getViewSignals) {
            if (c = c.gmaSdk.getViewSignals()) return c = b.replace(/^(.*?)(&adurl=)?$/, "$1&ms=" + c + "$2"), _.v.Promise.resolve(c)
        } else {
            var e, f;
            if (null == c ? 0 : null == (e = c.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals) {
                d = new _.lg;
                var g = d.resolve;
                d = d.promise;
                Gq(c.webkit.messageHandlers.getGmaViewSignals, {}, function(h) {
                    g(b.replace(/^(.*?)(&adurl=)?$/, "$1&" + h + "$2"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return Hh(a, h, k)
                });
                return d
            }
        }
        return _.v.Promise.resolve(b)
    };
    Pq = function(a, b) {
        var c = window;
        var d = void 0 === d ? rb : d;
        var e;
        if (c.customElements && null != (e = c.Reflect) && e.construct && !c.customElements.get("google-product-ad")) {
            var f = Fq(),
                g;
            null == (g = f ? new Lq(function(k, l) {
                return Hh(a, k, l)
            }, function() {}) : void 0) || g.oa();
            var h = wq(c);
            e = function() {
                return h.apply(this, arguments) || this
            };
            _.T(e, h);
            e.prototype.connectedCallback = function() {
                var k = Eq(a, b, this.dataset.rendering),
                    l = k.Vl,
                    m = k.Cl;
                k = k.Af;
                l && d(Mq(window, l));
                m && Kq(a, m, f).then(function(n) {
                    return void Nq(n)
                });
                k && ("true" === this.getAttribute("data-enable-click") || this.querySelector('[data-enable-click="true"]') ? (this.Af = k, this.addEventListener("click", this.j)) : Q(b, Oq(k)))
            };
            e.prototype.j = function(k) {
                var l = k.target instanceof c.HTMLElement ? k.target.closest("[data-enable-click]") : void 0;
                l instanceof c.HTMLElement && "true" === l.getAttribute("data-enable-click") && Jq(a, this, k, this.Af).then(function(m) {
                    return void Nq(m)
                })
            };
            c.customElements.define("google-product-ad", e)
        }
    };
    Rq = function(a) {
        Qq = a
    };
    Tq = function(a, b, c, d) {
        Zj(b, d, function(e, f) {
            Lh(a, e, f);
            var g, h;
            null == (h = (g = window.console).error) || h.call(g, f)
        }, function() {
            return void Q(c, Sq())
        })
    };
    Wq = function(a, b, c, d, e, f) {
        var g = window,
            h = new Jj;
        b = 8 === b ? 3 : 4;
        c = new Uq(a, c);
        O(h, c);
        O(h, new Vq(a, g, b, c.output, d, e, f));
        Sj(h);
        return h
    };
    ra = function(a, b) {
        a: {
            b = b[0];a = a[0];
            for (var c = _.oa, d = Math.min(b.length, a.length), e = 0; e < d; e++) {
                var f = c(b[e], a[e]);
                if (0 != f) {
                    b = f;
                    break a
                }
            }
            b = _.oa(b.length, a.length)
        }
        return b
    };
    Xq = function(a) {
        return Array.isArray(a) && 2 === a.length && "number" === typeof a[0] && _.A(a, "includes").call(a, 0)
    };
    Yq = function(a) {
        if (Xq(a)) return {
            size: [],
            Dg: !0
        };
        if (Array.isArray(a) && 0 < a.length && "number" !== typeof a[0]) {
            var b = !1;
            a = a.filter(function(c) {
                c = Xq(c);
                b = b || c;
                return !c
            });
            return {
                size: a,
                Dg: b
            }
        }
        return {
            size: a,
            Dg: !1
        }
    };
    $q = function(a, b) {
        var c = b.R;
        return Do(a, function(d) {
            return Zq(c[d.getDomId()]).join("&")
        }, {
            Ba: "|"
        })
    };
    Zq = function(a) {
        a = ar(a);
        var b = [];
        _.Ll(a, function(c, d) {
            c.length && (c = c.map(encodeURIComponent), d = encodeURIComponent(d), b.push(d + "=" + c.join()))
        });
        return b
    };
    ar = function(a) {
        for (var b = {}, c = _.z(bl(a)), d = c.next(); !d.done; d = c.next()) d = d.value, b[_.R(d, 1)] = _.jl(d, 2);
        a = _.jl(a, 8);
        a.length && (null != b.excl_cat || (b.excl_cat = a));
        return b
    };
    br = function(a) {
        var b = !1,
            c = _.bi(a, el, 2).map(function(d) {
                var e = _.R(d, 1);
                b = "excl_cat" === e;
                d = _.jl(d, 2);
                return encodeURIComponent(e) + "=" + encodeURIComponent(d.join())
            });
        a = _.jl(a, 3);
        !b && a.length && c.push(encodeURIComponent("excl_cat") + "=" + encodeURIComponent(a.join()));
        return c
    };
    dr = function(a, b, c, d, e) {
        if (c) {
            var f = {
                    Vd: new yn,
                    Wd: new yn,
                    bd: new yn
                },
                g = new Jj;
            O(g, new cr(a, b, c, d, f, e));
            Sj(g);
            return {
                Ga: g,
                bm: f
            }
        }
    };
    fr = function(a, b, c) {
        var d = window;
        if (_.H(tk) && b) {
            var e = new Jj;
            O(e, new er(a, d, b, c));
            Sj(e);
            return e
        }
    };
    gr = function(a) {
        return "gads_privacy_sandbox_td_buyerlist__" + a
    };
    ir = function(a, b) {
        return a.filter(function(c) {
            return hr(c, 2) > b
        })
    };
    kr = function(a, b) {
        a = new _.v.Map(a.map(function(e) {
            return [_.R(e, 1), e]
        }));
        b = _.z(b);
        for (var c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var d = a.get(_.R(c, 1));
            d ? jr(d, Math.max(hr(c, 2), hr(d, 2))) : a.set(_.R(c, 1), c)
        }
        return _.A(Array, "from").call(Array, _.A(a, "values").call(a))
    };
    or = function(a, b, c) {
        var d = Date.now();
        if (lr(a, b, c)) return new _.v.Map;
        b = new _.v.Map(_.A(Object, "entries").call(Object, a).filter(function(k) {
            var l = _.z(k);
            k = l.next().value;
            l = l.next().value;
            return _.A(k, "startsWith").call(k, "gads_privacy_sandbox_td_buyerlist__") && l
        }).map(function(k) {
            var l = _.z(k);
            k = l.next().value;
            l = l.next().value;
            return [k, mr(l)]
        }));
        c = _.z(b);
        for (var e = c.next(); !e.done; e = c.next()) {
            var f = _.z(e.value);
            e = f.next().value;
            f = f.next().value;
            var g = _.bi(f, nr, 1),
                h = ir(g, d);
            0 === h.length ? (b.delete(e), a.removeItem(e)) : h.length < g.length && (_.ol(f, 1, h), a.setItem(e, Ak(f)))
        }
        return b
    };
    lr = function(a, b, c) {
        if (!_.N(b, 3)) return !1;
        b = String(_.$f(c + "-" + _.R(b, 2) + _.R(b, 4) + _.N(b, 3)));
        if (a.getItem("gads_privacy_sandbox_tcf_hash") === b) return !1;
        c = _.z(_.A(Object, "keys").call(Object, a).filter(function(e) {
            return _.A(e, "startsWith").call(e, "gads_privacy_sandbox_td_buyerlist__")
        }));
        for (var d = c.next(); !d.done; d = c.next()) a.removeItem(d.value);
        a.setItem("gads_privacy_sandbox_tcf_hash", b);
        return !0
    };
    pr = function(a) {
        return (_.G = ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"], _.A(_.G, "includes")).call(_.G, a)
    };
    qr = function(a) {
        return (_.G = ["https://securepubads.g.doubleclick.net", "https://pubads.g.doubleclick.net"], _.A(_.G, "includes")).call(_.G, a)
    };
    sr = function(a, b, c, d, e) {
        if (b) {
            var f = b.Pb,
                g = b.zl;
            if (b.Pg && 4 === f) {
                b = new yn;
                f = new yn;
                if (!g) return b.F({
                    kind: 1,
                    reason: 1
                }), f.F(!1), {
                    Qi: {
                        yi: b,
                        Kh: f
                    }
                };
                g = new Jj;
                a = new rr(a, c, d, e, b, f);
                O(g, a);
                Sj(g);
                return {
                    Qi: {
                        yi: b,
                        Kh: f
                    },
                    hm: g
                }
            }
        }
    };
    tr = function(a) {
        var b = a.Hf,
            c = a.Ab,
            d = void 0 === a.fh ? [] : a.fh,
            e = a.interestGroupBuyers;
        a = a.Hc;
        var f = {};
        void 0 !== a && (f["https://googleads.g.doubleclick.net"] = a, f["https://td.doubleclick.net"] = a);
        e = {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            trustedScoringSignalsUrl: "https://securepubads.g.doubleclick.net/td/sts",
            interestGroupBuyers: null != e ? e : ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"],
            sellerExperimentGroupId: a,
            auctionSignals: b.auctionSignals.promise,
            sellerSignals: b.j.promise,
            sellerTimeout: 50,
            sellerCurrency: "USD",
            perBuyerCurrencies: b.perBuyerCurrencies.promise,
            perBuyerExperimentGroupIds: f,
            perBuyerSignals: b.perBuyerSignals.promise,
            perBuyerTimeouts: b.perBuyerTimeouts.promise,
            perBuyerCumulativeTimeouts: b.perBuyerCumulativeTimeouts.promise
        };
        e.directFromSellerSignalsHeaderAdSlot = b.directFromSellerSignalsHeaderAdSlot.promise;
        c = {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            interestGroupBuyers: [],
            auctionSignals: {},
            sellerExperimentGroupId: a,
            sellerSignals: b.topLevelSellerSignals.promise,
            sellerTimeout: 50,
            signal: c.signal,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: {},
            perBuyerTimeouts: {},
            perBuyerCumulativeTimeouts: {},
            componentAuctions: [e].concat(_.lh(d)),
            resolveToConfig: b.resolveToConfig.promise
        };
        c.directFromSellerSignalsHeaderAdSlot = b.directFromSellerSignalsHeaderAdSlot.promise;
        return c
    };
    ur = function(a, b) {
        b = b.Hf;
        b.topLevelSellerSignals.resolve(a.sellerSignals);
        b.directFromSellerSignals.resolve(a.directFromSellerSignals);
        b.directFromSellerSignalsHeaderAdSlot.resolve(a.directFromSellerSignalsHeaderAdSlot);
        b.resolveToConfig.resolve(!!a.resolveToConfig);
        var c;
        if (a = null == (c = a.componentAuctions) ? void 0 : _.A(c, "find").call(c, function(g) {
                return qr(g.seller)
            })) {
            b.auctionSignals.resolve(a.auctionSignals);
            b.j.resolve(a.sellerSignals);
            b.perBuyerSignals.resolve(a.perBuyerSignals);
            var d;
            b.perBuyerTimeouts.resolve(null != (d = a.perBuyerTimeouts) ? d : {});
            var e;
            b.perBuyerCumulativeTimeouts.resolve(null != (e = a.perBuyerCumulativeTimeouts) ? e : {});
            var f;
            b.perBuyerCurrencies.resolve(null != (f = a.perBuyerCurrencies) ? f : {})
        } else b.auctionSignals.resolve(void 0), b.j.resolve(void 0), b.perBuyerSignals.resolve({}), b.perBuyerTimeouts.resolve({}), b.perBuyerCumulativeTimeouts.resolve({}), b.perBuyerCurrencies.resolve({})
    };
    vr = function(a) {
        var b = Date.now() + 864E5;
        return a.map(function(c) {
            var d = new nr;
            c = _.rh(d, 1, c);
            return jr(c, b)
        })
    };
    wr = function(a, b, c) {
        var d = "https://googleads.g.doubleclick.net/td/auctionwinner?status=nowinner",
            e = _.N(c, 18),
            f = _.N(c, 7);
        if (f || e) d += "&isContextualWinner=1";
        f && (d += "&hasXfpAds=1");
        e = c.getEscapedQemQueryId();
        f = _.R(c, 6);
        e && (d += "&winner_qid=" + encodeURIComponent(e));
        f && (d += "&xfpQid=" + encodeURIComponent(f));
        _.N(c, 4) && (d += "&is_plog=1");
        (e = _.R(c, 11)) && (d += "&ecrs=" + e);
        if (null == c ? 0 : _.R(c, 19)) d += "&cid=" + encodeURIComponent(_.R(c, 19));
        (null == c ? 0 : _.N(c, 21)) || (d += "&turtlexTest=1");
        d += "&applied_timeout_ms=" + (b + "&duration_ms=" + Math.round(a));
        Nq(d)
    };
    xr = function(a, b, c, d, e) {
        a.Eb.F(e);
        a.Aa.F(c);
        a.La.F(d);
        null == b || b.F(!1)
    };
    Fr = function(a, b) {
        var c, d, e, f, g, h, k, l, m, n, p, r, w, u;
        return _.lb(function(x) {
            if (1 == x.j) return ("string" !== typeof a || _.A(a, "startsWith").call(a, "urn:")) && yr.deprecatedURNToURL && yr.deprecatedReplaceInURN ? x.yield(yr.deprecatedURNToURL(a), 2) : x.return();
            c = x.o;
            d = {};
            e = b.gdprApplies || "";
            (null != (f = c.match(zr)) ? f : []).forEach(function(y) {
                d[y] = e
            });
            g = b.xk || "";
            (null != (h = c.match(Ar)) ? h : []).forEach(function(y) {
                d[y] = g
            });
            k = b.rj || "";
            (null != (l = c.match(Br)) ? l : []).forEach(function(y) {
                d[y] = k
            });
            m = b.oj || "";
            (null != (n = c.match(Cr)) ? n : []).forEach(function(y) {
                d[y] = m
            });
            p = b.mj || "";
            (null != (r = c.match(Dr)) ? r : []).forEach(function(y) {
                d[y] = p
            });
            w = b.Bl || "";
            (null != (u = c.match(Er)) ? u : []).forEach(function(y) {
                d[y] = w
            });
            return x.yield(yr.deprecatedReplaceInURN(a, d), 0)
        })
    };
    Gr = function(a, b, c, d, e, f, g, h) {
        var k = 3 === b,
            l = 2 === b,
            m = 1 === b,
            n = f.getEscapedQemQueryId(),
            p = _.R(f, 6);
        Zi("run_ad_auction_stats", function(r) {
            ej(r, a);
            fj(r, "duration_ms", c);
            fj(r, "applied_timeout_ms", d);
            fj(r, "timed_out", l ? 1 : 0);
            fj(r, "error", k ? 1 : 0);
            fj(r, "auction_skipped", m ? 1 : 0);
            fj(r, "auction_winner", h ? 1 : 0);
            fj(r, "thread_release_only", _.N(f, 15) ? 1 : 0);
            fj(r, "winner_qid", null != n ? n : "");
            fj(r, "xfpQid", null != p ? p : "");
            fj(r, "publisher_tag", "gpt");
            e && fj(r, "parallel", "1");
            0 < g && fj(r, "nc", g)
        }, 1)
    };
    Hr = function(a, b, c, d, e) {
        var f = e.getEscapedQemQueryId(),
            g = _.R(e, 6);
        Zi("run_ad_auction_complete", function(h) {
            ej(h, a);
            fj(h, "duration_ms", Math.round(d));
            fj(h, "applied_timeout_ms", c);
            fj(h, "auction_has_winner", b);
            f && fj(h, "winner_qid", f);
            g && fj(h, "xfpQid", g)
        }, 1)
    };
    Ir = function(a, b) {
        var c = b.getEscapedQemQueryId(),
            d = _.R(b, 6);
        Zi("pre_run_ad_auction_ping", function(e) {
            ej(e, a);
            fj(e, "winner_qid", null != c ? c : "");
            fj(e, "xfpQid", null != d ? d : "");
            fj(e, "publisher_tag", "gpt")
        }, 1)
    };
    Or = function(a, b, c, d) {
        var e = Fi(a, document);
        e && xg(e, window, d, !0);
        Jr(_.Rf(Jh), "5", Kr(c.R[a.getDomId()], 20));
        Lr(a, Mr, 801, {
            mh: null,
            isBackfill: !1
        });
        if (_.jp(b, a) && !Oi(a, document)) {
            b = c.W;
            c = c.R[a.getDomId()];
            var f;
            (null != (f = Io(c, 10)) ? f : _.N(b, 11)) && ip(a, document, c, b)
        }
        Lr(a, Nr, 825, {
            isEmpty: !0
        })
    };
    Rr = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x) {
        if (Wf(window.isSecureContext, window.navigator, window.document) && !_.H(Pr) && u) {
            u = {
                Pd: new Cn,
                Aa: new yn,
                La: new yn,
                Lc: new yn
            };
            var y = new Jj;
            O(y, new Qr(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x));
            Sj(y);
            return {
                Ga: y,
                im: u
            }
        }
    };
    Tr = function(a, b, c, d, e, f, g, h, k) {
        if (b) {
            var l = b.Pb;
            if (b.Pg && 0 !== l) return b = new Jj, a = new Sr(a, l, c, d, e, f, g, h, k), O(b, a), Sj(b), {
                gm: a.l,
                fm: b
            }
        }
    };
    Ur = function() {
        for (var a = _.z(_.A(Array, "from").call(Array, document.getElementsByTagName("script"))), b = a.next(); !b.done; b = a.next()) {
            var c = b = b.value,
                d = b.src;
            d && (_.Ja(d, "/tag/js/gpt.js") || _.Ja(d, "/tag/js/gpt_mobile.js")) && !c.googletag_executed && b.textContent && (c.googletag_executed = !0, c = document.createElement("script"), gb(c, new _.Xe(b.textContent, Ye)), document.head.appendChild(c), document.head.removeChild(c))
        }
    };
    Vr = function(a, b) {
        b = _.z(_.A(Object, "entries").call(Object, b));
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = _.z(c.value);
            c = d.next().value;
            d = d.next().value;
            a.hasOwnProperty(c) || (a[c] = d)
        }
    };
    Yr = function(a, b, c) {
        var d = [];
        c = [].concat(_.lh(c.X)).slice();
        if (b) {
            if (!Array.isArray(b)) return Q(a, Uk("googletag.destroySlots", [b])), !1;
            na(b);
            d = c.filter(function(e) {
                return _.A(b, "includes").call(b, e.j)
            })
        } else d = c;
        if (!d.length) return !1;
        Wr(d);
        Xr(d);
        return !0
    };
    ys = function(a, b, c, d, e, f, g, h, k, l) {
        var m = Hm(),
            n, p, r = L(a, 74, function(u, x, y) {
                return e.defineSlot(a, b, u, x, y)
            }),
            w = {};
        r = (w._loaded_ = !0, w.cmd = [], w._vars_ = m._vars_, w.evalScripts = function() {
            try {
                Ur()
            } catch (y) {
                Lh(a, 297, y);
                var u, x;
                null == (u = window.console) || null == (x = u.error) || x.call(u, y)
            }
        }, w.display = L(a, 95, function(u) {
            void Zr(c, u, e)
        }), w.defineOutOfPageSlot = L(a, 73, function(u, x) {
            return (u = ep(a, b, e, {
                uh: x,
                adUnitPath: u
            })) ? u.j : null
        }), w.getVersion = L(a, 946, function() {
            return a.wc ? String(a.wc) : a.eb
        }), w.pubads = L(a, 947, function() {
            return rm(a, b, c, e, h)
        }), w.companionAds = L(a, 816, function() {
            null != n || (n = new is(a, b, c, f));
            return Xk(a, b, n)
        }), w.content = L(a, 817, function() {
            null != p || (p = new js(a, b, g));
            return Zk(a, b, p)
        }), w.setAdIframeTitle = L(a, 729, Rq), w.getEventLog = L(a, 945, function() {
            return new ks(a, b)
        }), w.sizeMapping = L(a, 90, function() {
            return new ls(a, b)
        }), w.enableServices = L(a, 91, function() {
            for (var u = _.z(ms), x = u.next(); !x.done; x = u.next()) x = x.value, x.enabled && b.info(ns()), os(x)
        }), w.destroySlots = L(a, 75, function(u) {
            return Yr(b, u, e)
        }), w.enums = xl(), w.defineSlot = r, w.defineUnit = r, w.getWindowsThatCanCommunicateWithHostpageLibrary = L(a, 955, function(u) {
            return ps(k, u).map(function(x) {
                var y;
                return null == (y = Oi(x, document)) ? void 0 : y.contentWindow
            }).filter(function(x) {
                return !!x
            })
        }), w.disablePublisherConsole = L(a, 93, ln), w.onPubConsoleJsLoad = L(a, 731, on), w.openConsole = L(a, 732, function(u) {
            fn = !0;
            var x;
            (null == (x = Hm()) ? 0 : x.console) ? Hm().console.openConsole(u): (u && (nn = u), mn = !0, bn(a))
        }), w.setConfig = L(a, 1034, function(u) {
            if (Af(u)) {
                var x = u.commerce;
                if (null === x) x = Qo(d, qs, 33), _.Ai(x, 1);
                else if (void 0 !== x) {
                    var y = Qo(d, qs, 33);
                    if (_.ka(x)) {
                        var C = x.query,
                            D = x.categories,
                            E = x.productIds,
                            J = x.filter,
                            M = _.Nd(rs(y, ss, 1));
                        null === C ? _.Ai(M, 1) : np(C) ? Vn(M, 1, C) : void 0 !== C && mp(b, x, "query", C);
                        null === D ? _.Ai(M, 2) : op(D) ? _.Uh(M, 2, D) : void 0 !== D && mp(b, x, "categories", D);
                        null === E ? _.Ai(M, 3) : op(E) ? _.Uh(M, 3, E) : void 0 !== E && mp(b, x, "productIds", E);
                        null === J ? _.Ai(M, 4) : np(J) ? Vn(M, 4, J) : void 0 !== J && mp(b, x, "filter", J);
                        null != _.Aj(M, 1) || _.jl(M, 2).length ? _.th(y, 1, M) : Q(b, ts())
                    } else Q(b, Uk("googletag.setConfig.commerce", [x]))
                }
                if (_.A(Object, "hasOwn").call(Object, u, "pps"))
                    if (C = u.pps, null === C) x = Qo(d, qs, 33), _.Ai(x, 2);
                    else if (x = Qo(Qo(d, qs, 33), us, 2), _.Ai(x, 1), "object" === typeof C && C.hasOwnProperty("taxonomies") ? y = !0 : (Q(b, Uk("googletag.setConfig.pps", [C])), y = !1), y)
                    if (y = C.taxonomies, null === y) eq("taxonomies", y, b, C);
                    else if (fq(y, b, C))
                    for (C = _.z(_.A(Object, "entries").call(Object, y)), D = C.next(); !D.done; D = C.next()) {
                        D = _.z(D.value);
                        var K = D.next().value;
                        D = D.next().value;
                        E = x;
                        J = b;
                        var X = y;
                        if (void 0 === K || null === K) eq("taxonomy", K, J, X);
                        else {
                            M = Number(K);
                            var ba = M,
                                la = J,
                                pa = X;
                            (_.G = _.A(Object, "values").call(Object, wl), _.A(_.G, "includes")).call(_.G, Number(ba)) ? K = !0 : (eq("taxonomy", K, la, pa), K = !1);
                            K && (null == D ? eq("taxonomyData", D, J, X) : (K = J, "object" === typeof D && D.hasOwnProperty("values") ? X = !0 : (eq("taxonomyData", D, K, X), X = !1), X && nq(M, D, E, J)))
                        }
                    }
                _.H(vs) ? _.A(Object, "hasOwn").call(Object, u, "adExpansion") && (_.Ai(d, 34), x = u.adExpansion, null !== x && Af(x) && _.A(Object, "hasOwn").call(Object, x, "enabled") && (x = x.enabled, Jm(x) && (x = Km(x), _.th(d, 34, x)))) : (x = u.adExpansion, void 0 === x || null === x ? _.Ai(d, 34) : (x = x.enabled, Jm(x) ? (x = Km(x), _.th(d, 34, x)) : void 0 !== x && null !== x || _.Ai(d, 34)));
                if (_.A(Object, "hasOwn").call(Object, u, "privacyTreatments")) {
                    u = u.privacyTreatments;
                    _.Ai(d, 36);
                    a: {
                        if (null !== u && Af(u) && _.A(Object, "hasOwn").call(Object, u, "treatments")) {
                            u = u.treatments;
                            if (ws(u) && u.every(qq)) {
                                u = {
                                    treatments: u
                                };
                                break a
                            }
                            Q(b, Uk("googletag.setConfig", [u]))
                        }
                        u = void 0
                    }
                    x = u;
                    if (void 0 !== x) {
                        u = new _.v.Set;
                        x = _.z(x.treatments);
                        for (y = x.next(); !y.done; y = x.next()) {
                            y = y.value;
                            a: {
                                switch (y) {
                                    case "disablePersonalization":
                                        C = 1;
                                        break a
                                }
                                C = void 0
                            }
                            void 0 === C ? Q(b, Uk("googletag.setConfig", [y])) : u.add(C)
                        }
                        if (u.size) {
                            x = new xs;
                            y = x.D;
                            C = Vb(y);
                            qc(Kd(x.D));
                            y = Vd(y, C, 1, 2, !1);
                            if (Array.isArray(u))
                                for (C = 0; C < u.length; C++) y.push(Jc(u[C]));
                            else
                                for (u = _.z(u), C = u.next(); !C.done; C = u.next()) y.push(Jc(C.value));
                            _.th(d, 36, x)
                        }
                    }
                }
            } else Q(b, Uk("googletag.setConfig", [u]))
        }), w.apiReady = !0, w);
        Tq(a, m, b, l);
        Vr(m, r)
    };
    Fs = function(a) {
        var b = window,
            c = new Jj,
            d = new zs(a, b);
        d = O(c, d).output;
        var e = new Jj;
        var f = new As(a, b);
        O(e, f);
        Sj(e);
        e = {
            jl: f.l
        };
        _.H(Bs) && O(c, new Cs(a, b));
        if (Na()) {
            f = {
                si: new yn
            };
            var g = new Jj;
            O(g, new Ds(a, window, f.si));
            Sj(g);
            a = f
        } else a = void 0;
        g = _.H(Pr);
        f = b.navigator;
        b = Wf(b.isSecureContext, b.navigator, b.document);
        b = !g && b;
        g = _.cg(Es);
        b = {
            Pg: b,
            Pb: g,
            zl: !!f.getInterestGroupAdAuctionData
        };
        Sj(c);
        return {
            il: e,
            ul: a,
            oe: d,
            dm: b
        }
    };
    Gs = function(a) {
        return window.IntersectionObserver && new IntersectionObserver(a, {
            threshold: [.5]
        })
    };
    Ks = function(a, b, c, d, e) {
        var f = void 0 === f ? Gs : f;
        var g = new Jj,
            h = O(g, new Rp(a, e, Hs));
        c = O(g, new Is(a, c, d, h.output, f));
        O(g, new Js(a, c.output, b, e));
        Sj(g);
        return {
            jk: g,
            Gn: c.output
        }
    };
    Ls = function(a) {
        var b = {
            threshold: [0, .3, .5, .75, 1]
        };
        return window.IntersectionObserver && new IntersectionObserver(a, b)
    };
    tt = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D) {
        var E = new Jj,
            J = fi(!0, window),
            M = k.W,
            K = k.R[e.getDomId()],
            X = D.oe,
            ba = null == C ? void 0 : C.pf,
            la = new Ms(a, window);
        O(E, la);
        var pa = m.Ck,
            za = m.pm,
            ya = m.pk,
            Qa = m.ec,
            Ga = m.sj,
            zb = m.Jk,
            bb = m.rf,
            wb = m.wk,
            bc = m.Uf,
            Hc = m.fe,
            jc = m.lm,
            Zd = m.Ik,
            Ic = m.Rk,
            rd = m.Rg,
            $d = m.Fk,
            xb = m.ak,
            kc = m.Aa,
            Th = m.Pi;
        C = m.Od;
        D = m.Jj;
        var il = m.Ej,
            Jf = new yn;
        Jf.F(p);
        var Cg = new Ns(a, window.top, Jf);
        O(E, Cg);
        var Xc = new Os(a, Ps(K), J.height, bc, pa);
        O(E, Xc);
        var ae = new Qs(a, e, Fi(e, n), e.getDomId(), Ni(e), n.documentElement, Ps(K), h, f);
        Rs(E, ae);
        m = new yn;
        m.Ja(ae.m.promise.then(function(bq) {
            return bq.output
        }));
        ae = new Ss(a, kc, Ga, zb, bb);
        O(E, ae);
        kc = new Ts(a, _.Zh(M, Us, 5));
        O(E, kc);
        za = Bn(a, window.location.hash, J, e.getAdUnitPath(), K, f, Xc.output, Hc, za, pa, ae.output, m);
        pa = za.Mg;
        _.S(E, za.Ga);
        bb = new Vs(a, M, K, Ga, bb, pa.Nh);
        O(E, bb);
        if (f = Rr(a, e, Cg.output, K, h, p, f, pa.Aa, pa.La, m, r, k, y, Qa, Th, g, w)) {
            _.S(E, f.Ga);
            var sd = f.im
        }
        var Ra, Dg;
        f = null != (Dg = null == (Ra = sd) ? void 0 : Ra.Aa) ? Dg : pa.Aa;
        var lc, Kf;
        Ra = null != (Kf = null == (lc = sd) ? void 0 : lc.La) ? Kf : pa.La;
        var wc;
        lc = null == (wc = sd) ? void 0 : wc.Pd;
        var xc;
        sd = null == (xc = sd) ? void 0 : xc.Lc;
        xc = new Ws(a, e, M, K, Ps(K), n, h, m, bb.output, Ra, ya, lc);
        O(E, xc);
        wc = new Xs(a, xc.output);
        O(E, wc);
        wc = new Ys(a, e, J, h, wc.output, kc.l, lc);
        O(E, wc);
        wc = new Zs(a, wc.output, xc.output, kc.l, lc);
        O(E, wc);
        kc = Fn(a, J, e, K, m, xc.output, ya, Ra, pa.fe, Qa, lc);
        J = kc.Mg;
        _.S(E, kc.Ga);
        jc = new $s(a, M, K, f, bb.output, jc);
        O(E, jc);
        kc = new at(a, window, xb, la.output, lc);
        O(E, kc);
        Kf = new bt(a, Ps(K), n);
        O(E, Kf);
        xb = new ct(a, x, Ps(K), bc, wb, lc);
        O(E, xb);
        Ic = new dt(a, Ic, sd, Jf, lc);
        O(E, Ic);
        (ba = fr(a, ba, il)) && _.S(E, ba);
        l = new et(a, e, h, k, u, l, window, f, bb.output, wc.output, m, xc.output, Ra, Qa, ya, jc.output, zb, Zd, rd, J.Pd, kc.output, Kf.output, xb.output, Th, X, lc);
        O(E, l);
        X = new ft(a, window, e, l.v, Jf);
        O(E, X);
        X = Ps(K);
        switch (X) {
            case 2:
            case 3:
                _.H(gt) ? O(E, new ht(a, h, Ps(K), e, window, bc, l.l, m, xb.output, Ra)) : O(E, new jt(a, h, Ps(K), e, window, bc, l.l, m, xb.output, Ra));
                break;
            case 5:
                O(E, new kt(a, e, k.ed, wb, l.l, m, Cg.output, xb.output));
                break;
            case 4:
                k = new lt(a, e, u, window, l.l, m);
                _.S(E, k);
                Sj(k);
                break;
            case 7:
                Rs(E, $p(a, e, u, l.l, m));
                break;
            case 8:
            case 9:
                (k = Wq(a, X, x, l.l, xc.output, Ra)) && _.S(E, k)
        }
        k = new mt(a, e, l.l, n, u);
        O(E, k);
        k = new nt(a, e, ot(h, e), window.top);
        O(E, k);
        u = Ks(a, u, n, l.l, e).jk;
        _.S(E, u);
        h = new pt(a, ot(h, e), window.top, l.l, la.output, k.output, k.l);
        O(E, h);
        O(E, new qt(a, e, ya, Ga, rd, l.l, xc.output, l.C));
        e = new rt(a, window, $d, l.l, xc.output, m);
        O(E, e);
        _.S(E, gp(a, n, Hm(), M, c, b, d, D));
        O(E, new st(a, Hm(), M, b, c, d, C));
        return E
    };
    wt = function(a, b, c) {
        var d = null;
        try {
            var e = ut(b.top.document, b.top).y;
            d = a.map(function(f) {
                var g = c.W,
                    h = c.R[f.getDomId()],
                    k;
                f = null == (k = Li(f, h, b.document, Jo(g, h))) ? void 0 : k.y;
                k = fi(!0, b).height;
                return void 0 === f || -12245933 === f || -12245933 === k ? -1 : f < e + k ? 0 : ++vt
            })
        } catch (f) {}
        return d
    };
    Et = function(a) {
        return Nh(a.ia.context, 1132, function() {
            if (a.ja.X.length) {
                var b = new _.v.Set(eg(xt));
                for (var c = _.z(_.N(a.ia.Z, 8) ? "loc gpic cookie ms ppid top etu uule video_doc_id".split(" ") : []), d = c.next(); !d.done; d = c.next()) b.add(d.value);
                d = new _.v.Map;
                c = _.z(yt);
                for (var e = c.next(); !e.done; e = c.next()) e = e.value, e(a, d);
                c = "https://" + (zt(a) ? "pagead2.googlesyndication.com" : "securepubads.g.doubleclick.net") + "/gampad/ads?";
                d = _.z(d);
                for (e = d.next(); !e.done; e = d.next()) {
                    var f = _.z(e.value);
                    e = f.next().value;
                    var g = f.next().value;
                    f = g.value;
                    g = void 0 === g.options ? {} : g.options;
                    (new RegExp("[?&]" + e + "=")).test(c);
                    if (!b.has(e) && null != f) {
                        var h = void 0 === g.Ba ? "," : g.Ba,
                            k = void 0 === g.Fa ? !1 : g.Fa,
                            l = void 0 === g.Nb ? !1 : g.Nb;
                        if (f = "object" !== typeof f ? null == f || !k && 0 === f ? null : encodeURIComponent(f) : Array.isArray(f) && f.length ? _.H(Bo) && l || _.H(At) ? Bt(f, g) : encodeURIComponent(f.join(h)) : null) "?" !== c[c.length - 1] && (c += "&"), c += e + "=" + f
                    }
                }
                if (1 === _.cg(Ct) || 2 === _.cg(Ct)) b = _.cg(Dt), b = 0 >= b ? "" : (_.G = _.A(Array, "from").call(Array, {
                    length: Math.ceil(b / 8)
                }), _.A(_.G, "fill")).call(_.G, "testdata").join("").substring(0, b), 2 === _.cg(Ct) && (c += "&dblt=" + b);
                b = c
            } else b = "";
            return b
        })
    };
    zt = function(a) {
        var b = a.ia.Z,
            c, d;
        a = null != (d = null == (c = Ft(a.ja.P.W)) ? void 0 : _.N(c, 9)) ? d : !1;
        c = _.N(b, 8);
        return a || c || !Lf(b)
    };
    Bt = function(a, b) {
        var c = void 0 === b.Ba ? "," : b.Ba,
            d = void 0 === b.md ? "" : b.md,
            e = void 0 === b.Fa ? !1 : b.Fa,
            f = !1;
        a = a.map(function(g) {
            f || (f = !!g);
            return String(0 === g && e ? g : g || d)
        });
        return f || e ? encodeURIComponent(a.join(c)) : null
    };
    Ht = function(a, b, c) {
        b = Gt(b, c);
        switch (b) {
            case 0:
                a();
                break;
            case 1:
                c.setTimeout(a, 0);
                break;
            case 2:
                c.scheduler.yield().then(a);
                break;
            default:
                _.db(b)
        }
    };
    Gt = function(a, b) {
        if (0 === a) return 0;
        a = _.cg(It);
        switch (a) {
            case 0:
                return 0;
            case 1:
                return 1;
            case 6:
                var c;
                return (null == (c = b.scheduler) ? 0 : c.yield) ? 2 : 1;
            case 5:
                var d;
                return (null == (d = b.scheduler) ? 0 : d.yield) ? 2 : 0;
            default:
                _.db(a)
        }
    };
    Jt = function(a) {
        function b(f) {
            var g = f;
            return function() {
                var h = _.Xa.apply(0, arguments);
                if (g) {
                    var k = g;
                    g = null;
                    k.apply(null, _.lh(h))
                }
            }
        }
        var c = null,
            d = 0,
            e = 0;
        return function() {
            var f, g, h, k;
            return _.lb(function(l) {
                if (1 == l.j) return d && clearTimeout(d), d = 0, f = new _.lg, g = b(f.resolve), h = ++e, l.yield(0, 2);
                if (e !== h) return g(!1), l.return(f.promise);
                c ? c(!1) : g(!0);
                k = b(function() {
                    c = null;
                    d = 0;
                    g(!0)
                });
                d = setTimeout(k, 1E3);
                _.tn(a, function() {
                    return void g(!1)
                });
                c = g;
                return l.return(f.promise)
            })
        }
    };
    Lt = function(a, b) {
        a = a.X;
        var c = b.L,
            d = b.Va;
        b = b.He;
        if (!a.length) return {
            Sc: []
        };
        for (var e = _.z(a), f = e.next(); !f.done; f = e.next()) kp(c, f.value);
        return b ? {
            Sc: []
        } : d ? (c = nh(a[0].getAdUnitPath()), {
            Sc: Kt(a, c)
        }) : {
            Sc: a.map(function(g) {
                return {
                    networkCode: nh(g.getAdUnitPath()),
                    X: [g]
                }
            })
        }
    };
    Kt = function(a, b) {
        var c = [];
        a = wa(a, function(f) {
            return nh(f.getAdUnitPath())
        });
        a = _.z(_.A(Object, "entries").call(Object, a));
        for (var d = a.next(); !d.done; d = a.next()) {
            var e = _.z(d.value);
            d = e.next().value;
            e = e.next().value;
            d === b ? c.unshift({
                networkCode: d,
                X: e
            }) : c.push({
                networkCode: d,
                X: e
            })
        }
        return c
    };
    Nt = function(a, b) {
        a = a.X;
        var c = function(d) {
            return !!gi(b.R[d.getDomId()]).length
        };
        return {
            Ig: a.filter(c),
            Sg: a.filter(Mt(c))
        }
    };
    Vt = function() {
        var a = new Ot;
        var b = (new Pt).setCorrelator(_.Rh(_.t));
        var c = _.Uf().join();
        b = _.rh(b, 5, c);
        b = _.I(b, 2, 1);
        a = _.th(a, 1, b);
        b = new Qt;
        c = _.H(Rt);
        b = _.xh(b, 7, c);
        c = _.H(St);
        b = _.xh(b, 8, c);
        c = _.H(Tt);
        b = _.xh(b, 9, c);
        b = _.xh(b, 10, !0);
        c = _.H(Ut);
        b = _.xh(b, 13, c);
        b = _.xh(b, 16, !0);
        a = _.th(a, 2, b);
        window.google_rum_config = a.toJSON()
    };
    Zt = function() {
        var a = _.H(Wt) ? _.Ve(Xt) : _.Ve(Yt);
        _.hn(document, a)
    };
    eu = function(a, b) {
        var c = $t() || au() ? 1 : _.Zf(),
            d = .001 > c;
        d ? (b.l = !0, Tf(31067358)) : .002 > c && Tf(31067357);
        Rl(23, a);
        a = 1E-4 > c;
        b = _.cg(bu);
        var e = 0 < b && c < b,
            f = _.cg(cu),
            g = 0 < f && c < 1 / f,
            h = _.H(du);
        return {
            Bc: d,
            Vh: 1E3,
            Ji: a,
            Uh: 1E4,
            Hg: d,
            Pf: 1E3,
            Nl: e,
            vl: b,
            Ll: g,
            bl: f,
            Ol: h,
            kh: c
        }
    };
    ju = function(a, b) {
        var c = _.A(Object, "assign").call(Object, {}, a);
        a = a.kh;
        c = (delete c.kh, c);
        var d = b.xb;
        /m\d+/.test(d) ? d = Number(d.substring(1)) : (d && vj({
            mjsv: d
        }, "gpt_inv_ver"), d = void 0);
        var e = window.document.URL,
            f = _.cg(fu);
        f = new gu(4, b.xb, f);
        return _.A(Object, "assign").call(Object, {}, b, c, {
            Nn: new hu(b)
        }, {
            wc: d,
            Qa: f,
            Lf: e,
            zh: 2012,
            Vk: new iu(f, a)
        })
    };
    _.ku = function(a) {
        var b;
        a = (null != (b = void 0 === a ? null : a) ? b : window).googletag;
        return (null == a ? 0 : a.apiReady) ? a : void 0
    };
    _.aa = [];
    lu = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    };
    mu = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };
    nu = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    };
    _.ou = nu(this);
    pu = "function" === typeof Symbol && "symbol" === typeof Symbol("x");
    _.v = {};
    qu = {};
    _.A = function(a, b, c) {
        if (!c || null != a) {
            c = qu[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        }
    };
    ru = function(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in _.v ? f = _.v : f = _.ou;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = pu && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? mu(_.v, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === qu[d] && (a = 1E9 * Math.random() >>> 0, qu[d] = pu ? _.ou.Symbol(d) : "$jscp$" + a + "$" + d), mu(f, qu[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    };
    ru("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.j = f;
            mu(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.j
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    ru("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, _.v.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = _.ou[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && mu(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return su(lu(this))
                }
            })
        }
        return a
    }, "es6");
    su = function(a) {
        a = {
            next: a
        };
        a[_.A(_.v.Symbol, "iterator")] = function() {
            return this
        };
        return a
    };
    _.tu = function(a) {
        return a.raw = a
    };
    uu = function(a, b) {
        a.raw = b;
        return a
    };
    _.z = function(a) {
        var b = "undefined" != typeof _.v.Symbol && _.A(_.v.Symbol, "iterator") && a[_.A(_.v.Symbol, "iterator")];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: lu(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    };
    _.lh = function(a) {
        if (!(a instanceof Array)) {
            a = _.z(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    };
    vu = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    wu = pu && "function" == typeof _.A(Object, "assign") ? _.A(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) vu(d, e) && (a[e] = d[e])
        }
        return a
    };
    ru("Object.assign", function(a) {
        return a || wu
    }, "es6");
    var xu = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        yu = function() {
            function a() {
                function c() {}
                new c;
                Reflect.construct(c, [], function() {});
                return new c instanceof c
            }
            if (pu && "undefined" != typeof Reflect && Reflect.construct) {
                if (a()) return Reflect.construct;
                var b = Reflect.construct;
                return function(c, d, e) {
                    c = b(c, d);
                    e && Reflect.setPrototypeOf(c, e.prototype);
                    return c
                }
            }
            return function(c, d, e) {
                void 0 === e && (e = c);
                e = xu(e.prototype || Object.prototype);
                return Function.prototype.apply.call(c, e, d) || e
            }
        }(),
        zu;
    if (pu && "function" == typeof _.A(Object, "setPrototypeOf")) zu = _.A(Object, "setPrototypeOf");
    else {
        var Au;
        a: {
            var Bu = {
                    a: !0
                },
                Cu = {};
            try {
                Cu.__proto__ = Bu;
                Au = Cu.a;
                break a
            } catch (a) {}
            Au = !1
        }
        zu = Au ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    Du = zu;
    _.T = function(a, b) {
        a.prototype = xu(b.prototype);
        a.prototype.constructor = a;
        if (Du) Du(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Wl = b.prototype
    };
    Eu = function() {
        this.l = !1;
        this.A = null;
        this.o = void 0;
        this.j = 1;
        this.I = this.m = 0;
        this.J = null
    };
    Fu = function(a) {
        if (a.l) throw new TypeError("Generator is already running");
        a.l = !0
    };
    Eu.prototype.H = function(a) {
        this.o = a
    };
    var Gu = function(a, b) {
        a.J = {
            exception: b,
            Lk: !0
        };
        a.j = a.m || a.I
    };
    Eu.prototype.return = function(a) {
        this.J = {
            return: a
        };
        this.j = this.I
    };
    Eu.prototype.yield = function(a, b) {
        this.j = b;
        return {
            value: a
        }
    };
    nb = function(a) {
        a.m = 0;
        var b = a.J.exception;
        a.J = null;
        return b
    };
    Hu = function(a) {
        this.j = new Eu;
        this.o = a
    };
    Ku = function(a, b) {
        Fu(a.j);
        var c = a.j.A;
        if (c) return Iu(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.j.return);
        a.j.return(b);
        return Ju(a)
    };
    Iu = function(a, b, c, d) {
        try {
            var e = b.call(a.j.A, c);
            if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
            if (!e.done) return a.j.l = !1, e;
            var f = e.value
        } catch (g) {
            return a.j.A = null, Gu(a.j, g), Ju(a)
        }
        a.j.A = null;
        d.call(a.j, f);
        return Ju(a)
    };
    Ju = function(a) {
        for (; a.j.j;) try {
            var b = a.o(a.j);
            if (b) return a.j.l = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.j.o = void 0, Gu(a.j, c)
        }
        a.j.l = !1;
        if (a.j.J) {
            b = a.j.J;
            a.j.J = null;
            if (b.Lk) throw b.exception;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    };
    Lu = function(a) {
        this.next = function(b) {
            Fu(a.j);
            a.j.A ? b = Iu(a, a.j.A.next, b, a.j.H) : (a.j.H(b), b = Ju(a));
            return b
        };
        this.throw = function(b) {
            Fu(a.j);
            a.j.A ? b = Iu(a, a.j.A["throw"], b, a.j.H) : (Gu(a.j, b), b = Ju(a));
            return b
        };
        this.return = function(b) {
            return Ku(a, b)
        };
        this[_.A(_.v.Symbol, "iterator")] = function() {
            return this
        }
    };
    Mu = function(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new _.v.Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : _.v.Promise.resolve(g.value).then(b, c).then(f, e)
            }
            f(a.next())
        })
    };
    _.lb = function(a) {
        return Mu(new Lu(new Hu(a)))
    };
    _.Xa = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    ru("Reflect", function(a) {
        return a ? a : {}
    }, "es6");
    ru("Reflect.construct", function() {
        return yu
    }, "es6");
    ru("Reflect.setPrototypeOf", function(a) {
        return a ? a : Du ? function(b, c) {
            try {
                return Du(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    }, "es6");
    ru("Promise", function(a) {
        function b() {
            this.j = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.o = function(g) {
            if (null == this.j) {
                this.j = [];
                var h = this;
                this.m(function() {
                    h.J()
                })
            }
            this.j.push(g)
        };
        var d = _.ou.setTimeout;
        b.prototype.m = function(g) {
            d(g, 0)
        };
        b.prototype.J = function() {
            for (; this.j && this.j.length;) {
                var g = this.j;
                this.j = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.A(l)
                    }
                }
            }
            this.j = null
        };
        b.prototype.A = function(g) {
            this.m(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.o = 0;
            this.m = void 0;
            this.j = [];
            this.H = !1;
            var h = this.A();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.A = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.ta),
                reject: g(this.J)
            }
        };
        e.prototype.ta = function(g) {
            if (g === this) this.J(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof e) this.K(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = null != g;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.C(g) : this.l(g)
            }
        };
        e.prototype.C = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.J(k);
                return
            }
            "function" == typeof h ? this.O(h, g) : this.l(g)
        };
        e.prototype.J = function(g) {
            this.I(2, g)
        };
        e.prototype.l = function(g) {
            this.I(1, g)
        };
        e.prototype.I = function(g, h) {
            if (0 != this.o) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.o);
            this.o = g;
            this.m = h;
            2 === this.o && this.G();
            this.M()
        };
        e.prototype.G = function() {
            var g = this;
            d(function() {
                if (g.v()) {
                    var h = _.ou.console;
                    "undefined" !== typeof h && h.error(g.m)
                }
            }, 1)
        };
        e.prototype.v = function() {
            if (this.H) return !1;
            var g = _.ou.CustomEvent,
                h = _.ou.Event,
                k = _.ou.dispatchEvent;
            if ("undefined" === typeof k) return !0;
            "function" === typeof g ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof h ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = _.ou.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.m;
            return k(g)
        };
        e.prototype.M = function() {
            if (null != this.j) {
                for (var g = 0; g < this.j.length; ++g) f.o(this.j[g]);
                this.j = null
            }
        };
        var f = new b;
        e.prototype.K = function(g) {
            var h = this.A();
            g.je(h.resolve, h.reject)
        };
        e.prototype.O = function(g, h) {
            var k = this.A();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(p, r) {
                return "function" == typeof p ? function(w) {
                    try {
                        l(p(w))
                    } catch (u) {
                        m(u)
                    }
                } : r
            }
            var l, m, n = new e(function(p, r) {
                l = p;
                m = r
            });
            this.je(k(g, l), k(h, m));
            return n
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.je = function(g, h) {
            function k() {
                switch (l.o) {
                    case 1:
                        g(l.m);
                        break;
                    case 2:
                        h(l.m);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.o);
                }
            }
            var l = this;
            null == this.j ? f.o(k) : this.j.push(k);
            this.H = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = _.z(g), m = l.next(); !m.done; m = l.next()) c(m.value).je(h, k)
            })
        };
        e.all = function(g) {
            var h = _.z(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function n(w) {
                    return function(u) {
                        p[w] = u;
                        r--;
                        0 == r && l(p)
                    }
                }
                var p = [],
                    r = 0;
                do p.push(void 0), r++, c(k.value).je(n(p.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    }, "es6");
    ru("Object.setPrototypeOf", function(a) {
        return a || Du
    }, "es6");
    ru("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.j = (e += Math.random() + 1).toString();
                if (g) {
                    g = _.z(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!vu(g, d)) {
                var k = new b;
                mu(g, d, {
                    value: k
                })
            }
            if (!vu(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.j] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && vu(g, d) ? g[d][this.j] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && vu(g, d) && vu(g[d], this.j)
        };
        f.prototype.delete = function(g) {
            return c(g) && vu(g, d) && vu(g[d], this.j) ? delete g[d][this.j] : !1
        };
        return f
    }, "es6");
    ru("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.A(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(_.z([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = _.A(k, "entries").call(k),
                        m = l.next();
                    if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (n) {
                    return !1
                }
            }()) return a;
        var b = new _.v.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = _.z(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.Sa ? l.Sa.value = k : (l.Sa = {
                next: this[1],
                Gb: this[1].Gb,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.Sa), this[1].Gb.next = l.Sa, this[1].Gb = l.Sa, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.Sa && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.Sa.Gb.next = h.Sa.next, h.Sa.next.Gb = h.Sa.Gb, h.Sa.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Gb = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).Sa
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).Sa) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = _.A(this, "entries").call(this), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        c.prototype[_.A(_.v.Symbol, "iterator")] = _.A(c.prototype, "entries");
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && vu(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var n = m[h];
                        if (k !== k && n.key !== n.key || k === n.key) return {
                            id: l,
                            list: m,
                            index: h,
                            Sa: n
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    Sa: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return su(function() {
                    if (l) {
                        for (; l.head != h[1];) l = l.Gb;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.Gb = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    var Nu = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[_.A(_.v.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    ru("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Nu(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    ru("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Nu(this, function(b) {
                return b
            })
        }
    }, "es6");
    var Ou = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    ru("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ou(this, b, "endsWith");
            void 0 === c && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; 0 < e && 0 < c;)
                if (d[--c] != b[--e]) return !1;
            return 0 >= e
        }
    }, "es6");
    var Pu = function(a, b, c) {
        a instanceof String && (a = String(a));
        for (var d = a.length, e = 0; e < d; e++) {
            var f = a[e];
            if (b.call(c, f, e, a)) return {
                i: e,
                Ui: f
            }
        }
        return {
            i: -1,
            Ui: void 0
        }
    };
    ru("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            return Pu(this, b, c).Ui
        }
    }, "es6");
    ru("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || Infinity === b || -Infinity === b || 0 === b) return b;
            var c = Math.floor(Math.abs(b));
            return 0 > b ? -c : c
        }
    }, "es6");
    ru("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) vu(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    ru("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    ru("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || _.A(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    ru("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== Ou(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    ru("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.A(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(_.z([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = _.A(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.j = new _.v.Map;
            if (c) {
                c = _.z(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.j.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.j.set(c, c);
            this.size = this.j.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.j.delete(c);
            this.size = this.j.size;
            return c
        };
        b.prototype.clear = function() {
            this.j.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.j.has(c)
        };
        b.prototype.entries = function() {
            return _.A(this.j, "entries").call(this.j)
        };
        b.prototype.values = function() {
            return _.A(this.j, "values").call(this.j)
        };
        b.prototype.keys = _.A(b.prototype, "values");
        b.prototype[_.A(_.v.Symbol, "iterator")] = _.A(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.j.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    ru("Number.EPSILON", function() {
        return Math.pow(2, -52)
    }, "es6");
    ru("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    ru("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    }, "es6");
    ru("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return _.A(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    ru("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return _.A(Number, "isInteger").call(Number, b) && Math.abs(b) <= _.A(Number, "MAX_SAFE_INTEGER")
        }
    }, "es6");
    ru("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return "number" === typeof b && isNaN(b)
        }
    }, "es6");
    ru("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Nu(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    ru("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                f = "undefined" != typeof _.v.Symbol && _.A(_.v.Symbol, "iterator") && b[_.A(_.v.Symbol, "iterator")];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    ru("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            0 > c && (c = Math.max(0, e + c));
            if (null == d || d > e) d = e;
            d = Number(d);
            0 > d && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    }, "es6");
    var Qu = function(a) {
        return a ? a : _.A(Array.prototype, "fill")
    };
    ru("Int8Array.prototype.fill", Qu, "es6");
    ru("Uint8Array.prototype.fill", Qu, "es6");
    ru("Uint8ClampedArray.prototype.fill", Qu, "es6");
    ru("Int16Array.prototype.fill", Qu, "es6");
    ru("Uint16Array.prototype.fill", Qu, "es6");
    ru("Int32Array.prototype.fill", Qu, "es6");
    ru("Uint32Array.prototype.fill", Qu, "es6");
    ru("Float32Array.prototype.fill", Qu, "es6");
    ru("Float64Array.prototype.fill", Qu, "es6");
    ru("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) vu(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    ru("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ou(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    ru("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = Ou(this, null, "repeat");
            if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    ru("globalThis", function(a) {
        return a || _.ou
    }, "es_2020");
    ru("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = Ou(this, null, "padStart");
            b -= d.length;
            c = void 0 !== c ? String(c) : " ";
            return (0 < b && c ? _.A(c, "repeat").call(c, Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    }, "es8");
    ru("AggregateError", function(a) {
        if (a) return a;
        a = function(b, c) {
            c = Error(c);
            "stack" in c && (this.stack = c.stack);
            this.errors = b;
            this.message = c.message
        };
        _.T(a, Error);
        a.prototype.name = "AggregateError";
        return a
    }, "es_2021");
    ru("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : _.A(Array, "from").call(Array, b);
            return _.v.Promise.all(b.map(function(c) {
                return _.v.Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new _.v.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    ru("Array.prototype.findIndex", function(a) {
        return a ? a : function(b, c) {
            return Pu(this, b, c).i
        }
    }, "es6");
    ru("Object.fromEntries", function(a) {
        return a ? a : function(b) {
            var c = {};
            if (!(_.A(_.v.Symbol, "iterator") in b)) throw new TypeError("" + b + " is not iterable");
            b = b[_.A(_.v.Symbol, "iterator")].call(b);
            for (var d = b.next(); !d.done; d = b.next()) {
                d = d.value;
                if (Object(d) !== d) throw new TypeError("iterable for fromEntries should yield objects");
                c[d[0]] = d[1]
            }
            return c
        }
    }, "es_2019");
    ru("Object.hasOwn", function(a) {
        return a ? a : function(b, c) {
            return Object.prototype.hasOwnProperty.call(b, c)
        }
    }, "es_next");
    ru("Promise.prototype.finally", function(a) {
        return a ? a : function(b) {
            return this.then(function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    return c
                })
            }, function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    throw c;
                })
            })
        }
    }, "es9");
    ru("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = void 0 === b ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && 0 < b ? (d = _.A(Array.prototype, "flat").call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    }, "es9");
    ru("String.raw", function(a) {
        return a ? a : function(b, c) {
            if (null == b) throw new TypeError("Cannot convert undefined or null to object");
            for (var d = b.raw, e = d.length, f = "", g = 0; g < e; ++g) f += d[g], g + 1 < e && g + 1 < arguments.length && (f += String(arguments[g + 1]));
            return f
        }
    }, "es6");
    ru("Math.sign", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            return 0 === b || isNaN(b) ? b : 0 < b ? 1 : -1
        }
    }, "es6");
    ru("String.fromCodePoint", function(a) {
        return a ? a : function(b) {
            for (var c = "", d = 0; d < arguments.length; d++) {
                var e = Number(arguments[d]);
                if (0 > e || 1114111 < e || e !== Math.floor(e)) throw new RangeError("invalid_code_point " + e);
                65535 >= e ? c += String.fromCharCode(e) : (e -= 65536, c += String.fromCharCode(e >>> 10 & 1023 | 55296), c += String.fromCharCode(e & 1023 | 56320))
            }
            return c
        }
    }, "es6");
    ru("Array.prototype.flatMap", function(a) {
        return a ? a : function(b, c) {
            var d = [];
            Array.prototype.forEach.call(this, function(e, f) {
                e = b.call(c, e, f, this);
                Array.isArray(e) ? d.push.apply(d, e) : d.push(e)
            });
            return d
        }
    }, "es9");
    var Ru, Cc, Su, Tu, Uu, Vu;
    _.t = this || self;
    Ru = function(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = _.t, e = 0; e < c.length; e++)
                if (d = d[c[e]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    };
    Cc = function(a) {
        var b = typeof a;
        return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
    };
    _.ta = function(a) {
        var b = Cc(a);
        return "array" == b || "object" == b && "number" == typeof a.length
    };
    _.ka = function(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    };
    _.ma = function(a) {
        return Object.prototype.hasOwnProperty.call(a, Su) && a[Su] || (a[Su] = ++Tu)
    };
    Su = "closure_uid_" + (1E9 * Math.random() >>> 0);
    Tu = 0;
    Uu = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    };
    Vu = function(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    };
    _.Wu = function(a, b, c) {
        _.Wu = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Uu : Vu;
        return _.Wu.apply(null, arguments)
    };
    _.Xu = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    };
    var Yu;
    var cv, $u, Zu;
    _.av = function(a, b) {
        this.j = a === Zu && b || "";
        this.o = $u
    };
    _.av.prototype.ob = !0;
    _.av.prototype.Za = function() {
        return this.j
    };
    _.bv = function(a) {
        return a instanceof _.av && a.constructor === _.av && a.o === $u ? a.j : "type_error:Const"
    };
    cv = function(a) {
        return new _.av(Zu, a)
    };
    $u = {};
    Zu = {};
    var qb = cv("https://tpc.googlesyndication.com/sodar/%{basename}.js");
    var dv, Mt, Gi;
    dv = function() {
        return !0
    };
    Mt = function(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    };
    Gi = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    _.ev = function(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = null;
                c()
            }
        }
    };
    _.fv = function(a, b) {
        var c = 0,
            d = !1,
            e = [],
            f = function() {
                c = 0;
                d && (d = !1, g())
            },
            g = function() {
                c = _.t.setTimeout(f, b);
                var h = e;
                e = [];
                a.apply(void 0, h)
            };
        return function(h) {
            e = arguments;
            c ? d = !0 : g()
        }
    };
    var da;
    _.gv = {
        passive: !0
    };
    da = Gi(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            _.t.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });
    _.jb = function(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, ea(d)), !0) : !1
    };
    _.uf = function(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, ea(d)), !0) : !1
    };
    _.fa = function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    };
    _.hv = function(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    _.Zg = function(a, b) {
        return Array.prototype.filter.call(a, b, void 0)
    };
    _.iv = function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    };
    _.ah = function(a, b) {
        return Array.prototype.some.call(a, b, void 0)
    };
    var yc = function(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Da = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
    var jv = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var Ye;
    Ye = {};
    _.Xe = function(a) {
        this.j = a;
        this.ob = !0
    };
    _.Xe.prototype.toString = function() {
        return this.j.toString()
    };
    _.Xe.prototype.Za = function() {
        return this.j.toString()
    };
    _.fb = function(a) {
        return a instanceof _.Xe && a.constructor === _.Xe ? a.j : "type_error:SafeScript"
    };
    var pb, pv, ov, lv, qv, Ue, mv;
    _.kv = function(a) {
        this.j = a
    };
    _.kv.prototype.toString = function() {
        return this.j + ""
    };
    _.kv.prototype.ob = !0;
    _.kv.prototype.Za = function() {
        return this.j.toString()
    };
    _.nv = function(a, b) {
        a = lv.exec(_.hb(a).toString());
        var c = a[3] || "";
        return Ue(a[1] + mv("?", a[2] || "", b) + mv("#", c))
    };
    _.hb = function(a) {
        return a instanceof _.kv && a.constructor === _.kv ? a.j : "type_error:TrustedResourceUrl"
    };
    pb = function(a, b) {
        var c = _.bv(a);
        if (!ov.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(pv, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof _.av ? _.bv(d) : encodeURIComponent(String(d))
        });
        return Ue(a)
    };
    pv = /%{(\w+)}/g;
    ov = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i");
    lv = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;
    qv = {};
    Ue = function(a) {
        return new _.kv(a, qv)
    };
    mv = function(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var rv, al, sv, Av, uv, vv, wv, xv, yv, zv, tv;
    rv = function(a, b) {
        var c = a.length - b.length;
        return 0 <= c && a.indexOf(b, c) == c
    };
    al = function(a) {
        return /^[\s\xa0]*$/.test(a)
    };
    sv = function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    };
    Av = function(a) {
        if (!tv.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(uv, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(vv, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(wv, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(xv, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(yv, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(zv, "&#0;"));
        return a
    };
    uv = /&/g;
    vv = /</g;
    wv = />/g;
    xv = /"/g;
    yv = /'/g;
    zv = /\x00/g;
    tv = /[\x00&<>"']/;
    _.Ja = function(a, b) {
        return -1 != a.indexOf(b)
    };
    var Bv, Cv, Ev, Fv, Hv, Ua;
    _.Ta = function(a) {
        this.j = a
    };
    _.Ta.prototype.toString = function() {
        return this.j.toString()
    };
    _.Ta.prototype.ob = !0;
    _.Ta.prototype.Za = function() {
        return this.j.toString()
    };
    _.ab = function(a) {
        return a instanceof _.Ta && a.constructor === _.Ta ? a.j : "type_error:SafeUrl"
    };
    Bv = /^data:(.*);base64,[a-z0-9+\/]+=*$/i;
    Cv = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;
    _.Dv = function(a) {
        if (a instanceof _.Ta) return a;
        a = "object" == typeof a && a.ob ? a.Za() : String(a);
        Cv.test(a) ? a = Ua(a) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(Bv) ? Ua(a) : null);
        return a
    };
    try {
        new URL("s://g"), Ev = !0
    } catch (a) {
        Ev = !1
    }
    Fv = Ev;
    _.Gv = function(a) {
        if (a instanceof _.Ta) return a;
        a = "object" == typeof a && a.ob ? a.Za() : String(a);
        a: {
            var b = a;
            if (Fv) {
                try {
                    var c = new URL(b)
                } catch (d) {
                    b = "https:";
                    break a
                }
                b = c.protocol
            } else b: {
                c = document.createElement("a");
                try {
                    c.href = b
                } catch (d) {
                    b = void 0;
                    break b
                }
                b = c.protocol;b = ":" === b || "" === b ? "https:" : b
            }
        }
        "javascript:" === b && (a = "about:invalid#zClosurez");
        return Ua(a)
    };
    Hv = {};
    Ua = function(a) {
        return new _.Ta(a, Hv)
    };
    _.Va = Ua("about:invalid#zClosurez");
    _.Iv = {};
    _.Jv = function(a) {
        this.j = a;
        this.ob = !0
    };
    _.Jv.prototype.Za = function() {
        return this.j
    };
    _.Jv.prototype.toString = function() {
        return this.j.toString()
    };
    _.Kv = new _.Jv("", _.Iv);
    _.Lv = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$");
    _.Mv = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g");
    _.Nv = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g");
    var Ov;
    Ov = {};
    _.Pv = function(a) {
        this.j = a;
        this.ob = !0
    };
    _.Pv.prototype.toString = function() {
        return this.j.toString()
    };
    _.Pv.prototype.Za = function() {
        return this.j
    };
    _.Qv = function(a) {
        return a instanceof _.Pv && a.constructor === _.Pv ? a.j : "type_error:SafeStyleSheet"
    };
    var Ha = Ru(610401301, !1),
        Rv = Ru(572417392, Ru(1, !0));
    var Ia, Sv = _.t.navigator;
    Ia = Sv ? Sv.userAgentData || null : null;
    var Tv, Wv, aw, Xv, cw, Yv, $v;
    Tv = {};
    _.Uv = function(a) {
        this.j = a;
        this.ob = !0
    };
    _.Uv.prototype.Za = function() {
        return this.j.toString()
    };
    _.Uv.prototype.toString = function() {
        return this.j.toString()
    };
    _.Vv = function(a) {
        return a instanceof _.Uv && a.constructor === _.Uv ? a.j : "type_error:SafeHtml"
    };
    Wv = function(a) {
        return a instanceof _.Uv ? a : _.sj(Av("object" == typeof a && a.ob ? a.Za() : String(a)))
    };
    _.Zv = function(a) {
        if (!Xv.test(a)) throw Error("");
        if (a.toUpperCase() in Yv) throw Error("");
    };
    aw = function(a) {
        var b = Wv($v),
            c = [],
            d = function(e) {
                Array.isArray(e) ? e.forEach(d) : (e = Wv(e), c.push(_.Vv(e).toString()))
            };
        a.forEach(d);
        return _.sj(c.join(_.Vv(b).toString()))
    };
    _.bw = function(a) {
        return aw(Array.prototype.slice.call(arguments))
    };
    _.sj = function(a) {
        return new _.Uv(a, Tv)
    };
    _.dw = function(a, b, c) {
        var d = "";
        if (b)
            for (var e in b)
                if (Object.prototype.hasOwnProperty.call(b, e)) {
                    if (!Xv.test(e)) throw Error("");
                    var f = b[e];
                    if (null != f) {
                        var g = e;
                        if (f instanceof _.av) f = _.bv(f);
                        else {
                            if ("style" == g.toLowerCase()) throw Error("");
                            if (/^on/i.test(g)) throw Error("");
                            if (g.toLowerCase() in cw)
                                if (f instanceof _.kv) f = _.hb(f).toString();
                                else if (f instanceof _.Ta) f = _.ab(f);
                            else if ("string" === typeof f) f = (_.Dv(f) || _.Va).Za();
                            else throw Error("");
                        }
                        f.ob && (f = f.Za());
                        f = g + '="' + Av(String(f)) + '"';
                        d += " " + f
                    }
                }
        b = "<" + a + d;
        null == c ? c = [] : Array.isArray(c) || (c = [c]);
        !0 === jv[a.toLowerCase()] ? b += ">" : (c = _.bw(c), b += ">" + _.Vv(c).toString() + "</" + a + ">");
        return _.sj(b)
    };
    Xv = /^[a-zA-Z0-9-]+$/;
    cw = {
        action: !0,
        cite: !0,
        data: !0,
        formaction: !0,
        href: !0,
        manifest: !0,
        poster: !0,
        src: !0
    };
    Yv = {
        APPLET: !0,
        BASE: !0,
        EMBED: !0,
        IFRAME: !0,
        LINK: !0,
        MATH: !0,
        META: !0,
        OBJECT: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    };
    $v = new _.Uv(_.t.trustedTypes && _.t.trustedTypes.emptyHTML || "", Tv);
    _.ew = _.sj("<br>");
    var Oa = function(a) {
            this.Pk = a
        },
        Sa = [Pa("data"), Pa("http"), Pa("https"), Pa("mailto"), Pa("ftp"), new Oa(function(a) {
            return /^[^:]*([/?#]|$)/.test(a)
        })],
        Za = "function" === typeof URL;
    var fw = {
            Nm: 0,
            Qm: 1,
            Lm: 2,
            Mm: 3,
            0: "FORMATTED_HTML_CONTENT",
            1: "HTML_FORMATTED_CONTENT",
            2: "EMBEDDED_INTERNAL_CONTENT",
            3: "EMBEDDED_TRUSTED_EXTERNAL_CONTENT"
        },
        gw = function(a, b) {
            b = Error.call(this, a + " cannot be used with intent " + fw[b]);
            this.message = b.message;
            "stack" in b && (this.stack = b.stack);
            this.type = a;
            this.name = "TypeCannotBeUsedWithIntentError"
        };
    _.T(gw, Error);
    var mb = function(a) {
        return new _.v.Promise(function(b, c) {
            var d = new XMLHttpRequest;
            d.onreadystatechange = function() {
                d.readyState === d.DONE && (200 <= d.status && 300 > d.status ? b(JSON.parse(d.responseText)) : c())
            };
            d.open("GET", a, !0);
            d.send()
        })
    };
    var tb, sb = "undefined" !== typeof TextEncoder;
    _.hw = function(a) {
        _.hw[" "](a);
        return a
    };
    _.hw[" "] = function() {};
    var iw = function(a, b) {
        try {
            return _.hw(a[b]), !0
        } catch (c) {}
        return !1
    };
    var jw, lw, mw, nw, ow, pw;
    jw = Ma() ? !1 : La("Opera");
    _.kw = Ma() ? !1 : La("Trident") || La("MSIE");
    lw = La("Edge");
    mw = La("Gecko") && !(_.Ja(Fa().toLowerCase(), "webkit") && !La("Edge")) && !(La("Trident") || La("MSIE")) && !La("Edge");
    nw = _.Ja(Fa().toLowerCase(), "webkit") && !La("Edge");
    ow = function() {
        var a = _.t.document;
        return a ? a.documentMode : void 0
    };
    a: {
        var qw = "",
            rw = function() {
                var a = Fa();
                if (mw) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (lw) return /Edge\/([\d\.]+)/.exec(a);
                if (_.kw) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (nw) return /WebKit\/(\S+)/.exec(a);
                if (jw) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();rw && (qw = rw ? rw[1] : "");
        if (_.kw) {
            var sw = ow();
            if (null != sw && sw > parseFloat(qw)) {
                pw = String(sw);
                break a
            }
        }
        pw = qw
    }
    var tw = pw,
        uw;
    if (_.t.document && _.kw) {
        var vw = ow();
        uw = vw ? vw : parseInt(tw, 10) || void 0
    } else uw = void 0;
    var ww = uw;
    !La("Android") || Na();
    Na();
    La("Safari") && (Na() || (Ma() ? 0 : La("Coast")) || (Ma() ? 0 : La("Opera")) || (Ma() ? 0 : La("Edge")) || (Ma() ? Ka("Microsoft Edge") : La("Edg/")) || Ma() && Ka("Opera"));
    var xw = {},
        yw = null,
        zw = mw || nw || "function" == typeof _.t.btoa,
        Ab = function(a, b) {
            void 0 === b && (b = 0);
            Aw();
            b = xw[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    k = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | k >> 6];
                k = b[k & 63];
                c[f++] = l + g + h + k
            }
            l = 0;
            k = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
            }
            return c.join("")
        },
        Bw = function(a, b) {
            if (zw && !b) a = _.t.btoa(a);
            else {
                for (var c = [], d = 0, e = 0; e < a.length; e++) {
                    var f = a.charCodeAt(e);
                    255 < f && (c[d++] = f & 255, f >>= 8);
                    c[d++] = f
                }
                a = Ab(c, b)
            }
            return a
        },
        Bq = function(a) {
            var b = "";
            Cw(a, function(c) {
                b += String.fromCharCode(c)
            });
            return b
        },
        af = function(a) {
            var b = [];
            Cw(a, function(c) {
                b.push(c)
            });
            return b
        },
        Dw = function(a) {
            var b = a.length,
                c = 3 * b / 4;
            c % 3 ? c = Math.floor(c) : _.Ja("=.", a[b - 1]) && (c = _.Ja("=.", a[b - 2]) ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            Cw(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        Cw = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = yw[l];
                    if (null != m) return m;
                    if (!al(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            Aw();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        Aw = function() {
            if (!yw) {
                yw = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    xw[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === yw[f] && (yw[f] = e)
                    }
                }
            }
        };
    var Fb = "undefined" !== typeof Uint8Array,
        yb = !_.kw && "function" === typeof btoa,
        Ew = /[-_.]/g,
        Db = {
            "-": "+",
            _: "/",
            ".": "="
        },
        Fw, Hb = {};
    var Gw, mc = function(a, b) {
            Ib(b);
            this.ga = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        },
        nc = function() {
            return Gw || (Gw = new mc(null, Hb))
        },
        Ad = function(a) {
            var b = a.ga;
            return null == b ? "" : "string" === typeof b ? b : a.ga = Cb(b)
        },
        Ek = function(a) {
            Ib(Hb);
            var b = a.ga;
            if (null != b && !Gb(b))
                if ("string" === typeof b)
                    if (yb) {
                        Ew.test(b) && (b = b.replace(Ew, Eb));
                        b = atob(b);
                        for (var c = new Uint8Array(b.length), d = 0; d < b.length; d++) c[d] = b.charCodeAt(d);
                        b = c
                    } else b = Dw(b);
            else b = null;
            return (a = null == b ? b : a.ga = b) ? new Uint8Array(a) : Fw || (Fw = new Uint8Array(0))
        };
    mc.prototype.isEmpty = function() {
        return null == this.ga
    };
    var Dd = !Rv,
        oe = !Rv;
    var Lb = 0,
        Mb = 0,
        Hw;
    var Iw = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        Kw = function(a) {
            if (!a) return Jw || (Jw = new Iw(0, 0));
            if (!/^\d+$/.test(a)) return null;
            Sb(a);
            return new Iw(Lb, Mb)
        },
        Jw, Lw = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        Fe = function(a) {
            if (!a) return Mw || (Mw = new Lw(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            Sb(a);
            return new Lw(Lb, Mb)
        },
        Mw;
    var Nw = function() {
        this.j = []
    };
    Nw.prototype.length = function() {
        return this.j.length
    };
    Nw.prototype.end = function() {
        var a = this.j;
        this.j = [];
        return a
    };
    var He = function(a, b, c) {
            for (; 0 < c || 127 < b;) a.j.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
            a.j.push(b)
        },
        Ge = function(a, b) {
            for (; 127 < b;) a.j.push(b & 127 | 128), b >>>= 7;
            a.j.push(b)
        },
        Ow = function(a, b) {
            if (0 <= b) Ge(a, b);
            else {
                for (var c = 0; 9 > c; c++) a.j.push(b & 127 | 128), b >>= 7;
                a.j.push(1)
            }
        };
    var Ne = function() {
            this.m = [];
            this.o = 0;
            this.j = new Nw
        },
        Je = function(a, b) {
            0 !== b.length && (a.m.push(b), a.o += b.length)
        },
        Pw = function(a, b, c) {
            Ge(a.j, 8 * b + 2);
            Ge(a.j, c.length);
            Je(a, a.j.end());
            Je(a, c)
        };
    var ze = function(a, b) {
        this.j = a;
        this.ej = b
    };
    var Qw = "function" === typeof _.v.Symbol && "symbol" === typeof(0, _.v.Symbol)() ? (0, _.v.Symbol)() : void 0,
        Zb = Qw ? function(a, b) {
            a[Qw] |= b
        } : function(a, b) {
            void 0 !== a.pb ? a.pb |= b : Object.defineProperties(a, {
                pb: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        },
        Ud = Qw ? function(a, b) {
            a[Qw] &= ~b
        } : function(a, b) {
            void 0 !== a.pb && (a.pb &= ~b)
        },
        Vb = Qw ? function(a) {
            return a[Qw] | 0
        } : function(a) {
            return a.pb | 0
        },
        Kd = Qw ? function(a) {
            return a[Qw]
        } : function(a) {
            return a.pb
        },
        Wb = Qw ? function(a, b) {
            a[Qw] = b
        } : function(a, b) {
            void 0 !== a.pb ? a.pb = b : Object.defineProperties(a, {
                pb: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };
    var fd = {},
        gc = {},
        Rw, zd = !Rv,
        Td, Sw = [];
    Wb(Sw, 55);
    Td = Object.freeze(Sw);
    var Tw = function(a, b, c) {
        this.m = 0;
        this.j = a;
        this.o = b;
        this.A = c
    };
    Tw.prototype.next = function() {
        if (this.m < this.j.length) {
            var a = this.j[this.m++];
            return {
                done: !1,
                value: this.o ? this.o.call(this.A, a) : a
            }
        }
        return {
            done: !0,
            value: void 0
        }
    };
    Tw.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return new Tw(this.j, this.o, this.A)
    };
    var de = {};
    var rc;
    var Fc = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/,
        id = "function" === typeof _.v.Symbol && "symbol" === typeof(0, _.v.Symbol)() ? (0, _.v.Symbol)() : "di";
    var md, od, pd;
    var Uw = function() {
            try {
                var a = function() {
                    return yu(_.v.Map, [], this.constructor)
                };
                _.T(a, _.v.Map);
                new a;
                return !1
            } catch (b) {
                return !0
            }
        }(),
        Vw = function() {
            this.j = new _.v.Map
        };
    _.q = Vw.prototype;
    _.q.get = function(a) {
        return this.j.get(a)
    };
    _.q.set = function(a, b) {
        this.j.set(a, b);
        this.size = this.j.size;
        return this
    };
    _.q.delete = function(a) {
        a = this.j.delete(a);
        this.size = this.j.size;
        return a
    };
    _.q.clear = function() {
        this.j.clear();
        this.size = this.j.size
    };
    _.q.has = function(a) {
        return this.j.has(a)
    };
    _.q.entries = function() {
        return _.A(this.j, "entries").call(this.j)
    };
    _.q.keys = function() {
        return _.A(this.j, "keys").call(this.j)
    };
    _.q.values = function() {
        return _.A(this.j, "values").call(this.j)
    };
    _.q.forEach = function(a, b) {
        return this.j.forEach(a, b)
    };
    Vw.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return _.A(this, "entries").call(this)
    };
    var Ww = function() {
            if (Uw) return _.A(Object, "setPrototypeOf").call(Object, Vw.prototype, _.v.Map.prototype), Object.defineProperties(Vw.prototype, {
                size: {
                    value: 0,
                    configurable: !0,
                    enumerable: !0,
                    writable: !0
                }
            }), Vw;
            var a = function() {
                return yu(_.v.Map, [], this.constructor)
            };
            _.T(a, _.v.Map);
            return a
        }(),
        Bd = function(a, b, c, d) {
            c = void 0 === c ? jd : c;
            d = void 0 === d ? jd : d;
            var e = Ww.call(this) || this;
            var f = Vb(a);
            f |= 64;
            Wb(a, f);
            e.ce = f;
            e.sf = b;
            e.Ed = c || jd;
            e.Tg = e.sf ? ud : d || jd;
            for (var g = 0; g < a.length; g++) {
                var h = a[g],
                    k = c(h[0], !1, !0),
                    l = h[1];
                b ? void 0 === l && (l = null) : l = d(h[1], !1, !0, void 0, void 0, f);
                Ww.prototype.set.call(e, k, l)
            }
            return e
        };
    _.T(Bd, Ww);
    var Xw = function(a) {
            if (a.ce & 2) throw Error("Cannot mutate an immutable Map");
        },
        Cd = function(a, b) {
            b = void 0 === b ? vd : b;
            return Md(a, b)
        },
        Md = function(a, b) {
            b = void 0 === b ? vd : b;
            var c = [];
            a = _.A(Ww.prototype, "entries").call(a);
            for (var d; !(d = a.next()).done;) d = d.value, d[0] = b(d[0]), d[1] = b(d[1]), c.push(d);
            return c
        };
    _.q = Bd.prototype;
    _.q.clear = function() {
        Xw(this);
        Ww.prototype.clear.call(this)
    };
    _.q.delete = function(a) {
        Xw(this);
        return Ww.prototype.delete.call(this, this.Ed(a, !0, !1))
    };
    _.q.entries = function() {
        var a = _.A(Array, "from").call(Array, _.A(Ww.prototype, "keys").call(this));
        return new Tw(a, wd, this)
    };
    _.q.keys = function() {
        return _.A(Ww.prototype, "keys").call(this)
    };
    _.q.values = function() {
        var a = _.A(Array, "from").call(Array, _.A(Ww.prototype, "keys").call(this));
        return new Tw(a, Bd.prototype.get, this)
    };
    _.q.forEach = function(a, b) {
        var c = this;
        Ww.prototype.forEach.call(this, function(d, e) {
            a.call(b, c.get(e), e, c)
        })
    };
    _.q.set = function(a, b) {
        Xw(this);
        a = this.Ed(a, !0, !1);
        return null == a ? this : null == b ? (Ww.prototype.delete.call(this, a), this) : Ww.prototype.set.call(this, a, this.Tg(b, !0, !0, this.sf, !1, this.ce))
    };
    _.q.has = function(a) {
        return Ww.prototype.has.call(this, this.Ed(a, !1, !1))
    };
    _.q.get = function(a) {
        a = this.Ed(a, !1, !1);
        var b = Ww.prototype.get.call(this, a);
        if (void 0 !== b) {
            var c = this.sf;
            return c ? (c = this.Tg(b, !1, !0, c, this.Dj, this.ce), c !== b && Ww.prototype.set.call(this, a, c), c) : b
        }
    };
    Bd.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return _.A(this, "entries").call(this)
    };
    Bd.prototype.toJSON = void 0;
    Bd.prototype.Wk = gc;
    Object.freeze({});
    var Pd, jo, Sd, In, Op, Pl, Fk, ce, yk, Gk, Dk, Qo, Yw, rs, Gj, Np, ai, Zw, $w, Kr, hr, bx, dx, ex, Io, fx, gx, hx, Fj, Vn, ix;
    Pd = (0, _.v.Symbol)();
    jo = function(a, b) {
        a = a.D;
        return Sd(a, Kd(a), b)
    };
    Sd = function(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= fc(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < e) return a[b]
        }
    };
    _.Ai = function(a, b, c) {
        var d = a.D,
            e = Kd(d);
        qc(e);
        Rd(d, e, b, c);
        return a
    };
    In = function(a, b, c) {
        return void 0 !== Yw(a, b, c, !1)
    };
    Op = function(a) {
        a = a.D;
        var b = Kd(a),
            c = Sd(a, b, 3),
            d = Bc(c);
        null != d && d !== c && Rd(a, b, 3, d);
        return d
    };
    Pl = function(a, b) {
        return Ec(jo(a, b))
    };
    Fk = function(a, b) {
        a = a.D;
        var c = Kd(a),
            d = Sd(a, c, b),
            e = oc(d, !0, !!(c & 34));
        null != e && e !== d && Rd(a, c, b, e);
        return null == e ? nc() : e
    };
    _.Uh = function(a, b, c) {
        return _.ie(a, b, c, cd)
    };
    yk = function(a, b, c, d) {
        var e = a.D,
            f = Kd(e);
        qc(f);
        (c = ke(e, f, c)) && c !== b && null != d && (f = Rd(e, f, c));
        Rd(e, f, b, d);
        return a
    };
    Gk = function(a, b, c) {
        a = a.D;
        return ke(a, Kd(a), b) === c ? c : -1
    };
    Dk = function(a, b) {
        a = a.D;
        return ke(a, Kd(a), b)
    };
    Qo = function(a, b, c) {
        a = a.D;
        var d = Kd(a);
        qc(d);
        var e = Sd(a, d, c);
        b = td(hd(e, b, !0, d));
        e !== b && Rd(a, d, c, b);
        return b
    };
    Yw = function(a, b, c, d) {
        a = a.D;
        var e = Kd(a),
            f = Sd(a, e, c, d);
        b = hd(f, b, !1, e);
        b !== f && null != b && Rd(a, e, c, b, d);
        return b
    };
    rs = function(a, b, c) {
        return (a = Yw(a, b, c, !1)) ? a : gd(b)
    };
    _.Zh = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        b = Yw(a, b, c, d);
        if (null == b) return b;
        a = a.D;
        var e = Kd(a);
        if (!(e & 2)) {
            var f = td(b);
            f !== b && (b = f, Rd(a, e, c, b, d))
        }
        return b
    };
    _.bi = function(a, b, c) {
        a = a.D;
        var d = Kd(a),
            e = !!(2 & d);
        return le(a, d, b, c, e ? 1 : 2, !1, !e)
    };
    _.th = function(a, b, c) {
        null == c && (c = void 0);
        return _.Ai(a, b, c)
    };
    _.zh = function(a, b, c, d) {
        null == d && (d = void 0);
        return yk(a, b, c, d)
    };
    _.ol = function(a, b, c) {
        var d = a.D,
            e = Kd(d);
        qc(e);
        if (null == c) return Rd(d, e, b), a;
        for (var f = Vb(c), g = f, h = !!(2 & f) || !!(2048 & f), k = h || Object.isFrozen(c), l = !k && !1, m = !0, n = !0, p = 0; p < c.length; p++) {
            var r = c[p];
            h || (r = !!(Vb(r.D) & 2), m && (m = !r), n && (n = r))
        }
        h || (f = Yb(f, 5, !0), f = Yb(f, 8, m), f = Yb(f, 16, n), l && (f = Yb(f, n ? 2 : 2048, !0)), f !== g && (k && (c = Tb(c), f = Wd(f, e, !0)), Wb(c, f)), l && Object.freeze(c));
        Rd(d, e, b, c);
        return a
    };
    Gj = function(a, b, c, d) {
        me(a, b, c, d);
        return a
    };
    Np = function(a, b) {
        return Mc(jo(a, b))
    };
    ai = function(a, b) {
        return Pc(jo(a, b))
    };
    Zw = function(a, b) {
        a = jo(a, b);
        a = null == a ? a : Gc(a) ? "number" === typeof a ? Yc(a) : Zc(a, !1) : void 0;
        return a
    };
    $w = function(a, b) {
        return Xd(a, b, $c, void 0, void 0, void 0, 0)
    };
    _.Aj = function(a, b) {
        return ed(jo(a, b))
    };
    _.jl = function(a, b, c, d, e) {
        return Xd(a, b, ed, c, d, e)
    };
    _.N = function(a, b, c) {
        return ne(Pl(a, b), void 0 === c ? !1 : c)
    };
    _.ax = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return ne(Np(a, b), c)
    };
    Kr = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return ne(ai(a, b), c)
    };
    _.sf = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return ne($c(jo(a, b)), c)
    };
    hr = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return ne(Zw(a, b), c)
    };
    _.R = function(a, b) {
        return ne(_.Aj(a, b), "")
    };
    _.Hk = function(a, b, c) {
        return ne(jo(a, b), void 0 === c ? 0 : c)
    };
    bx = function(a, b, c) {
        a = _.jl(a, b, void 0, 3, !0);
        if ("number" !== typeof c || 0 > c || c >= a.length) throw Error();
        return a[c]
    };
    dx = function(a) {
        return _.sf(a, Gk(a, cx, 3))
    };
    ex = function(a, b) {
        return _.R(a, Gk(a, b, 2))
    };
    Io = function(a, b) {
        a = Pl(a, b);
        return null == a ? void 0 : a
    };
    fx = function(a, b) {
        a = Np(a, b);
        return null == a ? void 0 : a
    };
    gx = function(a, b) {
        a = _.Aj(a, b);
        return null == a ? void 0 : a
    };
    hx = function(a, b) {
        a = jo(a, b);
        return null == a ? void 0 : a
    };
    Fj = function(a, b, c) {
        return _.Ai(a, b, null == c ? c : Dc(c))
    };
    _.xh = function(a, b, c) {
        return _.je(a, b, null == c ? c : Dc(c), !1)
    };
    _.So = function(a, b, c) {
        return _.Ai(a, b, null == c ? c : Lc(c))
    };
    _.yh = function(a, b, c) {
        return _.je(a, b, null == c ? c : Lc(c), 0)
    };
    _.xk = function(a, b, c) {
        return _.Ai(a, b, Uc(c))
    };
    _.qh = function(a, b, c) {
        return _.je(a, b, Uc(c), "0")
    };
    Vn = function(a, b, c) {
        return _.Ai(a, b, dd(c))
    };
    _.rh = function(a, b, c) {
        return _.je(a, b, dd(c), "")
    };
    _.ko = function(a, b, c) {
        return _.Ai(a, b, null == c ? c : Jc(c))
    };
    _.I = function(a, b, c) {
        return _.je(a, b, null == c ? c : Jc(c), 0)
    };
    ix = function(a, b, c) {
        var d = a.D,
            e = Kd(d);
        qc(e);
        b = Vd(d, e, b, 2);
        d = Vb(b);
        c = cd(c, !!(4 & d) && !!(4096 & d));
        b.push(c);
        return a
    };
    _.F = function(a, b, c) {
        this.D = _.B(a, b, c)
    };
    _.F.prototype.toJSON = function() {
        if (Rw) var a = pe(this, this.D, !1);
        else a = Fd(this.D, Hd, void 0, void 0, !1, !1), a = pe(this, a, !0);
        return a
    };
    var Ak = function(a) {
        Rw = !0;
        try {
            return JSON.stringify(a.toJSON(), yd)
        } finally {
            Rw = !1
        }
    };
    _.F.prototype.jg = fd;
    var se = (0, _.v.Symbol)(),
        ye = (0, _.v.Symbol)(),
        Be = (0, _.v.Symbol)(),
        jx = Ee(function(a, b, c) {
            b = Bc(b);
            null != b && (Ge(a.j, 8 * c + 5), a = a.j, c = Hw || (Hw = new DataView(new ArrayBuffer(8))), c.setFloat32(0, +b, !0), Mb = 0, b = Lb = c.getUint32(0, !0), a.j.push(b >>> 0 & 255), a.j.push(b >>> 8 & 255), a.j.push(b >>> 16 & 255), a.j.push(b >>> 24 & 255))
        }),
        kx = Ee(Ie),
        lx = Ee(Ie),
        mx = Ee(function(a, b, c) {
            a: if (null != b) {
                if (Gc(b)) {
                    if ("string" === typeof b) {
                        b = Zc(b, !1);
                        break a
                    }
                    if ("number" === typeof b) {
                        b = Yc(b);
                        break a
                    }
                }
                b = void 0
            }null != b && ("string" === typeof b && Kw(b), null != b && (Ge(a.j, 8 * c), "number" === typeof b ? (a = a.j, Ob(b), He(a, Lb, Mb)) : (c = Kw(b), He(a.j, c.o, c.j))))
        }),
        nx = Ee(function(a, b, c) {
            b = Mc(b);
            null != b && null != b && (Ge(a.j, 8 * c), Ow(a.j, b))
        }),
        ox = Ee(function(a, b, c) {
            b = Ec(b);
            null != b && (Ge(a.j, 8 * c), a.j.j.push(b ? 1 : 0))
        }),
        px = Ee(function(a, b, c) {
            b = ed(b);
            null != b && Pw(a, c, ub(b))
        }),
        qx;
    qx = new ze(function(a, b, c) {
        if (Array.isArray(b)) {
            var d = Vb(b);
            if (!(d & 4)) {
                for (var e = 0, f = 0; e < b.length; e++) {
                    var g = ed(b[e]);
                    null != g && (b[f++] = g)
                }
                f < e && (b.length = f);
                Wb(b, (d | 5) & -12289);
                d & 2 && Object.freeze(b)
            }
        } else b = void 0;
        if (null != b)
            for (d = 0; d < b.length; d++) e = b[d], null != e && Pw(a, c, ub(e))
    }, !1);
    var Ce = new ze(Ke, !0),
        Ae = new ze(Ke, !0),
        rx;
    rx = new ze(function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++) Ke(a, b[f], c, d, e)
    }, !0);
    var sx = Ee(function(a, b, c) {
        b = Mc(b);
        null != b && (b = parseInt(b, 10), Ge(a.j, 8 * c), Ow(a.j, b))
    });
    var Le = void 0;
    var Cq = function(a) {
        this.D = _.B(a)
    };
    _.T(Cq, _.F);
    var Dq = function(a) {
        this.D = _.B(a)
    };
    _.T(Dq, _.F);
    var tx = function(a) {
            this.j = a.o;
            this.o = a.m;
            this.A = a.A;
            this.Dd = a.Dd;
            this.B = a.B;
            this.Yc = a.Yc;
            this.Ie = a.Ie;
            this.jf = a.jf;
            this.Ge = a.Ge;
            this.m = a.j
        },
        ux = function(a, b, c) {
            this.o = a;
            this.m = b;
            this.A = c;
            this.B = window;
            this.Yc = "env";
            this.Ie = "n";
            this.jf = "0";
            this.Ge = "1";
            this.j = !0
        };
    ux.prototype.build = function() {
        return new tx(this)
    };
    var Mq = function(a, b) {
        var c = void 0 === _.N(b, 6) ? !0 : _.N(b, 6),
            d, e, f = Qe(_.Hk(b, 2, 0)),
            g = _.R(b, 3);
        a: switch (_.Hk(b, 4, 0)) {
            case 1:
                var h = "pt";
                break a;
            case 2:
                h = "cr";
                break a;
            default:
                h = ""
        }
        f = new ux(f, g, h);
        b = null != (e = null == (d = _.Zh(b, Cq, 5)) ? void 0 : _.R(d, 1)) ? e : "";
        f.Dd = b;
        f.j = c;
        f.B = a;
        return f.build()
    };
    var so = function(a) {
        this.D = _.B(a)
    };
    _.T(so, _.F);
    so.prototype.getId = function() {
        return _.R(this, 1)
    };
    var ro = function(a, b) {
            return Vn(a, 1, b)
        },
        vx = [0, px];
    var yo = function(a) {
        this.D = _.B(a)
    };
    _.T(yo, _.F);
    yo.prototype.getWidth = function() {
        return _.ax(this, 1)
    };
    var xo = function(a, b) {
        return _.So(a, 1, b)
    };
    yo.prototype.getHeight = function() {
        return _.ax(this, 2)
    };
    var wo = function(a, b) {
            return _.So(a, 2, b)
        },
        wx = [0, nx, -1];
    var xx = [0, lx, ox];
    var po = function(a) {
        this.D = _.B(a)
    };
    _.T(po, _.F);
    var to = function(a, b) {
            _.Uh(a, 4, b)
        },
        qo = function(a, b) {
            _.th(a, 6, b)
        },
        vo = function(a, b) {
            _.th(a, 7, b)
        };
    po.ca = [4];
    var yx = [0, px, lx, px, qx, sx, vx, wx, lx, xx];
    var Un = function(a) {
        this.D = _.B(a)
    };
    _.T(Un, _.F);
    var Tn = function(a, b) {
            return _.ko(a, 1, b)
        },
        Rn = function(a, b) {
            return Fj(a, 4, b)
        },
        Sn = function(a, b) {
            return _.So(a, 2, b)
        },
        zx = [0, sx, nx, px, ox];
    var fo = function(a) {
        this.D = _.B(a)
    };
    _.T(fo, _.F);
    var eo = function(a, b) {
            return Vn(a, 1, b)
        },
        ho = function(a, b) {
            _.xk(a, 2, b)
        },
        bo = function(a, b) {
            return Gj(a, 3, po, b)
        },
        co = function(a, b) {
            return _.ko(a, 4, b)
        };
    fo.prototype.Fh = function() {
        return _.Hk(this, 7, 0)
    };
    fo.ca = [10, 3];
    var Ax = [0, px, lx, rx, yx, sx, zx, ox, sx, 2, qx];
    var Bx = function(a) {
        this.D = _.B(a)
    };
    _.T(Bx, _.F);
    var Cx = [0, sx, ox];
    var Dx = function(a) {
        this.D = _.B(a)
    };
    _.T(Dx, _.F);
    var ao = function(a, b) {
            return me(a, 2, fo, b)
        },
        mo = function(a, b) {
            _.th(a, 5, b)
        },
        Ex = function(a, b) {
            _.th(a, 9, b)
        };
    Dx.ca = [2];
    var Fx = [0, sx, rx, Ax, sx, px, zx, px, ox, nx, Cx];
    var Gx = function(a) {
        this.D = _.B(a)
    };
    _.T(Gx, _.F);
    var Hx = function(a) {
        var b = new Dx;
        b = _.ko(b, 1, 1);
        return me(a, 1, Dx, b)
    };
    Gx.ca = [1];
    Gx.prototype.j = Oe([0, rx, Fx]);
    var Ix = function(a) {
        this.D = _.B(a)
    };
    _.T(Ix, _.F);
    var cx = [2, 3];
    var Jx = function(a) {
        this.D = _.B(a)
    };
    _.T(Jx, _.F);
    Jx.ca = [1];
    var Kx = function(a) {
        this.D = _.B(a)
    };
    _.T(Kx, _.F);
    Kx.ca = [1];
    var Lx = function(a) {
        this.D = _.B(a)
    };
    _.T(Lx, _.F);
    var Mx = [2, 3];
    var Nx = function(a) {
        this.D = _.B(a)
    };
    _.T(Nx, _.F);
    Nx.ca = [2];
    var Ox = function(a) {
        this.D = _.B(a)
    };
    _.T(Ox, _.F);
    Ox.ca = [6, 4];
    var Px = function(a) {
        this.D = _.B(a)
    };
    _.T(Px, _.F);
    Px.ca = [4, 5];
    var Qx = function(a) {
        this.D = _.B(a)
    };
    _.T(Qx, _.F);
    var Rx = function(a) {
        this.D = _.B(a)
    };
    _.T(Rx, _.F);
    Rx.prototype.Fe = function() {
        return rs(this, Qx, 2)
    };
    Rx.ca = [1];
    var Sx = function(a) {
        this.D = _.B(a)
    };
    _.T(Sx, _.F);
    var Tx = function(a) {
        this.D = _.B(a)
    };
    _.T(Tx, _.F);
    Tx.ca = [1];
    var Ux = function(a) {
        this.D = _.B(a)
    };
    _.T(Ux, _.F);
    var Vx = [0, sx, lx];
    var Wx = function(a) {
        this.D = _.B(a)
    };
    _.T(Wx, _.F);
    var Xx = [0, kx];
    var Yx = function(a) {
        this.D = _.B(a)
    };
    _.T(Yx, _.F);
    Yx.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 1)
    };
    var Zx = [0, px, Xx, Vx];
    var $x = function(a) {
        this.D = _.B(a)
    };
    _.T($x, _.F);
    $x.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    _.ay = function(a) {
        this.D = _.B(a)
    };
    _.T(_.ay, _.F);
    _.ay.ca = [5];
    _.by = function(a) {
        this.D = _.B(a)
    };
    _.T(_.by, _.F);
    _.by.prototype.Ce = ca(0);
    _.by.prototype.vd = ca(1);
    _.by.prototype.Ee = ca(2);
    _.by.ca = [15];
    var cy = function(a) {
        this.D = _.B(a)
    };
    _.T(cy, _.F);
    cy.prototype.getAdUnitPath = function() {
        return _.R(this, 2)
    };
    var dy = function(a) {
        this.D = _.B(a)
    };
    _.T(dy, _.F);
    var ey = [5, 7, 8, 9];
    var fy = function(a) {
        this.D = _.B(a)
    };
    _.T(fy, _.F);
    var gy = function(a) {
        this.D = _.B(a)
    };
    _.T(gy, _.F);
    gy.ca = [4, 5, 6];
    var hy = function(a) {
        this.D = _.B(a)
    };
    _.T(hy, _.F);
    hy.prototype.getValue = function() {
        return _.R(this, 2)
    };
    hy.prototype.Wf = function() {
        return null != _.Aj(this, 2)
    };
    var iy = function(a) {
        this.D = _.B(a)
    };
    _.T(iy, _.F);
    iy.ca = [13];
    var jy = function(a) {
        this.D = _.B(a)
    };
    _.T(jy, _.F);
    jy.ca = [15, 13];
    var ky = function(a) {
        this.D = _.B(a)
    };
    _.T(ky, _.F);
    var ly = function(a) {
            var b = new ky;
            return _.ko(b, 1, a)
        },
        my = [0, sx];
    var zj = function(a) {
        this.D = _.B(a)
    };
    _.T(zj, _.F);
    var ny = function(a) {
            var b = new zj;
            return Vn(b, 1, a)
        },
        oy = function(a) {
            var b = window.Date.now();
            b = _.A(Number, "isFinite").call(Number, b) ? Math.round(b) : 0;
            return _.xk(a, 3, b)
        };
    zj.prototype.gb = function(a) {
        return _.th(this, 10, a)
    };
    var py = Pe(zj),
        qy = [0, px, -1, lx, nx, -2, lx, jx, ox, my, ox];
    var ry = [0, 1, [0, mx, -2], -1, px, -1, ox, [0, 3, sx, px], lx];
    var sy = function(a) {
        this.D = _.B(a)
    };
    _.T(sy, _.F);
    sy.ca = [1, 2];
    sy.prototype.j = Oe([0, rx, ry, rx, qy]);
    var ty = function(a) {
        this.D = _.B(a)
    };
    _.T(ty, _.F);
    var uy = function(a) {
        this.D = _.B(a)
    };
    _.T(uy, _.F);
    uy.prototype.getValue = function() {
        return _.R(this, 1)
    };
    uy.prototype.Wf = function() {
        return null != _.Aj(this, 1)
    };
    uy.prototype.getVersion = function() {
        return _.Hk(this, 5, 0)
    };
    var vy = function(a) {
        this.D = _.B(a)
    };
    _.T(vy, _.F);
    var wy = function(a) {
        this.D = _.B(a)
    };
    _.T(wy, _.F);
    wy.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    var xy = function(a) {
        this.D = _.B(a)
    };
    _.T(xy, _.F);
    var yy = function(a) {
        this.D = _.B(a)
    };
    _.T(yy, _.F);
    var zy = function(a) {
        this.D = _.B(a)
    };
    _.T(zy, _.F);
    zy.prototype.getContentUrl = function() {
        return _.R(this, 2)
    };
    var Ay = function(a) {
        this.D = _.B(a)
    };
    _.T(Ay, _.F);
    Ay.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 4)
    };
    Ay.ca = [2];
    var By = function(a) {
        this.D = _.B(a)
    };
    _.T(By, _.F);
    var Cy = function(a) {
        this.D = _.B(a)
    };
    _.T(Cy, _.F);
    var Dy = function(a) {
        this.D = _.B(a)
    };
    _.T(Dy, _.F);
    var Ey = function(a) {
        this.D = _.B(a)
    };
    _.T(Ey, _.F);
    var Fy = function(a) {
        this.D = _.B(a)
    };
    _.T(Fy, _.F);
    Fy.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 2)
    };
    var Gy = function(a) {
        this.D = _.B(a)
    };
    _.T(Gy, _.F);
    var Hy = function(a) {
        this.D = _.B(a)
    };
    _.T(Hy, _.F);
    Hy.prototype.getWidth = function() {
        return _.ax(this, 9)
    };
    Hy.prototype.getHeight = function() {
        return _.ax(this, 10)
    };
    Hy.ca = [3, 7, 27, 11];
    var Iy = function(a) {
        this.D = _.B(a)
    };
    _.T(Iy, _.F);
    Iy.prototype.getHeight = function() {
        return Np(this, 6)
    };
    Iy.prototype.getWidth = function() {
        return Np(this, 7)
    };
    Iy.prototype.getEscapedQemQueryId = function() {
        return _.Aj(this, 34)
    };
    Iy.ca = [14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 23, 27, 38, 53, 62, 63, 67];
    var Jy = [39, 48];
    var Ky = function(a) {
        this.D = _.B(a)
    };
    _.T(Ky, _.F);
    var Aq = Pe(Ky);
    var Ly = function(a) {
        this.D = _.B(a)
    };
    _.T(Ly, _.F);
    var My = Pe(Ly);
    Ly.ca = [1, 2, 3];
    var Ny = window;
    var Qt = function(a) {
        this.D = _.B(a)
    };
    _.T(Qt, _.F);
    Qt.ca = [15];
    var Pt = function(a) {
        this.D = _.B(a)
    };
    _.T(Pt, _.F);
    Pt.prototype.getCorrelator = function() {
        return _.sf(this, 1)
    };
    Pt.prototype.setCorrelator = function(a) {
        return _.qh(this, 1, a)
    };
    var Ot = function(a) {
        this.D = _.B(a)
    };
    _.T(Ot, _.F);
    var Oy = _.kw || nw;
    var Qy, Ry;
    _.Py = Gi(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = _.Vv($v);
        return !b.parentElement
    });
    Qy = function(a, b) {
        b = b instanceof _.Ta ? b : _.Gv(b);
        a.href = _.ab(b)
    };
    Ry = /^[\w+/_-]+[=]{0,2}$/;
    _.Cp = function(a, b) {
        b = (b || _.t).document;
        return b.querySelector ? (a = b.querySelector(a)) && (a = a.nonce || a.getAttribute("nonce")) && Ry.test(a) ? a : "" : ""
    };
    _.oi = function(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    };
    _.oi.prototype.equals = function(a) {
        return a instanceof _.oi && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    _.oi.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    _.oi.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    _.oi.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    _.xi = function(a, b) {
        this.width = a;
        this.height = b
    };
    _.q = _.xi.prototype;
    _.q.aspectRatio = function() {
        return this.width / this.height
    };
    _.q.isEmpty = function() {
        return !(this.width * this.height)
    };
    _.q.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    _.q.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    _.q.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var Sy, Ty, Vy;
    Sy = function() {
        return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ Date.now()).toString(36)
    };
    Ty = 2147483648 * Math.random() | 0;
    _.Uy = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    Vy = function(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    var jf, Zy, Yy, bz, dz, iz;
    jf = function(a) {
        return a ? new _.Wy(_.Xy(a)) : Yu || (Yu = new _.Wy)
    };
    Zy = function(a, b) {
        Aa(b, function(c, d) {
            c && "object" == typeof c && c.ob && (c = c.Za());
            "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : Yy.hasOwnProperty(d) ? a.setAttribute(Yy[d], c) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, c) : a[d] = c
        })
    };
    Yy = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };
    _.az = function(a) {
        a = a.document;
        a = _.$y(a) ? a.documentElement : a.body;
        return new _.xi(a.clientWidth, a.clientHeight)
    };
    bz = function(a) {
        return a.scrollingElement ? a.scrollingElement : !nw && _.$y(a) ? a.documentElement : a.body || a.documentElement
    };
    _.cz = function(a) {
        return a ? a.parentWindow || a.defaultView : window
    };
    dz = function(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!_.ta(f) || _.ka(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (_.ka(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                _.hv(g ? _.ia(f) : f, d)
            }
        }
    };
    _.ez = function(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    };
    _.$y = function(a) {
        return "CSS1Compat" == a.compatMode
    };
    _.fz = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    _.gz = function(a) {
        var b;
        if (Oy && (b = a.parentElement)) return b;
        b = a.parentNode;
        return _.ka(b) && 1 == b.nodeType ? b : null
    };
    _.hz = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    _.Xy = function(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    };
    iz = function(a) {
        try {
            return a.contentWindow || (a.contentDocument ? _.cz(a.contentDocument) : null)
        } catch (b) {}
        return null
    };
    _.ch = function(a, b, c, d) {
        a && !c && (a = a.parentNode);
        for (c = 0; a && (null == d || c <= d);) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    };
    _.Wy = function(a) {
        this.j = a || _.t.document || document
    };
    _.q = _.Wy.prototype;
    _.q.yk = function(a) {
        return "string" === typeof a ? this.j.getElementById(a) : a
    };
    _.q.tm = _.Wy.prototype.yk;
    _.q.getElementsByTagName = function(a, b) {
        return (b || this.j).getElementsByTagName(String(a))
    };
    _.q.createElement = function(a) {
        return _.ez(this.j, a)
    };
    _.q.createTextNode = function(a) {
        return this.j.createTextNode(String(a))
    };
    _.q.append = function(a, b) {
        dz(_.Xy(a), a, arguments)
    };
    _.q.lj = _.fz;
    _.q.contains = _.hz;
    var kz = function() {
            return Ha && Ia ? Ia.mobile : !jz() && (La("iPod") || La("iPhone") || La("Android") || La("IEMobile"))
        },
        jz = function() {
            return Ha && Ia ? !Ia.mobile && (La("iPad") || La("Android") || La("Silk")) : La("iPad") || La("Android") && !La("Mobile") || La("Silk")
        };
    var mz, Il, nz, kn;
    _.lz = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    mz = function(a) {
        return a ? decodeURI(a) : a
    };
    Il = function(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) Il(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    };
    _.Iq = function(a, b) {
        var c = [];
        for (d in b) Il(d, b[d], c);
        b = c.join("&");
        if (b) {
            c = a.indexOf("#");
            0 > c && (c = a.length);
            var d = a.indexOf("?");
            if (0 > d || d > c) {
                d = c;
                var e = ""
            } else e = a.substring(d + 1, c);
            a = [a.slice(0, d), e, a.slice(c)];
            c = a[1];
            a[1] = b ? c ? c + "&" + b : b : c;
            a = a[0] + (a[1] ? "?" + a[1] : "") + a[2]
        }
        return a
    };
    nz = /#|$/;
    kn = function(a, b) {
        var c = a.search(nz);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    };
    var Lk, Vj, oz, Wj, Hi, wn, au, $t, qz, rz, Ii, sz, tz, uz, vz, wz, xz, yz, zz, Az, jj, lj, kj, Ln, Bz, Dz, Ez, Fz, Gz, Hz, Iz, Em, vm, Jz, Nl, Kz, Lz;
    _.nk = function(a) {
        try {
            return !!a && null != a.location.href && iw(a, "foo")
        } catch (b) {
            return !1
        }
    };
    Lk = function(a, b, c, d) {
        b = void 0 === b ? !1 : b;
        d = void 0 === d ? _.t : d;
        c = (void 0 === c ? 0 : c) ? oz(d) : d;
        for (d = 0; c && 40 > d++ && (!b && !_.nk(c) || !a(c));) c = oz(c)
    };
    Vj = function() {
        var a = window;
        Lk(function(b) {
            a = b;
            return !1
        });
        return a
    };
    oz = function(a) {
        try {
            var b = a.parent;
            if (b && b != a) return b
        } catch (c) {}
        return null
    };
    Wj = function(a) {
        return _.nk(a.top) ? a.top : null
    };
    _.hn = function(a, b) {
        var c = _.gf("SCRIPT", a);
        ib(c, b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    };
    Hi = function(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    };
    _.Zf = function() {
        if (!_.v.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            _.v.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    _.Ll = function(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    _.pz = function(a) {
        var b = [];
        _.Ll(a, function(c) {
            b.push(c)
        });
        return b
    };
    wn = function(a, b) {
        return Ca(a, function(c, d) {
            return Object.prototype.hasOwnProperty.call(a, d) && b(c, d)
        })
    };
    _.$f = function(a) {
        var b = a.length;
        if (0 == b) return 0;
        for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    };
    au = Gi(function() {
        return _.ah(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], qz) || 1E-4 > Math.random()
    });
    $t = Gi(function() {
        return qz("MSIE")
    });
    qz = function(a) {
        return _.Ja(Fa(), a)
    };
    rz = /^([0-9.]+)px$/;
    Ii = function(a) {
        return (a = rz.exec(a)) ? +a[1] : null
    };
    sz = function() {
        var a = window;
        try {
            for (var b = null; b != a; b = a, a = a.parent) switch (a.location.protocol) {
                case "https:":
                    return !0;
                case "file:":
                    return !0;
                case "http:":
                    return !1
            }
        } catch (c) {}
        return !0
    };
    tz = function(a) {
        if (!a) return "";
        var b = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
        try {
            var c = b.exec(decodeURIComponent(a));
            if (c) return c[1] && 1 < c[1].length ? c[1].substring(1) : "true"
        } catch (d) {}
        return ""
    };
    uz = {
        xm: "allow-forms",
        ym: "allow-modals",
        zm: "allow-orientation-lock",
        Am: "allow-pointer-lock",
        Bm: "allow-popups",
        Cm: "allow-popups-to-escape-sandbox",
        Dm: "allow-presentation",
        Em: "allow-same-origin",
        Fm: "allow-scripts",
        Gm: "allow-top-navigation",
        Hm: "allow-top-navigation-by-user-activation"
    };
    vz = Gi(function() {
        return _.pz(uz)
    });
    wz = function(a) {
        var b = vz();
        return a.length ? _.Zg(b, function(c) {
            return !(0 <= _.fa(a, c))
        }) : b
    };
    xz = function() {
        var a = _.gf("IFRAME"),
            b = {};
        _.hv(vz(), function(c) {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    };
    yz = function(a) {
        a = a && a.toString && a.toString();
        return "string" === typeof a && _.Ja(a, "[native code]")
    };
    zz = function(a, b) {
        for (var c = 0; 50 > c; ++c) {
            try {
                var d = !(!a.frames || !a.frames[b])
            } catch (e) {
                d = !1
            }
            if (d) return a;
            if (!(a = oz(a))) break
        }
        return null
    };
    Az = function(a) {
        if (!a || !a.frames) return null;
        if (a.frames.google_ads_top_frame) return a.frames.google_ads_top_frame.frameElement;
        try {
            var b = a.document,
                c = b.head,
                d, e = null != (d = b.body) ? d : null == c ? void 0 : c.parentElement;
            if (e) {
                var f = _.gf("IFRAME");
                f.name = "google_ads_top_frame";
                f.id = "google_ads_top_frame";
                f.style.display = "none";
                f.style.position = "fixed";
                f.style.left = "-999px";
                f.style.top = "-999px";
                f.style.width = "0px";
                f.style.height = "0px";
                e.appendChild(f);
                return f
            }
        } catch (g) {}
        return null
    };
    _.Pn = Gi(function() {
        return kz() ? 2 : jz() ? 1 : 0
    });
    jj = function(a, b) {
        var c;
        for (c = void 0 === c ? 100 : c; a && c--;) {
            if (a == b) return !0;
            a = a.parentElement
        }
        return !1
    };
    _.Si = function(a, b) {
        _.Ll(b, function(c, d) {
            a.style.setProperty(d, c, "important")
        })
    };
    lj = function(a, b, c) {
        for (c = void 0 === c ? 100 : c; a && c-- && !1 !== b(a);) a = a.parentElement
    };
    kj = function(a, b) {
        for (var c = 100; a && c--;) {
            var d = Hi(a, window);
            if (d) {
                if (b(d, a)) return !0;
                a = a.parentElement
            }
        }
        return !1
    };
    Ln = function(a) {
        if (!a) return null;
        a = a.transform;
        if (!a) return null;
        a = a.replace(/^.*\(([0-9., -]+)\)$/, "$1").split(/, /);
        return 6 != a.length ? null : _.iv(a, parseFloat)
    };
    Bz = {};
    _.Cz = (Bz["http://googleads.g.doubleclick.net"] = !0, Bz["http://pagead2.googlesyndication.com"] = !0, Bz["https://googleads.g.doubleclick.net"] = !0, Bz["https://pagead2.googlesyndication.com"] = !0, Bz);
    Dz = function(a) {
        _.t.console && _.t.console.warn && _.t.console.warn(a)
    };
    Ez = [];
    Fz = function() {
        var a = Ez;
        Ez = [];
        a = _.z(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                b()
            } catch (c) {}
        }
    };
    Gz = function(a) {
        return a.replace(/\\(n|r|\\)/g, function(b, c) {
            return "n" == c ? "\n" : "r" == c ? "\r" : "\\"
        })
    };
    Hz = function() {
        var a = void 0 === a ? Math.random : a;
        return Math.floor(a() * Math.pow(2, 52))
    };
    _.Rh = function(a) {
        if ("number" !== typeof a.goog_pvsid) try {
            Object.defineProperty(a, "goog_pvsid", {
                value: Hz(),
                configurable: !1
            })
        } catch (b) {}
        return Number(a.goog_pvsid) || -1
    };
    Iz = function(a, b) {
        "complete" === a.readyState || "interactive" === a.readyState ? (Ez.push(b), 1 == Ez.length && (_.v.Promise ? _.v.Promise.resolve().then(Fz) : window.setImmediate ? setImmediate(Fz) : setTimeout(Fz, 0))) : a.addEventListener("DOMContentLoaded", b)
    };
    Em = function(a) {
        return "number" === typeof a && isFinite(a) && 0 == a % 1 && 0 < a
    };
    vm = function(a) {
        return 0 === a || Em(a)
    };
    Jz = function(a) {
        return new _.v.Promise(function(b) {
            setTimeout(function() {
                return void b(void 0)
            }, a)
        })
    };
    Nl = function(a) {
        try {
            var b = JSON.stringify(a)
        } catch (c) {}
        return b || String(a)
    };
    _.gf = function(a, b) {
        b = void 0 === b ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    Kz = function(a) {
        for (var b = a; a && a != a.parent;) a = a.parent, _.nk(a) && (b = a);
        return b
    };
    _.Hg = function(a) {
        return Na() && kz() ? Lz(a, !0) : 1
    };
    Lz = function(a, b) {
        var c = (void 0 === b ? 0 : b) ? Wj(a) : a;
        if (!c) return 1;
        a = 0 === (0, _.Pn)();
        b = !!c.document.querySelector('meta[name=viewport][content*="width=device-width"]');
        var d = c.innerWidth;
        c = c.outerWidth;
        return 0 === d ? 1 : a || b ? Math.round(100 * (c / d + _.A(Number, "EPSILON"))) / 100 : Math.round(100 * (c / d / .4 + _.A(Number, "EPSILON"))) / 100
    };
    _.Mz = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    };
    _.Mz.prototype.getWidth = function() {
        return this.right - this.left
    };
    _.Mz.prototype.getHeight = function() {
        return this.bottom - this.top
    };
    _.Nz = function(a) {
        return new _.Mz(a.top, a.right, a.bottom, a.left)
    };
    _.Mz.prototype.contains = function(a) {
        return this && a ? a instanceof _.Mz ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    _.Mz.prototype.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    _.Mz.prototype.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    _.Mz.prototype.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    var Oz = function(a, b, c, d) {
            this.left = a;
            this.top = b;
            this.width = c;
            this.height = d
        },
        Pz = function(a) {
            return new _.Mz(a.top, a.left + a.width, a.top + a.height, a.left)
        },
        Qz = function(a, b) {
            var c = Math.max(a.left, b.left),
                d = Math.min(a.left + a.width, b.left + b.width);
            if (c <= d) {
                var e = Math.max(a.top, b.top);
                a = Math.min(a.top + a.height, b.top + b.height);
                if (e <= a) return new Oz(c, e, d - c, a - e)
            }
            return null
        };
    Oz.prototype.contains = function(a) {
        return a instanceof _.oi ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    Oz.prototype.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    Oz.prototype.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    Oz.prototype.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var Rz = function(a) {
        return (a = void 0 === a ? $e() : a) ? _.nk(a.master) ? a.master : null : null
    };
    var Uz, Wz, wi, Xz, Yz, ni;
    _.Tz = function(a, b, c) {
        if ("string" === typeof b)(b = _.Sz(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = _.Sz(c, d);
                f && (c.style[f] = e)
            }
    };
    Uz = {};
    _.Sz = function(a, b) {
        var c = Uz[b];
        if (!c) {
            var d = _.Uy(b);
            c = d;
            void 0 === a.style[d] && (d = (nw ? "Webkit" : mw ? "Moz" : _.kw ? "ms" : null) + Vy(d), void 0 !== a.style[d] && (c = d));
            Uz[b] = c
        }
        return c
    };
    _.Vz = function(a, b) {
        var c = _.Xy(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    };
    Wz = function(a, b) {
        return _.Vz(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    };
    wi = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };
    Xz = function(a) {
        if (_.kw && !(8 <= Number(ww))) return a.offsetParent;
        var b = _.Xy(a),
            c = Wz(a, "position"),
            d = "fixed" == c || "absolute" == c;
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (11 == a.nodeType && a.host && (a = a.host), c = Wz(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" == c || "relative" == c)) return a;
        return null
    };
    Yz = function(a) {
        var b = _.Xy(a),
            c = new _.oi(0, 0);
        var d = b ? _.Xy(b) : document;
        d = !_.kw || 9 <= Number(ww) || _.$y(jf(d).j) ? d.documentElement : d.body;
        if (a == d) return c;
        a = wi(a);
        d = jf(b).j;
        b = bz(d);
        d = d.parentWindow || d.defaultView;
        b = _.kw && d.pageYOffset != b.scrollTop ? new _.oi(b.scrollLeft, b.scrollTop) : new _.oi(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    };
    ni = function(a, b) {
        var c = new _.oi(0, 0),
            d = _.cz(_.Xy(a));
        if (!iw(d, "parent")) return c;
        do {
            var e = d == b ? Yz(a) : _.Zz(a);
            c.x += e.x;
            c.y += e.y
        } while (d && d != b && d != d.parent && (a = d.frameElement) && (d = d.parent));
        return c
    };
    _.Zz = function(a) {
        a = wi(a);
        return new _.oi(a.left, a.top)
    };
    _.$z = function(a, b) {
        "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
        return a
    };
    _.vi = function(a, b) {
        if ("none" != Wz(b, "display")) return a(b);
        var c = b.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = a(b);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    };
    _.aA = function(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = nw && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = wi(a), new _.xi(a.right - a.left, a.bottom - a.top)) : new _.xi(b, c)
    };
    var gj;
    _.bA = _.tu(["//fonts.googleapis.com/css"]);
    gj = function(a) {
        a = Rz($e(a)) || a;
        a = a.google_unique_id;
        return "number" === typeof a ? a : 0
    };
    var cA = function(a) {
        this.D = _.B(a)
    };
    _.T(cA, _.F);
    var dA = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var eA = function(a) {
        this.D = _.B(a)
    };
    _.T(eA, _.F);
    eA.prototype.getVersion = function() {
        return _.ax(this, 2)
    };
    eA.ca = [3];
    var fA = function(a) {
        this.D = _.B(a)
    };
    _.T(fA, _.F);
    var gA = function(a) {
        this.D = _.B(a)
    };
    _.T(gA, _.F);
    var hA = function(a) {
        this.D = _.B(a)
    };
    _.T(hA, _.F);
    hA.prototype.getVersion = function() {
        return _.ax(this, 1)
    };
    var iA = function(a) {
        this.D = _.B(a)
    };
    _.T(iA, _.F);
    var jA = function(a) {
        this.D = _.B(a)
    };
    _.T(jA, _.F);
    var kA = function(a) {
        var b = new jA;
        return _.th(b, 1, a)
    };
    var lA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        mA = lA.reduce(function(a, b) {
            return a + b
        });
    var nA = function(a) {
        this.D = _.B(a)
    };
    _.T(nA, _.F);
    var oA = function(a) {
        this.D = _.B(a)
    };
    _.T(oA, _.F);
    oA.prototype.getVersion = function() {
        return _.ax(this, 1)
    };
    var pA = function(a) {
        this.D = _.B(a)
    };
    _.T(pA, _.F);
    var qA = function(a) {
        this.D = _.B(a)
    };
    _.T(qA, _.F);
    var rA = function(a) {
        var b = new qA;
        return _.th(b, 1, a)
    };
    var sA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        tA = sA.reduce(function(a, b) {
            return a + b
        });
    var uA = function(a) {
        this.D = _.B(a)
    };
    _.T(uA, _.F);
    var vA = function(a) {
        this.D = _.B(a)
    };
    _.T(vA, _.F);
    var wA = function(a) {
        this.D = _.B(a)
    };
    _.T(wA, _.F);
    wA.prototype.getVersion = function() {
        return _.ax(this, 1)
    };
    var xA = function(a) {
        this.D = _.B(a)
    };
    _.T(xA, _.F);
    var yA = function(a) {
        this.D = _.B(a)
    };
    _.T(yA, _.F);
    var zA = function(a) {
        var b = new yA;
        return _.th(b, 1, a)
    };
    var AA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        BA = AA.reduce(function(a, b) {
            return a + b
        });
    var CA = function(a) {
        this.D = _.B(a)
    };
    _.T(CA, _.F);
    var DA = function(a) {
        this.D = _.B(a)
    };
    _.T(DA, _.F);
    DA.prototype.getVersion = function() {
        return _.ax(this, 1)
    };
    var EA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        FA = EA.reduce(function(a, b) {
            return a + b
        });
    var GA = function(a) {
        this.D = _.B(a)
    };
    _.T(GA, _.F);
    var HA = function(a, b) {
        var c = new GA;
        a = _.I(c, 1, a);
        b = _.rh(a, 2, b);
        this.J = _.Od(b)
    };
    var IA = function(a) {
        this.D = _.B(a)
    };
    _.T(IA, _.F);
    var JA = [1, 2, 3];
    var KA = function(a) {
        this.D = _.B(a)
    };
    _.T(KA, _.F);
    var LA = [2, 4];
    var MA = function(a) {
        this.D = _.B(a)
    };
    _.T(MA, _.F);
    MA.ca = [4];
    var NA = function(a) {
        this.D = _.B(a)
    };
    _.T(NA, _.F);
    var OA = function(a) {
        this.D = _.B(a)
    };
    _.T(OA, _.F);
    var Ih = function(a) {
        this.D = _.B(a)
    };
    _.T(Ih, _.F);
    var wh = function(a) {
        this.D = _.B(a)
    };
    _.T(wh, _.F);
    var vh = function(a) {
        this.D = _.B(a)
    };
    _.T(vh, _.F);
    var sh = function(a) {
        this.D = _.B(a)
    };
    _.T(sh, _.F);
    var Dh = function(a) {
        this.D = _.B(a)
    };
    _.T(Dh, _.F);
    var PA = function(a) {
        this.D = _.B(a)
    };
    _.T(PA, _.F);
    var QA = function(a) {
        this.D = _.B(a)
    };
    _.T(QA, _.F);
    var ph = function(a) {
        this.D = _.B(a)
    };
    _.T(ph, _.F);
    ph.prototype.getTagSessionCorrelator = function() {
        return _.sf(this, 2)
    };
    var Ch = function(a) {
        var b = new PA;
        return _.zh(a, 13, Ah, b)
    };
    ph.ca = [4];
    var Ah = [6, 7, 8, 9, 11, 13, 14];
    var Ro = function(a) {
        this.D = _.B(a)
    };
    _.T(Ro, _.F);
    var Oo = function(a) {
        this.D = _.B(a)
    };
    _.T(Oo, _.F);
    var Po = [1, 2, 3, 4];
    var Ko = function(a) {
        this.D = _.B(a)
    };
    _.T(Ko, _.F);
    Ko.prototype.getTagSessionCorrelator = function() {
        return _.sf(this, 2)
    };
    Ko.ca = [4];
    var Vh = function(a) {
        this.D = _.B(a)
    };
    _.T(Vh, _.F);
    Vh.ca = [3];
    var Sh = function(a) {
        this.D = _.B(a)
    };
    _.T(Sh, _.F);
    Sh.ca = [4, 5];
    var Qh = function(a) {
        this.D = _.B(a)
    };
    _.T(Qh, _.F);
    Qh.prototype.getTagSessionCorrelator = function() {
        return _.sf(this, 1)
    };
    Qh.ca = [2];
    var Ph = function(a) {
        this.D = _.B(a)
    };
    _.T(Ph, _.F);
    var Yh = [4, 6];
    var RA = function(a) {
        this.D = _.B(a)
    };
    _.T(RA, _.F);
    RA.prototype.getTagSessionCorrelator = function() {
        return _.sf(this, 1)
    };
    RA.prototype.getMessageId = function() {
        return _.Hk(this, 8, 0)
    };
    RA.prototype.getMessageArgs = function(a) {
        return bx(this, 9, a)
    };
    RA.ca = [2, 9];
    var SA = function() {
            HA.apply(this, arguments)
        },
        Fh;
    _.T(SA, HA);
    Fh = function(a, b) {
        var c = void 0 === b.step ? 1 : b.step;
        b = b.tf;
        var d = new MA;
        d = _.rh(d, 1, "uWt0se");
        var e = new IA;
        b = yk(e, 1, JA, dd(b));
        b = Gj(d, 4, IA, b);
        d = new KA;
        c = yk(d, 2, LA, Uc(Math.round(c)));
        c = _.th(b, 3, c);
        _.qh(c, 2, 1);
        a.Jl(c)
    };
    _.TA = function() {
        SA.apply(this, arguments)
    };
    _.T(_.TA, SA);
    _.q = _.TA.prototype;
    _.q.Kl = function() {
        this.o.apply(this, _.lh(_.Xa.apply(0, arguments).map(function(a) {
            return {
                vc: !0,
                Zc: 2,
                Pc: a.toJSON()
            }
        })))
    };
    _.q.Ac = function() {
        this.o.apply(this, _.lh(_.Xa.apply(0, arguments).map(function(a) {
            return {
                vc: !0,
                Zc: 5,
                Pc: a.toJSON()
            }
        })))
    };
    _.q.Hi = function() {
        this.o.apply(this, _.lh(_.Xa.apply(0, arguments).map(function(a) {
            return {
                vc: !0,
                Zc: 15,
                Pc: a.toJSON()
            }
        })))
    };
    _.q.Ii = ca(3);
    _.q.Ml = function() {
        this.o.apply(this, _.lh(_.Xa.apply(0, arguments).map(function(a) {
            return {
                vc: !0,
                Zc: 17,
                Pc: a.toJSON()
            }
        })))
    };
    _.q.Jl = function() {
        this.o.apply(this, _.lh(_.Xa.apply(0, arguments).map(function(a) {
            return {
                vc: !1,
                Zc: 1,
                Pc: a.toJSON()
            }
        })))
    };
    var UA = function(a, b) {
        if (_.v.globalThis.fetch) _.v.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var VA = function(a, b, c, d, e, f, g, h) {
        _.TA.call(this, a, b);
        this.v = c;
        this.M = d;
        this.C = e;
        this.H = f;
        this.I = g;
        this.A = h;
        this.j = [];
        this.m = null;
        this.l = !1
    };
    _.T(VA, _.TA);
    var WA = function(a) {
        null !== a.m && (clearTimeout(a.m), a.m = null);
        if (a.j.length) {
            var b = ff(a.j, a.J);
            a.M(a.v + "?e=1", b);
            a.j = []
        }
    };
    VA.prototype.o = function() {
        var a = _.Xa.apply(0, arguments),
            b = this;
        this.I && 65536 <= ff(this.j.concat(a), this.J).length && WA(this);
        this.A && !this.l && (this.l = !0, XA(this.A, function() {
            WA(b)
        }));
        this.j.push.apply(this.j, _.lh(a));
        this.j.length >= this.H && WA(this);
        this.j.length && null === this.m && (this.m = setTimeout(function() {
            WA(b)
        }, this.C))
    };
    var gu = function(a, b, c, d, e, f) {
        VA.call(this, a, b, "https://pagead2.googlesyndication.com/pagead/ping", UA, void 0 === c ? 1E3 : c, void 0 === d ? 100 : d, (void 0 === e ? !1 : e) && !!_.v.globalThis.fetch, f)
    };
    _.T(gu, VA);
    var ZA, $A, aB;
    _.YA = function(a, b) {
        this.j = a;
        this.defaultValue = void 0 === b ? !1 : b
    };
    ZA = function(a, b) {
        this.j = a;
        this.defaultValue = void 0 === b ? 0 : b
    };
    $A = function(a, b) {
        this.j = a;
        this.defaultValue = void 0 === b ? "" : b
    };
    aB = function(a) {
        var b = void 0 === b ? [] : b;
        this.j = a;
        this.defaultValue = b
    };
    var vs, Im, Xi, bB, cB, uo, dB, no, eB, fB, Dt, Ct, It, gB, cu, hB, iB, jB, kB, lB, mB, nB, oB, pB, qB, rB, sB, tB, uB, bu, vB, wB, xB, yB, xq, zB, Tm, AB, ug, At, Bo, Kh, HB, IB, gt, Up, JB, KB, LB, MB, NB, OB, PB, QB, RB, SB, sn, vp, TB, UB, VB, WB, Hl, El, xt, ZB, $B, aC, Dm, bC, cC, dC, fu, du, uk, eC, fC, gC, hC, tk, iC, Pr, jC, Es, kC, lC, mC, nC, oC, pC, qC, rC, St, Tt, sC, Ut, Rt, tC, uC, Bs, Wt, vC;
    vs = new _.YA(577837147, !0);
    Im = new _.YA(577939489, !0);
    Xi = new ZA(7, .1);
    bB = new _.YA(212);
    cB = new _.YA(561694963);
    uo = new ZA(474069761);
    dB = new ZA(462420536);
    no = new _.YA(476475256, !0);
    eB = new ZA(427198696, 1);
    fB = new ZA(438663674);
    Dt = new ZA(45409629);
    Ct = new ZA(522348973);
    It = new ZA(550605190);
    gB = new ZA(564509649);
    cu = new ZA(578655462);
    _.ap = new _.YA(571050247, !0);
    _.Uo = new _.YA(570864697, !0);
    hB = new _.YA(558225291);
    iB = new _.YA(577861852);
    jB = new _.YA(573236024);
    kB = new _.YA(580562135);
    lB = new ZA(494575051);
    mB = new aB(489560439);
    nB = new aB(505762507);
    oB = new _.YA(453);
    pB = new _.YA(454);
    qB = new ZA(377289019, 1E4);
    rB = new _.YA(579191270);
    sB = new _.YA(580185501);
    tB = new _.YA(576957572, !0);
    uB = new ZA(529, 20);
    bu = new ZA(573282293, .01);
    vB = new $A(10);
    wB = new _.YA(489217043);
    xB = new _.YA(549005203, !0);
    yB = new _.YA(495013820);
    xq = new ZA(447000223, .01);
    zB = new _.YA(360245597, !0);
    Tm = new _.YA(540043576);
    AB = new _.YA(471855283);
    ug = new _.YA(465118388);
    At = new _.YA(45401686);
    Bo = new _.YA(45401685, !0);
    _.BB = new _.YA(479390945);
    _.CB = new _.YA(518650310);
    _.DB = new _.YA(547020083);
    _.EB = new _.YA(561164161, !0);
    _.FB = new ZA(550718589, 250);
    _.GB = new _.YA(531615531);
    Kh = new _.YA(85);
    HB = new _.YA(547249510);
    IB = new _.YA(537116804);
    gt = new _.YA(524098256);
    Up = new ZA(532520346, 120);
    JB = new _.YA(557870754, !0);
    KB = new ZA(553562174, 10);
    LB = new aB(466086960);
    MB = new ZA(398776877, 6E4);
    NB = new ZA(374201269, 6E4);
    OB = new ZA(371364213, 6E4);
    PB = new _.YA(570764855, !0);
    QB = new $A(579921177, "control_1\\.\\d");
    RB = new ZA(570764854, 50);
    SB = new _.YA(578725095);
    sn = new _.YA(560793105);
    vp = new _.YA(568657331);
    TB = new _.YA(568657332);
    UB = new _.YA(453275889);
    VB = new _.YA(377936516, !0);
    WB = new ZA(24);
    Hl = new aB(1);
    El = new $A(2, "1-0-40");
    _.XB = new ZA(506394061, 100);
    _.YB = new _.YA(526684968, !0);
    xt = new aB(489);
    ZB = new _.YA(392065905);
    $B = new ZA(360245595, 500);
    aC = new _.YA(561985307);
    Dm = new _.YA(45397804, !0);
    bC = new _.YA(580311360);
    cC = new _.YA(45398607, !0);
    dC = new _.YA(424117738);
    fu = new ZA(397316938, 1E3);
    du = new _.YA(579196150);
    uk = new _.YA(531493729);
    eC = new _.YA(563462360, !0);
    fC = new _.YA(555237688);
    gC = new _.YA(555237687);
    hC = new _.YA(555237686);
    tk = new _.YA(507033477, !0);
    iC = new _.YA(552803605, !0);
    Pr = new _.YA(399705355);
    jC = new _.YA(45420038);
    Es = new ZA(514795754, 2);
    kC = new _.YA(564724551);
    lC = new _.YA(567489814, !0);
    mC = new _.YA(45415915, !0);
    nC = new _.YA(564852646, !0);
    oC = new _.YA(501);
    pC = new _.YA(439828594);
    qC = new _.YA(483962503);
    rC = new _.YA(506738118);
    St = new _.YA(77);
    Tt = new _.YA(78);
    sC = new _.YA(83);
    Ut = new _.YA(80);
    Rt = new _.YA(76);
    tC = new _.YA(84);
    uC = new _.YA(1958);
    Bs = new _.YA(1973);
    Wt = new _.YA(188);
    vC = new _.YA(485990406);
    var wC = new _.YA(1958);
    Ba({
        bn: 0,
        an: 1,
        Xm: 2,
        Sm: 3,
        Ym: 4,
        Tm: 5,
        Zm: 6,
        Vm: 7,
        Wm: 8,
        Rm: 9,
        Um: 10,
        cn: 11
    }).map(function(a) {
        return Number(a)
    });
    Ba({
        en: 0,
        fn: 1,
        dn: 2
    }).map(function(a) {
        return Number(a)
    });
    var xC = function(a, b) {
        this.j = lf(a);
        this.o = b
    };
    xC.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return this
    };
    xC.prototype.next = function() {
        var a = this.j.next();
        return {
            value: a.done ? void 0 : this.o.call(void 0, a.value),
            done: a.done
        }
    };
    var yC = function(a, b) {
            return new xC(a, b)
        },
        zC = function(a) {
            this.o = a;
            this.j = 0
        };
    zC.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return this
    };
    zC.prototype.next = function() {
        for (; this.j < this.o.length;) {
            var a = this.o[this.j].next();
            if (!a.done) return a;
            this.j++
        }
        return {
            done: !0
        }
    };
    var AC = function() {
        return new zC(_.Xa.apply(0, arguments).map(lf))
    };
    var BC = _.t.URL,
        CC;
    try {
        new BC("http://example.com"), CC = !0
    } catch (a) {
        CC = !1
    }
    var DC = CC,
        EC = function(a) {
            this.j = new _.v.Map;
            0 == a.indexOf("?") && (a = a.substring(1));
            a = _.z(a.split("&"));
            for (var b = a.next(); !b.done; b = a.next()) {
                var c = b.value;
                b = c;
                var d = "";
                c = c.split("=");
                1 < c.length && (b = decodeURIComponent(c[0].replace("+", " ")), d = decodeURIComponent(c[1].replace("+", " ")));
                c = this.j.get(b);
                null == c && (c = [], this.j.set(b, c));
                c.push(d)
            }
        };
    EC.prototype.get = function(a) {
        return (a = this.j.get(a)) && a.length ? a[0] : null
    };
    EC.prototype.getAll = function(a) {
        return [].concat(_.lh(this.j.get(a) || []))
    };
    EC.prototype.has = function(a) {
        return this.j.has(a)
    };
    EC.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return AC.apply(null, _.lh(yC(this.j, function(a) {
            var b = a[0];
            return yC(a[1], function(c) {
                return [b, c]
            })
        })))
    };
    EC.prototype.toString = function() {
        return FC(this)
    };
    var FC = function(a) {
            var b = function(c) {
                return encodeURIComponent(c).replace(/[!()~']|(%20)/g, function(d) {
                    return {
                        "!": "%21",
                        "(": "%28",
                        ")": "%29",
                        "%20": "+",
                        "'": "%27",
                        "~": "%7E"
                    }[d]
                })
            };
            return _.A(Array, "from").call(Array, a, function(c) {
                return b(c[0]) + "=" + b(c[1])
            }).join("&")
        },
        HC = function(a) {
            var b = _.ez(document, "A");
            try {
                Qy(b, Ua(a));
                var c = b.protocol
            } catch (e) {
                throw Error(a + " is not a valid URL.");
            }
            if ("" === c || ":" === c || ":" != c[c.length - 1]) throw Error(a + " is not a valid URL.");
            if (!GC.has(c)) throw Error(a + " is not a valid URL.");
            if (!b.hostname) throw Error(a + " is not a valid URL.");
            var d = b.href;
            a = {
                href: d,
                protocol: b.protocol,
                username: "",
                password: "",
                hostname: b.hostname,
                pathname: "/" + b.pathname,
                search: b.search,
                hash: b.hash,
                toString: function() {
                    return d
                }
            };
            GC.get(b.protocol) === b.port ? (a.host = a.hostname, a.port = "", a.origin = a.protocol + "//" + a.hostname) : (a.host = b.host, a.port = b.port, a.origin = a.protocol + "//" + a.hostname + ":" + a.port);
            return a
        },
        nf = function(a) {
            if (DC) {
                try {
                    var b = new BC(a)
                } catch (d) {
                    throw Error(a + " is not a valid URL.");
                }
                var c = GC.get(b.protocol);
                if (!c) throw Error(a + " is not a valid URL.");
                if (!b.hostname) throw Error(a + " is not a valid URL.");
                "null" == b.origin && (a = {
                    href: b.href,
                    protocol: b.protocol,
                    username: "",
                    password: "",
                    host: b.host,
                    port: b.port,
                    hostname: b.hostname,
                    pathname: b.pathname,
                    search: b.search,
                    hash: b.hash
                }, a.origin = c === b.port ? b.protocol + "//" + b.hostname : b.protocol + "//" + b.hostname + ":" + b.port, b = a);
                return b
            }
            return HC(a)
        },
        GC = new _.v.Map([
            ["http:", "80"],
            ["https:", "443"],
            ["ws:", "80"],
            ["wss:", "443"],
            ["ftp:", "21"]
        ]),
        mf = function(a) {
            return DC && a.searchParams ? a.searchParams : new EC(a.search)
        };
    var IC = function(a) {
        var b = a.document,
            c = function() {
                if (!a.frames.googlefcPresent)
                    if (b.body) {
                        var d = _.gf("IFRAME", b);
                        d.style.display = "none";
                        d.style.width = "0px";
                        d.style.height = "0px";
                        d.style.border = "none";
                        d.style.zIndex = "-1000";
                        d.style.left = "-1000px";
                        d.style.top = "-1000px";
                        d.name = "googlefcPresent";
                        b.body.appendChild(d)
                    } else a.setTimeout(c, 5)
            };
        c()
    };
    var JC = function(a) {
        this.D = _.B(a)
    };
    _.T(JC, _.F);
    JC.ca = [1, 2];
    var KC = function(a) {
        this.D = _.B(a)
    };
    _.T(KC, _.F);
    var rf = Pe(KC);
    _.U = function() {
        this.J = this.J;
        this.ta = this.ta
    };
    _.U.prototype.J = !1;
    _.U.prototype.wa = function() {
        this.J || (this.J = !0, this.o())
    };
    _.S = function(a, b) {
        _.tn(a, _.Xu(qf, b))
    };
    _.tn = function(a, b) {
        a.J ? b() : (a.ta || (a.ta = []), a.ta.push(b))
    };
    _.U.prototype.o = function() {
        if (this.ta)
            for (; this.ta.length;) this.ta.shift()()
    };
    var LC = function(a, b, c, d) {
        _.U.call(this);
        this.C = b;
        this.v = c;
        this.M = d;
        this.l = new _.v.Map;
        this.G = 0;
        this.m = new _.v.Map;
        this.I = new _.v.Map;
        this.H = void 0;
        this.A = a
    };
    _.T(LC, _.U);
    LC.prototype.o = function() {
        delete this.j;
        this.l.clear();
        this.m.clear();
        this.I.clear();
        this.H && (_.uf(this.A, "message", this.H), delete this.H);
        delete this.A;
        delete this.M;
        _.U.prototype.o.call(this)
    };
    var MC = function(a) {
            if (a.j) return a.j;
            a.v && a.v(a.A) ? a.j = a.A : a.j = zz(a.A, a.C);
            var b;
            return null != (b = a.j) ? b : null
        },
        OC = function(a, b, c) {
            if (MC(a))
                if (a.j === a.A)(b = a.l.get(b)) && b(a.j, c);
                else {
                    var d = a.m.get(b);
                    if (d && d.Mc) {
                        NC(a);
                        var e = ++a.G;
                        a.I.set(e, {
                            xc: d.xc,
                            Rj: d.Gd(c),
                            kl: "addEventListener" === b
                        });
                        a.j.postMessage(d.Mc(c, e), "*")
                    }
                }
        },
        NC = function(a) {
            a.H || (a.H = function(b) {
                try {
                    var c = a.M ? a.M(b) : void 0;
                    if (c) {
                        var d = c.yg,
                            e = a.I.get(d);
                        if (e) {
                            e.kl || a.I.delete(d);
                            var f;
                            null == (f = e.xc) || f.call(e, e.Rj, c.payload)
                        }
                    }
                } catch (g) {}
            }, _.jb(a.A, "message", a.H))
        };
    var PC = function(a, b) {
            var c = {
                cb: function(d) {
                    d = rf(d);
                    b.Jb({
                        bc: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        QC = {
            Gd: function(a) {
                return a.Jb
            },
            Mc: function(a, b) {
                return {
                    __fciCall: {
                        callId: b,
                        command: a.command,
                        spsp: a.spsp || void 0
                    }
                }
            },
            xc: function(a, b) {
                a({
                    bc: b
                })
            }
        },
        tp = function(a) {
            _.U.call(this);
            this.j = this.m = !1;
            this.caller = new LC(a, "googlefcPresent", void 0, tf);
            this.caller.l.set("getDataWithCallback", PC);
            this.caller.m.set("getDataWithCallback", QC)
        };
    _.T(tp, _.U);
    tp.prototype.o = function() {
        this.caller.wa();
        _.U.prototype.o.call(this)
    };
    tp.prototype.rc = function(a) {
        if (void 0 === a ? 0 : a) return !1;
        this.m || (this.j = !!MC(this.caller), this.m = !0);
        return this.j
    };
    var rp = function(a) {
            return new _.v.Promise(function(b) {
                a.rc() && OC(a.caller, "getDataWithCallback", {
                    command: "loaded",
                    Jb: function(c) {
                        b(c.bc)
                    }
                })
            })
        },
        RC = function(a, b) {
            a.rc() && OC(a.caller, "getDataWithCallback", {
                command: "prov",
                spsp: Ak(b),
                Jb: function() {}
            })
        };
    var SC = function(a, b, c, d, e) {
            vf(a, b, void 0 === c ? null : c, void 0 === d ? !1 : d, void 0 === e ? !1 : e)
        },
        vj = function(a, b) {
            var c = void 0 === c ? !1 : c;
            var d = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + b;
            _.Ll(a, function(e, f) {
                if (e || 0 === e) d += "&" + f + "=" + encodeURIComponent("" + e)
            });
            Nq(d, c)
        },
        Nq = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : SC(c, a, void 0, b, d)
        };
    var TC = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        UC = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            this.m = a;
            this.j = null;
            this.l = {};
            this.M = 0;
            var c;
            this.I = null != (c = b.timeoutMs) ? c : 500;
            var d;
            this.H = null != (d = b.wj) ? d : !1;
            this.A = null
        };
    _.T(UC, _.U);
    UC.prototype.o = function() {
        this.l = {};
        this.A && (_.uf(this.m, "message", this.A), delete this.A);
        delete this.l;
        delete this.m;
        delete this.j;
        _.U.prototype.o.call(this)
    };
    var WC = function(a) {
        return "function" === typeof a.m.__tcfapi || null != VC(a)
    };
    UC.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.H
            },
            d = _.ev(function() {
                return a(c)
            }),
            e = 0; - 1 !== this.I && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.I));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = TC(c), c.internalBlockOnErrors = b.H, h && 0 === c.internalErrorState || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            XC(this, "addEventListener", f)
        } catch (g) {
            c.tcString = "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    UC.prototype.removeEventListener = function(a) {
        a && a.listenerId && XC(this, "removeEventListener", null, a.listenerId)
    };
    var YC = function(a, b) {
            var c = void 0 === c ? "755" : c;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var d = a.publisher.restrictions[b];
                    if (void 0 !== d) {
                        d = d[void 0 === c ? "755" : c];
                        break a
                    }
                }
                d = void 0
            }
            if (0 === d) return !1;
            a.purpose && a.vendor ? (d = a.vendor.consents, (c = !(!d || !d[void 0 === c ? "755" : c])) && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : (c && (a = a.purpose.consents, c = !(!a || !a[b])), b = c)) : b = !0;
            return b
        },
        XC = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.m.__tcfapi) a = a.m.__tcfapi, a(b, 2, c, d);
            else if (VC(a)) {
                ZC(a);
                var e = ++a.M;
                a.l[e] = c;
                a.j && (c = {}, a.j.postMessage((c.__tcfapiCall = {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }, c), "*"))
            } else c({}, !1)
        },
        VC = function(a) {
            if (a.j) return a.j;
            a.j = zz(a.m, "__tcfapiLocator");
            return a.j
        },
        ZC = function(a) {
            a.A || (a.A = function(b) {
                try {
                    var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                    a.l[c.callId](c.returnValue, c.success)
                } catch (d) {}
            }, _.jb(a.m, "message", a.A))
        },
        $C = function(a) {
            if (!1 === a.gdprApplies) return !0;
            void 0 === a.internalErrorState && (a.internalErrorState = TC(a));
            return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (vj({
                e: String(a.internalErrorState)
            }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
        },
        aD = function(a, b) {
            return !1 === a.gdprApplies ? !0 : b.every(function(c) {
                return YC(a, c)
            })
        };
    var bD = function(a, b, c) {
            this.j = a;
            this.m = b;
            this.o = void 0 === c ? function() {} : c
        },
        jE = function(a, b, c) {
            return new bD(a, b, c)
        };
    bD.prototype.start = function(a) {
        if (this.j === this.j.top) try {
            IC(this.j), kE(this, a)
        } catch (b) {}
    };
    var kE = function(a, b) {
            var c = of (a.j),
                d = pf(a.j),
                e = {};
            c = (e.fc = c, e.fctype = d, e);
            c = lE(a.m, c);
            kf(a.j, c, function() {
                a.o(!0)
            }, function() {
                a.o(!1)
            });
            b && RC(new tp(a.j), b)
        },
        lE = function(a, b) {
            var c = cv("https://fundingchoicesmessages.google.com/i/%{id}");
            b = _.A(Object, "assign").call(Object, {}, b, {
                ers: 3
            });
            return _.nv(pb(c, {
                id: a
            }), b)
        };
    var mE = _.v.Promise;
    var nE = function(a) {
        this.o = a
    };
    nE.prototype.send = function(a, b, c) {
        this.o.then(function(d) {
            d.send(a, b, c)
        })
    };
    nE.prototype.j = function(a, b) {
        return this.o.then(function(c) {
            return c.j(a, b)
        })
    };
    var oE = function(a) {
        this.data = a
    };
    var pE = function(a) {
        this.o = a
    };
    pE.prototype.send = function(a, b, c) {
        c = void 0 === c ? [] : c;
        var d = new MessageChannel;
        qE(d.port1, b);
        this.o.postMessage(a, [d.port2].concat(c))
    };
    pE.prototype.j = function(a, b) {
        var c = this;
        return new mE(function(d) {
            c.send(a, d, b)
        })
    };
    var rE = function(a, b) {
            qE(a, b);
            return new pE(a)
        },
        qE = function(a, b) {
            b && (a.onmessage = function(c) {
                b(new oE(c.data, rE(c.ports[0])))
            })
        };
    var rk = function(a) {
            var b = a.nb,
                c = void 0 === a.ub ? "ZNWN1d" : a.ub,
                d = void 0 === a.onMessage ? void 0 : a.onMessage,
                e = void 0 === a.Se ? void 0 : a.Se;
            return sE({
                destination: a.destination,
                Fh: function() {
                    return b.contentWindow
                },
                al: tE(a.origin),
                ub: c,
                onMessage: d,
                Se: e
            })
        },
        sE = function(a) {
            var b = a.destination,
                c = a.Fh,
                d = a.al,
                e = void 0 === a.Ud ? void 0 : a.Ud,
                f = a.ub,
                g = void 0 === a.onMessage ? void 0 : a.onMessage,
                h = void 0 === a.Se ? void 0 : a.Se,
                k = Object.create(null);
            d.forEach(function(l) {
                k[l] = !0
            });
            return new nE(new mE(function(l, m) {
                var n = function(p) {
                    p.source && p.source === c() && !0 === k[p.origin] && (p.data.n || p.data) === f && (b.removeEventListener("message", n, !1), e && p.data.t !== e ? m(Error('Token mismatch while establishing channel "' + f + '". Expected ' + e + ", but received " + p.data.t + ".")) : (l(rE(p.ports[0], g)), h && h(p)))
                };
                b.addEventListener("message", n, !1)
            }))
        },
        tE = function(a) {
            a = "string" === typeof a ? [a] : a;
            var b = Object.create(null);
            a.forEach(function(c) {
                if ("null" === c) throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return a
        };
    var Ef = function(a) {
            return "string" === typeof a
        },
        Jm = function(a) {
            return "boolean" === typeof a
        },
        Af = function(a) {
            return !!a && ("object" === typeof a || "function" === typeof a)
        },
        ws = Cf(),
        Df = Cf();
    var uE = navigator,
        vE = function(a) {
            var b = 1,
                c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        wE = function(a, b) {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return vE(a.toLowerCase())
        },
        xE = RegExp("^\\s*_ga=\\s*1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        yE = RegExp("^[^=]+=\\s*GA1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        zE = RegExp("^\\s*_ga=\\s*()(amp-[\\w.-]{22,64})$");
    var li = function(a) {
            return !!a && a.top == a
        },
        Nk = function(a, b, c) {
            b = b || a.google_ad_width;
            c = c || a.google_ad_height;
            if (li(a)) return !1;
            var d = a.document,
                e = d.documentElement;
            if (b && c) {
                var f = 1,
                    g = 1;
                a.innerHeight ? (f = a.innerWidth, g = a.innerHeight) : e && e.clientHeight ? (f = e.clientWidth, g = e.clientHeight) : d.body && (f = d.body.clientWidth, g = d.body.clientHeight);
                if (g > 2 * c || f > 2 * b) return !1
            }
            return !0
        };
    var $i = function() {
        this.data = [];
        this.j = -1
    };
    $i.prototype.set = function(a, b) {
        b = void 0 === b ? !0 : b;
        0 <= a && 52 > a && _.A(Number, "isInteger").call(Number, a) && this.data[a] !== b && (this.data[a] = b, this.j = -1)
    };
    $i.prototype.get = function(a) {
        return !!this.data[a]
    };
    var bj = function(a) {
        -1 === a.j && (a.j = a.data.reduce(function(b, c, d) {
            return b + (c ? Math.pow(2, d) : 0)
        }, 0));
        return a.j
    };
    _.Oh = function(a) {
        return !!(a.error && a.meta && a.id)
    };
    var AE = function(a, b) {
            (0, a.__uspapi)("getUSPData", 1, function(c, d) {
                b.Jb({
                    bc: null != c ? c : void 0,
                    ve: d ? void 0 : 2
                })
            })
        },
        BE = {
            Gd: function(a) {
                return a.Jb
            },
            Mc: function(a, b) {
                a = {};
                return a.__uspapiCall = {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }, a
            },
            xc: function(a, b) {
                b = b.__uspapiReturn;
                var c;
                a({
                    bc: null != (c = b.returnValue) ? c : void 0,
                    ve: b.success ? void 0 : 2
                })
            }
        },
        CE = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            var c;
            this.timeoutMs = null != (c = b.timeoutMs) ? c : 500;
            this.caller = new LC(a, "__uspapiLocator", function(d) {
                return "function" === typeof d.__uspapi
            }, Gf);
            this.caller.l.set("getDataWithCallback", AE);
            this.caller.m.set("getDataWithCallback", BE)
        };
    _.T(CE, _.U);
    CE.prototype.o = function() {
        this.caller.wa();
        _.U.prototype.o.call(this)
    };
    var DE = function(a, b) {
        var c = {};
        if (MC(a.caller)) {
            var d = _.ev(function() {
                b(c)
            });
            OC(a.caller, "getDataWithCallback", {
                Jb: function(e) {
                    e.ve || (c = e.bc);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    };
    var Of = function(a) {
            this.j = a || {
                cookie: ""
            }
        },
        GE = function() {
            var a = EE;
            if (!_.t.navigator.cookieEnabled) return !1;
            if (!a.isEmpty()) return !0;
            a.set("TESTCOOKIESENABLED", "1", {
                hg: 60
            });
            if ("1" !== a.get("TESTCOOKIESENABLED")) return !1;
            FE(a, "TESTCOOKIESENABLED");
            return !0
        };
    Of.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.On;
            d = c.Hl || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.hg
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.j.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    Of.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.j.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = sv(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    var FE = function(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            hg: 0,
            path: c,
            domain: d
        })
    };
    Of.prototype.isEmpty = function() {
        return !this.j.cookie
    };
    Of.prototype.clear = function() {
        for (var a = (this.j.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = sv(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) FE(this, b[a])
    };
    var EE = new Of("undefined" == typeof document ? null : document);
    var HE = function(a, b) {
        this.j = a;
        this.options = b
    };
    var IE = function(a, b) {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        JE = function(a, b) {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        KE = function(a, b) {
            (0, a.__gpp)("getSection", function(c) {
                b.Jb({
                    bc: null != c ? c : void 0,
                    ve: c ? void 0 : 4
                })
            }, b.apiPrefix)
        },
        LE = {
            Gd: function(a) {
                return a.listener
            },
            Mc: function(a, b) {
                a = {};
                return a.__gppCall = {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }, a
            },
            xc: function(a, b) {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        ME = {
            Gd: function(a) {
                return a.listener
            },
            Mc: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }, c
            },
            xc: function(a, b) {
                b = b.__gppReturn;
                var c = b.returnValue.data;
                null == a || a(c, b.success)
            }
        },
        NE = {
            Gd: function(a) {
                return a.Jb
            },
            Mc: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "getSection",
                    version: "1.1",
                    parameter: a.apiPrefix
                }, c
            },
            xc: function(a, b) {
                b = b.__gppReturn;
                var c;
                a({
                    bc: null != (c = b.returnValue) ? c : void 0,
                    ve: b.success ? void 0 : 2
                })
            }
        },
        OE = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            this.caller = new LC(a, "__gppLocator", function(d) {
                return "function" === typeof d.__gpp
            }, Hf);
            this.caller.l.set("addEventListener", IE);
            this.caller.m.set("addEventListener", LE);
            this.caller.l.set("removeEventListener", JE);
            this.caller.m.set("removeEventListener", ME);
            this.caller.l.set("getDataWithCallback", KE);
            this.caller.m.set("getDataWithCallback", NE);
            var c;
            this.timeoutMs = null != (c = b.timeoutMs) ? c : 500
        };
    _.T(OE, _.U);
    OE.prototype.o = function() {
        this.caller.wa();
        _.U.prototype.o.call(this)
    };
    OE.prototype.addEventListener = function(a) {
        var b = this,
            c = _.ev(function() {
                a(PE, !0)
            }),
            d = -1 === this.timeoutMs ? void 0 : setTimeout(function() {
                c()
            }, this.timeoutMs);
        OC(this.caller, "addEventListener", {
            listener: function(e, f) {
                clearTimeout(d);
                try {
                    var g;
                    if (void 0 === (null == (g = e.pingData) ? void 0 : g.gppVersion) || "1" === e.pingData.gppVersion || "1.0" === e.pingData.gppVersion) {
                        b.removeEventListener(e.listenerId);
                        var h = {
                            eventName: "signalStatus",
                            data: "ready",
                            pingData: {
                                internalErrorState: 1,
                                gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                applicableSections: [-1]
                            }
                        }
                    } else Array.isArray(e.pingData.applicableSections) && 0 !== e.pingData.applicableSections.length ? h = e : (b.removeEventListener(e.listenerId), h = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 2,
                            gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                            applicableSections: [-1]
                        }
                    });
                    a(h, f)
                } catch (k) {
                    if (null == e ? 0 : e.listenerId) try {
                        b.removeEventListener(e.listenerId)
                    } catch (l) {
                        a(QE, !0);
                        return
                    }
                    a(RE, !0)
                }
            }
        })
    };
    OE.prototype.removeEventListener = function(a) {
        OC(this.caller, "removeEventListener", {
            listenerId: a
        })
    };
    var SE = function(a) {
            var b = bf(a.split("~")[0] + "A"),
                c = cf(b.slice(0, 6)),
                d = cf(b.slice(6, 12)),
                e = new eA;
            var f = _.yh(e, 1, c);
            var g = _.yh(f, 2, d);
            for (var h = b.slice(12), k = cf(h.slice(0, 12)), l = [], m = h.slice(12).replace(/0+$/, ""), n = 0; n < k; n++) {
                if (0 === m.length) throw Error("Found " + n + " of " + k + " sections [" + l + "] but reached end of input [" + h + "]");
                var p = 0 === cf(m[0]);
                m = m.slice(1);
                var r = ef(m, h),
                    w = 0 === l.length ? 0 : l[l.length - 1],
                    u = df(r) + w;
                m = m.slice(r.length);
                if (p) l.push(u);
                else {
                    for (var x = ef(m, h), y = df(x), C = 0; C <= y; C++) l.push(u + C);
                    m = m.slice(x.length)
                }
            }
            if (0 < m.length) throw Error("Found " + k + " sections [" + l + "] but has remaining input [" + m + "], entire input [" + h + "]");
            var D = _.ie(g, 3, l, Lc);
            var E = _.A(a, "includes").call(a, "~") ? a.split("~").slice(1) : [];
            for (var J = 0; J < Xd(D, 3, Mc).length; ++J) {
                var M = Xd(D, 3, Mc)[J],
                    K = E[J];
                switch (M) {
                    case 8:
                        if (0 === K.length) throw Error("Cannot decode empty USCA section string");
                        var X = K.split(".");
                        if (2 < X.length) throw Error("Expected at most 1 sub-section but got " + (X.length - 1) + " when decoding " + K);
                        var ba = void 0,
                            la = void 0,
                            pa = void 0,
                            za = void 0,
                            ya = void 0,
                            Qa = void 0,
                            Ga = void 0,
                            zb = void 0,
                            bb = void 0,
                            wb = void 0,
                            bc = void 0,
                            Hc = void 0,
                            jc = void 0,
                            Zd = void 0,
                            Ic = void 0,
                            rd = void 0,
                            $d = void 0,
                            xb = void 0,
                            kc = void 0,
                            Th = void 0,
                            il = void 0,
                            Jf = void 0,
                            Cg = void 0,
                            Xc = bf(X[0]),
                            ae = cf(Xc.slice(0, 6));
                        Xc = Xc.slice(6);
                        if (1 !== ae) throw Error("Unable to decode unsupported USCA Section specification version " + ae + " - only version 1 is supported.");
                        if (Xc.length < mA)
                            if (Xc.length + 8 >= mA) Xc += "00000000";
                            else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + mA + " but was " + (Xc.length + 8));
                        for (var sd = 0, Ra = [], Dg = 0; Dg < lA.length; Dg++) {
                            var lc = lA[Dg];
                            Ra.push(cf(Xc.slice(sd, sd + lc)));
                            sd += lc
                        }
                        var Kf = new hA;
                        Cg = _.yh(Kf, 1, ae);
                        var wc = Ra.shift();
                        Jf = _.I(Cg, 2, wc);
                        var xc = Ra.shift();
                        il = _.I(Jf, 3, xc);
                        var bq = Ra.shift();
                        Th = _.I(il, 4, bq);
                        var JS = Ra.shift();
                        kc = _.I(Th, 5, JS);
                        var KS = Ra.shift();
                        xb = _.I(kc, 6, KS);
                        var LS = new gA,
                            MS = Ra.shift();
                        $d = _.I(LS, 1, MS);
                        var NS = Ra.shift();
                        rd = _.I($d, 2, NS);
                        var OS = Ra.shift();
                        Ic = _.I(rd, 3, OS);
                        var PS = Ra.shift();
                        Zd = _.I(Ic, 4, PS);
                        var QS = Ra.shift();
                        jc = _.I(Zd, 5, QS);
                        var RS = Ra.shift();
                        Hc = _.I(jc, 6, RS);
                        var SS = Ra.shift();
                        bc = _.I(Hc, 7, SS);
                        var TS = Ra.shift();
                        wb = _.I(bc, 8, TS);
                        var US = Ra.shift();
                        bb = _.I(wb, 9, US);
                        zb = _.th(xb, 7, bb);
                        var VS = new fA,
                            WS = Ra.shift();
                        Ga = _.I(VS, 1, WS);
                        var XS = Ra.shift();
                        Qa = _.I(Ga, 2, XS);
                        ya = _.th(zb, 8, Qa);
                        var YS = Ra.shift();
                        za = _.I(ya, 9, YS);
                        var ZS = Ra.shift();
                        pa = _.I(za, 10, ZS);
                        var $S = Ra.shift();
                        la = _.I(pa, 11, $S);
                        var aT = Ra.shift();
                        var cD = ba = _.I(la, 12, aT);
                        if (1 === X.length) var dD = kA(cD);
                        else {
                            var bT = kA(cD),
                                eD = void 0,
                                fD = void 0,
                                gD = void 0,
                                qi = bf(X[1]);
                            if (3 > qi.length) throw Error("Invalid GPC Segment [" + qi + "]. Expected length 3, but was " + qi.length + ".");
                            var Tl = cf(qi.slice(0, 2));
                            if (0 > Tl || 1 < Tl) throw Error("Attempting to decode unknown GPC segment subsection type " + Tl + ".");
                            gD = Tl + 1;
                            var cT = cf(qi.charAt(2)),
                                dT = new iA;
                            fD = _.I(dT, 2, gD);
                            eD = _.xh(fD, 1, !!cT);
                            dD = _.th(bT, 2, eD)
                        }
                        var hD = _.Zh(dD, hA, 1);
                        if (1 === _.Hk(hD, 5, 0) || 1 === _.Hk(hD, 6, 0)) return !0;
                        break;
                    case 10:
                        if (0 === K.length) throw Error("Cannot decode empty USCO section string.");
                        var ri = K.split(".");
                        if (2 < ri.length) throw Error("Expected at most 2 segments but got " + ri.length + " when decoding " + K);
                        var eT = void 0,
                            iD = void 0,
                            jD = void 0,
                            kD = void 0,
                            lD = void 0,
                            mD = void 0,
                            nD = void 0,
                            oD = void 0,
                            pD = void 0,
                            qD = void 0,
                            rD = void 0,
                            sD = void 0,
                            tD = void 0,
                            uD = void 0,
                            vD = void 0,
                            wD = void 0,
                            xD = void 0,
                            yD = void 0,
                            Re = bf(ri[0]),
                            $r = cf(Re.slice(0, 6));
                        Re = Re.slice(6);
                        if (1 !== $r) throw Error("Unable to decode unsupported USCO Section specification version " + $r + " - only version 1 is supported.");
                        if (Re.length < tA)
                            if (Re.length + 8 >= tA) Re += "00000000";
                            else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + tA + " but was " + (Re.length + 8));
                        for (var as = 0, Ub = [], bs = 0; bs < sA.length; bs++) {
                            var zD = sA[bs];
                            Ub.push(cf(Re.slice(as, as + zD)));
                            as += zD
                        }
                        var fT = new oA;
                        yD = _.yh(fT, 1, $r);
                        var gT = Ub.shift();
                        xD = _.I(yD, 2, gT);
                        var hT = Ub.shift();
                        wD = _.I(xD, 3, hT);
                        var iT = Ub.shift();
                        vD = _.I(wD, 4, iT);
                        var jT = Ub.shift();
                        uD = _.I(vD, 5, jT);
                        var kT = Ub.shift();
                        tD = _.I(uD, 6, kT);
                        var lT = new nA,
                            mT = Ub.shift();
                        sD = _.I(lT, 1, mT);
                        var nT = Ub.shift();
                        rD = _.I(sD, 2, nT);
                        var oT = Ub.shift();
                        qD = _.I(rD, 3, oT);
                        var pT = Ub.shift();
                        pD = _.I(qD, 4, pT);
                        var qT = Ub.shift();
                        oD = _.I(pD, 5, qT);
                        var rT = Ub.shift();
                        nD = _.I(oD, 6, rT);
                        var sT = Ub.shift();
                        mD = _.I(nD, 7, sT);
                        lD = _.th(tD, 7, mD);
                        var tT = Ub.shift();
                        kD = _.I(lD, 8, tT);
                        var uT = Ub.shift();
                        jD = _.I(kD, 9, uT);
                        var vT = Ub.shift();
                        iD = _.I(jD, 10, vT);
                        var wT = Ub.shift();
                        var AD = eT = _.I(iD, 11, wT);
                        if (1 === ri.length) var BD = rA(AD);
                        else {
                            var xT = rA(AD),
                                CD = void 0,
                                DD = void 0,
                                ED = void 0,
                                si = bf(ri[1]);
                            if (3 > si.length) throw Error("Invalid GPC Segment [" + si + "]. Expected length 3, but was " + si.length + ".");
                            var Ul = cf(si.slice(0, 2));
                            if (0 > Ul || 1 < Ul) throw Error("Attempting to decode unknown GPC segment subsection type " + Ul + ".");
                            ED = Ul + 1;
                            var yT = cf(si.charAt(2)),
                                zT = new pA;
                            DD = _.I(zT, 2, ED);
                            CD = _.xh(DD, 1, !!yT);
                            BD = _.th(xT, 2, CD)
                        }
                        var FD = _.Zh(BD, oA, 1);
                        if (1 === _.Hk(FD, 5, 0) || 1 === _.Hk(FD, 6, 0)) return !0;
                        break;
                    case 12:
                        if (0 === K.length) throw Error("Cannot decode empty usct section string.");
                        var ti = K.split(".");
                        if (2 < ti.length) throw Error("Expected at most 2 segments but got " + ti.length + " when decoding " + K);
                        var AT = void 0,
                            GD = void 0,
                            HD = void 0,
                            ID = void 0,
                            JD = void 0,
                            KD = void 0,
                            LD = void 0,
                            MD = void 0,
                            ND = void 0,
                            OD = void 0,
                            PD = void 0,
                            QD = void 0,
                            RD = void 0,
                            SD = void 0,
                            TD = void 0,
                            UD = void 0,
                            VD = void 0,
                            WD = void 0,
                            XD = void 0,
                            YD = void 0,
                            ZD = void 0,
                            $D = void 0,
                            Se = bf(ti[0]),
                            cs = cf(Se.slice(0, 6));
                        Se = Se.slice(6);
                        if (1 !== cs) throw Error("Unable to decode unsupported USCT Section specification version " + cs + " - only version 1 is supported.");
                        if (Se.length < BA)
                            if (Se.length + 8 >= BA) Se += "00000000";
                            else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + BA + " but was " + (Se.length + 8));
                        for (var ds = 0, Bb = [], es = 0; es < AA.length; es++) {
                            var aE = AA[es];
                            Bb.push(cf(Se.slice(ds, ds + aE)));
                            ds += aE
                        }
                        var BT = new wA;
                        $D = _.yh(BT, 1, cs);
                        var CT = Bb.shift();
                        ZD = _.I($D, 2, CT);
                        var DT = Bb.shift();
                        YD = _.I(ZD, 3, DT);
                        var ET = Bb.shift();
                        XD = _.I(YD, 4, ET);
                        var FT = Bb.shift();
                        WD = _.I(XD, 5, FT);
                        var GT = Bb.shift();
                        VD = _.I(WD, 6, GT);
                        var HT = new vA,
                            IT = Bb.shift();
                        UD = _.I(HT, 1, IT);
                        var JT = Bb.shift();
                        TD = _.I(UD, 2, JT);
                        var KT = Bb.shift();
                        SD = _.I(TD, 3, KT);
                        var LT = Bb.shift();
                        RD = _.I(SD, 4, LT);
                        var MT = Bb.shift();
                        QD = _.I(RD, 5, MT);
                        var NT = Bb.shift();
                        PD = _.I(QD, 6, NT);
                        var OT = Bb.shift();
                        OD = _.I(PD, 7, OT);
                        var PT = Bb.shift();
                        ND = _.I(OD, 8, PT);
                        MD = _.th(VD, 7, ND);
                        var QT = new uA,
                            RT = Bb.shift();
                        LD = _.I(QT, 1, RT);
                        var ST = Bb.shift();
                        KD = _.I(LD, 2, ST);
                        var TT = Bb.shift();
                        JD = _.I(KD, 3, TT);
                        ID = _.th(MD, 8, JD);
                        var UT = Bb.shift();
                        HD = _.I(ID, 9, UT);
                        var VT = Bb.shift();
                        GD = _.I(HD, 10, VT);
                        var WT = Bb.shift();
                        var bE = AT = _.I(GD, 11, WT);
                        if (1 === ti.length) var cE = zA(bE);
                        else {
                            var XT = zA(bE),
                                dE = void 0,
                                eE = void 0,
                                fE = void 0,
                                ui = bf(ti[1]);
                            if (3 > ui.length) throw Error("Invalid GPC Segment [" + ui + "]. Expected length 3, but was " + ui.length + ".");
                            var Vl = cf(ui.slice(0, 2));
                            if (0 > Vl || 1 < Vl) throw Error("Attempting to decode unknown GPC segment subsection type " + Vl + ".");
                            fE = Vl + 1;
                            var YT = cf(ui.charAt(2)),
                                ZT = new xA;
                            eE = _.I(ZT, 2, fE);
                            dE = _.xh(eE, 1, !!YT);
                            cE = _.th(XT, 2, dE)
                        }
                        var gE = _.Zh(cE, wA, 1);
                        if (1 === _.Hk(gE, 5, 0) || 1 === _.Hk(gE, 6, 0)) return !0;
                        break;
                    case 9:
                        if (0 === K.length) throw Error("Cannot decode empty USVA section string.");
                        var Te = bf(K),
                            fs = cf(Te.slice(0, 6));
                        Te = Te.slice(6);
                        if (1 !== fs) throw Error("Unable to decode unsupported USVA Section specification version " + fs + " - only version 1 is supported.");
                        if (Te.length < FA)
                            if (Te.length + 8 >= FA) Te += "00000000";
                            else throw Error("Expected bitstring minus version plus padding to be at least of length " + FA + " but was " + (Te.length + 8));
                        for (var gs = 0, Nb = [], hs = 0; hs < EA.length; hs++) {
                            var hE = EA[hs];
                            Nb.push(cf(Te.slice(gs, gs + hE)));
                            gs += hE
                        }
                        var $T = fs,
                            aU = new DA;
                        var bU = _.yh(aU, 1, $T);
                        var cU = Nb.shift();
                        var dU = _.I(bU, 2, cU);
                        var eU = Nb.shift();
                        var fU = _.I(dU, 3, eU);
                        var gU = Nb.shift();
                        var hU = _.I(fU, 4, gU);
                        var iU = Nb.shift();
                        var jU = _.I(hU, 5, iU);
                        var kU = Nb.shift();
                        var lU = _.I(jU, 6, kU);
                        var mU = new CA,
                            nU = Nb.shift();
                        var oU = _.I(mU, 1, nU);
                        var pU = Nb.shift();
                        var qU = _.I(oU, 2, pU);
                        var rU = Nb.shift();
                        var sU = _.I(qU, 3, rU);
                        var tU = Nb.shift();
                        var uU = _.I(sU, 4, tU);
                        var vU = Nb.shift();
                        var wU = _.I(uU, 5, vU);
                        var xU = Nb.shift();
                        var yU = _.I(wU, 6, xU);
                        var zU = Nb.shift();
                        var AU = _.I(yU, 7, zU);
                        var BU = Nb.shift();
                        var CU = _.I(AU, 8, BU);
                        var DU = _.th(lU, 7, CU);
                        var EU = Nb.shift();
                        var FU = _.I(DU, 8, EU);
                        var GU = Nb.shift();
                        var HU = _.I(FU, 9, GU);
                        var IU = Nb.shift();
                        var JU = _.I(HU, 10, IU);
                        var KU = Nb.shift(),
                            iE = _.I(JU, 11, KU);
                        if (1 === _.Hk(iE, 5, 0) || 1 === _.Hk(iE, 6, 0)) return !0
                }
            }
            return !1
        },
        RE = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        PE = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        QE = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };
    var Fm = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, Fm.prototype)
    };
    _.T(Fm, Error);
    Fm.prototype.name = "PublisherInputError";
    var TE = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, TE.prototype)
    };
    _.T(TE, Error);
    TE.prototype.name = "ServerError";
    var UE = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, UE.prototype)
    };
    _.T(UE, Error);
    UE.prototype.name = "NetworkError";
    var VE = 0,
        WE = Ue(_.bv(cv("https://pagead2.googlesyndication.com/pagead/expansion_embed.js")));
    var XE = null,
        YE = function() {
            if (null === XE) {
                XE = "";
                try {
                    var a = "";
                    try {
                        a = _.t.top.location.hash
                    } catch (c) {
                        a = _.t.location.hash
                    }
                    if (a) {
                        var b = a.match(/\bdeid=([\d,]+)/);
                        XE = b ? b[1] : ""
                    }
                } catch (c) {}
            }
            return XE
        };
    _.Rf = function(a) {
        var b = "qc";
        if (a.qc && a.hasOwnProperty(b)) return a.qc;
        b = new a;
        return a.qc = b
    };
    var Sf = function() {};
    Sf.prototype.j = function() {};
    Sf.prototype.m = function() {};
    Sf.prototype.o = function() {
        return []
    };
    Sf.prototype.A = function() {
        return []
    };
    var hg = function(a, b) {
        a.j = Qf(1, b, function() {});
        a.o = function(c, d) {
            return Qf(2, b, function() {
                return []
            })(c, 2, d)
        };
        a.A = function() {
            return Qf(3, b, function() {
                return []
            })(2)
        };
        a.m = function(c) {
            Qf(16, b, function() {})(c, 2)
        }
    };
    var bg = function() {
        var a = {};
        this.o = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.m = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.A = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.J = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.j = function() {}
    };
    var fg = function() {
            this.j = function() {}
        },
        jg = function(a, b) {
            a.j = Qf(14, b, function() {})
        };
    var Dp = _.tu(["(a=0)=>{let b;const c=null ?? 1;}"]);
    var fi = function(a, b, c) {
            a && null !== b && b != b.top && (b = b.top);
            try {
                return (void 0 === c ? 0 : c) ? (new _.xi(b.innerWidth, b.innerHeight)).round() : _.az(b || window).round()
            } catch (d) {
                return new _.xi(-12245933, -12245933)
            }
        },
        ZE = function(a) {
            return "CSS1Compat" == a.compatMode ? a.documentElement : a.body
        },
        ut = function(a, b) {
            b = void 0 === b ? _.t : b;
            a = a.scrollingElement || ZE(a);
            return new _.oi(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
        },
        Ji = function(a) {
            try {
                return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
            } catch (b) {
                return !1
            }
        };
    var $E = function(a) {
        this.D = _.B(a)
    };
    _.T($E, _.F);
    var Lf = function(a) {
            return _.N(a, 5)
        },
        aF = function(a, b) {
            Fj(a, 13, b)
        },
        bF = function(a, b) {
            Fj(a, 12, b)
        },
        cF = function(a, b) {
            return _.ie(a, 10, b, _.Tc)
        },
        dF = function(a, b) {
            return Vn(a, 11, b)
        };
    $E.ca = [10];
    var fF, gF, hF;
    _.eF = function(a) {
        this.j = a;
        this.o = 0
    };
    fF = function(a, b) {
        if (0 === a.o) {
            if (_.Sl(a, "__gads", b)) b = !0;
            else {
                var c = a.j;
                Lf(b) && Nf(c) && (new Of(c.document)).set("GoogleAdServingTest", "Good", void 0);
                if (c = "Good" === Pf("GoogleAdServingTest", b, a.j)) {
                    var d = a.j;
                    Lf(b) && Nf(d) && FE(new Of(d.document), "GoogleAdServingTest")
                }
                b = c
            }
            a.o = b ? 2 : 1
        }
        return 2 === a.o
    };
    _.Sl = function(a, b, c) {
        return c ? Pf(b, c, a.j) : null
    };
    gF = function(a, b, c, d) {
        if (d) {
            var e = _.sf(c, 2) - Date.now() / 1E3;
            e = {
                hg: Math.max(e, 0),
                path: _.R(c, 3),
                domain: _.R(c, 4),
                Hl: !1
            };
            c = c.getValue();
            a = a.j;
            Lf(d) && Nf(a) && (new Of(a.document)).set(b, c, e)
        }
    };
    hF = function(a, b, c) {
        if (c && Pf(b, c, a.j)) {
            var d = a.j.location.hostname;
            if ("localhost" === d) d = ["localhost"];
            else if (d = d.split("."), 2 > d.length) d = [];
            else {
                for (var e = [], f = 0; f < d.length - 1; ++f) e.push(d.slice(f).join("."));
                d = e
            }
            d = _.z(d);
            for (e = d.next(); !e.done; e = d.next()) f = a.j, Lf(c) && Nf(f) && FE(new Of(f.document), b, "/", e.value)
        }
    };
    var iF = {},
        jF = (iF[3] = Ue(_.bv(cv("https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js"))), iF);
    ({})[3] = Ue(_.bv(cv("https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js")));
    var kF = function(a) {
            this.j = a;
            this.o = Sy()
        },
        lF = function(a) {
            var b = {};
            _.hv(a, function(c) {
                b[c.j] = c.o
            });
            return b
        };
    _.mF = _.tu(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]);
    var nF = function(a, b, c, d, e, f) {
        _.U.call(this);
        this.ub = a;
        this.status = 1;
        this.A = b;
        this.m = c;
        this.G = d;
        this.Bd = !!e;
        this.l = Math.random();
        this.H = {};
        this.j = null;
        this.M = (0, _.Wu)(this.C, this);
        this.I = f
    };
    _.T(nF, _.U);
    nF.prototype.C = function(a) {
        if (!("*" !== this.m && a.origin !== this.m || !this.Bd && a.source != this.A)) {
            var b = null;
            try {
                b = JSON.parse(a.data)
            } catch (c) {}
            if (_.ka(b) && (a = b.i, b.c === this.ub && a != this.l)) {
                if (2 !== this.status) try {
                    this.status = 2, oF(this), this.j && (this.j(), this.j = null)
                } catch (c) {}
                a = b.s;
                b = b.p;
                if ("string" === typeof a && ("string" === typeof b || _.ka(b)) && this.H.hasOwnProperty(a)) this.H[a](b)
            }
        }
    };
    var oF = function(a) {
        var b = {};
        b.c = a.ub;
        b.i = a.l;
        a.I && (b.e = a.I);
        a.A.postMessage(JSON.stringify(b), a.m)
    };
    nF.prototype.v = function() {
        if (1 === this.status) {
            try {
                this.A.postMessage && oF(this)
            } catch (a) {}
            window.setTimeout((0, _.Wu)(this.v, this), 50)
        }
    };
    nF.prototype.connect = function(a) {
        a && (this.j = a);
        _.jb(window, "message", this.M);
        this.G && this.v()
    };
    var pF = function(a, b, c) {
        a.H[b] = c
    };
    nF.prototype.send = function(a, b) {
        var c = {};
        c.c = this.ub;
        c.i = this.l;
        c.s = a;
        c.p = b;
        try {
            this.A.postMessage(JSON.stringify(c), this.m)
        } catch (d) {}
    };
    nF.prototype.o = function() {
        this.status = 3;
        _.uf(window, "message", this.M);
        _.U.prototype.o.call(this)
    };
    var qF = new _.v.Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        rF = new _.v.Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);
    var sF = function(a) {
        this.D = _.B(a)
    };
    _.T(sF, _.F);
    var tF = Pe(sF);
    var uF = function(a) {
        this.D = _.B(a)
    };
    _.T(uF, _.F);
    var vF = function(a) {
        this.D = _.B(a)
    };
    _.T(vF, _.F);
    var wF, xF, yF, zF;
    _.rq = function(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    };
    wF = function(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };
    xF = function(a) {
        return null != a.hidden ? a.hidden : null != a.mozHidden ? a.mozHidden : null != a.webkitHidden ? a.webkitHidden : null
    };
    yF = function(a, b) {
        if (3 == _.rq(b)) return !1;
        a();
        return !0
    };
    zF = function(a, b) {
        var c = _.H(tB);
        c = void 0 === c ? !1 : c;
        if (!yF(a, b))
            if (c) {
                var d = function() {
                    _.uf(b, "prerenderingchange", d);
                    a()
                };
                _.jb(b, "prerenderingchange", d)
            } else {
                var e = !1,
                    f = wF(b),
                    g = function() {
                        !e && yF(a, b) && (e = !0, _.uf(b, f, g))
                    };
                f && _.jb(b, f, g)
            }
    };
    var Lq = function(a, b) {
        this.j = a;
        this.m = b;
        this.o = {}
    };
    Lq.prototype.oa = function() {
        var a = this;
        Fq() && (document.addEventListener("touchstart", function(b) {
            a.j(902, function() {
                a.o[b.touches[0].identifier] = Date.now()
            })()
        }, _.gv), document.addEventListener("touchend", function(b) {
            a.j(902, function() {
                var c = b.changedTouches[0],
                    d = c.clientX,
                    e = c.clientY,
                    f = c.force;
                c = a.o[c.identifier];
                if (void 0 !== c) try {
                    var g = Fq(),
                        h = {
                            x: d,
                            y: e,
                            duration_ms: Date.now() - c
                        };
                    if (null == g ? 0 : g.gmaSdk) g.gmaSdk.reportTouchEvent(JSON.stringify(_.A(Object, "assign").call(Object, {}, h, {
                        type: 1,
                        force: f
                    })));
                    else {
                        var k, l, m;
                        null == g || null == (k = g.webkit) || null == (l = k.messageHandlers) || null == (m = l.reportGmaTouchEvent) || m.postMessage(h)
                    }
                } catch (n) {
                    a.m("paw_sigs", {
                        msg: "reportTouchError",
                        err: n instanceof Error ? n.message : "nonError"
                    })
                }
            })()
        }, _.gv))
    };
    var Gq = function(a, b, c, d, e) {
            var f = 200,
                g = yq;
            b = void 0 === b ? {} : b;
            c = void 0 === c ? function() {} : c;
            d = void 0 === d ? function() {} : d;
            f = void 0 === f ? 200 : f;
            var h = String(Math.floor(2147483647 * _.Zf())),
                k = 0,
                l = function(m) {
                    try {
                        var n = "object" === typeof m.data ? m.data : JSON.parse(m.data);
                        h === n.paw_id && (window.clearTimeout(k), window.removeEventListener("message", l), n.signal ? c(n.signal) : n.error && d(n.error))
                    } catch (p) {
                        g("paw_sigs", {
                            msg: "postmessageError",
                            err: p instanceof Error ? p.message : "nonError",
                            data: null == m.data ? "null" : 500 < m.data.length ? m.data.substring(0, 500) : m.data
                        })
                    }
                };
            window.addEventListener("message", function(m) {
                e(903, function() {
                    l(m)
                })()
            });
            a.postMessage(_.A(Object, "assign").call(Object, {}, {
                paw_id: h
            }, b));
            k = window.setTimeout(function() {
                window.removeEventListener("message", l);
                d("PAW GMA postmessage timed out.")
            }, f)
        },
        Fq = function() {
            var a = window,
                b, c;
            if (a.gmaSdk || (null == (b = a.webkit) ? 0 : null == (c = b.messageHandlers) ? 0 : c.getGmaViewSignals)) return a;
            try {
                var d = window.parent,
                    e, f;
                if (d.gmaSdk || (null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals)) return d
            } catch (g) {}
            return null
        };
    _.lg = function() {
        var a = this;
        this.promise = new _.v.Promise(function(b, c) {
            a.resolve = b;
            a.reject = c
        })
    };
    var DF, CF, FF, EF;
    _.AF = function() {
        this.m = "&";
        this.o = {};
        this.A = 0;
        this.j = []
    };
    _.BF = function(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    };
    DF = function(a, b, c, d, e) {
        var f = [];
        _.Ll(a, function(g, h) {
            (g = CF(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    };
    CF = function(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                for (var f = [], g = 0; g < a.length; g++) f.push(CF(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(DF(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    };
    FF = function(a, b) {
        var c = "https://pagead2.googlesyndication.com" + b,
            d = EF(a) - b.length;
        if (0 > d) return "";
        a.j.sort(function(m, n) {
            return m - n
        });
        b = null;
        for (var e = "", f = 0; f < a.j.length; f++)
            for (var g = a.j[f], h = a.o[g], k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                var l = DF(h[k], a.m, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.m;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    };
    EF = function(a) {
        var b = 1,
            c;
        for (c in a.o) b = c.length > b ? c.length : b;
        return 3997 - b - a.m.length - 1
    };
    _.GF = function() {
        this.j = Math.random()
    };
    _.Ug = function(a, b, c, d, e) {
        if (((void 0 === d ? 0 : d) ? a.j : Math.random()) < (e || .001)) try {
            if (c instanceof _.AF) var f = c;
            else f = new _.AF, _.Ll(c, function(h, k) {
                var l = f,
                    m = l.A++;
                h = _.BF(k, h);
                l.j.push(m);
                l.o[m] = h
            });
            var g = FF(f, "/pagead/gen_204?id=" + b + "&");
            g && SC(_.t, g)
        } catch (h) {}
    };
    var HF = function(a) {
        this.D = _.B(a)
    };
    _.T(HF, _.F);
    var IF = function(a, b) {
        return _.Uh(a, 1, b)
    };
    HF.ca = [1];
    var JF = function(a) {
        this.D = _.B(a)
    };
    _.T(JF, _.F);
    JF.ca = [1];
    var KF = function(a) {
        this.D = _.B(a)
    };
    _.T(KF, _.F);
    var LF = function(a, b) {
        return _.I(a, 1, b)
    };
    var MF = function(a) {
        this.D = _.B(a)
    };
    _.T(MF, _.F);
    var NF = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, NF.prototype);
        this.name = "InputError"
    };
    _.T(NF, Error);
    var OF = function() {
            this.fb = !1
        },
        PF = function() {
            OF.apply(this, arguments);
            this.j = [];
            this.Nd = new _.lg
        };
    _.T(PF, OF);
    var RF = function(a, b) {
            a.fb || (a.fb = !0, a.Rc = b, a.Nd.resolve(b), _.H(AB) && QF(a))
        },
        SF = function(a, b) {
            a.fb = !0;
            a.Ve = b;
            a.Nd.reject(b);
            _.H(AB) && QF(a)
        },
        QF = function(a) {
            for (var b = _.z(a.j), c = b.next(); !c.done; c = b.next()) c = c.value, c(a.Rc);
            a.j.length = 0
        };
    PF.prototype.me = function() {
        this.j.length = 0
    };
    var XA = function(a, b) {
        _.H(AB) && a.j.push(b)
    };
    _.ou.Object.defineProperties(PF.prototype, {
        promise: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Nd.promise
            }
        },
        zb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.fb
            }
        },
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ve
            }
        }
    });
    var yn = function() {
        PF.apply(this, arguments)
    };
    _.T(yn, PF);
    _.q = yn.prototype;
    _.q.F = function(a) {
        RF(this, a)
    };
    _.q.Ca = function(a) {
        RF(this, null != a ? a : null)
    };
    _.q.aa = function() {
        RF(this, null)
    };
    _.q.Ja = function(a) {
        var b = this;
        a.then(function(c) {
            RF(b, c)
        })
    };
    _.q.gb = function(a) {
        this.fb || (this.fb = !0, this.Rc = null, this.Ve = a, this.Nd.reject(a), _.H(AB) && QF(this))
    };
    var TF = function() {
        PF.apply(this, arguments)
    };
    _.T(TF, PF);
    TF.prototype.F = function(a) {
        RF(this, a)
    };
    TF.prototype.Ja = function(a) {
        var b = this;
        a.then(function(c) {
            return void RF(b, c)
        })
    };
    TF.prototype.gb = function(a) {
        this.fb || (this.fb = !0, this.Ve = a, this.Nd.reject(a))
    };
    var UF = function() {
        TF.apply(this, arguments)
    };
    _.T(UF, TF);
    UF.prototype.Ca = function(a) {
        RF(this, null != a ? a : null)
    };
    UF.prototype.aa = function() {
        RF(this, null)
    };
    UF.prototype.Ja = function(a) {
        var b = this;
        a.then(function(c) {
            return void b.Ca(c)
        })
    };
    var VF = function(a) {
        this.fb = !1;
        this.Ob = a
    };
    _.T(VF, OF);
    VF.prototype.zb = function() {
        return this.Ob.fb
    };
    VF.prototype.Wf = function() {
        return null != this.Ob.Rc
    };
    _.ou.Object.defineProperties(VF.prototype, {
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ob.Ve
            }
        }
    });
    var WF = function(a) {
        VF.call(this, a);
        this.Ob = a
    };
    _.T(WF, VF);
    _.ou.Object.defineProperties(WF.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ob.Rc
            }
        }
    });
    var XF = function(a) {
        VF.call(this, a);
        this.Ob = a
    };
    _.T(XF, VF);
    _.ou.Object.defineProperties(XF.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.Ob.Rc) ? a : null
            }
        }
    });
    var YF = function() {
        VF.apply(this, arguments)
    };
    _.T(YF, VF);
    _.ou.Object.defineProperties(YF.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.Ob.Rc) ? a : null
            }
        }
    });
    var Cn = function() {
        PF.apply(this, arguments)
    };
    _.T(Cn, PF);
    Cn.prototype.notify = function() {
        RF(this, null)
    };
    var ZF = function(a, b) {
            b.then(function() {
                a.notify()
            })
        },
        $F = function(a, b) {
            b = void 0 === b ? !1 : b;
            PF.call(this);
            var c = this;
            this.m = a;
            this.o = 0;
            if (_.H(AB)) {
                a = _.z(this.m);
                for (var d = a.next(), e = {}; !d.done; e = {
                        Md: e.Md
                    }, d = a.next()) e.Md = d.value, XA(e.Md, function(f) {
                    return function(g) {
                        c.o += 1;
                        f.Md.error ? SF(c, f.Md.error) : b || null !== g ? RF(c, null != g ? g : null) : c.o === c.m.length && RF(c, null)
                    }
                }(e))
            } else a = a.map(function(f) {
                return f.promise.then(function(g) {
                    if (b || null != g) return g;
                    throw g;
                }, function(g) {
                    SF(c, g);
                    return null
                })
            }), _.A(_.v.Promise, "any").call(_.v.Promise, a).then(function(f) {
                c.fb || RF(c, f)
            }, function() {
                c.fb || RF(c, null)
            })
        };
    _.T($F, PF);
    var aG = function(a, b) {
        PF.call(this);
        this.timeoutMs = a;
        this.defaultValue = b
    };
    _.T(aG, PF);
    var vg = function(a) {
        setTimeout(function() {
            var b;
            RF(a, null != (b = a.defaultValue) ? b : null)
        }, a.timeoutMs)
    };
    var bG = function(a) {
        _.U.call(this);
        this.H = a;
        this.j = [];
        this.m = [];
        this.l = [];
        this.A = []
    };
    _.T(bG, _.U);
    var cG = function(a, b, c) {
        a.m.push({
            Vb: void 0 === c ? !1 : c,
            Cb: b
        });
        _.H(AB) && XA(b, a.H)
    };
    bG.prototype.o = function() {
        this.j.length = 0;
        this.l.length = 0;
        if (_.H(AB))
            for (var a = _.z(this.m), b = a.next(); !b.done; b = a.next()) b.value.Cb.me();
        this.m.length = 0;
        this.A.length = 0;
        _.U.prototype.o.call(this)
    };
    var eG = function(a, b, c) {
        _.U.call(this);
        var d = this;
        this.id = a;
        this.timeoutMs = b;
        this.M = c;
        this.Ha = this.Ea = this.ua = this.started = !1;
        this.A = new bG(function() {
            dG(d)
        });
        _.S(this, this.A)
    };
    _.T(eG, _.U);
    eG.prototype.start = function() {
        var a = this,
            b;
        return _.lb(function(c) {
            if (1 == c.j) {
                if (a.started) return c.return();
                a.started = !0;
                c.m = 2;
                return c.yield(wg(a.A.m, a.A.A, a.timeoutMs), 4)
            }
            if (2 != c.j) {
                if (!a.J) {
                    for (var d = 0, e = _.z(a.A.l), f = e.next(); !f.done; f = e.next()) {
                        if (!f.value.Wf()) throw Error("missing input: " + a.id + "/" + d);
                        ++d
                    }
                    a.j()
                }
                c.j = 0;
                c.m = 0
            } else {
                b = nb(c);
                if (a.J) return c.return();
                b instanceof NF ? a.H(b) : b instanceof Error && (a.M ? a.M(a.id, b) : a.I(b), a.m(b));
                c.j = 0
            }
        })
    };
    var dG = function(a) {
            if (!a.started && a.ua) try {
                var b = a.A.m,
                    c = a.timeoutMs ? b.filter(function(k) {
                        return !k.Vb
                    }) : b,
                    d = b.filter(function(k) {
                        return k.Vb
                    }),
                    e, f = null == (e = _.A(b, "find").call(b, function(k) {
                        return void 0 !== k.Cb.error
                    })) ? void 0 : e.Cb.error;
                if (f) throw a.started = !0, f;
                if (!c.some(function(k) {
                        return !k.Cb.zb
                    })) {
                    if (d.length)
                        if (_.H(ug)) {
                            for (var g = _.z(a.A.A), h = g.next(); !h.done; h = g.next()) vg(h.value);
                            if (d.some(function(k) {
                                    return !k.Cb.zb
                                })) return
                        } else if (a.Ea || (a.Ea = !0, setTimeout(function() {
                            a.Ha = !0;
                            dG(a)
                        }, a.timeoutMs)), d.some(function(k) {
                            return !k.Cb.zb
                        }) && !a.Ha) return;
                    a.started = !0;
                    a.j()
                }
            } catch (k) {
                a.J || (k instanceof NF ? a.H(k) : k instanceof Error && (a.M ? a.M(a.id, k) : a.I(k), a.m(k)))
            }
        },
        V = function(a, b) {
            b = void 0 === b ? new yn : b;
            a.A.j.push(b);
            return b
        },
        fG = function(a) {
            var b = void 0 === b ? new TF : b;
            a.A.j.push(b);
            return b
        },
        gG = function(a) {
            var b = void 0 === b ? new UF : b;
            a.A.j.push(b);
            return b
        },
        hG = function(a, b) {
            b = void 0 === b ? new Cn : b;
            a.A.j.push(b);
            return b
        },
        W = function(a, b) {
            cG(a.A, b);
            b = new WF(b);
            a.A.l.push(b);
            return b
        },
        Y = function(a, b) {
            cG(a.A, b);
            return new XF(b)
        },
        iG = function(a, b) {
            if (_.H(ug)) {
                if (a.timeoutMs) {
                    var c = new aG(a.timeoutMs, void 0);
                    b = new $F([b, c], !0);
                    cG(a.A, b, !0);
                    a.A.A.push(c);
                    return new XF(b)
                }
                cG(a.A, b);
                return new XF(b)
            }
            cG(a.A, b, !0);
            return new XF(b)
        },
        jG = function(a, b) {
            cG(a.A, b)
        },
        kG = function(a, b) {
            if (_.H(ug))
                if (a.timeoutMs) {
                    var c = new aG(a.timeoutMs);
                    b = new $F([b, c], !0);
                    cG(a.A, b, !0);
                    a.A.A.push(c)
                } else jG(a, b);
            else cG(a.A, b, !0)
        },
        lG = function(a, b) {
            b = new $F(b);
            cG(a.A, b);
            b = new WF(b);
            a.A.l.push(b);
            return b
        };
    eG.prototype.H = function() {};
    eG.prototype.m = function(a) {
        if (!this.M && this.A.j.length) {
            a = new NF(a.message);
            for (var b = _.z(this.A.j), c = b.next(); !c.done; c = b.next()) c = c.value, c.zb || SF(c, a)
        }
    };
    var mG = function(a, b, c, d, e, f) {
        eG.call(this, a, e, f);
        this.f = b;
        this.C = d;
        a = {};
        c = _.z(_.A(Object, "entries").call(Object, c));
        for (b = c.next(); !b.done; b = c.next()) d = _.z(b.value), b = d.next().value, (d = d.next().value) && (a[b] = W(this, d));
        this.v = a
    };
    _.T(mG, eG);
    mG.prototype.j = function() {
        for (var a = this.f, b = {}, c = _.z(_.A(Object, "entries").call(Object, this.v)), d = c.next(); !d.done; d = c.next()) {
            var e = _.z(d.value);
            d = e.next().value;
            e = e.next().value;
            b[d] = e.value
        }
        a = a.call(this, b, this.C);
        this.l(a)
    };
    mG.prototype.I = function() {};
    var wp = function(a, b, c, d, e, f) {
        mG.call(this, a, b, c, d, e, f);
        this.output = V(this, new yn)
    };
    _.T(wp, mG);
    wp.prototype.l = function(a) {
        this.output.Ja(a)
    };
    var nG = function(a, b, c, d, e, f, g) {
        mG.call(this, a, b, c, d, f, g);
        this.finished = new Cn;
        a = _.A(Object, "keys").call(Object, e);
        a = _.z(a);
        for (b = a.next(); !b.done; b = a.next()) this[b.value] = V(this)
    };
    _.T(nG, mG);
    nG.prototype.l = function(a) {
        a = _.z(_.A(Object, "entries").call(Object, a));
        for (var b = a.next(); !b.done; b = a.next()) {
            var c = _.z(b.value);
            b = c.next().value;
            c = c.next().value;
            RF(this[b], c)
        }
        this.finished.notify()
    };
    var oG = function(a) {
        this.j = void 0 === a ? function() {} : a
    };
    var Jj = function(a) {
        a = void 0 === a ? new oG : a;
        _.U.call(this);
        this.v = a;
        this.l = [];
        this.H = [];
        this.C = {};
        this.A = [];
        this.m = new _.lg;
        this.j = {}
    };
    _.T(Jj, _.U);
    var O = function(a, b) {
            _.S(a, b);
            a.l.push(b);
            return b
        },
        dk = function(a, b) {
            b = _.z(b);
            for (var c = b.next(); !c.done; c = b.next()) O(a, c.value)
        },
        pG = function(a, b, c, d, e, f) {
            b = new nG(b, c, d, e, f, void 0, a.v.j);
            return O(a, b)
        },
        Rs = function(a, b) {
            a.H.push(b);
            _.S(a, b)
        },
        Sj = function(a) {
            var b, c, d, e, f, g, h, k, l, m, n, p;
            return _.lb(function(r) {
                switch (r.j) {
                    case 1:
                        if (!a.A.length) {
                            r.j = 2;
                            break
                        }
                        return r.yield(_.v.Promise.all(a.A.map(function(w) {
                            return w.m.promise
                        })), 2);
                    case 2:
                        b = _.z(a.l);
                        for (c = b.next(); !c.done; c = b.next()) d = c.value, _.H(AB) ? (d.ua = !0, dG(d)) : d.start();
                        e = _.z(a.H);
                        for (f = e.next(); !f.done; f = e.next()) g = f.value, Sj(g);
                        if (!a.j) {
                            r.j = 4;
                            break
                        }
                        h = _.A(Object, "keys").call(Object, a.j);
                        if (!h.length) {
                            r.j = 4;
                            break
                        }
                        return r.yield(_.v.Promise.all(_.A(Object, "values").call(Object, a.j).map(function(w) {
                            return w.promise
                        })), 6);
                    case 6:
                        for (k = r.o, l = 0, m = _.z(h), n = m.next(); !n.done; n = m.next()) p = n.value, a.C[p] = k[l++];
                    case 4:
                        return a.m.resolve(a.C), r.return(a.m.promise)
                }
            })
        };
    Jj.prototype.o = function() {
        _.U.prototype.o.call(this);
        this.l.length = 0;
        this.H.length = 0;
        this.A.length = 0
    };
    var qG = function(a) {
        this.D = _.B(a)
    };
    _.T(qG, _.F);
    qG.ca = [1];
    var rG = [0, rx, Zx];
    var sG = function(a) {
        this.D = _.B(a)
    };
    _.T(sG, _.F);
    sG.ca = [1, 2];
    sG.prototype.j = Oe([0, rx, Zx, rx, rG]);
    var uG, tG;
    uG = function() {
        this.wasPlaTagProcessed = !1;
        this.wasReactiveAdConfigReceived = {};
        this.adCount = {};
        this.wasReactiveAdVisible = {};
        this.stateForType = {};
        this.reactiveTypeEnabledInAsfe = {};
        this.wasReactiveTagRequestSent = !1;
        this.reactiveTypeDisabledByPublisher = {};
        this.tagSpecificState = {};
        this.messageValidationEnabled = !1;
        this.floatingAdsStacking = new tG;
        this.sideRailProcessedFixedElements = new _.v.Set;
        this.sideRailAvailableSpace = new _.v.Map;
        this.sideRailPlasParam = new _.v.Map
    };
    _.jh = function(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new _.v.Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new _.v.Map), null == a.google_reactive_ads_global_state.sideRailPlasParam && (a.google_reactive_ads_global_state.sideRailPlasParam = new _.v.Map)) : a.google_reactive_ads_global_state = new uG;
        return a.google_reactive_ads_global_state
    };
    tG = function() {
        this.maxZIndexRestrictions = {};
        this.nextRestrictionId = 0;
        this.maxZIndexListeners = []
    };
    var yG, AG, wG;
    _.vG = function(a) {
        this.j = _.jh(a).floatingAdsStacking
    };
    _.xG = function(a, b) {
        return new wG(a, b)
    };
    yG = function(a) {
        a = _.pz(a.j.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    };
    _.zG = function(a, b) {
        a.j.maxZIndexListeners.push(b);
        b(yG(a))
    };
    AG = function(a) {
        var b = yG(a);
        _.hv(a.j.maxZIndexListeners, function(c) {
            return c(b)
        })
    };
    wG = function(a, b) {
        this.o = a;
        this.m = b;
        this.j = null
    };
    _.BG = function(a) {
        if (null == a.j) {
            var b = a.o,
                c = a.m,
                d = b.j.nextRestrictionId++;
            b.j.maxZIndexRestrictions[d] = c;
            AG(b);
            a.j = d
        }
    };
    _.CG = function(a) {
        if (null != a.j) {
            var b = a.o;
            delete b.j.maxZIndexRestrictions[a.j];
            AG(b);
            a.j = null
        }
    };
    _.$o = 728 * 1.38;
    var Og, DG;
    _.Sg = function(a, b) {
        b = void 0 === b ? {} : b;
        this.ka = a;
        this.Da = b
    };
    _.EG = function(a, b) {
        var c = Lg(a.ka.document, b);
        if (c) {
            var d;
            if (!(d = DG(a, c, b))) a: {
                d = a.ka.document;
                for (c = c.offsetParent; c && c !== d.body; c = c.offsetParent) {
                    var e = DG(a, c, b);
                    if (e) {
                        d = e;
                        break a
                    }
                }
                d = null
            }
            a = d || null
        } else a = null;
        return a
    };
    Og = function(a, b) {
        b = _.z(b);
        for (var c = b.next(); !c.done; c = b.next())
            if (c = _.EG(a, c.value)) return c;
        return null
    };
    DG = function(a, b, c) {
        if ("fixed" !== Wz(b, "position")) return null;
        var d = "GoogleActiveViewInnerContainer" === b.getAttribute("class") || 1 >= _.vi(_.aA, b).width && 1 >= _.vi(_.aA, b).height || a.Da.Xj && !a.Da.Xj(b) ? !0 : !1;
        a.Da.Ah && a.Da.Ah(b, c, d);
        return d ? null : b
    };
    var Ng = 90 * 1.38;
    var FG, GG, HG;
    FG = _.tu(["* { pointer-events: none; }"]);
    GG = function(a, b) {
        var c = _.gf("STYLE", a);
        c.textContent = _.Qv(new _.Pv(FG[0], Ov));
        null == a || a.head.appendChild(c);
        setTimeout(function() {
            null == a || a.head.removeChild(c)
        }, b)
    };
    _.IG = function(a, b, c) {
        if (!a.body) return null;
        var d = new HG;
        d.apply(a, b);
        return function() {
            var e = c || 0;
            0 < e && GG(b.document, e);
            _.Tz(a.body, {
                filter: d.j,
                webkitFilter: d.j,
                overflow: d.m,
                position: d.A,
                top: d.J
            });
            b.scrollTo(0, d.o)
        }
    };
    HG = function() {
        this.j = this.J = this.A = this.m = null;
        this.o = 0
    };
    HG.prototype.apply = function(a, b) {
        this.m = a.body.style.overflow;
        this.A = a.body.style.position;
        this.J = a.body.style.top;
        this.j = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
        this.o = _.Jg(b);
        _.Tz(a.body, "top", -this.o + "px")
    };
    var Vo;
    Vo = function(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            var b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return "__storage_test__" === b
        } catch (c) {
            return !1
        }
    };
    _.Xo = function(a, b) {
        return 0 >= b || null == a || !Vo(a) ? null : bh(a, b)
    };
    _.Wo = function(a) {
        return !!a && 1 > a.length
    };
    var en = function(a) {
            var b = void 0 === b ? _.Rh(_.t) : b;
            this.id = a;
            this.o = .001 > Math.random();
            this.j = {
                pvsid: String(b)
            }
        },
        JG = function(a) {
            a = nh(a);
            var b;
            Xh.set(a, (null != (b = Xh.get(a)) ? b : 0) + 1)
        },
        Wh = function() {
            return [].concat(_.lh(_.A(Xh, "values").call(Xh))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        fj = function(a, b, c) {
            "string" !== typeof c && (c = String(c));
            /^\w+$/.test(b) && (c ? a.j[b] = c : delete a.j[b])
        },
        gn = function(a) {
            var b = 1;
            b = void 0 === b ? null : b;
            if (KG()) b = !0;
            else {
                var c = a.o;
                b && 0 <= b && (c = Math.random() < b);
                b = c && !!a.id
            }
            b && SC(window, LG(a) || "", void 0, !0)
        },
        LG = function(a) {
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + encodeURIComponent(a.id);
            _.Ll(a.j, function(c, d) {
                c && (b += "&" + d + "=" + encodeURIComponent(c))
            });
            return b
        },
        MG = function(a) {
            var b = [].concat(_.lh(_.A(Xh, "keys").call(Xh)));
            b = b.map(function(c) {
                return c.replace(/,/g, "\\,")
            });
            3 >= b.length ? fj(a, "nw_id", b.join()) : (b = b.slice(0, 3), b.push("__extra__"), fj(a, "nw_id", b.join()))
        },
        ej = function(a, b) {
            fj(a, "vrg", String(b.wc || b.eb));
            MG(a);
            fj(a, "nslots", Wh().toString());
            b = _.Uf();
            b.length && fj(a, "eid", b.join());
            fj(a, "pub_url", document.URL)
        },
        Zi = function(a, b, c) {
            c = void 0 === c ? .001 : c;
            if (void 0 === c || 0 > c || 1 < c) c = .001;
            Math.random() < c && (a = new en(a), b(a), gn(a))
        },
        Xh = new _.v.Map,
        KG = Gi(function() {
            return !!tz(_.t.location.href)
        });
    var NG = function(a, b, c, d, e) {
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = void 0 === d ? 0 : d;
        this.slotId = e;
        this.taskId = void 0;
        this.uniqueId = Math.random()
    };
    var OG, PG, QG, RG, SG;
    OG = _.t.performance;
    PG = !!(OG && OG.mark && OG.measure && OG.clearMarks);
    QG = Gi(function() {
        var a;
        if (a = PG) a = YE(), a = !!a.indexOf && 0 <= a.indexOf("1337");
        return a
    });
    RG = function(a, b) {
        this.o = [];
        var c = null;
        b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.o = b.google_js_reporting_queue, c = b.google_measure_js_timing);
        this.j = QG() || (null != c ? c : Math.random() < a)
    };
    _.Mh = function(a) {
        a && OG && QG() && (OG.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), OG.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    };
    SG = function(a, b, c, d, e, f) {
        a.j && (b = new NG(b, c, d, void 0 === e ? 0 : e, f), !a.j || 2048 < a.o.length || a.o.push(b))
    };
    RG.prototype.start = function(a, b) {
        if (!this.j) return null;
        a = new NG(a, b, _.Wg() || _.Vg());
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        OG && QG() && OG.mark(b);
        return a
    };
    RG.prototype.end = function(a) {
        if (this.j && "number" === typeof a.value) {
            a.duration = (_.Wg() || _.Vg()) - a.value;
            var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            OG && QG() && OG.mark(b);
            !this.j || 2048 < this.o.length || this.o.push(a)
        }
    };
    var Jr = function(a, b, c) {
        var d = _.Wg();
        d && SG(a, b, 9, d, 0, c)
    };
    var Jh = function() {
        RG.call(this, _.H(Kh) || _.H(tC) ? 1 : 0, _.t);
        this.m = 0;
        var a = _.H(Kh) || _.H(tC);
        _.t.google_measure_js_timing = a || _.t.google_measure_js_timing
    };
    _.T(Jh, RG);
    _.TG = function(a) {
        this.context = a
    };
    _.TG.prototype.Hb = function(a, b) {
        return Nh(this.context, a, b)
    };
    _.TG.prototype.xa = function(a, b) {
        return Hh(this.context, a, b)
    };
    _.TG.prototype.tb = function(a, b) {
        Lh(this.context, a, b);
        return !1
    };
    _.TG.prototype.Xc = ca(4);
    var UG = {},
        VG = (UG.companion_ads = "companionAds", UG.content = "content", UG.publisher_ads = "pubads", UG);
    var Jn = function(a) {
        this.D = _.B(a)
    };
    _.T(Jn, _.F);
    var Km = function(a) {
        var b = new Jn;
        return Fj(b, 1, a)
    };
    var Us = function(a) {
        this.D = _.B(a)
    };
    _.T(Us, _.F);
    var xs = function(a) {
        this.D = _.B(a)
    };
    _.T(xs, _.F);
    xs.ca = [1];
    var Kl = function(a) {
        this.D = _.B(a)
    };
    _.T(Kl, _.F);
    var el = function(a) {
        this.D = _.B(a)
    };
    _.T(el, _.F);
    var dl = function(a, b) {
            return Vn(a, 1, b)
        },
        cl = function(a, b) {
            return _.Uh(a, 2, b)
        },
        zl = function(a, b) {
            return ix(a, 2, b)
        };
    el.ca = [2];
    var ss = function(a) {
        this.D = _.B(a)
    };
    _.T(ss, _.F);
    ss.ca = [2, 3];
    var iq = function(a) {
        this.D = _.B(a)
    };
    _.T(iq, _.F);
    var lq = function(a, b) {
            return _.ko(a, 1, b)
        },
        jq = function(a, b) {
            return _.Uh(a, 2, b)
        };
    iq.ca = [2];
    var us = function(a) {
        this.D = _.B(a)
    };
    _.T(us, _.F);
    var kq = function(a, b) {
        Gj(a, 1, iq, b)
    };
    us.ca = [1];
    var qs = function(a) {
        this.D = _.B(a)
    };
    _.T(qs, _.F);
    var WG = function(a) {
        this.D = _.B(a)
    };
    _.T(WG, _.F);
    WG.prototype.setTagForChildDirectedTreatment = function(a) {
        return _.ko(this, 5, a)
    };
    WG.prototype.clearTagForChildDirectedTreatment = function() {
        return _.Ai(this, 5)
    };
    WG.prototype.setTagForUnderAgeOfConsent = function(a) {
        return _.ko(this, 6, a)
    };
    var XG = function(a) {
        this.D = _.B(a)
    };
    _.T(XG, _.F);
    XG.prototype.getCategoryExclusions = function(a) {
        return bx(this, 3, a)
    };
    XG.prototype.Ma = function() {
        return _.bi(this, el, 14)
    };
    XG.prototype.kc = function() {
        return _.Zh(this, Kl, 18)
    };
    var Ft = function(a) {
        return _.Zh(a, WG, 25)
    };
    XG.prototype.getCorrelator = function() {
        return hr(this, 26)
    };
    XG.prototype.setCorrelator = function(a) {
        return _.Ai(this, 26, null == a ? a : bd(a))
    };
    XG.prototype.Fe = function() {
        return rs(this, qs, 33)
    };
    XG.ca = [2, 3, 14];
    var zi = function() {
        this.j = new _.v.Map
    };
    var YG = {},
        ji = (YG[253] = !1, YG[246] = [], YG[150] = "", YG[221] = !1, YG[36] = /^true$/.test("false"), YG[172] = null, YG[260] = void 0, YG[251] = null, YG),
        ii = function() {
            this.j = !1
        };
    var ZG = function() {
            this.o = {};
            this.j = new XG;
            this.m = new _.v.Map;
            this.j.setCorrelator(Hz());
            _.ki(36) && Fj(this.j, 15, !0)
        },
        $G = function(a) {
            var b = Pi(),
                c = a.getDomId();
            if (c && !b.o.hasOwnProperty(c)) {
                var d = _.Rf(zi),
                    e = ++_.Rf(Jh).m;
                d.j.set(c, e);
                _.Ai(a, 20, _.Oc(e));
                b.o[c] = a
            }
        },
        aH = function(a, b) {
            return a.o[b]
        },
        Pi = function() {
            return _.Rf(ZG)
        };
    var bH = Gi(Di);
    var nj = ["auto", "inherit", "100%"],
        oj = nj.concat(["none"]),
        cH = [2, 1];
    var On = function(a, b, c) {
        if (!a) return !0;
        var d = !0;
        lj(a, function(e) {
            return d = mj(e, b, 10, 10)
        }, c);
        return d
    };
    var dH = /^data-(?!xml)[_a-z][_a-z.0-9-]*$/;
    var eH = function(a, b, c, d, e, f) {
            this.m = _.Nz(a);
            this.o = _.Nz(b);
            this.A = c;
            this.j = _.Nz(d);
            this.J = e;
            this.l = f
        },
        fH = function(a) {
            return JSON.stringify({
                windowCoords_t: a.m.top,
                windowCoords_r: a.m.right,
                windowCoords_b: a.m.bottom,
                windowCoords_l: a.m.left,
                frameCoords_t: a.o.top,
                frameCoords_r: a.o.right,
                frameCoords_b: a.o.bottom,
                frameCoords_l: a.o.left,
                styleZIndex: a.A,
                allowedExpansion_t: a.j.top,
                allowedExpansion_r: a.j.right,
                allowedExpansion_b: a.j.bottom,
                allowedExpansion_l: a.j.left,
                xInView: a.J,
                yInView: a.l
            })
        },
        gH = function(a) {
            var b = window,
                c = b.screenX || b.screenLeft || 0,
                d = b.screenY || b.screenTop || 0;
            b = new _.Mz(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
            c = Yz(a);
            d = _.vi(_.aA, a);
            var e = new Oz(c.x, c.y, d.width, d.height);
            c = Pz(e);
            d = String(Wz(a, "zIndex"));
            var f = new _.Mz(0, Infinity, Infinity, 0);
            for (var g = jf(a), h = g.j.body, k = g.j.documentElement, l = bz(g.j); a = Xz(a);)
                if (!(_.kw && 0 == a.clientWidth || nw && 0 == a.clientHeight && a == h) && a != h && a != k && "visible" != Wz(a, "overflow")) {
                    var m = Yz(a),
                        n = new _.oi(a.clientLeft, a.clientTop);
                    m.x += n.x;
                    m.y += n.y;
                    f.top = Math.max(f.top, m.y);
                    f.right = Math.min(f.right, m.x + a.clientWidth);
                    f.bottom = Math.min(f.bottom, m.y + a.clientHeight);
                    f.left = Math.max(f.left, m.x)
                }
            a = l.scrollLeft;
            l = l.scrollTop;
            f.left = Math.max(f.left, a);
            f.top = Math.max(f.top, l);
            g = g.j;
            g = _.az(g.parentWindow || g.defaultView || window);
            f.right = Math.min(f.right, a + g.width);
            f.bottom = Math.min(f.bottom, l + g.height);
            l = (f = (f = 0 <= f.top && 0 <= f.left && f.bottom > f.top && f.right > f.left ? f : null) ? new Oz(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ? Qz(e, f) : null;
            g = a = 0;
            l && !(new _.xi(l.width, l.height)).isEmpty() && (a = l.width / e.width, g = l.height / e.height);
            l = new _.Mz(0, 0, 0, 0);
            if (h = f)(e = Qz(e, f)) ? (k = Pz(f), m = Pz(e), h = m.right != k.left && k.right != m.left, k = m.bottom != k.top && k.bottom != m.top, h = (0 != e.width || h) && (0 != e.height || k)) : h = !1;
            h && (l = new _.Mz(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
            return new eH(b, c, d, l, a, g)
        };
    var hH = function(a) {
        this.A = a;
        this.J = null;
        this.v = this.status = 0;
        this.o = null;
        this.ub = "sfchannel" + a
    };
    hH.prototype.dg = function() {
        return 2 == this.v
    };
    var iH = function(a) {
        this.j = a
    };
    iH.prototype.getValue = function(a, b) {
        return null == this.j[a] || null == this.j[a][b] ? null : this.j[a][b]
    };
    var jH = function(a, b) {
        this.we = a;
        this.xe = b;
        this.o = this.j = !1
    };
    var kH = function(a, b, c, d, e, f, g, h) {
        h = void 0 === h ? [] : h;
        this.o = a;
        this.m = b;
        this.A = c;
        this.permissions = d;
        this.metadata = e;
        this.J = f;
        this.Bd = g;
        this.hostpageLibraryTokens = h;
        this.j = ""
    };
    var lH = function(a, b) {
        this.o = a;
        this.A = b
    };
    lH.prototype.j = function(a) {
        this.A && a && (a.sentinel = this.A);
        return JSON.stringify(a)
    };
    var mH = function(a, b, c) {
        lH.call(this, a, void 0 === c ? "" : c);
        this.version = b
    };
    _.T(mH, lH);
    mH.prototype.j = function() {
        return lH.prototype.j.call(this, {
            uid: this.o,
            version: this.version
        })
    };
    var nH = function(a, b, c, d) {
        lH.call(this, a, void 0 === d ? "" : d);
        this.J = b;
        this.m = c
    };
    _.T(nH, lH);
    nH.prototype.j = function() {
        return lH.prototype.j.call(this, {
            uid: this.o,
            initialWidth: this.J,
            initialHeight: this.m
        })
    };
    var oH = function(a, b, c) {
        lH.call(this, a, void 0 === c ? "" : c);
        this.description = b
    };
    _.T(oH, lH);
    oH.prototype.j = function() {
        return lH.prototype.j.call(this, {
            uid: this.o,
            description: this.description
        })
    };
    var pH = function(a, b, c, d) {
        lH.call(this, a, void 0 === d ? "" : d);
        this.m = b;
        this.push = c
    };
    _.T(pH, lH);
    pH.prototype.j = function() {
        return lH.prototype.j.call(this, {
            uid: this.o,
            expand_t: this.m.top,
            expand_r: this.m.right,
            expand_b: this.m.bottom,
            expand_l: this.m.left,
            push: this.push
        })
    };
    var qH = function(a, b) {
        lH.call(this, a, void 0 === b ? "" : b)
    };
    _.T(qH, lH);
    qH.prototype.j = function() {
        return lH.prototype.j.call(this, {
            uid: this.o
        })
    };
    var rH = function(a, b, c) {
        lH.call(this, a, void 0 === c ? "" : c);
        this.J = b
    };
    _.T(rH, lH);
    rH.prototype.j = function() {
        var a = {
            uid: this.o,
            newGeometry: fH(this.J)
        };
        return lH.prototype.j.call(this, a)
    };
    var sH = function(a, b, c, d, e, f) {
        rH.call(this, a, c, void 0 === f ? "" : f);
        this.success = b;
        this.m = d;
        this.push = e
    };
    _.T(sH, rH);
    sH.prototype.j = function() {
        var a = {
            uid: this.o,
            success: this.success,
            newGeometry: fH(this.J),
            expand_t: this.m.top,
            expand_r: this.m.right,
            expand_b: this.m.bottom,
            expand_l: this.m.left,
            push: this.push
        };
        this.A && (a.sentinel = this.A);
        return JSON.stringify(a)
    };
    var tH = function(a, b, c, d) {
        lH.call(this, a, void 0 === d ? "" : d);
        this.width = b;
        this.height = c
    };
    _.T(tH, lH);
    tH.prototype.j = function() {
        return lH.prototype.j.call(this, {
            uid: this.o,
            width: this.width,
            height: this.height
        })
    };
    var uH = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        Lk(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    var vH, yH, zH, xH;
    vH = function() {
        this.j = []
    };
    _.wH = function(a) {
        return a + "px"
    };
    yH = function(a, b, c, d, e) {
        a.j.push(new xH(b, c, d, e))
    };
    zH = function(a) {
        for (var b = a.j.length - 1; 0 <= b; b--) {
            var c = a.j[b];
            c.o ? (c.m.style.removeProperty(c.j), c.m.style.setProperty(c.j, String(c.A), c.J)) : c.m.style[c.j] = c.A
        }
        a.j.length = 0
    };
    xH = function(a, b, c, d) {
        this.m = a;
        this.j = (this.o = !(void 0 === d || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
        this.A = this.o ? a.style.getPropertyValue(this.j) : a.style[this.j];
        this.J = this.o ? a.style.getPropertyPriority(this.j) : void 0;
        this.o ? (a.style.removeProperty(this.j), a.style.setProperty(this.j, String(c), d)) : a.style[this.j] = String(c)
    };
    var AH, BH;
    AH = function(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    BH = function() {
        var a = window,
            b = _.Wg(a);
        b && AH({
            label: "2",
            type: 9,
            value: b
        }, a)
    };
    _.CH = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        var f = d || window,
            g = "undefined" !== typeof queueMicrotask;
        return function() {
            e && g && queueMicrotask(function() {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            var h = _.Wg(),
                k = 3;
            try {
                var l = b.apply(this, arguments)
            } catch (m) {
                k = 13;
                if (!c) throw m;
                c(a, m)
            } finally {
                f.google_measure_js_timing && h && AH(_.A(Object, "assign").call(Object, {}, {
                    label: a.toString(),
                    value: h,
                    duration: (_.Wg() || 0) - h,
                    type: k
                }, e && g && {
                    taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                }), f)
            }
            return l
        }
    };
    var HH = function(a) {
        hH.call(this, a.uniqueId);
        var b = this;
        this.H = a.Vk;
        this.M = 1 === a.size;
        this.U = new jH(a.permissions.we && !this.M, a.permissions.xe && !this.M);
        this.l = a.xg;
        var c;
        this.pa = null != (c = a.hostpageLibraryTokens) ? c : [];
        var d = window.location;
        c = d.protocol;
        d = d.host;
        this.ma = "file:" == c ? "*" : c + "//" + d;
        this.ya = !!a.Bd;
        this.K = a.Di ? "//" + a.Di + ".safeframe.googlesyndication.com" : "//tpc.googlesyndication.com";
        this.Ha = a.nb ? "*" : "https:" + this.K;
        this.ba = !!a.Zj;
        this.ua = DH(a);
        this.m = new vH;
        EH(this, a.xg, a.size);
        this.J = this.fa = gH(a.xg);
        this.G = a.Gl || "1-0-40";
        var e;
        this.Ea = null != (e = a.Cj) ? e : "";
        FH(this, a);
        this.C = _.CH(412, function() {
            return GH(b)
        }, a.mb);
        this.ta = -1;
        this.I = 0;
        var f = _.CH(415, function() {
            b.j && (b.j.name = "", a.gi && a.gi(), _.uf(b.j, "load", f))
        }, a.mb);
        _.jb(this.j, "load", f);
        this.Zf = _.CH(413, this.Zf, a.mb);
        this.Ag = _.CH(417, this.Ag, a.mb);
        this.Eg = _.CH(419, this.Eg, a.mb);
        this.Sf = _.CH(411, this.Sf, a.mb);
        this.Cf = _.CH(409, this.Cf, a.mb);
        this.O = _.CH(410, this.O, a.mb);
        this.sg = _.CH(416, this.sg, a.mb);
        this.o = new nF(this.ub, this.j.contentWindow, this.Ha, !1);
        pF(this.o, "init_done", (0, _.Wu)(this.Zf, this));
        pF(this.o, "register_done", (0, _.Wu)(this.Ag, this));
        pF(this.o, "report_error", (0, _.Wu)(this.Eg, this));
        pF(this.o, "expand_request", (0, _.Wu)(this.Sf, this));
        pF(this.o, "collapse_request", (0, _.Wu)(this.Cf, this));
        pF(this.o, "creative_geometry_update", (0, _.Wu)(this.O, this));
        this.o.connect((0, _.Wu)(this.sg, this))
    };
    _.T(HH, hH);
    var EH = function(a, b, c) {
            a.M ? (b.style.width = _.$z("100%", !0), b.style.height = _.$z("auto", !0)) : (b.style.width = _.$z(c.width, !0), b.style.height = _.$z(c.height, !0))
        },
        FH = function(a, b) {
            var c = b.nb,
                d = b.content,
                e = b.yd,
                f = b.size,
                g = void 0 === b.zd ? "3rd party ad content" : b.zd,
                h = b.ye;
            b = b.yf;
            var k = {
                shared: {
                    sf_ver: a.G,
                    ck_on: GE() ? 1 : 0,
                    flash_ver: "0"
                }
            };
            d = c ? "" : null != d ? d : "";
            d = a.G + ";" + d.length + ";" + d;
            k = new kH(a.A, a.ma, a.fa, a.U, new iH(k), a.M, a.ya, a.pa);
            var l = {};
            l.uid = k.o;
            l.hostPeerName = k.m;
            l.initialGeometry = fH(k.A);
            var m = k.permissions;
            m = JSON.stringify({
                expandByOverlay: m.we,
                expandByPush: m.xe,
                readCookie: m.j,
                writeCookie: m.o
            });
            l = (l.permissions = m, l.metadata = JSON.stringify(k.metadata.j), l.reportCreativeGeometry = k.J, l.isDifferentSourceWindow = k.Bd, l.goog_safeframe_hlt = lF(k.hostpageLibraryTokens), l);
            k.j && (l.sentinel = k.j);
            k = JSON.stringify(l);
            d += k;
            a.ba && f instanceof _.xi && (k = _.cz(_.Xy(a.l)), l = _.cz(_.Xy(a.l)).location.protocol + a.K, VE || _.hn(k.document, WE), VE++, k.google_eas_queue = k.google_eas_queue || [], k.google_eas_queue.push({
                a: e,
                b: l,
                c: f.width,
                d: f.height,
                e: "sf-gdn-exp-" + VE,
                f: void 0,
                g: void 0,
                h: void 0,
                i: void 0
            }));
            k = f.width;
            f = f.height;
            a.M && (f = k = 0);
            l = {};
            e = (l.id = e, l.title = g, l.name = d, l.scrolling = "no", l.marginWidth = "0", l.marginHeight = "0", l.width = String(k), l.height = String(f), l["data-is-safeframe"] = "true", l);
            void 0 === c && (g = _.cz(_.Xy(a.l)), f = a.Ea, d = a.K, (k = f) && (k = "?" + k), d = (void 0 === d ? "//tpc.googlesyndication.com" : d) + ("/safeframe/" + a.G + "/html/container.html" + k), (k = uH(g)) && (d += (f ? "&" : "?") + "n=" + k), f = "https:" + d, d = [], a.ba && (k = tz(g.location.href), g = d.push, k = [0 < k.length ? "google_debug" + (k ? "=" + k : "") + "&" : "", "xpc=", "sf-gdn-exp-" + a.A, "&p=", encodeURIComponent(_.t.document.location.protocol), "//", encodeURIComponent(_.t.document.location.host)].join(""), g.call(d, k)), d.length && (f += "#" + d.join("&")), e.src = f);
            null !== a.ua && (e.sandbox = a.ua);
            h && (e.allow = h);
            b && (e.credentialless = "true");
            e.role = "region";
            e["aria-label"] = "Advertisement";
            e.tabIndex = "0";
            c ? (a.j = c, Zy(a.j, e)) : (c = {}, c = (c.frameborder = 0, c.allowTransparency = "true", c.style = "border:0;vertical-align:bottom;", c.src = "about:blank", c), e && Ea(c, e), h = _.gf("IFRAME"), Zy(h, c), a.j = h);
            a.M && (a.j.style.minWidth = "100%");
            a.l.appendChild(a.j)
        };
    _.q = HH.prototype;
    _.q.sg = function() {
        _.jb(window, "resize", this.C);
        _.jb(window, "scroll", this.C)
    };
    _.q.Zf = function(a) {
        try {
            if (0 != this.status) throw Error("Container already initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !qj(b.uid) || "string" !== typeof b.version) throw Error("Cannot parse JSON message");
            var c = new mH(b.uid, b.version, b.sentinel);
            if (this.A !== c.o || this.G !== c.version) throw Error("Wrong source container");
            this.status = 1
        } catch (e) {
            var d;
            null == (d = this.H) || d.error("Invalid INITIALIZE_DONE message. Reason: " + e.message)
        }
    };
    _.q.Ag = function(a) {
        try {
            if (1 != this.status) throw Error("Container not initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !qj(b.uid) || "number" !== typeof b.initialWidth || "number" !== typeof b.initialHeight) throw Error("Cannot parse JSON message");
            if (this.A !== (new nH(b.uid, b.initialWidth, b.initialHeight, b.sentinel)).o) throw Error("Wrong source container");
            this.status = 2
        } catch (d) {
            var c;
            null == (c = this.H) || c.error("Invalid REGISTER_DONE message. Reason: " + d.message)
        }
    };
    _.q.Eg = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !qj(b.uid) || "string" !== typeof b.description) throw Error("Cannot parse JSON message");
            var c = new oH(b.uid, b.description, b.sentinel);
            if (this.A !== c.o) throw Error("Wrong source container");
            var d;
            null == (d = this.H) || d.info("Ext reported an error. Description: " + c.description)
        } catch (f) {
            var e;
            null == (e = this.H) || e.error("Invalid REPORT_ERROR message. Reason: " + f.message)
        }
    };
    _.q.Sf = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (0 != this.v) throw Error("Container is not collapsed");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !qj(b.uid) || "number" !== typeof b.expand_t || "number" !== typeof b.expand_r || "number" !== typeof b.expand_b || "number" !== typeof b.expand_l || "boolean" !== typeof b.push) throw Error("Cannot parse JSON message");
            var c = new pH(b.uid, new _.Mz(b.expand_t, b.expand_r, b.expand_b, b.expand_l), b.push, b.sentinel);
            if (this.A !== c.o) throw Error("Wrong source container");
            if (!(0 <= c.m.top && 0 <= c.m.left && 0 <= c.m.bottom && 0 <= c.m.right)) throw Error("Invalid expansion amounts");
            var d;
            if (d = c.push && this.U.xe || !c.push && this.U.we) {
                var e = c.m,
                    f = c.push,
                    g = this.J = gH(this.j);
                if (e.top <= g.j.top && e.right <= g.j.right && e.bottom <= g.j.bottom && e.left <= g.j.left) {
                    if (!f)
                        for (var h = this.j.parentNode; h && h.style; h = h.parentNode) yH(this.m, h, "overflowX", "visible", "important"), yH(this.m, h, "overflowY", "visible", "important");
                    var k = Pz(new Oz(0, 0, this.J.o.getWidth(), this.J.o.getHeight()));
                    _.ka(e) ? (k.top -= e.top, k.right += e.right, k.bottom += e.bottom, k.left -= e.left) : (k.top -= e, k.right += Number(void 0), k.bottom += Number(void 0), k.left -= Number(void 0));
                    yH(this.m, this.l, "position", "relative");
                    yH(this.m, this.j, "position", "absolute");
                    if (f) {
                        var l = k.getWidth();
                        yH(this.m, this.l, "width", _.wH(l));
                        var m = k.getHeight();
                        yH(this.m, this.l, "height", _.wH(m))
                    } else yH(this.m, this.j, "zIndex", "10000");
                    var n = k.getWidth();
                    yH(this.m, this.j, "width", _.wH(n));
                    var p = k.getHeight();
                    yH(this.m, this.j, "height", _.wH(p));
                    yH(this.m, this.j, "left", _.wH(k.left));
                    yH(this.m, this.j, "top", _.wH(k.top));
                    this.v = 2;
                    this.J = gH(this.j);
                    d = !0
                } else d = !1
            }
            a = d;
            this.o.send("expand_response", (new sH(this.A, a, this.J, c.m, c.push)).j());
            if (!a) throw Error("Viewport or document body not large enough to expand into.");
        } catch (w) {
            var r;
            null == (r = this.H) || r.error("Invalid EXPAND_REQUEST message. Reason: " + w.message)
        }
    };
    _.q.Cf = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (!this.dg()) throw Error("Container is not expanded");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !qj(b.uid)) throw Error("Cannot parse JSON message");
            if (this.A !== (new qH(b.uid, b.sentinel)).o) throw Error("Wrong source container");
            zH(this.m);
            this.v = 0;
            this.j && (this.J = gH(this.j));
            this.o.send("collapse_response", (new rH(this.A, this.J)).j())
        } catch (d) {
            var c;
            null == (c = this.H) || c.error("Invalid COLLAPSE_REQUEST message. Reason: " + d.message)
        }
    };
    var GH = function(a) {
        if (1 == a.status || 2 == a.status) switch (a.I) {
            case 0:
                IH(a);
                a.ta = window.setTimeout((0, _.Wu)(a.da, a), 1E3);
                a.I = 1;
                break;
            case 1:
                a.I = 2;
                break;
            case 2:
                a.I = 2
        }
    };
    HH.prototype.O = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !qj(b.uid) || "number" !== typeof b.width || "number" !== typeof b.height || b.sentinel && "string" !== typeof b.sentinel) throw Error("Cannot parse JSON message");
            var c = new tH(b.uid, b.width, b.height, b.sentinel);
            if (this.A !== c.o) throw Error("Wrong source container");
            var d = String(c.height);
            if (this.M) d !== this.j.height && (this.j.height = d, GH(this));
            else {
                var e;
                null == (e = this.H) || e.error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            }
        } catch (g) {
            var f;
            null == (f = this.H) || f.error("Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: " + g.message)
        }
    };
    HH.prototype.da = function() {
        if (1 == this.status || 2 == this.status) switch (this.I) {
            case 1:
                this.I = 0;
                break;
            case 2:
                IH(this), this.ta = window.setTimeout((0, _.Wu)(this.da, this), 1E3), this.I = 1
        }
    };
    var IH = function(a) {
            a.J = gH(a.j);
            a.o.send("geometry_update", (new rH(a.A, a.J)).j())
        },
        DH = function(a) {
            var b = null;
            a.Fi && (b = a.Fi);
            return null == b ? null : b.join(" ")
        },
        JH = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        KH = ["allow-top-navigation"],
        LH = ["allow-same-origin"],
        MH = wz([].concat(_.lh(JH), _.lh(KH)));
    wz([].concat(_.lh(JH), _.lh(LH)));
    wz([].concat(_.lh(JH), _.lh(KH), _.lh(LH)));
    var NH = _.tu(["https://tpc.googlesyndication.com/safeframe/", "/html/container.html"]),
        OH = {
            Qk: function(a) {
                if ("string" !== typeof a.version) throw new TypeError("version is not a string");
                if (!/^[0-9]+-[0-9]+-[0-9]+$/.test(a.version)) throw new RangeError("Invalid version: " + a.version);
                if ("string" !== typeof a.mf) throw new TypeError("subdomain is not a string");
                if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(a.mf)) throw new RangeError("Invalid subdomain: " + a.mf);
                return Ue("https://" + a.mf + ".safeframe.googlesyndication.com/safeframe/" + a.version + "/html/container.html")
            },
            Qn: function(a) {
                return _.Ve(NH, a)
            }
        };
    var PH = function() {};
    PH.j = function() {
        throw Error("Must be overridden");
    };
    var uj = function() {
        this.j = 0
    };
    _.T(uj, PH);
    uj.qc = void 0;
    uj.j = function() {
        return uj.qc ? uj.qc : uj.qc = new uj
    };
    var QH = function() {
            this.cache = {}
        },
        Dj = function() {
            RH || (RH = new QH);
            return RH
        },
        Ej = function(a) {
            var b = $c(jo(a, 3));
            if (!b) return 3;
            if (void 0 === _.Aj(a, 2)) return 4;
            a = Date.now();
            return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
        };
    QH.prototype.get = function(a, b) {
        if (this.cache[a]) return {
            Cc: this.cache[a],
            success: !0
        };
        var c = "";
        try {
            c = b.getItem("_GESPSK-" + a)
        } catch (g) {
            var d;
            wj(6, a, null == (d = g) ? void 0 : d.message);
            return {
                Cc: null,
                success: !1
            }
        }
        if (!c) return {
            Cc: null,
            success: !0
        };
        try {
            var e = py(c);
            this.cache[a] = e;
            return {
                Cc: e,
                success: !0
            }
        } catch (g) {
            var f;
            wj(5, a, null == (f = g) ? void 0 : f.message);
            return {
                Cc: null,
                success: !1
            }
        }
    };
    QH.prototype.set = function(a, b) {
        var c = _.Aj(a, 1),
            d = "_GESPSK-" + c;
        oy(a);
        try {
            b.setItem(d, Ak(a))
        } catch (f) {
            var e;
            wj(7, c, null == (e = f) ? void 0 : e.message);
            return !1
        }
        this.cache[c] = a;
        return !0
    };
    var RH = null;
    var SH = function(a, b) {
        eG.call(this, a);
        this.id = a;
        this.C = b
    };
    _.T(SH, eG);
    SH.prototype.I = function(a) {
        this.C(this.id, a)
    };
    var Lj = function(a, b, c, d) {
        SH.call(this, 1041, d);
        this.l = b;
        this.G = W(this, a);
        c && (this.v = Y(this, c))
    };
    _.T(Lj, SH);
    Lj.prototype.j = function() {
        var a = this.G.value,
            b, c, d = null != (c = this.l) ? c : null == (b = this.v) ? void 0 : b.value;
        d && Dj().set(a, d) && null != _.Aj(a, 2) && wj(27, _.Aj(a, 1))
    };
    var Nj = function(a, b) {
        SH.call(this, 1048, b);
        this.l = V(this);
        this.v = V(this);
        this.G = W(this, a)
    };
    _.T(Nj, SH);
    Nj.prototype.j = function() {
        var a = this.G.value,
            b = function(c) {
                var d = {};
                wj(c, _.Aj(a, 1), null, (d.tic = String(Math.round((Date.now() - $c(jo(a, 3))) / 6E4)), d))
            };
        switch (Ej(a)) {
            case 0:
                b(24);
                break;
            case 1:
                b(25);
                this.v.F(a);
                break;
            case 2:
                b(26);
                this.l.F(a);
                break;
            case 3:
                wj(9, _.Aj(a, 1));
                this.l.F(a);
                break;
            case 4:
                b(23), this.l.F(a)
        }
    };
    var TH = function(a, b) {
        SH.call(this, 1094, b);
        this.l = hG(this);
        this.v = W(this, a)
    };
    _.T(TH, SH);
    TH.prototype.j = function() {
        var a = this.v.value;
        if (a) {
            if (void 0 !== a)
                for (var b = _.z(_.A(Object, "keys").call(Object, a)), c = b.next(); !c.done; c = b.next())
                    if (c = c.value, _.A(c, "startsWith").call(c, "_GESPSK")) try {
                        a.removeItem(c)
                    } catch (d) {}
            RH = new QH;
            this.l.notify()
        }
    };
    var ck = function(a, b, c) {
        SH.call(this, 1049, c);
        this.l = b;
        jG(this, a)
    };
    _.T(ck, SH);
    ck.prototype.j = function() {
        for (var a = _.z(yj(this.l)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = Dj().get(b, this.l).Cc;
            if (c) {
                var d = Ej(c);
                if (2 === d || 3 === d) {
                    d = void 0;
                    var e = Dj();
                    c = _.Aj(c, 1);
                    try {
                        this.l.removeItem("_GESPSK-" + c), delete e.cache[c]
                    } catch (f) {
                        wj(8, c, null == (d = f) ? void 0 : d.message)
                    }
                    wj(40, b)
                }
            }
        }
    };
    var Kj = function(a, b, c) {
        SH.call(this, 1027, c);
        this.ne = a;
        this.G = b;
        this.l = V(this);
        this.v = V(this)
    };
    _.T(Kj, SH);
    Kj.prototype.j = function() {
        var a = Dj().get(this.ne, this.G).Cc;
        a || (a = oy(ny(this.ne)), this.v.F(a.gb(ly(100))));
        this.l.F(a)
    };
    var Uj = {};
    var gk = function(a, b) {
        SH.call(this, 1036, b);
        this.l = V(this);
        this.v = W(this, a)
    };
    _.T(gk, SH);
    gk.prototype.j = function() {
        var a = this.v.value;
        0 !== Ej(a) && this.l.F(a)
    };
    var Rj = function(a, b, c) {
        SH.call(this, 1046, c);
        this.output = hG(this);
        this.l = V(this);
        this.v = W(this, b);
        jG(this, a)
    };
    _.T(Rj, SH);
    Rj.prototype.j = function() {
        this.l.F(this.v.value)
    };
    var Oj = function(a, b, c) {
        SH.call(this, 1047, c);
        this.collectorFunction = a;
        this.l = V(this);
        this.v = V(this);
        this.G = V(this);
        this.K = W(this, b)
    };
    _.T(Oj, SH);
    Oj.prototype.j = function() {
        var a = this,
            b = this.K.value,
            c = _.Aj(b, 1);
        wj(18, c);
        try {
            var d = _.Vg();
            this.collectorFunction().then(function(e) {
                wj(29, c, null, {
                    delta: String(_.Vg() - d)
                });
                a.l.F(Vn(b, 2, e));
                a.G.Ca(e)
            }).catch(function(e) {
                wj(28, c, Ij(e));
                a.v.F(b.gb(ly(106)))
            })
        } catch (e) {
            wj(1, c, Ij(e)), this.v.F(b.gb(ly(107)))
        }
    };
    var Mj = function(a, b) {
        SH.call(this, 1028, b);
        this.l = V(this);
        this.v = W(this, a)
    };
    _.T(Mj, SH);
    Mj.prototype.j = function() {
        var a = this.v.value,
            b = _.Aj(a, 1);
        null != $c(jo(a, 3)) || wj(35, b);
        this.l.F(a)
    };
    var Pj = function(a, b, c, d, e) {
        SH.call(this, 1050, e);
        this.K = c;
        this.G = d;
        this.l = V(this);
        this.v = W(this, a);
        this.O = Y(this, b)
    };
    _.T(Pj, SH);
    Pj.prototype.j = function() {
        var a = this.v.value,
            b = _.Aj(a, 1),
            c = this.O.value;
        if (null == c) wj(41, b), a.gb(ly(111)), this.l.F(a);
        else if ("string" !== typeof c) wj(21, b), this.l.F(a.gb(ly(113)));
        else {
            if (c.length > (/^(\d+)$/.test(b) ? this.G : this.K)) {
                var d = {};
                wj(12, b, null, (d.sl = String(c.length), d));
                b = a.gb(ly(108));
                _.Ai(b, 2)
            } else c.length || wj(20, b), _.Ai(a, 10);
            this.l.F(a)
        }
    };
    var Qj = function(a) {
        SH.call(this, 1046, a);
        this.output = hG(this)
    };
    _.T(Qj, SH);
    Qj.prototype.j = function() {
        var a = this;
        xj().then(function() {
            a.output.notify()
        })
    };
    var UH = function(a, b, c, d) {
        SH.call(this, 1059, d);
        this.K = b;
        this.G = c;
        this.l = V(this);
        this.O = W(this, a);
        this.v = Y(this, c)
    };
    _.T(UH, SH);
    UH.prototype.j = function() {
        var a = this.v.value;
        if (a) {
            var b = this.O.value,
                c = b.id,
                d = b.collectorFunction,
                e;
            b = null != (e = b.networkCode) ? e : c;
            c = {};
            wj(42, b, null, (c.ea = String(Number(this.K)), c));
            this.l.Ja(Tj(b, d, a, this.G, this.C))
        }
    };
    var VH = function(a, b) {
        SH.call(this, 1057, b);
        this.l = a;
        this.v = V(this);
        this.G = V(this)
    };
    _.T(VH, SH);
    VH.prototype.j = function() {
        if (this.l)
            if ("object" !== typeof this.l) wj(46, "UNKNOWN_COLLECTOR_ID"), WH(this, "UNKNOWN_COLLECTOR_ID", 112);
            else {
                var a = this.l.id,
                    b = this.l.networkCode;
                a && b && (delete this.l.id, wj(47, a + ";" + b));
                a = null != b ? b : a;
                "string" !== typeof a ? (b = {}, wj(37, "INVALID_COLLECTOR_ID", null, (b.ii = JSON.stringify(a), b)), WH(this, "INVALID_COLLECTOR_ID", 102)) : "function" !== typeof this.l.collectorFunction ? (wj(14, a), WH(this, a, 105)) : (_.G = eg(nB), _.A(_.G, "includes")).call(_.G, a) ? (wj(22, a), WH(this, a, 104)) : this.G.F(this.l)
            }
        else wj(39, "UNKNOWN_COLLECTOR_ID"), WH(this, "UNKNOWN_COLLECTOR_ID", 110)
    };
    var WH = function(a, b, c) {
        a.v.F(ny(b).gb(ly(c)))
    };
    var ak = function(a, b, c, d, e) {
        var f = document;
        f = void 0 === f ? document : f;
        e = void 0 === e ? Uj : e;
        this.j = b;
        this.m = c;
        this.V = f;
        this.I = d;
        this.H = e;
        this.l = [];
        this.J = [];
        this.A = [];
        this.o = 0;
        a = _.z(a);
        for (b = a.next(); !b.done; b = a.next()) this.push(b.value)
    };
    ak.prototype.push = function(a) {
        var b = this;
        this.m || this.I();
        var c = function(f, g) {
            return void XH(b, f, g)
        };
        a = new VH(a, c);
        var d = new Lj(a.v, void 0, this.j, c);
        c = new UH(a.G, this.m, this.j, c, this.H);
        var e = new Jj;
        dk(e, [a, d, c]);
        Sj(e);
        a = c.l.promise;
        this.l.push(a);
        d = _.z(this.J);
        for (c = d.next(); !c.done; c = d.next()) a.then(c.value)
    };
    ak.prototype.addOnSignalResolveCallback = function(a) {
        this.J.push(a);
        for (var b = _.z(this.l), c = b.next(); !c.done; c = b.next()) c.value.then(a)
    };
    ak.prototype.addErrorHandler = function(a) {
        this.A.push(a)
    };
    ak.prototype.clearAllCache = function() {
        var a = this,
            b = this.V.currentScript instanceof HTMLScriptElement ? this.V.currentScript.src : "";
        if (1 === this.o) {
            var c = {};
            wj(49, "", null, (c.url = b, c))
        } else if (c = String(_.$f(null != b ? b : "")), (_.G = eg(mB), _.A(_.G, "includes")).call(_.G, c)) c = {}, wj(48, "", null, (c.url = b, c));
        else {
            var d = new Jj;
            c = new TH(this.j, function(e, f) {
                return void XH(a, e, f)
            });
            O(d, c);
            Sj(d);
            this.o = 1;
            setTimeout(function() {
                a.o = 0
            }, 1E3 * _.cg(lB));
            d = {};
            wj(43, "", null, (d.url = b, d));
            return c.l.promise
        }
    };
    var XH = function(a, b, c) {
            a = _.z(a.A);
            for (var d = a.next(); !d.done; d = a.next()) d = d.value, d(b, c)
        },
        bk = function(a) {
            this.push = function(b) {
                a.push(b)
            };
            this.addOnSignalResolveCallback = function(b) {
                a.addOnSignalResolveCallback(b)
            };
            this.addErrorHandler = function(b) {
                a.addErrorHandler(b)
            };
            this.clearAllCache = function() {
                a.clearAllCache()
            }
        };
    var hk = function(a, b, c) {
        SH.call(this, 1035, c);
        this.v = b;
        this.l = V(this);
        this.G = W(this, a)
    };
    _.T(hk, SH);
    hk.prototype.j = function() {
        var a = this,
            b = this.G.value,
            c = _.Aj(b, 1),
            d = this.v.toString(),
            e = {};
        wj(30, c, null, (e.url = d, e));
        var f = document.createElement("script");
        f.setAttribute("esp-signal", "true");
        ib(f, this.v);
        var g = function() {
            var h = {};
            wj(31, c, null, (h.url = d, h));
            a.l.F(b.gb(ly(109)));
            _.uf(f, "error", g)
        };
        document.head.appendChild(f);
        _.jb(f, "error", g)
    };
    var fk = new _.v.Set;
    var jk = function(a, b) {
        try {
            rb(Mq(a, b))
        } catch (c) {}
    };
    var YH = function(a) {
        this.D = _.B(a)
    };
    _.T(YH, _.F);
    YH.prototype.j = Oe([0, lx, -3, ox]);
    var ZH = [.05, .1, .2, .5],
        $H = [0, .5, 1],
        aI = function(a) {
            a = Wj(a);
            if (!a) return -1;
            try {
                var b = ZE(a.document);
                var c = new _.xi(b.clientWidth, b.clientHeight)
            } catch (d) {
                c = new _.xi(-12245933, -12245933)
            }
            return -12245933 == c.width || -12245933 == c.height ? -1 : c.width * c.height
        },
        bI = function(a, b) {
            return 0 >= a || 0 >= b ? [] : ZH.map(function(c) {
                return Math.min(a / b * c, 1)
            })
        },
        dI = function(a) {
            this.J = a.B;
            this.m = a.Kb;
            this.H = a.timer;
            this.o = null;
            this.A = a.mb;
            this.j = cI(this);
            this.l = a.Sl || !1
        },
        eI = function() {
            var a;
            return !!window.IntersectionObserver && yz(null == (a = window.performance) ? void 0 : a.now)
        };
    dI.prototype.getSlotId = function() {
        return this.o
    };
    var gI = function(a, b) {
            if (a.j) {
                if (null != a.o) {
                    try {
                        fI(a, Math.round(performance.now()), 0, 0, 0, !1)
                    } catch (c) {
                        a.A && a.A(c)
                    }
                    a.j && a.j.unobserve(a.m)
                }
                a.o = b;
                a.j.observe(a.m)
            }
        },
        cI = function(a) {
            if (!_.t.IntersectionObserver) return null;
            var b = a.m.offsetWidth * a.m.offsetHeight,
                c = aI(a.J);
            b = [].concat(_.lh($H), _.lh(bI(c, b)));
            na(b);
            return new _.t.IntersectionObserver(function(d) {
                try {
                    for (var e = aI(a.J), f = _.z(d), g = f.next(); !g.done; g = f.next()) {
                        var h = g.value;
                        a.l && fI(a, Math.round(h.time), h.boundingClientRect.width * h.boundingClientRect.height, h.intersectionRect.width * h.intersectionRect.height, e, h.isIntersecting)
                    }
                } catch (k) {
                    a.A && a.A(k)
                }
            }, {
                threshold: b
            })
        },
        fI = function(a, b, c, d, e, f) {
            if (null == a.o) throw Error("Not Attached.");
            var g = new YH;
            c = _.xk(g, 1, c);
            d = _.xk(c, 2, d);
            e = _.xk(d, 3, e);
            b = _.xk(e, 4, b);
            f = Fj(b, 5, f);
            f = Ab(f.j(), 4);
            SG(a.H, "1", 10, f, void 0, a.o)
        };
    var hI = function(a, b) {
            this.j = a;
            this.o = b
        },
        iI = function(a) {
            if (a.j.frames.google_ads_top_frame) return !0;
            var b = Az(a.j);
            b = b && b.contentWindow;
            if (!b) return !1;
            b.addEventListener("message", function(c) {
                var d = c.ports;
                "__goog_top_url_req" === c.data.msgType && d.length && d[0].postMessage({
                    msgType: "__goog_top_url_resp",
                    topUrl: a.o
                })
            }, !1);
            return !0
        };
    var wk = function(a) {
        this.D = _.B(a)
    };
    _.T(wk, _.F);
    var Ck = Pe(wk),
        zk = [1, 3];
    var wf = {
        yn: 0,
        un: 1,
        vn: 9,
        qn: 2,
        rn: 3,
        xn: 5,
        wn: 7,
        sn: 10
    };
    var jI = _.tu(["https://securepubads.g.doubleclick.net/static/topics/topics_frame.html"]),
        qk = _.Ve(jI);
    var kI = function() {
            this.id = "goog_" + Ty++
        },
        lI = function(a) {
            _.U.call(this);
            this.context = a;
            this.m = new _.v.Map
        };
    _.T(lI, _.U);
    lI.prototype.o = function() {
        _.U.prototype.o.call(this);
        this.m.clear()
    };
    lI.prototype.listen = function(a, b) {
        var c = this;
        if (this.J) return function() {};
        var d = "string" === typeof a ? a : a.id,
            e, f, g = null != (f = null == (e = this.m.get(d)) ? void 0 : e.add(b)) ? f : new _.v.Set([b]);
        this.m.set(d, g);
        return function() {
            return void mI(c, a, b)
        }
    };
    var nI = function(a) {
            var b = Hs;
            var c = void 0 === c ? function() {
                return !0
            } : c;
            return new _.v.Promise(function(d) {
                var e = a.listen(b, function(f) {
                    c(f) && (e(), d(f))
                })
            })
        },
        mI = function(a, b, c) {
            var d;
            return !(null == (d = a.m.get("string" === typeof b ? b : b.id)) || !d.delete(c))
        },
        Lr = function(a, b, c, d) {
            var e, f, g, h, k, l, m, n;
            _.lb(function(p) {
                e = "string" === typeof b ? b : b.id;
                f = a.m.get(e);
                if (null == (g = f) || !g.size) return p.return();
                h = "function" === typeof window.CustomEvent ? new CustomEvent(e, {
                    detail: d,
                    bubbles: !0,
                    cancelable: !0
                }) : function() {
                    var r = document.createEvent("CustomEvent");
                    r.initCustomEvent(e, !0, !0, d);
                    return r
                }();
                k = [];
                l = _.z(f);
                m = l.next();
                for (n = {}; !m.done; n = {
                        Je: n.Je
                    }, m = l.next()) n.Je = m.value, k.push(new _.v.Promise(function(r) {
                    return function(w) {
                        return _.lb(function(u) {
                            if (1 == u.j) return u.yield(0, 2);
                            Nh(a.context, c, function() {
                                a.m.has(e) && f.has(r.Je) && (0, r.Je)(h)
                            }, !0);
                            w();
                            u.j = 0
                        })
                    }
                }(n)));
                return p.yield(_.v.Promise.all(k), 0)
            })
        },
        oI = new kI,
        pI = new kI,
        Mr = new kI,
        qI = new kI,
        Nr = new kI,
        rI = new kI,
        sI = new kI,
        Sp = new kI,
        Hs = new kI,
        tI = new kI;
    var uI = function() {
            this.data = void 0;
            this.status = 0;
            this.j = []
        },
        vI = function(a) {
            a.data = void 0;
            a.status = 1
        };
    uI.prototype.me = function() {
        this.j = []
    };
    var wI, AI, DI, ot, EI, zI, yI, xI, kp;
    wI = function() {
        this.j = new _.v.Map;
        this.l = 0;
        this.o = new _.v.Map;
        this.re = null;
        this.A = this.m = this.M = this.H = 0;
        this.ze = null;
        this.I = new uI;
        this.J = new uI
    };
    AI = function(a, b) {
        a.j.get(b) || (a.j.set(b, {
            zc: !0,
            vg: "",
            gd: "",
            Ai: 0,
            tg: [],
            ug: [],
            nc: !1
        }), _.tn(b, function() {
            a.j.delete(b);
            xI(a, b)
        }), b.listen(pI, function(c) {
            c = c.detail;
            var d = a.j.get(b);
            d.vg = _.Aj(c, 33) || "";
            d.nc = !0;
            yI(a, b, function() {
                return void(d.vg = "")
            });
            zI(a, b, function() {
                return void(d.nc = !1)
            })
        }))
    };
    _.jp = function(a, b) {
        var c;
        return null == (c = a.j.get(b)) ? void 0 : c.zc
    };
    _.BI = function(a, b) {
        if (a = a.j.get(b)) a.zc = !1
    };
    _.CI = function(a, b) {
        if (a = a.j.get(b)) a.zc = !0
    };
    DI = function(a, b) {
        if (!b.length) return [];
        var c = nh(b[0].getAdUnitPath());
        b.every(function(g) {
            return nh(g.getAdUnitPath()) === c
        });
        var d = [];
        a = _.z(a.j);
        for (var e = a.next(); !e.done; e = a.next()) {
            var f = _.z(e.value);
            e = f.next().value;
            (f = f.next().value.vg) && nh(e.getAdUnitPath()) === c && !_.A(b, "includes").call(b, e) && d.push(f)
        }
        return d
    };
    ot = function(a, b) {
        var c, d;
        return null != (d = null == (c = a.j.get(b)) ? void 0 : c.gd) ? d : ""
    };
    EI = function(a, b) {
        return (a = a.j.get(b)) ? a.Ai - 1 : 0
    };
    zI = function(a, b, c) {
        (a = a.j.get(b)) && a.tg.push(c)
    };
    yI = function(a, b, c) {
        (a = a.j.get(b)) && a.ug.push(c)
    };
    xI = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.ug.slice(), a.ug.length = 0, a = _.z(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    kp = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.tg.slice(), a.tg.length = 0, a = _.z(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    wI.prototype.nc = function(a) {
        var b, c;
        return null != (c = null == (b = this.j.get(a)) ? void 0 : b.nc) ? c : !1
    };
    var FI = function(a, b, c) {
            if (a = a.j.get(b)) a.zi = c
        },
        GI = function(a, b) {
            if (a = a.j.get(b)) {
                var c;
                null == (c = a.zi) || c.wa();
                delete a.zi
            }
        };
    var Qk = new _.v.Map,
        Pk = new _.v.Map;
    var Sk = function(a, b) {
        this.messageId = a;
        this.messageArgs = b
    };
    Sk.prototype.getMessageId = function() {
        return this.messageId
    };
    Sk.prototype.getMessageArgs = function() {
        return this.messageArgs
    };
    var HI = P(2),
        II = P(3),
        JI = P(4),
        KI = P(5),
        LI = P(6),
        MI = P(12),
        NI = P(14),
        OI = P(16),
        ml = P(19),
        PI = P(20),
        QI = P(23),
        RI = P(26),
        SI = P(28),
        TI = P(149),
        UI = P(30),
        VI = P(31),
        WI = P(34),
        XI = P(35),
        Al = P(36),
        ns = P(38),
        YI = P(40),
        ZI = P(48),
        $I = P(50),
        aJ = P(60),
        bJ = P(63),
        cJ = P(64),
        dJ = P(66),
        eJ = P(68),
        fJ = P(69),
        gJ = P(70),
        hJ = P(71),
        iJ = P(78),
        jJ = P(80),
        fm = P(82),
        nl = P(84),
        kJ = P(85),
        lJ = P(87),
        fl = P(88),
        mJ = P(92),
        nJ = P(93),
        oJ = P(99),
        pl = P(103),
        dm = P(104),
        pJ = P(105),
        Yl = P(106),
        Zl = P(107),
        em = P(108),
        qJ = P(113),
        rJ = P(114),
        sJ = P(115),
        tJ = P(117),
        uJ = P(118),
        vJ = P(120),
        wJ = P(119),
        Ml = P(121),
        xJ = P(122),
        yJ = P(123),
        zq = P(125),
        zJ = P(126),
        AJ = P(127),
        BJ = P(144),
        mq = P(129),
        oq = P(132),
        CJ = P(134),
        DJ = P(135),
        EJ = P(136),
        FJ = P(137),
        GJ = P(138),
        HJ = P(139),
        IJ = P(140),
        Oq = P(142),
        JJ = P(143),
        KJ = P(145),
        LJ = P(147),
        ts = P(148),
        MJ = P(150),
        NJ = P(152),
        OJ = P(153),
        PJ = P(154),
        Sq = P(155),
        QJ = P(156),
        RJ = P(157),
        SJ = P(158),
        TJ = P(159),
        UJ = P(160);
    var VJ = function(a, b, c) {
        var d = this;
        this.addEventListener = L(a, 86, function(e, f) {
            if ("function" !== typeof f) return Q(b, Uk("Service.addEventListener", [e, f])), d;
            var g = Vk(e);
            if (!g) return Q(b, nJ(e)), d;
            c.addEventListener(g, f);
            return d
        });
        this.removeEventListener = L(a, 904, function(e, f) {
            var g = Vk(e);
            "function" === typeof f && g ? c.removeEventListener(g, f) : Q(b, Uk("Service.removeEventListener", [e, f]))
        });
        this.getSlots = L(a, 573, function() {
            return c.j.map(function(e) {
                return e.j
            })
        });
        this.getSlotIdMap = L(a, 574, function() {
            for (var e = {}, f = _.z(c.j), g = f.next(); !g.done; g = f.next()) g = g.value, e[g.toString()] = g.j;
            return e
        });
        this.getName = L(a, 575, function() {
            return c.getName()
        })
    };
    var Wk = function(a, b, c) {
        VJ.call(this, a, b, c);
        this.setRefreshUnfilledSlots = L(a, 59, function(d) {
            c.setRefreshUnfilledSlots(d)
        });
        this.notifyUnfilledSlots = L(a, 69, function(d) {
            c.zc && WJ(c, XJ(c, d))
        });
        this.refreshAllSlots = L(a, 60, function() {
            c.zc && WJ(c)
        });
        this.setVideoSession = L(a, 61, function(d, e, f) {
            c.H = e;
            c.v = f;
            "number" === typeof d && (e = Pi().j, _.Ai(e, 29, null == d ? d : bd(d)))
        });
        this.getDisplayAdsCorrelator = L(a, 62, function() {
            return String(Zw(Pi().j, 26))
        });
        this.getVideoStreamCorrelator = L(a, 63, function() {
            var d = Pi().j;
            d = hr(d, 29);
            return null != d ? d : 0
        });
        this.isSlotAPersistentRoadblock = L(a, 64, function(d) {
            var e = _.A(c.j, "find").call(c.j, function(f) {
                return f.j === d
            });
            return !!e && YJ(c, e)
        });
        this.onImplementationLoaded = L(a, 65, function() {
            c.T.info(ZI("GPT CompanionAds"))
        });
        this.slotRenderEnded = L(a, 67, function(d, e, f) {
            var g = _.A(c.j, "find").call(c.j, function(h) {
                return h.j === d
            });
            return g && ZJ(c, g, e, f)
        })
    };
    _.T(Wk, VJ);
    var Yk = function(a, b, c) {
        VJ.call(this, a, b, c);
        this.setContent = L(a, 72, function(d) {
            var e = _.A(c.j, "find").call(c.j, function(f) {
                return f.j === d
            });
            b.error(BJ(), e)
        })
    };
    _.T(Yk, VJ);
    var rl = function(a, b, c, d) {
        var e = this,
            f = c.getSlotId(),
            g = Pi().j,
            h = aH(Pi(), f.getDomId());
        this.set = L(a, 83, function(k, l) {
            "page_url" === k && l && (k = [cl(dl(new el, k), [String(l)])], _.ol(h, 3, k));
            return e
        });
        this.get = L(a, 84, function(k) {
            if ("page_url" !== k) return null;
            var l, m;
            return null != (m = null == (l = (_.G = h.Ma(), _.A(_.G, "find")).call(_.G, function(n) {
                return _.Aj(n, 1) === k
            })) ? void 0 : _.jl(l, 2)[0]) ? m : null
        });
        this.setClickUrl = L(a, 79, function(k) {
            $k(k, h, f, b);
            return e
        });
        this.setTargeting = L(a, 81, function(k, l) {
            gl(k, l, f, h, b);
            return e
        });
        this.updateTargetingFromMap = L(a, 85, function(k) {
            hl(k, f, h, b);
            return e
        });
        this.display = L(a, 78, function() {
            var k = Bi(g, Pi().o);
            var l = void 0 === l ? document : l;
            var m;
            null != (m = k.R[f.getDomId()]) && Fj(m, 19, !0);
            m = f.getDomId();
            m = Av(m);
            var n = {
                id: m
            };
            var p = void 0 === p ? $v : p;
            var r = _.A(Object, "assign").call(Object, {}, n);
            m = n.id;
            var w = n.style;
            n = n.data;
            r = (delete r.id, delete r.style, delete r.data, r);
            if (_.A(Object, "keys").call(Object, r).length) throw Error("Invalid attribute(s): " + _.A(Object, "keys").call(Object, r));
            m = {
                id: m,
                style: w ? w : void 0
            };
            if (n)
                for (w = _.z(_.A(n, "entries").call(n)), n = w.next(); !n.done; n = w.next()) r = _.z(n.value), n = r.next().value, r = r.next().value, Me(dH.test(n)), m[n] = r;
            _.Zv("div");
            p = _.dw("div", m, p);
            l.write(_.Vv(p));
            Fi(f, l) && (os(d), AI(d.L, f), $J(d, k, f))
        });
        this.setTagForChildDirectedTreatment = L(a, 80, function(k) {
            if (0 === k || 1 === k) {
                var l = Ft(g) || new WG;
                l.setTagForChildDirectedTreatment(k);
                _.th(g, 25, l)
            }
            return e
        });
        this.setForceSafeFrame = L(a, 567, function(k) {
            "boolean" === typeof k ? Fj(h, 12, k) : Q(b, Uk("PassbackSlot.setForceSafeFrame", [String(k)]), f);
            return e
        });
        this.setTagForUnderAgeOfConsent = L(a, 448, function(k) {
            if (0 === k || 1 === k) {
                var l = Ft(g) || new WG;
                l.setTagForUnderAgeOfConsent(k);
                _.th(g, 25, l)
            }
            return e
        })
    };
    var dq = {
        pn: 0,
        mn: 1,
        nn: 2,
        on: 3
    };
    var ul = {
            REWARDED: 4,
            TOP_ANCHOR: 2,
            BOTTOM_ANCHOR: 3,
            INTERSTITIAL: 5,
            GAME_MANUAL_INTERSTITIAL: 7,
            LEFT_SIDE_RAIL: 8,
            RIGHT_SIDE_RAIL: 9
        },
        wl = {
            IAB_AUDIENCE_1_1: 1,
            IAB_CONTENT_2_1: 2,
            IAB_CONTENT_2_2: 3
        },
        vl = {
            PURCHASED: 1,
            ORGANIC: 2
        };
    var yl = function() {
        var a = {};
        return a.adsense_channel_ids = "channel", a.adsense_ad_types = "ad_type", a.adsense_ad_format = "format", a.adsense_background_color = "color_bg", a.adsense_border_color = "color_border", a.adsense_link_color = "color_link", a.adsense_text_color = "color_text", a.adsense_url_color = "color_url", a.page_url = "url", a.adsense_allow_expandable_ads = "ea", a.adsense_encoding = "oe", a.adsense_family_safe = "adsafe", a.adsense_flash_version = "flash", a.adsense_font_face = "f", a.adsense_hints = "hints", a.adsense_keyword_type = "kw_type", a.adsense_keywords = "kw", a.adsense_test_mode = "adtest", a.alternate_ad_iframe_color = "alt_color", a.alternate_ad_url = "alternate_ad_url", a.demographic_age = "cust_age", a.demographic_gender = "cust_gender", a.document_language = "hl", a
    };
    var aK = "",
        Gl = null;
    var om = function(a, b, c) {
        lI.call(this, a);
        this.slotId = b;
        this.j = c
    };
    _.T(om, lI);
    om.prototype.getSlotId = function() {
        return this.slotId
    };
    var yf = function(a, b, c, d) {
        lI.call(this, a);
        this.adUnitPath = b;
        this.Kb = d;
        this.j = null;
        this.id = this.adUnitPath + "_" + c
    };
    _.T(yf, lI);
    _.q = yf.prototype;
    _.q.getId = function() {
        return this.id
    };
    _.q.getAdUnitPath = function() {
        return this.adUnitPath
    };
    _.q.getName = function() {
        return this.adUnitPath
    };
    _.q.toString = function() {
        return this.getId()
    };
    _.q.getDomId = function() {
        return this.Kb
    };
    var bK = function(a, b) {
        a.j = b
    };
    var hm = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;
    var lm = _.ev(function() {
            return void Dz("google_DisableInitialLoad is deprecated and will be removed. Please use googletag.pubads().isInitialLoadDisabled() instead to check if initial load has been disabled.")
        }),
        cK = _.ev(function() {
            return void Dz("googletag.pubads().setCookieOptions() has been removed, and no longer has any effect. Consider migrating to Limited Ads.")
        }),
        dK = _.ev(function() {
            return void Dz("The following functions are deprecated: googletag.pubads().setTagForChildDirectedTreatment(), googletag.pubads().clearTagForChildDirectedTreatment(), googletag.pubads().setRequestNonPersonalizedAds(), and googletag.pubads().setTagForUnderAgeOfConsent(). Please use googletag.pubads().setPrivacySettings() instead.")
        }),
        qm = function(a, b, c, d, e) {
            VJ.call(this, a, b, c);
            var f = this,
                g = Pi().j,
                h = Pi().o,
                k = !1;
            this.setTargeting = L(a, 1, function(l, m) {
                am({
                    key: l,
                    value: m,
                    Da: g,
                    serviceName: c.getName(),
                    Ql: c.enabled,
                    ab: e,
                    T: b,
                    context: a
                });
                return f
            });
            this.clearTargeting = L(a, 2, function(l) {
                gm(l, g, c.getName(), b);
                return f
            });
            this.getTargeting = L(a, 38, function(l) {
                return bm(l, g, b)
            });
            this.getTargetingKeys = L(a, 39, function() {
                return cm(g)
            });
            this.setCategoryExclusion = L(a, 3, function(l) {
                "string" !== typeof l || al(l) ? Q(b, Uk("PubAdsService.setCategoryExclusion", [l])) : ((_.G = _.jl(g, 3), _.A(_.G, "includes")).call(_.G, l) || ix(g, 3, l), b.info(kJ(l)));
                return f
            });
            this.clearCategoryExclusions = L(a, 4, function() {
                _.Ai(g, 3);
                b.info(lJ());
                return f
            });
            this.disableInitialLoad = L(a, 5, function() {
                Fj(g, 4, !0);
                k || (k = !0, mm())
            });
            this.enableSingleRequest = L(a, 6, function() {
                if (c.enabled && !_.N(g, 6)) return Q(b, aJ("PubAdsService.enableSingleRequest")), !1;
                b.info(bJ("single request"));
                Fj(g, 6, !0);
                return !0
            });
            this.enableAsyncRendering = L(a, 7, function() {
                return !0
            });
            this.enableSyncRendering = L(a, 8, function() {
                Dz("GPT synchronous rendering is no longer supported, ads will be requested and rendered asynchronously. See https://support.google.com/admanager/answer/9212594 for more details.");
                return !1
            });
            this.enableLazyLoad = L(a, 485, function(l) {
                var m = new Us;
                m = _.So(m, 1, 800);
                m = _.So(m, 2, 400);
                m = _.Ai(m, 3, _.Ac(3));
                if (_.ka(l)) {
                    var n = l.fetchMarginPercent;
                    "number" === typeof n && (0 <= n ? _.So(m, 1, n) : -1 === n && _.Ai(m, 1));
                    n = l.renderMarginPercent;
                    "number" === typeof n && (0 <= n ? _.So(m, 2, n) : -1 === n && _.Ai(m, 2));
                    l = l.mobileScaling;
                    "number" === typeof l && (0 < l ? _.Ai(m, 3, _.Ac(l)) : -1 === l && _.Ai(m, 3, _.Ac(1)))
                }
                window.IntersectionObserver || !Np(m, 1) && !Np(m, 2) ? _.th(g, 5, m) : Q(b, MJ())
            });
            this.setCentering = L(a, 9, function(l) {
                l = !!l;
                b.info(cJ("centering", String(l)));
                Fj(g, 15, l)
            });
            this.definePassback = L(a, 10, function(l, m) {
                return (l = pm(a, b, c, l, m, d)) && l.ni
            });
            this.refresh = L(a, 11, function() {
                var l = _.Xa.apply(0, arguments),
                    m = _.z(l),
                    n = m.next().value;
                m = m.next().value;
                m = void 0 === m ? {} : m;
                n && !Array.isArray(n) || !_.ka(m) || m.changeCorrelator && "boolean" !== typeof m.changeCorrelator ? Q(b, Uk("PubAdsService.refresh", l)) : (m && !1 === m.changeCorrelator || g.setCorrelator(Hz()), n = n ? km(n, c) : c.j, c.refresh(Bi(g, h), n) || Q(b, Uk("PubAdsService.refresh", l)))
            });
            this.enableVideoAds = L(a, 12, function() {
                Fj(g, 21, !0);
                eK(c, g)
            });
            this.setVideoContent = L(a, 13, function(l, m) {
                fK(c, l, m, g)
            });
            this.collapseEmptyDivs = L(a, 14, function(l) {
                l = void 0 === l ? !1 : l;
                l = void 0 === l ? !1 : l;
                Fj(g, 11, !0);
                l = !!l;
                Fj(g, 10, l);
                b.info(iJ(String(l)));
                return !!_.N(g, 11)
            });
            this.clear = L(a, 15, function(l) {
                if (Array.isArray(l)) return gK(c, g, h, km(l, c));
                if (void 0 === l) return gK(c, g, h, c.j);
                Q(b, Uk("PubAdsService.clear", [l]));
                return !1
            });
            this.setLocation = L(a, 16, function(l) {
                "string" !== typeof l ? Q(b, Uk("PubAdsService.setLocation", [l])) : Vn(g, 8, l);
                return f
            });
            this.setCookieOptions = L(a, 17, function() {
                cK();
                return f
            });
            this.setTagForChildDirectedTreatment = L(a, 18, function(l) {
                dK();
                if (1 !== l && 0 !== l) return Q(b, xJ("PubadsService.setTagForChildDirectedTreatment", Nl(l), "0,1")), f;
                var m = Ft(g) || new WG;
                m.setTagForChildDirectedTreatment(l);
                _.th(g, 25, m);
                return f
            });
            this.clearTagForChildDirectedTreatment = L(a, 19, function() {
                dK();
                var l = Ft(g);
                if (!l) return f;
                l.clearTagForChildDirectedTreatment();
                _.th(g, 25, l);
                return f
            });
            this.setPublisherProvidedId = L(a, 20, function(l) {
                l = String(l);
                b.info(cJ("PPID", l));
                Vn(g, 16, l);
                return f
            });
            this.set = L(a, 21, function(l, m) {
                Bl(l, m, g, c.getName(), b);
                return f
            });
            this.get = L(a, 22, function(l) {
                return Cl(l, g, b)
            });
            this.getAttributeKeys = L(a, 23, function() {
                return Dl(g)
            });
            this.display = L(a, 24, function(l, m, n, p) {
                return void c.display(l, m, d, n, p)
            });
            this.updateCorrelator = L(a, 25, function() {
                Dz(jm("update"));
                Q(b, sJ());
                g.setCorrelator(Hz());
                return f
            });
            this.defineOutOfPagePassback = L(a, 35, function(l) {
                l = pm(a, b, c, l, [1, 1], d);
                if (!l) return null;
                _.ko(l.Da, 15, 1);
                return l.ni
            });
            this.setForceSafeFrame = L(a, 36, function(l) {
                "boolean" !== typeof l ? Q(b, Uk("PubAdsService.setForceSafeFrame", [Nl(l)])) : Fj(g, 13, l);
                return f
            });
            this.setSafeFrameConfig = L(a, 37, function(l) {
                var m = Ol(b, l);
                m ? _.th(g, 18, m) : Q(b, Uk("PubAdsService.setSafeFrameConfig", [l]));
                return f
            });
            this.setRequestNonPersonalizedAds = L(a, 445, function(l) {
                dK();
                if (0 !== l && 1 !== l) return Q(b, xJ("PubAdsService.setRequestNonPersonalizedAds", Nl(l), "0,1")), f;
                var m = Ft(g) || new WG;
                Fj(m, 8, !!l);
                _.th(g, 25, m);
                return f
            });
            this.setTagForUnderAgeOfConsent = L(a, 447, function(l) {
                l = void 0 === l ? 2 : l;
                dK();
                if (2 !== l && 0 !== l && 1 !== l) return Q(b, xJ("PubadsService.setTagForUnderAgeOfConsent", Nl(l), "2,0,1")), f;
                var m = Ft(g) || new WG;
                m.setTagForUnderAgeOfConsent(l);
                _.th(g, 25, m);
                return f
            });
            this.getCorrelator = L(a, 27, function() {
                return String(Zw(g, 26))
            });
            this.getTagSessionCorrelator = L(a, 631, function() {
                return _.Rh(_.t)
            });
            this.getVideoContent = L(a, 30, function() {
                return hK(c, g)
            });
            this.getVersion = L(a, 568, function() {
                return a.wc ? String(a.wc) : a.eb
            });
            this.forceExperiment = L(a, 569, function(l) {
                return void c.forceExperiment(l)
            });
            this.setCorrelator = L(a, 28, function(l) {
                Dz(jm("set"));
                Q(b, rJ());
                if (li(window)) return f;
                if (!Em(l)) return Q(b, Uk("PubadsService.setCorrelator", [Nl(l)])), f;
                l = g.setCorrelator(l);
                Fj(l, 27, !0);
                return f
            });
            this.markAsAmp = L(a, 570, function() {
                window.console && window.console.warn && window.console.warn("googletag.pubads().markAsAmp() is deprecated and ignored.")
            });
            this.isSRA = L(a, 571, function() {
                return !!_.N(g, 6)
            });
            this.setImaContent = L(a, 328, function(l, m) {
                null != _.Aj(g, 22) ? fK(c, l, m, g) : (Fj(g, 21, !0), eK(c, g), "string" === typeof l && Vn(g, 19, l), "string" === typeof m && Vn(g, 20, m))
            });
            this.getImaContent = L(a, 329, function() {
                return null != _.Aj(g, 22) ? hK(c, g) : c.enabled ? {
                    vid: _.R(g, 19) || "",
                    cmsid: _.R(g, 20) || ""
                } : null
            });
            this.isInitialLoadDisabled = L(a, 572, function() {
                return !!_.N(g, 4)
            });
            this.setPrivacySettings = L(a, 648, function(l) {
                if (!_.ka(l)) return Q(b, Uk("PubAdsService.setPrivacySettings", [l])), f;
                var m = l.restrictDataProcessing,
                    n = l.childDirectedTreatment,
                    p = l.underAgeOfConsent,
                    r = l.limitedAds,
                    w = l.nonPersonalizedAds,
                    u = l.userOptedOutOfPersonalization,
                    x = l.trafficSource,
                    y, C = null != (y = Ft(g)) ? y : new WG;
                "boolean" === typeof w ? Fj(C, 8, w) : void 0 !== w && Q(b, Ml("PubAdsService.setPrivacySettings", Nl(l), "nonPersonalizedAds", Nl(w)));
                "boolean" === typeof u ? Fj(C, 13, u) : void 0 !== u && Q(b, Ml("PubAdsService.setPrivacySettings", Nl(l), "userOptedOutOfPersonalization", Nl(u)));
                "boolean" === typeof m ? Fj(C, 1, m) : void 0 !== m && Q(b, Ml("PubAdsService.setPrivacySettings", Nl(l), "restrictDataProcessing", Nl(m)));
                if ("boolean" === typeof r) {
                    m = im();
                    if (r && !_.N(C, 9) && a.Bc) {
                        w = a.Qa;
                        u = w.Ac;
                        y = uh(a);
                        var D = new QA;
                        D = _.xh(D, 1, !0);
                        D = _.xh(D, 2, m);
                        y = _.zh(y, 11, Ah, D);
                        u.call(w, y)
                    }
                    m ? Fj(C, 9, r) : r && Q(b, LJ())
                } else void 0 !== r && Q(b, Ml("PubAdsService.setPrivacySettings", Nl(l), "limitedAds", Nl(r)));
                void 0 !== p && (null === p ? C.setTagForUnderAgeOfConsent(2) : !1 === p ? C.setTagForUnderAgeOfConsent(0) : !0 === p ? C.setTagForUnderAgeOfConsent(1) : Q(b, Ml("PubAdsService.setPrivacySettings", Nl(l), "underAgeOfConsent", Nl(p))));
                void 0 !== n && (null === n ? C.clearTagForChildDirectedTreatment() : !1 === n ? C.setTagForChildDirectedTreatment(0) : !0 === n ? C.setTagForChildDirectedTreatment(1) : Q(b, Ml("PubAdsService.setPrivacySettings", Nl(l), "childDirectedTreatment", Nl(n))));
                void 0 !== x && (null === x ? _.Ai(C, 10) : (_.G = _.A(Object, "values").call(Object, vl), _.A(_.G, "includes")).call(_.G, x) ? _.ko(C, 10, x) : Q(b, Ml("PubAdsService.setPrivacySettings", Nl(l), "trafficSource", Nl(x))));
                _.th(g, 25, C);
                return f
            })
        };
    _.T(qm, VJ);
    var iK = function(a, b) {
        this.getId = L(a, 593, function() {
            return b.getId()
        });
        this.getAdUnitPath = L(a, 594, function() {
            return b.getAdUnitPath()
        });
        this.getName = L(a, 595, function() {
            return b.getName()
        });
        this.toString = L(a, 596, function() {
            return b.toString()
        });
        this.getDomId = L(a, 597, function() {
            return b.getDomId()
        })
    };
    var jK = function() {
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.creativeId = this.campaignId = this.advertiserId = null;
            this.isBackfill = !1;
            this.encryptedTroubleshootingInfo = this.creativeTemplateId = this.companyIds = this.yieldGroupIds = null
        },
        kK = function(a, b) {
            a.advertiserId = b
        },
        lK = function(a, b) {
            a.campaignId = b
        },
        mK = function(a, b) {
            a.yieldGroupIds = b
        },
        nK = function(a, b) {
            a.companyIds = b
        };
    var $h = function(a) {
        this.D = _.B(a)
    };
    _.T($h, _.F);
    $h.prototype.getWidth = function() {
        return Kr(this, 1)
    };
    $h.prototype.getHeight = function() {
        return Kr(this, 2)
    };
    var ym = function() {
        var a = new $h;
        return Fj(a, 3, !0)
    };
    var di = function(a) {
        this.D = _.B(a)
    };
    _.T(di, _.F);
    di.ca = [2];
    var oK = function(a) {
        this.D = _.B(a)
    };
    _.T(oK, _.F);
    var pK = function(a) {
        this.D = _.B(a)
    };
    _.T(pK, _.F);
    pK.ca = [1];
    var qK = function(a) {
        this.D = _.B(a)
    };
    _.T(qK, _.F);
    qK.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    qK.prototype.getDomId = function() {
        return _.R(this, 2)
    };
    var rK = function(a, b) {
        Vn(a, 2, b)
    };
    qK.prototype.Ma = function() {
        return _.bi(this, el, 3)
    };
    qK.prototype.getServices = function(a) {
        return bx(this, 4, a)
    };
    var sK = function(a, b) {
        _.ol(a, 5, b)
    };
    qK.prototype.getClickUrl = function() {
        return _.R(this, 7)
    };
    qK.prototype.setClickUrl = function(a) {
        return Vn(this, 7, a)
    };
    qK.prototype.getCategoryExclusions = function(a) {
        return bx(this, 8, a)
    };
    var bl = function(a) {
        return _.bi(a, el, 9)
    };
    qK.prototype.kc = function() {
        return _.Zh(this, Kl, 13)
    };
    var Ps = function(a) {
        return _.Hk(a, 15, 0)
    };
    qK.ca = [3, 4, 5, 6, 8, 9, 27];
    var tK = function(a, b) {
        this.width = a;
        this.height = b
    };
    tK.prototype.getWidth = function() {
        return this.width
    };
    tK.prototype.getHeight = function() {
        return this.height
    };
    var uK = new _.v.Set(["unhideWindow"]);
    var Nm = function(a, b, c) {
        var d = this,
            e = aH(Pi(), c.getDomId()),
            f = "",
            g = null,
            h = function() {
                return ""
            },
            k = "",
            l = !1;
        _.tn(c, function() {
            e = new qK;
            f = "";
            g = null;
            h = function() {
                return ""
            };
            k = ""
        });
        c.listen(Mr, function(n) {
            var p = n.detail;
            n = p.mh;
            p = p.isBackfill;
            n && (f = n, l = p)
        });
        this.set = L(a, 40, function(n, p) {
            sm(n, p, c, e, b);
            return d
        });
        this.get = L(a, 41, function(n) {
            return tm(n, c, e, b)
        });
        this.getAttributeKeys = L(a, 42, function() {
            return um(e)
        });
        this.addService = L(a, 43, function(n) {
            n = Qk.get(n);
            if (!n) return Q(b, Uk("Slot.addService", [n]), c), d;
            var p = n.getName();
            if ((_.G = _.jl(e, 4), _.A(_.G, "includes")).call(_.G, p)) return b.info(MI(p, c.toString()), c), d;
            n.slotAdded(c, e);
            return d
        });
        this.defineSizeMapping = L(a, 44, function(n) {
            try {
                var p = e;
                if (!Array.isArray(n)) throw new Fm("Size mapping must be an array");
                var r = n.map(Gm);
                _.ol(p, 6, r)
            } catch (w) {
                n = w, Lh(a, 44, n), Dz("Incorrect usage of googletag.Slot defineSizeMapping: " + n.message)
            }
            return d
        });
        this.setClickUrl = L(a, 45, function(n) {
            $k(n, e, c, b);
            return d
        });
        this.setCategoryExclusion = L(a, 46, function(n) {
            var p = e;
            "string" !== typeof n || al(n) ? Q(b, Uk("Slot.setCategoryExclusion", [n]), c) : ((_.G = _.jl(p, 8), _.A(_.G, "includes")).call(_.G, n) || ix(p, 8, n), b.info(NI(n), c));
            return d
        });
        this.clearCategoryExclusions = L(a, 47, function() {
            _.Ai(e, 8);
            b.info(OI(), c);
            return d
        });
        this.getCategoryExclusions = L(a, 48, function() {
            return _.jl(e, 8).slice()
        });
        this.setTargeting = L(a, 49, function(n, p) {
            gl(n, p, c, e, b);
            return d
        });
        this.updateTargetingFromMap = L(a, 649, function(n) {
            hl(n, c, e, b);
            return d
        });
        this.clearTargeting = L(a, 50, function(n) {
            ql(n, c, e, b);
            return d
        });
        this.getTargeting = L(a, 51, function(n) {
            return kl(n, c, e, b)
        });
        this.getTargetingKeys = L(a, 52, function() {
            return ll(e)
        });
        this.setCollapseEmptyDiv = L(a, 53, function(n, p) {
            var r = e;
            p = void 0 === p ? !1 : p;
            p = void 0 === p ? !1 : p;
            "boolean" !== typeof n || "boolean" !== typeof p ? Q(b, Uk("Slot.setCollapseEmptyDiv", [n, p]), c) : (r = Fj(r, 10, n), Fj(r, 11, n && p), p && !n && Q(b, PI(c.toString()), c));
            return d
        });
        this.getAdUnitPath = L(a, 54, function() {
            return c.getAdUnitPath()
        });
        this.getSlotElementId = L(a, 598, function() {
            return c.getDomId()
        });
        this.setForceSafeFrame = L(a, 55, function(n) {
            var p = e;
            "boolean" !== typeof n ? Q(b, Uk("Slot.setForceSafeFrame", [String(n)]), c) : Fj(p, 12, n);
            return d
        });
        this.setSafeFrameConfig = L(a, 56, function(n) {
            var p = e,
                r = Ol(b, n);
            r ? _.th(p, 13, r) : b.error(Uk("Slot.setSafeFrameConfig", [n]), c);
            return d
        });
        c.listen(pI, function(n) {
            n = n.detail;
            if (Pl(n, 8)) g = null;
            else {
                g = new jK;
                var p = !!Pl(n, 9);
                g.isBackfill = p;
                var r = $w(n, 15),
                    w = $w(n, 16);
                r.length && w.length && (g.sourceAgnosticCreativeId = r[0], g.sourceAgnosticLineItemId = w[0], p || (g.creativeId = r[0], g.lineItemId = w[0], (p = $w(n, 22)) && p.length && (g.creativeTemplateId = p[0])));
                $w(n, 17).length && kK(g, $w(n, 17)[0]);
                $w(n, 18).length && lK(g, $w(n, 18)[0]);
                $w(n, 19).length && mK(g, $w(n, 19));
                $w(n, 20).length && nK(g, $w(n, 20));
                n = Xd(n, 45, Kd(n.D) & 34 ? Yd : be).map(function(u) {
                    return Ad(u)
                });
                n.length && (g.encryptedTroubleshootingInfo = n[0])
            }
        });
        this.getResponseInformation = L(a, 355, function() {
            return g
        });
        this.getName = L(a, 170, function() {
            b.error(JJ());
            return c.getAdUnitPath()
        });
        var m = new iK(a, c);
        this.getSlotId = L(a, 579, function() {
            return m
        });
        this.getServices = L(a, 580, function() {
            return _.jl(e, 4).map(function(n) {
                var p = VG[n];
                if (p) {
                    var r, w, u;
                    n = null != (u = null == (w = (r = Hm())[p]) ? void 0 : w.call(r)) ? u : null
                } else n = null;
                return n
            })
        });
        this.getSizes = L(a, 581, function(n, p) {
            var r, w;
            return null != (w = null == (r = ei(e, n, p)) ? void 0 : r.map(function(u) {
                return _.N(u, 3) ? "fluid" : new tK(u.getWidth(), u.getHeight())
            })) ? w : null
        });
        this.getClickUrl = L(a, 582, function() {
            var n;
            return null != (n = e.getClickUrl()) ? n : ""
        });
        this.getTargetingMap = L(a, 583, function() {
            for (var n = {}, p = _.z(bl(e)), r = p.next(); !r.done; r = p.next()) r = r.value, _.R(r, 1) && (n[_.Aj(r, 1)] = _.jl(r, 2));
            return n
        });
        this.getOutOfPage = L(a, 584, function(n) {
            return "number" === typeof n ? Ps(e) === n : 0 !== Ps(e)
        });
        this.getCollapseEmptyDiv = L(a, 585, function() {
            return null != Pl(e, 10) ? _.N(e, 10) : null
        });
        this.getDivStartsCollapsed = L(a, 586, function() {
            return null != Pl(e, 11) ? _.N(e, 11) : null
        });
        c.listen(qI, function(n) {
            h = n.detail.Nj
        });
        this.getContentUrl = L(a, 587, function() {
            return h()
        });
        this.getFirstLook = L(a, 588, function() {
            Dz("The getFirstLook method of SlotInterface is deprecated. Please update your code to no longer call this method.");
            return 0
        });
        c.listen(pI, function(n) {
            var p;
            k = null != (p = n.detail.getEscapedQemQueryId()) ? p : ""
        });
        this.getEscapedQemQueryId = L(a, 591, function() {
            return k
        });
        this.getHtml = L(a, 592, function() {
            return l ? (window.console && console.warn && console.warn("This ad's html cannot be accessed using the getHtml method on googletag.Slot. Returning the empty string instead."), "") : f
        });
        this.setConfig = L(a, 1022, function(n) {
            var p = e;
            if (Af(n)) {
                var r = n.componentAuction,
                    w = n.adExpansion;
                if (null != r) {
                    var u = {
                        componentAuction: r
                    };
                    if (_.ka(u)) {
                        if (r = ge(p, 26, ld), void 0 !== u.componentAuction) {
                            u = _.z(u.componentAuction);
                            for (var x = u.next(); !x.done; x = u.next()) {
                                var y = x.value;
                                x = y.configKey;
                                y = y.auctionConfig;
                                "string" !== typeof x || al(x) || (null === y ? r.delete(x) : y && r.set(x, JSON.stringify(y)))
                            }
                        }
                    } else Q(b, Uk("googletag.Slot.setConfig", [u]))
                }
                if (_.A(Object, "hasOwn").call(Object, n, "interstitial"))
                    if (5 !== Ps(p)) Q(b, UJ("interstitial"), c);
                    else {
                        u = n.interstitial;
                        b.info(QJ("interstitial", Nl(u)), c);
                        if (Af(u))
                            for (r = {}, u = _.z(_.A(Object, "entries").call(Object, u)), x = u.next(); !x.done; x = u.next()) switch (y = _.z(x.value), x = y.next().value, y = y.next().value, x) {
                                case "triggers":
                                    r.triggers = y;
                                    break;
                                default:
                                    Q(b, SJ("interstitial", x), c)
                            } else Q(b, TJ("googletag.slot.setConfig", "interstitial", Nl(u)), c), r = null;
                        x = r;
                        r = new pK;
                        u = {};
                        if (x && x.triggers)
                            if (x = x.triggers, Af(x))
                                for (u.triggers = {}, x = _.z(_.A(Object, "entries").call(Object, x)), y = x.next(); !y.done; y = x.next()) {
                                    var C = _.z(y.value);
                                    y = C.next().value;
                                    C = C.next().value;
                                    var D = y;
                                    y = C;
                                    if (uK.has(D))
                                        if (Jm(y)) switch (D) {
                                            case "unhideWindow":
                                                C = new oK, C = _.ko(C, 1, 2), C = Fj(C, 2, y), Gj(r, 1, oK, C), u.triggers.Tn = y
                                        } else Q(b, TJ("interstitial.triggers", D, Nl(y)), c);
                                        else Q(b, SJ("interstitial.triggers", D), c)
                                } else Q(b, TJ("interstitial", "triggers", Nl(x)), c);
                        b.info(RJ("interstitial", Nl(u)), c);
                        _.th(p, 29, r)
                    }
                _.H(Im) ? _.A(Object, "hasOwn").call(Object, n, "adExpansion") && Lm(p, w) : Lm(p, w)
            } else Q(b, Uk("googletag.slot.setConfig", [n]), c)
        })
    };
    var Z = function(a, b, c) {
        eG.call(this, b, c);
        this.context = a
    };
    _.T(Z, eG);
    Z.prototype.I = function(a) {
        Lh(this.context, this.id, a);
        var b, c;
        null == (b = window.console) || null == (c = b.error) || c.call(b, a)
    };
    var un = function(a, b, c, d, e) {
        var f = null,
            g = Hh(a.context, b, e);
        _.jb(c, d, g) && (f = function() {
            return _.uf(c, d, g)
        }, _.tn(a, f));
        return f
    };
    var Vm = function(a, b, c, d, e) {
        Z.call(this, a, 959);
        this.ib = b;
        this.output = V(this);
        this.l = W(this, b);
        jG(this, c);
        jG(this, d);
        e && jG(this, e)
    };
    _.T(Vm, Z);
    Vm.prototype.j = function() {
        this.output.F(this.l.value)
    };
    var Um = function(a, b, c, d, e, f) {
        Z.call(this, a, 1172);
        this.T = b;
        this.L = c;
        this.B = d;
        this.l = hG(this);
        jG(this, e);
        this.v = W(this, f)
    };
    _.T(Um, Z);
    Um.prototype.j = function() {
        var a = this,
            b = new OE(this.B);
        _.S(this, b);
        if (MC(b.caller)) {
            var c = this.L.J,
                d = c.status,
                e = function(f) {
                    if (f.internalErrorState) dF(a.v.value, f.gppString);
                    else if (If(f.applicableSections)) bF(cF(a.v.value, f.applicableSections.filter(function(k) {
                        return _.A(Number, "isInteger").call(Number, k)
                    })), !1);
                    else {
                        var g = dF(cF(a.v.value, f.applicableSections.filter(function(k) {
                            return _.A(Number, "isInteger").call(Number, k)
                        })), f.gppString);
                        try {
                            var h = SE(f.gppString)
                        } catch (k) {
                            Lh(a.context, 1182, k), h = !1
                        }
                        bF(g, h)
                    }
                    a.l.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.j.push(e);
                    break;
                case 0:
                    vI(c);
                    c.j.push(e);
                    this.T.info(vJ());
                    b.addEventListener(Hh(this.context, 1173, function(f) {
                        if ("ready" === f.pingData.signalStatus || If(f.pingData.applicableSections)) c.data = f.pingData, c.status = 2, c.j.forEach(function(g) {
                            g(f.pingData)
                        }), c.me()
                    }));
                    break;
                default:
                    throw Error("Impossible CacheStatus: " + d);
            }
        } else this.l.notify()
    };
    var Sm = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 874);
        this.T = b;
        this.L = c;
        this.B = d;
        this.v = e;
        this.l = hG(this);
        jG(this, f);
        this.C = W(this, g)
    };
    _.T(Sm, Z);
    Sm.prototype.j = function() {
        var a = this,
            b = new UC(this.B, {
                timeoutMs: -1,
                wj: !0
            });
        _.S(this, b);
        if (WC(b)) {
            var c = this.L.I,
                d = c.status,
                e = function(f) {
                    var g = a.C.value,
                        h, k;
                    if (k = !(a.v ? _.N(a.v, 9) : _.H(iB) && im())) {
                        var l = void 0 === l ? !1 : l;
                        k = $C(f) ? !1 === f.gdprApplies || "tcunavailable" === f.tcString || void 0 === f.gdprApplies && !l || "string" !== typeof f.tcString || !f.tcString.length ? !0 : YC(f, "1") : !1
                    }
                    k = Fj(g, 5, k);
                    l = !aD(f, ["3", "4"]);
                    k = Fj(k, 9, l);
                    k = Vn(k, 2, f.tcString);
                    l = null != (h = f.addtlConsent) ? h : "";
                    h = Vn(k, 4, l);
                    _.ko(h, 7, f.internalErrorState);
                    null != f.gdprApplies && Fj(g, 3, f.gdprApplies);
                    _.H(dC) && !aD(f, ["2", "7", "9", "10"]) && Fj(g, 8, !0);
                    a.l.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.j.push(e);
                    break;
                case 0:
                    vI(c);
                    c.j.push(e);
                    this.T.info(uJ());
                    b.addEventListener(function(f) {
                        $C(f) ? ("tcunavailable" === f.tcString ? a.T.info(wJ("failed")) : a.T.info(wJ("succeeded")), c.data = f, c.status = 2, c.j.forEach(function(g) {
                            g(f)
                        }), c.me()) : vI(c)
                    });
                    break;
                default:
                    throw Error("Impossible CacheStatus: " + d);
            }
        } else this.l.notify()
    };
    var Rm = function(a, b, c, d, e) {
        Z.call(this, a, 875);
        this.T = b;
        this.B = c;
        this.l = hG(this);
        jG(this, d);
        this.v = W(this, e)
    };
    _.T(Rm, Z);
    Rm.prototype.j = function() {
        var a = this,
            b = new CE(this.B);
        _.S(this, b);
        if (MC(b.caller)) {
            var c = Hh(this.context, 660, function(d) {
                d && "string" === typeof d.uspString && (Vn(a.v.value, 1, d.uspString), aF(a.v.value, Hh(a.context, 1187, function() {
                    var e = d.uspString;
                    var f = e = e.toUpperCase();
                    4 == f.length && (-1 == f.indexOf("-") || "---" === f.substring(1)) && "1" <= f[0] && "9" >= f[0] && dA.hasOwnProperty(f[1]) && dA.hasOwnProperty(f[2]) && dA.hasOwnProperty(f[3]) ? (f = new cA, f = _.yh(f, 1, parseInt(e[0], 10)), f = _.I(f, 2, dA[e[1]]), f = _.I(f, 3, dA[e[2]]), e = _.I(f, 4, dA[e[3]])) : e = null;
                    return 2 === (null == e ? void 0 : _.Hk(e, 3, 0))
                })()));
                a.l.notify()
            });
            this.T.info(tJ());
            DE(b, c)
        } else this.l.notify()
    };
    var Pm = function(a, b) {
        Z.call(this, a, 958);
        this.l = b;
        this.ib = V(this)
    };
    _.T(Pm, Z);
    Pm.prototype.j = function() {
        var a = new $E,
            b = this.l ? _.N(this.l, 9) : im();
        Fj(a, 5, !b);
        this.ib.F(a)
    };
    var Qm = function(a, b, c, d) {
        d = void 0 === d ? .001 : d;
        Z.call(this, a, 960);
        this.B = b;
        this.v = d;
        this.l = W(this, c)
    };
    _.T(Qm, Z);
    Qm.prototype.j = function() {
        var a = this;
        Nh(this.context, 894, function() {
            return void Zi("cmpMet", function(b) {
                ej(b, a.context);
                var c = new UC(a.B);
                _.S(a, c);
                var d = new CE(a.B);
                _.S(a, d);
                fj(b, "fc", Number(a.l.value));
                fj(b, "tcfv1", Number(!!a.B.__cmp));
                fj(b, "tcfv2", Number(WC(c)));
                fj(b, "usp", Number(!!MC(d.caller)));
                fj(b, "ptt", 17)
            }, a.v)
        })
    };
    var vK = function(a, b, c, d) {
        Z.call(this, a, 1103);
        this.l = b;
        this.Z = c;
        this.privacyTreatments = d;
        this.output = V(this)
    };
    _.T(vK, Z);
    vK.prototype.j = function() {
        this.output.F(!!Lf(this.Z) && !_.N(this.Z, 9) && !_.N(this.Z, 13) && (!_.H(Tm) || !_.N(this.Z, 12)) && (this.l ? _.N(this.l, 9) || _.N(this.l, 8) || _.N(this.l, 1) || _.H(UB) && _.N(this.l, 13) || 1 === _.Hk(this.l, 6, 2) || 1 === jo(this.l, 5) || _.A(this.privacyTreatments, "includes").call(this.privacyTreatments, 1) ? !1 : !0 : !0))
    };
    var Zm = function(a) {
        this.T = a;
        this.o = this.j = 0
    };
    Zm.prototype.push = function() {
        for (var a = _.z(_.Xa.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                "function" === typeof b && (b.call(_.v.globalThis), this.j++)
            } catch (c) {
                this.o++, b = void 0, null == (b = window.console) || b.error("Exception in queued GPT command", c), this.T.error(UI(String(c)))
            }
        }
        this.T.info(VI(String(this.j), String(this.o)));
        return this.j
    };
    var Xm = function(a, b) {
        this.push = L(a, 76, b.push.bind(b))
    };
    var wK = ["Debug", "Info", "Warning", "Error", "Fatal"],
        xK = function(a, b, c) {
            this.level = a;
            this.message = b;
            this.j = c;
            this.timestamp = new Date
        };
    _.q = xK.prototype;
    _.q.getSlot = function() {
        return this.j
    };
    _.q.getLevel = function() {
        return this.level
    };
    _.q.getTimestamp = function() {
        return this.timestamp
    };
    _.q.getMessage = function() {
        return this.message
    };
    _.q.toString = function() {
        return this.timestamp.toTimeString() + ": " + wK[this.level] + ": " + this.message
    };
    var yK = _.tu(["https://console.googletagservices.com/pubconsole/loader.js"]),
        jn = _.Ve(yK),
        nn, mn = !1,
        dn = !1,
        fn = !1;
    var ks = function(a, b) {
        this.getAllEvents = L(a, 563, function() {
            return dn ? zK(b).slice() : []
        });
        this.getEventsBySlot = L(a, 565, function(c) {
            return dn ? AK(b, c).slice() : []
        });
        this.getEventsByLevel = L(a, 566, function(c) {
            return dn ? BK(b, c).slice() : []
        })
    };
    var CK = {
            20: function(a) {
                return "Ignoring a call to setCollapseEmptyDiv(false, true). Slots that start out collapsed should also collapse when empty. Slot: " + a[0] + "."
            },
            23: function(a) {
                return 'Error in googletag.display: could not find div with id "' + a[1] + '" in DOM for slot: ' + a[0] + "."
            },
            34: function(a) {
                return "Size mapping is null because invalid mappings were added: " + a[0] + "."
            },
            60: function(a) {
                return "Ignoring the " + a[0] + "(" + (a[1] || "") + ") call since the service is already enabled."
            },
            66: function(a) {
                return "Slot " + a[0] + " cannot be refreshed until PubAdsService is enabled."
            },
            68: function() {
                return "Slots cannot be cleared until service is enabled."
            },
            80: function(a) {
                return "Slot object at position " + a[0] + " is of incorrect type."
            },
            84: function(a) {
                return 'Cannot find targeting attribute "' + a[0] + '" for "' + a[1] + '".'
            },
            93: function(a) {
                return "Failed to register listener. Unknown event type: " + a[0] + "."
            },
            96: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + ")."
            },
            122: function(a) {
                return "Invalid argument: " + a[0] + "(" + a[1] + "). Valid values: " + a[2] + "."
            },
            121: function(a) {
                return "Invalid object passed to " + a[0] + "(" + a[1] + "), for " + a[2] + ": " + a[3] + "."
            },
            151: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + "). All zero-area slot sizes were removed."
            },
            105: function(a) {
                return "SRA requests may include a maximum of 30 ad slots. " + a[1] + " were requested, so the last " + a[2] + " were ignored."
            },
            106: function(a) {
                return "Publisher betas " + a[0] + " were declared after enableServices() was called."
            },
            107: function(a) {
                return "Publisher betas may only be declared once. " + a[0] + " were added after betas had already been declared."
            },
            108: function(a) {
                return "Beta keys cannot be cleared. clearTargeting() was called on " + a[0] + "."
            },
            123: function(a) {
                return "Refresh was throttled for slot: " + a[0] + "."
            },
            113: function(a) {
                return a[0] + " ad slot ineligible as page is not mobile optimized: " + a[1] + "."
            },
            114: function() {
                return 'setCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            115: function() {
                return 'updateCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            132: function(a) {
                return "Taxonomy with id " + a[0] + " has reached the limit of " + a[1] + " values."
            },
            133: function() {
                return "No taxonomy values were cleared, either due to an invalid taxonomy or no values present."
            },
            134: function(a) {
                return pn(a[0]) + " " + a[1] + " not requested: Format already created on the page."
            },
            135: function(a) {
                return pn(a[0]) + " " + a[1] + " not requested: Frequency cap of 1 has been exceeded."
            },
            136: function(a) {
                return pn(a[0]) + " " + a[1] + " not requested: The viewport exceeds the current maximum width of 2500px."
            },
            137: function(a) {
                return pn(a[0]) + " " + a[1] + " not requested: Format currently only supported on mobile."
            },
            138: function(a) {
                return pn(a[0]) + " " + a[1] + " not requested: Format currently only supports portrait orientation."
            },
            139: function(a) {
                return pn(a[0]) + " " + a[1] + " not requested: GPT is not running in the top-level window."
            },
            140: function(a) {
                return pn(a[0]) + " " + a[1] + " not requested: Detected browser is currently unsupported."
            },
            142: function(a) {
                return "A google product ad tag with click url " + a[0] + " does not contain any elements enabled for clicking."
            },
            145: function(a) {
                return pn(a[0]) + " " + a[1] + " not requested: Unable to access local storage to determine if the frequency cap has been exceeded due to insufficient user consent."
            },
            143: function() {
                return "getName on googletag.Slot is deprecated and will be removed. Use getAdUnitPath instead."
            },
            147: function() {
                return "GPT must be loaded from the limited ads URL to enable limited ads functionality."
            },
            148: function() {
                return "CommerceAdsConfig must contain a valid value for either categories or queries."
            },
            150: function() {
                return "Legacy browser does not support intersection observer causing lazy render/fetch as well as viewability events not to work properly."
            },
            154: function(a) {
                return "Refresh is disabled for " + pn(a[0]) + " " + a[1] + "."
            },
            152: function() {
                return "Attempted to load GPT multiple times."
            },
            155: function() {
                return "Using deprecated googletag.encryptedSignalProviders. Please use googletag.secureSignalProviders instead."
            },
            158: function(a) {
                return "Unrecognized property encountered when calling setConfig: " + a[0] + "." + a[1]
            },
            159: function(a) {
                return "Invalid value encountered when calling setConfig: " + a[0] + "." + a[1] + ": " + a[2]
            },
            160: function(a) {
                return "slot.setConfig key " + a[0] + " is not valid for this slot."
            }
        },
        DK = {
            26: function(a) {
                return "Div ID passed to googletag.display() does not match any defined slots: " + a[0] + "."
            },
            28: function(a) {
                return "Error in googletag.defineSlot: Cannot create slot " + a[1] + '. Div element "' + a[0] + '" is already associated with another slot: ' + a[2] + "."
            },
            149: function(a) {
                return "Error in googletag.defineSlot: Invalid ad unit path provided " + a[0] + ", see https://support.google.com/admanager/answer/10477476 for more information."
            },
            92: function(a) {
                return "Exception in " + a[1] + ' event listener: "' + a[0] + '".'
            },
            30: function(a) {
                return "Exception in googletag.cmd function: " + a[0] + "."
            },
            125: function(a) {
                return "google-product-ad element is invalid: " + a[0] + "."
            },
            126: function() {
                return "Attempted to collect prebid data but window.pbjs is undefined."
            },
            153: function() {
                return "Attempted to load GPT from both standard and limited ads domains."
            },
            127: function(a) {
                return "Encountered the following error while attempting to collect prebid metadata: " + a[0] + "."
            },
            144: function() {
                return "ContentService is no longer available. Use the browser's built-in DOM APIs to directly add content to div elements instead."
            }
        };
    var EK = function(a) {
            this.context = a;
            this.m = this.j = 0;
            this.A = window;
            this.o = [];
            this.o.length = 1E3
        },
        zK = function(a) {
            return [].concat(_.lh(a.o.slice(a.j)), _.lh(a.o.slice(0, a.j))).filter(function(b) {
                return !!b
            })
        },
        AK = function(a, b) {
            return zK(a).filter(function(c) {
                return c.getSlot() === b
            })
        },
        BK = function(a, b) {
            return zK(a).filter(function(c) {
                return c.getLevel() >= b
            })
        };
    EK.prototype.log = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? !1 : d;
        var e, f, g = new xK(a, b, null != (f = null == (e = c) ? void 0 : e.j) ? f : null);
        this.o[this.j] = g;
        this.j = (this.j + 1) % 1E3;
        f = 2 === a || 3 === a;
        var h = b.getMessageArgs();
        e = b.getMessageId();
        var k = CK[e] || DK[e];
        e = void 0;
        if (k) {
            e = k(h);
            if (d) throw new Fm(e);
            d = this.m < _.cg(uB) && f && _.t.console;
            if (this.A === top && d || _.A(_.t.navigator.userAgent, "includes").call(_.t.navigator.userAgent, "Lighthouse")) {
                d = "[GPT] " + e;
                var l, m, n, p;
                2 === a ? null == (m = (l = _.t.console).warn) || m.call(l, d) : null == (p = (n = _.t.console).error) || p.call(n, d);
                this.m++
            }
        }
        a: if (m = e, l = c, l = void 0 === l ? null : l, this.context.Nl) {
            switch (a) {
                case 2:
                    n = 1;
                    break;
                case 3:
                    n = 2;
                    break;
                default:
                    break a
            }
            var r, w, u;
            a = this.context.Qa;
            c = a.Ml;
            p = new RA;
            p = _.qh(p, 1, this.context.pvsid);
            d = _.Uf();
            p = _.ie(p, 2, d, Lc);
            p = _.rh(p, 3, this.context.Lf);
            p = _.rh(p, 4, this.context.eb);
            p = _.qh(p, 5, this.context.vl);
            n = _.I(p, 6, n);
            m = _.rh(n, 7, m);
            n = b.getMessageId();
            m = _.I(m, 8, n);
            b = b.getMessageArgs();
            b = _.Uh(m, 9, b);
            m = nh(null != (u = null == (r = l) ? void 0 : r.getAdUnitPath()) ? u : "");
            r = _.rh(b, 10, m);
            u = null == (w = l) ? void 0 : w.getAdUnitPath();
            w = _.rh(r, 11, u);
            c.call(a, w)
        }
        return g
    };
    EK.prototype.info = function(a, b) {
        return this.log(1, a, void 0 === b ? null : b)
    };
    var Q = function(a, b, c) {
        return a.log(2, b, c, !1)
    };
    EK.prototype.error = function(a, b, c) {
        return this.log(3, a, b, void 0 === c ? !1 : c)
    };
    var FK = function() {
            var a = {
                    W: Pi().j,
                    Mi: new Date(Date.now()),
                    oh: window.location.href
                },
                b = this;
            a = void 0 === a ? {} : a;
            var c = void 0 === a.W ? Pi().j : a.W,
                d = void 0 === a.Mi ? new Date(Date.now()) : a.Mi,
                e = void 0 === a.oh ? window.location.href : a.oh;
            this.j = "";
            this.A = this.o = null;
            this.J = this.l = !1;
            this.m = function() {
                return !1
            };
            a = {};
            var f = {},
                g = {};
            this.H = (g[3] = (a[72] = function(h, k) {
                var l = b.o;
                k = Number(k);
                h = null !== l ? _.$f("w5uHecUBa2S:" + Number(h) + ":" + l) % k === Math.floor(d.valueOf() / 864E5) % k : void 0;
                return h
            }, a[13] = function() {
                return _.Xa.apply(0, arguments).some(function(h) {
                    return _.A(b.j, "startsWith").call(b.j, h)
                })
            }, a[12] = function() {
                return !!_.N(c, 6)
            }, a[15] = function(h) {
                return b.m(h)
            }, a[66] = function() {
                try {
                    return !!HTMLScriptElement.supports("webbundle")
                } catch (h) {
                    return !1
                }
            }, a[67] = function() {
                return b.l
            }, a[68] = function() {
                return b.J
            }, a[74] = function() {
                return _.A(_.Xa.apply(0, arguments), "includes").call(_.Xa.apply(0, arguments), String(_.$f(e)))
            }, a), g[4] = (f[14] = function() {
                var h = Number(b.A || void 0);
                isNaN(h) ? h = void 0 : (h = new Date(1E3 * h), h = 1E4 * h.getFullYear() + 100 * (h.getMonth() + 1) + h.getDate());
                return h
            }, f), g[5] = {}, g)
        },
        GK = function(a, b) {
            if (b && !a.o) {
                b = b.split(":");
                a.o = _.A(b, "find").call(b, function(d) {
                    return 0 === d.indexOf("ID=")
                }) || null;
                var c;
                a.A = (null == (c = _.A(b, "find").call(b, function(d) {
                    return 0 === d.indexOf("T=")
                })) ? void 0 : c.substring(2)) || null
            }
        };
    var pt = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 863);
        this.v = c;
        this.gd = Number(b);
        this.l = W(this, d);
        this.G = W(this, e);
        this.K = W(this, f);
        this.C = W(this, g)
    };
    _.T(pt, Z);
    pt.prototype.j = function() {
        var a = this.K.value,
            b = this.l.value,
            c = this.C.value,
            d = this.G.value,
            e = this.v;
        var f = rn(e);
        var g = b.getBoundingClientRect();
        e = _.nk(e) ? ni(b, e) : {
            x: 0,
            y: 0
        };
        b = e.x;
        e = e.y;
        g = new _.Mz(e, b + g.right, e + g.bottom, b);
        b = new uF;
        b = _.So(b, 1, g.top);
        b = _.So(b, 3, g.bottom);
        b = _.So(b, 2, g.left);
        g = _.So(b, 4, g.right);
        b = new vF;
        b = _.Ai(b, 1, _.Oc(this.gd));
        d = Fj(b, 2, !d);
        d = _.th(d, 3, g);
        c = _.So(d, 4, c);
        f = _.So(c, 5, f);
        f = {
            type: "asmres",
            payload: Ak(f)
        };
        a.ports[0].postMessage(f)
    };
    var aq = function(a, b, c, d) {
        Z.call(this, a, 1061);
        var e = this;
        this.output = V(this);
        this.output.Ja(new _.v.Promise(function(f) {
            var g = b.listen(c, function(h) {
                h = d(h);
                null !== h && (g(), f(h))
            });
            _.tn(e, g)
        }))
    };
    _.T(aq, Z);
    aq.prototype.j = function() {};
    var Rp = function(a, b, c, d) {
        d = void 0 === d ? function() {
            return !0
        } : d;
        Z.call(this, a, 1061);
        var e = this;
        this.output = hG(this);
        ZF(this.output, new _.v.Promise(function(f) {
            var g = b.listen(c, function(h) {
                d(h) && (g(), f())
            });
            _.tn(e, g)
        }))
    };
    _.T(Rp, Z);
    Rp.prototype.j = function() {};
    var nt = function(a, b, c, d) {
        aq.call(this, a, b, Sp, function(e) {
            e = e.detail;
            var f;
            return "asmreq" === (null == (f = e.data) ? void 0 : f.type) && Kr(tF(e.data.payload), 1) === Number(c) ? e : null
        });
        this.v = d;
        this.l = V(this)
    };
    _.T(nt, aq);
    nt.prototype.j = function() {
        this.l.F(rn(this.v))
    };
    var HK = /(<head(\s+[^>]*)?>)/i,
        Ss = function(a, b, c, d, e) {
            Z.call(this, a, 665);
            this.output = V(this);
            this.l = W(this, b);
            this.v = Y(this, c);
            this.C = W(this, d);
            this.G = W(this, e)
        };
    _.T(Ss, Z);
    Ss.prototype.j = function() {
        var a;
        0 !== this.l.value.kind || null == (a = this.v.value) || !_.R(a, 1) || this.G.value ? this.output.F(this.l.value) : (a = this.l.value.wb, La("Firefox") || La("FxiOS") || (a = a.replace(HK, "$1<meta http-equiv=Content-Security-Policy content=\"script-src https://cdn.ampproject.org/;object-src 'none';child-src blob:;frame-src 'none'\">")), this.C.value && (a = a.replace(HK, '$1<meta name="referrer" content="origin">')), this.output.F({
            kind: 0,
            wb: a
        }))
    };
    var IK = function(a, b, c, d) {
        Z.call(this, a, 1124);
        this.Kd = hG(this);
        this.v = W(this, b);
        this.l = W(this, c);
        jG(this, d)
    };
    _.T(IK, Z);
    IK.prototype.j = function() {
        _.Tz(this.l.value, {
            "min-width": "100%",
            visibility: "hidden"
        });
        _.Tz(this.v.value, "min-width", "100%");
        this.Kd.notify()
    };
    var JK = function(a, b, c, d, e) {
        Z.call(this, a, 1125);
        this.v = W(this, b);
        this.l = W(this, c);
        jG(this, d);
        jG(this, e)
    };
    _.T(JK, Z);
    JK.prototype.j = function() {
        var a = this.v.value,
            b = a.contentDocument;
        b && (a.setAttribute("height", String(b.body.offsetHeight)), a.setAttribute("width", String(b.body.offsetWidth)), _.Tz(this.l.value, "visibility", "visible"))
    };
    var qt = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 718);
        this.slotId = b;
        this.Rg = e;
        this.v = f;
        this.C = g;
        this.output = V(this);
        this.l = new Rp(this.context, this.slotId, Hs);
        this.K = Y(this, c);
        this.G = Y(this, d);
        this.O = W(this, h)
    };
    _.T(qt, Z);
    qt.prototype.j = function() {
        var a = !this.O.value;
        if (null == this.G.value || "height" !== this.K.value || a) this.l.wa(), this.output.F(!1);
        else {
            a = new Jj;
            _.S(this, a);
            var b = new IK(this.context, this.v, this.C, this.Rg);
            O(a, b);
            O(a, this.l);
            O(a, new JK(this.context, this.v, this.C, this.l.output, b.Kd));
            Sj(a);
            this.output.F(!0)
        }
    };
    var En = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        Z.call(this, a, 699);
        this.V = b;
        this.slotId = c;
        this.l = d;
        this.ed = e;
        this.O = r;
        this.K = Y(this, f);
        this.ba = W(this, g);
        this.C = W(this, h);
        this.U = W(this, k);
        this.v = Y(this, l);
        this.da = W(this, m);
        this.G = W(this, n);
        p && jG(this, p)
    };
    _.T(En, Z);
    En.prototype.j = function() {
        var a = this.ba.value,
            b = this.C.value;
        b.style.width = "";
        b.style.height = "";
        if ("height" !== this.K.value) {
            var c, d = null != (c = this.v.value) ? c : 0;
            c = this.U.value;
            var e = this.da.value,
                f = this.G.value,
                g = !1;
            switch (d) {
                case 1:
                case 2:
                case 4:
                case 5:
                    var h = this.context;
                    g = this.V;
                    var k = this.slotId,
                        l = this.l,
                        m = this.ed,
                        n, p = a.parentElement ? null == (n = Hi(a.parentElement, window)) ? void 0 : n.width : void 0;
                    n = c.width;
                    var r = c.height,
                        w = 0;
                    var u = 0;
                    var x = gi(l);
                    x = _.z(x);
                    for (var y = x.next(); !y.done; y = x.next()) {
                        var C = y.value;
                        Array.isArray(C) && (y = C[0], C = C[1], w < y && (w = y), u < C && (u = C))
                    }
                    u = [w, u];
                    w = u[0] < n;
                    r = u[1] < r;
                    if (w || r) {
                        u = n + "px";
                        x = {
                            "max-height": "none",
                            "max-width": u,
                            padding: "0px",
                            width: u
                        };
                        r && (x.height = "auto");
                        Ti(b, a, x);
                        b = {};
                        if ((_.G = [2, 5], _.A(_.G, "includes")).call(_.G, d) || w && n > Qi(e.width)) b.width = u, b["max-width"] = u;
                        r && (b.height = "auto", b["max-height"] = "none");
                        c: {
                            for (D in b)
                                if (Object.prototype.hasOwnProperty.call(b, D)) {
                                    var D = !1;
                                    break c
                                }
                            D = !0
                        }
                        D ? b = !1 : (b["padding-" + ("ltr" === e.direction ? "left" : "right")] = "0px", _.Si(a, b), b = !0)
                    } else b = !1;
                    b: switch (u = c.width, D = g.defaultView || g.parentWindow || _.t, d) {
                        case 2:
                        case 5:
                            a = Ui(a, D, u, e, m);
                            break b;
                        case 1:
                        case 4:
                            if (e = a.parentElement)
                                if (m = yi(e)) {
                                    y = m.width;
                                    m = Fi(k, D.document);
                                    n = Hi(m, D);
                                    r = n.position;
                                    C = Qi(n.width) || 0;
                                    w = Hi(e, D);
                                    x = "rtl" === w.direction ? "Right" : "Left";
                                    m = x.toLowerCase();
                                    D = "absolute" === r ? 0 : Qi(w["padding" + x]);
                                    w = Qi(w["border" + x + "Width"]);
                                    u = Math.max(Math.round((y - Math.max(C, u)) / 2), 0);
                                    y = {};
                                    C = 0;
                                    var E = Ln(n);
                                    E && (C = E[4] * ("Right" === x ? -1 : 1), x = E[3] || 1, 1 !== (E[0] || 1) || 1 !== x) && (E[0] = 1, E[3] = 1, y.transform = "matrix(" + E.join(",") + ")");
                                    x = 0;
                                    switch (r) {
                                        case "fixed":
                                            var J, M = null != (J = Number(Ii(n.getPropertyValue(m)))) ? J : 0,
                                                K;
                                            J = null != (K = e.getBoundingClientRect().left) ? K : 0;
                                            x = M - J;
                                            break;
                                        case "relative":
                                            x = null != (M = Number(Ii(n.getPropertyValue(m)))) ? M : 0;
                                            break;
                                        case "absolute":
                                            y[m] = "0"
                                    }
                                    y["margin-" + m] = u - D - w - x - C + "px";
                                    _.Si(a, y);
                                    a = !0
                                } else a = !1;
                            else a = !1;
                            break b;
                        default:
                            a = !1
                    }
                    b || a ? (_.A(cH, "includes").call(cH, d) && Wi(h, g, k, l, d, c.width, c.height, p, "gpt_slotexp", f), g = !0) : g = !1;
                    break;
                case 3:
                    d = this.context, K = this.V, g = this.slotId, k = this.l, p = this.ed, l = a.parentElement ? null == (h = Hi(a.parentElement, window)) ? void 0 : h.width : void 0, h = c.width, J = c.height, M = Qi(e.height) || 0, J >= M || "none" === e.display || "hidden" === e.visibility || !p || -12245933 === p.width || a.getBoundingClientRect().bottom <= p.height ? g = !1 : (p = {
                        height: J + "px"
                    }, Ti(b, a, p), _.Si(a, p), Wi(d, K, g, k, 3, h, J, l, "gpt_slotred", f), g = !0)
            }!g && _.H(bB) && Wi(this.context, this.V, this.slotId, this.l, 0, c.width, c.height, void 0, "gpt_pgbrk", f)
        }
        this.O.notify()
    };
    var zn = function(a, b, c, d, e, f) {
        Z.call(this, a, 1114);
        this.K = b;
        this.ha = c;
        this.C = V(this);
        this.v = V(this);
        this.G = W(this, d);
        this.l = W(this, e);
        this.O = W(this, f)
    };
    _.T(zn, Z);
    zn.prototype.j = function() {
        if (this.K) {
            var a = this.K.split(":");
            if (2 !== a.length || "#flexibleAdSlotDebugSize" !== a[0]) KK(this);
            else {
                var b = a[1];
                a = LK(this, b);
                var c;
                (c = /(?:.*)height=(ratio|[0-9]+)(?:;.*|$)/.exec(b)) ? (c = c[1], "ratio" === c ? c = a && this.G.value && this.l.value ? Math.floor(this.l.value / this.G.value * a) : null : (c = Number(c), c = 0 <= c ? c : null)) : c = null;
                b = (b = /(?:.*)ius=(.+,?)+(?:;.*|$)/.exec(b)) ? b[1].split(",") : [];
                a || c ? (this.C.F(new _.xi(null != a ? a : this.G.value, null != c ? c : this.l.value)), this.v.F(b)) : KK(this)
            }
        } else KK(this)
    };
    var LK = function(a, b) {
            b = /(?:.*)width=(parent|viewport|[0-9]+)(?:;.*|$)/.exec(b);
            if (!b) return null;
            b = b[1];
            if ("viewport" === b) return a.ha;
            if ("parent" === b) {
                var c, d, e;
                return (b = null != (e = null == (d = yi(null == (c = a.O.value) ? void 0 : c.parentElement)) ? void 0 : d.width) ? e : null) ? Math.min(b, a.ha) : null
            }
            a = Number(b);
            return 0 <= a ? a : null
        },
        KK = function(a) {
            a.C.aa();
            a.v.F([])
        };
    var An = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        Z.call(this, a, 681);
        this.adUnitPath = b;
        this.K = c;
        this.Kc = d;
        this.U = n;
        this.ba = p;
        this.O = r;
        this.fa = w;
        this.C = Y(this, e);
        this.pa = Y(this, f);
        this.ma = Y(this, g);
        this.da = Y(this, h);
        this.l = W(this, k);
        this.v = W(this, l);
        this.G = W(this, m)
    };
    _.T(An, Z);
    An.prototype.j = function() {
        var a = MK(this),
            b = this.da.value,
            c;
        if (c = !this.Kc && a && b) this.l.value.length ? (c = this.adUnitPath.split("/"), c = _.A(this.l.value, "includes").call(this.l.value, c[c.length - 1])) : c = !0;
        if (c) {
            c = this.G.value;
            var d, e, f = null != (e = null == (d = yi(c.parentElement)) ? void 0 : d.width) ? e : 0;
            d = b.width;
            b = b.height;
            NK(this, !0, d, b, {
                kind: 0,
                wb: '<html><body style="height:' + (b - 2 + "px;width:" + (d - 2 + 'px;background-color:#ddd;color:#000;border:1px solid #f00;margin:0;"><p>Requested size:')) + (a.width + "x" + a.height + "</p><p>Rendered size:") + (d + "x" + b + "</p></body></html>")
            }, d <= f ? 1 : 2, c)
        } else if (a = this.pa.value, b = this.ma.value, this.Kc) NK(this, !1, null != a ? a : 0, null != b ? b : 0, this.v.value);
        else {
            if (null == a) throw new Fm("Missing 'width'.");
            if (null == b) throw new Fm("Missing 'height'.");
            NK(this, !1, a, b, this.v.value)
        }
    };
    var MK = function(a) {
            a = gi(a.K)[0];
            return Array.isArray(a) && a.every(function(b) {
                return "number" === typeof b
            }) ? new _.xi(a[0], a[1]) : null
        },
        NK = function(a, b, c, d, e, f, g) {
            f = void 0 === f ? a.C.value : f;
            a.fa.F(b);
            a.ba.F(new _.xi(c, d));
            a.U.F(e);
            a.O.Ca(f);
            g && _.Tz(g, "opacity", .5)
        };
    var Dn = function(a, b, c) {
        Z.call(this, a, 698);
        this.B = b;
        this.output = V(this);
        this.l = W(this, c)
    };
    _.T(Dn, Z);
    Dn.prototype.j = function() {
        this.output.Ca(Hi(this.l.value, this.B))
    };
    var OK = null;
    var PK = function(a, b, c, d, e) {
        Z.call(this, a, 937, _.cg(MB));
        this.hb = b;
        this.l = V(this);
        this.v = V(this);
        this.C = V(this);
        this.Yb = c;
        this.Wb = d;
        this.Fc = e
    };
    _.T(PK, Z);
    PK.prototype.j = function() {
        var a = {},
            b;
        if (null == (b = _.Zh(this.hb, Qx, 2)) ? 0 : _.N(b, 2)) a["*"] = {
            Ne: !0
        };
        b = new _.v.Set;
        for (var c = _.z(_.bi(this.hb, Px, 1)), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            for (var e = _.z([_.R(d, 2), _.R(d, 1)].filter(function(p) {
                    return !!p
                })), f = e.next(); !f.done; f = e.next()) a[f.value] = {
                Ne: _.N(d, 3)
            };
            d = _.z(Xd(d, 4, Mc));
            for (e = d.next(); !e.done; e = d.next()) b.add(e.value)
        }
        this.Yb.F(a);
        this.l.F([].concat(_.lh(b)));
        var g, h;
        a = null == (g = _.Zh(this.hb, Qx, 2)) ? void 0 : null == (h = _.Zh(g, Kx, 1)) ? void 0 : _.bi(h, Jx, 1);
        this.v.Ca((null == a ? 0 : a.length) ? a : null);
        var k;
        this.Wb.F(!(null == (k = _.Zh(this.hb, Qx, 2)) || !_.N(k, 4)));
        var l;
        this.Fc.F(!(null == (l = _.Zh(this.hb, Qx, 2)) || !_.N(l, 5)));
        var m, n;
        g = null == (m = _.Zh(this.hb, Qx, 2)) ? void 0 : null == (n = _.Zh(m, Kx, 3)) ? void 0 : _.bi(n, Jx, 1);
        this.C.Ca((null == g ? 0 : g.length) ? g : null)
    };
    PK.prototype.H = function(a) {
        this.m(a)
    };
    PK.prototype.m = function() {
        this.Yb.F({});
        this.l.F([]);
        this.v.aa();
        this.Wb.F(!1);
        this.Fc.F(!1);
        this.C.aa()
    };
    var QK = function(a, b, c, d) {
        Z.call(this, a, 980);
        this.ab = b;
        this.output = new Cn;
        this.l = W(this, c);
        this.v = W(this, d)
    };
    _.T(QK, Z);
    QK.prototype.j = function() {
        (_.G = _.A(Object, "entries").call(Object, this.l.value), _.A(_.G, "find")).call(_.G, function(c) {
            var d = _.z(c);
            c = d.next().value;
            d = d.next().value;
            return "*" !== c && (null == d ? void 0 : d.Ne)
        }) && (this.ab.J = !0);
        Rl(25, this.context);
        for (var a = _.z(this.v.value), b = a.next(); !b.done; b = a.next()) Tf(b.value);
        this.output.notify()
    };
    var RK = function(a, b, c, d) {
        Z.call(this, a, 931);
        this.l = Y(this, b);
        this.yc = c;
        this.Xb = d
    };
    _.T(RK, Z);
    RK.prototype.j = function() {
        var a = this.l.value,
            b = new _.v.Map;
        this.yc.F(new _.v.Map);
        if (a) {
            var c;
            a = _.z(null != (c = this.l.value) ? c : []);
            for (c = a.next(); !c.done; c = a.next()) {
                var d = c.value;
                c = _.bi(d, Ix, 1);
                c = 1 === _.Hk(c[0], 1, 0) ? dx(c[0]) : ex(c[0], cx);
                d = _.sf(d, 2);
                var e = void 0;
                b.set(c, Math.min(null != (e = b.get(c)) ? e : Number.MAX_VALUE, d))
            }
        }
        this.Xb.F(b)
    };
    RK.prototype.m = function() {
        this.yc.F(new _.v.Map);
        this.Xb.F(new _.v.Map)
    };
    var SK = function(a, b, c) {
        Z.call(this, a, 981);
        this.v = V(this);
        this.C = Y(this, b);
        this.l = c
    };
    _.T(SK, Z);
    SK.prototype.j = function() {
        var a = new _.v.Map,
            b, c = _.z(null != (b = this.C.value) ? b : []);
        for (b = c.next(); !b.done; b = c.next()) {
            b = b.value;
            var d = _.bi(b, Ix, 1);
            d = 1 === _.Hk(d[0], 1, 0) ? dx(d[0]) : ex(d[0], cx);
            a.set(d, _.sf(b, 2))
        }
        this.v.F(a);
        this.l.F(new Bx)
    };
    SK.prototype.m = function() {
        this.v.F(new _.v.Map);
        var a = this.l,
            b = a.F;
        var c = new Bx;
        c = _.ko(c, 1, 2);
        b.call(a, c)
    };
    var TK = function(a, b, c, d, e, f) {
        Z.call(this, a, 976);
        this.nextFunction = d;
        this.l = e;
        this.requestBidsConfig = f;
        jG(this, b);
        jG(this, c)
    };
    _.T(TK, Z);
    TK.prototype.j = function() {
        var a;
        null == (a = this.nextFunction) || a.apply(this.l, [this.requestBidsConfig])
    };
    var UK = function(a, b, c, d, e, f) {
        Z.call(this, a, 975);
        this.v = b;
        this.l = c;
        this.C = d;
        this.pbjs = e;
        this.requestBidsConfig = f;
        this.output = new Cn
    };
    _.T(UK, Z);
    UK.prototype.j = function() {
        Wn(this.pbjs, this.v, this.l, this.C, this.requestBidsConfig);
        this.output.notify()
    };
    UK.prototype.m = function() {
        this.output.notify()
    };
    var VK = function(a, b, c, d, e, f) {
        Z.call(this, a, 1100);
        this.pbjs = b;
        this.l = c;
        this.v = d;
        this.C = e;
        this.requestBidsConfig = f;
        this.output = new Cn
    };
    _.T(VK, Z);
    VK.prototype.j = function() {
        var a, b, c = null != (b = null == (a = this.l) ? void 0 : a.get("*")) ? b : _.cg(fB);
        if (c) this.Vb(c);
        else {
            var d, e, f, g;
            a = null != (g = null != (f = null == (d = this.requestBidsConfig) ? void 0 : d.adUnits) ? f : null == (e = this.pbjs) ? void 0 : e.adUnits) ? g : [];
            d = _.z(a);
            for (e = d.next(); !e.done; e = d.next())
                if (e = e.value.code) c = b = a = g = void 0, f = null != (g = null != (a = null == (c = this.l) ? void 0 : c.get(_.H(no) ? sg(e) : e)) ? a : null == (b = this.l) ? void 0 : b.get(_.$f(e))) ? g : 0, this.Vb(f)
        }
        this.output.notify()
    };
    VK.prototype.Vb = function(a) {
        var b;
        null != (b = this.v) && Fj(b, 2, this.C);
        if (a) {
            var c;
            null == (c = this.v) || _.ko(c, 1, 1);
            if (!this.C) {
                this.requestBidsConfig.timeout = a;
                var d, e, f;
                b = null != (f = null == (e = (d = this.pbjs).getConfig) ? void 0 : e.call(d).s2sConfig) ? f : [];
                if (Array.isArray(b))
                    for (d = _.z(b), e = d.next(); !e.done; e = d.next()) e.value.timeout = a;
                else b.timeout = a;
                var g, h;
                null == (h = (g = this.pbjs).setConfig) || h.call(g, {
                    bidderTimeout: a
                })
            }
        }
    };
    VK.prototype.m = function() {
        this.output.notify()
    };
    var WK = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.j = a;
        this.A = b;
        this.m = c;
        this.l = d;
        this.I = e;
        this.H = f;
        this.M = g;
        this.pbjs = h
    };
    _.T(WK, _.U);
    WK.prototype.push = function(a) {
        var b = a.context,
            c = a.nextFunction;
        a = a.requestBidsConfig;
        if (this.pbjs) {
            var d = new Jj;
            _.S(this, d);
            var e = new VK(this.j, this.pbjs, this.I, this.H, this.M, a),
                f = new UK(this.j, this.A, this.m, this.l, this.pbjs, a);
            O(d, e);
            O(d, f);
            O(d, new TK(this.j, f.output, e.output, c, b, a));
            Sj(d)
        }
    };
    var Yn = function(a, b) {
        this.push = L(a, 932, function(c) {
            b.push(c)
        })
    };
    var XK = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 951);
        this.B = window;
        this.G = W(this, b);
        this.v = Y(this, d);
        this.C = W(this, e);
        this.O = W(this, f);
        this.l = Y(this, g);
        this.U = Y(this, h);
        this.K = W(this, k);
        jG(this, c);
        this.af = null != l ? l : V(this);
        this.bf = null != m ? m : V(this)
    };
    _.T(XK, Z);
    XK.prototype.j = function() {
        var a = !!Hm().pbjs_hooks;
        this.bf.F(a);
        this.af.Ca(a ? null : _.Vg());
        var b, c = null == (b = this.v.value) ? void 0 : b.size,
            d;
        b = (null == (d = this.l.value) ? void 0 : d.size) || _.cg(fB);
        d = this.G.value;
        var e, f = null != (e = Hm().pbjs_hooks) ? e : [];
        e = new WK(this.context, this.v.value, this.C.value, this.O.value, this.l.value, this.U.value, this.K.value, d);
        _.S(this, e);
        f = _.z(f);
        for (var g = f.next(); !g.done; g = f.next()) e.push(g.value);
        if (c || b || a) Hm().pbjs_hooks = Zn(this.context, e);
        !c && !b || a || Xn(d, this.B)
    };
    var YK = function(a, b, c) {
        Z.call(this, a, 966);
        this.B = b;
        this.Rb = c
    };
    _.T(YK, Z);
    YK.prototype.j = function() {
        var a = this,
            b = rg(this.B);
        if (b) this.Rb.F(b);
        else if (b = Object.getOwnPropertyDescriptor(this.B, "_pbjsGlobals"), !b || b.configurable) {
            var c = null;
            Object.defineProperty(this.B, "_pbjsGlobals", {
                set: function(d) {
                    c = d;
                    (d = rg(a.B)) && a.Rb.F(d)
                },
                get: function() {
                    return c
                }
            })
        }
    };
    YK.prototype.m = function() {};
    var ZK = function(a, b, c, d, e) {
        Z.call(this, a, 1146, _.cg(MB));
        this.ab = b;
        this.B = d;
        this.l = e;
        this.v = iG(this, c)
    };
    _.T(ZK, Z);
    ZK.prototype.j = function() {
        var a = this.v.value,
            b = new Jj;
        _.S(this, b);
        var c = new YK(this.context, this.B, this.l.Rb);
        O(b, c);
        if (a) {
            a = new PK(this.context, a, this.l.Yb, this.l.Wb, this.l.Fc);
            O(b, a);
            var d = new QK(this.context, this.ab, a.Yb, a.l);
            O(b, d);
            var e = new RK(this.context, a.v, this.l.yc, this.l.Xb);
            O(b, e);
            var f = new SK(this.context, a.C, this.l.zf);
            O(b, f);
            c = new XK(this.context, c.Rb, d.output, e.Xb, this.l.Wb, e.yc, f.v, f.l, a.Fc, this.l.af, this.l.bf);
            O(b, c)
        } else $K(this);
        Sj(b)
    };
    var $K = function(a) {
        a.l.Yb.F({});
        a.l.Xb.F(new _.v.Map);
        a.l.Wb.F(!1);
        a.l.yc.F(new _.v.Map);
        a.l.af.aa();
        a.l.bf.F(!1);
        a.l.zf.F(new Bx);
        a.l.Fc.F(!1)
    };
    ZK.prototype.H = function(a) {
        this.m(a)
    };
    ZK.prototype.m = function() {
        $K(this)
    };
    var aL = /^v?\d{1,3}(\.\d{1,3}){0,2}(-pre)?$/,
        bL = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 920);
            this.T = b;
            this.R = c;
            this.pbjs = f;
            this.C = g;
            this.G = V(this);
            this.v = V(this);
            this.K = [];
            this.l = new _.v.Map;
            this.ba = W(this, d);
            this.U = Y(this, e.Xb);
            this.O = W(this, e.Wb);
            this.fa = W(this, e.yc);
            this.da = Y(this, e.zf)
        };
    _.T(bL, Z);
    bL.prototype.j = function() {
        var a = cL(this, this.pbjs);
        a ? (this.C.Ca(a), this.G.F(this.l), this.v.F(this.K)) : dL(this)
    };
    bL.prototype.H = function(a) {
        this.m(a)
    };
    bL.prototype.m = function(a) {
        this.T.error(AJ(a.message));
        dL(this)
    };
    var dL = function(a) {
            a.C.aa();
            a.G.aa();
            a.v.aa()
        },
        cL = function(a, b) {
            var c = (0, b.getEvents)(),
                d = c.filter(function(g) {
                    var h = g.args;
                    return "auctionEnd" === g.eventType && h.auctionId
                }),
                e = !1,
                f = a.ba.value.map(function(g) {
                    var h = new Gx,
                        k = function(pa) {
                            return pa === g.getDomId() || pa === g.getAdUnitPath()
                        },
                        l, m = null != (l = eL.get(g)) ? l : 0,
                        n;
                    l = null != (n = d.filter(function(pa) {
                        var za, ya, Qa;
                        return Number(null == (za = pa.args) ? void 0 : za.timestamp) > m && (null == (ya = pa.args) ? void 0 : null == (Qa = ya.adUnitCodes) ? void 0 : _.A(Qa, "find").call(Qa, k))
                    })) ? n : [];
                    if (!l.length) return a.K.push(g), [g, h];
                    var p;
                    n = null == (p = l.reduce(function(pa, za) {
                        return Number(za.args.timestamp) > Number(pa.args.timestamp) ? za : pa
                    })) ? void 0 : p.args;
                    if (!n) return [g, h];
                    var r = void 0 === n.bidderRequests ? [] : n.bidderRequests;
                    p = void 0 === n.bidsReceived ? [] : n.bidsReceived;
                    var w = n.auctionId;
                    n = n.timestamp;
                    if (!w || null == n || !r.length) return [g, h];
                    eL.has(g) || _.tn(g, function() {
                        return eL.delete(g)
                    });
                    eL.set(g, n);
                    n = Hx(h);
                    Math.random() < _.cg(eB) && b.version && aL.test(b.version) && Vn(n, 6, b.version);
                    var u;
                    Ex(n, null == (u = a.da) ? void 0 : u.value);
                    u = Gi(function() {
                        return zo(c, w)
                    });
                    l = bl(a.R[g.getDomId()]);
                    r = _.z(r);
                    for (var x = r.next(), y = {}; !x.done; y = {
                            bidderCode: y.bidderCode,
                            Lg: y.Lg
                        }, x = r.next()) {
                        var C = x.value;
                        y.bidderCode = C.bidderCode;
                        var D = C.bids;
                        x = C.timeout;
                        y.Lg = C.src;
                        C = C.auctionStart;
                        D = _.z(D);
                        for (var E = D.next(), J = {}; !E.done; J = {
                                kd: J.kd
                            }, E = D.next()) {
                            var M = E.value;
                            J.kd = M.bidId;
                            var K = M.transactionId;
                            E = M.adUnitCode;
                            var X = M.getFloor;
                            M = M.mediaTypes;
                            if (J.kd && k(E)) {
                                e = !0;
                                lo(n, g, E);
                                K && (null != _.Aj(n, 4) || Vn(n, 4, K), a.l.has(K) || a.l.set(K, C));
                                null == Np(n, 8) && _.A(Number, "isFinite").call(Number, x) && _.So(n, 8, x);
                                var ba = _.A(p, "find").call(p, function(pa) {
                                    return function(za) {
                                        return za.requestId === pa.kd
                                    }
                                }(J));
                                K = ao(n, function(pa) {
                                    return function() {
                                        var za = eo(new fo, pa.bidderCode);
                                        go(pa.bidderCode, b, za);
                                        switch (pa.Lg) {
                                            case "client":
                                                _.ko(za, 7, 1);
                                                break;
                                            case "s2s":
                                                _.ko(za, 7, 2)
                                        }
                                        return za
                                    }
                                }(y)());
                                oo(n, K, E, a.U.value, a.O.value, a.fa.value, X);
                                ba ? (co(K, 1), "number" === typeof ba.timeToRespond && ho(K, ba.timeToRespond), E = $n(ba, l, M), bo(K, E)) : (E = u().get(J.kd)) && !E.Rh ? ho(co(K, 2), Math.round(E.latency)) : (E = co(K, 3), _.A(Number, "isFinite").call(Number, x) && ho(E, x))
                            }
                        }
                    }
                    var la;
                    (null == (la = b.getConfig) ? 0 : la.call(b).useBidCache) && io(n, g, w, l, b);
                    return [g, h]
                });
            return e ? new _.v.Map(f) : null
        },
        eL = new _.v.Map;
    var fL = function(a, b, c, d) {
        Z.call(this, a, 1019);
        this.R = c;
        this.pbjs = d;
        this.l = Y(this, b)
    };
    _.T(fL, Z);
    fL.prototype.j = function() {
        gL(this)
    };
    var gL = function(a) {
        if (!(Math.random() >= _.cg(dB))) {
            var b = (a.l.value || []).filter(function(k) {
                return bl(a.R[k.getDomId()]).some(function(l) {
                    return "hb_pb" === _.Aj(l, 1)
                })
            });
            if (b.length) {
                var c, d, e, f, g, h = (null == (c = a.pbjs) ? 0 : null == (d = c.adUnits) ? 0 : d.length) ? [].concat(_.lh(new _.v.Set(null == (e = a.pbjs) ? void 0 : e.adUnits.map(function(k) {
                    return k.code
                })))) : _.A(Object, "keys").call(Object, (null == (f = a.pbjs) ? void 0 : null == (g = f.getAdserverTargeting) ? void 0 : g.call(f)) || {});
                c = new en("haux");
                fj(c, "ius", b.map(function(k) {
                    return k.getAdUnitPath()
                }).join("~"));
                fj(c, "dids", b.map(function(k) {
                    return k.getDomId()
                }).join("~"));
                fj(c, "paucs", h.join("~"));
                ej(c, a.context);
                gn(c)
            }
        }
    };
    var Eo = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1153);
        this.T = b;
        this.R = c;
        this.networkCode = d;
        this.G = e;
        this.de = f;
        this.l = h;
        this.K = W(this, f.Yb);
        this.v = new YF(f.Rb);
        g && (this.C = Y(this, g))
    };
    _.T(Eo, Z);
    Eo.prototype.j = function() {
        var a, b = null == (a = this.v) ? void 0 : a.value;
        if (a = hL(this)) null != b && b.libLoaded ? "function" !== typeof b.getEvents ? (this.T.error(zJ()), a = !1) : a = !0 : a = !1;
        if (a) {
            a = new Jj;
            var c = new bL(this.context, this.T, this.R, this.G, this.de, b, this.l.Kg);
            O(a, c);
            O(a, new fL(this.context, c.v, this.R, b));
            Sj(a)
        } else this.l.Kg.aa()
    };
    var hL = function(a) {
        var b;
        if (null == (b = a.C) ? 0 : b.value) return !0;
        var c = a.K.value;
        if (!c) return !1;
        var d;
        return !(null == (d = c["*"]) || !d.Ne) || a.networkCode.split(",").some(function(e) {
            var f;
            return !(null == (f = c[e]) || !f.Ne)
        })
    };
    var iL = function(a, b, c, d, e) {
        Z.call(this, a, 982);
        this.C = d;
        this.Ze = e;
        this.v = W(this, b);
        this.l = W(this, c)
    };
    _.T(iL, Z);
    iL.prototype.j = function() {
        for (var a = this, b = _.z(["bidWon", "staleRender", "adRenderFailed", "adRenderSucceeded"]), c = b.next(), d = {}; !c.done; d = {
                qd: d.qd,
                Te: d.Te
            }, c = b.next()) d.qd = c.value, d.Te = function(e) {
            return function(f) {
                if (a.C === f.adId) {
                    var g = new en("hbm_brt");
                    ej(g, a.context);
                    fj(g, "et", e.qd);
                    fj(g, "sf", a.v.value);
                    fj(g, "qqid", a.l.value);
                    var h, k, l;
                    fj(g, "bc", String(null != (l = null != (k = f.bidderCode) ? k : null == (h = f.bid) ? void 0 : h.bidder) ? l : ""));
                    gn(g)
                }
            }
        }(d), (0, this.Ze.onEvent)(d.qd, d.Te), _.tn(this, function(e) {
            return function() {
                return void Nh(a.context, a.id, function() {
                    var f, g;
                    return void(null == (g = (f = a.Ze).offEvent) ? void 0 : g.call(f, e.qd, e.Te))
                }, !0)
            }
        }(d))
    };
    iL.prototype.m = function() {};
    var Go = function(a, b, c, d, e) {
        Z.call(this, a, 1134);
        this.rf = d;
        this.ec = e;
        this.v = Y(this, b);
        this.l = new YF(c)
    };
    _.T(Go, Z);
    Go.prototype.j = function() {
        var a;
        if (this.v.value && null != (a = this.l.value) && a.onEvent) {
            a = new Jj;
            var b = new iL(this.context, this.rf, this.ec, this.v.value, this.l.value);
            O(a, b);
            Sj(a)
        }
    };
    var mL = function(a, b, c, d) {
            var e = this;
            this.context = a;
            this.L = c;
            this.j = new _.v.Map;
            this.o = new _.v.Map;
            this.timer = _.Rf(Jh);
            eI() && (_.jb(window, "DOMContentLoaded", Hh(a, 334, function() {
                for (var f = _.z(e.j), g = f.next(); !g.done; g = f.next()) {
                    var h = _.z(g.value);
                    g = h.next().value;
                    h = h.next().value;
                    jL(e, g, h) && e.j.delete(g)
                }
            })), b.listen(rI, function(f) {
                f = f.detail;
                var g = f.R;
                return void kL(e, lL(d, f.Jg), Kr(g, 20))
            }), b.listen(sI, function(f) {
                f = f.detail;
                var g = f.R;
                f = lL(d, f.Jg);
                g = Kr(g, 20);
                var h = e.o.get(f);
                null != h ? gI(h, g) : kL(e, f, g)
            }))
        },
        kL = function(a, b, c) {
            jL(a, b, c) ? a.j.delete(b) : (a.j.set(b, c), _.tn(b, function() {
                return a.j.delete(b)
            }))
        },
        jL = function(a, b, c) {
            var d = Fi(b);
            if ("DIV" !== (null == d ? void 0 : d.nodeName)) return !1;
            d = new dI({
                B: window,
                timer: a.timer,
                Kb: d,
                mb: function(e) {
                    return void Lh(a.context, 336, e)
                },
                Sl: _.H(tC)
            });
            if (!d.j) return !1;
            gI(d, c);
            a.o.set(b, d);
            zI(a.L, b, function() {
                return void a.o.delete(b)
            });
            return !0
        };
    var nL = function(a, b, c, d, e) {
        Z.call(this, a, 1058);
        this.B = b;
        this.Z = c;
        this.output = hG(this);
        d && (this.l = Y(this, d.Dc));
        jG(this, e)
    };
    _.T(nL, Z);
    nL.prototype.j = function() {
        var a;
        Yf(this.B.isSecureContext, this.B, this.B.document) && null != (a = this.l) && a.value && !_.H(hB) && Lf(this.Z) && (a = this.l.value, a({
            message: "goog:spam:client_age",
            pvsid: this.context.pvsid
        }));
        this.output.notify()
    };
    var oL = function(a, b, c) {
        Z.call(this, a, 1199);
        this.l = c;
        this.v = Y(this, b)
    };
    _.T(oL, Z);
    oL.prototype.j = function() {
        var a = this.v.value;
        a && (a = aH(this.l, a.getSlotElementId()), Fj(a, 30, !0))
    };
    var pL = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1109);
        this.V = c;
        this.W = d;
        this.l = e;
        this.C = f;
        this.G = g;
        this.v = h;
        this.output = V(this);
        this.K = Y(this, b)
    };
    _.T(pL, Z);
    pL.prototype.j = function() {
        var a = this,
            b = this.K.value;
        b && (this.v.push(function() {
            b.addService(a.l)
        }), Iz(this.V, function() {
            a.G();
            a.C(b);
            _.N(a.W, 4) && a.l.refresh([b])
        }))
    };
    var qL = {},
        Mo = (qL[64] = CJ, qL[134217728] = DJ, qL[32768] = EJ, qL[536870912] = FJ, qL[8] = GJ, qL[512] = HJ, qL[1048576] = IJ, qL[4194304] = KJ, qL);
    var rL = function(a) {
        return "22639388115" === nh(a.getAdUnitPath())
    };
    var sL = function(a, b, c, d, e, f) {
        Z.call(this, a, 1108);
        this.adUnitPath = b;
        this.format = c;
        this.qb = d;
        this.v = e;
        this.T = f;
        this.output = V(this);
        this.l = V(this)
    };
    _.T(sL, Z);
    sL.prototype.j = function() {
        var a = ep(this.context, this.T, this.v, {
            uh: this.format,
            adUnitPath: this.adUnitPath,
            qb: this.qb
        });
        this.l.Ca(a);
        this.output.Ca(a ? a.j : null)
    };
    var tL = function(a, b, c, d) {
        Z.call(this, a, 1111);
        this.l = c;
        this.v = d;
        this.C = Y(this, b)
    };
    _.T(tL, Z);
    tL.prototype.j = function() {
        var a = this.C.value;
        a && (a = aH(this.l, a.getSlotElementId()), Gj(a, 27, Yx, this.v))
    };
    var uL = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        Jj.call(this);
        this.context = a;
        this.V = b;
        this.adUnitPath = c;
        this.format = d;
        this.qb = e;
        this.U = f;
        this.K = g;
        this.O = h;
        this.G = k;
        this.W = l;
        this.I = m;
        this.ba = n;
        this.T = p;
        this.da = r;
        this.M = w;
        a = O(this, new sL(this.context, this.adUnitPath, this.format, this.qb, this.ba, this.T));
        this.M && O(this, new tL(this.context, a.output, this.I, this.M));
        this.da && O(this, new oL(this.context, a.output, this.I));
        O(this, new pL(this.context, a.output, this.V, this.W, this.U, this.K, this.O, this.G));
        this.j = {
            Rn: a.l
        }
    };
    _.T(uL, Jj);
    var fp = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1198);
        this.V = b;
        this.googletag = c;
        this.W = d;
        this.l = e;
        this.v = f;
        this.T = g;
        this.C = W(this, h)
    };
    _.T(fp, Z);
    fp.prototype.j = function() {
        for (var a = this, b = _.z(this.C.value), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            c = d.getAdUnitPath();
            d = _.Hk(d, 2, 0);
            c && d && (c = new uL(this.context, this.V, c, d, !0, this.googletag.pubads(), this.googletag.display, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, this.googletag.cmd, this.W, this.l, this.v, this.T, !0), Sj(c), _.S(this, c))
        }
    };
    var zs = function(a, b) {
        Z.call(this, a, 1110);
        this.B = b;
        this.output = V(this)
    };
    _.T(zs, Z);
    zs.prototype.j = function() {
        var a = this.B;
        a = _.H(pC) && void 0 !== a.credentialless && (_.H(qC) || a.crossOriginIsolated);
        this.output.F(a)
    };
    var vL = function(a, b, c, d, e, f) {
        Z.call(this, a, 935);
        this.L = b;
        this.P = c;
        this.V = d;
        this.output = hG(this);
        this.l = W(this, e);
        jG(this, f)
    };
    _.T(vL, Z);
    vL.prototype.j = function() {
        var a = this.P,
            b = a.W;
        a = a.R;
        for (var c = _.z(this.l.value), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = a[d.getDomId()],
                f = this.V;
            hp(e, b) && !this.L.nc(d) && ip(d, f, e, b)
        }
        this.output.notify()
    };
    var wL = function(a, b, c, d, e) {
        Z.call(this, a, 864);
        this.L = b;
        this.P = c;
        this.V = d;
        this.l = hG(this);
        this.v = W(this, e)
    };
    _.T(wL, Z);
    wL.prototype.j = function() {
        lp({
            X: this.v.value
        }, {
            L: this.L,
            P: this.P,
            V: this.V
        });
        this.l.notify()
    };
    var pp = function(a, b, c) {
        Z.call(this, a, 1208);
        this.l = b;
        this.output = new Cn;
        this.v = Y(this, c)
    };
    _.T(pp, Z);
    pp.prototype.j = function() {
        var a, b = null == (a = this.v.value) ? void 0 : _.Zh(a, uy, 1);
        if (b) {
            a = this.l;
            var c = new $E;
            c = Fj(c, 5, !0);
            gF(a, "__eoi", b, c)
        }
        this.output.notify()
    };
    var xp = function(a, b, c, d) {
        Z.call(this, a, 879);
        this.Ic = b;
        this.l = V(this);
        c && (this.v = W(this, d))
    };
    _.T(xp, Z);
    xp.prototype.j = function() {
        var a, b;
        (null != (b = null == (a = this.v) ? void 0 : a.value) ? b : this.Ic.rc()) ? (a = rp(this.Ic), this.l.Ja(a)) : this.l.aa()
    };
    var up = function(a, b, c, d) {
        Z.call(this, a, 896);
        this.Ic = b;
        this.lc = d;
        this.tc = V(this);
        c && jG(this, c)
    };
    _.T(up, Z);
    up.prototype.j = function() {
        this.tc.F(this.Ic.rc(".google.cn" === this.lc))
    };
    var xL = function(a, b) {
        Z.call(this, a, 1018);
        this.Ae = hG(this);
        this.l = Y(this, b)
    };
    _.T(xL, Z);
    xL.prototype.j = function() {
        var a, b, c, d = _.z(null != (c = null == (a = this.l.value) ? void 0 : null == (b = _.Zh(a, JC, 5)) ? void 0 : Xd(b, 1, Mc)) ? c : []);
        for (a = d.next(); !a.done; a = d.next()) Tf(a.value);
        this.Ae.notify()
    };
    var yL = function(a, b) {
        Z.call(this, a, 1070);
        this.l = V(this);
        this.v = Y(this, b)
    };
    _.T(yL, Z);
    yL.prototype.j = function() {
        var a, b = null == (a = this.v.value) ? void 0 : _.Zh(a, JC, 5);
        if (b) {
            a = [];
            for (var c = _.z(Xd(b, 2, ad, void 0, void 0, void 0, 0)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value;
                d = new Yx;
                var f = new Wx;
                e = _.Ai(f, 1, Uc(e));
                d = _.th(d, 2, e);
                null != Np(b, 3) && (e = new Ux, e = _.ko(e, 1, 1), f = _.ax(b, 3), e = _.xk(e, 2, f), _.th(d, 3, e));
                a.push(d)
            }
            this.l.F(a)
        } else this.l.F([])
    };
    var zL = function(a, b, c, d) {
        Z.call(this, a, 1016);
        this.output = V(this);
        this.v = Y(this, b);
        this.l = Y(this, c);
        this.C = lG(this, [b, d])
    };
    _.T(zL, Z);
    zL.prototype.j = function() {
        if (this.l.value) {
            var a = this.v.value || this.C.value;
            a && AL(this, a) ? this.output.F(a) : this.output.aa()
        } else this.output.aa()
    };
    zL.prototype.H = function(a) {
        this.m(a)
    };
    zL.prototype.m = function() {
        this.output.aa()
    };
    var AL = function(a, b) {
        return _.bi(a.l.value, Sx, 1).some(function(c) {
            return _.R(c, 1) === b
        })
    };
    var BL = function(a, b) {
        Z.call(this, a, 1015);
        this.l = V(this);
        this.v = Y(this, b)
    };
    _.T(BL, Z);
    BL.prototype.j = function() {
        if (this.v.value)
            if (_.bi(this.v.value, Sx, 1).length) {
                var a = _.bi(this.v.value, Sx, 1)[0];
                (_.G = [2, 3], _.A(_.G, "includes")).call(_.G, _.Hk(a, 3, 0)) ? this.l.F(_.R(a, 1)) : this.l.aa()
            } else this.l.aa();
        else this.l.aa()
    };
    BL.prototype.H = function(a) {
        this.m(a)
    };
    BL.prototype.m = function() {
        this.l.aa()
    };
    var CL = function(a, b, c) {
        Z.call(this, a, 1017);
        this.B = c;
        this.output = hG(this);
        this.l = Y(this, b)
    };
    _.T(CL, Z);
    CL.prototype.j = function() {
        var a = this;
        if (this.l.value) {
            var b = jE(this.B, this.l.value, function(c) {
                if (!c) {
                    c = jf(b.j);
                    for (var d = _.z(document.getElementsByName("googlefcPresent")), e = d.next(); !e.done; e = d.next()) c.lj(e.value)
                }
                a.output.notify()
            });
            b.start()
        } else this.output.notify()
    };
    CL.prototype.H = function(a) {
        this.m(a)
    };
    CL.prototype.m = function() {
        this.output.notify()
    };
    var DL = function(a, b) {
        Z.call(this, a, 1056);
        this.output = V(this);
        this.l = W(this, b)
    };
    _.T(DL, Z);
    DL.prototype.j = function() {
        var a = nh(this.l.value.getAdUnitPath());
        this.output.F(a)
    };
    DL.prototype.H = function(a) {
        this.m(a)
    };
    DL.prototype.m = function() {
        this.output.aa()
    };
    var EL = function(a, b, c, d) {
        Z.call(this, a, 906, _.cg(NB));
        this.l = hG(this);
        if (b === b.top) {
            var e = new Jj;
            _.S(this, e);
            var f = new BL(a, c);
            O(e, f);
            d = new aq(a, d, rI, function(g) {
                return g.detail.R
            });
            O(e, d);
            d = new DL(a, d.output);
            O(e, d);
            a = new zL(a, f.l, c, d.output);
            O(e, a);
            b = new CL(this.context, a.output, b);
            O(e, b);
            kG(this, b.output);
            Sj(e)
        } else this.l.notify()
    };
    _.T(EL, Z);
    EL.prototype.j = function() {
        this.l.notify()
    };
    EL.prototype.H = function(a) {
        this.m(a)
    };
    EL.prototype.m = function() {
        this.l.notify()
    };
    var ft = function(a, b, c, d, e) {
        Z.call(this, a, 934);
        this.B = b;
        this.slotId = c;
        jG(this, d);
        this.l = W(this, e)
    };
    _.T(ft, Z);
    ft.prototype.j = function() {
        var a = this;
        this.slotId.listen(Sp, function(b) {
            b = b.detail.data;
            try {
                var c = JSON.parse(b);
                if ("gpi-uoo" === c.googMsgType) {
                    var d = c.userOptOut,
                        e = c.clearAdsData,
                        f = a.l.value,
                        g = new uy;
                    var h = Vn(g, 1, d ? "1" : "0");
                    var k = Vn(_.xk(h, 2, 2147483647), 3, "/");
                    var l = Vn(k, 4, a.B.location.hostname);
                    var m = new _.eF(a.B);
                    gF(m, "__gpi_opt_out", l, f);
                    if (d || e) hF(m, "__gads", f), hF(m, "__gpi", f)
                }
            } catch (n) {}
        })
    };
    var FL = function(a, b, c) {
        Z.call(this, a, 944);
        this.B = b;
        this.l = new _.eF(this.B);
        this.v = W(this, c)
    };
    _.T(FL, Z);
    FL.prototype.j = function() {
        var a = this.v.value;
        if (fF(this.l, a)) {
            var b = _.Sl(this.l, "__gpi_opt_out", a);
            if (b) {
                var c = new uy;
                b = Vn(c, 1, b);
                b = Vn(_.xk(b, 2, 2147483647), 3, "/");
                b = Vn(b, 4, this.B.location.hostname);
                gF(this.l, "__gpi_opt_out", b, a)
            }
        }
    };
    var GL = function(a, b, c, d) {
        Z.call(this, a, 821);
        this.Z = b;
        this.za = c;
        this.l = W(this, d)
    };
    _.T(GL, Z);
    GL.prototype.j = function() {
        if (Lf(this.Z))
            for (var a = new _.v.Set, b = _.z(_.bi(this.l.value, uy, 14)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = void 0,
                    e = null != (d = hx(c, 5)) ? d : 1;
                a.has(e) || (gF(this.za, 2 === e ? "__gpi" : "__gads", c, this.Z), a.add(e))
            }
    };
    var HL = function() {
            this.o = [];
            this.hostpageLibraryTokens = [];
            this.j = {}
        },
        ps = function(a, b) {
            var c, d;
            a = null != (d = null == (c = a.j[b]) ? void 0 : _.A(c, "values").call(c)) ? d : [];
            return [].concat(_.lh(a))
        };
    var IL = function(a, b, c, d) {
        Z.call(this, a, 822);
        this.slotId = b;
        this.Ta = c;
        this.l = W(this, d)
    };
    _.T(IL, Z);
    IL.prototype.j = function() {
        var a = Xd(this.l.value, 23, Kc);
        a = _.z(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = this.Ta;
            if (!_.A(c.o, "includes").call(c.o, b) && (_.G = [1, 2, 3], _.A(_.G, "includes")).call(_.G, b)) {
                var d = jF[b];
                if (d) {
                    var e = b + "_hostpage_library";
                    if (d = _.hn(document, d)) d.id = e
                }
                c.o.push(b);
                e = new kF(b);
                c.hostpageLibraryTokens.push(e);
                c = Hm();
                c.hostpageLibraryTokens || (c.hostpageLibraryTokens = {});
                c.hostpageLibraryTokens[e.j] = e.o
            }
            c = void 0;
            e = this.Ta;
            d = this.slotId;
            e.j[b] = null != (c = e.j[b]) ? c : new _.v.Set;
            e.j[b].add(d)
        }
    };
    var Jp = 0;
    var rt = function(a, b, c, d, e, f) {
        Z.call(this, a, 721);
        this.B = b;
        this.G = Y(this, c);
        this.v = W(this, d);
        this.l = W(this, e);
        this.C = W(this, f)
    };
    _.T(rt, Z);
    rt.prototype.j = function() {
        var a = this,
            b = this.G.value,
            c, d = null == b ? void 0 : null == (c = _.R(b, 1)) ? void 0 : c.toUpperCase(),
            e;
        b = null == b ? void 0 : null == (e = _.R(b, 2)) ? void 0 : e.toUpperCase();
        if (d && b) {
            e = this.v.value;
            c = this.l.value;
            var f = this.C.value,
                g = f.style.height,
                h = f.style.width,
                k = f.style.display,
                l = f.style.position,
                m = Lp(e.id + "_top", d),
                n = Lp(e.id + "_bottom", b);
            _.Si(n, {
                position: "relative",
                top: "calc(100vh - 48px)"
            });
            f.appendChild(m);
            f.appendChild(n);
            _.Si(c, {
                position: "absolute",
                top: "24px",
                clip: "rect(0, auto, auto, 0)",
                width: "100vw",
                height: "calc(100vh - 48px)"
            });
            _.Si(e, {
                position: "fixed",
                top: "0",
                height: "100vh"
            });
            var p;
            _.Si(f, {
                position: "relative",
                display: (null == (p = this.B.screen.orientation) ? 0 : p.angle) ? "none" : "block",
                width: "100vw",
                height: "100vh"
            });
            vn(this, 722, this.B, "orientationchange", function() {
                var r;
                (null == (r = a.B.screen.orientation) ? 0 : r.angle) ? _.Si(f, {
                    display: "none"
                }): _.Si(f, {
                    display: "block"
                })
            });
            _.tn(this, function() {
                _.fz(m);
                _.fz(n);
                f.style.position = l;
                f.style.height = g;
                f.style.width = h;
                f.style.display = k
            })
        }
    };
    var JL = _.tu(["https://td.doubleclick.net/td/kb?kbli=", ""]),
        dt = function(a, b, c, d, e) {
            Z.call(this, a, 1007);
            this.C = Y(this, b);
            this.l = W(this, d);
            c && (this.v = W(this, c));
            e && jG(this, e)
        };
    _.T(dt, Z);
    dt.prototype.j = function() {
        if (Lf(this.l.value)) {
            var a;
            if (null == (a = this.v) || !a.value) {
                var b = this.C.value;
                if (null != b && b.length && null === document.getElementById("koelBirdIGRegisterIframe")) {
                    a = document.createElement("iframe");
                    b = Ya(JL, encodeURIComponent(b.join()));
                    a.removeAttribute("srcdoc");
                    if (b instanceof _.kv) throw new gw("TrustedResourceUrl", 3);
                    var c = "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-storage-access-by-user-activation".split(" ");
                    a.setAttribute("sandbox", "");
                    for (var d = 0; d < c.length; d++) a.sandbox.supports && !a.sandbox.supports(c[d]) || a.sandbox.add(c[d]);
                    b = _.cb(b);
                    void 0 !== b && (a.src = b);
                    a.id = "koelBirdIGRegisterIframe";
                    document.head.appendChild(a)
                }
            }
        }
    };
    var Ts = function(a, b) {
        Z.call(this, a, 1176);
        this.v = b;
        this.l = V(this)
    };
    _.T(Ts, Z);
    Ts.prototype.j = function() {
        var a, b = this.l,
            c = b.Ca,
            d = null != (a = this.v) ? a : new Us;
        a = null != Np(d, 2) ? null != Op(d) && 0 !== (0, _.Pn)() ? Np(d, 2) * Op(d) : Np(d, 2) : null;
        c.call(b, a)
    };
    var Zs = function(a, b, c, d, e, f) {
        f = void 0 === f ? Mp : f;
        Z.call(this, a, 666);
        this.v = f;
        this.output = hG(this);
        jG(this, b);
        e && jG(this, e);
        this.l = W(this, c);
        this.C = Y(this, d)
    };
    _.T(Zs, Z);
    Zs.prototype.j = function() {
        var a = this.C.value,
            b = this.l.value;
        null == a || 0 > a || !Ji(b) ? this.output.notify() : KL(this, a, b)
    };
    var KL = function(a, b, c) {
        var d = a.v(b, Hh(a.context, 291, function(e, f) {
            e = _.z(e);
            for (var g = e.next(); !g.done; g = e.next())
                if (g = g.value, !(0 >= g.intersectionRatio)) {
                    f.unobserve(g.target);
                    a.output.notify();
                    break
                }
        }));
        d ? (d.observe(c), _.tn(a, function() {
            d.disconnect()
        })) : a.output.notify()
    };
    var Ys = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 664);
        this.slotId = b;
        this.ed = c;
        this.L = d;
        this.output = hG(this);
        this.v = W(this, e);
        this.l = Y(this, f);
        g && jG(this, g)
    };
    _.T(Ys, Z);
    Ys.prototype.j = function() {
        var a = this,
            b, c = null != (b = this.l.value) ? b : 0;
        if (0 !== (0, _.Pn)() || 0 < c)
            if (b = wF(document), xF(document) && b && (0 < EI(this.L, this.slotId) || !LL(this)) && b) {
                var d = vn(this, 324, document, b, function() {
                    xF(document) || (d && d(), a.output.notify())
                });
                if (d) return
            }
        this.output.notify()
    };
    var LL = function(a) {
        try {
            var b = top;
            if (!b) return !0;
            var c = ut(b.document, b).y,
                d = c + a.ed.height,
                e = a.v.value;
            return e.y >= c && e.y <= d
        } catch (f) {
            return !0
        }
    };
    var Xs = function(a, b) {
        Z.call(this, a, 676);
        this.output = V(this);
        this.l = W(this, b)
    };
    _.T(Xs, Z);
    Xs.prototype.j = function() {
        var a = pi(this.l.value);
        this.output.F(a)
    };
    var Pp = function(a, b, c, d, e, f) {
        f = void 0 === f ? _.v.globalThis.IntersectionObserver : f;
        Z.call(this, a, 886);
        this.X = b;
        this.L = c;
        this.v = d;
        this.l = f;
        this.output = hG(this);
        e && jG(this, e)
    };
    _.T(Pp, Z);
    Pp.prototype.j = function() {
        this.X.some(function(a) {
            return !Ji(Fi(a))
        }) ? this.output.notify() : ZF(this.output, ML(this, this.v))
    };
    var ML = function(a, b) {
        return new _.v.Promise(function(c) {
            if (a.l) {
                for (var d = new a.l(function(h, k) {
                        h.some(function(l) {
                            return 0 < l.intersectionRatio
                        }) && (k.disconnect(), c())
                    }, {
                        rootMargin: b + "%"
                    }), e = _.z(a.X), f = e.next(), g = {}; !f.done; g = {
                        Sd: g.Sd
                    }, f = e.next()) {
                    f = f.value;
                    g.Sd = Fi(f);
                    if (!g.Sd) return;
                    d.observe(g.Sd);
                    zI(a.L, f, function(h) {
                        return function() {
                            return void d.unobserve(h.Sd)
                        }
                    }(g))
                }
                _.tn(a, function() {
                    return void d.disconnect()
                })
            } else c()
        })
    };
    var NL = [{
            name: "Interstitial",
            format: 1,
            Ld: 5
        }, {
            name: "TopAnchor",
            format: 2,
            Ld: 2
        }, {
            name: "BottomAnchor",
            format: 3,
            Ld: 3
        }, {
            name: "LeftSideRail",
            format: 4,
            Ld: 8
        }, {
            name: "RightSideRail",
            format: 5,
            Ld: 9
        }],
        OL = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 789);
            this.V = b;
            this.googletag = c;
            this.v = d;
            this.l = e;
            this.T = f;
            this.C = g;
            this.output = V(this)
        };
    _.T(OL, Z);
    OL.prototype.j = function() {
        var a = this;
        NL.filter(function(b) {
            return (new RegExp("gam" + b.name + "Demo", "i")).test(a.C)
        }).forEach(function(b) {
            var c = b.name;
            b = b.Ld;
            var d, e;
            null == (d = window.console) || null == (e = d.warn) || e.call(d, "GPT - Demo " + c + " ENABLED");
            c = new uL(a.context, a.V, "/22639388115/example/" + c.toLowerCase(), b, !1, a.googletag.pubads(), function(f) {
                return void a.googletag.display(f)
            }, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, a.googletag.cmd, a.l.j, a.l, a.v, a.T, !1);
            _.S(a, c);
            Sj(c)
        })
    };
    var PL = function(a, b, c) {
        Z.call(this, a, 1163);
        _.H(gt);
        this.l = W(this, b);
        c && jG(this, c)
    };
    _.T(PL, Z);
    PL.prototype.j = function() {
        this.l.value.kj();
        this.l.value.ya()
    };
    var jt = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 682);
        this.L = b;
        this.format = c;
        this.slotId = d;
        this.B = e;
        this.v = V(this);
        this.l = Y(this, f);
        this.C = W(this, g);
        this.O = W(this, h);
        this.G = Y(this, k);
        this.K = W(this, l)
    };
    _.T(jt, Z);
    jt.prototype.j = function() {
        var a = this,
            b;
        if (null != (b = this.l.value) && _.N(b, 12, !1)) {
            b = this.G.value.mk;
            var c = _.jp(this.L, this.slotId),
                d = this.O.value,
                e = this.C.value;
            _.Si(e, {
                "max-height": "30vh",
                overflow: "hidden"
            });
            if (QL) QL.ij(e, this.K.value);
            else {
                QL = new b(this.context, this.format, e, this.B, d, this.L, this.slotId);
                b = {};
                d = _.z(_.bi(this.l.value, hy, 13));
                for (var f = d.next(); !f.done; f = d.next()) f = f.value, b[_.Aj(f, 1)] = _.Aj(f, 2);
                QL.jj(b);
                _.H(gt) ? (QL.fj(), this.v.F(QL)) : QL.ya();
                yI(this.L, this.slotId, function() {
                    QL && (QL.wa(), QL = null);
                    c && _.CI(a.L, a.slotId)
                })
            }
            _.tn(this, function() {
                return _.fz(e)
            })
        }
    };
    var QL = null;
    var ht = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 1155);
        this.L = b;
        this.format = c;
        this.slotId = d;
        this.B = e;
        this.Uf = f;
        this.v = g;
        this.G = h;
        this.C = k;
        this.K = l;
        this.l = Y(this, f)
    };
    _.T(ht, Z);
    ht.prototype.j = function() {
        var a;
        if (null != (a = this.l.value) && null != Pl(a, 12)) {
            a = new Jj;
            _.S(this, a);
            var b, c = (null == (b = this.l.value) ? 0 : _.N(b, 15)) ? O(a, new Rp(this.context, this.slotId, Sp, function(d) {
                d = d.detail.data;
                try {
                    var e = JSON.parse(d);
                    return "floating" === e.type && "loaded" === e.message
                } catch (f) {}
                return !1
            })).output : void 0;
            b = new jt(this.context, this.L, this.format, this.slotId, this.B, this.Uf, this.v, this.G, this.C, this.K);
            O(a, b);
            b = new PL(this.context, b.v, c);
            O(a, b);
            Sj(a)
        }
    };
    var Yp = function(a, b, c) {
        Z.call(this, a, 1150);
        this.B = b;
        this.output = hG(this);
        jG(this, c)
    };
    _.T(Yp, Z);
    Yp.prototype.j = function() {
        var a = this;
        this.B.location.hash = "goog_game_inter";
        _.tn(this, function() {
            "goog_game_inter" === a.B.location.hash && (a.B.location.hash = "")
        });
        ZF(this.output, new _.v.Promise(function(b) {
            return void vn(a, a.id, a.B, "hashchange", function(c) {
                rv(c.oldURL, "#goog_game_inter") && b()
            })
        }))
    };
    var RL = function(a, b) {
            this.serviceName = b;
            this.slot = a.j
        },
        SL = function(a, b) {
            RL.call(this, a, b);
            this.isEmpty = !1;
            this.slotContentChanged = !0;
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.labelIds = this.creativeTemplateId = this.creativeId = this.campaignId = this.advertiserId = this.size = null;
            this.isBackfill = !1;
            this.companyIds = this.yieldGroupIds = null
        };
    _.T(SL, RL);
    var TL = function() {
        RL.apply(this, arguments)
    };
    _.T(TL, RL);
    var UL = function(a, b, c) {
        RL.call(this, a, b);
        this.inViewPercentage = c
    };
    _.T(UL, RL);
    var VL = function() {
        RL.apply(this, arguments)
    };
    _.T(VL, RL);
    var WL = function() {
        RL.apply(this, arguments)
    };
    _.T(WL, RL);
    var XL = function() {
        RL.apply(this, arguments)
    };
    _.T(XL, RL);
    var YL = function() {
        RL.apply(this, arguments)
    };
    _.T(YL, RL);
    var ZL = function(a, b, c, d) {
        RL.call(this, a, b);
        this.makeRewardedVisible = c;
        this.payload = d
    };
    _.T(ZL, RL);
    var $L = function(a, b, c) {
        RL.call(this, a, b);
        this.payload = c
    };
    _.T($L, RL);
    var aM = function() {
        RL.apply(this, arguments)
    };
    _.T(aM, RL);
    var bM = function(a, b, c) {
        RL.call(this, a, b);
        this.makeGameManualInterstitialVisible = c
    };
    _.T(bM, RL);
    var cM = function() {
        RL.apply(this, arguments)
    };
    _.T(cM, RL);
    var Zp = function(a, b, c, d, e, f) {
        Z.call(this, a, 1151);
        this.slotId = b;
        this.ra = c;
        jG(this, d);
        a = [e];
        f && a.push(f);
        f = new $F(a, !0);
        cG(this.A, f)
    };
    _.T(Zp, Z);
    Zp.prototype.j = function() {
        Lr(this.ra, "gameManualInterstitialSlotClosed", 1148, new cM(this.slotId, "publisher_ads"))
    };
    var Wp = function(a, b, c, d) {
        Z.call(this, a, 1149);
        this.slotId = b;
        this.ra = c;
        this.output = hG(this);
        jG(this, d)
    };
    _.T(Wp, Z);
    Wp.prototype.j = function() {
        var a = new _.lg,
            b = a.promise;
        Lr(this.ra, "gameManualInterstitialSlotReady", 1147, new bM(this.slotId, "publisher_ads", a.resolve));
        0 < _.cg(KB) ? ZF(this.output, b.then(function() {
            return Jz(_.cg(KB))
        })) : ZF(this.output, b)
    };
    var Vp = function(a, b, c) {
        c = void 0 === c ? dM : c;
        Z.call(this, a, 1158);
        this.l = c;
        this.v = 1E3 * _.cg(Up);
        this.output = hG(this);
        jG(this, b)
    };
    _.T(Vp, Z);
    Vp.prototype.j = function() {
        var a = this;
        this.l.Ye++ ? ZF(this.output, Jz(this.v * (this.l.Ye - 2) + (this.v - (Date.now() - this.l.fg))).then(function() {
            a.l.fg = Date.now();
            a.l.Ye--
        })) : (this.l.fg = Date.now(), Jz(this.v).then(function() {
            return void a.l.Ye--
        }), this.output.notify())
    };
    var dM = {
        Ye: 0,
        fg: Date.now()
    };
    var eM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        fM = {
            width: "100%",
            height: "100%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        Xp = function(a, b, c, d, e) {
            Z.call(this, a, 1150);
            this.B = b;
            this.l = W(this, c);
            this.C = W(this, d);
            jG(this, e);
            this.v = new _.vG(this.B)
        };
    _.T(Xp, Z);
    Xp.prototype.j = function() {
        var a = 0 === (0, _.Pn)() ? "rgba(1,1,1,0.5)" : "white";
        _.Si(this.l.value, _.A(Object, "assign").call(Object, {
            position: "absolute"
        }, 0 === (0, _.Pn)() ? fM : eM));
        _.Si(this.C.value, _.A(Object, "assign").call(Object, {
            "background-color": a,
            opacity: "1",
            position: "fixed",
            margin: "0",
            padding: "0",
            "z-index": "2147483647",
            display: "block"
        }, eM));
        _.tn(this, _.IG(this.B.document, this.B));
        a = {};
        iz(this.l.value).postMessage(JSON.stringify((a.googMsgType = "sth", a.msg_type = "i-view", a)), "*");
        if (this.B === this.B.top) {
            var b = _.xG(this.v, 2147483646);
            _.BG(b);
            _.tn(this, function() {
                return void _.CG(b)
            })
        }
    };
    var gM = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 683);
        this.slotId = b;
        this.O = c;
        this.l = d;
        this.v = V(this);
        this.C = W(this, e);
        this.U = W(this, f);
        this.G = Y(this, g);
        this.K = Y(this, h)
    };
    _.T(gM, Z);
    gM.prototype.j = function() {
        var a = this,
            b = this.U.value,
            c = this.C.value,
            d = this.K.value.Gk,
            e = new _.TG(this.context),
            f = null != ai(this.l, 14) ? 60 * Kr(this.l, 14) : 604800;
        b = new d(window, c, b, e, this.O, hM(this), new _.v.Set(Xd(this.l, 15, Kc)), rL(this.slotId), function() {
            return void a.wa()
        }, f, this.G.value);
        b.K();
        _.S(this, b);
        this.v.F(b)
    };
    var hM = function(a) {
        var b = {};
        a = _.z(_.bi(a.l, hy, 13));
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, b[_.Aj(c, 1)] = _.Aj(c, 2);
        return b
    };
    var kt = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1141);
        this.slotId = b;
        this.G = c;
        this.v = e;
        this.K = f;
        this.sb = g;
        this.C = h;
        this.output = V(this);
        this.l = Y(this, d)
    };
    _.T(kt, Z);
    kt.prototype.j = function() {
        var a = this;
        if (this.l.value) {
            var b = new Jj;
            _.S(this, b);
            var c = O(b, new gM(this.context, this.slotId, this.G, this.l.value, this.v, this.K, this.sb, this.C));
            _.tn(c, function() {
                return void a.wa()
            });
            this.output.Ja(c.v.promise.then(function() {
                return !0
            }));
            Sj(b)
        } else this.output.F(!1)
    };
    var iM = function(a) {
        this.module = a
    };
    iM.prototype.toString = function() {
        return String(this.module)
    };
    _.jM = new iM(2);
    _.kM = new iM(5);
    _.lM = new iM(6);
    var ct = function(a, b, c, d, e, f) {
        Z.call(this, a, 846);
        this.C = b;
        this.format = c;
        this.output = V(this);
        this.l = Y(this, d);
        this.v = Y(this, e);
        f && jG(this, f)
    };
    _.T(ct, Z);
    ct.prototype.j = function() {
        var a, b = (2 === this.format || 3 === this.format) && !(null == (a = this.l.value) || !_.N(a, 12, !1));
        a = 5 === this.format && this.v.value;
        b || a ? this.output.Ja(this.C.load(_.jM)) : this.output.aa()
    };
    var mM = function(a, b, c, d, e) {
        Z.call(this, a, 905);
        this.P = b;
        this.l = c;
        this.output = hG(this);
        this.v = W(this, d);
        jG(this, e)
    };
    _.T(mM, Z);
    mM.prototype.j = function() {
        for (var a = _.z(this.v.value), b = a.next(); !b.done; b = a.next()) {
            var c = void 0;
            b = null == (c = this.P.R[b.value.getDomId()]) ? void 0 : Ps(c);
            if (2 === b || 3 === b || 5 === b) {
                this.l.load(_.jM);
                return
            }
        }
        this.output.notify()
    };
    var nM = function(a, b, c, d, e, f) {
        Z.call(this, a, 696);
        this.slotId = b;
        this.ra = c;
        jG(this, d);
        lG(this, [e, f])
    };
    _.T(nM, Z);
    nM.prototype.j = function() {
        Lr(this.ra, "rewardedSlotClosed", 703, new aM(this.slotId, "publisher_ads"))
    };
    var oM = function(a, b, c, d, e) {
        Z.call(this, a, 694);
        this.slotId = b;
        this.ra = c;
        jG(this, d);
        this.l = Y(this, e)
    };
    _.T(oM, Z);
    oM.prototype.j = function() {
        var a, b = null == (a = this.l.value) ? void 0 : a.payload;
        Lr(this.ra, "rewardedSlotGranted", 702, new $L(this.slotId, "publisher_ads", null != b ? b : null))
    };
    var pM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        qM = function(a, b, c, d, e, f) {
            Z.call(this, a, 693);
            this.B = b;
            this.G = f;
            this.output = hG(this);
            this.v = W(this, c);
            this.C = W(this, d);
            jG(this, e);
            this.l = new _.vG(this.B)
        };
    _.T(qM, Z);
    qM.prototype.j = function() {
        var a = this;
        if (!this.G.zb) {
            var b = 0 === (0, _.Pn)() ? "rgba(1,1,1,0.5)" : "white";
            _.Si(this.C.value, _.A(Object, "assign").call(Object, {
                "background-color": b,
                opacity: "1",
                position: "fixed",
                margin: "0",
                padding: "0",
                "z-index": "2147483647",
                display: "block"
            }, pM));
            _.tn(this, _.IG(this.B.document, this.B));
            iz(this.v.value).postMessage(JSON.stringify({
                type: "rewarded",
                message: "visible"
            }), "*");
            if (this.B === this.B.top) {
                this.B.location.hash = "goog_rewarded";
                var c = _.xG(this.l, 2147483646);
                _.BG(c);
                _.tn(this, function() {
                    _.CG(c);
                    "goog_rewarded" === a.B.location.hash && (a.B.location.hash = "")
                })
            }
            this.output.notify()
        }
    };
    var rM = function(a, b, c, d) {
        Z.call(this, a, 695);
        this.B = b;
        this.l = W(this, c);
        jG(this, d)
    };
    _.T(rM, Z);
    rM.prototype.j = function() {
        if (this.B === this.B.top) var a = iz(this.l.value),
            b = vn(this, 503, this.B, "hashchange", function(c) {
                rv(c.oldURL, "#goog_rewarded") && (a.postMessage(JSON.stringify({
                    type: "rewarded",
                    message: "back_button"
                }), "*"), b())
            })
    };
    var sM = function(a, b, c, d) {
        Z.call(this, a, 692);
        this.slotId = b;
        this.ra = c;
        this.output = hG(this);
        this.l = W(this, d)
    };
    _.T(sM, Z);
    sM.prototype.j = function() {
        var a = this.l.value,
            b = new _.lg,
            c = b.promise,
            d;
        Lr(this.ra, "rewardedSlotReady", 701, new ZL(this.slotId, "publisher_ads", b.resolve, null != (d = a.payload) ? d : null));
        ZF(this.output, c)
    };
    var tM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        uM = {
            width: "60%",
            height: "60%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        vM = function(a, b, c, d, e) {
            Z.call(this, a, 691);
            this.C = V(this);
            this.v = hG(this);
            this.G = W(this, c);
            this.l = lG(this, [d, e])
        };
    _.T(vM, Z);
    vM.prototype.j = function() {
        if ("ha_before_make_visible" === this.l.value.message) this.v.notify();
        else {
            var a = _.H(JB) ? tM : uM;
            _.Si(this.G.value, _.A(Object, "assign").call(Object, {
                position: "absolute"
            }, 0 === (0, _.Pn)() ? a : tM));
            this.C.F(this.l.value)
        }
    };
    var lt = function(a, b, c, d, e, f) {
        Jj.call(this);
        var g = cq(b, "granted", a);
        O(this, g);
        var h = cq(b, "prefetched", a);
        O(this, h);
        var k = cq(b, "closed", a);
        O(this, k);
        var l = cq(b, "ha_before_make_visible", a);
        O(this, l);
        var m = new vM(a, b, e, h.output, l.output);
        O(this, m);
        h = new sM(a, b, c, m.C);
        O(this, h);
        f = new qM(a, d, e, f, h.output, m.v);
        O(this, f);
        O(this, new rM(a, d, e, f.output));
        O(this, new oM(a, b, c, h.output, g.output));
        O(this, new nM(a, b, c, h.output, k.output, l.output))
    };
    _.T(lt, Jj);
    var Cs = function(a, b) {
        Z.call(this, a, 1031);
        this.B = b
    };
    _.T(Cs, Z);
    Cs.prototype.j = function() {
        this.B === this.B.top && Kk(this.B)
    };
    var As = function(a, b, c) {
        c = void 0 === c ? pg : c;
        Z.call(this, a, 1063);
        this.B = b;
        this.v = c;
        this.l = V(this)
    };
    _.T(As, Z);
    As.prototype.j = function() {
        var a = this;
        if (_.H(zB) && qg(this.B)) {
            var b = null,
                c = 0,
                d = Hh(this.context, this.id, function() {
                    var f, g, h, k;
                    return _.lb(function(l) {
                        switch (l.j) {
                            case 1:
                                return f = a.v(a.B), g = "0", l.m = 2, l.yield(f, 4);
                            case 4:
                                g = null != (h = l.o) ? h : "0";
                                1E4 < g.length && (Lh(a.context, a.id, new Fm("ML:" + g.length)), g = "0");
                                l.j = 3;
                                l.m = 0;
                                break;
                            case 2:
                                k = nb(l), Lh(a.context, a.id, k);
                            case 3:
                                b = g, c = _.Vg(a.B) + 3E5, l.j = 0
                        }
                    })
                });
            var e = (_.G = d(), _.A(_.G, "finally")).call(_.G, function() {
                e = void 0
            });
            this.l.F(function() {
                var f, g;
                return _.lb(function(h) {
                    if (1 == h.j) {
                        f = _.Vg(a.B) >= c;
                        g = null === b || "0" === b;
                        if (!f && !g) {
                            h.j = 2;
                            return
                        }
                        e || (e = (_.G = d(), _.A(_.G, "finally")).call(_.G, function() {
                            e = void 0
                        }));
                        return h.yield(e, 2)
                    }
                    return h.return(b)
                })
            })
        } else this.l.F(function() {
            return _.v.Promise.resolve("")
        })
    };
    As.prototype.m = function() {
        this.l.F(function() {
            return _.v.Promise.resolve("")
        })
    };
    var wM = function(a, b) {
        Z.call(this, a, 1091);
        this.output = V(this);
        b && (this.l = Y(this, b))
    };
    _.T(wM, Z);
    wM.prototype.j = function() {
        var a;
        null != (a = this.l) && a.value ? this.output.Ja(this.l.value()) : this.output.F("")
    };
    wM.prototype.m = function() {
        this.output.F("")
    };
    var pq = new _.v.Set(["disablePersonalization"]);
    var sq = function(a, b, c) {
        Z.call(this, a, 1122);
        this.V = b;
        this.l = c;
        hG(this, c)
    };
    _.T(sq, Z);
    sq.prototype.j = function() {
        var a = this,
            b = _.H(sB) ? Eh(this.context) : void 0;
        ZF(this.l, new _.v.Promise(function(c) {
            return void zF(function() {
                c();
                null == b || b()
            }, a.V)
        }))
    };
    var Ds = function(a, b, c) {
        Z.call(this, a, 1107);
        this.B = b;
        this.l = c;
        V(this, c)
    };
    _.T(Ds, Z);
    Ds.prototype.j = function() {
        var a = Wf(this.B.isSecureContext, this.B.navigator, this.B.document),
            b = Xf(this.B.isSecureContext, this.B.document),
            c = Yf(this.B.isSecureContext, this.B, this.B.document),
            d = !(!this.B.isSecureContext || !Vf("attribution-reporting", this.B.document)),
            e = 0;
        a && (e |= 1);
        b && (e |= 4);
        c && (e |= 8);
        d && (e |= 2);
        this.l.Ca(0 === e ? null : e)
    };
    Ds.prototype.m = function() {
        this.l.aa()
    };
    var xM = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1118, _.cg(RB));
        this.C = b;
        this.G = d;
        this.R = e;
        V(this, d);
        c && (this.K = Y(this, c));
        f && (this.v = W(this, f));
        g && (this.l = iG(this, g))
    };
    _.T(xM, Z);
    xM.prototype.j = function() {
        var a = new MF;
        a = _.je(a, 1, _.Oc(this.C), 0);
        if (this.l)
            if (this.l.value) {
                var b = _.rh(a, 3, this.l.value.label);
                _.I(b, 4, this.l.value.status)
            } else this.l.zb() || _.I(a, 4, 5);
        if (this.C & 1) {
            var c, d;
            b = yM(this, null != (d = null == (c = this.K) ? void 0 : c.value) ? d : null);
            _.th(a, 2, b)
        }
        this.G.F(a)
    };
    var yM = function(a, b) {
            switch (_.cg(Es)) {
                case 1:
                    var c = 1;
                    break;
                case 2:
                    c = 2;
                    break;
                case 3:
                    c = 3;
                    break;
                default:
                    c = 0
            }
            var d = LF(new KF, c);
            null == b || b.forEach(function(g, h) {
                var k = he(d, 2, JF);
                var l = k.set,
                    m = new JF;
                g = _.ie(m, 1, g, Nc);
                l.call(k, h, g)
            });
            var e;
            if ((null == (e = a.v) ? 0 : e.value) && a.R) {
                var f;
                b = _.z(null == (f = a.v) ? void 0 : f.value);
                for (f = b.next(); !f.done; f = b.next()) f = f.value, (c = zM(a, a.R[f.getDomId()])) && he(d, 3, HF).set(f.getAdUnitPath(), c)
            }
            return d
        },
        zM = function(a, b) {
            a = Mm(a.context, b);
            if (0 !== a.length) return IF(new HF, a.map(function(c) {
                return c.seller
            }))
        };
    var uq = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1165);
        this.G = c;
        this.df = d;
        this.R = e;
        this.C = f;
        this.v = g;
        this.l = Y(this, b.si)
    };
    _.T(uq, Z);
    uq.prototype.j = function() {
        if (this.l.value) {
            var a = new Jj,
                b = new xM(this.context, this.l.value, this.G, this.df.zg, this.R, this.C, this.v);
            O(a, b);
            Sj(a)
        } else this.df.zg.aa()
    };
    var AM = function(a, b, c) {
        Z.call(this, a, 1206);
        this.v = b;
        this.l = V(this);
        this.Z = W(this, c)
    };
    _.T(AM, Z);
    AM.prototype.j = function() {
        var a = this;
        this.v.cookieDeprecationLabel ? Lf(this.Z.value) ? this.l.Ja(this.v.cookieDeprecationLabel.getValue().then(function(b) {
            return {
                status: 1,
                label: b
            }
        }).catch(function(b) {
            a.I(b);
            return {
                status: 2
            }
        })) : this.l.F({
            status: 4
        }) : this.l.F({
            status: 3
        })
    };
    var BM = function(a, b) {
        Z.call(this, a, 1213, _.cg(RB));
        this.l = V(this);
        b && (this.v = iG(this, b))
    };
    _.T(BM, Z);
    BM.prototype.j = function() {
        var a, b, c;
        (null == (c = null == (a = this.v) ? void 0 : null == (b = a.value) ? void 0 : b.label) ? 0 : c.match(dg(QB))) ? this.l.F(!0): this.l.F(!1)
    };
    var CM = function(a, b) {
        Z.call(this, a, 1212, _.cg(RB));
        this.l = V(this);
        this.v = V(this);
        b && (this.C = iG(this, b))
    };
    _.T(CM, Z);
    CM.prototype.j = function() {
        var a, b, c = null == (a = this.C) ? void 0 : null == (b = a.value) ? void 0 : b.label;
        c ? (this.v.F(!0), c.match(dg(QB)) ? this.l.F(!0) : this.l.F(!1)) : (this.l.F(!1), this.v.F(!1))
    };
    var DM = function(a, b, c) {
        Z.call(this, a, 873);
        this.B = b;
        this.l = W(this, c)
    };
    _.T(DM, Z);
    DM.prototype.j = function() {
        var a = this.context,
            b = this.l.value,
            c = this.B;
        !Hm()._pubconsole_disable_ && (b = Pf("google_pubconsole", b, c)) && (b = b.split("|"), "1" !== b[0] && "0" !== b[0] || bn(a, c))
    };
    var EM = function() {
        this.resources = {}
    };
    var Qq = "3rd party ad content";
    var FM = function(a, b, c) {
        _.U.call(this);
        this.context = a;
        this.jb = b;
        this.m = c;
        a = c.slotId;
        b = c.size;
        this.j = "height" === c.nk ? "fluid" : [b.width, b.height];
        this.yd = Mi(a);
        this.zd = Qq
    };
    _.T(FM, _.U);
    FM.prototype.render = function() {
        var a = this.jb,
            b = this.m,
            c = b.slotId,
            d = b.P.R,
            e = b.size,
            f = b.Qf,
            g = b.isBackfill,
            h = b.Yd;
        xg(b.Ki, _.cz(b.V), null != f ? f : "", !1);
        Jr(_.Rf(Jh), "5", Kr(d[c.getDomId()], 20));
        Lr(c, Mr, 801, {
            mh: 0 === a.kind ? a.wb : "",
            isBackfill: g
        });
        a = this.l();
        h && a && a.setAttribute("data-google-container-id", h);
        Lr(c, Nr, 825, {
            size: e,
            isEmpty: !1
        });
        return a
    };
    FM.prototype.loaded = function(a) {
        var b = this.m,
            c = b.slotId,
            d = b.ra;
        b = b.P.R;
        Lr(c, Hs, 844);
        a && a.setAttribute("data-load-complete", !0);
        Lr(d, "slotOnload", 710, new VL(c, "publisher_ads"));
        Jr(_.Rf(Jh), "6", Kr(b[c.getDomId()], 20))
    };
    var GM = function(a) {
        a = a.jb;
        a = 0 === a.kind ? a.wb : "";
        var b = "";
        b = void 0 === b ? "" : b;
        if (a) {
            var c = a.toLowerCase();
            a = -1 < c.indexOf("<!doctype") || -1 < c.indexOf("<html") || _.H(wC) ? a : "<!doctype html><html><head>" + b + "</head><body>" + a + "</body></html>"
        }
        return a
    };
    FM.prototype.o = function() {
        _.U.prototype.o.call(this);
        this.m.Ki.removeAttribute("data-google-query-id")
    };
    FM.prototype.H = function(a) {
        var b = this,
            c = HM(this, function() {
                return void b.loaded(c.j)
            }, a);
        _.tn(this, function() {
            100 != c.status && (c.dg() && (zH(c.m), c.v = 0), window.clearTimeout(c.ta), c.ta = -1, c.I = 3, c.o && (c.o.wa(), c.o = null), _.uf(window, "resize", c.C), _.uf(window, "scroll", c.C), c.l && c.j && c.l == _.gz(c.j) && c.l.removeChild(c.j), c.j = null, c.l = null, c.status = 100)
        });
        return c
    };
    var HM = function(a, b, c) {
        var d = a.m,
            e = d.Ei,
            f = d.isBackfill,
            g = d.Hk,
            h = d.Yd,
            k = d.ye,
            l = d.yf,
            m = d.Ta,
            n = Array.isArray(a.j) ? new _.xi(Number(a.j[0]), Number(a.j[1])) : 1;
        return new HH({
            xg: d.gh,
            yd: a.yd,
            zd: a.zd,
            content: GM(a),
            size: n,
            Zj: !!g,
            gi: b,
            Fi: null != e ? e : void 0,
            permissions: {
                we: null != Pl(c, 1) ? !!_.N(c, 1) : !f,
                xe: null != Pl(c, 2) ? !!_.N(c, 2) : !1
            },
            Bd: !!Hm().fifWin,
            Gl: aK ? aK : aK = Fl(),
            Cj: Jl(),
            hostpageLibraryTokens: m.hostpageLibraryTokens,
            mb: function(p, r) {
                return void Lh(a.context, p, r)
            },
            uniqueId: h,
            Di: bH(),
            ye: null != k ? k : void 0,
            nb: void 0,
            yf: null != l ? l : void 0
        })
    };
    var IM = function() {
        FM.apply(this, arguments)
    };
    _.T(IM, FM);
    IM.prototype.l = function() {
        var a = this.m,
            b = a.P,
            c = b.W;
        a = b.R[a.slotId.getDomId()];
        b = new Kl;
        c = Ql([b, c.kc(), null == a ? void 0 : a.kc()]);
        return FM.prototype.H.call(this, c).j
    };
    IM.prototype.A = function() {
        return !1
    };
    var Vs = function(a, b, c, d, e, f) {
        Z.call(this, a, 669);
        this.W = b;
        this.R = c;
        this.output = V(this);
        this.v = Y(this, d);
        this.l = W(this, e);
        f && (this.C = W(this, f))
    };
    _.T(Vs, Z);
    Vs.prototype.j = function() {
        var a;
        if (null == (a = this.C) ? 0 : a.value) this.output.F(!0);
        else {
            var b;
            a = !(null == (b = this.v.value) || !_.R(b, 1)) && (_.N(this.R, 12) || Pl(this.W, 13)) || this.l.value;
            this.output.F(!!a)
        }
    };
    var JM = function(a, b, c, d) {
        Z.call(this, a, 833);
        this.l = b;
        this.B = c;
        this.output = hG(this);
        jG(this, d)
    };
    _.T(JM, Z);
    JM.prototype.j = function() {
        var a = this.l,
            b = this.B,
            c = bH();
        c = {
            version: aK ? aK : aK = Fl(),
            mf: c
        };
        c = OH.Qk(c);
        var d = uH(b);
        c = d ? _.We(c, new _.v.Map([
            ["n", String(d)]
        ])) : c;
        d = eg(Hl);
        for (var e = new _.v.Map, f = 0; f < d.length; f += 2) e.set(d[f], d[f + 1]);
        c = _.We(c, e);
        var g;
        a.resources[c.toString()] || (null == (g = Hm()) ? 0 : g.fifWin) || (a.resources[c.toString()] = 1, b = b.document, a = _.gf("IFRAME"), a.src = _.hb(c).toString(), a.style.visibility = "hidden", a.style.display = "none", b = b.getElementsByTagName("script"), b.length && (b = b[b.length - 1], b.parentNode && b.parentNode.insertBefore(a, b.nextSibling)));
        this.output.notify()
    };
    var KM = function(a, b, c) {
        Z.call(this, a, 1135);
        this.v = b;
        this.C = c;
        this.l = V(this)
    };
    _.T(KM, Z);
    KM.prototype.j = function() {
        for (var a = new Nx, b = new _.v.Map, c = new _.v.Set, d = _.z(this.v), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            if (null != _.Aj(f, 1)) {
                e = new _.v.Set;
                b.set(_.R(f, 1).toString(), e);
                f = _.z(_.bi(f, Lx, 2));
                for (var g = f.next(); !g.done; g = f.next()) {
                    g = g.value;
                    var h = _.R(g, 1);
                    e.add(h);
                    c.has(h) || Gj(a, 2, Lx, g);
                    c.add(h)
                }
            }
        }
        this.C.F(b);
        this.l.F(a)
    };
    var LM = function(a, b, c) {
        Z.call(this, a, 1051);
        this.v = b;
        this.l = Y(this, c)
    };
    _.T(LM, Z);
    LM.prototype.j = function() {
        var a = this;
        this.l.value && ek(this.l.value, function(b, c) {
            Lh(a.context, b, c);
            var d, e;
            null == (d = a.v) || null == (e = d.error) || e.call(d, c)
        })
    };
    var MM = function(a, b) {
        Z.call(this, a, 1040);
        this.l = V(this);
        this.v = Y(this, b)
    };
    _.T(MM, Z);
    MM.prototype.j = function() {
        var a = this.v.value;
        a ? (a = _.bi(a, Lx, 2), this.l.F(a.map(function(b) {
            var c = ex(b, Mx);
            b = _.R(b, 1);
            c = c && (_.A(c, "startsWith").call(c, location.protocol) || _.A(c, "startsWith").call(c, "data:") && 80 >= c.length) ? Ue(rj(c)) : void 0;
            return {
                ne: b,
                url: c
            }
        }))) : this.l.F([])
    };
    var NM = function(a, b, c, d, e) {
        Z.call(this, a, 813);
        this.C = b;
        this.l = d;
        this.sb = e;
        c && (this.G = Y(this, c));
        e && (this.v = Y(this, e))
    };
    _.T(NM, Z);
    NM.prototype.j = function() {
        var a = this,
            b, c, d = null != (c = this.C) ? c : null == (b = this.G) ? void 0 : b.value,
            e, f;
        b = null != (f = this.l) ? f : null == (e = this.v) ? void 0 : e.value;
        if (null != d && d.length && b)
            for (d = _.z(d), e = d.next(); !e.done; e = d.next()) f = e.value, e = f.ne, (f = f.url) && _.S(this, ik(e, f, b, this.sb, function(g, h) {
                Lh(a.context, g, h);
                var k, l;
                null == (l = (k = console).error) || l.call(k, h)
            }))
    };
    var OM = function(a, b, c) {
        Z.call(this, a, 1045);
        this.l = b;
        this.sb = c
    };
    _.T(OM, Z);
    OM.prototype.j = function() {
        var a = new Jj;
        _.S(this, a);
        var b = new MM(this.context, this.l);
        O(a, b);
        b = new NM(this.context, void 0, b.l, void 0, this.sb);
        O(a, b);
        Sj(a)
    };
    var Ns = function(a, b, c, d) {
        Z.call(this, a, 706);
        this.B = b;
        this.output = null != d ? d : V(this);
        this.l = W(this, c)
    };
    _.T(Ns, Z);
    Ns.prototype.j = function() {
        this.output.Ca(Mf(this.l.value, this.B))
    };
    var PM = function(a, b, c, d) {
        Z.call(this, a, 1154);
        this.ib = c;
        this.l = d;
        this.v = Y(this, b)
    };
    _.T(PM, Z);
    PM.prototype.j = function() {
        if (this.v.value) {
            var a = new Jj;
            _.S(this, a);
            var b = new Ns(this.context, window, this.ib, this.l.sb);
            O(a, b);
            b = new KM(this.context, this.v.value, this.l.qg);
            O(a, b);
            O(a, new OM(this.context, b.l, this.l.sb));
            b = new LM(this.context, console, this.l.sb);
            O(a, b);
            Sj(a)
        } else this.l.qg.aa(), this.l.sb.aa()
    };
    var QM = function(a, b, c, d, e, f) {
        Z.call(this, a, 1096);
        this.B = b;
        this.Z = c;
        this.l = d;
        this.lc = e;
        this.v = Y(this, f)
    };
    _.T(QM, Z);
    QM.prototype.j = function() {
        var a, b = null == (a = this.v.value) ? void 0 : a.pj;
        b && b(this.l, this.Z, this.B, this.lc, this.context.Qa)
    };
    var RM = function(a, b) {
        Z.call(this, a, 1095);
        this.l = b;
        this.output = V(this)
    };
    _.T(RM, Z);
    RM.prototype.j = function() {
        this.output.Ja(this.l.load(_.kM))
    };
    var SM = function(a, b, c, d, e) {
        Z.call(this, a, 1090);
        this.l = b;
        this.lc = c;
        this.v = W(this, d);
        this.C = Y(this, e)
    };
    _.T(SM, Z);
    SM.prototype.j = function() {
        var a = this.C.value,
            b;
        if (a && null != (b = _.Zh(a, _.by, 1)) && _.bi(b, _.ay, 15).length) {
            b = new Jj;
            _.S(this, b);
            var c = new RM(this.context, this.l);
            O(b, c);
            a = new QM(this.context, window, this.v.value, a, this.lc, c.output);
            O(b, a);
            Sj(b)
        }
    };
    var Vq = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1205);
        this.B = b;
        this.K = c;
        this.G = W(this, d);
        this.v = W(this, e);
        this.l = W(this, f);
        this.C = W(this, g)
    };
    _.T(Vq, Z);
    Vq.prototype.j = function() {
        var a = this.G.value;
        a = new a.Tl(this.v.value, this.B, this.l.value, this.K, this.C.value, new _.TG(this.context), new a.lk(this.B));
        _.S(this, a);
        _.S(this, a.K)
    };
    var Uq = function(a, b) {
        Z.call(this, a, 1204);
        this.l = b;
        this.output = V(this)
    };
    _.T(Uq, Z);
    Uq.prototype.j = function() {
        this.output.Ja(this.l.load(_.lM))
    };
    var ls = function(a, b) {
        var c = this,
            d = [],
            e = [];
        this.addSize = Hh(a, 88, function(f, g) {
            var h;
            if (h = xm(f)) h = g, h = wm(h) || Array.isArray(h) && h.every(wm);
            if (h) {
                if (_.H(cC)) {
                    var k = Yq(g);
                    h = k.size;
                    k.Dg && (g = Tk([f, g]), g = g.substring(1, g.length - 1), Q(b, new Sk(151, ["SizeMappingBuilder.addSize", g])), g = h)
                }
                d.push([f, g])
            } else e.push([f, g]), Q(b, Uk("SizeMappingBuilder.addSize", [f, g]));
            return c
        });
        this.build = Hh(a, 89, function() {
            if (e.length) return Q(b, WI(Nl(e))), null;
            sa(d);
            return d
        })
    };
    var TM = function(a, b, c, d, e, f) {
        f = void 0 === f ? kk : f;
        Z.call(this, a, 939);
        this.v = b;
        this.B = c;
        this.Z = d;
        this.l = f;
        this.output = hG(this);
        jG(this, e)
    };
    _.T(TM, Z);
    TM.prototype.j = function() {
        var a = this.l,
            b = this.B,
            c = new Dq;
        var d = new Cq;
        d = _.rh(d, 1, String(this.v));
        c = _.th(c, 5, d);
        c = _.I(c, 4, 1);
        c = _.I(c, 2, 2);
        c = _.rh(c, 3, this.context.xb || this.context.eb);
        c = _.xh(c, 6, Lf(this.Z));
        a.call(this, b, c);
        this.output.notify()
    };
    var at = function(a, b, c, d, e) {
        Z.call(this, a, 807);
        this.B = b;
        this.output = hG(this);
        this.l = Y(this, c);
        this.v = W(this, d);
        e && jG(this, e)
    };
    _.T(at, Z);
    at.prototype.j = function() {
        var a = this.l.value;
        if (a && !this.v.value) {
            var b = Kz(this.B);
            iI(new hI(b, a)) || this.I(new Fm("Cannot create top window frame"))
        }
        this.output.notify()
    };
    var UM = function(a, b) {
        Z.call(this, a, 820);
        this.B = b;
        this.output = V(this)
    };
    _.T(UM, Z);
    UM.prototype.j = function() {
        var a = this;
        this.output.Ja(ok(this.B).then(function(b) {
            var c = b.re,
                d = b.status;
            Zi("gpt_etu", function(e) {
                ej(e, a.context);
                fj(e, "rsn", d)
            }, c ? void 0 : 0);
            return null != c ? c : ""
        }))
    };
    var VM = function(a, b, c, d) {
        Z.call(this, a, 979);
        this.B = b;
        this.l = Y(this, d);
        this.output = c
    };
    _.T(VM, Z);
    VM.prototype.j = function() {
        var a = this;
        if (_.H(hC)) this.output.aa();
        else {
            var b;
            sk(this.B, null != (b = this.l.value) ? b : !1).then(function(c) {
                a.output.F(c)
            })
        }
    };
    VM.prototype.m = function() {
        this.output.aa()
    };
    var WM = function(a, b, c, d) {
        Z.call(this, a, 1156);
        this.B = b;
        this.oe = c;
        this.l = {
            Dc: new yn
        };
        this.v = W(this, d)
    };
    _.T(WM, Z);
    WM.prototype.j = function() {
        if (Lf(this.v.value)) {
            var a = new Jj;
            _.S(this, a);
            var b = new VM(this.context, this.B, this.l.Dc, this.oe);
            O(a, b);
            Sj(a)
        } else this.l.Dc.aa()
    };
    var XM = function(a, b, c) {
        Z.call(this, a, 1123);
        this.l = b;
        this.v = c;
        V(this, b);
        V(this, c)
    };
    _.T(XM, Z);
    XM.prototype.j = function() {
        _.H(fC) ? (this.l.F(!1), this.v.aa()) : (this.l.F(!0), this.v.F(10))
    };
    var YM = function(a, b, c, d, e) {
        Z.call(this, a, 978);
        this.B = b;
        this.C = c;
        this.l = e;
        V(this, e);
        this.v = Y(this, d.Dc)
    };
    _.T(YM, Z);
    YM.prototype.j = function() {
        if (_.H(gC)) this.l.aa();
        else if (this.v.value) {
            var a = Bk(this.v.value, this.B, new _.TG(this.context), this.C);
            this.l.Ja(a)
        } else this.l.aa()
    };
    YM.prototype.m = function() {
        this.l.aa()
    };
    var cr = function(a, b, c, d, e, f) {
        Z.call(this, a, 1164);
        this.v = b;
        this.pf = c;
        this.l = e;
        this.C = W(this, d);
        f && (this.G = W(this, f))
    };
    _.T(cr, Z);
    cr.prototype.j = function() {
        var a = Xf(window.isSecureContext, window.document),
            b;
        _.H(iC) && !a || (null == (b = this.G) ? 0 : b.value) ? (this.l.bd.aa(), this.l.Vd.F(!1), this.l.Wd.aa()) : this.C.value ? (a = new Jj, _.S(this, a), O(a, new YM(this.context, window, this.v, this.pf, this.l.bd)), b = new XM(this.context, this.l.Vd, this.l.Wd), O(a, b), Sj(a)) : (this.l.bd.F(5), this.l.Vd.F(!1), this.l.Wd.F(5))
    };
    var ZM = function(a, b, c) {
        Z.call(this, a, 1101);
        this.B = b;
        this.l = c
    };
    _.T(ZM, Z);
    ZM.prototype.j = function() {
        if (!_.H(gC)) {
            var a = this.l,
                b = pk(this.B);
            b.setTopicsCalled ? _.v.Promise.resolve() : (b.setTopicsCalled = !0, a({
                message: "goog:topics:frame:get:topics",
                skipTopicsObservation: !1
            }))
        }
    };
    var er = function(a, b, c, d) {
        Z.call(this, a, 1180);
        this.B = b;
        this.v = Y(this, d);
        this.l = Y(this, c.Dc)
    };
    _.T(er, Z);
    er.prototype.j = function() {
        if (this.v.value && this.l.value) {
            var a = new Jj;
            _.S(this, a);
            O(a, new ZM(this.context, this.B, this.l.value));
            Sj(a)
        }
    };
    var nr = function(a) {
        this.D = _.B(a)
    };
    _.T(nr, _.F);
    var jr = function(a, b) {
        return _.je(a, 2, null == b ? b : bd(b), "0")
    };
    var $M = function(a) {
        this.D = _.B(a)
    };
    _.T($M, _.F);
    var mr = Pe($M);
    $M.ca = [1];
    var aN = function(a, b, c, d) {
        Z.call(this, a, 1186);
        this.L = b;
        this.B = c;
        this.output = V(this);
        this.Z = W(this, d)
    };
    _.T(aN, Z);
    aN.prototype.j = function() {
        if (!Wf(this.B.isSecureContext, this.B.navigator, this.B.document) || _.H(Pr)) this.output.aa();
        else {
            var a = this.L.ze;
            if (null !== a) this.output.F(a);
            else {
                var b = _.Sl(new _.eF(this.B), "__gpi", this.Z.value);
                a = this.output;
                var c = a.F;
                b = _.$f(b || String(this.context.pvsid)) % 63001;
                this.L.ze = b;
                c.call(a, b)
            }
        }
    };
    var bN = function(a, b, c) {
        Z.call(this, a, 1171);
        this.l = c;
        V(this, c);
        this.Cg = W(this, b)
    };
    _.T(bN, Z);
    bN.prototype.j = function() {
        this.l.F(0 === this.Cg.value.kind)
    };
    var cN = function(a, b, c) {
        Z.call(this, a, 1160);
        this.l = c;
        V(this, c);
        this.v = W(this, b)
    };
    _.T(cN, Z);
    cN.prototype.j = function() {
        var a = this;
        if (this.v.value.requestId) {
            var b = this.v.value.request;
            Zi("td_ba", function(d) {
                ej(d, a.context);
                fj(d, "sz", b.byteLength)
            }, 1);
            if (32768 < b.byteLength) this.l.F({
                kind: 1,
                reason: 3
            });
            else {
                var c = Ab(b, 3);
                c.length ? this.l.F({
                    kind: 0,
                    signal: c,
                    requestId: this.v.value.requestId
                }) : this.l.F({
                    kind: 1,
                    reason: 5
                })
            }
        } else this.l.F({
            kind: 1,
            reason: this.v.value
        })
    };
    cN.prototype.m = function() {
        this.l.F({
            kind: 1,
            reason: 4
        })
    };
    var dN = function(a, b) {
        Z.call(this, a, 1159);
        this.output = V(this);
        this.l = b
    };
    _.T(dN, Z);
    dN.prototype.j = function() {
        var a = this;
        this.output.Ja(this.l.getInterestGroupAdAuctionData({
            seller: "https://securepubads.g.doubleclick.net"
        }).catch(function(b) {
            a.I(b);
            return 4
        }))
    };
    dN.prototype.m = function() {
        this.output.F(4)
    };
    var rr = function(a, b, c, d, e, f) {
        Z.call(this, a, 1177);
        this.C = b;
        this.l = e;
        this.v = f;
        V(this, e);
        V(this, f);
        this.G = W(this, c);
        d && (this.K = W(this, d))
    };
    _.T(rr, Z);
    rr.prototype.j = function() {
        if (this.G.value) {
            var a;
            if (null == (a = this.K) ? 0 : a.value) this.l.F({
                kind: 1,
                reason: 6
            }), this.v.F(!1);
            else {
                a = new Jj;
                _.S(this, a);
                var b = new dN(this.context, this.C);
                O(a, b);
                b = new cN(this.context, b.output, this.l);
                O(a, b);
                b = new bN(this.context, this.l, this.v);
                O(a, b);
                Sj(a)
            }
        } else this.l.F({
            kind: 1,
            reason: 2
        }), this.v.F(!1)
    };
    var eN = function(a, b, c, d) {
        Z.call(this, a, 881);
        this.Da = b;
        this.sa = c;
        this.l = d;
        this.output = V(this)
    };
    _.T(eN, Z);
    eN.prototype.j = function() {
        if (4 === _.cg(Es)) {
            var a = _.Zh(this.sa, Dy, 23);
            if (a) {
                var b;
                if (0 !== (null == (b = this.l) ? void 0 : b.kind)) throw new TypeError("Received remote auction config despite " + (this.l ? "invalid" : "absent") + " remarketing input.");
                this.output.F({
                    seller: "https://securepubads.g.doubleclick.net",
                    interestGroupBuyers: _.jl(this.sa, 3),
                    requestId: this.l.requestId,
                    serverResponse: Ek(Fk(a, 1)),
                    resolveToConfig: !_.N(this.sa, 14)
                })
            } else this.output.aa()
        } else {
            b = this.output;
            a = b.F;
            for (var c = this.sa, d = Mm(this.context, this.Da), e = !_.N(c, 14) && !0, f = {}, g = _.z(_.bi(c, By, 7)), h = g.next(); !h.done; h = g.next()) h = h.value, f[_.R(h, 1)] = JSON.parse(_.R(h, 2));
            if (g = _.Zh(c, Ay, 6)) f["https://googleads.g.doubleclick.net"] = g.toJSON(), f["https://td.doubleclick.net"] = g.toJSON();
            h = {};
            g = _.z(_.bi(c, Cy, 11));
            for (var k = g.next(); !k.done; k = g.next()) k = k.value, h[_.R(k, 1)] = _.ax(k, 2);
            k = {};
            0 !== _.ax(c, 21) && (k["*"] = _.ax(c, 21));
            var l = {};
            Kr(c, 18) && (l["https://googleads.g.doubleclick.net"] = Kr(c, 18), l["https://td.doubleclick.net"] = Kr(c, 18));
            g = _.z(he(c, 24, Gy));
            for (var m = g.next(); !m.done; m = g.next()) {
                var n = m.value;
                Kr(n[1], 4) && (m = n[0], n = Kr(n[1], 4), l[m] = n)
            }
            g = _.R(c, 1).split("/td/")[0];
            var p;
            m = null == (p = _.Zh(c, Fy, 5)) ? void 0 : _.Nd(p);
            var r;
            null != m && null != (r = _.Zh(m, Ey, 5)) && _.Ai(r, 2);
            p = _.A(Object, "assign").call(Object, {}, {
                seller: g,
                decisionLogicUrl: _.R(c, 1),
                trustedScoringSignalsUrl: _.R(c, 2),
                interestGroupBuyers: _.jl(c, 3),
                sellerExperimentGroupId: Kr(c, 17),
                auctionSignals: JSON.parse(_.R(c, 4) || "{}"),
                sellerSignals: (null == m ? void 0 : m.toJSON()) || [],
                sellerTimeout: _.ax(c, 15) || 50,
                perBuyerExperimentGroupIds: l,
                perBuyerSignals: f,
                perBuyerTimeouts: h,
                perBuyerCumulativeTimeouts: k
            }, e ? {
                resolveToConfig: e
            } : {});
            if (null == c ? 0 : _.N(rs(c, Fy, 5), 25)) p.sellerCurrency = "USD", p.perBuyerCurrencies = _.A(Object, "fromEntries").call(Object, ge(c, 22, ld));
            _.R(c, 28) ? p.directFromSellerSignalsHeaderAdSlot = _.R(c, 28) : _.R(c, 19) && (r = _.R(c, 19), p.directFromSellerSignals = "" !== r ? g + r : void 0);
            r = new Fy;
            if (In(rs(c, Fy, 5), Ey, 5)) {
                f = new Ey;
                h = rs(rs(c, Fy, 5), Ey, 5);
                var w = void 0 === w ? "0" : w;
                w = ne(ad(jo(h, 2)), w);
                w = _.je(f, 2, Uc(w), "0");
                _.th(r, 5, w)
            }
            rs(c, Fy, 5).getEscapedQemQueryId() && (w = rs(c, Fy, 5).getEscapedQemQueryId(), _.rh(r, 2, w));
            d = _.A(Object, "assign").call(Object, {}, {
                seller: g,
                decisionLogicUrl: _.R(c, 1),
                sellerExperimentGroupId: Kr(c, 17),
                sellerSignals: r.toJSON(),
                sellerTimeout: _.ax(c, 15) || 50,
                interestGroupBuyers: [],
                auctionSignals: {},
                perBuyerExperimentGroupIds: {},
                perBuyerSignals: {},
                perBuyerTimeouts: {},
                perBuyerCumulativeTimeouts: {},
                componentAuctions: [p].concat(_.lh(null != d ? d : []))
            }, e ? {
                resolveToConfig: e
            } : {});
            _.R(c, 28) ? d.directFromSellerSignalsHeaderAdSlot = _.R(c, 28) : _.R(c, 19) && (c = _.R(c, 19), d.directFromSellerSignals = "" !== c ? g + c : void 0);
            a.call(b, d)
        }
    };
    eN.prototype.m = function() {
        this.output.aa()
    };
    var fN = function(a, b, c, d) {
        Z.call(this, a, 1105);
        this.adUnitPath = b;
        this.sa = c;
        this.l = d
    };
    _.T(fN, Z);
    fN.prototype.j = function() {
        var a = _.jl(this.sa, 3),
            b = gr(this.adUnitPath);
        if (_.N(this.sa, 20)) {
            a = vr(a);
            var c = this.l.getItem(b),
                d = c ? _.bi(mr(c), nr, 1) : [];
            c = new $M;
            a = kr(d, a);
            a = _.ol(c, 1, a);
            this.l.setItem(b, Ak(a))
        } else _.H(mC) && this.l.removeItem(b)
    };
    var gN = function(a, b, c, d) {
        Z.call(this, a, 1174);
        var e = this;
        this.V = b;
        this.directFromSellerSignals = c;
        this.l = _.ev(function() {
            var f = (_.G = [].concat(_.lh(e.V.head.querySelectorAll("script[type=webbundle]"))), _.A(_.G, "find")).call(_.G, function(h) {
                var k;
                return null == (k = h.textContent) ? void 0 : k.match(e.directFromSellerSignals)
            });
            if (null != f && f.textContent) {
                var g = JSON.parse(f.textContent);
                g.resources = g.resources.filter(function(h) {
                    return !h.match(e.directFromSellerSignals)
                });
                f.remove();
                g.resources.length && (f = e.V.createElement("script"), f.type = "webbundle", gb(f, Ze(g)), e.V.head.appendChild(f))
            }
        });
        jG(this, d);
        _.tn(this, function() {
            return setTimeout(function() {
                return void e.l()
            }, 5E3)
        })
    };
    _.T(gN, Z);
    gN.prototype.j = function() {
        this.l()
    };
    var hN = function(a, b, c) {
        Z.call(this, a, 1175);
        this.output = hG(this);
        jG(this, b);
        jG(this, c)
    };
    _.T(hN, Z);
    hN.prototype.j = function() {
        ZF(this.output, Jz(5E3))
    };
    Bf({
        google_signals: Bf({
            buyer_reporting_id: Ef
        })
    });
    var yr = navigator,
        zr = /(\$\{GDPR})/gi,
        Ar = /(\$\{GDPR_CONSENT_[0-9]+\})/gi,
        Br = /(\$\{ADDTL_CONSENT})/gi,
        Cr = /(\$\{AD_WIDTH})/gi,
        Dr = /(\$\{AD_HEIGHT})/gi,
        Er = /(\$\{RENDER_DATA})/gi;
    var iN = function() {
            var a = this;
            this.promise = new _.v.Promise(function(b, c) {
                a.reject = c;
                a.resolve = b
            })
        },
        jN = function() {
            this.auctionSignals = new iN;
            this.topLevelSellerSignals = new iN;
            this.j = new iN;
            this.perBuyerSignals = new iN;
            this.perBuyerTimeouts = new iN;
            this.perBuyerCumulativeTimeouts = new iN;
            this.directFromSellerSignals = new iN;
            this.directFromSellerSignalsHeaderAdSlot = new iN;
            this.perBuyerCurrencies = new iN;
            this.resolveToConfig = new iN
        },
        kN = function(a, b, c) {
            this.j = a;
            this.Hf = b;
            this.Ab = c
        };
    var lN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u) {
        Z.call(this, a, 1201);
        this.da = b;
        this.Z = c;
        this.sa = d;
        this.fa = e;
        this.U = k;
        this.G = l;
        this.K = m;
        this.O = n;
        this.C = p;
        this.l = r;
        this.ma = hG(this);
        this.v = V(this);
        this.ya = Y(this, f);
        this.Ia = W(this, g);
        this.pa = W(this, h);
        this.ba = W(this, u);
        W(this, w);
        V(this, p);
        V(this, n.Eb);
        V(this, n.Aa);
        V(this, n.La);
        V(this, this.l)
    };
    _.T(lN, Z);
    lN.prototype.j = function() {
        var a = Math.round(performance.now() - this.Ia.value),
            b = this.pa.value,
            c = this.ya.value,
            d = _.Zh(this.sa, Fy, 5),
            e = _.N(d, 10),
            f = _.N(d, 9),
            g = "string" === typeof c || "function" === typeof FencedFrameConfig && c instanceof FencedFrameConfig,
            h = 3 !== c && 2 !== c && 1 !== c;
        this.l.F(g && !f);
        h && Hr(this.context, g, b, a, d);
        var k, l;
        h = null != (l = null == (k = this.ba.value.componentAuctions) ? void 0 : k.length) ? l : 0;
        Gr(this.context, c, a, b, !!this.fa, d, h, g);
        if (g)
            if (e) this.da.deprecatedURNToURL(c, !0), this.C.F(!0), this.v.aa();
            else if (f) {
            _.N(d, 17) ? wr(0, 0, d) : this.da.deprecatedURNToURL(c, !0);
            var m;
            xr(this.O, this.l, this.G, this.K, this.U, null == (m = this.sa) ? void 0 : _.R(m, 25));
            this.C.F(!0);
            this.v.aa()
        } else {
            this.v.F(c);
            this.C.F(!0);
            if (_.H(lC)) {
                b = this.ba.value;
                d = this.sa;
                var n;
                a = 1 === (null == (n = b.componentAuctions) ? void 0 : n.length) && qr(b.componentAuctions[0].seller) && b.componentAuctions[0].interestGroupBuyers.every(pr) && In(d, zy, 26) ? Bw(Ak(rs(d, zy, 26)), 3) : ""
            } else a = void 0;
            n = a;
            ZF(this.ma, Fr(c, _.A(Object, "assign").call(Object, {}, {
                gdprApplies: null != Pl(this.Z, 3) ? _.N(this.Z, 3) ? "1" : "0" : null,
                xk: _.Aj(this.Z, 2),
                rj: _.Aj(this.Z, 4),
                oj: this.sa.getWidth().toString(),
                mj: this.sa.getHeight().toString()
            }, n ? {
                Bl: n
            } : {})))
        } else {
            wr(a, 2 === c ? b : 0, d);
            if (!e) {
                var p;
                xr(this.O, this.l, this.G, this.K, this.U, null == (p = this.sa) ? void 0 : _.R(p, 25))
            }
            this.C.F(!0);
            this.v.aa()
        }
    };
    lN.prototype.m = function() {
        var a, b = null == (a = this.sa) ? void 0 : _.Zh(a, Fy, 5);
        a = this.fa;
        var c = this.O,
            d = this.l,
            e = this.G,
            f = this.K,
            g = this.U;
        b && wr(0, 0, b);
        null == a || a.Ab.abort();
        xr(c, d, e, f, g)
    };
    var mN = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        Z.call(this, a, 1200);
        this.L = b;
        this.pa = c;
        this.v = d;
        this.sa = e;
        this.U = g;
        this.G = h;
        this.K = k;
        this.O = m;
        this.ba = n;
        this.C = gG(this);
        this.ma = V(this);
        this.fa = V(this);
        this.da = V(this);
        this.l = Y(this, f);
        W(this, l);
        V(this, m.Eb);
        V(this, m.Aa);
        V(this, m.La);
        V(this, n)
    };
    _.T(mN, Z);
    mN.prototype.j = function() {
        if (this.l.value) {
            var a = rs(this.sa, Fy, 5);
            Ir(this.context, a);
            this.ma.F(performance.now());
            var b = _.ax(this.sa, 8) || 1E3;
            this.fa.F(b);
            var c = _.ax(a, 14) || -1,
                d = _.ax(a, 13) || -1;
            d = 0 < d && this.L.A >= d;
            if (0 < c && this.L.m >= c || d) this.C.F(1);
            else if (++this.L.m, ++this.L.A, this.l.value.signal = AbortSignal.timeout(b), _.N(a, 15)) --this.L.m, this.C.Ja(new _.v.Promise(function(e) {
                setTimeout(function() {
                    e(1)
                }, 0)
            }));
            else {
                if (this.v && this.l.value.serverResponse) throw new TypeError("Attempted to provide a RemoteAuctionConfig in parallelized auction.");
                a = this.v ? nN(this.l.value, b, this.v) : oN(this, this.l.value);
                --this.L.m;
                this.C.Ja(a)
            }
        } else null == (a = this.v) || a.Ab.abort(), xr(this.O, this.ba, this.G, this.K, this.U), this.da.F(!1)
    };
    var oN = function(a, b) {
            var c, d;
            return null == (d = (c = a.pa).runAdAuction) ? void 0 : d.call(c, b).catch(function(e) {
                return e instanceof DOMException && "TimeoutError" === e.name ? 2 : 3
            })
        },
        nN = function(a, b, c) {
            ur(a, c);
            setTimeout(function() {
                c.Ab.abort(new DOMException("runAdAuction", "TimeoutError"))
            }, b);
            return c.j
        };
    mN.prototype.m = function() {
        var a, b = null == (a = this.sa) ? void 0 : _.Zh(a, Fy, 5);
        a = this.v;
        var c = this.O,
            d = this.ba,
            e = this.G,
            f = this.K,
            g = this.U;
        b && wr(0, 0, b);
        null == a || a.Ab.abort();
        xr(c, d, e, f, g)
    };
    var pN = function(a, b, c, d, e, f) {
        Z.call(this, a, 1202);
        this.sa = b;
        this.l = c;
        this.v = Y(this, e);
        this.C = W(this, d);
        jG(this, f);
        V(this, c.Eb);
        V(this, c.Aa);
        V(this, c.La)
    };
    _.T(pN, Z);
    pN.prototype.j = function() {
        this.v.value && (this.C.value.style.display = "", this.l.Aa.F({
            kind: 2,
            Ud: this.v.value
        }), this.l.La.F(new _.xi(this.sa.getWidth(), this.sa.getHeight())), this.l.Eb.F(!1))
    };
    var qN = function(a, b, c) {
        Z.call(this, a, 1054);
        this.l = b;
        this.output = hG(this);
        this.v = W(this, c)
    };
    _.T(qN, Z);
    qN.prototype.j = function() {
        this.v.value || this.l();
        this.output.notify()
    };
    var rN = function(a, b, c, d, e, f) {
        Z.call(this, a, 1053);
        this.slotId = b;
        this.P = c;
        this.L = d;
        this.l = V(this);
        this.v = W(this, e);
        this.C = W(this, f)
    };
    _.T(rN, Z);
    rN.prototype.j = function() {
        this.C.value ? (Or(this.slotId, this.L, this.P, this.v.value), this.l.F(!1)) : this.l.F(!0)
    };
    var sN = function(a, b, c, d) {
        Z.call(this, a, 1055);
        this.l = d;
        jG(this, c);
        this.v = W(this, b);
        hG(this, this.l)
    };
    _.T(sN, Z);
    sN.prototype.j = function() {
        this.v.value && this.l.notify()
    };
    var Qr = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x) {
        Z.call(this, a, 1179);
        this.slotId = b;
        this.R = d;
        this.L = e;
        this.Z = f;
        this.v = g;
        this.O = l;
        this.C = m;
        this.P = n;
        this.ba = p;
        this.ec = r;
        this.l = u;
        this.fa = x;
        this.da = Y(this, w);
        this.G = W(this, h);
        this.K = W(this, k);
        this.U = Y(this, c)
    };
    _.T(Qr, Z);
    Qr.prototype.j = function() {
        var a = new Jj;
        _.S(this, a);
        var b = this.da.value,
            c = V(this);
        if (b) {
            var d = rs(b, Fy, 5),
                e = _.N(d, 10);
            if (b.getWidth() && b.getHeight())
                if (e)
                    if (xr({
                            Eb: c,
                            Aa: this.l.Aa,
                            La: this.l.La
                        }, this.l.Lc, this.G.value, this.K.value, this.v), _.N(d, 17)) {
                        wr(0, 0, d);
                        var f;
                        null == (f = this.C) || f.Ab.abort()
                    } else tN(this, a, b);
            else c = tN(this, a, b);
            else {
                xr({
                    Eb: c,
                    Aa: this.l.Aa,
                    La: this.l.La
                }, this.l.Lc, this.G.value, this.K.value, this.v);
                wr(0, 0, d);
                var g;
                null == (g = this.C) || g.Ab.abort()
            }
        } else xr({
            Eb: c,
            Aa: this.l.Aa,
            La: this.l.La
        }, this.l.Lc, this.G.value, this.K.value, this.v), null == (d = this.C) || d.Ab.abort();
        b = new rN(this.context, this.slotId, this.P, this.L, this.ec, c);
        O(a, b);
        c = new qN(this.context, this.ba, c);
        O(a, c);
        c = new sN(this.context, b.l, c.output, this.l.Pd);
        O(a, c);
        Sj(a)
    };
    var tN = function(a, b, c) {
        if (2 === _.cg(Es) && a.U.value && _.N(c, 20) && 0 !== _.jl(c, 3).length) {
            var d = new fN(a.context, a.slotId.getAdUnitPath(), c, a.U.value);
            O(b, d)
        }
        var e = new eN(a.context, a.R, c, a.fa);
        O(b, e);
        var f = navigator,
            g = {
                Aa: a.l.Aa,
                La: a.l.La,
                Eb: new yn
            };
        d = g.Eb;
        var h = new mN(a.context, a.L, f, a.C, c, e.output, a.v, a.G.value, a.K.value, a.O, g, a.l.Lc);
        O(b, h);
        var k = h.da;
        e = new lN(a.context, f, a.Z, c, a.C, h.C, h.ma, h.fa, a.v, a.G.value, a.K.value, g, k, a.l.Lc, a.O, e.output);
        O(b, e);
        g = new pN(a.context, c, g, a.O, e.v, e.ma);
        O(b, g);
        g = new Rp(a.context, a.slotId, Nr);
        O(b, g);
        k = new hN(a.context, k, g.output);
        O(b, k);
        c = _.R(c, 19);
        (null == c ? 0 : c.length) && O(b, new gN(a.context, window.document, c, k.output));
        return d
    };
    var uN = function() {
        FM.apply(this, arguments)
    };
    _.T(uN, FM);
    var vN = function(a, b) {
            var c = _.gf(b ? "fencedframe" : "IFRAME");
            b && (c.mode = "opaque-ads");
            c.id = a.yd;
            c.name = a.yd;
            c.title = a.zd;
            Array.isArray(a.j) ? null != a.j[0] && null != a.j[1] && (c.width = String(a.j[0]), c.height = String(a.j[1])) : (c.width = "100%", c.height = "0");
            c.allowTransparency = "true";
            c.scrolling = "no";
            c.marginWidth = "0";
            c.marginHeight = "0";
            c.frameBorder = "0";
            c.style.border = "0";
            c.style.verticalAlign = "bottom";
            c.setAttribute("role", "region");
            c.setAttribute("aria-label", "Advertisement");
            c.tabIndex = 0;
            return c
        },
        wN = function(a, b) {
            "string" !== typeof a.j && (b.width = String(a.j[0]), b.height = String(a.j[1]));
            var c = Hh(a.context, 774, function() {
                a.loaded(b);
                _.uf(b, "load", c)
            });
            _.jb(b, "load", c);
            _.tn(a, function() {
                return _.uf(b, "load", c)
            });
            a.m.gh.appendChild(b)
        };
    var xN = function() {
        uN.apply(this, arguments)
    };
    _.T(xN, uN);
    xN.prototype.l = function() {
        var a = vN(this, !this.m.km);
        if ("string" === typeof this.jb.Ud) {
            var b = this.jb.Ud;
            /^(uuid-in-package|urn:uuid):[0-9a-fA-F-]*$/.test(b) && (b = Ue(b), a.src = _.hb(b).toString())
        } else a.config = this.jb.Ud;
        wN(this, a);
        return a
    };
    xN.prototype.A = function() {
        return !1
    };
    var yN = navigator,
        zN = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 1089);
            this.Pb = b;
            this.X = c;
            this.R = d;
            this.Hc = f;
            this.l = g;
            V(this, g);
            e && (this.v = Y(this, e))
        };
    _.T(zN, Z);
    zN.prototype.j = function() {
        var a = {};
        if (1 === this.Pb)
            for (var b = _.z(this.X), c = b.next(); !c.done; c = b.next()) {
                var d = c.value;
                c = this.R[d.getDomId()];
                a[d.getId()] = AN(this, c, void 0, this.Hc)
            } else if (2 === this.Pb) {
                b = null == (d = this.v) ? void 0 : d.value;
                if (!b) {
                    this.l.aa();
                    return
                }
                d = _.z(this.X);
                for (c = d.next(); !c.done; c = d.next()) {
                    c = c.value;
                    var e = b.get(c.getId()),
                        f = void 0;
                    null != (f = e) && f.length && (f = this.R[c.getDomId()], a[c.getId()] = AN(this, f, e, this.Hc))
                }
            }
        this.l.F(a)
    };
    var AN = function(a, b, c, d) {
        var e = new jN,
            f = new AbortController;
        a = tr({
            Hf: e,
            Ab: f,
            fh: Mm(a.context, b),
            interestGroupBuyers: c,
            Hc: d
        });
        a = yN.runAdAuction(a).catch(function(g) {
            return g instanceof DOMException && "TimeoutError" === g.name ? 2 : 3
        });
        return new kN(a, e, f)
    };
    var BN = function(a, b, c, d, e, f) {
        Z.call(this, a, 1106);
        this.Z = b;
        this.v = c;
        this.X = d;
        this.Hc = e;
        this.C = f;
        this.l = V(this);
        V(this, f)
    };
    _.T(BN, Z);
    BN.prototype.j = function() {
        for (var a = or(this.v, this.Z, this.Hc), b = new _.v.Map, c = new _.v.Map, d = _.z(this.X), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            e = f.getAdUnitPath();
            var g = void 0,
                h = void 0,
                k = null != (h = null == (g = a.get(gr(e))) ? void 0 : _.bi(g, nr, 1).map(function(l) {
                    return _.R(l, 1)
                })) ? h : [];
            b.set(f.getId(), k);
            if (!c.has(e)) {
                f = [];
                k = _.z(k.sort());
                for (g = k.next(); !g.done; g = k.next()) f.push(_.$f(g.value));
                c.set(e, f)
            }
        }
        this.l.F(b);
        this.C.F(c)
    };
    var Sr = function(a, b, c, d, e, f, g, h, k) {
        Z.call(this, a, 1170);
        this.Pb = b;
        this.R = c;
        this.Z = d;
        this.v = e;
        this.l = {
            wg: V(this)
        };
        2 === b && this.v && (this.l.ag = V(this));
        this.K = W(this, f);
        this.G = W(this, g);
        h && (this.C = Y(this, h));
        k && (this.O = W(this, k))
    };
    _.T(Sr, Z);
    Sr.prototype.j = function() {
        var a = this.K.value,
            b;
        if (!this.G.value || !a.length || (null == (b = this.O) ? 0 : b.value)) {
            this.l.wg.aa();
            var c;
            null == (c = this.l.ag) || c.aa()
        } else {
            b = new Jj;
            _.S(this, b);
            if (2 === this.Pb && this.v) {
                var d, e;
                var f = new BN(this.context, this.Z, this.v, a, null != (e = null == (d = this.C) ? void 0 : d.value) ? e : void 0, this.l.ag);
                O(b, f);
                f = f.l
            }
            var g, h;
            a = new zN(this.context, this.Pb, a, this.R, f, null != (h = null == (g = this.C) ? void 0 : g.value) ? h : void 0, this.l.wg);
            O(b, a);
            Sj(b)
        }
    };
    var CN = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1166);
        this.ld = b;
        this.V = c;
        this.G = d;
        this.l = gG(this);
        this.v = V(this);
        this.C = V(this);
        this.O = W(this, e);
        this.U = W(this, f);
        jG(this, g);
        this.K = W(this, h)
    };
    _.T(CN, Z);
    CN.prototype.j = function() {
        var a = this,
            b = this.O.value;
        if (b) {
            var c = pb(this.U.value, {
                    uuid: this.ld
                }),
                d = this.V.createElement("script");
            b = {
                source: b,
                credentials: this.K.value ? "include" : "omit",
                resources: [c.toString()]
            };
            d.setAttribute("type", "webbundle");
            gb(d, Ze(b));
            this.V.head.appendChild(d);
            this.v.F(d);
            this.C.F(b);
            this.l.Ja(DN(c).catch(function(e) {
                e instanceof UE ? a.G(e) : (a.I(e), a.m(e));
                return null
            }))
        } else this.l.aa(), this.v.aa(), this.C.aa()
    };
    var DN = function(a) {
        var b, c;
        return _.lb(function(d) {
            if (1 == d.j) return d.yield(fetch(a.toString()).catch(function() {
                throw new UE("Failed to fetch bundle index.");
            }), 2);
            if (3 != d.j) return b = d.o, d.yield(b.text(), 3);
            c = d.o;
            return d.return(My(c))
        })
    };
    var EN = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 1167);
        this.V = b;
        this.Z = c;
        this.G = d;
        this.l = e;
        this.C = f;
        this.v = W(this, g);
        this.O = Y(this, h);
        this.U = Y(this, k);
        this.ba = Y(this, l);
        m && (this.K = Y(this, m))
    };
    _.T(EN, Z);
    EN.prototype.j = function() {
        var a = this.O.value,
            b = this.U.value,
            c = this.ba.value;
        if (a)
            if (b && c) {
                var d = _.jl(a, 1),
                    e = _.jl(a, 2);
                a = _.jl(a, 3);
                if (d.length !== e.length) this.l(new TE("Received " + d.length + " ad URLs but " + e.length + " metadatas"));
                else {
                    c.resources = [].concat(_.lh(d.filter(function(f) {
                        return f
                    })), _.lh(a.map(function(f) {
                        return "https://securepubads.g.doubleclick.net" + f
                    })));
                    c.resources.length ? (a = _.gf("SCRIPT"), a.setAttribute("type", "webbundle"), gb(a, Ze(c)), this.V.head.removeChild(b), this.V.head.appendChild(a)) : this.V.head.removeChild(b);
                    for (b = 0; b < d.length; b++) c = void 0, this.G(b, e[b], {
                        kind: 1,
                        url: d[b]
                    }, this.v.value, this.Z, null == (c = this.K) ? void 0 : c.value, void 0);
                    this.C(d.length - 1, this.v.value, this.Z)
                }
            } else this.l(Error("Lost bundle script"))
    };
    var FN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        Jj.call(this);
        e = new CN(a, f, h, c, m, n, p, r);
        O(this, e);
        O(this, new EN(a, h, g, b, c, d, k, e.l, e.v, e.C, l));
        this.j = {
            output: e.l
        }
    };
    _.T(FN, Jj);
    var ms = new _.v.Set,
        GN = function(a, b, c) {
            var d = 0,
                e = function() {
                    d = 0
                };
            return function(f) {
                d || (d = _.t.setTimeout(e, b), a.apply(c, arguments))
            }
        }(function() {
            throw new Fm("Reached Limit for addEventListener");
        }, 3E5),
        HN = function(a, b, c) {
            _.U.call(this);
            this.context = a;
            this.T = b;
            this.m = c;
            this.j = [];
            this.enabled = !1;
            this.I = 0;
            this.l = new _.v.Map;
            ms.add(this);
            this.T.info(XI(this.getName()))
        };
    _.T(HN, _.U);
    var os = function(a) {
        a.enabled || (a.enabled = !0, Rl(6, a.context), a.M())
    };
    HN.prototype.slotAdded = function(a, b) {
        this.j.push(a);
        var c = new WL(a, this.getName());
        Lr(this.m, "slotAdded", 818, c);
        this.T.info(YI(this.getName(), a.getAdUnitPath()), a);
        a = this.getName();
        ix(b, 4, a)
    };
    HN.prototype.destroySlots = function(a) {
        var b = this;
        return a.filter(function(c) {
            return ha(b.j, c)
        })
    };
    HN.prototype.addEventListener = function(a, b, c) {
        var d = this;
        c = void 0 === c ? window : c;
        if (this.I >= _.cg(qB) && 0 < _.cg(qB)) return GN(), !1;
        if (!c.IntersectionObserver && (_.G = ["impressionViewable", "slotVisibilityChanged"], _.A(_.G, "includes")).call(_.G, a)) return Q(this.T, MJ()), !1;
        var e;
        if (null == (e = this.l.get(a)) ? 0 : e.has(b)) return !1;
        this.l.has(a) || this.l.set(a, new _.v.Map);
        c = function(f) {
            f = f.detail;
            try {
                b(f)
            } catch (k) {
                d.T.error(mJ(String(k), a));
                var g, h;
                null == (g = window.console) || null == (h = g.error) || h.call(g, k)
            }
        };
        this.l.get(a).set(b, c);
        this.m.listen(a, c);
        this.I++;
        return !0
    };
    HN.prototype.removeEventListener = function(a, b) {
        var c, d = null == (c = this.l.get(a)) ? void 0 : c.get(b);
        if (!d || !mI(this.m, a, d)) return !1;
        this.I--;
        return this.l.get(a).delete(b)
    };
    var Wr = function(a) {
        for (var b = _.z(ms), c = b.next(); !c.done; c = b.next()) c.value.destroySlots(a)
    };
    var is = function(a, b, c, d) {
        HN.call(this, a, b, d);
        this.A = c;
        this.ads = new _.v.Map;
        this.zc = !1
    };
    _.T(is, HN);
    is.prototype.setRefreshUnfilledSlots = function(a) {
        "boolean" === typeof a && (this.zc = a)
    };
    var YJ = function(a, b) {
            var c;
            return a.A.enabled && !(null == (c = a.ads.get(b)) || !c.ll)
        },
        ZJ = function(a, b, c, d) {
            b = new SL(b, a.getName());
            null != c && null != d && (b.size = [c, d]);
            Lr(a.m, "slotRenderEnded", 67, b)
        };
    is.prototype.getName = function() {
        return "companion_ads"
    };
    is.prototype.slotAdded = function(a, b) {
        var c = this;
        a.listen(pI, function(d) {
            Pl(d.detail, 11) && (IN(c, a).ll = !0)
        });
        HN.prototype.slotAdded.call(this, a, b)
    };
    is.prototype.M = function() {};
    var IN = function(a, b) {
            var c = a.ads.get(b);
            c || (c = {}, a.ads.set(b, c), _.tn(b, function() {
                return a.ads.delete(b)
            }));
            return c
        },
        WJ = function(a, b) {
            var c = Pi().j,
                d = Pi().o;
            if (a.A.enabled) {
                var e = {
                    Sb: 3
                };
                a.H && (e.cd = a.H);
                a.v && (e.dd = a.v);
                b = null != b ? b : a.j;
                c = Bi(c, d);
                d = e.cd;
                var f = e.dd;
                d && "number" !== typeof d || f && "number" !== typeof f || a.A.refresh(c, b, e)
            } else(null == b ? 0 : b[0]) && a.T.error(dJ(b[0].getDomId()))
        },
        XJ = function(a, b) {
            return a.j.filter(function(c) {
                return _.A(b, "includes").call(b, c.toString())
            })
        };
    var js = function(a, b, c) {
        HN.call(this, a, b, c)
    };
    _.T(js, HN);
    js.prototype.getName = function() {
        return "content"
    };
    js.prototype.M = function() {};
    var JN = function() {
        this.Qj = 1E3
    };
    JN.prototype.send = function(a, b) {
        a.Hi(b)
    };
    var iu = function(a, b) {
        var c = {};
        this.configuration = (c[576944485] = new JN, c);
        this.Ka = a;
        this.j = b
    };
    iu.prototype.log = function(a, b, c) {
        var d, e = null != (d = c.ff) ? d : this.configuration[a].Qj;
        1 / e < this.j || (b = b(_.A(Object, "assign").call(Object, {}, {
            ff: e
        }, c)), this.configuration[a].send(this.Ka, b))
    };
    var KN = _.tu(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl_", "", ".js"]),
        LN = _.tu(["https://securepubads.g.doubleclick.net/gpt/pubads_impl_", "_", ".js"]),
        MN = _.tu(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl_", "", ".js"]),
        NN = _.tu(["https://pagead2.googlesyndication.com/gpt/pubads_impl_", "_", ".js"]),
        ON = new _.v.Map([
            [2, {
                og: "page_level_ads"
            }],
            [5, {
                og: "shoppit"
            }],
            [6, {
                og: "side_rails"
            }]
        ]),
        PN = function(a) {
            var b = void 0 === b ? ON : b;
            this.context = a;
            this.j = b;
            this.o = new _.v.Map;
            this.loaded = new _.v.Set
        },
        RN;
    PN.prototype.load = function(a) {
        var b = _.QN(this, a),
            c, d = (null != (c = this.j.get(a.module)) ? c : {}).og;
        if (!d) throw Error("cannot load invalid module: " + d);
        if (!this.loaded.has(a.module)) {
            (c = _.ki(172)) && "pagead2.googlesyndication.com" === mz((c.src || "").match(_.lz)[3] || null) ? (c = "", _.H(IB) && (c = Ep(_.H(HB), this.context.zh)), d = this.context.xb ? _.Ve(MN, this.context.xb, d, c) : _.Ve(NN, d, this.context.eb)) : this.context.xb ? (c = "", _.H(IB) && (c = Ep(_.H(HB), this.context.zh)), d = _.Ve(KN, this.context.xb, d, c)) : d = _.Ve(LN, d, this.context.eb);
            c = {};
            var e = _.cg(WB);
            e && (c.cb = e);
            d = _.A(Object, "keys").call(Object, c).length ? _.nv(d, c) : d;
            RN(this, a);
            _.hn(document, d);
            this.loaded.add(a.module)
        }
        return b.promise
    };
    _.QN = function(a, b) {
        b = b.module;
        a.o.has(b) || a.o.set(b, new _.lg);
        return a.o.get(b)
    };
    RN = function(a, b) {
        var c = b.module;
        b = "_gpt_js_load_" + c + "_";
        var d = Hh(a.context, 340, function(e) {
            if (a.j.has(c) && "function" === typeof e) {
                var f = a.j.get(c);
                f = (void 0 === f.Sj ? [] : f.Sj).map(function(g) {
                    return _.QN(a, g).promise
                });
                _.v.Promise.all(f).then(function() {
                    e.call(window, _, a)
                })
            }
        });
        Object.defineProperty(Hm(), b, {
            value: function(e) {
                if (d) {
                    var f = d;
                    d = null;
                    f(e)
                }
            },
            writable: !1,
            enumerable: !1
        })
    };
    var SN = function(a, b) {
        Z.call(this, a, 980);
        this.output = new Cn;
        this.l = [];
        this.v = W(this, b)
    };
    _.T(SN, Z);
    SN.prototype.j = function() {
        for (var a = _.z((_.G = [this.v.value, this.l.map(function(c) {
                return c.value
            })], _.A(_.G, "flat")).call(_.G)), b = a.next(); !b.done; b = a.next()) Tf(b.value);
        this.output.notify()
    };
    var TN = function(a, b) {
        Z.call(this, a, 892, _.cg(OB));
        this.l = V(this);
        this.C = V(this);
        this.v = V(this);
        this.pd = V(this);
        this.Od = V(this);
        this.G = V(this);
        this.uf = V(this);
        this.K = iG(this, b);
        _.H(kB) && (this.od = V(this))
    };
    _.T(TN, Z);
    TN.prototype.j = function() {
        var a = this.K.value;
        if (!a) throw Error("config timeout");
        this.l.Ca(_.Zh(a, Rx, 3));
        this.C.Ca(_.Zh(a, Tx, 2));
        this.v.F(Xd(a, 4, Mc));
        this.pd.Ca(_.bi(a, Nx, 6));
        this.Od.Ca(_.bi(a, dy, 5));
        this.G.Ca(_.Zh(a, cy, 7));
        var b;
        this.uf.F(new _.v.Set((null == (b = _.Zh(a, Ox, 1)) ? void 0 : _.jl(b, 6)) || []));
        var c;
        null == (c = this.od) || c.Ca(_.Zh(a, fy, 8))
    };
    TN.prototype.H = function(a) {
        this.m(a)
    };
    TN.prototype.m = function(a) {
        this.l.gb(a);
        this.C.gb(a);
        this.v.F([]);
        this.pd.F([]);
        this.Od.F([]);
        this.G.aa();
        var b;
        null == (b = this.od) || b.aa()
    };
    var UN = function(a, b) {
        Z.call(this, a, 891);
        var c = this;
        this.l = V(this);
        this.error = void 0;
        var d = V(this);
        this.v = W(this, d);
        b(function(e, f) {
            if (f) c.error = f, d.F([]);
            else try {
                if ("string" === typeof e) {
                    var g = JSON.parse(e || "[]");
                    Array.isArray(g) && d.F(g)
                }
            } catch (h) {} finally {
                d.zb || (c.error = Error("malformed response"), d.F([]))
            }
        })
    };
    _.T(UN, Z);
    UN.prototype.j = function() {
        if (this.error) throw this.error;
        this.l.F(qe(gy, this.v.value))
    };
    var VN = function(a, b) {
        Z.call(this, a, 1081);
        this.Mb = V(this);
        this.l = Y(this, b)
    };
    _.T(VN, Z);
    VN.prototype.j = function() {
        this.l.value ? this.Mb.F(this.l.value) : this.Mb.aa()
    };
    var WN = new _.v.Map([
            [1, 5],
            [2, 2],
            [3, 3]
        ]),
        XN = function(a, b, c, d, e, f, g, h, k) {
            Z.call(this, a, 1079);
            this.V = b;
            this.googletag = c;
            this.W = d;
            this.G = e;
            this.l = f;
            this.T = g;
            this.v = h;
            this.C = k;
            V(this)
        };
    _.T(XN, Z);
    XN.prototype.j = function() {
        var a = this,
            b = this.v.getAdUnitPath(),
            c = WN.get(_.Hk(this.v, 2, 0));
        if (b && c) {
            var d, e = null != (d = this.W) ? d : this.l.j;
            b = new uL(this.context, this.V, b, c, !0, this.googletag.pubads(), this.googletag.display, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, this.googletag.cmd, e, this.l, this.G, this.T, !1, this.C);
            _.S(this, b);
            Sj(b)
        }
    };
    var st = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1082);
        this.googletag = b;
        this.W = c;
        this.G = d;
        this.v = e;
        this.T = f;
        this.C = V(this);
        this.l = new VN(this.context, this.C);
        this.Mb = this.l.Mb;
        _.S(this, this.l);
        this.K = W(this, g)
    };
    _.T(st, Z);
    st.prototype.j = function() {
        if (_.H(VB)) {
            for (var a = [], b = _.z(this.K.value), c = b.next(); !c.done; c = b.next()) switch (c = c.value, Dk(c, ey)) {
                case 5:
                    a.push(c);
                    break;
                case 8:
                    var d = c
            }
            this.C.Ca(null == d ? void 0 : _.Zh(d, Yx, 4));
            d = new Jj;
            _.S(this, d);
            a = _.z(a);
            for (b = a.next(); !b.done; b = a.next()) b = b.value, c = void 0, O(d, new XN(this.context, document, this.googletag, null != (c = this.W) ? c : this.v.j, this.G, this.v, this.T, _.Zh(b, $x, Gk(b, ey, 5)), _.Zh(b, Yx, 4)));
            O(d, this.l);
            Sj(d)
        } else this.Mb.aa()
    };
    var YN = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.context = a;
        this.A = b;
        this.m = c;
        this.T = d;
        this.L = e;
        this.j = f;
        this.ab = g;
        this.l = h
    };
    _.T(YN, _.U);
    var ZN = function(a, b, c, d) {
        var e = new Jj;
        _.S(a, e);
        var f = a.context;
        var g = a.j;
        var h = new Jj;
        g = new UN(f, g);
        O(h, g);
        var k = new TN(f, g.l);
        O(h, k);
        Sj(h);
        var l = k.l;
        var m = k.C;
        var n = k.v;
        f = k.pd;
        var p = k.Od;
        var r = k.G;
        g = k.uf;
        k = k.od;
        _.S(a, h);
        var w;
        h = new OL(a.context, document, Hm(), a.A, a.m, a.T, null != (w = window.location.hash) ? w : "");
        O(e, h);
        w = new st(a.context, Hm(), null, a.A, a.m, a.T, p);
        O(e, w);
        h = new SN(a.context, n);
        O(e, h);
        b = new EL(a.context, window, m, b);
        O(e, b);
        n = a.context;
        p = a.ab;
        m = {
            Rb: new yn,
            Yb: new yn,
            Xb: new yn,
            Wb: new yn,
            Fc: new yn,
            yc: new yn,
            af: new yn,
            bf: new yn,
            zf: new yn
        };
        var u = new Jj;
        O(u, new ZK(n, p, l, window, m));
        Sj(u);
        _.S(a, u);
        l = yp(a.context, a.j, b.l);
        p = l.tc;
        u = l.Dh;
        _.S(e, l.Ga);
        l = new xL(a.context, u);
        O(e, l);
        n = new yL(a.context, u);
        O(e, n);
        u = Wm(a.context, a.T, a.L, window, p, u);
        p = u.ib;
        _.S(a, u.Ga);
        if (_.H(PB)) {
            u = new AM(a.context, window.navigator, p);
            var x = u.l;
            O(e, u)
        }
        u = void 0;
        if (_.H(jC)) {
            var y = new aN(a.context, a.L, window, p);
            u = y.output;
            O(e, y)
        }
        y = a.context;
        if (_.H(oB) || im()) y = void 0;
        else {
            var C = {
                    qg: new yn,
                    sb: new yn
                },
                D = new Jj;
            O(D, new PM(y, f, p, C));
            Sj(D);
            y = {
                hf: C,
                Ga: D
            }
        }
        if (y) {
            var E = y.hf;
            _.S(a, y.Ga)
        }
        y = a.context;
        d = d.oe;
        C = window;
        D = !Xf(C.isSecureContext, C.document);
        Yf(C.isSecureContext, C, C.document) || !D ? (D = new Jj, d = new WM(y, C, d, p), O(D, d), Sj(D), d = d.l) : d = void 0;
        C = a.context;
        D = a.l;
        y = new Jj;
        c = new SM(C, D, c, p, r);
        O(y, c);
        Sj(y);
        _.S(a, y);
        Sj(e);
        return {
            de: m,
            hf: E,
            Zk: b.l,
            Lj: h.output,
            Mb: w.Mb,
            pd: f,
            Ae: l.Ae,
            uk: n.l,
            uf: g,
            pf: d,
            Ch: u,
            Oj: x,
            od: k
        }
    };
    var hu = function(a) {
        oG.call(this, function(b, c) {
            Lh(a, b, c);
            var d;
            null == (d = console) || d.error(c)
        })
    };
    _.T(hu, oG);
    var $N = function() {
        uN.apply(this, arguments)
    };
    _.T($N, uN);
    $N.prototype.l = function() {
        var a = this,
            b = this.m,
            c = b.Ei;
        b = b.ye;
        var d = vN(this);
        if (null == c ? 0 : c.length)
            if (_.kw) {
                c = _.z(c);
                for (var e = c.next(); !e.done; e = c.next()) d.sandbox.add(e.value)
            } else d.sandbox.add.apply(d.sandbox, _.lh(c));
        b && (d.allow = b);
        wN(this, d);
        Nh(this.context, 653, function() {
            var f;
            if (f = tj(a.jb.wb)) {
                var g = f.toString().toLowerCase();
                f = -1 < g.indexOf("<!doctype") || -1 < g.indexOf("<html") || _.H(uC) ? f : tj("<!doctype html><html><head><script>var inDapIF=true,inGptIF=true;\x3c/script></head><body>" + f + "</body></html>")
            }
            var h, k;
            g = null != (k = null == (h = d.contentWindow) ? void 0 : h.document) ? k : d.contentDocument;
            (La("Firefox") || La("FxiOS")) && g.open("text/html", "replace");
            g.write(_.Vv(f));
            var l, m, n;
            if (rv(null != (n = null == (l = d.contentWindow) ? void 0 : null == (m = l.location) ? void 0 : m.href) ? n : "", "#")) {
                var p, r;
                null == (p = d.contentWindow) || null == (r = p.history) || r.replaceState(null, "", "#" + Math.random())
            }
            g.close()
        }, !0);
        return d
    };
    $N.prototype.A = function() {
        return !0
    };
    var et = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D, E, J, M, K, X, ba) {
        Z.call(this, a, 680);
        this.slotId = b;
        this.L = c;
        this.P = d;
        this.ra = e;
        this.Ta = f;
        this.B = g;
        this.l = V(this);
        this.C = V(this);
        this.v = hG(this);
        this.K = W(this, h);
        this.Pa = W(this, k);
        jG(this, l);
        this.fa = W(this, m);
        this.G = W(this, n);
        this.da = W(this, p);
        jG(this, D);
        this.O = W(this, r);
        this.U = Y(this, w);
        this.Xa = Y(this, u);
        this.ba = W(this, x);
        this.Ia = Y(this, y);
        this.Bb = Y(this, C);
        jG(this, E);
        this.ya = W(this, J);
        jG(this, M);
        ba && jG(this, ba);
        this.ma = Y(this, K);
        X && (this.pa = Y(this, X))
    };
    _.T(et, Z);
    et.prototype.j = function() {
        var a = this.K.value;
        if (0 === a.kind && null == a.wb) throw new TE("invalid html");
        var b, c;
        a: {
            var d = this.context,
                e = {
                    V: document,
                    slotId: this.slotId,
                    L: this.L,
                    P: this.P,
                    ra: this.ra,
                    size: this.da.value,
                    Ki: this.fa.value,
                    gh: this.G.value,
                    Qf: this.O.value,
                    nk: this.U.value,
                    Ei: this.Xa.value,
                    isBackfill: this.ba.value,
                    Hk: _.H(bC) ? !1 : this.Ia.value,
                    Yd: this.Bb.value,
                    ye: this.ya.value,
                    km: null == (b = this.ma.value) ? void 0 : _.N(b, 14),
                    yf: null == (c = this.pa) ? void 0 : c.value,
                    Ta: this.Ta
                };b = this.Pa.value;c = a.kind;
            switch (c) {
                case 0:
                    a = new(b ? IM : $N)(d, a, e);
                    break a;
                case 2:
                    a = new xN(d, a, e);
                    break a;
                default:
                    _.db(c)
            }
            a = void 0
        }
        _.S(this, a);
        d = a.render();
        aO(this, this.B, d);
        this.B.top && this.B.top !== this.B && _.nk(this.B.top) && aO(this, this.B.top, d);
        this.v.notify();
        this.l.F(d);
        this.C.F(a.A())
    };
    var aO = function(a, b, c) {
        vn(a, a.id, b, "message", function(d) {
            c.contentWindow === d.source && Lr(a.slotId, Sp, 824, d)
        })
    };
    var Os = function(a, b, c, d, e) {
        Z.call(this, a, 720);
        this.format = b;
        this.na = c;
        this.output = V(this);
        this.l = Y(this, d);
        this.v = Y(this, e)
    };
    _.T(Os, Z);
    Os.prototype.j = function() {
        var a = this.v.value;
        if (null == a) this.output.aa();
        else {
            var b = Math.round(.3 * this.na),
                c;
            2 !== this.format && 3 !== this.format || null == (c = this.l.value) || !_.N(c, 12, !1) || 0 >= b || a <= b ? this.output.F(a) : this.output.F(b)
        }
    };
    var Ws = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        Z.call(this, a, 674);
        this.slotId = b;
        this.W = c;
        this.v = d;
        this.V = f;
        this.L = g;
        this.output = V(this);
        this.O = 2 === e || 3 === e;
        this.l = W(this, h);
        this.K = W(this, k);
        this.G = Y(this, l);
        this.C = Y(this, m);
        n && jG(this, n)
    };
    _.T(Ws, Z);
    Ws.prototype.j = function() {
        var a = Jo(this.W, this.v),
            b = Ei(this.slotId, this.V) || Gn(this.l.value, Ni(this.slotId), a);
        this.K.value && !a && (b.style.display = "inline-block");
        this.O ? yI(this.L, this.slotId, function() {
            return void _.fz(b)
        }) : _.tn(this, function() {
            return void _.fz(b)
        });
        a = bO(this);
        0 < a && (b.style.paddingTop = a + "px");
        this.output.F(b)
    };
    var bO = function(a) {
        var b = a.l.value,
            c, d = null == (c = a.G.value) ? void 0 : c.height;
        if (b && !a.C.value && d) {
            var e;
            c = (null != (e = Io(a.v, 23)) ? e : _.N(a.W, 31)) ? Math.floor((b.offsetHeight - d) / 2) : 0
        } else c = 0;
        return c
    };
    var Ms = function(a, b) {
        Z.call(this, a, 859);
        this.B = b;
        this.output = V(this)
    };
    _.T(Ms, Z);
    Ms.prototype.j = function() {
        this.output.F(!_.nk(this.B.top))
    };
    var bt = function(a, b, c) {
        Z.call(this, a, 840);
        this.format = b;
        this.V = c;
        this.output = V(this)
    };
    _.T(bt, Z);
    bt.prototype.j = function() {
        var a = [],
            b = this.V;
        b = void 0 === b ? document : b;
        var c;
        null != (c = b.featurePolicy) && (_.G = c.features(), _.A(_.G, "includes")).call(_.G, "attribution-reporting") && a.push("attribution-reporting");
        5 !== this.format && 4 !== this.format || !_.H(cB) || a.push("autoplay");
        a.length ? this.output.F(a.join(";")) : this.output.F("")
    };
    var Js = function(a, b, c, d) {
        Z.call(this, a, 1207);
        this.ra = c;
        this.slotId = d;
        jG(this, b)
    };
    _.T(Js, Z);
    Js.prototype.j = function() {
        Lr(this.ra, "impressionViewable", 715, new TL(this.slotId, "publisher_ads"))
    };
    var Is = function(a, b, c, d, e) {
        e = void 0 === e ? Gs : e;
        Z.call(this, a, 1121);
        this.V = b;
        this.K = e;
        this.output = hG(this);
        this.C = !1;
        this.G = W(this, c);
        jG(this, d)
    };
    _.T(Is, Z);
    Is.prototype.j = function() {
        var a = this;
        if (this.v = this.K(Hh(this.context, this.id, function(b) {
                b = _.z(b);
                for (var c = b.next(); !c.done; c = b.next()) c = 100 * c.value.intersectionRatio, _.A(Number, "isFinite").call(Number, c) && 50 <= c ? a.l || (a.C = !0, xF(a.V) || cO(a)) : (a.C = !1, dO(a))
            }))) _.tn(this, function() {
            var b;
            null == (b = a.v) || b.disconnect();
            dO(a)
        }), this.v.observe(this.G.value), this.O = vn(this, this.id, this.V, "visibilitychange", function() {
            xF(a.V) ? dO(a) : a.C && !a.l && cO(a)
        })
    };
    var cO = function(a) {
            a.l = setTimeout(function() {
                a.l = void 0;
                if (!xF(a.V)) {
                    a.output.notify();
                    var b;
                    null == (b = a.v) || b.disconnect();
                    var c;
                    null == (c = a.O) || c.call(a)
                }
            }, 1E3)
        },
        dO = function(a) {
            clearTimeout(a.l);
            a.l = void 0
        };
    var mt = function(a, b, c, d, e, f) {
        f = void 0 === f ? Ls : f;
        Z.call(this, a, 783);
        var g = this;
        this.slotId = b;
        this.V = d;
        this.ra = e;
        this.C = f;
        this.l = this.v = -1;
        this.K = _.fv(function() {
            Lr(g.ra, "slotVisibilityChanged", 716, new UL(g.slotId, "publisher_ads", g.l))
        }, 200);
        this.G = W(this, c);
        var h = new Cn;
        nI(this.slotId).then(function() {
            return void h.notify()
        });
        jG(this, h)
    };
    _.T(mt, Z);
    mt.prototype.j = function() {
        var a = this,
            b = this.C(Hh(this.context, this.id, function(c) {
                c = _.z(c);
                for (var d = c.next(); !d.done; d = c.next()) a.v = 100 * d.value.intersectionRatio, _.A(Number, "isFinite").call(Number, a.v) && eO(a)
            }));
        b && (b.observe(this.G.value), vn(this, this.id, this.V, "visibilitychange", function() {
            eO(a)
        }), _.tn(this, function() {
            b.disconnect()
        }))
    };
    var eO = function(a) {
        var b = Math.floor(xF(a.V) ? 0 : a.v);
        if (0 > b || 100 < b || b === a.l ? 0 : -1 !== a.l || 0 !== b) a.l = b, a.K()
    };
    var $s = function(a, b, c, d, e, f) {
        Z.call(this, a, 719);
        this.W = b;
        this.v = c;
        this.output = V(this);
        this.l = W(this, d);
        this.C = W(this, e);
        this.G = Y(this, f)
    };
    _.T($s, Z);
    $s.prototype.j = function() {
        var a = this.l.value.kind;
        switch (a) {
            case 0:
                if (this.l.value.wb)
                    if (this.C.value) {
                        a = this.G.value;
                        var b = new Kl;
                        a = Fj(b, 3, a);
                        _.N(Ql([a, this.W.kc(), this.v.kc()]), 3) ? this.output.F(MH) : this.output.aa()
                    } else this.output.aa();
                else this.output.aa();
                break;
            case 2:
                this.output.aa();
                break;
            default:
                _.db(a)
        }
    };
    var fO = function(a, b, c, d, e, f) {
        Z.call(this, a, 1119);
        this.slotId = b;
        this.v = c;
        this.documentElement = d;
        this.L = e;
        this.l = f;
        this.output = fG(this)
    };
    _.T(fO, Z);
    fO.prototype.j = function() {
        var a = _.gf("INS");
        a.id = this.v;
        (_.G = [8, 9], _.A(_.G, "includes")).call(_.G, this.l) || _.Si(a, {
            display: "none"
        });
        this.documentElement.appendChild(a);
        var b = function() {
            return void _.fz(a)
        };
        (_.G = [2, 3], _.A(_.G, "includes")).call(_.G, this.l) ? yI(this.L, this.slotId, b) : _.tn(this, b);
        this.output.F(a)
    };
    var gO = function(a, b, c, d, e) {
        Z.call(this, a, 1120);
        this.G = b;
        this.v = c;
        this.Kc = d;
        this.l = e;
        this.output = fG(this);
        a = this.l;
        if (!_.ka(a) || !_.ka(a) || 1 !== a.nodeType || a.namespaceURI && "http://www.w3.org/1999/xhtml" !== a.namespaceURI) this.C = W(this, this.l)
    };
    _.T(gO, Z);
    gO.prototype.j = function() {
        var a, b, c = null != (b = null == (a = this.C) ? void 0 : a.value) ? b : this.l;
        if (!(_.G = [2, 3], _.A(_.G, "includes")).call(_.G, this.v)) {
            a = _.z(_.A(Array, "from").call(Array, c.childNodes));
            for (b = a.next(); !b.done; b = a.next()) b = b.value, 1 === b.nodeType && b.id !== this.G && _.fz(b);
            this.Kc || (c.style.display = "")
        }
        this.output.F(c)
    };
    var Qs = function(a, b, c, d, e, f, g, h, k) {
        Jj.call(this);
        c ? (a = new gO(a, e, g, k, c), O(this, a), a = a.output) : 0 !== g && 1 !== g ? (a = new fO(a, b, d, f, h, g), O(this, a), a = a.output) : (b = new aq(a, b, oI, function(l) {
            return l.detail
        }), O(this, b), a = new gO(a, e, g, k, b.output), O(this, a), a = a.output);
        this.j = {
            output: a
        }
    };
    _.T(Qs, Jj);
    var hO = function(a, b) {
            var c = Pi();
            this.context = a;
            this.L = b;
            this.j = c
        },
        iO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x) {
            var y = document,
                C = window;
            e || f || GI(a.L, d);
            var D = tt(a.context, b, a.j, c, d, e, f, g, h, k, l, y, m, n, p, r, w, function() {
                GI(a.L, d);
                FI(a.L, d, D)
            }, u, x);
            f || FI(a.L, d, D);
            _.tn(d, function() {
                GI(a.L, d)
            });
            C.top !== C && C.addEventListener("pagehide", function(E) {
                E.persisted || GI(a.L, d)
            });
            Sj(D)
        };
    var jO = function(a, b, c, d) {
        Z.call(this, a, 884);
        this.za = b;
        this.ab = c;
        this.v = V(this);
        this.l = W(this, d)
    };
    _.T(jO, Z);
    jO.prototype.j = function() {
        GK(this.ab, _.Sl(this.za, "__gads", this.l.value));
        Xl(20, this.context, this.za, this.l.value);
        Xl(2, this.context, this.za, this.l.value);
        this.v.F(_.Uf())
    };
    var vt = 0,
        kO = new _.oi(-9, -9);
    var yt = new _.v.Set([function(a, b) {
        var c = a.ja.P.W;
        b.set("pvsid", {
            value: a.ia.context.pvsid
        }).set("correlator", {
            value: hr(c, 26)
        })
    }, function(a, b) {
        a = a.Xi;
        var c = a.ld;
        "wbn" === a.We && b.set("wbsu", {
            value: c
        })
    }, function(a, b) {
        var c = a.ja.P.W,
            d = a.om;
        a = d.dd;
        d = d.cd;
        var e = _.N(c, 21);
        b = b.set("hxva", {
            value: e ? 1 : null
        }).set("cmsid", {
            value: e ? _.Aj(c, 23) : null
        }).set("vid", {
            value: e ? _.Aj(c, 22) : null
        }).set("pod", {
            value: d
        }).set("ppos", {
            value: a
        });
        a = b.set;
        c = Zw(c, 29);
        a.call(b, "scor", {
            value: null == c ? void 0 : c
        })
    }, function(a, b) {
        var c = a.ja,
            d = c.X,
            e = c.P.R;
        c = a.yl;
        var f = c.Ak,
            g = c.vk;
        b.set("eid", {
            value: a.ia.Tf
        }).set("debug_experiment_id", {
            value: YE().split(",")
        }).set("expflags", {
            value: _.ki(253) ? dg(vB) || null : null
        }).set("pied", {
            value: function() {
                var h = new sG,
                    k = !1,
                    l = !1;
                f && (k = !0, Gj(h, 1, Yx, f));
                var m = d.map(function(p) {
                    var r = new qG,
                        w;
                    p = null == (w = e[p.getDomId()]) ? void 0 : _.bi(w, Yx, 27);
                    if (null == p || !p.length) return r;
                    l = k = !0;
                    w = _.z(p);
                    for (p = w.next(); !p.done; p = w.next()) Gj(r, 1, Yx, p.value);
                    return r
                });
                l && _.ol(h, 2, m);
                m = _.z(null != g ? g : []);
                for (var n = m.next(); !n.done; n = m.next()) Gj(h, 1, Yx, n.value), k = !0;
                return k ? Ab(h.j(), 3) : null
            }()
        })
    }, function(a, b) {
        var c = a.ia,
            d = c.context;
        c = c.Va;
        b.set("output", {
            value: a.Xi.We
        }).set("gdfp_req", {
            value: 1
        }).set("vrg", {
            value: d.wc ? String(d.wc) : d.eb
        }).set("ptt", {
            value: 17
        }).set("impl", {
            value: c ? "fifs" : "fif"
        })
    }, function(a, b) {
        var c = a.ia.Z;
        a = Ft(a.ja.P.W) || new WG;
        var d = _.Hk(a, 6, 2);
        b.set("rdp", {
            value: _.N(a, 1) ? "1" : null
        }).set("ltd", {
            value: _.N(a, 9) ? "1" : null
        }).set("gdpr_consent", {
            value: gx(c, 2)
        }).set("gdpr", {
            value: null != Pl(c, 3) ? _.N(c, 3) ? "1" : "0" : null,
            options: {
                Fa: !0
            }
        }).set("addtl_consent", {
            value: gx(c, 4)
        }).set("tcfe", {
            value: hx(c, 7)
        }).set("us_privacy", {
            value: gx(c, 1)
        }).set("npa", {
            value: _.N(c, 6) || _.N(a, 8) ? 1 : null
        }).set("puo", {
            value: _.H(UB) && _.N(a, 13) ? 1 : null
        }).set("tfua", {
            value: 2 !== d ? d : null,
            options: {
                Fa: !0
            }
        }).set("tfcd", {
            value: null != jo(a, 5) ? _.Hk(a, 5, 0) : null,
            options: {
                Fa: !0
            }
        }).set("trt", {
            value: null != jo(a, 10) ? _.Hk(a, 10, 0) : null,
            options: {
                Fa: !0
            }
        }).set("tad", {
            value: null != Pl(c, 8) ? _.N(c, 8) ? "1" : "0" : null,
            options: {
                Fa: !0
            }
        }).set("gpp", {
            value: gx(c, 11)
        }).set("gpp_sid", {
            value: $w(c, 10).join(",") || void 0
        })
    }, function(a, b) {
        var c = a.ja,
            d = c.P,
            e = c.X,
            f = c.cg,
            g = a.ia.B;
        a = {
            Ba: "~"
        };
        var h = e.map(function(l) {
                return d.R[l.getDomId()]
            }),
            k = [];
        c = e.map(function(l) {
            return l.getAdUnitPath().replace(/,/g, ":").split("/").map(function(m) {
                if (!m) return "";
                var n = _.A(k, "findIndex").call(k, function(p) {
                    return p === m
                });
                return 0 <= n ? n : k.push(m) - 1
            }).join("/")
        });
        b.set("iu_parts", {
            value: k
        }).set("enc_prev_ius", {
            value: c
        }).set("prev_iu_szs", {
            value: h.map(function(l) {
                return hi(l)
            })
        }).set("fluid", {
            value: function() {
                var l = !1,
                    m = h.map(function(n) {
                        n = (_.G = gi(n), _.A(_.G, "includes")).call(_.G, "fluid");
                        l || (l = n);
                        return n ? "height" : "0"
                    });
                return l ? m : null
            }()
        }).set("ifi", {
            value: function() {
                var l = gj(g);
                if (!f) {
                    l += 1;
                    var m = g,
                        n = e.length;
                    n = void 0 === n ? 1 : n;
                    m = Rz($e(m)) || m;
                    m.google_unique_id = (m.google_unique_id || 0) + n
                }
                return l
            }()
        }).set("didk", {
            value: _.H(ZB) ? Do(e, function(l) {
                return _.$f(l.getDomId())
            }, a) : null,
            options: _.A(Object, "assign").call(Object, {}, a, {
                Nb: !0
            })
        })
    }, function(a, b) {
        var c = a.ja;
        a = c.X;
        c = c.P;
        var d = c.W,
            e = c.R;
        b.set("sfv", {
            value: aK ? aK : aK = Fl()
        }).set("fsfs", {
            value: Do(a, function(f) {
                f = e[f.getDomId()];
                var g;
                return Number(null != (g = null == f ? void 0 : Io(f, 12)) ? g : Pl(d, 13))
            }, {
                rd: 0
            }),
            options: {
                Ba: ",",
                md: 0,
                Nb: !0
            }
        }).set("fsbs", {
            value: Do(a, function(f) {
                f = e[f.getDomId()].kc();
                var g = d.kc(),
                    h;
                return (null != (h = null == f ? void 0 : Io(f, 3)) ? h : null == g ? 0 : _.N(g, 3)) ? 1 : 0
            }, {
                rd: 0
            }),
            options: {
                md: 0,
                Nb: !0
            }
        })
    }, function(a, b) {
        var c = a.ia.L;
        a = a.ja;
        var d = a.cg;
        b.set("rcs", {
            value: Do(a.X, function(e) {
                if (!d) {
                    var f = c.j.get(e);
                    f && f.Ai++
                }
                return EI(c, e)
            }, {
                rd: 0
            }),
            options: {
                md: 0,
                Nb: !0
            }
        })
    }, function(a, b) {
        var c = a.ja;
        a = a.ia.Va;
        c = c.P.R[c.X[0].getDomId()];
        b.set("click", {
            value: !a && c.getClickUrl() ? _.Aj(c, 7) : null
        })
    }, function(a, b, c) {
        var d = a.ja,
            e = d.X,
            f = d.P.R;
        a = a.ia;
        var g = a.Z,
            h = a.B;
        c = void 0 === c ? function(n, p) {
            return Mf(n, p)
        } : c;
        a = e.map(function(n) {
            return f[n.getDomId()]
        });
        var k, l, m;
        b.set("ists", {
            value: Ao(a, function(n) {
                var p;
                if (p = 0 !== Ps(n)) n = Ps(n), p = !(8 === n || 9 === n);
                return p
            }) || null
        }).set("fas", {
            value: Do(a, function(n) {
                return Zo(Ps(n))
            }, {
                rd: 0
            }),
            options: {
                md: 0,
                Nb: !0
            }
        }).set("itsi", {
            value: e.some(function(n) {
                var p;
                return !rL(n) && 5 === (null == (p = f[n.getDomId()]) ? void 0 : Ps(p))
            }) ? function() {
                var n = c(g, h);
                if (!n) return 1;
                var p;
                n = Math.max.apply(Math, _.lh(null != (p = _.Xo(n, 604800)) ? p : []));
                return isFinite(n) ? Math.floor(Math.max((Date.now() - n) / 6E4, 1)) : null
            }() : null
        }).set("fsapi", {
            value: Ao(a, function(n) {
                return 5 === Ps(n) && _.H(_.DB)
            }) || null
        }).set("ifs", {
            value: null != (m = null == (k = (_.G = _.A(Object, "values").call(Object, f), _.A(_.G, "find")).call(_.G, function(n) {
                return In(n, pK, 29)
            })) ? void 0 : null == (l = _.Zh(k, pK, 29)) ? void 0 : Ak(l)) ? m : null
        })
    }, function(a, b) {
        a = a.ja;
        var c = a.P.R;
        a = a.X.map(function(d) {
            return c[d.getDomId()]
        });
        b.set("rbvs", {
            value: Ao(a, function(d) {
                return 4 === Ps(d)
            }) || null
        })
    }, function(a, b) {
        var c = a.ja,
            d = a.ia;
        a = d.isSecureContext;
        d = d.B;
        var e = b.set;
        var f = c.X;
        var g = c.P;
        c = c.Sb;
        var h = g.W,
            k = g.R,
            l = new $i;
        l.set(0, 1 !== c);
        k = k[f[0].getDomId()];
        l.set(1, !!_.N(k, 17));
        l.set(2, Ip(f, g));
        l.set(3, _.N(h, 27) || !1);
        l.set(4, 3 === c);
        f = bj(l);
        e.call(b, "eri", {
            value: f
        }).set("gct", {
            value: Ap("google_preview", d)
        }).set("sc", {
            value: a ? 1 : 0,
            options: {
                Fa: !0
            }
        })
    }, function(a, b) {
        var c = a.ia,
            d = c.B,
            e = c.Z;
        c = c.za;
        var f = Fp(a.ja.P.W.Ma()),
            g = _.Sl(c, "__gads", e);
        a = "1" === _.Sl(c, "__gpi_opt_out", e) ? "1" : null;
        b = b.set("cookie", {
            value: g,
            options: {
                Fa: !0
            }
        }).set("cookie_enabled", {
            value: !g && fF(c, e) ? "1" : null
        });
        g = d.document;
        var h = g.domain;
        d = b.set.call(b, "cdm", {
            value: (f || mi(d)) === g.URL ? "" : h
        });
        f = d.set;
        e = (e = _.Sl(c, "__gpi", e)) && !_.A(e, "includes").call(e, "&") ? e : null;
        f.call(d, "gpic", {
            value: e
        }).set("pdopt", {
            value: a
        })
    }, function(a, b) {
        a = a.ia.B;
        b.set("arp", {
            value: xn(a) ? 1 : null
        }).set("abxe", {
            value: _.nk(a.top) || yz(a.IntersectionObserver) ? 1 : null
        })
    }, function(a, b) {
        var c = a.ia.B;
        a = Fp(a.ja.P.W.Ma());
        b.set("dt", {
            value: (new Date).getTime()
        });
        if (!a) {
            try {
                var d = Math.round(Date.parse(c.document.lastModified) / 1E3) || null
            } catch (e) {
                d = null
            }
            b.set("lmt", {
                value: d
            })
        }
    }, function(a, b) {
        var c = a.ja,
            d = c.P;
        c = c.X;
        var e = a.ia;
        a = e.B;
        var f = e.Va;
        e = fi(!0, a);
        for (var g = d.W, h = a.document, k = d.R, l = [], m = [], n = _.z(c), p = n.next(); !p.done; p = n.next()) {
            p = p.value;
            var r = k[p.getDomId()];
            p = Li(p, r, h, Jo(g, r));
            r = void 0;
            var w = f ? null != (r = p) ? r : kO : p;
            w && (l.push(Math.round(w.x)), m.push(Math.round(w.y)))
        }
        e && (d.ed = e);
        f = li(a) ? null : fi(!1, a);
        try {
            var u = a.top;
            var x = ut(u.document, u)
        } catch (y) {
            x = new _.oi(-12245933, -12245933)
        }
        b.set("adxs", {
            value: l,
            options: {
                Fa: !0
            }
        }).set("adys", {
            value: m,
            options: {
                Fa: !0
            }
        }).set("biw", {
            value: e ? e.width : null
        }).set("bih", {
            value: e ? e.height : null
        }).set("isw", {
            value: e ? null == f ? void 0 : f.width : null
        }).set("ish", {
            value: e ? null == f ? void 0 : f.height : null
        }).set("scr_x", {
            value: Math.round(x.x),
            options: {
                Fa: !0
            }
        }).set("scr_y", {
            value: Math.round(x.y),
            options: {
                Fa: !0
            }
        }).set("btvi", {
            value: wt(c, a, d),
            options: {
                Fa: !0,
                Ba: "|"
            }
        })
    }, function(a, b) {
        var c = a.ia.L;
        b.set("ucis", {
            value: a.ja.X.map(function(d) {
                d = c.j.get(d);
                null != d.Yd || (d.Yd = window === window.top ? (++c.M).toString(36) : Sy());
                return d.Yd
            }),
            options: {
                Ba: "|"
            }
        }).set("oid", {
            value: 2
        })
    }, function(a, b) {
        a = a.ja;
        var c = a.X,
            d = a.P,
            e = d.R;
        a = new _.v.Map;
        d = _.z(d.W.Ma());
        for (var f = d.next(); !f.done; f = d.next()) {
            var g = f.value;
            a.set(_.R(g, 1), [_.jl(g, 2)[0]])
        }
        for (d = 0; d < c.length; d++)
            if (g = e[c[d].getDomId()])
                for (g = _.z(g.Ma()), f = g.next(); !f.done; f = g.next()) {
                    var h = f.value;
                    f = _.R(h, 1);
                    var k = a.get(f) || [];
                    h = _.jl(h, 2)[0];
                    1 === c.length ? k[0] = h : h !== k[0] && (k[d + 1] = h);
                    a.set(f, k)
                }
        c = [];
        e = _.z(_.A(a, "keys").call(a));
        for (d = e.next(); !d.done; d = e.next()) g = d.value, d = yl()[g], g = a.get(g), d && g && (1 < g.length ? (g = g.map(function(l) {
            return encodeURIComponent(l || "")
        }).join(), c.push(d + "," + g)) : 1 === g.length && "url" !== d && b.set(d, {
            value: g[0]
        }));
        c.length && b.set("sps", {
            value: c,
            options: {
                Ba: "|"
            }
        })
    }, function(a, b) {
        a = a.ia.B;
        var c, d, e, f, g, h, k;
        var l = a;
        l = void 0 === l ? Ny : l;
        try {
            var m = l.history.length
        } catch (D) {
            m = 0
        }
        b = b.set("u_his", {
            value: m
        }).set("u_h", {
            value: null == (c = a.screen) ? void 0 : c.height
        }).set("u_w", {
            value: null == (d = a.screen) ? void 0 : d.width
        }).set("u_ah", {
            value: null == (e = a.screen) ? void 0 : e.availHeight
        }).set("u_aw", {
            value: null == (f = a.screen) ? void 0 : f.availWidth
        }).set("u_cd", {
            value: null == (g = a.screen) ? void 0 : g.colorDepth
        });
        c = b.set;
        d = a;
        d = void 0 === d ? _.t : d;
        d = d.devicePixelRatio;
        c = c.call(b, "u_sd", {
            value: "number" === typeof d ? +d.toFixed(3) : null
        }).set("u_tz", {
            value: -(new Date).getTimezoneOffset()
        }).set("dmc", {
            value: null != (k = null == (h = a.navigator) ? void 0 : h.deviceMemory) ? k : null
        });
        h = c.set;
        k = a;
        k = void 0 === k ? _.t : k;
        d = new $i;
        "SVGElement" in k && "createElementNS" in k.document && d.set(0);
        e = xz();
        e["allow-top-navigation-by-user-activation"] && d.set(1);
        e["allow-popups-to-escape-sandbox"] && d.set(2);
        k.crypto && k.crypto.subtle && d.set(3);
        "TextDecoder" in k && "TextEncoder" in k && d.set(4);
        k = bj(d);
        h = h.call(c, "bc", {
            value: k
        });
        k = h.set;
        a: {
            try {
                var n, p, r = null == (n = a.performance) ? void 0 : null == (p = n.getEntriesByType("navigation")) ? void 0 : p[0];
                if (null == r ? 0 : r.type) {
                    var w;
                    var u = null != (w = qF.get(r.type)) ? w : null;
                    break a
                }
            } catch (D) {}
            var x, y, C;u = null != (C = rF.get(null == (x = a.performance) ? void 0 : null == (y = x.navigation) ? void 0 : y.type)) ? C : null
        }
        u = k.call(h, "nvt", {
            value: u
        });
        n = u.set;
        p = _.cg(gB);
        p = 0 === p ? null : Lz(a, 2 === p);
        u = n.call(u, "bz", {
            value: p
        });
        n = u.set;
        _.H(aC) ? a = Na() && Ik(a) ? a.document.documentElement.lang : void 0 : a = null;
        n.call(u, "tl", {
            value: a
        })
    }, function(a, b) {
        (a = _.ki(251)) && b.set("uach", {
            value: Bw(a, 3)
        })
    }, function(a, b) {
        a = a.ia;
        if (!a.Fb) {
            var c;
            if (a = null == (c = a.B.navigator) ? void 0 : c.userActivation) {
                c = 0;
                if (null == a ? 0 : a.hasBeenActive) c |= 1;
                if (null == a ? 0 : a.isActive) c |= 2
            } else c = void 0;
            c && b.set("uas", {
                value: c
            })
        }
    }, function(a, b) {
        var c = a.ia,
            d = c.B,
            e = c.L;
        c = c.Va;
        a = a.ja;
        var f = a.X;
        a = a.P;
        var g = a.W,
            h = a.R;
        a = Bp("google_preview", d);
        var k = d.document,
            l = a ? Gp(k.URL) : k.URL;
        k = a ? Gp(k.referrer) : k.referrer;
        a = !1;
        if (c) c = Fp(g.Ma());
        else {
            var m;
            c = null != (m = Fp(h[f[0].getDomId()].Ma())) ? m : Fp(g.Ma())
        }
        if (null != c) {
            var n = l;
            li(d) || (k = "", a = !0)
        } else c = l;
        m = Hp(d);
        b.set("nhd", {
            value: m || null
        }).set("url", {
            value: c
        }).set("loc", {
            value: null !== n && n !== c ? n : null
        }).set("ref", {
            value: k
        });
        if (m) {
            n = b.set;
            var p, r;
            m = _.nk(d.top) && (null == (p = d.top) ? void 0 : null == (r = p.location) ? void 0 : r.href);
            var w;
            p = null == (w = d.location) ? void 0 : w.ancestorOrigins;
            d = Mk(d) || "";
            w = (null == p ? void 0 : p[p.length - 1]) || "";
            d = (d = m || d || w) ? a ? mz(d.match(_.lz)[3] || null) : d : null;
            n.call(b, "top", {
                value: d
            }).set("etu", {
                value: e.re
            })
        }
    }, function(a, b) {
        a = a.ia.context.pvsid;
        b.set("rumc", {
            value: _.H(tC) || _.Rf(Jh).j ? a : null
        }).set("rume", {
            value: _.H(sC) ? 1 : null
        })
    }, function(a, b) {
        b.set("vis", {
            value: _.rq(a.ia.B.document)
        })
    }, function(a, b) {
        var c = a.ja,
            d = c.X;
        c = c.P;
        a = a.ia.B;
        var e = Kn(d, c.R, c.W),
            f = Nn(d, e, a);
        c = f.dl;
        f = f.Ul;
        var g = Qn(d, e, a),
            h = g.qk;
        g = g.cl;
        null != OK || (OK = Ok(a));
        var k = !1;
        d = d.map(function(m) {
            var n;
            m = null != (n = e.get(m)) ? n : 0;
            if (0 === m) return null;
            k = !0;
            return 2 === m ? "1" : "0"
        });
        var l;
        b.set("aee", {
            value: k ? d : null,
            options: {
                Ba: "|"
            }
        }).set("psz", {
            value: c,
            options: {
                Ba: "|"
            }
        }).set("msz", {
            value: f,
            options: {
                Ba: "|"
            }
        }).set("fws", {
            value: h,
            options: {
                Fa: !0
            }
        }).set("ohw", {
            value: g,
            options: {
                Fa: !0
            }
        }).set("ea", {
            value: OK ? null : "0",
            options: {
                Fa: !0
            }
        }).set("efat", {
            value: "#flexibleAdSlotTest" === (null == (l = a.location) ? void 0 : l.hash) ? "1" : null
        })
    }, function(a, b) {
        b.set("psts", {
            value: DI(a.ia.L, a.ja.X)
        })
    }, function(a, b) {
        var c = a.ia;
        a = c.Z;
        c = c.B;
        var d;
        var e = c.document.domain,
            f = null != (d = Lf(a) && Nf(c) ? c.document.cookie : null) ? d : "",
            g = c.history.length,
            h = c.screen,
            k = c.document.referrer;
        if ($e()) var l = window.gaGlobal || {};
        else {
            var m = Math.round((new Date).getTime() / 1E3),
                n = c.google_analytics_domain_name;
            e = "undefined" == typeof n ? wE("auto", e) : wE(n, e);
            var p = -1 < f.indexOf("__utma=" + e + "."),
                r = -1 < f.indexOf("__utmb=" + e);
            (d = (Rz() || window).gaGlobal) || (d = {}, (Rz() || window).gaGlobal = d);
            var w = !1;
            if (p) {
                var u = f.split("__utma=" + e + ".")[1].split(";")[0].split(".");
                r ? d.sid = u[3] : d.sid || (d.sid = m + "");
                d.vid = u[0] + "." + u[1];
                d.from_cookie = !0
            } else {
                d.sid || (d.sid = m + "");
                if (!d.vid) {
                    w = !0;
                    r = Math.round(2147483647 * Math.random());
                    p = uE.appName;
                    var x = uE.version,
                        y = uE.language ? uE.language : uE.browserLanguage,
                        C = uE.platform,
                        D = uE.userAgent;
                    try {
                        u = uE.javaEnabled()
                    } catch (E) {
                        u = !1
                    }
                    u = [p, x, y, C, D, u ? 1 : 0].join("");
                    h ? u += h.width + "x" + h.height + h.colorDepth : _.t.java && _.t.java.awt && (h = _.t.java.awt.Toolkit.getDefaultToolkit().getScreenSize(), u += h.screen.width + "x" + h.screen.height);
                    u = u + f + (k || "");
                    for (k = u.length; 0 < g;) u += g-- ^ k++;
                    d.vid = (r ^ vE(u) & 2147483647) + "." + m
                }
                d.from_cookie || (d.from_cookie = !1)
            }
            if (!d.cid) {
                b: for (m = 999, n && (n = 0 == n.indexOf(".") ? n.substr(1) : n, m = n.split(".").length), n = 999, f = f.split(";"), u = 0; u < f.length; u++)
                    if (k = xE.exec(f[u]) || yE.exec(f[u]) || zE.exec(f[u])) {
                        h = k[1] || 0;
                        if (h == m) {
                            l = k[2];
                            break b
                        }
                        h < n && (n = h, l = k[2])
                    }w && l && -1 != l.search(/^\d+\.\d+$/) ? (d.vid = l, d.from_cookie = !0) : l != d.vid && (d.cid = l)
            }
            d.dh = e;
            d.hid || (d.hid = Math.round(2147483647 * Math.random()));
            l = d
        }
        e = l.sid;
        d = l.hid;
        w = l.from_cookie;
        f = l.cid;
        w && !Lf(a) || b.set("ga_vid", {
            value: l.vid
        }).set("ga_sid", {
            value: e
        }).set("ga_hid", {
            value: d
        }).set("ga_fc", {
            value: w
        }).set("ga_cid", {
            value: f
        }).set("ga_wpids", {
            value: c.google_analytics_uacct
        })
    }, function(a, b) {
        var c = a.ia.B,
            d = a.jm;
        a = d.Cg;
        var e = d.ze;
        d = d.Rl;
        if (!_.H(vC) && !d) {
            Wf(c.isSecureContext, c.navigator, c.document) && b.set("td", {
                value: 1
            });
            if (a) switch (a.kind) {
                case 0:
                    b.set("eig", {
                        value: a.signal
                    });
                    break;
                case 1:
                    b.set("eigir", {
                        value: a.reason,
                        options: {
                            Fa: !0
                        }
                    });
                    break;
                default:
                    _.db(a)
            }
            void 0 !== e && b.set("egid", {
                value: e,
                options: {
                    Fa: !0
                }
            })
        }
    }, function(a, b) {
        var c = a.ia.B,
            d = a.Zl;
        a = d.cm;
        d = d.am;
        Xf(c.isSecureContext, c.document) && (b.set("topics", {
            value: a instanceof Uint8Array ? Ab(a, 3) : a
        }), !a || a instanceof Uint8Array || b.set("tps", {
            value: a
        }), d && b.set("htps", {
            value: d
        }))
    }, function(a, b) {
        var c = a.ia,
            d = c.B,
            e = c.Z,
            f = a.ja.X;
        c = a.Il;
        a = c.Ze;
        var g = c.ek,
            h = c.Xk;
        if (!_.H(pB)) {
            c = b.set;
            d = Mf(e, d);
            f = nh(f[0].getAdUnitPath());
            e = new sy;
            g = null != g ? g : [];
            if (f && a && g && "function" === typeof a.getUserIdsAsEidBySource) {
                if ("function" === typeof a.getUserIdsAsEids) try {
                    for (var k = _.z(a.getUserIdsAsEids()), l = k.next(); !l.done; l = k.next()) {
                        var m = l.value;
                        "string" === typeof m.source && wj(52, m.source)
                    }
                } catch (w) {
                    var n;
                    wj(45, "", null == (n = w) ? void 0 : n.message)
                }
                k = _.z(g);
                for (l = k.next(); !l.done; l = k.next())
                    if (l = l.value, String(_.R(l, 1)) === f)
                        for (l = _.z(_.bi(l, Lx, 2)), m = l.next(); !m.done; m = l.next())
                            if (m = m.value, _.N(m, Gk(m, Mx, 3)) && (m = _.R(m, 1), !Bj(e, m))) {
                                n = null;
                                try {
                                    var p = g = void 0,
                                        r = void 0;
                                    n = null == (g = a.getUserIdsAsEidBySource(m)) ? void 0 : null == (p = g.uids) ? void 0 : null == (r = p[0]) ? void 0 : r.id
                                } catch (w) {
                                    g = void 0, wj(45, m, null == (g = w) ? void 0 : g.message)
                                }
                                n && (300 < n.length ? (g = {}, wj(12, m, null, (g.sl = String(n.length), g.fp = "1", g))) : (g = ny(m), g = Vn(g, 2, n), g = Fj(g, 11, !0), Gj(e, 2, zj, g), g = {}, wj(19, m, null, (g.fp = "1", g.hs = n ? "1" : "0", g))))
                            }
            }
            Hj(e, d, f, h);
            _.bi(e, zj, 2).length ? (wj(50, ""), a = Ab(e.j(), 3)) : a = null;
            c.call(b, "a3p", {
                value: a
            })
        }
    }, function(a, b) {
        var c = a.hb.ee,
            d = a.ja.X;
        a = {
            Ba: "~"
        };
        var e = function() {
            return c ? d.map(function(f) {
                return c.get(f)
            }) : []
        }();
        b.set("cbidsp", {
            value: Do(e, function(f) {
                return Ab(f.j(), 3)
            }, a),
            options: _.A(Object, "assign").call(Object, {}, a, {
                Nb: !0
            })
        })
    }, function(a, b) {
        a = a.ja.P.W;
        In(a.Fe(), ss, 1) && (a = rs(a.Fe(), ss, 1), b.set("cmrv", {
            value: 1
        }).set("cmrq", {
            value: _.R(a, 1)
        }).set("cmrc", {
            value: _.jl(a, 2),
            options: {
                Ba: ">"
            }
        }).set("cmrids", {
            value: _.jl(a, 3),
            options: {
                Ba: "!"
            }
        }).set("cmrf", {
            value: _.R(a, 4)
        }))
    }, function(a, b) {
        var c = [];
        a = _.z(_.bi(rs(a.ja.P.W.Fe(), us, 2), iq, 1));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, _.jl(d, 2).length && c.push(_.Hk(d, 1, 0) + 2 + "=" + _.jl(d, 2).join("|"));
        b.set("pps", {
            value: c,
            options: {
                Ba: "~"
            }
        })
    }, function(a, b) {
        b.set("scar", {
            value: a.gl.zk
        })
    }, function(a, b) {
        a = a.ia.B;
        a = !(!a.isSecureContext || !Vf("attribution-reporting", a.document));
        !_.H(rC) && a && b.set("nt", {
            value: 1
        })
    }, function(a, b) {
        if (a = a.tl.rl) a = Bw(Ak(a), 3), b.set("psd", {
            value: a
        })
    }, function(a, b) {
        a = _.Yg(a.ia.B);
        var c = Jp;
        0 < a && c >= a && b.set("dlt", {
            value: a
        }).set("idt", {
            value: c - a
        })
    }, function(a, b) {
        a = a.ja.P.W;
        b.set("ppid", {
            value: null != _.Aj(a, 16) ? _.R(a, 16) : null,
            options: {
                Fa: !0
            }
        })
    }, function(a, b) {
        var c = b.set;
        (a = _.Aj(a.ja.P.W, 8)) ? (50 < a.length && (a = a.substring(0, 50)), a = "a " + Bw('role:1 producer:12 loc:"' + a + '"')) : a = "";
        c.call(b, "uule", {
            value: a
        })
    }, function(a, b) {
        a = a.ja;
        var c = a.P.W;
        b.set("prev_scp", {
            value: $q(a.X, a.P),
            options: {
                Nb: !0,
                Ba: "|"
            }
        }).set("cust_params", {
            value: br(c),
            options: {
                Ba: "&"
            }
        })
    }, function(a, b) {
        var c = a.ja,
            d = c.P;
        a = a.ia;
        var e = a.L,
            f = a.Va;
        b.set("adks", {
            value: c.X.map(function(g) {
                if (f) {
                    var h = d.R[g.getDomId()];
                    h = qn(h);
                    if (g = e.j.get(g)) g.gd = h;
                    return h
                }
                h = d.W;
                var k = d.R[g.getDomId()],
                    l;
                if (!(l = ot(e, g))) {
                    h = qn(k, _.N(h, 6) || _.N(k, 17) ? null : Fi(g));
                    if (g = e.j.get(g)) g.gd = h;
                    l = h
                }
                return l
            })
        })
    }, function(a, b) {
        var c = b.set;
        a = a.ia.B;
        var d = Kz(a);
        var e = Nk(a, a.google_ad_width, a.google_ad_height);
        var f = d.location.href;
        if (d === d.top) f = !0;
        else {
            var g = !1,
                h = d.document;
            h && h.referrer && (f = h.referrer, d.parent === d.top && (g = !0));
            (d = d.location.ancestorOrigins) && (d = d[d.length - 1]) && -1 === f.indexOf(d) && (g = !1);
            f = g
        }
        g = a.top == a ? 0 : _.nk(a.top) ? 1 : 2;
        d = 4;
        e || 1 != g ? e || 2 != g ? e && 1 == g ? d = 7 : e && 2 == g && (d = 8) : d = 6 : d = 5;
        f && (d |= 16);
        e = "" + d;
        if (a != a.top)
            for (; a && a != a.top && _.nk(a) && !a.sf_ && !a.$sf && !a.inGptIF && !a.inDapIF; a = a.parent);
        c.call(b, "frm", {
            value: e || null
        })
    }, function(a, b) {
        var c = b.set;
        a = rs(a.ja.P.W, xs, 36);
        a = Xd(a, 1, Kc);
        c.call(b, "ppt", {
            value: a,
            options: {
                Ba: "~"
            }
        })
    }, function(a, b) {
        a = a.ia.B;
        try {
            var c, d, e = null == (c = a.external) ? void 0 : null == (d = c.getHostEnvironmentValue) ? void 0 : d.call(c, "os-mode");
            if (e) {
                var f = Number(JSON.parse(e)["os-mode"]);
                0 > f || b.set("wsm", {
                    value: f + 1
                })
            }
        } catch (g) {}
    }, function(a, b) {
        var c = a.ja;
        a = c.P.R;
        var d = [],
            e = !1;
        c = _.z(c.X);
        for (var f = c.next(); !f.done; f = c.next()) {
            var g = void 0;
            (null == (g = a[f.value.getDomId()]) ? 0 : _.N(g, 30)) ? (d.push("1"), e = !0) : d.push("")
        }
        b.set("is_cau", {
            value: e ? d : null
        })
    }, function(a, b) {
        var c = a.ja,
            d = c.P.R;
        a = a.ia.B;
        var e = [],
            f = !1;
        c = _.z(c.X);
        for (var g = c.next(); !g.done; g = c.next()) g = Ps(d[g.value.getDomId()]), (_.G = [8, 9], _.A(_.G, "includes")).call(_.G, g) ? (f = 9 === g ? "right" : "left", e.push(_.jh(a).sideRailPlasParam.get(f)), f = !0) : e.push("");
        f && b.set("plas", {
            value: e,
            options: {
                Ba: "|"
            }
        })
    }, function(a, b) {
        var c = a.ia,
            d = c.B;
        c = c.Z;
        var e = a.ja,
            f = e.P.W;
        e = e.networkCode;
        a = a.bk.ck;
        if (_.H(jB)) {
            a = a ? !ge(a, 1, kd).get(e) : _.H(kB);
            var g;
            f = !(null == (g = Ft(f)) || !_.N(g, 9));
            d = new HE(d, {
                xl: a,
                wl: f
            });
            d = _.N(c, 8) || (d.options.wl || !Lf(c)) && d.options.xl ? void 0 : (new Of(d.j.document)).get("__eoi") || "";
            d && b.set("eo_id_str", {
                value: d
            })
        }
    }]);
    var lO = function(a, b, c) {
        Z.call(this, a, 798);
        this.output = V(this);
        this.l = Y(this, b);
        this.v = W(this, c)
    };
    _.T(lO, Z);
    lO.prototype.j = function() {
        var a = this,
            b = new _.v.Map;
        if (this.l.value) {
            var c = this.l.value,
                d = c.ia.Va,
                e = c.hb.ee;
            c = _.z(c.ja.X);
            for (var f = c.next(); !f.done; f = c.next()) {
                f = f.value;
                var g = void 0,
                    h = null == (g = e) ? void 0 : g.get(f);
                b.set(f, d ? mO(this, f, h) : function() {
                    return a.v.value
                })
            }
        }
        this.output.F(b)
    };
    var mO = function(a, b, c) {
        return Gi(function() {
            var d = _.A(Object, "assign").call(Object, {}, a.l.value);
            d.ja.cg = !0;
            d.ja.X = [b];
            c && (d.hb.ee = new _.v.Map, d.hb.ee.set(b, c));
            return zp(Et(d)).url
        })
    };
    var nO = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 810);
        this.v = b;
        this.Va = c;
        this.P = d;
        this.T = e;
        this.B = f;
        this.Z = g;
        this.l = V(this)
    };
    _.T(nO, Z);
    nO.prototype.j = function() {
        var a = this,
            b = this.v;
        !this.Va && 1 < this.v.length && (b = [b[0]]);
        b = b.filter(function(c) {
            if (c.J) return !1;
            var d = a.P.R[c.getDomId()],
                e;
            if (e = !(cp(Ps(d)) && (_.G = eg(LB), _.A(_.G, "includes")).call(_.G, String(Ps(d))))) e = a.T, Eg(a.B) && 4 === Ps(d) ? (Q(e, qJ("googletag.enums.OutOfPageFormat.REWARDED", String(c.getAdUnitPath()))), e = !0) : e = !1, e = !e;
            if (e) {
                e = a.T;
                var f = a.B,
                    g = a.Z;
                d = Ps(d);
                5 !== d ? c = !1 : (f = Yo(f, !rL(c), g), (f &= -134217729) && No(e, f, d, c.getAdUnitPath()), c = !!f);
                e = !c
            }
            return e
        });
        30 < b.length && (Q(this.T, pJ("30", String(b.length), String(b.length - 30))), b = b.slice(0, 30));
        this.l.F(b)
    };
    var oO = function(a, b, c) {
        Z.call(this, a, 919);
        this.l = b;
        this.Z = c;
        this.output = V(this)
    };
    _.T(oO, Z);
    oO.prototype.j = function() {
        var a, b = !(null == (a = this.l) ? 0 : _.N(a, 9)) && !!Lf(this.Z);
        this.output.F(b)
    };
    var pO = function(a, b, c, d, e, f) {
        Z.call(this, a, 928);
        this.requestId = b;
        this.C = f;
        this.output = hG(this);
        this.v = W(this, c);
        e && (this.l = W(this, e));
        jG(this, d)
    };
    _.T(pO, Z);
    var qO = function(a) {
        return a.l ? a.C.split(",").some(function(b) {
            var c;
            return null == (c = a.l) ? void 0 : c.value.has(b)
        }) : !1
    };
    pO.prototype.j = function() {
        var a = this.context,
            b = this.requestId,
            c = this.v.value.length,
            d = qO(this);
        if (a.Bc) {
            var e = a.Qa,
                f = e.Ac;
            a = uh(a);
            var g = new NA;
            b = _.qh(g, 2, b);
            c = _.yh(b, 1, c);
            d = _.xh(c, 3, d);
            d = _.zh(a, 7, Ah, d);
            f.call(e, d)
        }
        this.output.notify()
    };
    var rO = function(a, b, c, d) {
        Z.call(this, a, 867);
        this.ra = b;
        this.P = c;
        this.output = hG(this);
        this.l = W(this, d)
    };
    _.T(rO, Z);
    rO.prototype.j = function() {
        for (var a = _.z(this.l.value), b = a.next(); !b.done; b = a.next()) {
            var c = _.z(b.value);
            b = c.next().value;
            c = c.next().value;
            var d = ai(this.P.R[b.getDomId()], 20);
            Lr(b, qI, 808, {
                Nj: c,
                Fl: d
            });
            Lr(this.ra, "slotRequested", 705, new XL(b, "publisher_ads"))
        }
        this.output.notify()
    };
    var sO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D, E, J, M, K, X, ba, la, pa, za, ya, Qa, Ga, zb, bb, wb) {
        Z.call(this, a, 785, _.cg($B));
        this.Va = b;
        this.L = c;
        this.za = d;
        this.P = e;
        this.We = f;
        this.Sb = g;
        this.networkCode = h;
        this.dd = k;
        this.cd = l;
        this.Tf = m;
        this.ld = n;
        this.timer = p;
        this.Z = r;
        this.isSecureContext = w;
        this.Fb = u;
        this.B = x;
        this.l = V(this);
        this.v = V(this);
        this.U = V(this);
        jG(this, K);
        this.Ia = iG(this, y);
        this.G = iG(this, C);
        this.K = W(this, D);
        J && (this.C = _.H(eC) ? new YF(J.bd) : iG(this, J.bd), J.Wd && (this.jc = Y(this, J.Wd)));
        M && (this.O = _.H(eC) ? new YF(M.Dc) : iG(this, M.Dc));
        jG(this, K);
        X && (this.Xa = W(this, X));
        ba && (this.ba = new YF(ba));
        la && (this.Pa = Y(this, la));
        pa && (this.ma = W(this, pa));
        za && jG(this, za);
        ya && (this.ya = W(this, ya));
        E && (this.da = Y(this, E));
        Qa && (this.Bb = Y(this, Qa.zg));
        Ga && (this.mc = W(this, Ga));
        zb && (this.pa = Y(this, zb));
        bb && (this.fa = Y(this, bb));
        wb && (this.ic = W(this, wb))
    };
    _.T(sO, Z);
    sO.prototype.j = function() {
        if (this.K.value.length) {
            var a = null;
            if (this.C) {
                var b = this.C.value;
                a = b ? b : this.O && !this.O.zb() ? 9 : this.C.zb() ? null : 1
            }
            this.G.value && (this.L.re = this.G.value);
            var c, d, e, f, g, h, k, l, m, n, p, r, w, u;
            b = {
                ia: {
                    B: this.B,
                    context: this.context,
                    L: this.L,
                    za: this.za,
                    Z: this.Z,
                    Va: this.Va,
                    Tf: this.Tf,
                    isSecureContext: this.isSecureContext,
                    Fb: this.Fb
                },
                ja: {
                    networkCode: this.networkCode,
                    X: this.K.value,
                    P: this.P,
                    Sb: this.Sb,
                    cg: !1
                },
                om: {
                    dd: this.dd,
                    cd: this.cd
                },
                gl: {
                    zk: null != (w = this.Ia.value) ? w : "0"
                },
                Xi: {
                    We: this.We,
                    ld: this.ld
                },
                hb: {
                    ee: null == (c = this.da) ? void 0 : c.value
                },
                Zl: {
                    cm: a,
                    am: null == (d = this.jc) ? void 0 : d.value
                },
                Il: {
                    Xk: null != (u = null == (e = this.Xa) ? void 0 : e.value) ? u : void 0,
                    Ze: null == (f = this.ba) ? void 0 : f.value,
                    ek: null == (g = this.ma) ? void 0 : g.value
                },
                yl: {
                    Ak: null == (h = this.Pa) ? void 0 : h.value,
                    vk: null == (k = this.ya) ? void 0 : k.value
                },
                tl: {
                    rl: null == (l = this.Bb) ? void 0 : l.value
                },
                jm: {
                    Cg: null == (m = this.mc) ? void 0 : m.value,
                    ze: null == (n = this.pa) ? void 0 : n.value,
                    Rl: null == (p = this.ic) ? void 0 : p.value
                },
                bk: {
                    ck: null == (r = this.fa) ? void 0 : r.value
                }
            };
            this.v.F(b);
            c = zp(Et(b));
            d = c.url;
            SG(this.timer, (9).toString(), 9, c.ah);
            this.l.F(d);
            this.U.F(zt(b) ? cv("https://pagead2.googlesyndication.com/gampad/ads/%{uuid}") : cv("https://securepubads.g.doubleclick.net/gampad/ads/%{uuid}"))
        } else this.l.F(""), this.v.aa()
    };
    var tO = function(a, b, c, d, e, f) {
        Z.call(this, a, 878);
        this.l = b;
        this.V = c;
        this.P = d;
        this.B = e;
        this.output = hG(this);
        f && jG(this, f)
    };
    _.T(tO, Z);
    tO.prototype.j = function() {
        for (var a = _.z(this.l), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = Fi(b, this.V);
            if (!Ei(b, this.V) && c) {
                a: {
                    var d = c;
                    var e = this.P.R[b.getDomId()],
                        f = 0,
                        g = 0;e = _.z(gi(e));
                    for (var h = e.next(); !h.done; h = e.next())
                        if (h = h.value, Array.isArray(h)) {
                            var k = _.z(h);
                            h = k.next().value;
                            k = k.next().value;
                            if (!("number" !== typeof h || "number" !== typeof k || 1 >= h || 1 >= k || (f = f || h, g = Math.min(g || Infinity, k), Hn(Hi(d, this.B)) || !d.parentElement || Hn(Hi(d.parentElement, this.B))))) {
                                d = [f, 0];
                                break a
                            }
                        }
                    d = f || g ? [f, g] : null
                }
                g = this.P;f = g.W;g = g.R[b.getDomId()];Gn(c, Ni(b), Jo(f, g), d)
            }
        }
        this.output.notify()
    };
    var uO = function(a, b, c, d, e, f, g) {
            this.l = a;
            this.I = b;
            this.J = c;
            this.X = d;
            this.Z = e;
            this.M = f;
            this.H = g;
            this.A = "";
            this.m = -1;
            this.j = 1;
            this.o = ""
        },
        wO = function(a, b) {
            if (b)
                if (1 !== a.j && 2 !== a.j) vO(a, new TE("state err: (" + ([a.j, a.o.length].join() + ")")));
                else {
                    a.o && (b = a.o + b);
                    var c = 0;
                    do {
                        var d = b.indexOf("\n", c);
                        var e = -1 !== d;
                        if (!e) break;
                        var f = a;
                        c = b.substr(c, d - c);
                        if (1 === f.j) f.A = c, ++f.m, f.j = 2;
                        else {
                            try {
                                f.l(f.m, f.A, {
                                    kind: 0,
                                    wb: Gz(c)
                                }, f.X, f.Z, f.M, f.H), f.A = ""
                            } catch (g) {}
                            f.j = 1
                        }
                        c = d + 1
                    } while (e && c < b.length);
                    a.o = b.substr(c)
                }
        },
        vO = function(a, b) {
            a.j = 4;
            try {
                a.I(b)
            } catch (c) {}
        },
        xO = function(a) {
            1 !== a.j || a.o ? vO(a, new TE("state err (" + ([a.j, a.o.length].join() + ")"))) : (a.j = 3, a.J(a.m, a.X, a.Z))
        };
    var yO = function(a, b, c, d, e, f, g, h, k, l, m, n, p) {
        Z.call(this, a, 788);
        this.U = b;
        this.O = c;
        this.K = d;
        this.Z = e;
        this.L = f;
        this.P = g;
        this.output = hG(this);
        this.G = 0;
        this.C = !1;
        this.l = null != p ? p : new XMLHttpRequest;
        this.v = W(this, h);
        k && (this.da = Y(this, k));
        this.fa = W(this, l);
        jG(this, m);
        this.ba = W(this, n)
    };
    _.T(yO, Z);
    yO.prototype.j = function() {
        var a = this,
            b = this.fa.value;
        if (b) {
            var c, d = new uO(this.U, this.O, this.K, this.v.value, this.Z, null == (c = this.da) ? void 0 : c.value);
            this.l.open("GET", b);
            this.l.withCredentials = this.ba.value;
            this.l.onreadystatechange = function() {
                zO(a, d, !1)
            };
            this.l.onload = function() {
                zO(a, d, !0)
            };
            this.l.onerror = function() {
                vO(d, new UE("XHR error"));
                AO(a)
            };
            this.l.send()
        }
        this.output.notify()
    };
    var zO = function(a, b, c) {
            try {
                if (3 === a.l.readyState || 4 === a.l.readyState)
                    if (300 <= a.l.status) a.C || (vO(b, new UE("xhr_err-" + a.l.status)), a.C = !0, AO(a));
                    else {
                        var d = a.l.responseText.substr(a.G);
                        d && wO(b, d);
                        a.G = a.l.responseText.length;
                        c && 4 === a.l.readyState && xO(b)
                    }
            } catch (e) {
                vO(b, e)
            }
        },
        AO = function(a) {
            _.H(rB) && a.v.value.forEach(function(b) {
                Or(b, a.L, a.P, "")
            })
        };
    var BO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        Z.call(this, a, 1078);
        this.G = b;
        this.C = c;
        this.v = d;
        this.Z = e;
        this.L = f;
        this.P = g;
        this.output = hG(this);
        this.l = W(this, h);
        k && (this.O = Y(this, k));
        l && (this.U = W(this, l));
        this.ba = W(this, m);
        jG(this, n);
        this.K = W(this, p);
        if (null == r ? 0 : r.Vd) this.fa = Y(this, r.Vd);
        w && (this.da = W(this, w))
    };
    _.T(BO, Z);
    BO.prototype.j = function() {
        var a = this,
            b = this.ba.value;
        if (b) {
            var c, d, e = new uO(this.G, this.C, this.v, this.l.value, this.Z, null == (c = this.O) ? void 0 : c.value, null == (d = this.U) ? void 0 : d.value);
            c = this.K.value ? "include" : "omit";
            var f;
            d = null == (f = this.fa) ? void 0 : f.value;
            var g;
            f = null == (g = this.da) ? void 0 : g.value;
            g = _.A(Object, "assign").call(Object, {}, {
                credentials: c
            }, d ? {
                browsingTopics: d
            } : {}, f ? {
                adAuctionHeaders: f
            } : {});
            fetch(b, g).then(function(h) {
                CO(a, h, e)
            }).catch(function(h) {
                DO(h, e);
                EO(a)
            })
        }
        this.output.notify()
    };
    var CO = function(a, b, c) {
            if (300 <= b.status) vO(c, new UE("fetch_status-" + b.status)), EO(a);
            else {
                var d, e = null == (d = b.body) ? void 0 : d.pipeThrough(new TextDecoderStream).getReader();
                e ? e.read().then(function(f) {
                    FO(a, f, e, c)
                }).catch(function(f) {
                    DO(f, c)
                }) : vO(c, new UE("failed_reader"))
            }
        },
        FO = function(a, b, c, d) {
            var e = b.value;
            b.done ? xO(d) : (wO(d, e), c.read().then(function(f) {
                FO(a, f, c, d)
            }).catch(function(f) {
                DO(f, d)
            }))
        },
        DO = function(a, b) {
            vO(b, new UE("fetch error: " + (a instanceof Error ? a.message : void 0)))
        },
        EO = function(a) {
            _.H(rB) && a.l.value.forEach(function(b) {
                Or(b, a.L, a.P, "")
            })
        };
    var GO = function(a, b, c, d, e) {
        Z.call(this, a, 918);
        this.P = b;
        this.timer = c;
        this.output = hG(this);
        this.l = W(this, e);
        jG(this, d)
    };
    _.T(GO, Z);
    GO.prototype.j = function() {
        var a = this.l.value;
        a.length && Jr(this.timer, "3", Kr(this.P.R[a[0].getDomId()], 20));
        this.output.notify()
    };
    var IO = function(a, b, c) {
        Z.call(this, a, 804);
        this.jb = c;
        this.output = fG(this);
        this.v = [];
        this.Qc = {
            Ck: HO(this, function(d) {
                return fx(d, 6)
            }),
            pm: HO(this, function(d) {
                return fx(d, 7)
            }),
            Kk: HO(this, function(d) {
                return !!Pl(d, 8)
            }),
            pk: HO(this, function(d) {
                return gx(d, 10)
            }),
            ec: HO(this, function(d) {
                var e;
                return null != (e = d.getEscapedQemQueryId()) ? e : ""
            }),
            sj: HO(this, function(d) {
                return _.Zh(d, vy, 43)
            }),
            Jk: HO(this, function(d) {
                return !!Pl(d, 9)
            }),
            rf: HO(this, function(d) {
                return !!Pl(d, 12)
            }),
            wk: HO(this, function(d) {
                return _.Zh(d, jy, Gk(d, Jy, 48))
            }),
            Uf: HO(this, function(d) {
                return _.Zh(d, iy, Gk(d, Jy, 39))
            }),
            fe: HO(this, function(d) {
                return hx(d, 36)
            }),
            lm: HO(this, function(d) {
                return !!Pl(d, 13)
            }),
            Ik: HO(this, function(d) {
                return !!Pl(d, 3)
            }),
            Rg: HO(this, function(d) {
                return gx(d, 49)
            }),
            Fk: HO(this, function(d) {
                return _.Zh(d, yy, 51)
            }),
            ak: HO(this, function(d) {
                return gx(d, 61)
            }),
            Aa: V(this),
            Pi: HO(this, function(d) {
                return _.Zh(d, Hy, 58)
            }),
            qm: HO(this, function(d) {
                var e, f;
                return null != (f = null == (e = _.Zh(d, ty, 56)) ? void 0 : gx(e, 1)) ? f : null
            }),
            Od: HO(this, function(d) {
                return _.bi(d, dy, 62)
            }),
            Jj: HO(this, function(d) {
                return _.bi(d, wy, 67)
            }),
            Rk: HO(this, function(d) {
                return Xd(d, 63, ad, void 0, void 0, void 0, 0)
            }),
            Ej: HO(this, function(d) {
                return !!Pl(d, 64)
            }),
            dk: HO(this, function(d) {
                return Qo(d, xy, 68)
            })
        };
        this.l = W(this, b)
    };
    _.T(IO, Z);
    var HO = function(a, b) {
        var c = V(a);
        a.v.push({
            output: c,
            hk: b
        });
        return c
    };
    IO.prototype.j = function() {
        for (var a = _.z(this.v), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = b.hk,
                d = void 0;
            b.output.Ca(null != (d = c(this.l.value)) ? d : null)
        }
        0 === this.jb.kind ? this.Qc.Aa.F(this.jb) : this.Qc.Aa.F({
            kind: 0,
            wb: _.Aj(this.l.value, 4) || ""
        });
        this.output.F(this.Qc)
    };
    var JO = function(a, b, c, d, e) {
        Z.call(this, a, 803);
        this.l = b;
        this.slotId = c;
        this.za = d;
        this.Z = e;
        this.output = V(this)
    };
    _.T(JO, Z);
    JO.prototype.j = function() {
        var a = JSON.parse(this.l),
            b = wn(a, dv);
        if (!b) throw Error("missing ad unit path");
        if (null == a || !a[b]) throw Error("invalid ad unit path: " + b);
        a = a[b];
        if (!Array.isArray(a)) throw Error("dictionary not an array: " + this.l);
        a = qe(Iy, a);
        b = _.z(Xd(a, 27, Mc));
        for (var c = b.next(); !c.done; c = b.next()) c = c.value, _.Rf(Sf).j(c);
        Xl(4, this.context, this.za, this.Z);
        Lr(this.slotId, pI, 800, a);
        this.output.F(a)
    };
    var KO = function(a, b, c, d) {
        Z.call(this, a, 823);
        this.slotId = b;
        this.L = c;
        this.l = W(this, d)
    };
    _.T(KO, Z);
    KO.prototype.j = function() {
        var a = this;
        Pl(this.l.value, 11) && (_.BI(this.L, this.slotId), yI(this.L, this.slotId, function() {
            _.CI(a.L, a.slotId)
        }))
    };
    var LO = function(a, b, c, d) {
        Jj.call(this);
        this.context = a;
        this.slotId = b;
        a = d.L;
        var e = d.Z;
        b = d.Ta;
        var f = d.za;
        d = d.jb;
        c = new JO(this.context, c, this.slotId, f, e);
        O(this, c);
        e = new GL(this.context, e, f, c.output);
        O(this, e);
        b = new IL(this.context, this.slotId, b, c.output);
        O(this, b);
        a = new KO(this.context, this.slotId, a, c.output);
        O(this, a);
        a = new IO(this.context, c.output, d);
        O(this, a);
        d = a.Qc;
        this.j = {
            Kc: d.Kk,
            Qf: d.ec,
            sa: d.Pi,
            Qc: a.output
        }
    };
    _.T(LO, Jj);
    /* 
     
    Math.uuid.js (v1.4) 
    http://www.broofa.com 
    mailto:robert@broofa.com 
    Copyright (c) 2010 Robert Kieffer 
    Dual licensed under the MIT and GPL licenses. 
    */
    var MO = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(""),
        NO = function() {
            for (var a = Array(36), b = 0, c, d = 0; 36 > d; d++) 8 == d || 13 == d || 18 == d || 23 == d ? a[d] = "-" : 14 == d ? a[d] = "4" : (2 >= b && (b = 33554432 + 16777216 * Math.random() | 0), c = b & 15, b >>= 4, a[d] = MO[19 == d ? c & 3 | 8 : c]);
            return a.join("")
        };
    var OO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D, E, J, M, K, X) {
        Z.call(this, a, 973);
        this.pa = b;
        this.T = c;
        this.K = d;
        this.ba = e;
        this.P = f;
        this.L = g;
        this.za = h;
        this.fa = k;
        this.O = l;
        this.G = m;
        this.Qd = n;
        this.ma = p;
        this.networkCode = r;
        this.isSecureContext = w;
        this.Fb = u;
        this.Ta = x;
        this.B = y;
        this.V = C;
        this.l = M;
        this.U = K;
        this.ya = X;
        this.C = [];
        this.v = Y(this, D);
        this.da = W(this, E);
        this.Ia = W(this, J);
        this.l && jG(this, this.l.Lj)
    };
    _.T(OO, Z);
    OO.prototype.j = function() {
        var a = this,
            b = new Jj;
        _.S(this, b);
        var c = this.da.value,
            d = Ft(this.P.W);
        this.v.value && this.ya.F(this.v.value);
        var e = tq(this.context, this.V);
        e && _.S(b, e.Ga);
        var f = Qp(this.context, _.Zh(this.P.W, Us, 5), this.L, this.K, null == e ? void 0 : e.ol.Kd);
        e = f.gg;
        (f = f.Sk) && _.S(b, f);
        f = new tO(this.context, this.K, this.V, this.P, this.B, e);
        O(b, f);
        var g = !!_.N(this.P.W, 6);
        e = new nO(this.context, this.K, g, this.P, this.T, this.B, c);
        O(b, e);
        var h, k = new vK(this.context, d, c, (null == (h = _.Zh(this.P.W, xs, 36)) ? void 0 : Xd(h, 1, Kc)) || []);
        O(b, k);
        h = this.U;
        var l = h.il,
            m = h.ul,
            n = h.dm,
            p, r = null != (p = this.l) ? p : {},
            w = r.de;
        h = r.hf;
        var u = r.Mb,
            x = r.pd,
            y = r.Ae,
            C = r.uk;
        p = r.uf;
        var D = r.Ch,
            E = r.Oj;
        r = r.od;
        if (_.H(SB)) {
            var J = new BM(this.context, E);
            var M = new CM(this.context, E);
            O(b, J);
            O(b, M);
            var K = J.l;
            J = M.l;
            M = M.v
        }
        if (D = Tr(this.context, n, this.P.R, c, this.v.value, e.l, k.output, D, J)) {
            var X = D.gm;
            D = D.fm;
            var ba = X.wg;
            X = X.ag;
            _.S(b, D)
        }
        if (M = sr(this.context, n, this.B.navigator, k.output, M)) {
            var la = M.Qi;
            M = M.hm;
            var pa = la.yi;
            la = la.Kh;
            M && _.S(b, M)
        }
        _.H(kC) && (la = V(this), la.F(n.Pg));
        D = new UM(this.context, this.B);
        O(b, D);
        n = (null != w ? w : {}).Rb;
        var za;
        M = null == (za = this.l) ? void 0 : za.pf;
        za = new wM(this.context, l.jl);
        O(b, za);
        if (l = Fo(this.context, this.T, this.P.R, this.networkCode, e.l, w, u)) {
            var ya = l.vj;
            _.S(this, l.Ga)
        }
        if (X = vq(this.context, m, X, _.H(nC) ? this.P.R : void 0, _.H(nC) ? e.l : void 0, E)) {
            var Qa = X.df;
            _.S(this, X.Ga)
        }
        if (K = dr(this.context, this.v.value, M, k.output, K)) {
            var Ga = K.bm;
            _.S(this, K.Ga);
            this.C.push(Ga.bd.promise)
        }
        K = window.isSecureContext && _.H(oC) ? "wbn" : "ldjh";
        var zb = ++this.L.H;
        X = "wbn" === K ? NO().toLowerCase() : void 0;
        k = this.Qd;
        var bb, wb;
        ya = new sO(this.context, g, this.L, this.za, this.P, K, k.Sb, this.networkCode, k.dd, k.cd, this.Ia.value, X, _.Rf(Jh), c, this.isSecureContext, this.Fb, this.B, za.output, D.output, e.l, null == (bb = ya) ? void 0 : bb.Kg, Ga, M, f.output, null == h ? void 0 : h.qg, n, u, x, y, C, Qa, pa, null == (wb = this.l) ? void 0 : wb.Ch, r, J);
        O(b, ya);
        Qa = new GO(this.context, this.P, _.Rf(Jh), ya.l, e.l);
        O(b, Qa);
        d = new oO(this.context, d, c);
        O(b, d);
        bb = Hh(this.context, 646, function(bc, Hc, jc, Zd, Ic, rd, $d) {
            Ht(function() {
                return void PO(a, Ic, bc, Hc, jc, Zd, rd, $d)
            }, bc, a.B)
        });
        wb = Hh(this.context, 647, function(bc, Hc, jc) {
            Ht(function() {
                return void QO(a, zb, jc, Hc, bc)
            }, -1, a.B)
        });
        "ldjh" === K ? (J = RO(this, 289, "strm_err"), _.H(wB) && window.fetch && window.TextDecoderStream || _.H(yB) && yz(window.fetch) && yz(window.TextDecoderStream) || _.H(xB) && Na() && yz(window.fetch) && yz(window.TextDecoderStream) ? (ba = new BO(this.context, bb, J, wb, c, this.L, this.P, e.l, ba, pa, ya.l, Qa.output, d.output, Ga, la), O(b, ba), ba = ba.output) : (ba = new yO(this.context, bb, J, wb, c, this.L, this.P, e.l, ba, ya.l, Qa.output, d.output), O(b, ba), ba = ba.output)) : (pa = new FN(this.context, bb, RO(this, 1042, "Unknown web bundle error."), wb, K, X, c, this.V, e.l, ba, ya.l, ya.U, Qa.output, d.output), Rs(b, pa), ba = new Cn, ZF(ba, Sj(pa).then(function() {})));
        pa = new pO(this.context, zb, e.l, ba, p, this.networkCode);
        O(b, pa);
        Ga = new lO(this.context, ya.v, ya.l);
        O(b, Ga);
        Ga = new rO(this.context, this.G.ra, this.P, Ga.output);
        O(b, Ga);
        Ga = new JM(this.context, this.fa, this.B, Ga.output);
        O(b, Ga);
        Ga = new mM(this.context, this.P, this.O, e.l, Ga.output);
        O(b, Ga);
        e = new vL(this.context, this.L, this.P, this.V, e.l, Ga.output);
        O(b, e);
        Ga = new TM(this.context, _.Rh(this.B), this.B, c, ba);
        O(b, Ga);
        1 === zb && (c = new nL(this.context, this.B, c, M, ba), O(b, c), this.C.push(c.output.promise));
        this.C.push(pa.output.promise, e.output.promise, Ga.output.promise);
        Sj(b)
    };
    var PO = function(a, b, c, d, e, f, g, h) {
            var k, l, m;
            return _.lb(function(n) {
                k = f[c];
                if (!k) return Lh(a.context, 646, Error("missing slot")), n.return();
                0 === c && (l = Kr(a.P.R[k.getDomId()], 20), Jr(_.Rf(Jh), "4", l));
                return n.yield(SO(a, k, d, e, b, null == (m = g) ? void 0 : m[k.getId()], h), 0)
            })
        },
        QO = function(a, b, c, d, e) {
            var f, g, h;
            return _.lb(function(k) {
                if (1 == k.j) {
                    var l = a.context,
                        m = e + 1,
                        n = d.length;
                    if (l.Bc) {
                        var p = l.Qa,
                            r = p.Ac;
                        l = uh(l);
                        var w = new OA;
                        w = _.qh(w, 3, b);
                        m = _.yh(w, 1, m);
                        n = _.yh(m, 2, n);
                        n = _.zh(l, 8, Ah, n);
                        r.call(p, n)
                    }
                    f = e + 1
                }
                if (3 != k.j) {
                    if (!(f < d.length)) return k.yield(TO(a), 0);
                    if (!d[f]) {
                        k.j = 3;
                        return
                    }
                    p = new Iy;
                    p = Fj(p, 8, !0);
                    g = Ak(p);
                    h = '{"empty":' + g + "}";
                    return k.yield(PO(a, c, f, h, {
                        kind: 0,
                        wb: ""
                    }, d), 3)
                }++f;
                k.j = 2
            })
        },
        SO = function(a, b, c, d, e, f, g) {
            var h, k, l, m, n, p, r, w, u, x;
            return _.lb(function(y) {
                if (1 == y.j) return h = {
                    Z: e,
                    Ta: a.Ta,
                    L: a.L,
                    za: a.za,
                    jb: d
                }, k = new LO(a.context, b, c, h), y.yield(Sj(k), 2);
                l = y.o;
                m = l.Kc;
                n = l.Qf;
                p = l.sa;
                r = l.Qc;
                Ho(a.context, null == (w = a.l) ? void 0 : w.de, r.qm, r.rf, r.ec);
                _.H(jB) && qp(a.context, a.za, r.dk);
                if (b.J) return y.return();
                (u = !!p) && Zi("gpt_td_init", function(C) {
                    ej(C, a.context);
                    fj(C, "noFill", m ? "1" : "0");
                    fj(C, "publisher_tag", "gpt");
                    var D = _.Zh(p, Fy, 5);
                    D && (fj(C, "winner_qid", D.getEscapedQemQueryId()), fj(C, "xfpQid", _.R(D, 6)))
                }, 1);
                (x = Bp("google_norender")) || m && !u ? Or(b, a.L, a.P, n) : iO(a.ma, a.pa, a.T, b, m || x, u, a.L, a.P, a.Ta, r, e, f, g, a.G.ra, a.O, a.l, a.U);
                k.wa();
                y.j = 0
            })
        },
        RO = function(a, b, c) {
            return Hh(a.context, b, function(d) {
                d = d instanceof Error ? d : Error();
                d.message = d.message || c;
                Lh(a.context, b, d);
                TO(a)
            })
        },
        TO = function(a) {
            return _.lb(function(b) {
                if (1 == b.j) {
                    var c = a.L,
                        d = a.ba,
                        e = c.o.get(d) - 1;
                    0 === e ? c.o.delete(d) : c.o.set(d, e);
                    return e ? b.return() : b.yield(_.v.Promise.all(a.C), 2)
                }
                Lr(a.G.Gh, tI, 965, a.ba);
                b.j = 0
            })
        };
    var UO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D, E, J, M, K) {
        Z.call(this, a, 885);
        this.da = b;
        this.T = c;
        this.P = d;
        this.L = e;
        this.za = f;
        this.Qd = g;
        this.U = h;
        this.G = k;
        this.l = l;
        this.C = m;
        this.ba = n;
        this.isSecureContext = p;
        this.ab = r;
        this.O = w;
        this.Fb = u;
        this.Ta = x;
        this.B = y;
        this.V = C;
        this.v = J;
        this.K = M;
        this.fa = K;
        this.ma = W(this, D);
        jG(this, E)
    };
    _.T(UO, Z);
    UO.prototype.j = function() {
        var a = this.ma.value;
        if (a.length) {
            var b = this.L,
                c = this.l,
                d = a.length;
            b.o.has(c);
            b.o.set(c, d);
            a = _.z(a);
            for (b = a.next(); !b.done; b = a.next()) {
                c = b.value;
                var e = void 0;
                b = c.networkCode;
                d = c.X;
                c = new Jj;
                _.S(this, c);
                var f = yp(this.context, this.O, null == (e = this.v) ? void 0 : e.Zk);
                e = f.tc;
                var g = f.Dh;
                _.S(c, f.Ga);
                e = Wm(this.context, this.T, this.L, this.B, e, g, Ft(this.P.W));
                f = e.ib;
                _.S(c, e.Ga);
                e = new DM(this.context, this.B, f);
                O(c, e);
                e = new FL(this.context, this.B, f);
                O(c, e);
                e = new Ns(this.context, this.B, f);
                O(c, e);
                g = new jO(this.context, this.za, this.ab, f);
                O(c, g);
                b = new OO(this.context, this.da, this.T, d, this.l, this.P, this.L, this.za, this.U, this.G, this.C, this.Qd, this.ba, b, this.isSecureContext, this.Fb, this.Ta, this.B, this.V, e.output, f, g.v, this.v, this.K, this.fa);
                O(c, b);
                Sj(c)
            }
        } else Lr(this.C.Gh, tI, 965, this.l)
    };
    var VO = new _.v.Map,
        WO = function(a, b, c, d) {
            d = void 0 === d ? VO : d;
            Z.call(this, a, 834);
            this.T = b;
            this.X = c;
            this.l = d;
            this.v = V(this);
            this.v.Ja(_.v.Promise.all(this.X.map(this.C, this)).then(function(e) {
                return e.filter(function(f) {
                    return null != f && !f.J
                })
            }))
        };
    _.T(WO, Z);
    WO.prototype.j = function() {};
    WO.prototype.C = function(a) {
        var b = this,
            c, d;
        return _.lb(function(e) {
            if (1 == e.j) {
                if (a.J) return e.return();
                b.l.has(a) || (b.l.set(a, Jt(a)), _.tn(a, function() {
                    return void b.l.delete(a)
                }));
                c = b.l.get(a);
                return e.yield(c(), 2)
            }
            d = e.o;
            if (b.J) return e.return();
            if (d) return e.return(a);
            Q(b.T, yJ(a.getAdUnitPath()));
            return e.return()
        })
    };
    var XO = function(a, b, c, d, e) {
        Z.call(this, a, 847);
        this.L = b;
        this.Va = c;
        this.He = d;
        this.l = V(this);
        this.v = W(this, e)
    };
    _.T(XO, Z);
    XO.prototype.j = function() {
        var a = Lt({
            X: this.v.value
        }, {
            L: this.L,
            Va: this.Va,
            He: this.He
        });
        this.l.F(a.Sc)
    };
    var YO = function(a, b, c) {
        Z.call(this, a, 845);
        this.R = b;
        this.l = V(this);
        this.v = V(this);
        this.C = W(this, c)
    };
    _.T(YO, Z);
    YO.prototype.j = function() {
        var a = Nt({
            X: this.C.value
        }, {
            R: this.R
        });
        this.l.F(a.Ig);
        this.v.F(a.Sg)
    };
    var ZO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C) {
        _.U.call(this);
        var D = this;
        this.context = a;
        this.C = b;
        this.T = c;
        this.L = d;
        this.za = e;
        this.ra = f;
        this.M = g;
        this.l = h;
        this.v = k;
        this.isSecureContext = l;
        this.ab = m;
        this.I = n;
        this.Fb = p;
        this.Ta = r;
        this.V = w;
        this.B = u;
        this.A = x;
        this.H = y;
        this.G = C;
        this.j = new _.v.Map;
        this.m = new lI(a);
        _.S(this, this.m);
        this.m.listen(tI, function(E) {
            E = E.detail;
            var J = D.j.get(E);
            J && (D.j.delete(E), J.wa())
        })
    };
    _.T(ZO, _.U);
    var $O = function(a, b, c, d) {
        var e = ++a.L.l;
        a.j.has(e);
        var f = new Jj;
        a.j.set(e, f);
        b = new WO(a.context, a.T, b);
        O(f, b);
        if (_.H(TB)) {
            b = pG(f, 845, Nt, {
                X: b.v
            }, {
                R: d.R
            }, {
                Ig: void 0,
                Sg: void 0
            });
            var g = b.Sg;
            b = pG(f, 847, Lt, {
                X: b.Ig
            }, {
                L: a.L,
                Va: !!_.N(d.W, 6),
                He: Bp("google_nofetch")
            }, {
                Sc: void 0
            }).Sc;
            g = pG(f, 864, lp, {
                X: g
            }, {
                L: a.L,
                P: d,
                V: document
            }, {}).finished
        } else g = new YO(a.context, d.R, b.v), O(f, g), b = new XO(a.context, a.L, !!_.N(d.W, 6), Bp("google_nofetch"), g.l), b = O(f, b).l, g = new wL(a.context, a.L, d, document, g.v), O(f, g), g = g.l;
        a = new UO(a.context, a.C, a.T, d, a.L, a.za, c, a.M, a.l, e, {
            Gh: a.m,
            ra: a.ra
        }, a.v, a.isSecureContext, a.ab, a.I, a.Fb, a.Ta, a.B, a.V, b, g, a.A, a.H, a.G);
        O(f, a);
        Sj(f)
    };
    var aP = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        HN.call(this, a, c, h);
        this.context = a;
        this.L = d;
        this.A = new _.v.Set;
        this.H = {};
        this.v = new hO(a, d);
        this.C = new ZO(a, b, c, d, new _.eF(window), this.m, m, e, this.v, f, g, k, l, n, document, window, p, r, w);
        _.S(this, this.C)
    };
    _.T(aP, HN);
    aP.prototype.getName = function() {
        return "publisher_ads"
    };
    aP.prototype.display = function(a, b, c, d, e) {
        d = void 0 === d ? "" : d;
        e = void 0 === e ? "" : e;
        var f = "";
        if (d)
            if (_.ka(d) && 1 == d.nodeType) {
                var g = d;
                f = g.id
            } else f = d;
        os(this);
        var h = nm(c, this.context, this.T, a, b, f),
            k = h.slotId;
        h = h.Da;
        if (k && h) {
            g && !f && (g.id = k.getDomId());
            this.slotAdded(k, h);
            h.setClickUrl(e);
            var l;
            Zr(this, null != (l = g) ? l : k.getDomId(), c)
        } else Q(this.T, Uk("PubAdsService.display", [a, b, d]))
    };
    var Zr = function(a, b, c) {
        var d = bP(b, c);
        c = d.slotId;
        var e = d.Vj;
        d = d.Wj;
        if (c) {
            if (b = Pi(), (d = aH(b, c.getDomId())) && !_.N(d, 19))
                if (e && b.m.set(c, e), (e = Fi(c)) || (e = Ps(d), e = 0 !== e && 1 !== e), e) {
                    if (Fj(d, 19, !0), e = Bi(b.j, b.o), a.enabled) {
                        os(a);
                        a.enabled && AI(a.L, c);
                        a.T.info($I());
                        b = e.W;
                        d = e.R;
                        var f = _.N(b, 6);
                        if (f || !a.L.nc(c)) f && (f = Fi(c)) && Lr(c, oI, 778, f), _.N(b, 4) && (d = d[c.getDomId()], hp(d, b) && !a.L.nc(c) && ip(c, document, d, b)), $J(a, e, c)
                    }
                } else Q(a.T, QI(String(_.Aj(d, 1)), String(_.Aj(d, 2))), c)
        } else d ? a.T.error(RI(d)) : a.T.error(Uk("googletag.display", [String(b)]))
    };
    aP.prototype.slotAdded = function(a, b) {
        var c = this;
        _.N(b, 17) || this.enabled && AI(this.L, a);
        Lr(this.m, rI, 724, {
            Jg: a.getDomId(),
            R: b
        });
        a.listen(Nr, function(d) {
            var e = d.detail;
            d = e.size;
            var f = new SL(a, "publisher_ads");
            e.isEmpty && (f.isEmpty = !0);
            e = a.j.getResponseInformation();
            d && e && (f.size = [d.width, d.height], f.sourceAgnosticCreativeId = e.sourceAgnosticCreativeId, f.sourceAgnosticLineItemId = e.sourceAgnosticLineItemId, f.isBackfill = e.isBackfill, f.creativeId = e.creativeId, f.lineItemId = e.lineItemId, f.creativeTemplateId = e.creativeTemplateId, f.advertiserId = e.advertiserId, f.campaignId = e.campaignId, f.yieldGroupIds = e.yieldGroupIds, f.companyIds = e.companyIds);
            Lr(c.m, "slotRenderEnded", 708, f)
        });
        a.listen(pI, function() {
            Lr(c.m, "slotResponseReceived", 709, new YL(a, c.getName()))
        });
        4 === Ps(b) && cP(this, "rewardedSlotClosed", a, b);
        7 === Ps(b) && cP(this, "gameManualInterstitialSlotClosed", a, b);
        HN.prototype.slotAdded.call(this, a, b)
    };
    var cP = function(a, b, c, d) {
            _.tn(c, a.m.listen(b, function(e) {
                c.j === e.detail.slot && (e = {}, dP(a, [c], Pi().j, (e[c.getDomId()] = d, e), a.L))
            }))
        },
        $J = function(a, b, c) {
            var d = eP(a, b, c);
            fP(a, d, b, {
                Sb: 1
            });
            b = c.getAdUnitPath();
            if (c = a.H[b]) {
                c = _.z(c);
                for (d = c.next(); !d.done; d = c.next()) d = d.value, fP(a, d.X, d.P, d.Qd);
                delete a.H[b]
            }
        },
        eP = function(a, b, c) {
            var d = b.W;
            b = b.R;
            if (_.N(d, 4)) return [];
            var e;
            return !_.N(d, 6) || (null == (e = b[c.getDomId()]) ? 0 : _.N(e, 17)) ? (a.A.add(c), _.tn(c, function() {
                return void a.A.delete(c)
            }), [c]) : a.j.filter(function(f) {
                if (a.A.has(f)) return !1;
                a.A.add(f);
                _.tn(f, function() {
                    return void a.A.delete(f)
                });
                return !0
            })
        },
        fP = function(a, b, c, d) {
            a.T.info(gJ());
            if (gP(a, b, d, c) && 1 !== d.Sb)
                for (b = _.z(b), d = b.next(); !d.done; d = b.next()) d = d.value.getDomId(), Lr(a.m, sI, 725, {
                    Jg: d,
                    R: c.R[d]
                })
        },
        gP = function(a, b, c, d) {
            b = b.filter(function(e) {
                var f = d.R[e.getDomId()],
                    g = _.jp(a.L, e);
                !1 === g && Q(a.T, PJ(String(Ps(f)), e.getAdUnitPath()));
                if (!g) return !1;
                (_.G = [5, 4, 7], _.A(_.G, "includes")).call(_.G, Ps(f)) && _.BI(a.L, e);
                return !0
            });
            if (!b.length) return null;
            $O(a.C, b, c, d);
            return b
        };
    aP.prototype.refresh = function(a, b, c) {
        c = void 0 === c ? {
            Sb: 2
        } : c;
        b = hP(this, b);
        if (!b.length) return !1;
        iP(this, a, b, c);
        return !0
    };
    var hP = function(a, b) {
            return b.filter(function(c, d) {
                if (!c.J) return !0;
                Q(a.T, jJ(String(d)));
                return !1
            })
        },
        iP = function(a, b, c, d) {
            var e = c[0],
                f, g = null != (f = null == e ? void 0 : e.getDomId()) ? f : "";
            if (a.enabled) {
                var h = _.z(c);
                e = h.next();
                for (f = {}; !e.done; f = {
                        Td: f.Td
                    }, e = h.next()) f.Td = e.value, a.A.add(f.Td), _.tn(f.Td, function(k) {
                    return function() {
                        return void a.A.delete(k.Td)
                    }
                }(f));
                fP(a, c, b, d)
            } else c.length && _.N(b.W, 6) ? (Q(a.T, fJ(g), e), e = e.getAdUnitPath(), f = null != (h = a.H[e]) ? h : [], f.push({
                X: c,
                P: b,
                Qd: d
            }), a.H[e] = f) : Q(a.T, dJ(g), e)
        };
    aP.prototype.M = function() {
        var a = Pi().j;
        if (_.N(a, 6))
            for (var b = _.z(this.j), c = b.next(); !c.done; c = b.next()) this.enabled && AI(this.L, c.value);
        eK(this, a);
        a = Hm();
        a.hasOwnProperty("pubadsReady") || (a.pubadsReady = !0)
    };
    aP.prototype.destroySlots = function(a) {
        a = HN.prototype.destroySlots.call(this, a);
        if (a.length && this.enabled) {
            var b = Pi();
            jP(this, a, b.j, b.o)
        }
        return a
    };
    var gK = function(a, b, c, d) {
            if (!a.enabled) return Q(a.T, eJ(), d[0]), !1;
            var e = hP(a, d);
            if (!e.length) return Q(a.T, Uk("PubAdsService.clear", [d].filter(function(f) {
                return void 0 !== f
            }))), !1;
            a.T.info(hJ());
            jP(a, e, b, c);
            return !0
        },
        jP = function(a, b, c, d) {
            for (var e = _.z(b), f = e.next(); !f.done; f = e.next()) xI(a.L, f.value);
            dP(a, b, c, d, a.L)
        };
    aP.prototype.forceExperiment = function(a) {
        a = Number(a);
        0 < a && _.Rf(Sf).j(a)
    };
    var dP = function(a, b, c, d, e) {
            var f = void 0 === f ? window : f;
            b = _.z(b);
            for (var g = b.next(); !g.done; g = b.next()) {
                g = g.value;
                GI(a.v.L, g);
                var h = d[g.getDomId()];
                hp(h, c) && ip(g, f.document, h, c);
                kp(e, g)
            }
        },
        fK = function(a, b, c, d) {
            if ("string" !== typeof b || "string" !== typeof c) Q(a.T, Uk("PubAdsService.setVideoContent", [b, c]));
            else {
                var e = Fj(d, 21, !0);
                b = Vn(e, 22, b);
                Vn(b, 23, c);
                eK(a, d)
            }
        },
        hK = function(a, b) {
            if (!a.enabled) return null;
            var c, d;
            return {
                vid: null != (c = _.R(b, 22)) ? c : "",
                cmsid: null != (d = _.R(b, 23)) ? d : ""
            }
        },
        eK = function(a, b) {
            _.N(b, 21) && a.enabled && (a = Hz(), _.Ai(b, 29, null == a ? a : bd(a)))
        },
        bP = function(a, b) {
            var c = "";
            if ("string" === typeof a) c = a, b = lL(b, c);
            else if (_.ka(a) && 1 == a.nodeType) {
                var d = a;
                c = d.id;
                b = lL(b, c)
            } else b = (_.G = [].concat(_.lh(b.X)), _.A(_.G, "find")).call(_.G, function(e) {
                return e.j === a
            });
            return {
                slotId: b,
                Vj: d,
                Wj: c
            }
        };
    var Xt = _.tu(["https://pagead2.googlesyndication.com/pagead/js/rum_debug.js"]),
        Yt = _.tu(["https://pagead2.googlesyndication.com/pagead/js/rum.js"]);
    var kP = uu(["^[-p{L}p{M}p{N}_,.!*<>():/]*$"], ["^[-\\p{L}\\p{M}\\p{N}_,\\.!*<>():/]*$"]),
        lP = _.ev(function() {
            Dz("The googletag.pubads().definePassback function has been deprecated. The function may break in certain contexts, see https://developers.google.com/publisher-tag/guides/passback-tags#construct_passback_tags for how to correctly create a passback.")
        }),
        nP = function(a, b) {
            var c = this;
            var d = void 0 === d ? _.A(String, "raw").call(String, kP) : d;
            this.L = a;
            this.o = d;
            this.j = new _.v.Map;
            this.X = new _.v.Set;
            b.m = function(e) {
                return mP(c, e)
            }
        };
    nP.prototype.defineSlot = function(a, b, c, d, e) {
        a = nm(this, a, b, c, d, e);
        var f = a.slotId;
        if (f) return f.j;
        a.ue || b.error(Uk("googletag.defineSlot", [c, d, e]));
        return null
    };
    var nm = function(a, b, c, d, e, f, g) {
        return "string" === typeof d && 0 < d.length && e && (void 0 === f || "string" === typeof f) ? a.add(b, c, d, e, {
            Kb: f,
            mi: void 0 === g ? !1 : g
        }) : {}
    };
    nP.prototype.add = function(a, b, c, d, e, f) {
        var g = this,
            h = e.Kb,
            k = void 0 === e.format ? 0 : e.format,
            l = void 0 === e.mi ? !1 : e.mi;
        e = void 0 === e.qb ? !1 : e.qb;
        f = void 0 === f ? _.t : f;
        try {
            var m = new RegExp(this.o, "u");
            if (m.test("/1") && !m.test(c)) return b.error(TI(c)), {
                ue: !0
            }
        } catch (p) {}
        f = bp(k, f, e);
        null !== f && To(a, f, Zo(k));
        if (f) return No(b, f, k, c), {};
        l && lP();
        k = this.j.get(c) || Number(l);
        b = oP(this, a, b, c, k, d, h || "gpt_unit_" + c + "_" + k);
        a = b.Da;
        var n = b.slotId;
        b = b.ue;
        if (!n) return {
            ue: b
        };
        this.j.set(c, k + 1);
        this.X.add(n);
        _.tn(n, function() {
            return void g.X.delete(n)
        });
        JG(c);
        return {
            slotId: n,
            Da: a
        }
    };
    var lL = function(a, b) {
            a = _.z(a.X);
            for (var c = a.next(); !c.done; c = a.next())
                if (c = c.value, c.getDomId() === b) return c
        },
        Xr = function(a) {
            a = _.z(a);
            for (var b = a.next(); !b.done; b = a.next()) b.value.wa()
        },
        oP = function(a, b, c, d, e, f, g) {
            var h = lL(a, g);
            if (h) return c.error(SI(g, d, h.getAdUnitPath())), {
                ue: !0
            };
            var k = new qK;
            rK(Vn(k, 1, d), g);
            sK(k, Cm(f));
            $G(k);
            var l = new yf(b, d, e, g);
            bK(l, Om(b, c, l));
            _.tn(l, function() {
                var m = Pi(),
                    n = l.getDomId();
                delete m.o[n];
                m.m.delete(l);
                m = l.getAdUnitPath();
                m = nh(m);
                var p;
                n = (null != (p = Xh.get(m)) ? p : 0) - 1;
                0 >= n ? Xh.delete(m) : Xh.set(m, n);
                c.info(oJ(l.toString()), l);
                (p = Pk.get(l)) && Qk.delete(p);
                Pk.delete(l)
            });
            c.info(HI(l.toString()), l);
            l.listen(qI, function(m) {
                m = m.detail.Fl;
                c.info(II(l.getAdUnitPath()), l);
                SG(_.Rf(Jh), "7", 9, EI(a.L, l), 0, m)
            });
            l.listen(pI, function(m) {
                var n = m.detail;
                c.info(JI(l.getAdUnitPath()), l);
                var p;
                m = _.Rf(Jh);
                var r = Kr(k, 20);
                n = null != (p = n.getEscapedQemQueryId()) ? p : "";
                m.j && (_.t.google_timing_params = _.t.google_timing_params || {}, _.t.google_timing_params["qqid." + r] = n)
            });
            l.listen(Mr, function() {
                return void c.info(KI(l.getAdUnitPath()), l)
            });
            l.listen(Nr, function() {
                return void c.info(LI(l.getAdUnitPath()), l)
            });
            return {
                Da: k,
                slotId: l
            }
        },
        mP = function(a, b) {
            var c = new RegExp("(^|,|/)" + b + "($|,|/)");
            return [].concat(_.lh(a.X)).some(function(d) {
                return c.test(nh(d.getAdUnitPath()))
            })
        };
    (function(a, b) {
        var c = null != a ? a : {
            pvsid: _.Rh(window),
            eb: "1",
            xb: "m202311150101",
            Qa: new gu(3, "m202311150101", 0),
            Hg: !0,
            Pf: 1
        };
        try {
            sc(function(ya) {
                Lh(c, 1190, ya)
            });
            var d = Hm();
            Me(!_.Rf(ii).j);
            _.A(Object, "assign").call(Object, ji, d._vars_);
            d._vars_ = ji;
            if (d.evalScripts) d.evalScripts();
            else {
                BH();
                try {
                    kg()
                } catch (ya) {
                    Lh(c, 408, ya)
                }
                Kp();
                var e = new FK;
                try {
                    gg(e.H), Rl(13, c), Rl(3, c)
                } catch (ya) {
                    Lh(c, 408, ya)
                }
                var f = eu(c, e),
                    g = null != a ? a : ju(f, c),
                    h = null != b ? b : new EK(g);
                Bh(g);
                Gh(g);
                Zi("gpt_fifwin", function(ya) {
                    ej(ya, g)
                }, d.fifWin ? .01 : 0);
                var k = new wI,
                    l = new nP(k, e),
                    m = new PN(g),
                    n = _.ki(260),
                    p = new YN(g, l, Pi(), h, k, n, e, m),
                    r = sz(),
                    w = Fs(g),
                    u = new lI(g),
                    x = new lI(g),
                    y = new lI(g),
                    C = _.ki(150),
                    D;
                n && (D = ZN(p, u, C, w));
                var E = _.ki(221),
                    J = new EM,
                    M = new HL,
                    K, X, ba, la = null != (ba = null == (K = D) ? void 0 : null == (X = K.hf) ? void 0 : X.sb) ? ba : new yn,
                    pa = new aP(g, l, h, k, m, r, e, u, n, E, J, M, D, w, la);
                _.H(tC) && new mL(g, u, k, l);
                var za = Pi().j;
                ys(g, h, pa, za, l, x, y, e, M, la);
                $m(g, d, h);
                window.setTimeout(function() {
                    for (var ya = window.document.scripts, Qa = 0, Ga = 0, zb = 0; zb < ya.length; zb++) ya[zb].src.match("securepubads.g.doubleclick.net/tag/js/gpt.js") ? Qa++ : ya[zb].src.match("www.googletagservices.com/tag/js/gpt.js") && Ga++;
                    1 < Qa && 0 === Ga || 1 < Ga && 0 === Qa ? Q(h, NJ()) : 0 < Ga && 0 < Qa && h.error(OJ())
                }, 1E3);
                Ur();
                if (_.H(tC) || _.Rf(Jh).j) Vt(), Zt();
                Pq(g, h);
                cn(g)
            }
        } catch (ya) {
            Lh(c, 106, ya)
        }
    })();
    _.pP = _.t.requestAnimationFrame || _.t.webkitRequestAnimationFrame;
    _.qP = !!_.pP && !/'iPhone'/.test(_.t.navigator.userAgent);
    _.rP = function(a, b, c) {
        _.U.call(this);
        var d = this;
        this.A = a;
        this.j = b;
        this.m = c;
        this.U = null;
        _.tn(this, function() {
            return d.U = null
        })
    };
    _.T(_.rP, _.U);
}).call(this, {});