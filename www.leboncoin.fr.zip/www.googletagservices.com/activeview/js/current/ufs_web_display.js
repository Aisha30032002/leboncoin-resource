(function() {
    var n, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("a");
        },
        da =
        ca(this),
        p = function(a, b) {
            if (b) a: {
                var c = da;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && ba(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
    p("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.Gg = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.Gg
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("b");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    p("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = da[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ea(aa(this))
                }
            })
        }
        return a
    });
    p("Symbol.asyncIterator", function(a) {
        return a ? a : Symbol("Symbol.asyncIterator")
    });
    var ea = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        fa = function(a) {
            return a.raw = a
        },
        ha = function(a, b) {
            a.raw = b;
            return a
        },
        t = function(a) {
            var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if ("number" == typeof a.length) return {
                next: aa(a)
            };
            throw Error("c`" + String(a));
        },
        u = function(a) {
            if (!(a instanceof Array)) {
                a = t(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        ja = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a,
                b)
        },
        ka = "function" == typeof Object.assign ? Object.assign : function(a, b) {
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) ja(d, e) && (a[e] = d[e])
            }
            return a
        };
    p("Object.assign", function(a) {
        return a || ka
    });
    var la = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ma;
    if ("function" == typeof Object.setPrototypeOf) ma = Object.setPrototypeOf;
    else {
        var na;
        a: {
            var oa = {
                    a: !0
                },
                qa = {};
            try {
                qa.__proto__ = oa;
                na = qa.a;
                break a
            } catch (a) {}
            na = !1
        }
        ma = na ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError("d`" + a);
            return a
        } : null
    }
    var ra = ma,
        x = function(a, b) {
            a.prototype = la(b.prototype);
            a.prototype.constructor = a;
            if (ra) ra(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Qi = b.prototype
        },
        sa = function() {
            this.nc = !1;
            this.gb = null;
            this.df = void 0;
            this.ma = 1;
            this.Ma = this.ib = 0;
            this.ke = this.ga = null
        };
    sa.prototype.fb = function() {
        if (this.nc) throw new TypeError("f");
        this.nc = !0
    };
    sa.prototype.sc = function(a) {
        this.df = a
    };
    sa.prototype.Bc = function(a) {
        this.ga = {
            Bf: a,
            Sf: !0
        };
        this.ma = this.ib || this.Ma
    };
    sa.prototype.return = function(a) {
        this.ga = {
            return: a
        };
        this.ma = this.Ma
    };
    var ta = function(a, b, c) {
        a.ma = c;
        return {
            value: b
        }
    };
    sa.prototype.pb = function(a) {
        this.ma = a
    };
    var ua = function(a, b, c) {
            c = a.ke.splice(c || 0)[0];
            (c = a.ga = a.ga || c) ? c.Sf ? a.ma = a.ib || a.Ma : void 0 != c.pb && a.Ma < c.pb ? (a.ma = c.pb, a.ga = null) : a.ma = a.Ma: a.ma = b
        },
        va = function(a) {
            this.s = new sa;
            this.vi = a
        };
    va.prototype.sc = function(a) {
        this.s.fb();
        if (this.s.gb) return wa(this, this.s.gb.next, a, this.s.sc);
        this.s.sc(a);
        return xa(this)
    };
    var ya = function(a, b) {
        a.s.fb();
        var c = a.s.gb;
        if (c) return wa(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.s.return);
        a.s.return(b);
        return xa(a)
    };
    va.prototype.Bc = function(a) {
        this.s.fb();
        if (this.s.gb) return wa(this, this.s.gb["throw"], a, this.s.sc);
        this.s.Bc(a);
        return xa(this)
    };
    var wa = function(a, b, c, d) {
            try {
                var e = b.call(a.s.gb, c);
                if (!(e instanceof Object)) throw new TypeError("e`" + e);
                if (!e.done) return a.s.nc = !1, e;
                var f = e.value
            } catch (g) {
                return a.s.gb = null, a.s.Bc(g), xa(a)
            }
            a.s.gb = null;
            d.call(a.s, f);
            return xa(a)
        },
        xa = function(a) {
            for (; a.s.ma;) try {
                var b = a.vi(a.s);
                if (b) return a.s.nc = !1, {
                    value: b.value,
                    done: !1
                }
            } catch (c) {
                a.s.df = void 0, a.s.Bc(c)
            }
            a.s.nc = !1;
            if (a.s.ga) {
                b = a.s.ga;
                a.s.ga = null;
                if (b.Sf) throw b.Bf;
                return {
                    value: b.return,
                    done: !0
                }
            }
            return {
                value: void 0,
                done: !0
            }
        },
        za = function(a) {
            this.next =
                function(b) {
                    return a.sc(b)
                };
            this.throw = function(b) {
                return a.Bc(b)
            };
            this.return = function(b) {
                return ya(a, b)
            };
            this[Symbol.iterator] = function() {
                return this
            }
        },
        Aa = function(a) {
            function b(d) {
                return a.next(d)
            }

            function c(d) {
                return a.throw(d)
            }
            return new Promise(function(d, e) {
                function f(g) {
                    g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
                }
                f(a.next())
            })
        },
        Ba = function(a) {
            return Aa(new za(new va(a)))
        },
        Ca = function(a) {
            this[Symbol.asyncIterator] = function() {
                return this
            };
            this[Symbol.iterator] = function() {
                return a
            };
            this.next = function(b) {
                return Promise.resolve(a.next(b))
            };
            void 0 !== a["throw"] && (this["throw"] = function(b) {
                return Promise.resolve(a["throw"](b))
            });
            void 0 !== a["return"] && (this["return"] = function(b) {
                return Promise.resolve(a["return"](b))
            })
        },
        y = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    p("Promise", function(a) {
        function b() {
            this.Wa = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(k) {
                k(g)
            })
        }
        if (a) return a;
        b.prototype.nf = function(g) {
            if (null == this.Wa) {
                this.Wa = [];
                var k = this;
                this.pf(function() {
                    k.nh()
                })
            }
            this.Wa.push(g)
        };
        var d = da.setTimeout;
        b.prototype.pf = function(g) {
            d(g, 0)
        };
        b.prototype.nh = function() {
            for (; this.Wa && this.Wa.length;) {
                var g = this.Wa;
                this.Wa = [];
                for (var k = 0; k < g.length; ++k) {
                    var h = g[k];
                    g[k] = null;
                    try {
                        h()
                    } catch (l) {
                        this.Tg(l)
                    }
                }
            }
            this.Wa = null
        };
        b.prototype.Tg = function(g) {
            this.pf(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.Tb = 0;
            this.yc = void 0;
            this.Ob = [];
            this.Vf = !1;
            var k = this.ae();
            try {
                g(k.resolve, k.reject)
            } catch (h) {
                k.reject(h)
            }
        };
        e.prototype.ae = function() {
            function g(l) {
                return function(m) {
                    h || (h = !0, l.call(k, m))
                }
            }
            var k = this,
                h = !1;
            return {
                resolve: g(this.Fi),
                reject: g(this.Pe)
            }
        };
        e.prototype.Fi = function(g) {
            if (g === this) this.Pe(new TypeError("g"));
            else if (g instanceof e) this.Ki(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var k = null != g;
                        break a;
                    case "function":
                        k = !0;
                        break a;
                    default:
                        k = !1
                }
                k ? this.Ei(g) : this.Ff(g)
            }
        };
        e.prototype.Ei = function(g) {
            var k = void 0;
            try {
                k = g.then
            } catch (h) {
                this.Pe(h);
                return
            }
            "function" == typeof k ? this.Li(k, g) : this.Ff(g)
        };
        e.prototype.Pe = function(g) {
            this.qg(2, g)
        };
        e.prototype.Ff = function(g) {
            this.qg(1, g)
        };
        e.prototype.qg = function(g, k) {
            if (0 != this.Tb) throw Error("h`" + g + "`" + k + "`" + this.Tb);
            this.Tb = g;
            this.yc = k;
            2 === this.Tb && this.Hi();
            this.oh()
        };
        e.prototype.Hi = function() {
            var g = this;
            d(function() {
                if (g.gi()) {
                    var k = da.console;
                    "undefined" !== typeof k && k.error(g.yc)
                }
            }, 1)
        };
        e.prototype.gi = function() {
            if (this.Vf) return !1;
            var g = da.CustomEvent,
                k = da.Event,
                h = da.dispatchEvent;
            if ("undefined" === typeof h) return !0;
            "function" === typeof g ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof k ? g = new k("unhandledrejection", {
                cancelable: !0
            }) : (g = da.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.yc;
            return h(g)
        };
        e.prototype.oh = function() {
            if (null != this.Ob) {
                for (var g = 0; g < this.Ob.length; ++g) f.nf(this.Ob[g]);
                this.Ob = null
            }
        };
        var f = new b;
        e.prototype.Ki = function(g) {
            var k =
                this.ae();
            g.Pc(k.resolve, k.reject)
        };
        e.prototype.Li = function(g, k) {
            var h = this.ae();
            try {
                g.call(k, h.resolve, h.reject)
            } catch (l) {
                h.reject(l)
            }
        };
        e.prototype.then = function(g, k) {
            function h(q, v) {
                return "function" == typeof q ? function(w) {
                    try {
                        l(q(w))
                    } catch (A) {
                        m(A)
                    }
                } : v
            }
            var l, m, r = new e(function(q, v) {
                l = q;
                m = v
            });
            this.Pc(h(g, l), h(k, m));
            return r
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.Pc = function(g, k) {
            function h() {
                switch (l.Tb) {
                    case 1:
                        g(l.yc);
                        break;
                    case 2:
                        k(l.yc);
                        break;
                    default:
                        throw Error("i`" +
                            l.Tb);
                }
            }
            var l = this;
            null == this.Ob ? f.nf(h) : this.Ob.push(h);
            this.Vf = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(k, h) {
                h(g)
            })
        };
        e.race = function(g) {
            return new e(function(k, h) {
                for (var l = t(g), m = l.next(); !m.done; m = l.next()) c(m.value).Pc(k, h)
            })
        };
        e.all = function(g) {
            var k = t(g),
                h = k.next();
            return h.done ? c([]) : new e(function(l, m) {
                function r(w) {
                    return function(A) {
                        q[w] = A;
                        v--;
                        0 == v && l(q)
                    }
                }
                var q = [],
                    v = 0;
                do q.push(void 0), v++, c(h.value).Pc(r(q.length - 1), m), h = k.next(); while (!h.done)
            })
        };
        return e
    });
    p("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) ja(b, d) && c.push(b[d]);
            return c
        }
    });
    var Da = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    p("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Da(this, function(b) {
                return b
            })
        }
    });
    p("WeakMap", function(a) {
        function b() {}

        function c(h) {
            var l = typeof h;
            return "object" === l && null !== h || "function" === l
        }

        function d(h) {
            if (!ja(h, f)) {
                var l = new b;
                ba(h, f, {
                    value: l
                })
            }
        }

        function e(h) {
            var l = Object[h];
            l && (Object[h] = function(m) {
                if (m instanceof b) return m;
                Object.isExtensible(m) && d(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var h = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [h, 2],
                            [l, 3]
                        ]);
                    if (2 != m.get(h) || 3 != m.get(l)) return !1;
                    m.delete(h);
                    m.set(l, 4);
                    return !m.has(h) && 4 == m.get(l)
                } catch (r) {
                    return !1
                }
            }()) return a;
        var f = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var g = 0,
            k = function(h) {
                this.kc = (g += Math.random() + 1).toString();
                if (h) {
                    h = t(h);
                    for (var l; !(l = h.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        k.prototype.set = function(h, l) {
            if (!c(h)) throw Error("j");
            d(h);
            if (!ja(h, f)) throw Error("k`" + h);
            h[f][this.kc] = l;
            return this
        };
        k.prototype.get = function(h) {
            return c(h) && ja(h, f) ? h[f][this.kc] : void 0
        };
        k.prototype.has = function(h) {
            return c(h) && ja(h, f) && ja(h[f], this.kc)
        };
        k.prototype.delete = function(h) {
            return c(h) &&
                ja(h, f) && ja(h[f], this.kc) ? delete h[f][this.kc] : !1
        };
        return k
    });
    p("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var k = Object.seal({
                            x: 4
                        }),
                        h = new a(t([
                            [k, "s"]
                        ]));
                    if ("s" != h.get(k) || 1 != h.size || h.get({
                            x: 4
                        }) || h.set({
                            x: 4
                        }, "t") != h || 2 != h.size) return !1;
                    var l = h.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != k || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (r) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(k) {
                this[0] = {};
                this[1] =
                    f();
                this.size = 0;
                if (k) {
                    k = t(k);
                    for (var h; !(h = k.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        c.prototype.set = function(k, h) {
            k = 0 === k ? 0 : k;
            var l = d(this, k);
            l.list || (l.list = this[0][l.id] = []);
            l.S ? l.S.value = h : (l.S = {
                next: this[1],
                Sa: this[1].Sa,
                head: this[1],
                key: k,
                value: h
            }, l.list.push(l.S), this[1].Sa.next = l.S, this[1].Sa = l.S, this.size++);
            return this
        };
        c.prototype.delete = function(k) {
            k = d(this, k);
            return k.S && k.list ? (k.list.splice(k.index, 1), k.list.length || delete this[0][k.id], k.S.Sa.next = k.S.next, k.S.next.Sa = k.S.Sa,
                k.S.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Sa = f();
            this.size = 0
        };
        c.prototype.has = function(k) {
            return !!d(this, k).S
        };
        c.prototype.get = function(k) {
            return (k = d(this, k).S) && k.value
        };
        c.prototype.entries = function() {
            return e(this, function(k) {
                return [k.key, k.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(k) {
                return k.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(k) {
                return k.value
            })
        };
        c.prototype.forEach = function(k, h) {
            for (var l = this.entries(),
                    m; !(m = l.next()).done;) m = m.value, k.call(h, m[1], m[0], this)
        };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(k, h) {
                var l = h && typeof h;
                "object" == l || "function" == l ? b.has(h) ? l = b.get(h) : (l = "" + ++g, b.set(h, l)) : l = "p_" + h;
                var m = k[0][l];
                if (m && ja(k[0], l))
                    for (k = 0; k < m.length; k++) {
                        var r = m[k];
                        if (h !== h && r.key !== r.key || h === r.key) return {
                            id: l,
                            list: m,
                            index: k,
                            S: r
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    S: void 0
                }
            },
            e = function(k, h) {
                var l = k[1];
                return ea(function() {
                    if (l) {
                        for (; l.head != k[1];) l = l.Sa;
                        for (; l.next != l.head;) return l =
                            l.next, {
                                done: !1,
                                value: h(l)
                            };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var k = {};
                return k.Sa = k.next = k.head = k
            },
            g = 0;
        return c
    });
    var Ea = function(a, b, c) {
        if (null == a) throw new TypeError("l`" + c);
        if (b instanceof RegExp) throw new TypeError("m`" + c);
        return a + ""
    };
    p("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    p("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ea(this, b, "startsWith");
            b += "";
            var e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });
    p("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    });
    p("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Da(this, function(b, c) {
                return c
            })
        }
    });
    p("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    p("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    p("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== Ea(this, b, "includes").indexOf(b, c || 0)
        }
    });
    p("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(t([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.Da = new Map;
            if (c) {
                c =
                    t(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.Da.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.Da.set(c, c);
            this.size = this.Da.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.Da.delete(c);
            this.size = this.Da.size;
            return c
        };
        b.prototype.clear = function() {
            this.Da.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.Da.has(c)
        };
        b.prototype.entries = function() {
            return this.Da.entries()
        };
        b.prototype.values = function() {
            return this.Da.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.Da.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });
    p("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Da(this, function(b, c) {
                return [b, c]
            })
        }
    });
    p("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    p("Math.log2", function(a) {
        return a ? a : function(b) {
            return Math.log(b) / Math.LN2
        }
    });
    p("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || Infinity === b || -Infinity === b || 0 === b) return b;
            var c = Math.floor(Math.abs(b));
            return 0 > b ? -c : c
        }
    });
    p("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    });
    p("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
        }
    });
    p("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(k) {
                return k
            };
            var e = [],
                f = "undefined" != typeof Symbol && Symbol.iterator && b[Symbol.iterator];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    p("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return "number" === typeof b && isNaN(b)
        }
    });
    p("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            0 > c && (c = Math.max(0, e + c));
            if (null == d || d > e) d = e;
            d = Number(d);
            0 > d && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    });
    var Ia = function(a) {
        return a ? a : Array.prototype.fill
    };
    p("Int8Array.prototype.fill", Ia);
    p("Uint8Array.prototype.fill", Ia);
    p("Uint8ClampedArray.prototype.fill", Ia);
    p("Int16Array.prototype.fill", Ia);
    p("Uint16Array.prototype.fill", Ia);
    p("Int32Array.prototype.fill", Ia);
    p("Uint32Array.prototype.fill", Ia);
    p("Float32Array.prototype.fill", Ia);
    p("Float64Array.prototype.fill", Ia);
    p("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) ja(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    p("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = void 0 === b ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && 0 < b ? (d = Array.prototype.flat.call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Ja = this || self,
        Ka = function(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var d = Ja, e = 0; e < c.length; e++)
                    if (d = d[c[e]], null == d) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return null != a ? a : b
        },
        La = function(a) {
            var b = typeof a;
            return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        Ma = function(a) {
            var b = La(a);
            return "array" == b || "object" == b && "number" == typeof a.length
        },
        Na = function(a) {
            var b = typeof a;
            return "object" == b && null != a || "function" == b
        },
        Oa = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.Qi = b.prototype;
            a.prototype = new c;
            a.prototype.constructor =
                a;
            a.Ej = function(d, e, f) {
                for (var g = Array(arguments.length - 2), k = 2; k < arguments.length; k++) g[k - 2] = arguments[k];
                return b.prototype[e].apply(d, g)
            }
        },
        Pa = function(a) {
            return a
        };
    var Qa = function() {
        this.yg = 0
    };
    Qa.prototype.Ub = function(a, b) {
        var c = this;
        return function() {
            var d = y.apply(0, arguments);
            c.yg = a;
            return b.apply(null, u(d))
        }
    };
    var Sa = function() {
            var a = {};
            this.Fa = (a[3] = [], a[2] = [], a[1] = [], a);
            this.Ae = !1
        },
        Ua = function(a, b, c) {
            var d = Ta(a, c);
            a.Fa[c].push(b);
            d && 1 === a.Fa[c].length && a.flush()
        },
        Ta = function(a, b) {
            return Object.keys(a.Fa).map(function(c) {
                return Number(c)
            }).filter(function(c) {
                return !isNaN(c) && c > b
            }).every(function(c) {
                return 0 === a.Fa[c].length
            })
        };
    Sa.prototype.flush = function() {
        if (!this.Ae) {
            this.Ae = !0;
            try {
                for (; Object.values(this.Fa).some(function(a) {
                        return 0 < a.length
                    });) Va(this, 3), Va(this, 2), Va(this, 1)
            } catch (a) {
                throw Object.values(this.Fa).forEach(function(b) {
                    return void b.splice(0, b.length)
                }), a;
            } finally {
                this.Ae = !1
            }
        }
    };
    var Va = function(a, b) {
        for (; Ta(a, b) && 0 < a.Fa[b].length;) a.Fa[b][0](), a.Fa[b].shift()
    };
    da.Object.defineProperties(Sa.prototype, {
        mg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Object.values(this.Fa).some(function(a) {
                    return 0 < a.length
                })
            }
        }
    });

    function Wa(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, Wa);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        void 0 !== b && (this.cause = b)
    }
    Oa(Wa, Error);
    Wa.prototype.name = "CustomError";
    var Xa;

    function Ya(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        Wa.call(this, c + a[d])
    }
    Oa(Ya, Wa);
    Ya.prototype.name = "AssertionError";

    function Za(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new Ya("" + e, f || []);
    }
    var z = function(a, b, c) {
            a || Za("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        $a = function(a, b, c) {
            null == a && Za("Expected to exist: %s.", [a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        ab = function(a, b) {
            throw new Ya("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        bb = function(a, b, c) {
            "number" !== typeof a && Za("Expected number but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        cb = function(a, b, c) {
            "string" !== typeof a && Za("Expected string but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        db = function(a, b, c) {
            "function" !== typeof a && Za("Expected function but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        eb = function(a, b, c) {
            Na(a) || Za("Expected object but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        F = function(a, b, c) {
            Array.isArray(a) || Za("Expected array but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        gb = function(a, b, c, d) {
            a instanceof b || Za("Expected instanceof %s but got %s.", [fb(b), fb(a)], c, Array.prototype.slice.call(arguments, 3));
            return a
        };

    function fb(a) {
        return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : null === a ? "null" : typeof a
    };
    var hb = Array.prototype.forEach ? function(a, b) {
            z(null != a.length);
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        },
        ib = Array.prototype.map ? function(a, b) {
            z(null != a.length);
            return Array.prototype.map.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = Array(c), e = "string" === typeof a ? a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
            return d
        },
        kb = Array.prototype.some ? function(a, b) {
            z(null !=
                a.length);
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };

    function lb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function mb(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function nb(a, b, c) {
        if (!Ma(a) || !Ma(b) || a.length != b.length) return !1;
        var d = a.length;
        c = c || ob;
        for (var e = 0; e < d; e++)
            if (!c(a[e], b[e])) return !1;
        return !0
    }

    function ob(a, b) {
        return a === b
    }

    function pb(a, b) {
        return lb.apply([], ib(a, b))
    };
    var qb;
    var sb = function(a, b) {
        if (b !== rb) throw Error("n");
        this.hg = a
    };
    sb.prototype.toString = function() {
        return this.hg + ""
    };
    var rb = {},
        tb = function(a) {
            if (void 0 === qb) {
                var b = null;
                var c = Ja.trustedTypes;
                if (c && c.createPolicy) try {
                    b = c.createPolicy("goog#html", {
                        createHTML: Pa,
                        createScript: Pa,
                        createScriptURL: Pa
                    })
                } catch (d) {
                    Ja.console && Ja.console.error(d.message)
                }
                qb = b
            }
            a = (b = qb) ? b.createScriptURL(a) : a;
            return new sb(a, rb)
        };
    var vb = function(a, b) {
        return -1 != a.toLowerCase().indexOf(b.toLowerCase())
    };
    var yb = function(a) {
        if (xb !== xb) throw Error("o");
        this.ui = a
    };
    yb.prototype.toString = function() {
        return this.ui.toString()
    };
    var xb = {};
    new yb("about:invalid#zClosurez");
    new yb("about:blank");
    var zb = {},
        Ab = function() {
            if (zb !== zb) throw Error("p");
            this.ti = ""
        };
    Ab.prototype.toString = function() {
        return this.ti.toString()
    };
    new Ab;
    var Bb = {},
        Cb = function() {
            if (Bb !== Bb) throw Error("q");
            this.si = ""
        };
    Cb.prototype.toString = function() {
        return this.si.toString()
    };
    new Cb;
    var Db = Ka(610401301, !1),
        Eb = Ka(572417392, Ka(1, !0));

    function Fb() {
        var a = Ja.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Gb, Hb = Ja.navigator;
    Gb = Hb ? Hb.userAgentData || null : null;

    function Ib(a) {
        return Db ? Gb ? Gb.brands.some(function(b) {
            return (b = b.brand) && -1 != b.indexOf(a)
        }) : !1 : !1
    }

    function H(a) {
        return -1 != Fb().indexOf(a)
    };

    function Jb() {
        return Db ? !!Gb && 0 < Gb.brands.length : !1
    }

    function Kb() {
        return Jb() ? !1 : H("Opera")
    }

    function Lb() {
        return Jb() ? !1 : H("Trident") || H("MSIE")
    }

    function Mb() {
        return H("Safari") && !(Nb() || (Jb() ? 0 : H("Coast")) || Kb() || (Jb() ? 0 : H("Edge")) || (Jb() ? Ib("Microsoft Edge") : H("Edg/")) || (Jb() ? Ib("Opera") : H("OPR")) || H("Firefox") || H("FxiOS") || H("Silk") || H("Android"))
    }

    function Nb() {
        return Jb() ? Ib("Chromium") : (H("Chrome") || H("CriOS")) && !(Jb() ? 0 : H("Edge")) || H("Silk")
    }

    function Ob() {
        return H("Android") && !(Nb() || H("Firefox") || H("FxiOS") || Kb() || H("Silk"))
    }

    function Pb() {
        var a = Fb();
        if (Lb()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
        } else a = "";
        return a
    }

    function Rb() {
        if (Jb()) {
            var a = Gb.brands.find(function(b) {
                return "Internet Explorer" === b.brand
            });
            if (!a || !a.version) return NaN;
            a = a.version.split(".")
        } else {
            a = Pb();
            if ("" === a) return NaN;
            a = a.split(".")
        }
        return 0 === a.length ? NaN : Number(a[0])
    };
    var Sb = {},
        Ub = function() {
            var a = Ja.trustedTypes && Ja.trustedTypes.emptyHTML || "";
            if (Sb !== Sb) throw Error("r");
            this.ri = a
        };
    Ub.prototype.toString = function() {
        return this.ri.toString()
    };
    new Ub;
    var Vb = function() {
        this.names = new Map
    };
    Vb.prototype.Na = function(a) {
        var b = this.names.get(a);
        if (b) return b;
        var c;
        b = null != (c = a.description) ? c : Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ Date.now()).toString(36);
        this.names.set(a, b);
        return b
    };
    /*


     Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

         http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    var Wb = !1,
        Xb = {
            set ya(a) {
                a ? console.warn("s`" + Error().stack) : Wb && console.log("t");
                Wb = a
            },
            get ya() {
                return Wb
            }
        };
    var Yb = "function" === typeof Symbol && Symbol.observable || "@@observable";

    function Zb(a) {
        setTimeout(function() {
            throw a;
        }, 0)
    };
    var $b = {
        closed: !0,
        next: function() {},
        error: function(a) {
            if (Xb.ya) throw a;
            Zb(a)
        },
        complete: function() {}
    };
    var ac = function() {
        function a(b) {
            this.message = b ? b.length + " errors occurred during unsubscription:\n" + b.map(function(c, d) {
                return d + 1 + ") " + c.toString()
            }).join("\n  ") : "";
            this.name = "UnsubscriptionError";
            this.errors = b;
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    }();
    var bc = Array.isArray || function(a) {
        return a && "number" === typeof a.length
    };

    function cc(a) {
        return "function" === typeof a
    };

    function dc(a) {
        return null !== a && "object" === typeof a
    };
    var I = function(a) {
        this.closed = !1;
        this.Ab = this.Wb = null;
        a && (this.Ig = !0, this.Ia = a)
    };
    I.prototype.unsubscribe = function() {
        if (!this.closed) {
            var a = this.Wb,
                b = this.Ig,
                c = this.Ia,
                d = this.Ab;
            this.closed = !0;
            this.Ab = this.Wb = null;
            if (a instanceof I) a.remove(this);
            else if (null !== a)
                for (var e = 0; e < a.length; ++e) a[e].remove(this);
            if (cc(c)) {
                b && (this.Ia = void 0);
                try {
                    c.call(this)
                } catch (h) {
                    var f = h instanceof ac ? ec(h.errors) : [h]
                }
            }
            if (bc(d)) {
                e = -1;
                for (var g = d.length; ++e < g;) {
                    var k = d[e];
                    if (dc(k)) try {
                        k.unsubscribe()
                    } catch (h) {
                        f = f || [], h instanceof ac ? f = f.concat(ec(h.errors)) : f.push(h)
                    }
                }
            }
            if (f) throw new ac(f);
        }
    };
    I.prototype.add = function(a) {
        var b = a;
        if (!a) return I.EMPTY;
        switch (typeof a) {
            case "function":
                b = new I(a);
            case "object":
                if (b === this || b.closed || "function" !== typeof b.unsubscribe) return b;
                if (this.closed) return b.unsubscribe(), b;
                b instanceof I || (a = b, b = new I, b.Ab = [a]);
                break;
            default:
                throw Error("u`" + a);
        }
        var c = b.Wb;
        if (null === c) b.Wb = this;
        else if (c instanceof I) {
            if (c === this) return b;
            b.Wb = [c, this]
        } else if (-1 === c.indexOf(this)) c.push(this);
        else return b;
        a = this.Ab;
        null === a ? this.Ab = [b] : a.push(b);
        return b
    };
    I.prototype.remove = function(a) {
        var b = this.Ab;
        b && (a = b.indexOf(a), -1 !== a && b.splice(a, 1))
    };
    var fc = new I;
    fc.closed = !0;
    I.EMPTY = fc;

    function gc(a) {
        return a instanceof I || a && "closed" in a && "function" === typeof a.remove && "function" === typeof a.add && "function" === typeof a.unsubscribe
    }

    function ec(a) {
        return a.reduce(function(b, c) {
            return b.concat(c instanceof ac ? c.errors : c)
        }, [])
    };
    var J = function(a, b, c) {
        I.call(this);
        this.yd = null;
        this.F = this.na = this.xd = !1;
        switch (arguments.length) {
            case 0:
                this.destination = $b;
                break;
            case 1:
                if (!a) {
                    this.destination = $b;
                    break
                }
                if ("object" === typeof a) {
                    a instanceof J ? (this.na = a.na, this.destination = a, a.add(this)) : (this.na = !0, this.destination = new hc(this, a));
                    break
                }
            default:
                this.na = !0, this.destination = new hc(this, a, b, c)
        }
    };
    x(J, I);
    J.EMPTY = I.EMPTY;
    J.create = function(a, b, c) {
        a = new J(a, b, c);
        a.na = !1;
        return a
    };
    n = J.prototype;
    n.next = function(a) {
        this.F || this.o(a)
    };
    n.error = function(a) {
        this.F || (this.F = !0, this.aa(a))
    };
    n.complete = function() {
        this.F || (this.F = !0, this.D())
    };
    n.unsubscribe = function() {
        this.closed || (this.F = !0, I.prototype.unsubscribe.call(this))
    };
    n.o = function(a) {
        this.destination.next(a)
    };
    n.aa = function(a) {
        this.destination.error(a);
        this.unsubscribe()
    };
    n.D = function() {
        this.destination.complete();
        this.unsubscribe()
    };
    var hc = function(a, b, c, d) {
        J.call(this);
        this.Xb = a;
        var e = this;
        if (cc(b)) var f = b;
        else b && (f = b.next, c = b.error, d = b.complete, b !== $b && (e = Object.create(b), gc(b) && b.add(this.unsubscribe.bind(this)), e.unsubscribe = this.unsubscribe.bind(this)));
        this.Ha = e;
        this.o = f;
        this.aa = c;
        this.D = d
    };
    x(hc, J);
    hc.EMPTY = J.EMPTY;
    hc.create = J.create;
    n = hc.prototype;
    n.next = function(a) {
        if (!this.F && this.o) {
            var b = this.Xb;
            Xb.ya && b.na ? this.Hd(b, this.o, a) && this.unsubscribe() : this.Id(this.o, a)
        }
    };
    n.error = function(a) {
        if (!this.F) {
            var b = this.Xb,
                c = Xb.ya;
            if (this.aa) c && b.na ? this.Hd(b, this.aa, a) : this.Id(this.aa, a), this.unsubscribe();
            else if (b.na) c ? (b.yd = a, b.xd = !0) : Zb(a), this.unsubscribe();
            else {
                this.unsubscribe();
                if (c) throw a;
                Zb(a)
            }
        }
    };
    n.complete = function() {
        var a = this;
        if (!this.F) {
            var b = this.Xb;
            if (this.D) {
                var c = function() {
                    return a.D.call(a.Ha)
                };
                Xb.ya && b.na ? this.Hd(b, c) : this.Id(c)
            }
            this.unsubscribe()
        }
    };
    n.Id = function(a, b) {
        try {
            a.call(this.Ha, b)
        } catch (c) {
            this.unsubscribe();
            if (Xb.ya) throw c;
            Zb(c)
        }
    };
    n.Hd = function(a, b, c) {
        if (!Xb.ya) throw Error("v");
        try {
            b.call(this.Ha, c)
        } catch (d) {
            return Xb.ya ? (a.yd = d, a.xd = !0) : Zb(d), !0
        }
        return !1
    };
    n.Ia = function() {
        var a = this.Xb;
        this.Xb = this.Ha = null;
        a.unsubscribe()
    };

    function ic(a) {
        return a
    };

    function K() {
        return jc(y.apply(0, arguments))
    }

    function jc(a) {
        return 0 === a.length ? ic : 1 === a.length ? a[0] : function(b) {
            return a.reduce(function(c, d) {
                return d(c)
            }, b)
        }
    };

    function kc(a) {
        return a && "function" === typeof a.next && "function" === typeof a.error && "function" === typeof a.complete
    }
    var lc = function(a) {
        J.call(this);
        this.destination = a
    };
    x(lc, J);
    lc.EMPTY = J.EMPTY;
    lc.create = J.create;
    var L = function(a) {
        a && (this.fa = a)
    };
    n = L.prototype;
    n.Jb = function(a) {
        var b = new L;
        b.source = this;
        b.operator = a;
        return b
    };
    n.subscribe = function(a, b, c) {
        var d = this.operator;
        a: {
            if (a) {
                if (a instanceof J || kc(a) && gc(a)) break a;
                if (kc(a)) {
                    a = new lc(a);
                    break a
                }
            }
            a = a || b || c ? new J(a, b, c) : new J($b)
        }
        d ? a.add(d.call(a, this.source)) : a.add(this.source || Xb.ya && !a.na ? this.fa(a) : this.Nd(a));
        if (Xb.ya && a.na && (a.na = !1, a.xd)) throw a.yd;
        return a
    };
    n.Nd = function(a) {
        try {
            return this.fa(a)
        } catch (e) {
            Xb.ya && (a.xd = !0, a.yd = e);
            var b;
            a: {
                for (b = a; b;) {
                    var c = b.destination,
                        d = b.F;
                    if (b.closed || d) {
                        b = !1;
                        break a
                    }
                    b = c && c instanceof J ? c : null
                }
                b = !0
            }
            b ? a.error(e) : console.warn(e)
        }
    };
    n.forEach = function(a, b) {
        var c = this;
        b = mc(b);
        return new b(function(d, e) {
            var f = c.subscribe(function(g) {
                try {
                    a(g)
                } catch (k) {
                    e(k), f && f.unsubscribe()
                }
            }, e, d)
        })
    };
    n.fa = function(a) {
        var b = this.source;
        return b && b.subscribe(a)
    };
    L.prototype[Yb] = function() {
        return this
    };
    L.prototype.g = function() {
        var a = y.apply(0, arguments);
        return 0 === a.length ? this : jc(a)(this)
    };
    L.create = function(a) {
        return new L(a)
    };

    function mc(a) {
        a || (a = Promise);
        if (!a) throw Error("w");
        return a
    };
    var nc = function(a, b) {
        I.call(this);
        this.tg = a;
        this.Te = b;
        this.closed = !1
    };
    x(nc, I);
    nc.EMPTY = I.EMPTY;
    nc.prototype.unsubscribe = function() {
        if (!this.closed) {
            this.closed = !0;
            var a = this.tg,
                b = a.Qa;
            this.tg = null;
            !b || 0 === b.length || a.F || a.closed || (a = b.indexOf(this.Te), -1 !== a && b.splice(a, 1))
        }
    };
    var oc = function() {
        function a() {
            this.message = "object unsubscribed";
            this.name = "ObjectUnsubscribedError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    }();
    var M = function() {
        this.Qa = [];
        this.ic = this.F = this.closed = !1;
        this.zd = null
    };
    x(M, L);
    n = M.prototype;
    n.Jb = function(a) {
        var b = new pc(this, this);
        b.operator = a;
        return b
    };
    n.next = function(a) {
        if (this.closed) throw new oc;
        if (!this.F) {
            var b = this.Qa,
                c = b.length;
            b = b.slice();
            for (var d = 0; d < c; d++) b[d].next(a)
        }
    };
    n.error = function(a) {
        if (this.closed) throw new oc;
        this.ic = !0;
        this.zd = a;
        this.F = !0;
        var b = this.Qa,
            c = b.length;
        b = b.slice();
        for (var d = 0; d < c; d++) b[d].error(a);
        this.Qa.length = 0
    };
    n.complete = function() {
        if (this.closed) throw new oc;
        this.F = !0;
        var a = this.Qa,
            b = a.length;
        a = a.slice();
        for (var c = 0; c < b; c++) a[c].complete();
        this.Qa.length = 0
    };
    n.unsubscribe = function() {
        this.closed = this.F = !0;
        this.Qa = null
    };
    n.Nd = function(a) {
        if (this.closed) throw new oc;
        return L.prototype.Nd.call(this, a)
    };
    n.fa = function(a) {
        if (this.closed) throw new oc;
        if (this.ic) return a.error(this.zd), I.EMPTY;
        if (this.F) return a.complete(), I.EMPTY;
        this.Qa.push(a);
        return new nc(this, a)
    };
    n.V = function() {
        var a = new L;
        a.source = this;
        return a
    };
    M.create = function(a, b) {
        return new pc(a, b)
    };
    var pc = function(a, b) {
        M.call(this);
        this.destination = a;
        this.source = b
    };
    x(pc, M);
    pc.create = M.create;
    pc.prototype.next = function(a) {
        var b = this.destination;
        b && b.next && b.next(a)
    };
    pc.prototype.error = function(a) {
        var b = this.destination;
        b && b.error && this.destination.error(a)
    };
    pc.prototype.complete = function() {
        var a = this.destination;
        a && a.complete && this.destination.complete()
    };
    pc.prototype.fa = function(a) {
        return this.source ? this.source.subscribe(a) : I.EMPTY
    };
    var qc = function(a) {
        M.call(this);
        this.Od = a
    };
    x(qc, M);
    qc.create = M.create;
    qc.prototype.fa = function(a) {
        var b = M.prototype.fa.call(this, a);
        b && !b.closed && a.next(this.Od);
        return b
    };
    qc.prototype.getValue = function() {
        if (this.ic) throw this.zd;
        if (this.closed) throw new oc;
        return this.Od
    };
    qc.prototype.next = function(a) {
        M.prototype.next.call(this, this.Od = a)
    };
    da.Object.defineProperties(qc.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.getValue()
            }
        }
    });
    var rc = new L(function(a) {
        return a.complete()
    });

    function sc(a, b) {
        return new L(function(c) {
            var d = new I,
                e = 0;
            d.add(b.C(function() {
                e === a.length ? c.complete() : (c.next(a[e++]), c.closed || d.add(this.C()))
            }));
            return d
        })
    };
    var tc = function(a) {
        return function(b) {
            for (var c = 0, d = a.length; c < d && !b.closed; c++) b.next(a[c]);
            b.complete()
        }
    };

    function uc(a, b) {
        return b ? sc(a, b) : new L(tc(a))
    };

    function vc(a) {
        return a && "function" === typeof a.C
    };

    function N() {
        var a = y.apply(0, arguments),
            b = a[a.length - 1];
        return vc(b) ? (a.pop(), sc(a, b)) : uc(a)
    };

    function wc(a) {
        return new L(function(b) {
            return b.error(a)
        })
    };
    var xc = {
        now: function() {
            return (xc.hh || Date).now()
        },
        hh: void 0
    };
    var yc = function(a, b, c) {
        a = void 0 === a ? Infinity : a;
        b = void 0 === b ? Infinity : b;
        c = void 0 === c ? xc : c;
        M.call(this);
        this.Ui = c;
        this.Hc = [];
        this.kf = !1;
        this.ef = 1 > a ? 1 : a;
        this.Og = 1 > b ? 1 : b;
        Infinity === b ? (this.kf = !0, this.next = this.di) : this.next = this.fi
    };
    x(yc, M);
    yc.create = M.create;
    n = yc.prototype;
    n.di = function(a) {
        var b = this.Hc;
        b.push(a);
        b.length > this.ef && b.shift();
        M.prototype.next.call(this, a)
    };
    n.fi = function(a) {
        this.Hc.push({
            time: this.hf(),
            value: a
        });
        this.lf();
        M.prototype.next.call(this, a)
    };
    n.fa = function(a) {
        var b = this.kf,
            c = b ? this.Hc : this.lf(),
            d = c.length;
        if (this.closed) throw new oc;
        if (this.F || this.ic) var e = I.EMPTY;
        else this.Qa.push(a), e = new nc(this, a);
        if (b)
            for (var f = 0; f < d && !a.closed; f++) a.next(c[f]);
        else
            for (f = 0; f < d && !a.closed; f++) a.next(c[f].value);
        this.ic ? a.error(this.zd) : this.F && a.complete();
        return e
    };
    n.hf = function() {
        var a = this.Ui;
        return a ? a.now() : xc.now()
    };
    n.lf = function() {
        for (var a = this.hf(), b = this.ef, c = this.Og, d = this.Hc, e = d.length, f = 0; f < e && !(a - d[f].time < c);) f++;
        e > b && (f = Math.max(f, e - b));
        0 < f && d.splice(0, f);
        return d
    };
    var Ac = function(a, b) {
        b = void 0 === b ? zc : b;
        this.Hg = a;
        this.now = b
    };
    Ac.prototype.C = function(a, b, c) {
        b = void 0 === b ? 0 : b;
        return (new this.Hg(this, a)).C(c, b)
    };
    var zc = xc.now;
    var Bc = function() {
        function a() {
            this.message = "no elements in sequence";
            this.name = "EmptyError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    }();

    function O(a, b) {
        if (a && "function" === typeof a.Jb) return a.Jb(b);
        throw new TypeError("x");
    };

    function Cc() {
        return function(a) {
            return O(a, new Dc)
        }
    }
    var Dc = function() {};
    Dc.prototype.call = function(a, b) {
        b.Yb++;
        a = new Ec(a, b);
        var c = b.subscribe(a);
        a.closed || (a.connection = b.connect());
        return c
    };
    var Ec = function(a, b) {
        J.call(this, a);
        this.Cb = b;
        this.connection = null
    };
    x(Ec, J);
    Ec.EMPTY = J.EMPTY;
    Ec.create = J.create;
    Ec.prototype.Ia = function() {
        var a = this.Cb;
        if (a) {
            this.Cb = null;
            var b = a.Yb;
            0 >= b ? this.connection = null : (a.Yb = b - 1, 1 < b ? this.connection = null : (b = this.connection, a = a.zb, this.connection = null, !a || b && a !== b || a.unsubscribe()))
        } else this.connection = null
    };
    var Fc = function(a, b) {
        this.source = a;
        this.ug = b;
        this.Yb = 0;
        this.Ic = !1
    };
    x(Fc, L);
    Fc.create = L.create;
    Fc.prototype.fa = function(a) {
        return this.cd().subscribe(a)
    };
    Fc.prototype.cd = function() {
        var a = this.Jc;
        if (!a || a.F) this.Jc = this.ug();
        return this.Jc
    };
    Fc.prototype.connect = function() {
        var a = this.zb;
        a || (this.Ic = !1, a = this.zb = new I, a.add(this.source.subscribe(new Gc(this.cd(), this))), a.closed && (this.zb = null, a = I.EMPTY));
        return a
    };
    Fc.prototype.jg = function() {
        return Cc()(this)
    };
    var Hc, Ic = Fc.prototype;
    Hc = {
        operator: {
            value: null
        },
        Yb: {
            value: 0,
            writable: !0
        },
        Jc: {
            value: null,
            writable: !0
        },
        zb: {
            value: null,
            writable: !0
        },
        fa: {
            value: Ic.fa
        },
        Ic: {
            value: Ic.Ic,
            writable: !0
        },
        cd: {
            value: Ic.cd
        },
        connect: {
            value: Ic.connect
        },
        jg: {
            value: Ic.jg
        }
    };
    var Gc = function(a, b) {
        J.call(this);
        this.destination = a;
        this.Cb = b
    };
    x(Gc, J);
    Gc.EMPTY = J.EMPTY;
    Gc.create = J.create;
    Gc.prototype.aa = function(a) {
        this.Ia();
        J.prototype.aa.call(this, a)
    };
    Gc.prototype.D = function() {
        this.Cb.Ic = !0;
        this.Ia();
        J.prototype.D.call(this)
    };
    Gc.prototype.Ia = function() {
        var a = this.Cb;
        if (a) {
            this.Cb = null;
            var b = a.zb;
            a.Yb = 0;
            a.Jc = null;
            a.zb = null;
            b && b.unsubscribe()
        }
    };

    function P(a) {
        return function(b) {
            if ("function" !== typeof a) throw new TypeError("y");
            return O(b, new Jc(a))
        }
    }
    var Jc = function(a) {
        this.O = a;
        this.oa = void 0
    };
    Jc.prototype.call = function(a, b) {
        return b.subscribe(new Kc(a, this.O, this.oa))
    };
    var Kc = function(a, b, c) {
        J.call(this, a);
        this.O = b;
        this.count = 0;
        this.oa = c || this
    };
    x(Kc, J);
    Kc.EMPTY = J.EMPTY;
    Kc.create = J.create;
    Kc.prototype.o = function(a) {
        try {
            var b = this.O.call(this.oa, a, this.count++)
        } catch (c) {
            this.destination.error(c);
            return
        }
        this.destination.next(b)
    };
    var Lc = "function" === typeof Symbol && Symbol.iterator ? Symbol.iterator : "@@iterator";
    var Mc = function(a) {
        return a && "number" === typeof a.length && "function" !== typeof a
    };

    function Nc(a) {
        return !!a && "function" !== typeof a.subscribe && "function" === typeof a.then
    };

    function Oc(a) {
        return function(b) {
            Pc(a, b).catch(function(c) {
                return b.error(c)
            })
        }
    }

    function Pc(a, b) {
        var c, d, e, f, g, k;
        return Ba(function(h) {
            switch (h.ma) {
                case 1:
                    h.ib = 2;
                    h.Ma = 3;
                    var l = a[Symbol.asyncIterator];
                    f = void 0 !== l ? l.call(a) : new Ca(t(a));
                case 5:
                    return ta(h, f.next(), 8);
                case 8:
                    d = h.df;
                    if (d.done) {
                        h.pb(3);
                        break
                    }
                    g = d.value;
                    b.next(g);
                    h.pb(5);
                    break;
                case 3:
                    h.ke = [h.ga];
                    h.ib = 0;
                    h.Ma = 0;
                    h.ib = 0;
                    h.Ma = 9;
                    if (!d || d.done || !(e = f.return)) {
                        h.pb(9);
                        break
                    }
                    return ta(h, e.call(f), 9);
                case 9:
                    h.ke[1] = h.ga;
                    h.ib = 0;
                    h.Ma = 0;
                    if (c) throw c.error;
                    ua(h, 10, 1);
                    break;
                case 10:
                    ua(h, 4);
                    break;
                case 2:
                    h.ib = 0;
                    l = h.ga.Bf;
                    h.ga = null;
                    k = l;
                    c = {
                        error: k
                    };
                    h.pb(3);
                    break;
                case 4:
                    b.complete(), h.ma = 0
            }
        })
    };
    var Qc = function(a) {
        return function(b) {
            var c = a[Lc]();
            do {
                var d = void 0;
                try {
                    d = c.next()
                } catch (e) {
                    b.error(e);
                    return
                }
                if (d.done) {
                    b.complete();
                    break
                }
                b.next(d.value);
                if (b.closed) break
            } while (1);
            "function" === typeof c.return && b.add(function() {
                c.return && c.return()
            });
            return b
        }
    };
    var Rc = function(a) {
        return function(b) {
            var c = a[Yb]();
            if ("function" !== typeof c.subscribe) throw new TypeError("z");
            return c.subscribe(b)
        }
    };
    var Sc = function(a) {
        return function(b) {
            a.then(function(c) {
                b.closed || (b.next(c), b.complete())
            }, function(c) {
                return b.error(c)
            }).then(null, Zb);
            return b
        }
    };
    var Tc = function(a) {
        if (a && "function" === typeof a[Yb]) return Rc(a);
        if (Mc(a)) return tc(a);
        if (Nc(a)) return Sc(a);
        if (a && "function" === typeof a[Lc]) return Qc(a);
        if (Symbol && Symbol.asyncIterator && a && "function" === typeof a[Symbol.asyncIterator]) return Oc(a);
        throw new TypeError("A`" + (dc(a) ? "an invalid object" : "'" + a + "'"));
    };
    var Uc = function(a) {
        J.call(this);
        this.parent = a
    };
    x(Uc, J);
    Uc.EMPTY = J.EMPTY;
    Uc.create = J.create;
    Uc.prototype.o = function(a) {
        this.parent.ua(a)
    };
    Uc.prototype.aa = function(a) {
        this.parent.bb(a);
        this.unsubscribe()
    };
    Uc.prototype.D = function() {
        this.parent.U();
        this.unsubscribe()
    };
    var Vc = function(a, b, c) {
        J.call(this);
        this.parent = a;
        this.gg = b;
        this.pi = c
    };
    x(Vc, J);
    Vc.EMPTY = J.EMPTY;
    Vc.create = J.create;
    Vc.prototype.o = function(a) {
        this.parent.ua(this.gg, a, this.pi, this)
    };
    Vc.prototype.aa = function(a) {
        this.parent.bb(a);
        this.unsubscribe()
    };
    Vc.prototype.D = function() {
        this.parent.U(this);
        this.unsubscribe()
    };
    var Q = function() {
        J.apply(this, arguments)
    };
    x(Q, J);
    Q.EMPTY = J.EMPTY;
    Q.create = J.create;
    Q.prototype.ua = function(a) {
        this.destination.next(a)
    };
    Q.prototype.bb = function(a) {
        this.destination.error(a)
    };
    Q.prototype.U = function() {
        this.destination.complete()
    };
    var Wc = function() {
        J.apply(this, arguments)
    };
    x(Wc, J);
    Wc.EMPTY = J.EMPTY;
    Wc.create = J.create;
    Wc.prototype.ua = function(a, b) {
        this.destination.next(b)
    };
    Wc.prototype.bb = function(a) {
        this.destination.error(a)
    };
    Wc.prototype.U = function() {
        this.destination.complete()
    };

    function Xc(a, b) {
        if (!b.closed) return a instanceof L ? a.subscribe(b) : Tc(a)(b)
    };
    var Yc = {};

    function R() {
        var a = y.apply(0, arguments),
            b = void 0,
            c = void 0,
            d = void 0;
        vc(a[a.length - 1]) && (c = a.pop());
        "function" === typeof a[a.length - 1] && (b = a.pop());
        if (1 === a.length) {
            var e = a[0];
            bc(e) && (a = e);
            dc(e) && Object.getPrototypeOf(e) === Object.prototype && (d = Object.keys(e), a = d.map(function(f) {
                return e[f]
            }))
        }
        return O(uc(a, c), new Zc(b, d))
    }
    var Zc = function(a, b) {
        this.Ua = a;
        this.keys = b
    };
    Zc.prototype.call = function(a, b) {
        return b.subscribe(new $c(a, this.Ua, this.keys))
    };
    var $c = function(a, b, c) {
        Wc.call(this, a);
        this.Ua = b;
        this.keys = c;
        this.active = 0;
        this.values = [];
        this.cb = []
    };
    x($c, Wc);
    $c.EMPTY = Wc.EMPTY;
    $c.create = Wc.create;
    n = $c.prototype;
    n.o = function(a) {
        this.values.push(Yc);
        this.cb.push(a)
    };
    n.D = function() {
        var a = this.cb,
            b = a.length;
        if (0 === b) this.destination.complete();
        else {
            this.yb = this.active = b;
            for (var c = 0; c < b; c++) this.add(Xc(a[c], new Vc(this, null, c)))
        }
    };
    n.U = function() {
        0 === --this.active && this.destination.complete()
    };
    n.ua = function(a, b, c) {
        var d = this.values,
            e = d[c];
        e = this.yb ? e === Yc ? --this.yb : this.yb : 0;
        d[c] = b;
        0 === e && (this.Ua ? this.Kg(d) : this.destination.next(this.keys ? this.keys.reduce(function(f, g, k) {
            return f[g] = d[k], f
        }, {}) : d.slice()))
    };
    n.Kg = function(a) {
        try {
            var b = this.Ua.apply(this, a)
        } catch (c) {
            this.destination.error(c);
            return
        }
        this.destination.next(b)
    };

    function ad(a, b) {
        if (!a) throw Error("B");
        return new L(function(c) {
            var d = new I;
            d.add(b.C(function() {
                var e = a[Symbol.asyncIterator]();
                d.add(b.C(function() {
                    var f = this;
                    e.next().then(function(g) {
                        g.done ? c.complete() : (c.next(g.value), f.C())
                    })
                }))
            }));
            return d
        })
    };

    function bd(a, b) {
        if (!a) throw Error("B");
        return new L(function(c) {
            var d = new I,
                e;
            d.add(function() {
                e && "function" === typeof e.return && e.return()
            });
            d.add(b.C(function() {
                e = a[Lc]();
                d.add(b.C(function() {
                    if (!c.closed) {
                        try {
                            var f = e.next();
                            var g = f.value;
                            var k = f.done
                        } catch (h) {
                            c.error(h);
                            return
                        }
                        k ? c.complete() : (c.next(g), this.C())
                    }
                }))
            }));
            return d
        })
    };

    function cd(a, b) {
        return new L(function(c) {
            var d = new I;
            d.add(b.C(function() {
                var e = a[Yb]();
                d.add(e.subscribe({
                    next: function(f) {
                        d.add(b.C(function() {
                            return c.next(f)
                        }))
                    },
                    error: function(f) {
                        d.add(b.C(function() {
                            return c.error(f)
                        }))
                    },
                    complete: function() {
                        d.add(b.C(function() {
                            return c.complete()
                        }))
                    }
                }))
            }));
            return d
        })
    };

    function dd(a, b) {
        return new L(function(c) {
            var d = new I;
            d.add(b.C(function() {
                return a.then(function(e) {
                    d.add(b.C(function() {
                        c.next(e);
                        d.add(b.C(function() {
                            return c.complete()
                        }))
                    }))
                }, function(e) {
                    d.add(b.C(function() {
                        return c.error(e)
                    }))
                })
            }));
            return d
        })
    };

    function fd(a) {
        var b = gd;
        if (null != a) {
            if (a && "function" === typeof a[Yb]) return cd(a, b);
            if (Nc(a)) return dd(a, b);
            if (Mc(a)) return sc(a, b);
            if (a && "function" === typeof a[Lc] || "string" === typeof a) return bd(a, b);
            if (Symbol && Symbol.asyncIterator && "function" === typeof a[Symbol.asyncIterator]) return ad(a, b)
        }
        throw new TypeError("C`" + (null !== a && typeof a || a));
    };

    function hd(a) {
        return a instanceof L ? a : new L(Tc(a))
    };

    function id(a, b) {
        var c = void 0 === c ? Infinity : c;
        if ("function" === typeof b) return function(d) {
            return d.g(id(function(e, f) {
                return hd(a(e, f)).g(P(function(g, k) {
                    return b(e, g, f, k)
                }))
            }, c))
        };
        "number" === typeof b && (c = b);
        return function(d) {
            return O(d, new jd(a, c))
        }
    }
    var jd = function(a, b) {
        b = void 0 === b ? Infinity : b;
        this.O = a;
        this.Xd = b
    };
    jd.prototype.call = function(a, b) {
        return b.subscribe(new kd(a, this.O, this.Xd))
    };
    var kd = function(a, b, c) {
        c = void 0 === c ? Infinity : c;
        Q.call(this, a);
        this.destination = a;
        this.O = b;
        this.Xd = c;
        this.Fb = !1;
        this.buffer = [];
        this.index = this.active = 0
    };
    x(kd, Q);
    kd.EMPTY = Q.EMPTY;
    kd.create = Q.create;
    kd.prototype.o = function(a) {
        if (this.active < this.Xd) {
            var b = this.index++;
            try {
                var c = this.O(a, b)
            } catch (d) {
                this.destination.error(d);
                return
            }
            this.active++;
            a = new Uc(this);
            this.destination.add(a);
            Xc(c, a)
        } else this.buffer.push(a)
    };
    kd.prototype.D = function() {
        this.Fb = !0;
        0 === this.active && 0 === this.buffer.length && this.destination.complete();
        this.unsubscribe()
    };
    kd.prototype.ua = function(a) {
        this.destination.next(a)
    };
    kd.prototype.U = function() {
        var a = this.buffer;
        this.active--;
        0 < a.length ? this.o(a.shift()) : 0 === this.active && this.Fb && this.destination.complete()
    };

    function ld(a) {
        a = void 0 === a ? Infinity : a;
        return id(ic, a)
    };

    function md() {
        return ld(1)(N.apply(null, u(y.apply(0, arguments))))
    };

    function nd(a, b, c) {
        if (cc(c)) {
            var d = c;
            c = void 0
        }
        return d ? nd(a, b, c).g(P(function(e) {
            return bc(e) ? d.apply(null, u(e)) : d(e)
        })) : new L(function(e) {
            od(a, b, function(f) {
                1 < arguments.length ? e.next(Array.prototype.slice.call(arguments)) : e.next(f)
            }, e, c)
        })
    }

    function od(a, b, c, d, e) {
        if (a && "function" === typeof a.addEventListener && "function" === typeof a.removeEventListener) {
            a.addEventListener(b, c, e);
            var f = function() {
                return a.removeEventListener(b, c, e)
            }
        } else if (a && "function" === typeof a.ji && "function" === typeof a.ii) a.ji(b, c), f = function() {
            return a.ii(b, c)
        };
        else if (a && "function" === typeof a.addListener && "function" === typeof a.removeListener) a.addListener(b, c), f = function() {
            return a.removeListener(b, c)
        };
        else if (a && a.length)
            for (var g = 0, k = a.length; g < k; g++) od(a[g], b,
                c, d, e);
        else throw new TypeError("D");
        d.add(f)
    };
    var pd = function() {
        I.call(this)
    };
    x(pd, I);
    pd.EMPTY = I.EMPTY;
    pd.prototype.C = function() {
        return this
    };
    var qd = function(a, b) {
        return setInterval.apply(null, [a, b].concat(u(y.apply(2, arguments))))
    };
    var rd = function(a, b) {
        I.call(this);
        this.scheduler = a;
        this.Fd = b;
        this.pending = !1
    };
    x(rd, pd);
    rd.EMPTY = pd.EMPTY;
    n = rd.prototype;
    n.C = function(a, b) {
        b = void 0 === b ? 0 : b;
        if (this.closed) return this;
        this.state = a;
        a = this.id;
        var c = this.scheduler;
        null != a && (this.id = this.vc(c, a, b));
        this.pending = !0;
        this.delay = b;
        this.id = this.id || this.xc(c, this.id, b);
        return this
    };
    n.xc = function(a, b, c) {
        return qd(a.flush.bind(a, this), void 0 === c ? 0 : c)
    };
    n.vc = function(a, b, c) {
        c = void 0 === c ? 0 : c;
        if (null !== c && this.delay === c && !1 === this.pending) return b;
        clearInterval(b)
    };
    n.execute = function(a, b) {
        if (this.closed) return Error("E");
        this.pending = !1;
        if (a = this.ff(a, b)) return a;
        !1 === this.pending && null != this.id && (this.id = this.vc(this.scheduler, this.id, null))
    };
    n.ff = function(a) {
        var b = !1,
            c = void 0;
        try {
            this.Fd(a)
        } catch (d) {
            b = !0, c = !!d && d || Error(d)
        }
        if (b) return this.unsubscribe(), c
    };
    n.Ia = function() {
        var a = this.id,
            b = this.scheduler,
            c = b.actions,
            d = c.indexOf(this);
        this.state = this.Fd = null;
        this.pending = !1;
        this.scheduler = null; - 1 !== d && c.splice(d, 1);
        null != a && (this.id = this.vc(b, a, null));
        this.delay = null
    };
    var sd = function(a, b) {
        b = void 0 === b ? zc : b;
        Ac.call(this, a, b);
        this.actions = [];
        this.active = !1;
        this.ud = void 0
    };
    x(sd, Ac);
    sd.prototype.flush = function(a) {
        var b = this.actions;
        if (this.active) b.push(a);
        else {
            var c;
            this.active = !0;
            do
                if (c = a.execute(a.state, a.delay)) break; while (a = b.shift());
            this.active = !1;
            if (c) {
                for (; a = b.shift();) a.unsubscribe();
                throw c;
            }
        }
    };

    function td() {
        var a = y.apply(0, arguments),
            b = Infinity,
            c = void 0,
            d = a[a.length - 1];
        vc(d) ? (c = a.pop(), 1 < a.length && "number" === typeof a[a.length - 1] && (b = a.pop())) : "number" === typeof d && (b = a.pop());
        return !c && 1 === a.length && a[0] instanceof L ? a[0] : ld(b)(uc(a, c))
    };

    function ud() {};
    var vd = new L(ud);

    function T(a) {
        return function(b) {
            return O(b, new wd(a))
        }
    }
    var wd = function(a) {
        this.wa = a;
        this.oa = void 0
    };
    wd.prototype.call = function(a, b) {
        return b.subscribe(new xd(a, this.wa, this.oa))
    };
    var xd = function(a, b, c) {
        J.call(this, a);
        this.wa = b;
        this.oa = c;
        this.count = 0
    };
    x(xd, J);
    xd.EMPTY = J.EMPTY;
    xd.create = J.create;
    xd.prototype.o = function(a) {
        try {
            var b = this.wa.call(this.oa, a, this.count++)
        } catch (c) {
            this.destination.error(c);
            return
        }
        b && this.destination.next(a)
    };

    function yd() {
        var a = y.apply(0, arguments);
        if (1 === a.length)
            if (bc(a[0])) a = a[0];
            else return hd(a[0]);
        return O(uc(a), new zd)
    }
    var zd = function() {};
    zd.prototype.call = function(a, b) {
        return b.subscribe(new Ad(a))
    };
    var Ad = function(a) {
        Wc.call(this, a);
        this.jc = !1;
        this.cb = [];
        this.Ac = []
    };
    x(Ad, Wc);
    Ad.EMPTY = Wc.EMPTY;
    Ad.create = Wc.create;
    n = Ad.prototype;
    n.o = function(a) {
        this.cb.push(a)
    };
    n.D = function() {
        var a = this.cb,
            b = a.length;
        if (0 === b) this.destination.complete();
        else {
            for (var c = 0; c < b && !this.jc; c++) {
                var d = Xc(a[c], new Vc(this, null, c));
                this.Ac && this.Ac.push(d);
                this.add(d)
            }
            this.cb = null
        }
    };
    n.ua = function(a, b, c) {
        if (!this.jc) {
            this.jc = !0;
            for (var d = 0; d < this.Ac.length; d++)
                if (d !== c) {
                    var e = this.Ac[d];
                    e.unsubscribe();
                    this.remove(e)
                }
            this.Ac = null
        }
        this.destination.next(b)
    };
    n.U = function(a) {
        this.jc = !0;
        Wc.prototype.U.call(this, a)
    };
    n.bb = function(a) {
        this.jc = !0;
        Wc.prototype.bb.call(this, a)
    };

    function Bd() {
        var a = y.apply(0, arguments),
            b = void 0;
        "function" === typeof a[a.length - 1] && (b = a.pop());
        return O(uc(a), new Cd(b))
    }
    var Cd = function(a) {
        this.Ua = a
    };
    Cd.prototype.call = function(a, b) {
        return b.subscribe(new Dd(a, this.Ua))
    };
    var Dd = function(a, b, c) {
        void 0 === c && Object.create(null);
        J.call(this, a);
        this.De = [];
        this.active = 0;
        this.Ua = b
    };
    x(Dd, J);
    Dd.EMPTY = J.EMPTY;
    Dd.create = J.create;
    Dd.prototype.o = function(a) {
        var b = this.De;
        bc(a) ? b.push(new Ed(a)) : "function" === typeof a[Lc] ? b.push(new Fd(a[Lc]())) : b.push(new Gd(this.destination, this, a))
    };
    Dd.prototype.D = function() {
        var a = this.De,
            b = a.length;
        this.unsubscribe();
        if (0 === b) this.destination.complete();
        else {
            this.active = b;
            for (var c = 0; c < b; c++) {
                var d = a[c];
                d.Oi ? this.destination.add(d.subscribe()) : this.active--
            }
        }
    };
    Dd.prototype.Lg = function(a) {
        try {
            var b = this.Ua.apply(this, a)
        } catch (c) {
            this.destination.error(c);
            return
        }
        this.destination.next(b)
    };
    var Fd = function(a) {
        this.iterator = a;
        this.Ie = a.next()
    };
    Fd.prototype.lb = function() {
        return !0
    };
    Fd.prototype.next = function() {
        var a = this.Ie;
        this.Ie = this.iterator.next();
        return a
    };
    Fd.prototype.Fb = function() {
        var a = this.Ie;
        return a && !!a.done
    };
    var Ed = function(a) {
        this.Rd = a;
        this.length = this.index = 0;
        this.length = a.length
    };
    Ed.prototype[Lc] = function() {
        return this
    };
    Ed.prototype.next = function() {
        var a = this.index++,
            b = this.Rd;
        return a < this.length ? {
            value: b[a],
            done: !1
        } : {
            value: null,
            done: !0
        }
    };
    Ed.prototype.lb = function() {
        return this.Rd.length > this.index
    };
    Ed.prototype.Fb = function() {
        return this.Rd.length === this.index
    };
    var Gd = function(a, b, c) {
        Q.call(this, a);
        this.parent = b;
        this.observable = c;
        this.Oi = !0;
        this.buffer = [];
        this.mb = !1
    };
    x(Gd, Q);
    Gd.EMPTY = Q.EMPTY;
    Gd.create = Q.create;
    Gd.prototype[Lc] = function() {
        return this
    };
    n = Gd.prototype;
    n.next = function() {
        var a = this.buffer;
        return 0 === a.length && this.mb ? {
            value: null,
            done: !0
        } : {
            value: a.shift(),
            done: !1
        }
    };
    n.lb = function() {
        return 0 < this.buffer.length
    };
    n.Fb = function() {
        return 0 === this.buffer.length && this.mb
    };
    n.U = function() {
        if (0 < this.buffer.length) {
            this.mb = !0;
            var a = this.parent;
            a.active--;
            0 === a.active && a.destination.complete()
        } else this.destination.complete()
    };
    n.ua = function(a) {
        this.buffer.push(a);
        a: {
            a = this.parent;
            for (var b = a.De, c = b.length, d = a.destination, e = 0; e < c; e++) {
                var f = b[e];
                if ("function" === typeof f.lb && !f.lb()) break a
            }
            e = !1;f = [];
            for (var g = 0; g < c; g++) {
                var k = b[g],
                    h = k.next();
                k.Fb() && (e = !0);
                if (h.done) {
                    d.complete();
                    break a
                }
                f.push(h.value)
            }
            a.Ua ? a.Lg(f) : d.next(f);e && d.complete()
        }
    };
    n.subscribe = function() {
        return Xc(this.observable, new Uc(this))
    };
    (function() {
        function a(b) {
            this.message = "Timeout has occurred";
            this.name = "TimeoutError";
            this.info = void 0 === b ? null : b;
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    })();
    var Hd = 1,
        Id, Jd = {};

    function Kd(a) {
        return a in Jd ? (delete Jd[a], !0) : !1
    }
    var Ld = function(a) {
        var b = Hd++;
        Jd[b] = !0;
        Id || (Id = Promise.resolve());
        Id.then(function() {
            return Kd(b) && a()
        });
        return b
    };
    var Md = function() {
        return Ld.apply(null, u(y.apply(0, arguments)))
    };
    var Nd = function(a, b) {
        rd.call(this, a, b);
        this.scheduler = a;
        this.Fd = b
    };
    x(Nd, rd);
    Nd.EMPTY = rd.EMPTY;
    Nd.prototype.xc = function(a, b, c) {
        c = void 0 === c ? 0 : c;
        if (null !== c && 0 < c) return rd.prototype.xc.call(this, a, b, c);
        a.actions.push(this);
        return a.ud || (a.ud = Md(a.flush.bind(a, void 0)))
    };
    Nd.prototype.vc = function(a, b, c) {
        c = void 0 === c ? 0 : c;
        if (null !== c && 0 < c || null === c && 0 < this.delay) return rd.prototype.vc.call(this, a, b, c);
        0 === a.actions.length && (Kd(b), a.ud = void 0)
    };
    var Od = function() {
        sd.apply(this, arguments)
    };
    x(Od, sd);
    Od.prototype.flush = function(a) {
        this.active = !0;
        this.ud = void 0;
        var b = this.actions,
            c, d = -1;
        a = a || b.shift();
        var e = b.length;
        do
            if (c = a.execute(a.state, a.delay)) break; while (++d < e && (a = b.shift()));
        this.active = !1;
        if (c) {
            for (; ++d < e && (a = b.shift());) a.unsubscribe();
            throw c;
        }
    };
    var Pd = new Od(Nd);
    var Qd = function(a, b) {
        rd.call(this, a, b);
        this.scheduler = a;
        this.Fd = b
    };
    x(Qd, rd);
    Qd.EMPTY = rd.EMPTY;
    Qd.prototype.C = function(a, b) {
        b = void 0 === b ? 0 : b;
        if (0 < b) return rd.prototype.C.call(this, a, b);
        this.delay = b;
        this.state = a;
        this.scheduler.flush(this);
        return this
    };
    Qd.prototype.execute = function(a, b) {
        return 0 < b || this.closed ? rd.prototype.execute.call(this, a, b) : this.ff(a, b)
    };
    Qd.prototype.xc = function(a, b, c) {
        c = void 0 === c ? 0 : c;
        return null !== c && 0 < c || null === c && 0 < this.delay ? rd.prototype.xc.call(this, a, b, c) : a.flush(this)
    };
    var Rd = function() {
        sd.apply(this, arguments)
    };
    x(Rd, sd);
    var gd = new Rd(Qd);
    var Sd = function() {
        function a() {
            this.message = "argument out of range";
            this.name = "ArgumentOutOfRangeError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    }();
    (function() {
        function a(b) {
            this.message = b;
            this.name = "NotFoundError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    })();
    (function() {
        function a(b) {
            this.message = b;
            this.name = "SequenceError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    })();
    var Td = function() {
        this.B = new Qa;
        this.h = new Sa;
        this.Jh = Symbol();
        this.dc = new Vb
    };
    Td.prototype.pe = function() {
        return vd
    };
    var Ud = function(a, b) {
        null !== a.Ka && a.Ka.next(b)
    };
    da.Object.defineProperties(Td.prototype, {
        xb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Jh
            }
        }
    });
    var Vd = function(a, b) {
        b = Error.call(this, b ? a + ": " + b : String(a));
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.code = a;
        this.__proto__ = Vd.prototype;
        this.name = String(a)
    };
    x(Vd, Error);
    var Wd = function(a) {
        Vd.call(this, 1E3, 'sfr:"' + a + '"');
        this.Xh = a;
        this.__proto__ = Wd.prototype
    };
    x(Wd, Vd);
    var Xd = function() {
        Vd.call(this, 1003);
        this.__proto__ = Xd.prototype
    };
    x(Xd, Vd);
    var Yd = function() {
        Vd.call(this, 1009);
        this.__proto__ = Yd.prototype
    };
    x(Yd, Vd);
    var Zd = function() {
        Vd.call(this, 1011);
        this.__proto__ = Zd.prototype
    };
    x(Zd, Vd);
    var $d = function() {
        Vd.call(this, 1007);
        this.__proto__ = Xd.prototype
    };
    x($d, Vd);
    var ae = function() {
        Vd.call(this, 1008);
        this.__proto__ = Xd.prototype
    };
    x(ae, Vd);
    var be = function() {
        Vd.call(this, 1001);
        this.__proto__ = be.prototype
    };
    x(be, Vd);
    var ce = function(a) {
        Vd.call(this, 1004, String(a));
        this.Gh = a;
        this.__proto__ = ce.prototype
    };
    x(ce, Vd);
    var ee = function(a) {
        Vd.call(this, 1010, a);
        this.__proto__ = de.prototype
    };
    x(ee, Vd);
    var de = function(a) {
        Vd.call(this, 1005, a);
        this.__proto__ = de.prototype
    };
    x(de, Vd);
    var fe = function(a) {
        var b = y.apply(1, arguments),
            c = this;
        this.Pb = [];
        this.Pb.push(a);
        b.forEach(function(d) {
            c.Pb.push(d)
        })
    };
    fe.prototype.L = function(a) {
        return this.Pb.some(function(b) {
            return b.L(a)
        })
    };
    fe.prototype.N = function(a, b) {
        for (var c = 0; c < this.Pb.length; c++)
            if (this.Pb[c].L(b)) return this.Pb[c].N(a, b);
        throw new Yd;
    };

    function ge(a) {
        var b, c, d;
        return !!a && "boolean" === typeof a.active && "function" === typeof(null == (b = a.clock) ? void 0 : b.now) && void 0 !== (null == (c = a.clock) ? void 0 : c.timeline) && !(null == (d = a.A) || !d.timestamp) && "function" === typeof a.ja && "function" === typeof a.ka && "function" === typeof a.qa && "function" === typeof a.map && "function" === typeof a.ta
    };
    var he = Symbol("time-origin"),
        je = Symbol("date"),
        ke = function(a, b) {
            this.value = a;
            this.timeline = b
        },
        le = function(a, b) {
            if (b.timeline !== a.timeline) throw new $d;
        },
        me = function(a, b) {
            le(a, b);
            return a.value - b.value
        };
    n = ke.prototype;
    n.equals = function(a) {
        return 0 === me(this, a)
    };
    n.maximum = function(a) {
        le(this, a);
        return this.value >= a.value ? this : a
    };
    n.round = function() {
        return new ke(Math.round(this.value), this.timeline)
    };
    n.add = function(a) {
        return new ke(this.value + a, this.timeline)
    };
    n.toString = function() {
        return String(this.value)
    };

    function ne(a) {
        function b(c) {
            return "boolean" === typeof c || "string" === typeof c || "number" === typeof c || void 0 === c || null === c
        }
        return b(a) ? !0 : Array.isArray(a) ? a.every(b) : "object" === typeof a ? Object.keys(a).every(function(c) {
            return "string" === typeof c
        }) && Object.values(a).every(function(c) {
            return Array.isArray(c) ? c.every(b) : b(c)
        }) : !1
    }

    function oe(a) {
        if (ne(a)) return a;
        if (ge(a)) return {
            A: {
                value: oe(a.A.value),
                timestamp: me(a.A.timestamp, new ke(0, a.A.timestamp.timeline))
            },
            active: a.active
        };
        try {
            return JSON.parse(JSON.stringify(a))
        } catch (b) {}
        return String(a)
    };
    var pe = ["sessionStart", "sessionError", "sessionFinish"],
        qe = function(a, b) {
            this.K = a;
            this.Gc = b;
            this.ready = !1;
            this.sb = [];
            this.og = function() {};
            this.Bg = function() {};
            this.Gf = function() {};
            this.Pf = function() {};
            this.sd = function() {}
        },
        re = function(a, b) {
            a.og = b
        },
        se = function(a, b) {
            a.Bg = b
        },
        te = function(a, b) {
            a.Gf = b
        },
        ue = function(a, b) {
            a.Pf = b
        },
        ve = function(a, b) {
            a.sd = b;
            a.sd(a.sb.length)
        };
    qe.prototype.uf = function() {
        for (var a = this, b = t("geometryChange impression loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(" ")), c = b.next(); !c.done; c = b.next()) this.K.addEventListener(c.value, function(d) {
            we(a, d)
        });
        xe(this.K, function(d) {
            "sessionStart" !== d.type && we(a, d)
        }, this.Gc);
        xe(this.K, function(d) {
            "sessionStart" === d.type && (we(a, d), ye(a), ze(a))
        }, this.Gc)
    };
    var we = function(a, b) {
            a.sb.push(b);
            a.sd(a.sb.length);
            ze(a)
        },
        ze = function(a) {
            if (a.ready)
                for (; 0 < a.sb.length;) {
                    var b = a.sb.pop();
                    void 0 !== b && ("geometryChange" === b.type ? a.Gf(b) : "impression" === b.type ? a.Pf(b) : pe.includes(b.type) ? a.og(b) : a.Bg(b));
                    a.sd(a.sb.length)
                }
        },
        ye = function(a) {
            a.ready || (a.ready = !0, a.sb.sort(function(b, c) {
                return c.timestamp - b.timestamp
            }))
        };

    function Ae(a) {
        return function(b) {
            return O(b, function(c) {
                var d = this,
                    e = new I,
                    f = null,
                    g = !1,
                    k;
                f = c.subscribe({
                    next: function(h) {
                        return d.next(h)
                    },
                    error: function(h) {
                        try {
                            k = hd(a(h, Ae(a)(c)))
                        } catch (l) {
                            d.error(l)
                        }
                        k && (f ? (f.unsubscribe(), f = null, e.add(k.subscribe(d))) : g = !0)
                    },
                    complete: function() {
                        return d.complete()
                    }
                });
                g ? (f.unsubscribe(), f = null, e.add(k.subscribe(d))) : e.add(f);
                return e
            })
        }
    };

    function Be() {
        var a = y.apply(0, arguments),
            b = void 0;
        "function" === typeof a[a.length - 1] && (b = a.pop());
        1 === a.length && bc(a[0]) && (a = a[0].slice());
        return function(c) {
            var d = hd([c].concat(u(a))),
                e = new Zc(b);
            if (c && "function" === typeof c.Jb) c = c.Jb.call(d, e);
            else throw new TypeError("x");
            return c
        }
    }

    function Ce() {
        return Be.apply(null, u(y.apply(0, arguments)))
    };

    function De(a) {
        a = void 0 === a ? null : a;
        return function(b) {
            return O(b, new Ee(a))
        }
    }
    var Ee = function(a) {
        this.defaultValue = a
    };
    Ee.prototype.call = function(a, b) {
        return b.subscribe(new Fe(a, this.defaultValue))
    };
    var Fe = function(a, b) {
        J.call(this, a);
        this.defaultValue = b;
        this.ld = !0
    };
    x(Fe, J);
    Fe.EMPTY = J.EMPTY;
    Fe.create = J.create;
    Fe.prototype.o = function(a) {
        this.ld = !1;
        this.destination.next(a)
    };
    Fe.prototype.D = function() {
        this.ld && this.destination.next(this.defaultValue);
        this.destination.complete()
    };

    function Ge(a) {
        return function(b) {
            return O(b, new He(a))
        }
    }
    var He = function(a) {
        this.ee = a
    };
    He.prototype.call = function(a, b) {
        return b.subscribe(new Ie(a, this.ee))
    };
    var Ie = function(a, b) {
        Wc.call(this, a);
        this.ee = b;
        this.ia = !1;
        this.Wc = [];
        this.index = 0
    };
    x(Ie, Wc);
    Ie.EMPTY = Wc.EMPTY;
    Ie.create = Wc.create;
    n = Ie.prototype;
    n.ua = function(a, b, c, d) {
        this.destination.next(a);
        Je(this, d);
        Ke(this)
    };
    n.bb = function(a) {
        this.aa(a)
    };
    n.U = function(a) {
        (a = Je(this, a)) && this.destination.next(a);
        Ke(this)
    };
    n.o = function(a) {
        var b = this.index++;
        try {
            var c = this.ee(a, b);
            if (c) {
                var d = Xc(c, new Vc(this, a, 0));
                d && !d.closed && (this.destination.add(d), this.Wc.push(d))
            }
        } catch (e) {
            this.destination.error(e)
        }
    };
    n.D = function() {
        this.ia = !0;
        Ke(this);
        this.unsubscribe()
    };
    var Je = function(a, b) {
            b.unsubscribe();
            var c = a.Wc.indexOf(b); - 1 !== c && a.Wc.splice(c, 1);
            return b.gg
        },
        Ke = function(a) {
            a.ia && 0 === a.Wc.length && a.destination.complete()
        };

    function Le(a) {
        return function(b) {
            return O(b, new Me(a))
        }
    }
    var Me = function(a) {
        this.ab = a;
        this.wh = void 0
    };
    Me.prototype.call = function(a, b) {
        return b.subscribe(new Ne(a, this.ab, this.wh))
    };
    var Ne = function(a, b, c) {
        Q.call(this, a);
        this.ab = b;
        this.values = new Set;
        c && this.add(Xc(c, new Uc(this)))
    };
    x(Ne, Q);
    Ne.EMPTY = Q.EMPTY;
    Ne.create = Q.create;
    n = Ne.prototype;
    n.ua = function() {
        this.values.clear()
    };
    n.bb = function(a) {
        this.aa(a)
    };
    n.o = function(a) {
        this.ab ? this.Mg(a) : this.gf(a, a)
    };
    n.Mg = function(a) {
        var b = this.destination;
        try {
            var c = this.ab(a)
        } catch (d) {
            b.error(d);
            return
        }
        this.gf(c, a)
    };
    n.gf = function(a, b) {
        var c = this.values;
        c.has(a) || (c.add(a), this.destination.next(b))
    };

    function V(a) {
        return function(b) {
            return O(b, new Oe(a))
        }
    }
    var Oe = function(a) {
        this.compare = a;
        this.ab = void 0
    };
    Oe.prototype.call = function(a, b) {
        return b.subscribe(new Pe(a, this.compare, this.ab))
    };
    var Pe = function(a, b, c) {
        J.call(this, a);
        this.ab = c;
        this.Nf = !1;
        "function" === typeof b && (this.compare = b)
    };
    x(Pe, J);
    Pe.EMPTY = J.EMPTY;
    Pe.create = J.create;
    Pe.prototype.compare = function(a, b) {
        return a === b
    };
    Pe.prototype.o = function(a) {
        try {
            var b = this.ab;
            var c = b ? b(a) : a
        } catch (e) {
            return this.destination.error(e)
        }
        b = !1;
        if (this.Nf) try {
            var d = this.compare;
            b = d(this.key, c)
        } catch (e) {
            return this.destination.error(e)
        } else this.Nf = !0;
        b || (this.key = c, this.destination.next(a))
    };

    function Qe(a) {
        if (isNaN(a)) throw new TypeError("F");
        if (0 > a) throw new Sd;
        return function(b) {
            return 0 === a ? rc : O(b, new Re(a))
        }
    }
    var Re = function(a) {
        this.count = a
    };
    Re.prototype.call = function(a, b) {
        return b.subscribe(new Se(a, this.count))
    };
    var Se = function(a, b) {
        J.call(this, a);
        this.count = b;
        this.Ng = 0
    };
    x(Se, J);
    Se.EMPTY = J.EMPTY;
    Se.create = J.create;
    Se.prototype.o = function(a) {
        var b = this.count,
            c = ++this.Ng;
        c <= b && (this.destination.next(a), c === b && (this.destination.complete(), this.unsubscribe()))
    };

    function Te(a) {
        a = void 0 === a ? Ue : a;
        return function(b) {
            return O(b, new Ve(a))
        }
    }
    var Ve = function(a) {
        this.he = a
    };
    Ve.prototype.call = function(a, b) {
        return b.subscribe(new We(a, this.he))
    };
    var We = function(a, b) {
        J.call(this, a);
        this.he = b;
        this.lb = !1
    };
    x(We, J);
    We.EMPTY = J.EMPTY;
    We.create = J.create;
    We.prototype.o = function(a) {
        this.lb = !0;
        this.destination.next(a)
    };
    We.prototype.D = function() {
        if (this.lb) return this.destination.complete();
        try {
            var a = this.he()
        } catch (b) {
            a = b
        }
        this.destination.error(a)
    };

    function Ue() {
        return new Bc
    };

    function Xe() {
        var a = y.apply(0, arguments);
        return function(b) {
            return md(b, N.apply(null, u(a)))
        }
    };

    function Ye(a) {
        return function(b) {
            return O(b, new Ze(a, b))
        }
    }
    var Ze = function(a, b) {
        this.wa = a;
        this.oa = void 0;
        this.source = b
    };
    Ze.prototype.call = function(a, b) {
        return b.subscribe(new $e(a, this.wa, this.oa, this.source))
    };
    var $e = function(a, b, c, d) {
        J.call(this, a);
        this.wa = b;
        this.oa = c;
        this.source = d;
        this.index = 0;
        this.oa = c || this
    };
    x($e, J);
    $e.EMPTY = J.EMPTY;
    $e.create = J.create;
    $e.prototype.U = function(a) {
        this.destination.next(a);
        this.destination.complete()
    };
    $e.prototype.o = function(a) {
        var b = !1;
        try {
            b = this.wa.call(this.oa, a, this.index++, this.source)
        } catch (c) {
            this.destination.error(c);
            return
        }
        b || this.U(!1)
    };
    $e.prototype.D = function() {
        this.U(!0)
    };

    function af() {
        return function(a) {
            return O(a, new bf)
        }
    }
    var bf = function() {};
    bf.prototype.call = function(a, b) {
        return b.subscribe(new cf(a))
    };
    var cf = function() {
        J.apply(this, arguments)
    };
    x(cf, J);
    cf.EMPTY = J.EMPTY;
    cf.create = J.create;
    cf.prototype.o = function() {};

    function df() {
        if (isNaN(1)) throw new TypeError("F");
        return function(a) {
            return O(a, new ef)
        }
    }
    var ef = function() {
        this.total = 1
    };
    ef.prototype.call = function(a, b) {
        return b.subscribe(new ff(a, this.total))
    };
    var ff = function(a, b) {
        J.call(this, a);
        this.total = b;
        this.lg = [];
        this.count = 0
    };
    x(ff, J);
    ff.EMPTY = J.EMPTY;
    ff.create = J.create;
    ff.prototype.o = function(a) {
        var b = this.lg,
            c = this.total,
            d = this.count++;
        b.length < c ? b.push(a) : b[d % c] = a
    };
    ff.prototype.D = function() {
        var a = this.destination,
            b = this.count;
        if (0 < b)
            for (var c = this.count >= this.total ? this.total : this.count, d = this.lg, e = 0; e < c; e++) {
                var f = b++ % c;
                a.next(d[f])
            }
        a.complete()
    };

    function gf(a, b) {
        var c = 2 <= arguments.length;
        return function(d) {
            return d.g(a ? T(function(e, f) {
                return a(e, f, d)
            }) : ic, df(), c ? De(b) : Te(function() {
                return new Bc
            }))
        }
    };

    function hf(a) {
        return function(b) {
            return O(b, new jf(a))
        }
    }
    var jf = function(a) {
        this.value = a
    };
    jf.prototype.call = function(a, b) {
        return b.subscribe(new kf(a, this.value))
    };
    var kf = function(a, b) {
        J.call(this, a);
        this.value = b
    };
    x(kf, J);
    kf.EMPTY = J.EMPTY;
    kf.create = J.create;
    kf.prototype.o = function() {
        this.destination.next(this.value)
    };

    function lf(a, b) {
        var c = !1;
        2 <= arguments.length && (c = !0);
        return function(d) {
            return O(d, new mf(a, b, c))
        }
    }
    var mf = function(a, b, c) {
        this.Pd = a;
        this.seed = b;
        this.Dh = void 0 === c ? !1 : c
    };
    mf.prototype.call = function(a, b) {
        return b.subscribe(new nf(a, this.Pd, this.seed, this.Dh))
    };
    var nf = function(a, b, c, d) {
        J.call(this, a);
        this.Pd = b;
        this.Jd = c;
        this.jf = d;
        this.index = 0
    };
    x(nf, J);
    nf.EMPTY = J.EMPTY;
    nf.create = J.create;
    nf.prototype.o = function(a) {
        var b = this.destination;
        if (this.jf) {
            var c = this.index++;
            try {
                var d = this.Pd(this.Jd, a, c)
            } catch (e) {
                b.error(e);
                return
            }
            this.Jd = d;
            b.next(d)
        } else this.Jd = a, this.jf = !0, b.next(a)
    };

    function of (a) {
        return function(b) {
            var c = "function" === typeof a ? a : function() {
                return a
            };
            var d = Object.create(b, Hc);
            d.source = b;
            d.ug = c;
            return d
        }
    };

    function pf() {
        var a = y.apply(0, arguments);
        1 === a.length && bc(a[0]) && (a = a[0]);
        return function(b) {
            return O(b, new qf(a))
        }
    }
    var qf = function(a) {
        this.Je = a
    };
    qf.prototype.call = function(a, b) {
        return b.subscribe(new rf(a, this.Je))
    };
    var rf = function(a, b) {
        Q.call(this, a);
        this.destination = a;
        this.Je = b
    };
    x(rf, Q);
    rf.EMPTY = Q.EMPTY;
    rf.create = Q.create;
    rf.prototype.bb = function() {
        sf(this)
    };
    rf.prototype.U = function() {
        sf(this)
    };
    rf.prototype.aa = function() {
        sf(this);
        this.unsubscribe()
    };
    rf.prototype.D = function() {
        sf(this);
        this.unsubscribe()
    };
    var sf = function(a) {
        var b = a.Je.shift();
        if (b) {
            var c = new Uc(a);
            a.destination.add(c);
            Xc(b, c)
        } else a.destination.complete()
    };

    function tf(a) {
        var b = new yc(a, void 0, void 0);
        return function(c) {
            return of(function() {
                return b
            })(c)
        }
    };

    function uf() {
        var a = void 0 === a ? Infinity : a;
        return function(b) {
            return 0 >= a ? rc : O(b, function(c) {
                var d = this,
                    e = 0,
                    f = new I,
                    g, k = function() {
                        var h = !1;
                        g = c.subscribe({
                            next: function(l) {
                                return d.next(l)
                            },
                            error: function(l) {
                                return d.error(l)
                            },
                            complete: function() {
                                ++e < a ? g ? (g.unsubscribe(), g = null, k()) : h = !0 : d.complete()
                            }
                        });
                        h ? (g.unsubscribe(), g = null, k()) : f.add(g)
                    };
                k();
                return f
            })
        }
    };

    function vf() {
        return new M
    }

    function wf() {
        return function(a) {
            return Cc()( of (vf)(a))
        }
    };

    function W() {
        var a = y.apply(0, arguments),
            b = a[a.length - 1];
        return vc(b) ? (a.pop(), function(c) {
            return md(a, c, b)
        }) : function(c) {
            return md(a, c)
        }
    };
    var xf = function(a, b, c) {
        b = void 0 === b ? 0 : b;
        c = void 0 === c ? Pd : c;
        this.source = a;
        this.delayTime = b;
        this.scheduler = c;
        0 > b && (this.delayTime = 0);
        vc(c) || (this.scheduler = Pd)
    };
    x(xf, L);
    xf.create = L.create;
    xf.ih = function(a) {
        return this.add(a.source.subscribe(a.Te))
    };
    xf.prototype.fa = function(a) {
        return this.scheduler.C(xf.ih, this.delayTime, {
            source: this.source,
            Te: a
        })
    };

    function yf() {
        var a = void 0 === a ? 0 : a;
        return function(b) {
            return O(b, new zf(a))
        }
    }
    var zf = function(a) {
        this.scheduler = gd;
        this.delay = a
    };
    zf.prototype.call = function(a, b) {
        return (new xf(b, this.delay, this.scheduler)).subscribe(a)
    };

    function X(a) {
        return function(b) {
            return O(b, new Af(a))
        }
    }
    var Af = function(a) {
        this.O = a
    };
    Af.prototype.call = function(a, b) {
        return b.subscribe(new Bf(a, this.O))
    };
    var Bf = function(a, b) {
        Q.call(this, a);
        this.destination = a;
        this.O = b;
        this.index = 0
    };
    x(Bf, Q);
    Bf.EMPTY = Q.EMPTY;
    Bf.create = Q.create;
    n = Bf.prototype;
    n.o = function(a) {
        var b = this.index++;
        try {
            var c = this.O(a, b)
        } catch (d) {
            this.destination.error(d);
            return
        }(a = this.hd) && a.unsubscribe();
        a = new Uc(this);
        this.destination.add(a);
        this.hd = a;
        Xc(c, a)
    };
    n.D = function() {
        var a = this.hd;
        a && !a.closed || Q.prototype.D.call(this);
        this.unsubscribe()
    };
    n.Ia = function() {
        this.hd = void 0
    };
    n.U = function() {
        this.hd = void 0;
        this.F && Q.prototype.D.call(this)
    };
    n.ua = function(a) {
        this.destination.next(a)
    };

    function Cf(a, b) {
        b = void 0 === b ? !1 : b;
        return function(c) {
            return O(c, new Df(a, b))
        }
    }
    var Df = function(a, b) {
        this.wa = a;
        this.ve = b
    };
    Df.prototype.call = function(a, b) {
        return b.subscribe(new Ef(a, this.wa, this.ve))
    };
    var Ef = function(a, b, c) {
        J.call(this, a);
        this.wa = b;
        this.ve = c;
        this.index = 0
    };
    x(Ef, J);
    Ef.EMPTY = J.EMPTY;
    Ef.create = J.create;
    Ef.prototype.o = function(a) {
        var b = this.destination;
        try {
            var c = this.wa(a, this.index++)
        } catch (d) {
            b.error(d);
            return
        }
        b = this.destination;
        c ? b.next(a) : (this.ve && b.next(a), b.complete())
    };

    function Ff(a, b, c) {
        return function(d) {
            return O(d, new Gf(a, b, c))
        }
    }
    var Gf = function(a, b, c) {
        this.ei = a;
        this.error = b;
        this.complete = c
    };
    Gf.prototype.call = function(a, b) {
        return b.subscribe(new Hf(a, this.ei, this.error, this.complete))
    };
    var Hf = function(a, b, c, d) {
        J.call(this, a);
        this.Kd = this.Ld = this.Md = ud;
        this.Ld = c || ud;
        this.Kd = d || ud;
        cc(b) ? (this.Ha = this, this.Md = b) : b && (this.Ha = b, this.Md = b.next || ud, this.Ld = b.error || ud, this.Kd = b.complete || ud)
    };
    x(Hf, J);
    Hf.EMPTY = J.EMPTY;
    Hf.create = J.create;
    Hf.prototype.o = function(a) {
        try {
            this.Md.call(this.Ha, a)
        } catch (b) {
            this.destination.error(b);
            return
        }
        this.destination.next(a)
    };
    Hf.prototype.aa = function(a) {
        try {
            this.Ld.call(this.Ha, a)
        } catch (b) {
            this.destination.error(b);
            return
        }
        this.destination.error(a)
    };
    Hf.prototype.D = function() {
        try {
            this.Kd.call(this.Ha)
        } catch (a) {
            this.destination.error(a);
            return
        }
        return this.destination.complete()
    };

    function If() {
        var a = y.apply(0, arguments);
        return function(b) {
            var c;
            "function" === typeof a[a.length - 1] && (c = a.pop());
            return O(b, new Jf(a, c))
        }
    }
    var Jf = function(a, b) {
        this.cb = a;
        this.O = b
    };
    Jf.prototype.call = function(a, b) {
        return b.subscribe(new Kf(a, this.cb, this.O))
    };
    var Kf = function(a, b, c) {
        Wc.call(this, a);
        this.O = c;
        this.yb = [];
        a = b.length;
        this.values = Array(a);
        for (c = 0; c < a; c++) this.yb.push(c);
        for (c = 0; c < a; c++) this.add(Xc(b[c], new Vc(this, void 0, c)))
    };
    x(Kf, Wc);
    Kf.EMPTY = Wc.EMPTY;
    Kf.create = Wc.create;
    Kf.prototype.ua = function(a, b, c) {
        this.values[c] = b;
        b = this.yb;
        0 < b.length && (c = b.indexOf(c), -1 !== c && b.splice(c, 1))
    };
    Kf.prototype.U = function() {};
    Kf.prototype.o = function(a) {
        0 === this.yb.length && (a = [a].concat(u(this.values)), this.O ? this.Jg(a) : this.destination.next(a))
    };
    Kf.prototype.Jg = function(a) {
        try {
            var b = this.O.apply(this, a)
        } catch (c) {
            this.destination.error(c);
            return
        }
        this.destination.next(b)
    };
    var Lf = function(a) {
        this.K = a
    };
    Lf.prototype.L = function(a) {
        return (null == a ? 0 : a.Nc) ? !0 : "POST" === (null == a ? void 0 : a.Bb) || (null == a ? 0 : a.Db) || (null == a ? 0 : a.de) ? !1 : this.K.L()
    };
    Lf.prototype.ping = function() {
        var a = this,
            b = N.apply(null, u(y.apply(0, arguments))).g(id(function(c) {
                return Of(a, c)
            }), Ye(function(c) {
                return c
            }), tf(1));
        b.connect();
        return b
    };
    var Of = function(a, b) {
        var c = new yc(1);
        Pf(a.K, b, function() {
            c.next(!0);
            c.complete()
        }, function() {
            c.next(!1);
            c.complete()
        });
        return c
    };
    Lf.prototype.rd = function(a, b, c) {
        this.ping.apply(this, u(y.apply(3, arguments)))
    };

    function Qf(a, b) {
        var c = !1;
        return new L(function(d) {
            var e = a.setTimeout(function() {
                c = !0;
                d.next(!0);
                d.complete()
            }, b);
            return function() {
                c || a.clearTimeout(e)
            }
        })
    };
    var Rf = function(a) {
        this.K = a;
        this.timeline = je
    };
    n = Rf.prototype;
    n.setTimeout = function(a, b) {
        return Number(this.K.setTimeout(function() {
            return a()
        }, b))
    };
    n.clearTimeout = function(a) {
        this.K.clearTimeout(a)
    };
    n.now = function() {
        return new ke(Date.now(), this.timeline)
    };
    n.interval = function(a, b) {
        var c = this.Oa(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Oa = function(a) {
        return Qf(this, a).g(uf(), lf(function(b) {
            return b + 1
        }, -1))
    };
    n.ha = function() {
        return !0
    };
    var Sf = function(a, b) {
        this.context = a;
        this.Qb = b
    };
    Sf.prototype.L = function(a) {
        return this.Qb.L(a)
    };
    Sf.prototype.N = function(a, b) {
        if (!this.L(b)) throw new Yd;
        return new Tf(this.context, this.Qb, null != b ? b : void 0, a)
    };
    var Tf = function(a, b, c, d) {
        var e = this;
        this.Qb = b;
        this.properties = c;
        this.url = d;
        this.kd = !0;
        this.Db = new Map;
        this.body = void 0;
        var f;
        this.method = null != (f = null == c ? void 0 : c.Bb) ? f : "GET";
        this.Ug = a.pe().subscribe(function() {
            e.sendNow()
        })
    };
    Tf.prototype.deactivate = function() {
        this.kd = !1
    };
    Tf.prototype.sendNow = function() {
        if (this.kd)
            if (this.Ug.unsubscribe(), this.Qb.L(this.properties)) try {
                if (0 < this.Db.size || void 0 !== this.body) {
                    var a, b;
                    this.Qb.rd(null != (a = this.properties) ? a : {}, this.Db, null != (b = this.body) ? b : "", this.url)
                } else this.Qb.ping(this.url);
                this.kd = !1
            } catch (c) {} else this.kd = !1
    };
    var Vf = function(a, b, c, d, e, f) {
            this.mode = a;
            this.i = b;
            this.setTime = c;
            this.wc = d;
            this.Ti = e;
            this.Yg = f;
            this.ia = !1;
            this.id = 0 === this.mode ? Uf(this) : 0
        },
        Uf = function(a) {
            return a.i.setTimeout(function() {
                Wf(a)
            }, a.wc)
        },
        Xf = function(a, b) {
            var c = me(b, a.setTime);
            c >= a.wc ? Wf(a) : (a.setTime = b, a.wc -= c)
        },
        Wf = function(a) {
            try {
                a.Ti(a.setTime.add(a.wc))
            } finally {
                a.ia = !0, a.Yg()
            }
        };
    Vf.prototype.We = function(a, b) {
        this.ia || (1 === this.mode && 1 === a ? Xf(this, b) : 1 === this.mode && 0 === a ? (this.mode = a, Xf(this, this.i.now()), this.ia || (this.id = Uf(this))) : 0 === this.mode && 1 === a && (this.mode = a, this.clear(), Xf(this, b)))
    };
    Vf.prototype.clear = function() {
        this.ia || this.i.clearTimeout(this.id)
    };
    var Yf = function(a) {
        this.Vc = a;
        this.Hh = this.mode = 0;
        this.Hb = {};
        this.timeline = a.timeline;
        this.qb = a.now()
    };
    n = Yf.prototype;
    n.We = function(a, b) {
        this.mode = a;
        le(this.qb, b);
        this.qb = b;
        Object.values(this.Hb).forEach(function(c) {
            return void c.We(a, b)
        })
    };
    n.now = function() {
        return 1 === this.mode ? this.qb : this.Vc.now()
    };
    n.setTimeout = function(a, b) {
        var c = this,
            d = ++this.Hh,
            e = 1 === this.mode ? this.qb : this.Vc.now();
        this.Hb[d] = new Vf(this.mode, this.Vc, e, b, function(f) {
            var g = c.qb;
            1 === c.mode && (c.qb = f);
            a();
            c.qb = g
        }, function() {
            delete c.Hb[d]
        });
        return d
    };
    n.clearTimeout = function(a) {
        this.Hb[a] && (this.Hb[a].clear(), delete this.Hb[a])
    };
    n.interval = function() {
        throw Error("G");
    };
    n.Oa = function() {
        throw Error("H");
    };
    n.ha = function() {
        return this.Vc.ha()
    };

    function Zf(a, b) {
        var c = new Yf(a);
        a = b.subscribe(function(d) {
            c.We(d.value ? 1 : 0, d.timestamp)
        });
        return {
            i: c,
            Kj: a
        }
    };

    function $f(a) {
        var b = Object.assign({}, a);
        delete b.timestamp;
        return {
            timestamp: new ke(a.timestamp, je),
            value: b
        }
    };

    function ag(a) {
        return void 0 !== a && "number" === typeof a.x && "number" === typeof a.y && "number" === typeof a.width && "number" === typeof a.height
    }

    function bg(a) {
        if (void 0 === a) return !1;
        a = a.data;
        var b;
        if (b = void 0 !== a) b = a.viewport, b = !(void 0 === b || void 0 !== b && "number" === typeof b.width && "number" === typeof b.height);
        if (b) return !1;
        a = a.adView;
        return void 0 !== a && "number" === typeof a.percentageInView && (void 0 === a.geometry || ag(a.geometry)) && (void 0 === a.onScreenGeometry || ag(a.onScreenGeometry))
    };
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    var cg = fa([""]),
        dg = ha(["\x00"], ["\\0"]),
        eg = ha(["\n"], ["\\n"]),
        fg = ha(["\x00"], ["\\u0000"]),
        gg = fa([""]),
        hg = ha(["\x00"], ["\\0"]),
        ig = ha(["\n"], ["\\n"]),
        jg = ha(["\x00"], ["\\u0000"]);

    function kg(a) {
        return Object.isFrozen(a) && Object.isFrozen(a.raw)
    }

    function lg(a) {
        return -1 === a.toString().indexOf("`")
    }
    var mg = lg(function(a) {
            return a(cg)
        }) || lg(function(a) {
            return a(dg)
        }) || lg(function(a) {
            return a(eg)
        }) || lg(function(a) {
            return a(fg)
        }),
        ng = kg(gg) && kg(hg) && kg(ig) && kg(jg);
    var og = function(a, b) {
        this.name = a;
        this.value = b
    };
    og.prototype.toString = function() {
        return this.name
    };
    var pg = new og("OFF", Infinity),
        qg = new og("WARNING", 900),
        rg = new og("INFO", 800),
        sg = new og("CONFIG", 700),
        tg = function() {
            this.Qc = 0;
            this.clear()
        },
        ug;
    tg.prototype.clear = function() {
        this.rf = Array(this.Qc);
        this.wf = -1;
        this.Tf = !1
    };
    var vg = function(a, b, c) {
        this.reset(a || pg, b, c, void 0, void 0)
    };
    vg.prototype.reset = function(a, b, c, d) {
        d || Date.now();
        this.ci = b
    };
    vg.prototype.getMessage = function() {
        return this.ci
    };
    var wg = function(a, b) {
            this.level = null;
            this.Ah = [];
            this.parent = (void 0 === b ? null : b) || null;
            this.children = [];
            this.Zf = {
                Na: function() {
                    return a
                }
            }
        },
        xg = function(a) {
            if (a.level) return a.level;
            if (a.parent) return xg(a.parent);
            ab("Root logger has no level set.");
            return pg
        },
        yg = function(a, b) {
            for (; a;) a.Ah.forEach(function(c) {
                c(b)
            }), a = a.parent
        },
        zg = function() {
            this.entries = {};
            var a = new wg("");
            a.level = sg;
            this.entries[""] = a
        },
        Ag, Bg = function(a, b, c) {
            var d = a.entries[b];
            if (d) return void 0 !== c && (d.level = c), d;
            d = Bg(a, b.slice(0,
                Math.max(b.lastIndexOf("."), 0)));
            var e = new wg(b, d);
            a.entries[b] = e;
            d.children.push(e);
            void 0 !== c && (e.level = c);
            return e
        },
        Cg = function() {
            Ag || (Ag = new zg);
            return Ag
        },
        Dg = function(a, b) {
            var c = qg,
                d;
            if (d = a)
                if (d = a && c) {
                    d = c.value;
                    var e = a ? xg(Bg(Cg(), a.Na())) : pg;
                    d = d >= e.value
                }
            if (d) {
                c = c || pg;
                d = Bg(Cg(), a.Na());
                "function" === typeof b && (b = b());
                ug || (ug = new tg);
                e = ug;
                a = a.Na();
                if (0 < e.Qc) {
                    var f = (e.wf + 1) % e.Qc;
                    e.wf = f;
                    e.Tf ? (e = e.rf[f], e.reset(c, b, a), a = e) : (e.Tf = f == e.Qc - 1, a = e.rf[f] = new vg(c, b, a))
                } else a = new vg(c, b, a);
                yg(d, a)
            }
        };
    var Eg = [],
        Fg = function(a) {
            var b = Bg(Cg(), "safevalues").Zf;
            b && Dg(b, "A URL with content '" + a + "' was sanitized away.")
        }; - 1 === Eg.indexOf(Fg) && Eg.push(Fg);

    function Gg(a) {
        var b = y.apply(1, arguments);
        if (!Array.isArray(a) || !Array.isArray(a.raw) || a.length !== a.raw.length || !mg && a === a.raw || !(mg && !ng || kg(a)) || b.length + 1 !== a.length) throw new TypeError("I");
        if (0 === b.length) return tb(a[0]);
        var c = a[0].toLowerCase();
        if (/^data:/.test(c)) throw Error("P");
        if (/^https:\/\//.test(c) || /^\/\//.test(c)) {
            var d = c.indexOf("//") + 2;
            var e = c.indexOf("/", d);
            if (e <= d) throw Error("J");
            d = c.substring(d, e);
            if (!/^[0-9a-z.:-]+$/i.test(d)) throw Error("K");
            if (!/^[^:]*(:[0-9]+)?$/i.test(d)) throw Error("L");
            if (!/(^|\.)[a-z][^.]*$/i.test(d)) throw Error("M");
            d = !0
        } else d = !1;
        if (!d)
            if (/^\//.test(c))
                if ("/" === c || 1 < c.length && "/" !== c[1] && "\\" !== c[1]) d = !0;
                else throw Error("O");
        else d = !1;
        if (!(d = d || RegExp("^[^:\\s\\\\/]+/").test(c)))
            if (/^about:blank/.test(c)) {
                if ("about:blank" !== c && !/^about:blank#/.test(c)) throw Error("N");
                d = !0
            } else d = !1;
        if (!d) throw Error("Q");
        c = a[0];
        for (d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return tb(c)
    };
    var Hg = fa(["https://www.googleadservices.com/pagead/managed/js/activeview/", "/reach_worklet.html"]),
        Ig = fa(["./reach_worklet.js"]),
        Jg = fa(["./reach_worklet.js"]),
        Kg = fa(["./reach_worklet.html"]),
        Lg = fa(["./reach_worklet.js"]),
        Mg = fa(["./reach_worklet.js"]);

    function Ng(a) {
        var b = {};
        return b[0] = Gg(Hg, a), b[1] = Gg(Ig), b[2] = Gg(Jg), b
    }
    Gg(Kg);
    Gg(Lg);
    Gg(Mg);
    var Pg = function(a, b, c, d, e) {
        c = void 0 === c ? !1 : c;
        d = void 0 === d ? null : d;
        e = void 0 === e ? Ng("current") : e;
        Td.call(this);
        this.K = a;
        this.Gc = b;
        this.Ka = d;
        this.sg = e;
        this.Nb = null;
        this.wd = new yc(3);
        this.wd.g(T(function(f) {
            return "sessionStart" === f.value.type
        }));
        this.Ji = this.wd.g(T(function(f) {
            return "sessionFinish" === f.value.type
        }));
        this.te = new yc(1);
        this.Cg = new yc;
        this.le = new yc(10);
        this.H = new Sf(this, new Lf(a));
        this.Ph = this.K.L();
        c ? this.i = Og(this, new Rf(this.K)) : (this.i = new Rf(this.K), this.uf())
    };
    x(Pg, Td);
    Pg.prototype.validate = function() {
        return this.Ph
    };
    var Og = function(a, b) {
        a.Nb = new qe(a.K, a.Gc);
        var c = new yc;
        re(a.Nb, function(f) {
            f = $f(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.wd.next(f)
        });
        te(a.Nb, function(f) {
            bg(f) ? (f = $f(f), c.next({
                timestamp: f.timestamp,
                value: !0
            }), a.le.next(f)) : .01 >= Math.random() && (f = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" + JSON.stringify(f), a.H.N(f).sendNow())
        });
        se(a.Nb, function(f) {
            f = $f(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Cg.next(f)
        });
        ue(a.Nb, function(f) {
            f =
                $f(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.te.next(f)
        });
        var d = 0;
        ve(a.Nb, function(f) {
            d += f;
            0 < d && 0 === f && c.next({
                timestamp: a.i.now(),
                value: !1
            })
        });
        var e = c.g(Cf(function(f) {
            return f.value
        }, !0));
        return Zf(b, e).i
    };
    Pg.prototype.uf = function() {
        var a = this;
        xe(this.K, function(e) {
            return void a.wd.next($f(e))
        }, this.Gc);
        this.K.addEventListener("geometryChange", function(e) {
            bg(e) ? a.le.next($f(e)) : .01 >= Math.random() && (e = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" + JSON.stringify(e), a.H.N(e).sendNow())
        });
        for (var b = t("loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(" ")),
                c = b.next(), d = {}; !c.done; d = {
                Xc: d.Xc
            }, c = b.next()) d.Xc = c.value, this.K.addEventListener(d.Xc, function(e) {
            return function(f) {
                f.type === e.Xc && a.Cg.next($f(f))
            }
        }(d));
        this.K.addEventListener("impression", function(e) {
            a.te.next($f(e))
        })
    };
    da.Object.defineProperties(Pg.prototype, {
        global: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Qg
            }
        }
    });
    var Qg = {};

    function Rg(a, b) {
        return function(c) {
            return new L(function(d) {
                return c.subscribe(function(e) {
                    a.Ub(b, function() {
                        d.next(e)
                    })()
                }, function(e) {
                    a.Ub(b, function() {
                        d.error(e)
                    })()
                }, function() {
                    a.Ub(b, function() {
                        d.complete()
                    })()
                })
            })
        }
    };
    var Tg = function() {
        for (var a = t(y.apply(0, arguments)), b = a.next(); !b.done; b = a.next())
            if (b = b.value, b.ha()) {
                this.i = b;
                return
            }
        this.i = new Sg
    };
    n = Tg.prototype;
    n.ha = function() {
        return this.i.ha()
    };
    n.now = function() {
        return this.i.now()
    };
    n.setTimeout = function(a, b) {
        return this.i.setTimeout(a, b)
    };
    n.clearTimeout = function(a) {
        this.i.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Oa(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Oa = function(a) {
        return this.i.Oa(a)
    };
    da.Object.defineProperties(Tg.prototype, {
        timeline: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.i.timeline
            }
        }
    });
    var Sg = function() {
        this.timeline = Symbol()
    };
    n = Sg.prototype;
    n.ha = function() {
        return !1
    };
    n.now = function() {
        return new ke(0, this.timeline)
    };
    n.setTimeout = function() {
        return 0
    };
    n.clearTimeout = function() {};
    n.interval = function() {
        return function() {}
    };
    n.Oa = function() {
        return vd
    };
    var Ug = function(a, b) {
        this.J = a;
        this.B = b
    };
    n = Ug.prototype;
    n.setTimeout = function(a, b) {
        return this.J.setTimeout(this.B.Ub(734, a), b)
    };
    n.clearTimeout = function(a) {
        this.J.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Oa(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Oa = function(a) {
        var b = this;
        return new L(function(c) {
            var d = 0,
                e = b.J.setInterval(function() {
                    c.next(d++)
                }, a);
            return function() {
                b.J.clearInterval(e)
            }
        })
    };
    n.ha = function() {
        return !!this.J.clearTimeout && "setTimeout" in this.J && "setInterval" in this.J && !!this.J.clearInterval
    };
    var Vg = function(a, b) {
        Ug.call(this, a, b);
        this.timeline = je
    };
    x(Vg, Ug);
    Vg.prototype.now = function() {
        return new ke(this.J.Date.now(), this.timeline)
    };
    Vg.prototype.ha = function() {
        return !!this.J.Date && !!this.J.Date.now && Ug.prototype.ha.call(this)
    };
    var Wg = function(a, b) {
        Ug.call(this, a, b);
        this.timeline = he
    };
    x(Wg, Ug);
    Wg.prototype.now = function() {
        return new ke(this.J.performance.now(), this.timeline)
    };
    Wg.prototype.ha = function() {
        return !!this.J.performance && !!this.J.performance.now && Ug.prototype.ha.call(this)
    };
    var Xg = function(a) {
        this.context = a
    };
    Xg.prototype.L = function() {
        return !Yg(this.context) && !!this.context.global.fetch
    };
    Xg.prototype.ping = function() {
        var a = this;
        return td.apply(null, u(y.apply(0, arguments).map(function(b) {
            return hd(a.context.global.fetch(b, {
                method: "GET",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors"
            })).g(P(function(c) {
                return 200 === c.status
            }))
        }))).g(Ye(function(b) {
            return b
        }), gf())
    };
    Xg.prototype.rd = function(a, b, c) {
        for (var d = y.apply(3, arguments), e = this, f = new Headers, g = t(b.entries()), k = g.next(); !k.done; k = g.next()) {
            var h = t(k.value);
            k = h.next().value;
            h = h.next().value;
            f.set(k, h)
        }
        var l, m = null != (l = a.Yf) ? l : !1;
        td.apply(null, u(d.map(function(r) {
            return hd(e.context.global.fetch(r, Object.assign({}, {
                method: String(a.Bb),
                cache: "no-cache"
            }, m ? {
                keepalive: !0
            } : {}, {
                mode: "no-cors",
                headers: f,
                body: c
            }))).g(P(function(q) {
                return 200 === q.status
            }))
        }))).g(Ye(function(r) {
            return r
        }), gf())
    };
    var Zg = function(a) {
        Zg[" "](a);
        return a
    };
    Zg[" "] = function() {};
    var $g = function(a, b) {
        try {
            return Zg(a[b]), !0
        } catch (c) {}
        return !1
    };
    var ah = Kb(),
        bh = Lb(),
        ch = H("Edge"),
        dh = H("Gecko") && !(vb(Fb(), "WebKit") && !H("Edge")) && !(H("Trident") || H("MSIE")) && !H("Edge"),
        eh = vb(Fb(), "WebKit") && !H("Edge"),
        fh = function() {
            var a = Ja.document;
            return a ? a.documentMode : void 0
        },
        gh;
    a: {
        var hh = "",
            ih = function() {
                var a = Fb();
                if (dh) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (ch) return /Edge\/([\d\.]+)/.exec(a);
                if (bh) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (eh) return /WebKit\/(\S+)/.exec(a);
                if (ah) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();ih && (hh = ih ? ih[1] : "");
        if (bh) {
            var jh = fh();
            if (null != jh && jh > parseFloat(hh)) {
                gh = String(jh);
                break a
            }
        }
        gh = hh
    }
    var kh = gh,
        lh;
    if (Ja.document && bh) {
        var mh = fh();
        lh = mh ? mh : parseInt(kh, 10) || void 0
    } else lh = void 0;
    var nh = lh;
    var oh = function(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    };
    n = oh.prototype;
    n.clone = function() {
        return new oh(this.x, this.y)
    };
    n.toString = function() {
        return "(" + this.x + ", " + this.y + ")"
    };
    n.equals = function(a) {
        return a instanceof oh && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    n.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    n.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    n.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    n.translate = function(a, b) {
        a instanceof oh ? (this.x += a.x, this.y += a.y) : (this.x += Number(a), "number" === typeof b && (this.y += b));
        return this
    };
    n.scale = function(a, b) {
        this.x *= a;
        this.y *= "number" === typeof b ? b : a;
        return this
    };
    var ph = function(a, b) {
        this.width = a;
        this.height = b
    };
    n = ph.prototype;
    n.clone = function() {
        return new ph(this.width, this.height)
    };
    n.toString = function() {
        return "(" + this.width + " x " + this.height + ")"
    };
    n.aspectRatio = function() {
        return this.width / this.height
    };
    n.ld = function() {
        return !(this.width * this.height)
    };
    n.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    n.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    n.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    n.scale = function(a, b) {
        this.width *= a;
        this.height *= "number" === typeof b ? b : a;
        return this
    };
    var sh = function(a) {
            return a ? new qh(rh(a)) : Xa || (Xa = new qh)
        },
        th = function(a) {
            var b = a.scrollingElement ? a.scrollingElement : eh || "CSS1Compat" != a.compatMode ? a.body || a.documentElement : a.documentElement;
            a = a.parentWindow || a.defaultView;
            return bh && a.pageYOffset != b.scrollTop ? new oh(b.scrollLeft, b.scrollTop) : new oh(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
        },
        uh = function(a, b, c) {
            function d(k) {
                k && b.appendChild("string" === typeof k ? a.createTextNode(k) : k)
            }
            for (var e = 1; e < c.length; e++) {
                var f = c[e];
                if (!Ma(f) ||
                    Na(f) && 0 < f.nodeType) d(f);
                else {
                    a: {
                        if (f && "number" == typeof f.length) {
                            if (Na(f)) {
                                var g = "function" == typeof f.item || "string" == typeof f.item;
                                break a
                            }
                            if ("function" === typeof f) {
                                g = "function" == typeof f.item;
                                break a
                            }
                        }
                        g = !1
                    }
                    hb(g ? mb(f) : f, d)
                }
            }
        },
        rh = function(a) {
            z(a, "Node cannot be null or undefined.");
            return 9 == a.nodeType ? a : a.ownerDocument || a.document
        },
        vh = function(a, b) {
            a && (a = a.parentNode);
            for (var c = 0; a;) {
                z("parentNode" != a.name);
                if (b(a)) return a;
                a = a.parentNode;
                c++
            }
            return null
        },
        qh = function(a) {
            this.Eb = a || Ja.document ||
                document
        };
    n = qh.prototype;
    n.getElementsByTagName = function(a, b) {
        return (b || this.Eb).getElementsByTagName(String(a))
    };
    n.createElement = function(a) {
        var b = this.Eb;
        a = String(a);
        "application/xhtml+xml" === b.contentType && (a = a.toLowerCase());
        return b.createElement(a)
    };
    n.createTextNode = function(a) {
        return this.Eb.createTextNode(String(a))
    };
    n.appendChild = function(a, b) {
        z(null != a && null != b, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    n.append = function(a, b) {
        uh(rh(a), a, arguments)
    };
    n.canHaveChildren = function(a) {
        if (1 != a.nodeType) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    n.removeNode = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    n.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    var xh = function() {
            return Db && Gb ? Gb.mobile : !wh() && (H("iPod") || H("iPhone") || H("Android") || H("IEMobile"))
        },
        wh = function() {
            return Db && Gb ? !Gb.mobile && (H("iPad") || H("Android") || H("Silk")) : H("iPad") || H("Android") && !H("Mobile") || H("Silk")
        };
    var yh = function(a) {
        try {
            return !!a && null != a.location.href && $g(a, "foo")
        } catch (b) {
            return !1
        }
    };
    var zh = function(a) {
        this.context = a
    };
    zh.prototype.L = function(a) {
        return (null == a ? 0 : a.Nc) || "POST" === (null == a ? void 0 : a.Bb) || (null == a ? 0 : a.Db) || (null == a ? 0 : a.de) || (null == a ? 0 : a.Yf) ? !1 : !Yg(this.context)
    };
    zh.prototype.ping = function() {
        var a = this;
        return N(y.apply(0, arguments).map(function(b) {
            try {
                var c = a.context.global;
                c.google_image_requests || (c.google_image_requests = []);
                var d = c.document;
                d = void 0 === d ? document : d;
                var e = d.createElement("img");
                e.src = b;
                c.google_image_requests.push(e);
                return !0
            } catch (f) {
                return !1
            }
        }).every(function(b) {
            return b
        }))
    };
    zh.prototype.rd = function(a, b, c) {
        this.ping.apply(this, u(y.apply(3, arguments)))
    };

    function Ah(a) {
        a = a.global;
        if (a.PendingGetBeacon) return a.PendingGetBeacon
    }
    var Bh = function(a) {
        this.context = a
    };
    Bh.prototype.L = function(a) {
        return Ch && !Yg(this.context) && void 0 !== Ah(this.context) && !(null == a ? 0 : a.Nc) && "POST" !== (null == a ? void 0 : a.Bb) && !(null == a ? 0 : a.Db) && !(null == a ? 0 : a.de)
    };
    Bh.prototype.N = function(a, b) {
        if (!this.L(b)) throw new Yd;
        return new Dh(this.context, a)
    };
    var Ch = !1,
        Dh = function(a, b) {
            this.context = a;
            this.Xe = b;
            a = Ah(this.context);
            if (void 0 === a) throw Error();
            this.cf = new a(Eh(this), {})
        },
        Eh = function(a) {
            a = a.Xe;
            return ("&" === a.slice(-1)[0] ? a : a + "&") + "pbapi=1"
        };
    Dh.prototype.deactivate = function() {
        this.cf.deactivate()
    };
    Dh.prototype.sendNow = function() {
        this.cf.sendNow()
    };
    da.Object.defineProperties(Dh.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Xe
            },
            set: function(a) {
                this.Xe = a;
                this.cf.setURL(Eh(this))
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "GET"
            },
            set: function(a) {
                if ("GET" !== a) throw new Yd;
            }
        }
    });
    var Fh = function(a) {
        this.context = a
    };
    Fh.prototype.L = function(a) {
        if ((null == a ? 0 : a.Nc) || "GET" === (null == a ? void 0 : a.Bb) || (null == a ? 0 : a.Db) || (null == a ? 0 : a.de) || (null == a ? 0 : a.Yf)) return !1;
        var b;
        return !Yg(this.context) && void 0 !== (null == (b = this.context.global.navigator) ? void 0 : b.sendBeacon)
    };
    Fh.prototype.ping = function() {
        var a = this;
        return N(y.apply(0, arguments).map(function(b) {
            var c;
            return null == (c = a.context.global.navigator) ? void 0 : c.sendBeacon(b)
        }).every(function(b) {
            return b
        }))
    };
    Fh.prototype.rd = function(a, b, c) {
        this.ping.apply(this, u(y.apply(3, arguments)))
    };

    function Gh(a) {
        return function(b) {
            return b.g(Hh(a, of (new M)))
        }
    }

    function Y(a, b) {
        return function(c) {
            return c.g(Hh(a, tf(b)))
        }
    }

    function Hh(a, b) {
        function c(d) {
            return new L(function(e) {
                return d.subscribe(function(f) {
                    Ua(a, function() {
                        return void e.next(f)
                    }, 3)
                }, function(f) {
                    Ua(a, function() {
                        return void e.error(f)
                    }, 3)
                }, function() {
                    Ua(a, function() {
                        return void e.complete()
                    }, 3)
                })
            })
        }
        return K(c, yf(), b, Cc(), c)
    };
    var Z = function(a) {
        this.value = a
    };
    Z.prototype.V = function(a) {
        return N(this.value).g(Y(a, 1))
    };
    var Ih = new Z(!1);
    Ob();
    Nb();
    Mb();
    var Jh = {},
        Kh = null,
        Lh = dh || eh || "function" == typeof Ja.btoa,
        Nh = function(a) {
            var b;
            z(Ma(a), "encodeByteArray takes an array as a parameter");
            void 0 === b && (b = 0);
            Mh();
            b = Jh[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    k = a[e + 1],
                    h = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | k >> 4];
                k = b[(k & 15) << 2 | h >> 6];
                h = b[h & 63];
                c[f++] = "" + l + g + k + h
            }
            l = 0;
            h = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], h = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = "" + b[a >> 2] + b[(a & 3) << 4 | l >> 4] + h + d
            }
            return c.join("")
        },
        Ph = function(a) {
            var b =
                a.length,
                c = 3 * b / 4;
            c % 3 ? c = Math.floor(c) : -1 != "=.".indexOf(a[b - 1]) && (c = -1 != "=.".indexOf(a[b - 2]) ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            Oh(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        Oh = function(a, b) {
            function c(h) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = Kh[l];
                    if (null != m) return m;
                    if (!/^[\s\xa0]*$/.test(l)) throw Error("S`" + l);
                }
                return h
            }
            Mh();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    k = c(64);
                if (64 === k && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != k && b(g << 6 & 192 | k))
            }
        },
        Mh = function() {
            if (!Kh) {
                Kh = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    Jh[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e],
                            g = Kh[f];
                        void 0 === g ? Kh[f] = e : z(g === e)
                    }
                }
            }
        };

    function Qh(a) {
        var b = Rh(a);
        return null === b ? new Z(null) : b.g(P(function(c) {
            c = c.eb();
            if (Lh) c = Ja.btoa(c);
            else {
                for (var d = [], e = 0, f = 0; f < c.length; f++) {
                    var g = c.charCodeAt(f);
                    if (255 < g) throw Error("R");
                    d[e++] = g
                }
                c = Nh(d)
            }
            return c
        }), Qe(1), Y(a.h, 1))
    };

    function Sh(a) {
        var b = void 0 === b ? {} : b;
        if ("function" === typeof Event) return new Event(a, b);
        if ("undefined" !== typeof document) {
            var c = document.createEvent("CustomEvent");
            c.initCustomEvent(a, b.bubbles || !1, b.cancelable || !1, b.detail);
            return c
        }
        throw Error();
    };
    var Uh = function(a) {
        this.value = a;
        this.Qe = new M
    };
    Uh.prototype.release = function() {
        this.Qe.next();
        this.Qe.complete();
        this.value = void 0
    };
    da.Object.defineProperties(Uh.prototype, {
        j: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.value
            }
        },
        released: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Qe
            }
        }
    });
    var Vh = ["FRAME", "IMG", "IFRAME"],
        Wh = /^[01](px)?$/;

    function Xh(a) {
        return "string" === typeof a ? document.getElementById(a) : a
    }

    function Yh(a, b) {
        var c = !0,
            d = !0,
            e = void 0,
            f = !0;
        c = void 0 === c ? !0 : c;
        d = void 0 === d ? !1 : d;
        f = void 0 === f ? !1 : f;
        var g = void 0 === g ? !1 : g;
        if (a = Xh(a)) {
            e || (e = function(ia, E, B) {
                ia.addEventListener(E, B)
            });
            for (var k = !1, h = function(ia) {
                    k || (k = !0, b(ia))
                }, l, m, r = 0; r < Vh.length; ++r)
                if (Vh[r] == a.tagName) {
                    m = 3;
                    l = [a];
                    break
                }
            l || (l = a.querySelectorAll(Vh.join(",")), m = 2);
            var q = 0,
                v = 0,
                w = !g,
                A = a = !1;
            r = {};
            for (var D = 0; D < l.length; r = {
                    lc: r.lc
                }, D++) {
                var C = l[D];
                if (!("IMG" == C.tagName && (C.complete && (!C.naturalWidth || !C.naturalHeight) || (void 0 === g ? 0 : g) &&
                        C.style && "none" === C.style.display) || Wh.test(C.getAttribute("width")) && Wh.test(C.getAttribute("height")))) {
                    r.lc = "IMG" === C.tagName;
                    if ("IMG" == C.tagName) var S = C.naturalWidth && C.naturalHeight ? !0 : !1;
                    else try {
                        S = "complete" === (C.readyState ? C.readyState : C.contentWindow && C.contentWindow.document && C.contentWindow.document.readyState) ? !0 : !1
                    } catch (ia) {
                        S = void 0 === d ? !1 : d
                    }
                    if (S) a = !0, r.lc && (w = !0);
                    else {
                        q++;
                        var pa = function(ia) {
                            return function(E) {
                                q--;
                                !q && w && h(m);
                                ia.lc && (E = E && "error" === E.type, v--, E || (w = !0), !v && A && w && h(m))
                            }
                        }(r);
                        e(C, "load", pa);
                        r.lc && (v++, e(C, "error", pa))
                    }
                }
            }
            0 === v && (w = !0);
            l = null;
            if (0 === q && !a && "complete" === Ja.document.readyState) m = 5;
            else if (q || !a) {
                e(Ja, "load", function() {
                    !f || !v && w ? h(4) : A = !0
                });
                return
            }
            c && h(m)
        }
    };

    function Zh(a, b, c) {
        if (a)
            for (var d = 0; null != a && 500 > d && !c(a); ++d) a = b(a)
    }

    function $h(a, b) {
        Zh(a, function(c) {
            try {
                return c === c.parent ? null : c.parent
            } catch (d) {}
            return null
        }, b)
    }

    function ai(a, b) {
        if ("IFRAME" == a.tagName) b(a);
        else {
            a = a.querySelectorAll("IFRAME");
            for (var c = 0; c < a.length && !b(a[c]); ++c);
        }
    }

    function bi(a) {
        return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
    }

    function ci(a, b, c) {
        try {
            var d = JSON.parse(c.data)
        } catch (g) {}
        if ("object" === typeof d && d && "creativeLoad" === d.type) {
            var e = bi(a);
            if (c.source && e) {
                var f;
                $h(c.source, function(g) {
                    try {
                        if (g.parent === e) return f = g, !0
                    } catch (k) {}
                });
                f && ai(a, function(g) {
                    if (g.contentWindow === f) return b(d), !0
                })
            }
        }
    }

    function di(a) {
        return "string" === typeof a ? document.getElementById(a) : a
    }
    var ei = function(a, b) {
        var c = di(a);
        if (c)
            if (c.onCreativeLoad) c.onCreativeLoad(b);
            else {
                var d = b ? [b] : [],
                    e = function(f) {
                        for (var g = 0; g < d.length; ++g) try {
                            d[g](1, f)
                        } catch (k) {}
                        d = {
                            push: function(k) {
                                k(1, f)
                            }
                        }
                    };
                c.onCreativeLoad = function(f) {
                    d.push(f)
                };
                c.setAttribute("data-creative-load-listener", "");
                c.addEventListener("creativeLoad", function(f) {
                    e(f.detail)
                });
                Ja.addEventListener("message", function(f) {
                    ci(c, e, f)
                })
            }
    };
    var fi = function(a, b) {
            var c = this;
            this.global = a;
            this.qd = b;
            this.ni = this.document ? td(N(!0), nd(this.document, "visibilitychange")).g(Rg(this.qd.B, 748), P(function() {
                return c.document ? c.document.visibilityState : "visible"
            }), V()) : N("visible");
            this.ki = this.document ? nd(this.document, "DOMContentLoaded").g(Rg(this.qd.B, 739), Qe(1)) : N(Sh("DOMContentLoaded"))
        },
        gi = function(a) {
            return a.document ? a.document.readyState : "complete"
        },
        hi = function(a) {
            return null !== a.document && void 0 !== a.document.visibilityState
        };
    fi.prototype.querySelector = function(a) {
        return this.document ? this.document.querySelector(a) : null
    };
    fi.prototype.querySelectorAll = function(a) {
        return this.document ? mb(this.document.querySelectorAll(a)) : []
    };
    var ii = function(a) {
        return null !== a.document && "function" === typeof a.document.elementFromPoint
    };
    fi.prototype.elementFromPoint = function(a, b) {
        if (!this.document || !ii(this)) return null;
        a = this.document.elementFromPoint(a, b);
        return null === a ? null : new Uh(a)
    };
    var ji = function(a, b, c) {
            c = void 0 === c ? !1 : c;
            if (void 0 === b.j || !a.document) return N(b).g(Rg(a.qd.B, 749));
            var d = new yc(1),
                e = function() {
                    d.next(b)
                };
            c || ei(b.j, e);
            Yh(b.j, e);
            return d.g(Rg(a.qd.B, 749), Qe(1))
        },
        ki = function(a, b, c) {
            var d, e, f;
            return Ba(function(g) {
                if (1 == g.ma) {
                    d = a.global.document.createElement("iframe");
                    e = new Promise(function(h) {
                        d.onload = h;
                        d.onerror = h
                    });
                    if (b instanceof sb && b.constructor === sb) var k = b.hg;
                    else ab("expected object of type TrustedResourceUrl, got '%s' of type %s", b, La(b)), k = "type_error:TrustedResourceUrl";
                    d.src = k.toString();
                    a.document && a.document.body.appendChild(d);
                    d.style.display = "none";
                    return ta(g, e, 2)
                }
                f = d.contentWindow;
                if (!f) return g.return();
                f.postMessage(c, "*");
                return g.return(d)
            })
        };
    da.Object.defineProperties(fi.prototype, {
        document: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return $g(this.global, "document") ? this.global.document || null : null
            }
        }
    });
    var li = {
        left: 0,
        top: 0,
        width: 0,
        height: 0
    };

    function mi(a, b) {
        return a.left === b.left && a.top === b.top && a.width === b.width && a.height === b.height
    }

    function ni(a, b) {
        return {
            left: Math.max(a.left, b.left),
            top: Math.max(a.top, b.top),
            width: Math.max(0, Math.min(a.left + a.width, b.left + b.width) - Math.max(a.left, b.left)),
            height: Math.max(0, Math.min(a.top + a.height, b.top + b.height) - Math.max(a.top, b.top))
        }
    }

    function oi(a, b) {
        return {
            left: Math.round(a.left + b.x),
            top: Math.round(a.top + b.y),
            width: a.width,
            height: a.height
        }
    };
    var pi = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    };
    n = pi.prototype;
    n.qe = function() {
        return this.right - this.left
    };
    n.ne = function() {
        return this.bottom - this.top
    };
    n.clone = function() {
        return new pi(this.top, this.right, this.bottom, this.left)
    };
    n.toString = function() {
        return "(" + this.top + "t, " + this.right + "r, " + this.bottom + "b, " + this.left + "l)"
    };
    n.contains = function(a) {
        return this && a ? a instanceof pi ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    n.expand = function(a, b, c, d) {
        Na(a) ? (this.top -= a.top, this.right += a.right, this.bottom += a.bottom, this.left -= a.left) : (this.top -= a, this.right += Number(b), this.bottom += Number(c), this.left -= Number(d));
        return this
    };
    n.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    n.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    n.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    n.translate = function(a, b) {
        a instanceof oh ? (this.left += a.x, this.right += a.x, this.top += a.y, this.bottom += a.y) : (bb(a), this.left += a, this.right += a, "number" === typeof b && (this.top += b, this.bottom += b));
        return this
    };
    n.scale = function(a, b) {
        b = "number" === typeof b ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };

    function qi(a, b) {
        if (a) throw Error("T");
        b.push(65533)
    }

    function ri(a, b) {
        b = String.fromCharCode.apply(null, b);
        return null == a ? b : a + b
    }
    var si = void 0,
        ti, ui, vi = "undefined" !== typeof TextDecoder;
    var wi = "undefined" !== typeof Uint8Array,
        xi = !bh && "function" === typeof btoa;

    function yi(a) {
        if (!xi) return Nh(a);
        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    }
    var zi = /[-_.]/g,
        Ai = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function Bi(a) {
        return Ai[a] || ""
    }

    function Ci(a) {
        if (!xi) return Ph(a);
        var b = a;
        zi.test(b) && (b = b.replace(zi, Bi));
        try {
            var c = atob(b)
        } catch (d) {
            throw Error("U`" + a + "`" + d);
        }
        a = new Uint8Array(c.length);
        for (b = 0; b < c.length; b++) a[b] = c.charCodeAt(b);
        return a
    }
    var Di, Ei = {};
    var Fi, Hi = function(a, b) {
        if (b !== Ei) throw Error("V");
        this.Fc = a;
        if (null != a && 0 === a.length) throw Error("W");
        this.dontPassByteStringToStructuredClone = Gi
    };
    Hi.prototype.ld = function() {
        return null == this.Fc
    };

    function Gi() {};

    function Ii(a) {
        return Array.prototype.slice.call(a)
    };
    var Ji = "function" === typeof Symbol && "symbol" === typeof Symbol() ? Symbol("INTERNAL_ARRAY_STATE") : void 0;
    z(13 === Math.round(Math.log2(Math.max.apply(Math, u(Object.values({
        sj: 1,
        qj: 2,
        pj: 4,
        wj: 8,
        vj: 16,
        uj: 32,
        dj: 64,
        zj: 128,
        oj: 256,
        nj: 512,
        rj: 1024,
        hj: 2048,
        yj: 4096,
        ij: 8192
    }))))));

    function Ki(a) {
        z((a & 16777215) == a)
    }
    var Li = Ji ? function(a, b) {
        Ki(b);
        F(a, "state is only maintained on arrays.");
        a[Ji] |= b
    } : function(a, b) {
        Ki(b);
        F(a, "state is only maintained on arrays.");
        void 0 !== a.sa ? a.sa |= b : Object.defineProperties(a, {
            sa: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        })
    };

    function Mi(a) {
        var b = Ni(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = Ii(a)), Oi(a, b | 1))
    }
    var Pi = Ji ? function(a, b) {
        Ki(b);
        F(a, "state is only maintained on arrays.");
        a[Ji] &= ~b
    } : function(a, b) {
        Ki(b);
        F(a, "state is only maintained on arrays.");
        void 0 !== a.sa && (a.sa &= ~b)
    };

    function Qi(a, b, c) {
        return c ? a | b : a & ~b
    }
    var Ri = Object.getOwnPropertyDescriptor(Array.prototype, "Qh");
    Object.defineProperties(Array.prototype, {
        Qh: {
            get: function() {
                function a(e, f) {
                    e & b && c.push(f)
                }
                var b = Ni(this),
                    c = [];
                a(1, "IS_REPEATED_FIELD");
                a(2, "IS_IMMUTABLE_ARRAY");
                a(4, "IS_API_FORMATTED");
                a(4096, "STRING_FORMATTED");
                a(8192, "GBIGINT_FORMATTED");
                a(8, "ONLY_MUTABLE_VALUES");
                a(32, "MUTABLE_REFERENCES_ARE_OWNED");
                a(64, "CONSTRUCTED");
                a(128, "TRANSFERRED");
                a(256, "HAS_SPARSE_OBJECT");
                a(512, "HAS_MESSAGE_ID");
                a(2048, "FROZEN_ARRAY");
                var d = Si(b);
                536870912 !== d && c.push("pivot: " + d);
                d = c.join(",");
                return Ri ? Ri.get.call(this) +
                    "|" + d : d
            },
            configurable: !0,
            enumerable: !1
        }
    });
    var Ni = Ji ? function(a) {
        F(a, "state is only maintained on arrays.");
        return a[Ji] | 0
    } : function(a) {
        F(a, "state is only maintained on arrays.");
        return a.sa | 0
    };

    function Ti(a, b) {
        z(b & 64, "state for messages must be constructed");
        z(0 === (b & 5), "state for messages should not contain repeated field state");
        var c = Si(b),
            d = a.length;
        z(c + (+!!(b & 512) - 1) >= d - 1, "pivot %s is pointing at an index earlier than the last index of the array, length: %s", c, d);
        b & 512 && z("string" === typeof a[0], "arrays with a message_id bit must have a string in the first position, got: %s", a[0]);
        a = d ? a[d - 1] : void 0;
        z((null != a && "object" === typeof a && a.constructor === Object) === !!(b & 256), "arraystate and array disagree on sparseObject presence")
    }
    var Ui = Ji ? function(a) {
            F(a, "state is only maintained on arrays.");
            var b = a[Ji];
            Ti(a, b);
            return b
        } : function(a) {
            F(a, "state is only maintained on arrays.");
            var b = a.sa;
            Ti(a, b);
            return b
        },
        Oi = Ji ? function(a, b) {
            F(a, "state is only maintained on arrays.");
            Ki(b);
            a[Ji] = b
        } : function(a, b) {
            F(a, "state is only maintained on arrays.");
            Ki(b);
            void 0 !== a.sa ? a.sa = b : Object.defineProperties(a, {
                sa: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };

    function Vi() {
        var a = [];
        Li(a, 1);
        return a
    }

    function Wi(a) {
        return !!(Ni(a) & 2)
    }

    function Xi(a, b) {
        Oi(b, (a | 0) & -14591)
    }

    function Yi(a, b) {
        Oi(b, (a | 34) & -14557)
    }

    function Zi(a, b) {
        bb(b);
        z(0 < b && 1023 >= b || 536870912 === b);
        return a & -16760833 | (b & 1023) << 14
    }

    function Si(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var $i, aj = {};

    function bj(a) {
        var b = a.Zh === aj;
        z(!$i || b === a instanceof $i);
        return b
    }
    var cj = {};

    function dj(a) {
        var b = !(!a || "object" !== typeof a || a.Ij !== cj);
        z(b === a instanceof Map);
        return b && 0 === gb(a, Map).size
    }

    function ej(a, b) {
        bb(a);
        z(0 < a);
        z(0 === b || -1 === b);
        return a + b
    }

    function fj(a, b) {
        bb(a);
        z(0 <= a);
        z(0 === b || -1 === b);
        return a - b
    }

    function gj(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    var hj, ij = !Eb;

    function jj(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        var d = Ni(a);
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        Oi(a, d | 1);
        return !0
    }
    var kj, lj = [];
    Oi(lj, 55);
    kj = Object.freeze(lj);

    function mj(a) {
        if (a & 2) throw Error("X");
    }

    function nj() {}
    var oj;

    function pj(a, b) {
        F(a);
        if (b) {
            oj || (oj = Symbol("unknownBinaryFields"));
            var c = a[oj];
            c ? c.push(b) : a[oj] = [b]
        }
    }

    function qj(a, b) {
        F(a);
        F(b);
        (b = oj ? F(b)[oj] : void 0) && (a[oj] = Ii(b))
    }
    var rj, sj;

    function tj() {
        return sj || (sj = Symbol("JSPB_COMPARISON_TYPE_INFO"))
    }

    function uj(a, b) {
        var c = Ni(F(a));
        b || z(!(c & 2 && c & 4 || c & 2048) || Object.isFrozen(a));
        b = !!(c & 8);
        c = !!(c & 16 && c & 32);
        if (b || c) {
            var d, e, f;
            a.forEach(function(g) {
                Array.isArray(g) ? f = !0 : g && bj(g) && (Wi(g.u) ? e = !0 : d = !0)
            });
            f && z(!e && !d);
            c && z(!f && !d);
            b && z(!f && !e)
        }
        vj(a)
    }

    function vj(a) {
        var b = Ni(a),
            c = b & 4,
            d = (4096 & b ? 1 : 0) + (8192 & b ? 1 : 0);
        z(c && 1 >= d || !c && 0 === d, "Expected at most 1 type-specific formatting bit, but got " + d + " with state: " + b);
        if (4096 & Ni(a))
            for (b = 0; b < a.length; b++) "string" !== typeof a[b] && ab("Unexpected element of type " + typeof a[b] + " in string formatted repeated 64-bit int field")
    };
    var wj = "function" === typeof Uint8Array.prototype.slice,
        xj = 0,
        yj = 0;

    function zj(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = t(Aj(c, a)), b = c.next().value, a = c.next().value, c = b);
        xj = c >>> 0;
        yj = a >>> 0
    }

    function Bj() {
        var a = xj,
            b = yj;
        b >>>= 0;
        a >>>= 0;
        if (2097151 >= b) var c = "" + (4294967296 * b + a);
        else "function" === typeof BigInt ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + 6777216 * c + 6710656 * b, c += 8147497 * b, b *= 2, 1E7 <= a && (c += Math.floor(a / 1E7), a %= 1E7), 1E7 <= c && (b += Math.floor(c / 1E7), c %= 1E7), z(b), c = b + Cj(c) + Cj(a));
        return c
    }

    function Cj(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function Aj(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };

    function Dj(a) {
        a = Error(a);
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = "warning";
        return a
    };

    function Ej(a) {
        return a.displayName || a.name || "unknown type name"
    }

    function Fj(a) {
        if ("boolean" !== typeof a) throw Error("Y`" + La(a) + "`" + a);
        return a
    }

    function Gj(a) {
        if (null == a || "boolean" === typeof a) return a;
        if ("number" === typeof a) return !!a
    }
    var Hj = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Ij(a) {
        var b = typeof a;
        return "number" === b ? Number.isFinite(a) : "string" !== b ? !1 : Hj.test(a)
    }

    function Jj(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0
    }

    function Kj(a) {
        return "Expected uint32 as finite number but got " + La(a) + ": " + a
    }

    function Lj(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a >>> 0 : void 0
    }

    function Mj(a) {
        return "-" === a[0] ? !1 : 20 > a.length ? !0 : 20 === a.length && 184467 > Number(a.substring(0, 6))
    }

    function Nj(a) {
        z(0 > a || !(0 < a && a < Number.MAX_SAFE_INTEGER));
        z(Number.isInteger(a));
        if (0 > a) {
            zj(a);
            var b = Bj();
            a = Number(b);
            return Number.isSafeInteger(a) ? a : b
        }
        if (Mj(String(a))) return a;
        zj(a);
        return 4294967296 * yj + (xj >>> 0)
    }

    function Oj(a) {
        if (null == a) return a;
        if (Ij(a)) {
            if ("string" === typeof a) {
                z(Ij(a));
                var b = Math.trunc(Number(a));
                if (Number.isSafeInteger(b) && 0 <= b) a = String(b);
                else if (b = a.indexOf("."), -1 !== b && (a = a.substring(0, b)), z(-1 === a.indexOf(".")), !Mj(a)) {
                    z(0 < a.length);
                    if (16 > a.length) zj(Number(a));
                    else if ("function" === typeof BigInt) a = BigInt(a), xj = Number(a & BigInt(4294967295)) >>> 0, yj = Number(a >> BigInt(32) & BigInt(4294967295));
                    else {
                        z(0 < a.length);
                        b = +("-" === a[0]);
                        yj = xj = 0;
                        for (var c = a.length, d = 0 + b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d =
                            Number(a.slice(d, e)), yj *= 1E6, xj = 1E6 * xj + d, 4294967296 <= xj && (yj += Math.trunc(xj / 4294967296), yj >>>= 0, xj >>>= 0);
                        b && (b = t(Aj(xj, yj)), a = b.next().value, b = b.next().value, xj = a, yj = b)
                    }
                    a = Bj()
                }
                return a
            }
            if ("number" === typeof a) return z(Ij(a)), a = Math.trunc(a), a = 0 <= a && Number.isSafeInteger(a) ? a : Nj(a), a
        }
    }

    function Pj(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function Qj(a, b, c) {
        if (null != a && "object" === typeof a && bj(a)) return a;
        if (Array.isArray(a)) {
            var d = Ni(a),
                e = d;
            0 === e && (e |= c & 32);
            e |= c & 2;
            e !== d && Oi(a, e);
            return new b(a)
        }
    }
    var Rj = "function" === typeof Symbol && "symbol" === typeof Symbol() ? Symbol("defaultInstance") : "0di";
    var Sj = function() {
        throw Error("aa");
    };
    if ("undefined" != typeof Symbol && "undefined" != typeof Symbol.hasInstance) {
        var Tj = function() {
                throw Error("ba");
            },
            Uj = {};
        Object.defineProperties(Sj, (Uj[Symbol.hasInstance] = {
            value: Tj,
            configurable: !1,
            writable: !1,
            enumerable: !1
        }, Uj));
        z(Sj[Symbol.hasInstance] === Tj, "defineProperties did not work: was it monkey-patched?")
    };
    var Vj;

    function Wj(a, b) {
        z(!!(Ni(b) & 32));
        Vj = b;
        a = new a(b);
        Vj = void 0;
        return a
    }
    var Xj, Yj;

    function Zj(a) {
        switch (typeof a) {
            case "boolean":
                return Xj || (Xj = [0, void 0, !0]);
            case "number":
                return 0 < a ? void 0 : 0 === a ? Yj || (Yj = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return F(a), z(2 === a.length || 3 === a.length && !0 === a[2]), z(null == a[0] || "number" === typeof a[0] && 0 <= a[0]), z(null == a[1] || "string" === typeof a[1]), a
        }
    }

    function ak(a, b) {
        F(b);
        return bk(a, b[0], b[1])
    }

    function bk(a, b, c) {
        null == a && (a = Vj);
        Vj = void 0;
        if (null != a)
            for (var d = 0; d < a.length; d++) {
                var e = a[d];
                Array.isArray(e) && uj(e)
            }
        if (null == a) d = 96, c ? (a = [c], d |= 512) : a = [], b && (d = Zi(d, b));
        else {
            if (!Array.isArray(a)) throw Error("ca`" + JSON.stringify(a) + "`" + La(a));
            if (Object.isFrozen(a) || !Object.isExtensible(a) || Object.isSealed(a)) throw Error("da");
            d = Ni(a);
            if (d & 64) return Ti(a, d), sj && delete a[sj], a;
            d |= 64;
            if (c && (d |= 512, c !== a[0])) throw Error("ea`" + c + "`" + JSON.stringify(a[0]) + "`" + La(a[0]));
            a: {
                c = d;
                if (d = a.length)
                    if (e = d - 1, gj(a[e])) {
                        c |=
                            256;
                        b = fj(e, +!!(c & 512) - 1);
                        if (1024 <= b) throw Error("fa`" + b);
                        d = Zi(c, b);
                        break a
                    }
                if (b) {
                    b = Math.max(b, fj(d, +!!(c & 512) - 1));
                    if (1024 < b) throw Error("ga`" + d);
                    d = Zi(c, b)
                } else d = c
            }
        }
        Oi(a, d);
        z(d & 64);
        return a
    };

    function ck(a, b) {
        return dk(b)
    }

    function dk(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return ij || !jj(a, void 0, 9999) ? a : void 0;
                    if (wi && null != a && a instanceof Uint8Array) return yi(a);
                    if (a instanceof Hi) {
                        var b = a.Fc;
                        return null == b ? "" : "string" === typeof b ? b : a.Fc = yi(b)
                    }
                }
        }
        return a
    };

    function ek(a, b, c) {
        var d = Ii(a),
            e = d.length,
            f = b & 256 ? d[e - 1] : void 0;
        e += f ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < e; b++) d[b] = c(d[b]);
        if (f) {
            b = d[b] = {};
            for (var g in f) z(!isNaN(g), "should not have non-numeric keys in sparse objects after a constructor is called."), b[g] = c(f[g])
        }
        qj(d, a);
        return d
    }

    function fk(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && Ni(a) & 1 ? void 0 : f && Ni(a) & 2 ? a : gk(a, b, c, void 0 !== d, e, f);
            else if (gj(a)) {
                var g = {},
                    k;
                for (k in a) g[k] = fk(a[k], b, c, d, e, f);
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function gk(a, b, c, d, e, f) {
        var g = d || c ? Ni(a) : 0;
        d = d ? !!(g & 32) : void 0;
        for (var k = Ii(a), h = 0; h < k.length; h++) k[h] = fk(k[h], b, c, d, e, f);
        c && (qj(k, a), c(g, k));
        return k
    }

    function hk(a) {
        return bj(a) ? a.toJSON() : dk(a)
    };

    function ik(a, b, c) {
        c = void 0 === c ? Yi : c;
        if (null != a) {
            if (wi && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = Ni(a);
                if (d & 2) return a;
                uj(a);
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (Oi(a, (d | 34) & -12293), a) : gk(a, ik, d & 4 ? Yi : c, !0, !1, !0)
            }
            bj(a) && (z(bj(a)), c = a.u, d = Ui(c), a = d & 2 ? a : Wj(a.constructor, jk(c, d, !0)));
            return a
        }
    }

    function jk(a, b, c) {
        var d = c || b & 2 ? Yi : Xi,
            e = !!(b & 32);
        a = ek(a, b, function(f) {
            return ik(f, e, d)
        });
        Li(a, 32 | (c ? 2 : 0));
        return a
    }

    function kk(a) {
        var b = a.u,
            c = Ui(b);
        return c & 2 ? Wj(a.constructor, jk(b, c, !1)) : a
    };
    var lk = Object.freeze({});
    Object.freeze({});
    var nk = function(a, b) {
            a = a.u;
            return mk(a, Ui(a), b)
        },
        mk = function(a, b, c, d) {
            if (-1 === c) return null;
            if (c >= Si(b)) {
                if (b & 256) return a[a.length - 1][c]
            } else {
                var e = a.length;
                if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
                b = ej(c, +!!(b & 512) - 1);
                if (b < e) return a[b]
            }
        },
        pk = function(a, b, c) {
            var d = a.u,
                e = Ui(d);
            mj(e);
            ok(d, e, b, c);
            return a
        };

    function ok(a, b, c, d) {
        z(!gj(d), "Invalid object passed to a setter");
        var e = Si(b);
        if (c >= e) {
            z(536870912 !== e);
            var f = b;
            if (b & 256) e = a[a.length - 1];
            else {
                if (null == d) return;
                e = ej(e, +!!(b & 512) - 1);
                z(e >= a.length && Number.isInteger(e) && 4294967295 > e, "Expected sparseObjectIndex (%s) to be >= %s and a valid array index", e, a.length);
                e = a[e] = {};
                f |= 256
            }
            e[c] = d;
            f !== b && Oi(a, f)
        } else a[ej(c, +!!(b & 512) - 1)] = d, b & 256 && (a = a[a.length - 1], c in a && delete a[c])
    }
    var rk = function(a, b, c, d) {
        return void 0 !== qk(a, b, c, void 0 === d ? !1 : d)
    };

    function sk(a, b) {
        if (!a) return a;
        z(Wi(b) ? Wi(a.u) : !0);
        return a
    }

    function tk(a, b, c, d) {
        c = void 0 === c ? !1 : c;
        d = void 0 === d ? !1 : d;
        uj(a, c);
        c || (d || z(Object.isFrozen(a) || !(Ni(a) & 32)), z(Wi(b) ? Object.isFrozen(a) : !0));
        return a
    }

    function uk(a, b, c, d, e) {
        z((d & 3) === d);
        var f = b & 2;
        e = mk(a, b, c, e);
        Array.isArray(e) || (e = kj);
        var g = !(d & 2);
        d = !(d & 1);
        var k = !!(b & 32),
            h = Ni(e);
        0 !== h || !k || f || g ? h & 1 || (h |= 1, Oi(e, h)) : (h |= 33, Oi(e, h));
        f ? (a = !1, h & 2 || (Li(e, 34), a = !!(4 & h)), (d || a) && Object.freeze(e)) : (f = !!(2 & h) || !!(2048 & h), d && f ? (e = Ii(e), f = 1, k && !g && (f |= 32), Oi(e, f), ok(a, b, c, e)) : g && h & 32 && !f && Pi(e, 32));
        return e
    }
    var vk = function(a, b) {
            var c = void 0 === c ? !1 : c;
            return tk(uk(a, Ui(a), b, 2, c), a, !1, !0)
        },
        wk = function(a, b, c, d) {
            var e = Ui(a);
            mj(e);
            d = mk(a, e, c, d);
            if (null != d && bj(d)) return b = kk(d), b !== d && ok(a, e, c, b), b.u;
            if (Array.isArray(d)) {
                var f = Ni(d);
                f = f & 2 ? jk(d, f, !1) : d;
                f = ak(f, b)
            } else f = ak(void 0, b);
            f !== d && ok(a, e, c, f);
            return f
        },
        qk = function(a, b, c, d) {
            a = a.u;
            var e = Ui(a);
            d = mk(a, e, c, d);
            b = Qj(d, b, e);
            b !== d && null != b && ok(a, e, c, b);
            return sk(b, a)
        },
        yk = function(a) {
            var b = xk;
            (a = qk(a, b, 2, !1)) ? b = a: (a = b[Rj]) ? b = a : (a = new b, Li(a.u, 34), b = b[Rj] = a);
            return b
        },
        zk = function(a, b, c) {
            b = qk(a, b, c, !1);
            if (null == b) return b;
            a = a.u;
            var d = Ui(a);
            if (!(d & 2)) {
                var e = kk(b);
                e !== b && (b = e, ok(a, d, c, b))
            }
            return sk(b, a)
        },
        Bk = function(a) {
            var b = Ak;
            a = a.u;
            var c = Ui(a);
            var d = !!d;
            var e = !!(2 & c) && !1;
            z(!e, "returnType must be FROZEN for immutable messages");
            z(!0);
            var f = uk(a, c, 10, 3);
            c = Ui(a);
            var g = Ni(f),
                k = !!(2 & g),
                h = !!(4 & g),
                l = !!(32 & g),
                m = k && h || !!(2048 & g);
            if (!h) {
                var r;
                (r = !!(2 & g)) && (c = Qi(c, 2, !0));
                for (var q = !r, v = !0, w = 0, A = 0; w < f.length; w++) {
                    var D = Qj(f[w], b, c);
                    if (D instanceof b) {
                        if (!r) {
                            var C = Wi(D.u);
                            q &&
                                (q = !C);
                            v && (v = C)
                        }
                        f[A++] = D
                    }
                }
                A < w && (f.length = A);
                g = Qi(g, 4, !0);
                g = Qi(g, 16, v);
                g = Qi(g, 8, q);
                Oi(f, g);
                k && !e && (Object.freeze(f), m = !0)
            }
            b = g;
            z(!m || g === b);
            m || (g = Qi(g, !f.length || 16 & g && (!h || l) ? 2 : 2048, !0), g !== b && Oi(f, g), Object.freeze(f));
            if (!d) {
                d = !1;
                d = void 0 === d ? !1 : d;
                b = Wi(a);
                h = Wi(f);
                l = Object.isFrozen(f) && h;
                tk(f, a, d);
                if (b || h) d ? z(h) : z(l);
                z(!!(Ni(f) & 4));
                if (h && f.length)
                    for (d = 0; 1 > d; d++) sk(f[d], a)
            }
            return f
        };

    function Ck(a, b) {
        return null != a ? a : b
    }
    var Dk = function(a, b, c) {
            c = void 0 === c ? !1 : c;
            return Ck(Gj(nk(a, b)), c)
        },
        Ek = function(a, b) {
            var c = void 0 === c ? 0 : c;
            return Ck(Jj(nk(a, b)), c)
        },
        Fk = function(a) {
            var b = void 0 === b ? "" : b;
            return Ck(Pj(nk(a, 2)), b)
        },
        Gk = function(a, b) {
            a = Pj(nk(a, b));
            return null == a ? void 0 : a
        },
        Hk = function(a, b) {
            if (null != b) {
                if ("number" !== typeof b) throw Dj(Kj(b));
                if (!Number.isFinite(b)) throw Dj(Kj(b));
                b >>>= 0
            }
            pk(a, 1, b)
        },
        Ik = function(a, b, c) {
            if (null != c && "string" !== typeof c) throw Error("Z`" + c + "`" + La(c));
            return pk(a, b, c)
        };
    if ("undefined" !== typeof Proxy) {
        var Kk = Jk;
        new Proxy({}, {
            getPrototypeOf: Kk,
            setPrototypeOf: Kk,
            isExtensible: Kk,
            preventExtensions: Kk,
            getOwnPropertyDescriptor: Kk,
            defineProperty: Kk,
            has: Kk,
            get: Kk,
            set: Kk,
            deleteProperty: Kk,
            apply: Kk,
            construct: Kk
        })
    }

    function Jk() {
        throw Error("ha");
        throw Error();
    };
    var Lk = function(a, b, c) {
        gb(this, Lk, "The message constructor should only be used by subclasses");
        z(this.constructor !== Lk, "Message is an abstract class and cannot be directly constructed");
        this.u = bk(a, b, c);
        this.preventPassingToStructuredClone = nj
    };
    n = Lk.prototype;
    n.toJSON = function() {
        if (hj) var a = Mk(this, this.u, !1);
        else a = this.u, F(a), a = gk(a, hk, void 0, void 0, !1, !1), a = Mk(this, a, !0);
        return a
    };
    n.eb = function() {
        hj = !0;
        try {
            return JSON.stringify(this.toJSON(), ck)
        } finally {
            hj = !1
        }
    };
    n.getExtension = function(a) {
        gb(this, a.qh);
        var b = gb(this, Lk);
        b = a.cc ? a.bd(b, a.cc, a.fc, !0, void 0 !== lk ? 1 : 2) : a.Wf ? a.bd(b, a.fc, !0, void 0 !== lk ? 1 : 2) : a.bd(b, a.fc, a.defaultValue, !0);
        return a.Hj && null == b ? a.defaultValue : b
    };
    n.hasExtension = function(a) {
        z(!a.Wf, "repeated extensions don't support hasExtension");
        if (a.cc) a = rk(this, a.cc, a.fc, !0);
        else {
            z(!a.Wf, "repeated extensions don't support getExtensionOrUndefined");
            gb(this, a.qh);
            var b = gb(this, Lk);
            a = a.cc ? a.bd(b, a.cc, a.fc, !0) : a.bd(b, a.fc, null, !0);
            a = void 0 !== (null === a ? void 0 : a)
        }
        return a
    };
    n.clone = function() {
        var a = gb(this, Lk);
        z(bj(a));
        var b = a.u,
            c = Ui(b);
        return Wj(a.constructor, jk(b, c, !1))
    };
    n.nb = function() {
        return Wi(this.u)
    };
    $i = Lk;
    Lk.prototype.Zh = aj;
    Lk.prototype.toString = function() {
        return Mk(this, this.u, !1).toString()
    };

    function Mk(a, b, c) {
        var d = a.constructor.kg,
            e = Ui(c ? a.u : b),
            f = Si(e),
            g = !1;
        if (d && ij) {
            if (!c) {
                b = Ii(b);
                var k;
                if (b.length && gj(k = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            Object.assign(b[b.length - 1] = {}, k);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            k = Ui(a.u);
            a = Si(k);
            k = +!!(k & 512) - 1;
            for (var h, l, m = 0; m < d.length; m++)
                if (l = d[m], l < a) {
                    l = ej(l, k);
                    var r = f[l];
                    null == r ? f[l] = c ? kj : Vi() : c && r !== kj && Mi(r)
                } else h || (r = void 0, f.length && gj(r = f[f.length - 1]) ? h = r : f.push(h = {})), r = h[l], null == h[l] ? h[l] = c ? kj : Vi() : c && r !== kj && Mi(r)
        }
        h = b.length;
        if (!h) return b;
        var q;
        if (gj(f = b[h - 1])) {
            a: {
                var v = f;c = {};a = !1;
                for (var w in v) {
                    k = v[w];
                    if (Array.isArray(k)) {
                        m = k;
                        if (jj(k, d, +w) || dj(k)) k = null;
                        k != m && (a = !0)
                    }
                    null != k ? c[w] = k : a = !0
                }
                if (a) {
                    for (var A in c) {
                        v = c;
                        break a
                    }
                    v = null
                }
            }
            v != f && (q = !0);h--
        }
        for (e = +!!(e & 512) - 1; 0 < h; h--) {
            w = h - 1;
            f = b[w];
            if (null != f && !jj(f, d, w - e) && !dj(f)) break;
            var D = !0
        }
        if (!q && !D) return b;
        b = g ? b : Array.prototype.slice.call(b, 0, h);
        g && (b.length = h);
        v && b.push(v);
        return b
    };

    function Nk(a) {
        if ("string" === typeof a) return {
            buffer: Ci(a),
            nb: !1
        };
        if (Array.isArray(a)) return {
            buffer: new Uint8Array(a),
            nb: !1
        };
        if (a.constructor === Uint8Array) return {
            buffer: a,
            nb: !1
        };
        if (a.constructor === ArrayBuffer) return {
            buffer: new Uint8Array(a),
            nb: !1
        };
        if (a.constructor === Hi) {
            gb(a, Hi);
            if (Ei !== Ei) throw Error("V");
            var b = a.Fc;
            null == b || wi && null != b && b instanceof Uint8Array || ("string" === typeof b ? b = Ci(b) : (ab("Cannot coerce to Uint8Array: " + La(b)), b = null));
            return {
                buffer: (null == b ? b : a.Fc = b) || Di || (Di = new Uint8Array(0)),
                nb: !0
            }
        }
        if (a instanceof Uint8Array) return {
            buffer: new Uint8Array(a.buffer, a.byteOffset, a.byteLength),
            nb: !1
        };
        throw Error("ja");
    };
    var Pk = function(a, b) {
            this.za = null;
            this.Sd = !1;
            this.I = this.Aa = this.fb = 0;
            Ok(this, a, b)
        },
        Ok = function(a, b, c) {
            c = void 0 === c ? {} : c;
            a.Mc = void 0 === c.Mc ? !1 : c.Mc;
            b && (b = Nk(b), a.za = b.buffer, a.Sd = b.nb, a.fb = 0, a.Aa = a.za.length, a.I = a.fb)
        };
    n = Pk.prototype;
    n.Ef = function() {
        this.clear();
        100 > Qk.length && Qk.push(this)
    };
    n.clear = function() {
        this.za = null;
        this.Sd = !1;
        this.I = this.Aa = this.fb = 0;
        this.Mc = !1
    };
    n.setEnd = function(a) {
        this.Aa = a
    };
    n.reset = function() {
        this.I = this.fb
    };
    n.W = function() {
        return this.I
    };
    n.advance = function(a) {
        Rk(this, this.I + a)
    };
    var Sk = function(a) {
            var b = 0,
                c = 0,
                d = 0,
                e = a.za,
                f = a.I;
            do {
                var g = e[f++];
                b |= (g & 127) << d;
                d += 7
            } while (32 > d && g & 128);
            32 < d && (c |= (g & 127) >> 4);
            for (d = 3; 32 > d && g & 128; d += 7) g = e[f++], c |= (g & 127) << d;
            Rk(a, f);
            if (128 > g) return 4294967296 * (c >>> 0) + (b >>> 0 >>> 0);
            throw Error("qa");
        },
        Rk = function(a, b) {
            a.I = b;
            if (b > a.Aa) throw Error("ra`" + b + "`" + a.Aa);
        },
        Tk = function(a) {
            var b = a.za,
                c = a.I,
                d = b[c++],
                e = d & 127;
            if (d & 128 && (d = b[c++], e |= (d & 127) << 7, d & 128 && (d = b[c++], e |= (d & 127) << 14, d & 128 && (d = b[c++], e |= (d & 127) << 21, d & 128 && (d = b[c++], e |= d << 28, d & 128 && b[c++] & 128 &&
                    b[c++] & 128 && b[c++] & 128 && b[c++] & 128 && b[c++] & 128))))) throw Error("qa");
            Rk(a, c);
            return e
        },
        Uk = function(a) {
            return Tk(a) >>> 0
        },
        Vk = function(a) {
            return Sk(a)
        },
        Wk = function(a) {
            for (var b = 0, c = a.I, d = c + 10, e = a.za; c < d;) {
                var f = e[c++];
                b |= f;
                if (0 === (f & 128)) return Rk(a, c), !!(b & 127)
            }
            throw Error("qa");
        },
        Xk = function(a, b) {
            if (0 > b) throw Error("sa`" + b);
            var c = a.I,
                d = c + b;
            if (d > a.Aa) throw Error("ra`" + (a.Aa - c) + "`" + b);
            a.I = d;
            return c
        };
    Pk.prototype.ig = function(a, b) {
        var c = Xk(this, a),
            d = z(this.za);
        if (vi) {
            var e;
            b ? (e = ti) || (e = ti = new TextDecoder("utf-8", {
                fatal: !0
            })) : (e = ui) || (e = ui = new TextDecoder("utf-8", {
                fatal: !1
            }));
            var f = c + a;
            d = 0 === c && f === d.length ? d : d.subarray(c, f);
            try {
                var g = e.decode(d)
            } catch (m) {
                if (b) {
                    if (void 0 === si) {
                        try {
                            e.decode(new Uint8Array([128]))
                        } catch (r) {}
                        try {
                            e.decode(new Uint8Array([97])), si = !0
                        } catch (r) {
                            si = !1
                        }
                    }
                    b = !si
                }
                b && (ti = void 0);
                throw m;
            }
        } else {
            a = c + a;
            g = [];
            for (var k = null, h, l; c < a;) h = d[c++], 128 > h ? g.push(h) : 224 > h ? c >= a ? qi(b, g) : (l =
                d[c++], 194 > h || 128 !== (l & 192) ? (c--, qi(b, g)) : (h = (h & 31) << 6 | l & 63, z(128 <= h && 2047 >= h), g.push(h))) : 240 > h ? c >= a - 1 ? qi(b, g) : (l = d[c++], 128 !== (l & 192) || 224 === h && 160 > l || 237 === h && 160 <= l || 128 !== ((e = d[c++]) & 192) ? (c--, qi(b, g)) : (h = (h & 15) << 12 | (l & 63) << 6 | e & 63, z(2048 <= h && 65535 >= h), z(55296 > h || 57343 < h), g.push(h))) : 244 >= h ? c >= a - 2 ? qi(b, g) : (l = d[c++], 128 !== (l & 192) || 0 !== (h << 28) + (l - 144) >> 30 || 128 !== ((e = d[c++]) & 192) || 128 !== ((f = d[c++]) & 192) ? (c--, qi(b, g)) : (h = (h & 7) << 18 | (l & 63) << 12 | (e & 63) << 6 | f & 63, z(65536 <= h && 1114111 >= h), h -= 65536, g.push((h >>
                10 & 1023) + 55296, (h & 1023) + 56320))) : qi(b, g), 8192 <= g.length && (k = ri(k, g), g.length = 0);
            z(c === a, "expected " + c + " === " + a);
            g = ri(k, g)
        }
        return g
    };
    Pk.prototype.Ne = function(a) {
        if (0 == a) return Fi || (Fi = new Hi(null, Ei));
        var b = Xk(this, a);
        if (this.Mc && this.Sd) b = this.za.subarray(b, b + a);
        else {
            var c = z(this.za);
            a = b + a;
            b = b === a ? Di || (Di = new Uint8Array(0)) : wj ? c.slice(b, a) : new Uint8Array(c.subarray(b, a))
        }
        gb(b, Uint8Array);
        return 0 == b.length ? Fi || (Fi = new Hi(null, Ei)) : new Hi(b, Ei)
    };
    var Qk = [];
    z(!0);
    var Zk = function(a, b) {
            if (Qk.length) {
                var c = Qk.pop();
                Ok(c, a, b);
                a = c
            } else a = new Pk(a, b);
            this.l = a;
            this.La = this.l.W();
            this.m = this.Ea = this.Mb = -1;
            Yk(this, b)
        },
        Yk = function(a, b) {
            b = void 0 === b ? {} : b;
            a.fe = void 0 === b.fe ? !1 : b.fe
        };
    Zk.prototype.Ef = function() {
        this.l.clear();
        this.m = this.Mb = this.Ea = -1;
        100 > $k.length && $k.push(this)
    };
    Zk.prototype.W = function() {
        return this.l.W()
    };
    Zk.prototype.reset = function() {
        this.l.reset();
        this.La = this.l.W();
        this.m = this.Mb = this.Ea = -1
    };
    Zk.prototype.advance = function(a) {
        this.l.advance(a)
    };
    var al = function(a) {
            var b = a.l;
            if (b.I == b.Aa) return !1; - 1 !== a.Ea && (b = a.l.W(), a.l.I = a.La, Uk(a.l), 4 === a.m || 3 === a.m ? z(b === a.l.W(), "Expected to not advance the cursor.  Group tags do not have values.") : z(b > a.l.W(), "Expected to read the field, did you forget to call a read or skip method?"), a.l.I = b);
            a.La = a.l.W();
            b = Uk(a.l);
            var c = b >>> 3,
                d = b & 7;
            if (!(0 <= d && 5 >= d)) throw Error("la`" + d + "`" + a.La);
            if (1 > c) throw Error("ma`" + c + "`" + a.La);
            a.Ea = b;
            a.Mb = c;
            a.m = d;
            return !0
        },
        cl = function(a) {
            if (2 != a.m) ab("Invalid wire type for skipDelimitedField"),
                bl(a);
            else {
                var b = Uk(a.l);
                a.l.advance(b)
            }
        },
        bl = function(a) {
            switch (a.m) {
                case 0:
                    0 != a.m ? (ab("Invalid wire type for skipVarintField"), bl(a)) : Wk(a.l);
                    break;
                case 1:
                    z(1 === a.m);
                    a.l.advance(8);
                    break;
                case 2:
                    cl(a);
                    break;
                case 5:
                    z(5 === a.m);
                    a.l.advance(4);
                    break;
                case 3:
                    var b = a.Mb;
                    do {
                        if (!al(a)) throw Error("oa");
                        if (4 == a.m) {
                            if (a.Mb != b) throw Error("pa");
                            break
                        }
                        bl(a)
                    } while (1);
                    break;
                default:
                    throw Error("la`" + a.m + "`" + a.La);
            }
        },
        el = function(a) {
            var b = a.La;
            bl(a);
            return dl(a, b)
        },
        dl = function(a, b) {
            if (!a.fe) {
                var c = a.l.W();
                a.l.I = b;
                b = a.l.Ne(c - b);
                z(c == a.l.W());
                return b
            }
        },
        fl = function(a, b, c) {
            z(2 == a.m);
            var d = a.l.Aa,
                e = Uk(a.l),
                f = a.l.W() + e,
                g = f - d;
            0 >= g && (a.l.setEnd(f), c(b, a, void 0, void 0, void 0), g = f - a.l.W());
            if (g) throw Error("ka`" + e + "`" + (e - g));
            a.l.I = f;
            a.l.setEnd(d)
        },
        hl = function(a, b) {
            z(11 === a.Ea);
            for (var c = 0, d = 0; al(a) && 4 != a.m;) 16 !== a.Ea || c ? 26 !== a.Ea || d ? bl(a) : c ? (d = -1, fl(a, c, b)) : (d = a.La, cl(a)) : (c = gl(a), d && (z(0 < d), a.Ea = -1, a.m = -1, a.l.I = d, d = 0));
            if (12 !== a.Ea || !d || !c) throw Error("na");
        },
        gl = function(a) {
            z(0 == a.m);
            return Uk(a.l)
        },
        il = function(a) {
            z(0 ==
                a.m);
            return Sk(a.l)
        };
    Zk.prototype.ig = function() {
        return jl(this)
    };
    var jl = function(a) {
        z(2 == a.m);
        var b = Uk(a.l);
        return a.l.ig(b, !0)
    };
    Zk.prototype.Ne = function() {
        z(2 == this.m);
        var a = Uk(this.l);
        return this.l.Ne(a)
    };
    var kl = function(a, b, c) {
            z(2 == a.m);
            var d = Uk(a.l);
            for (d = a.l.W() + d; a.l.W() < d;) c.push(b(a.l))
        },
        $k = [];
    var ll = function(a, b, c, d) {
        this.Gd = a;
        this.Fg = c;
        this.Eg = d
    };

    function ml(a) {
        return Array.isArray(a) ? a[0] instanceof ll ? (z(2 === a.length), nl(a[1]), a) : [ol, nl(a)] : [gb(a, ll), void 0]
    }
    var rl = function(a, b, c) {
            F(a);
            for (var d = c.Cf, e = {}; al(b) && 4 != b.m;)
                if (e = {
                        Dd: e.Dd
                    }, 11 === b.Ea) {
                    var f = b.La;
                    e.Dd = !1;
                    hl(b, function(g) {
                        return function(k, h) {
                            var l = c[k];
                            if (!l) {
                                var m = d[k];
                                if (m) {
                                    l = nl(m);
                                    var r = pl(l),
                                        q = ql(l).Lb;
                                    l = c[k] = function(v, w, A) {
                                        return r(wk(w, q, A, !0), v)
                                    }
                                }
                            }
                            l ? l(h, a, k) : (g.Dd = !0, h.l.I = h.l.Aa)
                        }
                    }(e));
                    e.Dd && pj(a, dl(b, f))
                } else pj(a, el(b))
        },
        tl = function(a, b) {
            return function(c, d, e) {
                return c.Zj(e, sl(d, a), b)
            }
        };

    function ul(a, b, c) {
        if (Array.isArray(b)) {
            var d = Ni(b);
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                var g = a(b[e]);
                null != g && (b[f++] = g)
            }
            f < e && (b.length = f);
            c && (Oi(b, (d | 5) & -12289), d & 2 && Object.freeze(b));
            return b
        }
    }

    function sl(a, b) {
        return a instanceof Lk ? a.u : Array.isArray(a) ? ak(a, b) : void 0
    }
    var vl = Symbol("deserializeBinaryFromReaderCache");

    function pl(a) {
        var b = a[vl];
        if (!b) {
            var c = wl(a),
                d = ql(a),
                e = d.xf;
            b = e ? function(f, g) {
                return e(f, g, d)
            } : function(f, g) {
                for (; al(g) && 4 != g.m;) {
                    var k = g.Mb,
                        h = d[k];
                    if (!h) {
                        var l = d.Cf;
                        l && (l = l[k]) && (h = d[k] = xl(l))
                    }
                    h && h(g, f, k) || pj(f, el(g))
                }
                c === yl || c === zl || c.fg || (f[tj()] = c)
            };
            a[vl] = b
        }
        return b
    }

    function xl(a) {
        a = ml(a);
        var b = gb(a[0], ll).Gd;
        if (a = a[1]) {
            nl(a);
            var c = pl(a),
                d = ql(z(a)).Lb;
            return function(e, f, g) {
                return b(e, f, g, d, c)
            }
        }
        return b
    }
    var yl, zl, Al = Symbol("comparisonTypeInfoCache");

    function Bl(a, b, c) {
        var d = c[1];
        if (d) {
            var e = d[Al];
            var f = e ? e.Lb : z(Zj(d[0]));
            a[b] = null != e ? e : d
        }
        f && f === Xj ? F(a.nd || (a.nd = [])).push(b) : c[0] && F(a.td || (a.td = [])).push(b)
    }

    function Cl(a, b) {
        return [a.Fg, !b || 0 < b[0] ? void 0 : b]
    }

    function wl(a) {
        var b = a[Al];
        if (b) return b;
        b = Dl(a, a[Al] = {}, Cl, Cl, Bl);
        if (!b.td && !b.nd) {
            var c = !0,
                d;
            for (d in b) {
                isNaN(d) || (c = !1);
                break
            }
            c ? (b = z(Zj(a[0])) === Xj, b = a[Al] = b ? zl || (zl = {
                Lb: z(Zj(!0))
            }) : yl || (yl = {})) : b.fg = !0
        }
        return b
    }

    function El(a, b, c, d) {
        var e;
        (e = b[a]) ? Array.isArray(e) && (b[a] = e = wl(e)): e = void 0;
        if (e) {
            var f = b.td;
            (f = (f ? Array.isArray(f) ? b.td = new Set(f) : f : rj || (rj = new Set)).has(a)) || (f = b.nd, f = (f ? Array.isArray(f) ? b.nd = new Set(f) : f : rj || (rj = new Set)).has(a));
            if (f) {
                if (Array.isArray(c))
                    for (f = 0; f < c.length; f++) {
                        var g = c[f];
                        d = !1;
                        if (g instanceof Lk) d = !0, g = g.u;
                        else if (!Array.isArray(g)) throw Error("ta`" + g + "`" + a + "`" + JSON.stringify(b));
                        Fl(g, e, d)
                    }
            } else {
                if (c instanceof Lk) d = !0, c = c.u;
                else if (!Array.isArray(c)) throw Error("ua");
                Fl(c,
                    e, d)
            }
        }
    }

    function Fl(a, b, c) {
        F(a);
        if (b !== yl && b !== zl) {
            b.fg || (a[tj()] = b);
            var d = a.length;
            var e = z(b.Lb);
            F(e);
            e = e[1] ? 0 : -1;
            for (var f = 0; f < a.length; f++) {
                var g = a[f];
                if (g && "object" === typeof g)
                    if (f === d - 1 && gj(g))
                        for (var k in g) {
                            var h = +k;
                            if (Number.isNaN(h)) {
                                var l = g[k];
                                l && "object" === typeof l && El(h, b, l, c)
                            }
                        } else h = fj(f, e), El(h, b, g, c)
            }
        }
    }
    var Gl = Symbol("makeCrossSerializerComparisonsCompatible");

    function Hl(a) {
        var b = a[Gl];
        if (!b) {
            var c = wl(a);
            b = function(d) {
                return Fl(d, c, !0)
            };
            a[Gl] = b
        }
        return b
    }

    function nl(a) {
        F(a);
        var b;
        if (!(b = Il in a || Jl in a) && (b = 0 < a.length)) {
            b = a[0];
            var c = Zj(b);
            null != c && c !== b && (a[0] = c);
            b = null != c
        }
        z(b);
        return a
    }

    function Kl(a, b, c) {
        a[b] = c
    }

    function Dl(a, b, c, d, e) {
        e = void 0 === e ? Kl : e;
        b.Lb = z(Zj(a[0]));
        var f = 0,
            g = a[++f];
        g && g.constructor === Object && (b.Cf = g, g = a[++f], "function" === typeof g && (b.xf = g, b.Th = db(a[++f]), z(b.xf === rl), z(b.Th === tl), g = a[++f]));
        for (var k = {}; Array.isArray(g) && "number" === typeof g[0] && 0 < g[0];) {
            for (var h = 0; h < g.length; h++) k[g[h]] = g;
            g = a[++f]
        }
        for (h = 1; void 0 !== g;) {
            "number" === typeof g && (z(0 < g), h += g, g = a[++f]);
            var l = void 0;
            if (g instanceof ll) var m = g;
            else m = Ll, f--;
            if (m.Eg) {
                g = a[++f];
                l = a;
                var r = f;
                "function" == typeof g && (z(0 === g.length),
                    g = g(), l[r] = g);
                nl(g);
                l = g
            }
            g = a[++f];
            r = h + 1;
            "number" === typeof g && 0 > g && (r -= g, g = a[++f]);
            for (; h < r; h++) {
                var q = k[h];
                e(b, h, l ? d(m, l, q) : c(m, q))
            }
        }
        return b
    }
    var Jl = Symbol("serializerFnCache"),
        Il = Symbol("deserializerFnCache");

    function Ml(a, b) {
        var c = a.Gd;
        return b ? function(d, e, f) {
            return c(d, e, f, b)
        } : c
    }

    function Nl(a, b, c) {
        var d = a.Gd,
            e, f;
        return function(g, k, h) {
            return d(g, k, h, f || (f = ql(b).Lb), e || (e = pl(b)), c)
        }
    }

    function ql(a) {
        var b = a[Il];
        if (b) return b;
        wl(a);
        b = Dl(a, a[Il] = {}, Ml, Nl);
        Il in a && Jl in a && (a.length = 0);
        return b
    }

    function Ol(a, b) {
        return new ll(a, b, !1, !1)
    }

    function Pl(a, b, c) {
        ok(a, Ui(a), b, c)
    }

    function Ql(a, b, c, d, e) {
        a.Yj(c, sl(b, d), e)
    }
    var Rl = Ol(function(a, b, c) {
            if (5 !== a.m) return !1;
            z(5 == a.m);
            a = a.l;
            var d = a.za,
                e = a.I,
                f = d[e + 0];
            var g = d[e + 1];
            var k = d[e + 2];
            d = d[e + 3];
            a.advance(4);
            g = (f << 0 | g << 8 | k << 16 | d << 24) >>> 0;
            a = 2 * (g >> 31) + 1;
            f = g >>> 23 & 255;
            g &= 8388607;
            Pl(b, c, 255 == f ? g ? NaN : Infinity * a : 0 == f ? a * Math.pow(2, -149) * g : a * Math.pow(2, f - 150) * (g + Math.pow(2, 23)));
            return !0
        }, function(a, b, c) {
            b = null == b ? b : "number" === typeof b || "NaN" === b || "Infinity" === b || "-Infinity" === b ? Number(b) : void 0;
            a.Wj(c, b)
        }),
        Sl = Ol(function(a, b, c) {
            if (0 !== a.m) return !1;
            Pl(b, c, il(a));
            return !0
        }, function(a,
            b, c) {
            a.ek(c, Oj(b))
        }),
        Tl;
    Tl = new ll(function(a, b, c) {
        if (0 !== a.m && 2 !== a.m) return !1;
        b = vk(b, c);
        2 == a.m ? kl(a, Vk, b) : b.push(il(a));
        return !0
    }, function(a, b, c) {
        a.bk(c, ul(Oj, b, !1))
    }, !0, !1);
    var Ul = Ol(function(a, b, c) {
            if (0 !== a.m) return !1;
            z(0 == a.m);
            a = Tk(a.l);
            Pl(b, c, a);
            return !0
        }, function(a, b, c) {
            a.Xj(c, Jj(b))
        }),
        Xl = Ol(function(a, b, c) {
            if (0 !== a.m) return !1;
            z(0 == a.m);
            a = Wk(a.l);
            Pl(b, c, a);
            return !0
        }, function(a, b, c) {
            a.Uj(c, Gj(b))
        }),
        Yl = Ol(function(a, b, c) {
            if (2 !== a.m) return !1;
            Pl(b, c, jl(a));
            return !0
        }, function(a, b, c) {
            a.ck(c, Pj(b))
        }),
        ol = new ll(function(a, b, c, d, e) {
            if (2 !== a.m) return !1;
            fl(a, wk(b, d, c, !0), e);
            return !0
        }, Ql, !1, !0),
        Ll = new ll(function(a, b, c, d, e) {
            if (2 !== a.m) return !1;
            fl(a, wk(b, d, c), e);
            return !0
        }, Ql, !1, !0),
        Zl;
    Zl = new ll(function(a, b, c, d, e) {
        if (2 !== a.m) return !1;
        d = ak(void 0, d);
        var f = Ui(b);
        mj(f);
        var g = uk(b, f, c, 3);
        f = Ui(b);
        if (Ni(g) & 4) {
            g = Ii(g);
            var k = Ni(g);
            Oi(g, (k | 1) & -2079);
            ok(b, f, c, g)
        }
        g.push(d);
        fl(a, d, e);
        return !0
    }, function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++) Ql(a, b[f], c, d, e)
    }, !0, !0);
    var $l = Ol(function(a, b, c) {
            if (0 !== a.m) return !1;
            Pl(b, c, gl(a));
            return !0
        }, function(a, b, c) {
            a.dk(c, Lj(b))
        }),
        am;
    am = new ll(function(a, b, c) {
        if (0 !== a.m && 2 !== a.m) return !1;
        b = vk(b, c);
        2 == a.m ? kl(a, Uk, b) : b.push(gl(a));
        return !0
    }, function(a, b, c) {
        a.ak(c, ul(Lj, b, !0))
    }, !0, !1);
    var bm = Ol(function(a, b, c) {
        if (0 !== a.m) return !1;
        z(0 == a.m);
        a = Tk(a.l);
        Pl(b, c, a);
        return !0
    }, function(a, b, c) {
        a.Vj(c, Jj(b))
    });

    function cm(a) {
        if (a instanceof Lk) return a.constructor.Ca
    };

    function dm(a, b) {
        b = void 0 === b ? new Set : b;
        if (b.has(a)) return "(Recursive reference)";
        switch (typeof a) {
            case "object":
                if (a) {
                    var c = Object.getPrototypeOf(a);
                    switch (c) {
                        case Map.prototype:
                        case Set.prototype:
                        case Array.prototype:
                            b.add(a);
                            var d = "[" + Array.from(a, function(e) {
                                return dm(e, b)
                            }).join(", ") + "]";
                            b.delete(a);
                            c !== Array.prototype && (d = em(c.constructor) + "(" + d + ")");
                            return d;
                        case Object.prototype:
                            return b.add(a), c = "{" + Object.entries(a).map(function(e) {
                                var f = t(e);
                                e = f.next().value;
                                f = f.next().value;
                                return e +
                                    ": " + dm(f, b)
                            }).join(", ") + "}", b.delete(a), c;
                        default:
                            return d = "Object", c && c.constructor && (d = em(c.constructor)), "function" === typeof a.toString && a.toString !== Object.prototype.toString ? d + "(" + String(a) + ")" : "(object " + d + ")"
                    }
                }
                break;
            case "function":
                return "function " + em(a);
            case "number":
                if (!Number.isFinite(a)) return String(a);
                break;
            case "bigint":
                return a.toString(10) + "n";
            case "symbol":
                return a.toString()
        }
        return JSON.stringify(a)
    }

    function em(a) {
        var b = a.name;
        b || (b = (a = /function\s+([^\(]+)/m.exec(String(a))) ? a[1] : "(Anonymous)");
        return b
    };

    function fm(a, b) {
        a.Jf = "function" === typeof b ? b : function() {
            return b
        };
        return a
    }
    var gm = void 0;

    function hm() {
        throw Error(y.apply(0, arguments).map(function(a) {
            return "function" === typeof a ? a() : a
        }).filter(function(a) {
            return a
        }).join("\n").trim().replace(/:$/, ""));
    };
    (function() {
        var a = Ja.jspbGetTypeName;
        Ja.jspbGetTypeName = a ? function(b) {
            return a(b) || cm(b)
        } : cm
    })();
    var im = Lk;

    function jm(a, b) {
        return function(c) {
            c = gb(gb(c, a), Lk);
            Hl(b)(gb(c, Lk).u)
        }
    };
    var Ak = function(a) {
        im.call(this, a)
    };
    x(Ak, im);
    Ak.prototype.If = function() {
        return Fk(this)
    };
    Ak.Ca = "wireless.mdl.UserAgentClientHints.BrandAndVersion";
    var km = [0, Yl, -1];
    Ak.makeCrossSerializerComparisonsCompatible = jm(Ak, km);
    var lm = function(a) {
        im.call(this, a)
    };
    x(lm, im);
    var mm = function(a, b) {
            return Ik(a, 2, b)
        },
        nm = function(a, b) {
            return Ik(a, 3, b)
        },
        om = function(a, b) {
            return Ik(a, 4, b)
        },
        pm = function(a, b) {
            return Ik(a, 5, b)
        },
        qm = function(a, b) {
            return Ik(a, 9, b)
        },
        rm = function(a, b) {
            var c = Ak,
                d = a.u,
                e = Ui(d);
            mj(e);
            if (null == b) ok(d, e, 10);
            else {
                F(b);
                var f = Ni(b),
                    g = f,
                    k = !!(2 & f) || !!(2048 & f);
                z(!k || Object.isFrozen(b));
                var h = k || Object.isFrozen(b),
                    l;
                if (l = !h) l = !1;
                for (var m = !0, r = !0, q = 0; q < b.length; q++) {
                    var v = b[q],
                        w = $a(c);
                    if (!(v instanceof w)) throw Error("$`" + Ej(w) + "`" + (v && Ej(v.constructor)));
                    k || (v = Wi(v.u),
                        m && (m = !v), r && (r = v))
                }
                k || (f = Qi(f, 5, !0), f = Qi(f, 8, m), f = Qi(f, 16, r));
                if (l || h && f !== g) b = Ii(b), g = 0, c = Qi(f, 2, !!(2 & e)), c = Qi(c, 32, !!(32 & e) && !0), f = c = Qi(c, 2048, !1);
                f !== g && Oi(b, f);
                uj(b);
                ok(d, e, 10, b)
            }
            return a
        },
        sm = function(a, b) {
            return pk(a, 11, null == b ? b : Fj(b))
        },
        tm = function(a, b) {
            return Ik(a, 1, b)
        },
        um = function(a, b) {
            return pk(a, 7, null == b ? b : Fj(b))
        };
    lm.Ca = "wireless.mdl.UserAgentClientHints";
    lm.kg = [10, 6];
    lm.makeCrossSerializerComparisonsCompatible = jm(lm, [0, Yl, -4, Zl, km, Xl, bm, Yl, Zl, km, Xl]);
    var vm = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function wm(a) {
        var b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    }

    function xm(a) {
        var b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    }

    function ym(a) {
        if (!xm(a)) return null;
        var b = wm(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(vm).then(function(c) {
            null != b.uach || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function zm(a) {
        var b;
        return sm(rm(pm(mm(tm(om(um(qm(nm(new lm, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), (null == (b = a.fullVersionList) ? void 0 : b.map(function(c) {
            var d = new Ak;
            d = Ik(d, 1, c.brand);
            return Ik(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function Am(a) {
        var b, c;
        return null != (c = null == (b = ym(a)) ? void 0 : b.then(function(d) {
            return zm(d)
        })) ? c : null
    };
    var Bm = function(a, b, c, d) {
        a = void 0 === a ? window : a;
        b = void 0 === b ? null : b;
        c = void 0 === c ? new Qa : c;
        d = void 0 === d ? Ng("current") : d;
        Td.call(this);
        this.global = a;
        this.Ka = b;
        this.B = c;
        this.sg = d;
        this.li = nd(this.global, "pagehide").g(Rg(this.B, 941));
        this.eg = nd(this.global, "load").g(Rg(this.B, 738), Qe(1));
        this.mi = nd(this.global, "resize").g(Rg(this.B, 741));
        this.onMessage = nd(this.global, "message").g(Rg(this.B, 740));
        this.document = new fi(this.global, this);
        this.i = new Tg(new Wg(this.J, this.B), new Vg(this.J, this.B));
        this.H = new fe(new Bh(this),
            new Sf(this, new Xg(this)), new Sf(this, new Fh(this)), new Sf(this, new zh(this)))
    };
    x(Bm, Td);
    var Yg = function(a) {
        var b = a.global;
        return !!a.global.HTMLFencedFrameElement && !!b.fence && "function" === typeof b.fence.reportEvent
    };
    Bm.prototype.ub = function(a) {
        Yg(this) && this.global.fence.reportEvent(a)
    };
    Bm.prototype.pe = function() {
        return this.li.g(Rg(this.B, 942), Y(this.h, 1), P(function() {}))
    };
    var Cm = function(a) {
            var b = new Bm(a.global.top, a.Ka);
            b.H = a.H;
            return b
        },
        Dm = function(a, b) {
            b.start();
            return nd(b, "message").g(Rg(a.B, 740))
        };
    Bm.prototype.postMessage = function(a, b, c) {
        c = void 0 === c ? [] : c;
        this.global.postMessage(a, b, c)
    };
    Bm.prototype.qe = function() {
        return yh(this.global) ? this.global.width : 0
    };
    Bm.prototype.ne = function() {
        return yh(this.global) ? this.global.height : 0
    };
    var Em = function(a, b) {
        try {
            var c = a.global;
            try {
                b && (c = c.top);
                a = c;
                var d = wh() || xh();
                b && null !== a && a != a.top && (a = a.top);
                try {
                    if (void 0 === d ? 0 : d) var e = (new ph(a.innerWidth, a.innerHeight)).round();
                    else {
                        var f = (a || window).document,
                            g = "CSS1Compat" == f.compatMode ? f.documentElement : f.body;
                        e = (new ph(g.clientWidth, g.clientHeight)).round()
                    }
                    var k = e
                } catch (w) {
                    k = new ph(-12245933, -12245933)
                }
                b = k;
                var h = b.height,
                    l = b.width;
                if (-12245933 === l) var m = new pi(l, l, l, l);
                else {
                    var r = th(sh(c.document).Eb),
                        q = r.x,
                        v = r.y;
                    m = new pi(v, q + l, v + h, q)
                }
            } catch (w) {
                m =
                    new pi(-12245933, -12245933, -12245933, -12245933)
            }
            return {
                left: m.left,
                top: m.top,
                width: m.qe(),
                height: m.ne()
            }
        } catch (w) {
            return li
        }
    };
    Bm.prototype.validate = function() {
        var a = this.H.L() || Yg(this);
        return this.global && this.i.ha() && a
    };
    var Rh = function(a) {
        return (a = Am(a.global)) ? hd(a) : null
    };
    da.Object.defineProperties(Bm.prototype, {
        sharedStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.global.sharedStorage
            }
        },
        J: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return window
            }
        },
        Gb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !yh(this.global.top)
            }
        },
        ue: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Gb || this.global.top !== this.global
            }
        },
        scrollY: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.global.scrollY
            }
        },
        MutationObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.J.MutationObserver
            }
        },
        ResizeObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.J.ResizeObserver
            }
        },
        Nh: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                z(!0, "Major version must be an integer");
                return 8 <= Rb()
            }
        },
        Xg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "vu" in this.global || "vv" in this.global
            }
        }
    });
    var Fm = !bh && !Mb(),
        Gm = function(a, b) {
            if (/-[a-z]/.test(b)) return null;
            if (Fm && a.dataset) {
                if (Ob() && !(b in a.dataset)) return null;
                a = a.dataset[b];
                return void 0 === a ? null : a
            }
            return a.getAttribute("data-" + String(b).replace(/([A-Z])/g, "-$1").toLowerCase())
        };
    var Hm = {},
        Im = (Hm["data-google-av-cxn"] = "_avicxn_", Hm["data-google-av-cpmav"] = "_cvu_", Hm["data-google-av-metadata"] = "_avm_", Hm["data-google-av-adk"] = "_adk_", Hm["data-google-av-btr"] = void 0, Hm["data-google-av-override"] = void 0, Hm["data-google-av-dm"] = void 0, Hm["data-google-av-immediate"] = void 0, Hm["data-google-av-aid"] = void 0, Hm["data-google-av-naid"] = void 0, Hm["data-google-av-inapp"] = void 0, Hm["data-google-av-slift"] = void 0, Hm["data-google-av-itpl"] = void 0, Hm["data-google-av-ext-cxn"] = void 0, Hm["data-google-av-rs"] =
            void 0, Hm["data-google-av-flags"] = void 0, Hm["data-google-av-turtlex"] = void 0, Hm["data-google-av-ufs-integrator-metadata"] = void 0, Hm["data-google-av-vattr"] = void 0, Hm["data-google-av-vrus"] = void 0, Hm),
        Jm = {},
        Km = (Jm["data-google-av-adk"] = "googleAvAdk", Jm["data-google-av-btr"] = "googleAvBtr", Jm["data-google-av-cpmav"] = "googleAvCpmav", Jm["data-google-av-dm"] = "googleAvDm", Jm["data-google-av-ext-cxn"] = "googleAvExtCxn", Jm["data-google-av-immediate"] = "googleAvImmediate", Jm["data-google-av-inapp"] = "googleAvInapp",
            Jm["data-google-av-itpl"] = "googleAvItpl", Jm["data-google-av-metadata"] = "googleAvMetadata", Jm["data-google-av-naid"] = "googleAvNaid", Jm["data-google-av-override"] = "googleAvOverride", Jm["data-google-av-rs"] = "googleAvRs", Jm["data-google-av-slift"] = "googleAvSlift", Jm["data-google-av-cxn"] = "googleAvCxn", Jm["data-google-av-aid"] = void 0, Jm["data-google-av-flags"] = "googleAvFlags", Jm["data-google-av-turtlex"] = "googleAvTurtlex", Jm["data-google-av-ufs-integrator-metadata"] = "googleAvUfsIntegratorMetadata", Jm["data-google-av-vattr"] =
            "googleAvVattr", Jm["data-google-av-vrus"] = "googleAvVurs", Jm);

    function Lm(a, b) {
        if (void 0 === a.j) return null;
        try {
            var c;
            var d = null != (c = a.j.getAttribute(b)) ? c : null;
            if (null !== d) return d
        } catch (g) {}
        try {
            var e = Im[b];
            if (e && (d = a.j[e], void 0 !== d)) return d
        } catch (g) {}
        try {
            var f = Km[b];
            if (f) return Gm(a.j, f)
        } catch (g) {}
        return null
    }

    function Mm(a) {
        return P(function(b) {
            return Lm(b, a)
        })
    };
    var Nm = K(function(a) {
        return P(function(b) {
            return a.map(function(c) {
                return Lm(b, c)
            })
        })
    }(["data-google-av-cxn", "data-google-av-turtlex"]), P(function(a) {
        var b = t(a);
        a = b.next().value;
        b = b.next().value;
        if (!a) {
            if (null !== b) return [];
            throw new be;
        }
        return a.split("|")
    }));
    var Om = function() {
        return K(id(function(a) {
            return a.element.g(Nm, Ae(function() {
                return N([""])
            })).g(P(function(b) {
                return {
                    Ga: b,
                    Tc: a
                }
            }))
        }), Le(function(a) {
            return a.Ga.sort().join(";")
        }), P(function(a) {
            return a.Tc
        }))
    };
    var Qm = function() {
            return id(function(a) {
                return hd(Pm(a)).g(Gh(a.h))
            })
        },
        Pm = function(a) {
            return a.document.querySelectorAll(".GoogleActiveViewElement,.GoogleActiveViewClass").map(function(b) {
                return new Uh(b)
            })
        };

    function Rm(a) {
        var b = a.eg,
            c = a.document.ki;
        return td(N({}), c, b).g(P(function() {
            return a
        }))
    };
    var Tm = P(Sm);

    function Sm(a) {
        var b = Number(Lm(a, "data-google-av-rs"));
        if (!isNaN(b) && 0 !== b) return b;
        var c;
        return (a = null == (c = a.j) ? void 0 : c.id) ? a.startsWith("DfaVisibilityIdentifier") ? 6 : a.startsWith("YtKevlarVisibilityIdentifier") ? 15 : a.startsWith("YtSparklesVisibilityIdentifier") ? 17 : a.startsWith("YtKabukiVisibilityIdentifier") ? 18 : 0 : 0
    };

    function Um() {
        return K(T(function(a) {
            return void 0 !== a
        }), P(function(a) {
            return a
        }))
    };

    function Vm() {
        return function(a) {
            var b = [];
            return a.g(T(function(c) {
                if (void 0 === c.j || b.some(function(d) {
                        return d.j === c.j
                    })) return !1;
                b.push(c);
                return !0
            }))
        }
    };

    function Wm(a, b) {
        b = void 0 === b ? rc : b;
        return td(Rm(a), b).g(Qm(), Vm(), Um(), Y(a.h, 1))
    };

    function Xm(a, b) {
        return new L(function(c) {
            var d = !1,
                e = Array(b.length);
            e.fill(void 0);
            var f = new Set,
                g = new Set,
                k = function(r, q) {
                    a.mg ? (e[q] = r, f.add(q), d || (d = !0, Ua(a, function() {
                        d = !1;
                        c.next(mb(e))
                    }, 1))) : c.error(new ce(q))
                },
                h = function(r, q) {
                    g.add(q);
                    f.add(q);
                    Ua(a, function() {
                        c.error(r)
                    }, 1)
                },
                l = function(r) {
                    g.add(r);
                    Ua(a, function() {
                        g.size === b.length && c.complete()
                    }, 1)
                },
                m = b.map(function(r, q) {
                    return r.subscribe(function(v) {
                        return void k(v, q)
                    }, function(v) {
                        return void h(v, q)
                    }, function() {
                        return void l(q)
                    })
                });
            return function() {
                m.forEach(function(r) {
                    return void r.unsubscribe()
                })
            }
        })
    };

    function Ym(a, b, c) {
        function d() {
            if (b.Ka) {
                var D = b.Ka,
                    C = D.next;
                var S = {
                    creativeId: b.dc.Na(c),
                    requiredSignals: e,
                    signals: Object.assign({}, f),
                    hasPrematurelyCompleted: g,
                    errorMessage: k,
                    erroredSignalKey: h
                };
                S = {
                    specMajor: 2,
                    specMinor: 0,
                    specPatch: 0,
                    timestamp: me(b.i.now(), new ke(0, b.i.timeline)),
                    instanceId: b.dc.Na(b.xb),
                    creativeState: S
                };
                C.call(D, S)
            }
        }
        for (var e = Object.keys(a), f = {}, g = !1, k = null, h = null, l = {}, m = new Set, r = [], q = [], v = t(e), w = v.next(), A = {}; !w.done; A = {
                da: A.da
            }, w = v.next()) A.da = w.value, w = a[A.da], w instanceof
        Z ? (l[A.da] = w.value, m.add(A.da), b.Ka && (f[String(A.da)] = oe(w.value))) : (w = w.g(V(function(D, C) {
                return ge(D) || ge(C) ? !1 : D === C
            }), P(function(D) {
                return function(C) {
                    b.Ka && (f[String(D.da)] = oe(C), d());
                    var S = {};
                    return S[D.da] = C, S
                }
            }(A)), Ae(function(D) {
                return function(C) {
                    if (C instanceof ce) throw new ee(String(D.da));
                    throw C;
                }
            }(A)), Ff(function(D) {
                return function() {
                    m.add(D.da)
                }
            }(A), function(D) {
                return function(C) {
                    h = String(D.da);
                    k = String(C);
                    d()
                }
            }(A), function(D) {
                return function() {
                    m.has(D.da) || (g = !0, d())
                }
            }(A))), q.push(A.da),
            r.push(w));
        (a = 0 < Object.keys(f).length) && d();
        v = Xm(b.h, r).g(Ae(function(D) {
            if (D instanceof ce) throw new de(String(q[D.Gh]));
            throw D;
        }), P(function(D) {
            return Object.freeze(Object.assign.apply(Object, [{}, l].concat(u(D))))
        }));
        return (r = 0 < r.length) && a ? td(N(Object.freeze(l)), v) : r ? v : N(Object.freeze(l))
    };

    function Zm(a, b, c, d) {
        var e = $m(an(bn(), cn), dn, en);
        return a.B.Ub.bind(a.B)(733, function() {
            var f = {};
            try {
                return b.g(Ae(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return rc
                }), id(function(g) {
                    try {
                        var k = c(a, g)
                    } catch (l) {
                        return d(Object.assign({}, f, {
                            error: l instanceof Error ? l : String(l)
                        })), rc
                    }
                    var h = {};
                    return Ym(k, a, g.xb).g(Ff(function(l) {
                        h = l
                    }), tf(1), Cc()).g(e, Ae(function(l) {
                        d(Object.assign({}, h, {
                            error: l
                        }));
                        return rc
                    }), Xe(void 0), P(function() {
                        return !0
                    }))
                })).g(lf(function(g) {
                    return g + 1
                }, 0), Ae(function(g) {
                    d(Object.assign({},
                        f, {
                            error: g
                        }));
                    return rc
                }))
            } catch (g) {
                return d(Object.assign({}, f, {
                    error: g
                })), rc
            }
        })()
    };

    function fn(a, b) {
        return K(X(function(c) {
            var d = a(c),
                e = b(c),
                f = {};
            return d && e && f ? new L(function(g) {
                e(d, f, function(k) {
                    g.next(Object.assign({}, c, {
                        hb: k
                    }));
                    g.complete()
                });
                return function() {}
            }) : vd
        }), T(function(c) {
            return c.hb
        }))
    };
    var dn = K(T(function(a) {
        var b = a.H,
            c = a.Oc,
            d = a.Vb,
            e = a.ub,
            f = a.ob,
            g = a.Zb;
        return void 0 !== a.kb && void 0 !== g && void 0 !== b && void 0 !== c && void 0 !== d && (!f || void 0 !== e)
    }), Cf(function(a) {
        return !(!1 === a.Rf && void 0 !== a.zf)
    }, !1), T(function(a) {
        return !0 === a.Rf
    }), fn(function(a) {
        return a.Zb
    }, function(a) {
        return a.kb
    }), P(function(a) {
        if (a.ob) {
            var b;
            a.ub({
                eventType: "active-view-begin-to-render",
                eventData: null != (b = a.Cd) ? b : "",
                destination: ["buyer"]
            })
        } else a.Vb(a.Oc, a).forEach(function(c) {
            a.H.N(c).sendNow()
        })
    }), Qe(1), af());

    function gn(a) {
        var b = new Map;
        if ("object" !== typeof a || null === a) return b;
        Object.values(a).forEach(function(c) {
            c && "function" === typeof c.ka && (b.has(c.clock.timeline) || b.set(c.clock.timeline, c.clock.now()))
        });
        return b
    };

    function hn(a, b) {
        var c = jn,
            d = kn,
            e = ln;
        b = void 0 === b ? .01 : b;
        return function(f) {
            0 < b && Math.random() <= b && (a.global.HTMLFencedFrameElement && a.global.fence && "function" === typeof a.global.fence.reportEvent && a.global.fence.reportEvent({
                eventType: "active-view-error",
                eventData: "",
                destination: ["buyer"]
            }), f = Object.assign({}, f, {
                errorMessage: f.error instanceof Error && f.error.message ? f.error.message : String(f.error),
                Af: f.error instanceof Error && f.error.stack ? String(f.error.stack) : null,
                kh: f.error instanceof Error && f.error.name ?
                    String(f.error.name) : null,
                jh: String(a.B.yg)
            }), d(Object.assign({}, f, {
                va: function() {
                    return function(g) {
                        try {
                            return e(Object.assign({}, g))
                        } catch (k) {
                            return {}
                        }
                    }
                }(),
                Ga: [c]
            }), gn(f)).forEach(function(g) {
                a.H.N(g).sendNow()
            }))
        }
    };
    var en = K(P(function(a) {
        var b = a.H,
            c = a.rh;
        if (void 0 === b || void 0 === c) return !1;
        if (void 0 !== a.zf) return !0;
        if (null === c) return !1;
        for (a = 0; a < c; a++) b.N("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=extra&rnd=" + Math.floor(1E7 * Math.random())).sendNow();
        return !0
    }), Cf(function(a) {
        return !a
    }), af());
    var ln = function(a) {
        return {
            id: a.Me,
            mcvt: a.qc,
            p: a.Uc,
            asp: a.Bj,
            mtos: a.rc,
            tos: a.Cc,
            v: a.Wg,
            bin: a.Vg,
            avms: a.cg,
            bs: a.qf,
            mc: a.ag,
            "if": a.dh,
            vu: a.gh,
            app: a.Za,
            mse: a.Ge,
            mtop: a.He,
            itpl: a.we,
            adk: a.Qd,
            exk: a.Dj,
            rs: a.Ta,
            la: a.Uf,
            cr: a.ze,
            uach: a.Ec,
            vs: a.Ye,
            r: a.Oe,
            pay: a.Bh,
            rst: a.Qg,
            rpt: a.Pg,
            isd: a.Fh,
            lsd: a.Sh,
            context: a.jh,
            msg: a.errorMessage,
            stack: a.Af,
            name: a.kh,
            ec: a.Ch,
            sfr: a.Se,
            met: a.bc,
            wmsd: a.bf,
            pv: a.Lj,
            epv: a.Gj,
            pbe: a.Qf,
            vae: a.Eh,
            spb: a.vg,
            ffslot: a.Mh,
            reach: a.Mi,
            io2: a.Ed,
            rxdbg: a.Pj
        }
    };

    function $m() {
        var a = y.apply(0, arguments);
        return function(b) {
            var c = b.g(tf(1), Cc());
            b = a.map(function(d) {
                return c.g(d, Xe(!0))
            });
            return R(b).g(Qe(1), af())
        }
    };

    function an() {
        var a = y.apply(0, arguments);
        return function(b) {
            var c = b.g(tf(1), Cc());
            b = a.map(function(d) {
                return c.g(d, Xe(!0))
            });
            return td.apply(null, u(b)).g(Qe(1), af())
        }
    };

    function bn() {
        var a = mn,
            b = nn;
        return function(c) {
            var d = c.g(tf(1), Cc());
            c = d.g(a, Xe(!0));
            d = d.g(K(b, tf(), Cc()), Xe(!0));
            c = R([c, d]);
            return yd(c, d).g(Qe(1), af())
        }
    };
    var nn = function(a) {
        var b = [];
        return a.g(P(function(c) {
            var d = c.H,
                e = c.uh,
                f = c.Cc,
                g = c.Si,
                k = c.va,
                h = c.Ri,
                l = c.wg,
                m = c.Dc,
                r = c.Ze,
                q = c.Mf,
                v = c.Qf,
                w = c.vg,
                A = c.Cd;
            if (!c.Hf || !q || void 0 === c.rc || void 0 === f || void 0 === g || void 0 === k || void 0 === h || void 0 === m || void 0 === d) return !1;
            if (c.ob) {
                if (void 0 === l) return !1;
                g = c.ub;
                if (!g) return !1;
                g({
                    eventType: "active-view-time-on-screen",
                    eventData: null != A ? A : "",
                    destination: ["buyer"]
                });
                return !0
            }
            if (!v && !l) return !1;
            A = gn(c);
            var D;
            r = null != (D = null == r ? void 0 : r.ra(A).value) ? D : !1;
            c = m(Object.assign({},
                c, {
                    Me: h,
                    Ye: r ? 4 : 3,
                    Oe: null != l ? l : "u",
                    va: k,
                    Ga: g
                }), A);
            if (v) {
                for (; b.length > g.length;) v = void 0, null == (v = b.shift()) || v.deactivate();
                c.forEach(function(C, S) {
                    S >= b.length ? b.push(d.N(C)) : b[S].url = C
                });
                return w && e && void 0 !== l ? (c.forEach(function(C) {
                    e.N(C).sendNow()
                }), !0) : void 0 !== l
            }
            return w && e && void 0 !== l ? (c.forEach(function(C) {
                e.N(C).sendNow()
            }), !0) : void 0 !== l ? (c.forEach(function(C) {
                d.N(C).sendNow()
            }), !0) : !1
        }), Cf(function(c) {
            return !c
        }), af())
    };

    function on(a) {
        return function(b) {
            return b.g(P(function(c) {
                a.mg || ab("Assertion on queued Observable output failed");
                return c
            }))
        }
    };

    function pn(a) {
        return function(b) {
            return new L(function(c) {
                var d = !1,
                    e = b.g(on(a)).subscribe(function(f) {
                        d = !0;
                        c.next(f)
                    }, c.error.bind(c), c.complete.bind(c));
                Ua(a, function() {
                    d || c.next(null)
                }, 3);
                return e
            })
        }
    };

    function qn(a, b) {
        return function(c) {
            return c.g(X(function(d) {
                return new L(function(e) {
                    function f() {
                        k.disconnect();
                        h.unsubscribe()
                    }
                    var g = a.MutationObserver;
                    if (g && void 0 !== d.j) {
                        var k = new g(function(l) {
                            e.next(l)
                        });
                        k.observe(d.j, b);
                        var h = d.released.subscribe(f);
                        return f
                    }
                })
            }))
        }
    };
    var rn = {
        Aj: 0,
        ej: 1,
        gj: 2,
        fj: 3,
        0: "UNKNOWN",
        1: "DEFER_MEASUREMENT",
        2: "DO_NOT_DEFER_MEASUREMENT",
        3: "DEFER_MEASUREMENT_AND_PING"
    };

    function sn(a, b) {
        var c = b.g(qn(a, {
            attributes: !0
        }), Y(a.h, 1));
        return R([b, c.g(Y(a.h, 1), pn(a.h))]).g(P(function(d) {
            return t(d).next().value
        }), Mm("data-google-av-dm"), P(tn))
    }

    function tn(a) {
        return a && a in rn ? Number(a) : 2
    };

    function un(a) {
        if (3 === a.Wh) return null;
        if (void 0 !== a.wg) {
            var b = !1 === a.bh ? "n" : null;
            if (null !== b) return b
        }
        return a.Zc instanceof Wd ? "msf" : a.Yd instanceof Xd ? "c" : !1 === a.ah ? "pv" : a.Zc || a.Yd ? "x" : null
    }
    var cn = K(T(function(a) {
        return void 0 !== a.ed && void 0 !== a.va && void 0 !== a.Dc && void 0 !== a.fd && void 0 !== a.H
    }), T(function(a) {
        return null !== un(a)
    }), fn(function(a) {
        return a.Kc
    }, function(a) {
        return a.kb
    }), P(function(a) {
        if (a.ob) {
            var b = a.ub;
            if (b) {
                var c;
                b({
                    eventType: "active-view-unmeasurable",
                    eventData: null != (c = a.Cd) ? c : "",
                    destination: ["buyer"]
                })
            }
        } else {
            c = void 0;
            var d = un(a);
            if ("x" === d) {
                var e, f = null != (e = a.Zc) ? e : a.Yd;
                f && (b = f.stack, c = f.message)
            }
            a.Dc(Object.assign({}, a, {
                Ga: a.ed,
                va: a.va,
                Me: a.fd,
                Ye: 2,
                Oe: d,
                errorMessage: c,
                Af: b
            }), gn(a)).forEach(function(g) {
                a.H.N(g).sendNow()
            })
        }
    }), Qe(1), af());

    function vn(a, b) {
        return "string" === typeof a ? encodeURIComponent(a) : "number" === typeof a ? String(a) : Array.isArray(a) ? a.map(function(c) {
            return vn(c, b)
        }).join(",") : a instanceof ke ? a.toString() : a && "function" === typeof a.ka ? vn(a.ra(b).value, b) : !0 === a ? "1" : !1 === a ? "0" : void 0 === a || null === a ? null : [a.top, a.left, a.top + a.height, a.left + a.width].join()
    }

    function wn(a, b) {
        a = Object.entries(a).map(function(c) {
            var d = t(c);
            c = d.next().value;
            d = d.next().value;
            d = vn(d, b);
            return null === d ? "" : c + "=" + d
        }).filter(function(c) {
            return "" !== c
        });
        return a.length ? a.join("&") : ""
    };
    var xn = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g,
        yn = Bg(Cg(), "google3.javascript.ads.common.url_macros_substitutor", rg).Zf;

    function zn(a, b) {
        return a.replace(xn, function(c, d) {
            try {
                var e = null !== b && d in b ? b[d] : void 0;
                if (null == e) return yn && Dg(yn, "No value supplied for unsupported macro: " + d), c;
                if (null == e.toString()) return yn && Dg(yn, "The toString method of value returns null for macro: " + d), c;
                e = e.toString();
                if ("" == e || !/^[\s\xa0]*$/.test(null == e ? "" : String(e))) return encodeURIComponent(e).replace(/%2C/g, ",");
                yn && Dg(yn, "Null value supplied for macro: " + d)
            } catch (f) {
                yn && Dg(yn, "Failed to set macro: " + d)
            }
            return c
        })
    };

    function An(a, b) {
        var c = Object.assign({}, a),
            d = a.Ec;
        c = (delete c.Ec, c);
        c = a.va(c);
        var e = wn(c, b);
        return ib(a.Ga, function(f) {
            var g = "";
            "string" === typeof d && (g = "&" + wn({
                uach: d
            }, b));
            var k = {};
            return zn(f, (k.VIEWABILITY = e, k)) + g
        })
    };

    function kn(a, b) {
        var c = a.va(a),
            d = wn(c, b);
        return d ? ib(a.Ga, function(e) {
            e = 0 <= e.indexOf("?") ? e : e + "?";
            e = 0 <= "?&".indexOf(e.slice(-1)) ? e : e + "&";
            return e + d
        }) : a.Ga
    };

    function Bn(a, b) {
        return ib(a, function(c) {
            if ("string" === typeof b.Ec) {
                var d = "&" + wn({
                    uach: b.Ec
                }, new Map);
                return "&adurl=" == c.substring(c.length - 7) ? c.substring(0, c.length - 7) + d + "&adurl=" : c + d
            }
            return c
        })
    };
    var mn = K(T(function(a) {
        return void 0 !== a.va && void 0 !== a.ed && void 0 !== a.Dc && void 0 !== a.fd && void 0 !== a.H
    }), P(function(a) {
        return Object.assign({}, a, {
            zg: gn(a)
        })
    }), T(function(a) {
        var b = a.Ze,
            c = a.zg,
            d;
        return !!a.Mf && (null != (d = null == b ? void 0 : b.ra(c).value) ? d : !1)
    }), fn(function(a) {
        return a.Lc
    }, function(a) {
        return a.kb
    }), P(function(a) {
        var b = a.H,
            c = a.Cd;
        if (a.ob) {
            var d = a.ub;
            if (!d) return !1;
            d({
                eventType: "active-view-viewable",
                eventData: null != c ? c : "",
                destination: ["buyer"]
            });
            return !0
        }
        c = a.Dc(Object.assign({}, a, {
            Ga: a.ed,
            va: a.va,
            Me: a.fd,
            Ye: 4,
            Oe: "v"
        }), a.zg);
        (d = a.Zd) && 0 < d.length && a.Vb && a.Vb(d, a).forEach(function(e) {
            b.N(e).sendNow()
        });
        (d = a.af) && 0 < d.length && a.Vb && a.Vb(d, a).forEach(function(e) {
            b.N(e).sendNow()
        });
        c.forEach(function(e) {
            b.N(e, {
                Nc: a.Ce
            }).sendNow()
        });
        return !0
    }), Cf(function(a) {
        return !a
    }), af());

    function Cn(a) {
        var b = Math.pow(10, 2);
        return Math.round(a * b) / b
    };

    function Dn(a, b, c, d) {
        var e = Object.keys(c).map(function(k) {
                return k
            }),
            f = e.filter(function(k) {
                var h = c[k];
                k = d[k];
                return h instanceof Z && k instanceof Z && h.value === k.value
            }),
            g = f.reduce(function(k, h) {
                var l = {};
                return Object.assign({}, k, (l[h] = c[h], l))
            }, {});
        return e.reduce(function(k, h) {
            if (0 <= f.indexOf(h)) return k;
            var l = {};
            return Object.assign({}, k, (l[h] = b.g(X(function(m) {
                return (m = m ? c[h] : d[h]) && (m instanceof L || "function" === typeof m.Jb && "function" === typeof m.subscribe) ? m : m.V(a)
            })), l))
        }, g)
    };

    function En(a) {
        return K(P(function() {
            return !0
        }), W(!1), Y(a, 1))
    };

    function Fn(a) {
        return 0 >= a.length ? rc : R(a.map(function(b) {
            var c = 0;
            return b.g(P(function(d) {
                return {
                    index: c++,
                    value: d
                }
            }))
        })).g(T(function(b) {
            return b.every(function(c) {
                return c.index === b[0].index
            })
        }), P(function(b) {
            return b.map(function(c) {
                return c.value
            })
        }))
    };

    function Gn(a, b) {
        a.Ja && (a.tb = a.Ja);
        a.Ja = b;
        a.tb && a.tb.value ? (b = Math.max(0, me(b.timestamp, a.tb.timestamp)), a.totalTime += b, a.pa += b) : a.pa = 0;
        return a
    }

    function Hn() {
        return K(lf(Gn, {
            totalTime: 0,
            pa: 0
        }), P(function(a) {
            return a.totalTime
        }))
    }

    function In() {
        return K(lf(Gn, {
            totalTime: 0,
            pa: 0
        }), P(function(a) {
            return a.pa
        }))
    };

    function Jn(a, b) {
        return K(Mm("data-google-av-metadata"), P(function(c) {
            if (null === c) return b(void 0);
            c = c.split("&").map(function(d) {
                return d.split("=")
            }).filter(function(d) {
                return d[0] === a
            });
            return 0 === c.length ? b(void 0) : b(c[0].slice(1).join("="))
        }))
    };
    var Kn = {
        bj: "asmreq",
        cj: "asmres"
    };
    var Ln = function(a) {
        im.call(this, a)
    };
    x(Ln, im);
    Ln.prototype.pg = function(a) {
        Hk(this, a)
    };
    Ln.Ca = "tagging.common.osd.AdSpeedMetricsRequest";
    Ln.makeCrossSerializerComparisonsCompatible = jm(Ln, [0, $l]);
    var Mn = function(a) {
        im.call(this, a)
    };
    x(Mn, im);
    Mn.Ca = "tagging.common.osd.AdSpeedMetricsResponse.Box";
    var Nn = [0, Ul, -3];
    Mn.makeCrossSerializerComparisonsCompatible = jm(Mn, Nn);
    var On = function(a) {
        im.call(this, a)
    };
    x(On, im);
    On.prototype.pg = function(a) {
        Hk(this, a)
    };
    var Pn = function(a) {
        return function(b) {
            db(a);
            if (null == b || "" == b) b = gb(new a, Lk);
            else {
                cb(b);
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("ia`" + La(b) + "`" + b);
                Li(b, 32);
                b = Wj(a, b)
            }
            return b
        }
    }(On);
    On.Ca = "tagging.common.osd.AdSpeedMetricsResponse";
    On.makeCrossSerializerComparisonsCompatible = jm(On, [0, $l, Xl, Nn, Ul, -1]);

    function Qn(a, b) {
        var c = void 0 === c ? Cm(a) : c;
        var d = new MessageChannel;
        b = b.g(P(function(f) {
            return Number(f)
        }), T(function(f) {
            return !isNaN(f) && 0 !== f
        }), Ff(function(f) {
            var g = new Ln;
            g.pg(f);
            f = {
                type: "asmreq",
                payload: g.eb()
            };
            c.postMessage(f, "*", [d.port2])
        }), Qe(1));
        var e = Dm(a, d.port1).g(T(function(f) {
                return "object" === typeof f.data
            }), P(function(f) {
                var g = f.data,
                    k = Object.values(Kn).includes(g.type);
                g = "string" === typeof g.payload;
                if (!k || !g || "asmres" !== f.data.type) return null;
                try {
                    return Pn(f.data.payload)
                } catch (h) {
                    return null
                }
            }),
            T(function(f) {
                return null !== f
            }), P(function(f) {
                return f
            }));
        return b.g(X(function(f) {
            return N(f).g(Ce(e))
        }), T(function(f) {
            var g = t(f);
            f = g.next().value;
            g = g.next().value;
            if (null != Lj(nk(g, 1))) {
                var k = void 0 === k ? 0 : k;
                k = Ck(Lj(nk(g, 1)), k) === f
            } else k = !1;
            return k
        }), P(function(f) {
            f = t(f);
            f.next();
            return f.next().value
        }), Gh(a.h))
    };

    function Rn(a, b, c) {
        var d = b.oc.g(Qe(1), X(function() {
            return Qn(a, c)
        }), T(function(f) {
            return Dk(f, 2) && rk(f, Mn, 3) && null != Jj(nk(f, 4)) && null != Jj(nk(f, 5))
        }), Qe(1), Gh(a.h));
        b = d.g(P(function(f) {
            return {
                x: Ek(zk(f, Mn, 3), 2),
                y: Ek(zk(f, Mn, 3), 1)
            }
        }), V(function(f, g) {
            return f.x === g.x && f.y === g.y
        }), Y(a.h, 1));
        var e = d.g(P(function(f) {
            return Ek(f, 4)
        }), Y(a.h, 1));
        d = d.g(P(function(f) {
            return Ek(f, 5)
        }), Y(a.h, 1));
        return {
            Fh: e,
            Sg: b,
            Sh: d
        }
    };

    function Sn(a, b) {
        return b.oc.g(Qe(1), P(function() {
            return a.i.now().round()
        }))
    };
    var Tn = P(function(a) {
        return [a.value.P.width, a.value.P.height]
    });

    function Un(a, b) {
        return function(c) {
            return Fn(b.map(function(d) {
                return c.g(a(d))
            }))
        }
    };

    function Vn() {
        var a;
        return K(Ff(function(b) {
            return void(a = b.timestamp)
        }), In(), P(function(b) {
            return {
                timestamp: a,
                value: Math.round(b)
            }
        }))
    };
    var Wn = function(a, b) {
            this.Td = a;
            this.options = b;
            this.M = this.ye = this.xe = null
        },
        Xn = function(a, b) {
            2 === b.M || 3 === b.M ? a.M || (b = Object.assign({}, a.options, {
                delay: 100,
                trackVisibility: !0
            }), a.M = new IntersectionObserver(a.Td, b)) : 1 === b.M ? a.ye || (b = Object.assign({}, a.options, {
                delay: 100
            }), a.ye = new IntersectionObserver(a.Td, b)) : a.xe || (a.xe = new IntersectionObserver(a.Td, a.options))
        },
        Yn = function(a, b) {
            a = 2 === b || 3 === b ? a.M : 1 === b ? a.ye : a.xe;
            if (!a) throw new Zd;
            return a
        };
    Wn.prototype.observe = function(a, b) {
        Yn(this, a).observe(b)
    };
    Wn.prototype.unobserve = function(a, b) {
        Yn(this, a).unobserve(b)
    };
    Wn.prototype.disconnect = function(a) {
        Yn(this, a).disconnect()
    };
    Wn.prototype.takeRecords = function(a) {
        return Yn(this, a).takeRecords()
    };
    var Zn = {
        Y: "ns",
        ca: li,
        P: li,
        X: new M,
        R: "ns",
        G: li,
        T: li,
        ea: {
            x: 0,
            y: 0
        }
    };

    function $n(a, b) {
        return mi(a.P, b.P) && mi(a.G, b.G) && mi(a.ca, b.ca) && mi(a.T, b.T) && a.R === b.R && a.X === b.X && a.Y === b.Y && a.ea.x === b.ea.x && a.ea.y === b.ea.y
    };
    var ao = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };

    function bo(a, b) {
        return function(c) {
            return function(d) {
                var e = d.g( of (new M), Cc());
                d = c.element.g(V());
                e = e.g(P(function(f) {
                    return f.value
                }));
                return R([d, e, b]).g(P(function(f) {
                    var g = t(f);
                    f = g.next().value;
                    var k = g.next().value;
                    g = g.next().value;
                    if (void 0 === f.j) var h = {
                        top: 0,
                        left: 0,
                        width: 0,
                        height: 0
                    };
                    else {
                        h = f.j.getBoundingClientRect();
                        var l = f.j,
                            m = a.global,
                            r = new oh(0, 0);
                        var q = (q = rh(l)) ? q.parentWindow || q.defaultView : window;
                        if ($g(q, "parent")) {
                            do {
                                if (q == m) {
                                    var v = l,
                                        w = rh(v);
                                    eb(v, "Parameter is required");
                                    var A = new oh(0,
                                        0);
                                    var D = w ? rh(w) : document;
                                    D = !bh || 9 <= Number(nh) || "CSS1Compat" == sh(D).Eb.compatMode ? D.documentElement : D.body;
                                    v != D && (v = ao(v), w = th(sh(w).Eb), A.x = v.left + w.x, A.y = v.top + w.y)
                                } else A = z(l), A = ao(A), A = new oh(A.left, A.top);
                                r.x += A.x;
                                r.y += A.y
                            } while (q && q != m && q != q.parent && (l = q.frameElement) && (q = q.parent))
                        }
                        h = {
                            top: r.y,
                            left: r.x,
                            width: h.width,
                            height: h.height
                        }
                    }
                    h = oi(h, k.ea);
                    m = ni(h, k.ca);
                    r = a.i.now();
                    q = Object;
                    l = q.assign;
                    if (2 !== g || a.Gb || 0 >= m.width || 0 >= m.height) var C = !1;
                    else try {
                        var S = a.document.elementFromPoint(m.left + m.width /
                            2, m.top + m.height / 2);
                        C = S ? !co(S, f) : !1
                    } catch (pa) {
                        C = !1
                    }
                    return {
                        timestamp: r,
                        value: l.call(q, {}, k, {
                            R: "geo",
                            T: C ? Zn.T : m,
                            G: h
                        })
                    }
                }), Gh(a.h))
            }
        }
    }

    function co(a, b, c) {
        c = void 0 === c ? 0 : c;
        return void 0 === a.j || void 0 === b.j ? !1 : a.j === b.j || vh(b.j, function(d) {
            return d === a.j
        }) ? !0 : b.j.ownerDocument && b.j.ownerDocument.defaultView && b.j.ownerDocument.defaultView === b.j.ownerDocument.defaultView.top ? !1 : 10 > c && b.j.ownerDocument && b.j.ownerDocument.defaultView && b.j.ownerDocument.defaultView.frameElement ? co(a, new Uh(b.j.ownerDocument.defaultView.frameElement), c + 1) : !0
    };

    function eo(a) {
        return function(b) {
            return b.g(a.ResizeObserver ? fo(a) : go(a), tf(1), Cc())
        }
    }

    function fo(a) {
        return function(b) {
            return b.g(X(function(c) {
                var d = a.ResizeObserver;
                if (!d || void 0 === c.j) return N(Zn.G);
                var e = (new L(function(f) {
                    function g() {
                        void 0 !== c.j && k.unobserve(c.j);
                        k.disconnect();
                        h.unsubscribe()
                    }
                    if (void 0 === c.j) return f.complete(),
                        function() {};
                    var k = new d(function(l) {
                        l.forEach(function(m) {
                            f.next(m)
                        })
                    });
                    k.observe(c.j);
                    var h = c.released.subscribe(g);
                    return g
                })).g(Rg(a.B, 736), P(function(f) {
                    return f.contentRect
                }));
                return td(N(c.j.getBoundingClientRect()), e)
            }), V(mi))
        }
    }

    function go(a) {
        return function(b) {
            var c = b.g(qn(a, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                })),
                d = a.mi;
            c = td(b.g(P(function() {
                return Sh("resize")
            })), c, d);
            return R(b, c).g(Rg(a.B, 737), P(function(e) {
                e = t(e).next().value;
                return void 0 === e.j ? void 0 : e.j.getBoundingClientRect()
            }), Um(), V(mi))
        }
    };

    function ho(a, b) {
        var c = io(a, b).g(tf(1), Cc());
        return function(d) {
            return function(e) {
                e = e.g(X(function(f) {
                    return f.element
                }), V());
                return R([c, e]).g(X(function(f) {
                    var g = t(f);
                    f = g.next().value;
                    g = g.next().value;
                    return jo(a, f.Kh, eo(a), f.hi, d, f.vh, g)
                }), Gh(a.h))
            }
        }
    }

    function ko(a, b, c) {
        var d = ho(a, c)(b);
        return function(e) {
            var f = d(N(e));
            return function(g) {
                return R([g, f]).g(P(function(k) {
                    var h = t(k);
                    k = h.next().value;
                    h = h.next().value;
                    var l = oi(h.value.G, k.value.ea),
                        m = ni(oi(h.value.T, k.value.ea), k.value.ca);
                    return {
                        timestamp: k.timestamp.maximum(h.timestamp),
                        value: Object.assign({}, k.value, {
                            R: "nio",
                            T: m,
                            G: l
                        })
                    }
                }))
            }
        }
    }

    function lo(a) {
        return P(function(b) {
            return "nio" !== b.value.Y ? b : Object.assign({}, b, {
                value: Object.assign({}, b.value, {
                    ca: Em(a, !0),
                    P: Em(a, !0)
                })
            })
        })
    }

    function mo(a, b) {
        return N(b).g(a, P(function() {
            return b
        }))
    }

    function io(a, b) {
        return a.i.timeline !== he ? wc(new Wd(2)) : a.MutationObserver ? "undefined" === typeof IntersectionObserver ? wc(new Wd(0)) : (new L(function(c) {
            var d = new M,
                e = new Wn(d.next.bind(d), {
                    threshold: [].concat(u(b))
                });
            c.next({
                hi: d.g(Rg(a.B, 735)),
                Kh: e,
                vh: function(f) {
                    f = e.takeRecords(f.M);
                    0 < f.length && d.next(f)
                }
            })
        })).g(Qe(1), tf(1), Cc()) : wc(new Wd(1))
    }

    function no(a) {
        return fd(a.sort(function(b, c) {
            return b.time - c.time
        }))
    }

    function jo(a, b, c, d, e, f, g) {
        return new L(function(k) {
            function h() {
                w || (w = !0, void 0 !== g.j && b.unobserve(e.M, g.j), m.unsubscribe(), v.unsubscribe(), q.unsubscribe(), A.unsubscribe())
            }
            if (void 0 !== g.j) {
                Xn(b, e);
                b.observe(e.M, g.j);
                var l = new qc({
                        timestamp: a.i.now(),
                        value: Object.assign({}, Zn, {
                            Y: "nio",
                            R: "nio"
                        })
                    }),
                    m = d.g(id(function(D) {
                        return no(D)
                    }), T(function(D) {
                        return D.target === g.j
                    }), P(function(D) {
                        return {
                            timestamp: new ke(D.time, he),
                            value: {
                                Y: "nio",
                                ca: D.rootBounds || li,
                                P: D.rootBounds || Em(a, !0),
                                X: r,
                                R: "nio",
                                T: D.intersectionRect,
                                G: D.boundingClientRect,
                                ea: {
                                    x: 0,
                                    y: 0
                                },
                                isIntersecting: D.isIntersecting,
                                Xf: D.isVisible
                            }
                        }
                    }), of (l), Cc()).subscribe(k),
                    r = new M,
                    q = r.subscribe(function() {
                        f(e);
                        k.next({
                            timestamp: a.i.now(),
                            value: l.value.value
                        });
                        void 0 !== g.j && (b.unobserve(e.M, g.j), b.observe(e.M, g.j))
                    }),
                    v = mo(c, g).subscribe(function() {
                        r.next()
                    }),
                    w = !1,
                    A = g.released.subscribe(function() {
                        return h()
                    });
                return h
            }
        })
    };

    function oo(a, b) {
        var c = a.pe().g(P(function() {
            return "b"
        }));
        return yd(b, c).g(Qe(1), Y(a.h, 1))
    };

    function po(a) {
        return function(b) {
            var c;
            return b.g(Ff(function(d) {
                return void(c = d.timestamp)
            }), P(function(d) {
                return d.value
            }), a, P(function(d) {
                return {
                    timestamp: c,
                    value: d
                }
            }))
        }
    };
    var qo = function(a) {
            return a.T.width * a.T.height / (a.G.width * a.G.height)
        },
        ro = po(K(P(function(a) {
            var b;
            return null != (b = a.Yc) ? b : qo(a)
        }), P(function(a) {
            return isFinite(a) ? a : 0
        }))),
        so = po(K(P(function(a) {
            var b;
            return null != (b = a.Yc) ? b : qo(a)
        }), P(function(a) {
            return isFinite(a) ? a : -1
        })));
    var to = function(a, b) {
        this.a = a;
        this.b = b;
        if (a.clock.timeline !== b.clock.timeline) throw Error();
    };
    to.prototype.ja = function(a) {
        return a instanceof to ? this.a.ja(a.a) && this.b.ja(a.b) : !1
    };
    to.prototype.qa = function(a) {
        var b = this.a.qa(a).value,
            c = this.b.qa(a).value;
        return {
            timestamp: a,
            value: [b, c]
        }
    };
    da.Object.defineProperties(to.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.active || this.b.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.clock
            }
        },
        A: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a = this.a.A.timestamp.maximum(this.b.A.timestamp),
                    b = this.a.A.timestamp.equals(a) ? this.a.A.value : this.a.qa(a).value,
                    c = this.b.A.timestamp.equals(a) ? this.b.A.value : this.b.qa(a).value;
                return {
                    timestamp: a,
                    value: [b, c]
                }
            }
        }
    });
    var uo = function(a, b) {
        this.input = a;
        this.od = b;
        this.A = {
            timestamp: this.input.A.timestamp,
            value: this.od(this.input.A.value)
        }
    };
    uo.prototype.ja = function(a) {
        return a instanceof uo ? this.input.ja(a.input) && this.od === a.od : !1
    };
    uo.prototype.qa = function(a) {
        a = this.input.qa(a);
        return {
            timestamp: a.timestamp,
            value: this.od(a.value)
        }
    };
    da.Object.defineProperties(uo.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.clock
            }
        }
    });

    function vo(a, b, c) {
        c = void 0 === c ? function(d, e) {
            return d === e
        } : c;
        return a.timestamp.equals(b.timestamp) && c(a.value, b.value)
    };
    var wo = function(a, b, c) {
        this.clock = a;
        this.A = b;
        this.active = c
    };
    wo.prototype.ja = function(a) {
        return a instanceof wo ? this.active === a.active && this.clock.timeline === a.clock.timeline && vo(this.A, a.A) : !1
    };
    wo.prototype.qa = function(a) {
        return {
            timestamp: a,
            value: this.A.value + (this.active ? Math.max(0, me(a, this.A.timestamp)) : 0)
        }
    };
    var xo = function() {};
    xo.prototype.ka = function() {
        return this.qa(this.clock.now())
    };
    xo.prototype.ra = function(a) {
        var b = this.clock.timeline,
            c, d = null != (c = a.get(b)) ? c : this.clock.now();
        a.set(b, d);
        return this.qa(d)
    };
    xo.prototype.map = function(a) {
        return new yo(this, a)
    };
    xo.prototype.ta = function(a) {
        return new zo(this, a)
    };
    var zo = function() {
        to.apply(this, arguments);
        this.map = xo.prototype.map;
        this.ta = xo.prototype.ta;
        this.ka = xo.prototype.ka;
        this.ra = xo.prototype.ra
    };
    x(zo, to);
    var Ao = function() {
        wo.apply(this, arguments);
        this.map = xo.prototype.map;
        this.ta = xo.prototype.ta;
        this.ka = xo.prototype.ka;
        this.ra = xo.prototype.ra
    };
    x(Ao, wo);
    var yo = function() {
        uo.apply(this, arguments);
        this.map = xo.prototype.map;
        this.ta = xo.prototype.ta;
        this.ka = xo.prototype.ka;
        this.ra = xo.prototype.ra
    };
    x(yo, uo);

    function Bo(a, b) {
        a.Ja && (a.tb = a.Ja);
        a.Ja = b;
        a.tb && a.tb.value ? (b = Math.max(0, me(b.timestamp, a.tb.timestamp)), a.totalTime += b, a.pa += b) : a.pa = 0;
        return a
    }

    function Co(a) {
        return K(lf(Bo, {
            totalTime: 0,
            pa: 0
        }), P(function(b) {
            return new Ao(a, {
                timestamp: b.Ja.timestamp,
                value: b.totalTime
            }, b.Ja.value)
        }))
    }

    function Do(a) {
        return K(lf(Bo, {
            totalTime: 0,
            pa: 0
        }), P(function(b) {
            return new Ao(a, {
                timestamp: b.Ja.timestamp,
                value: b.pa
            }, b.Ja.value)
        }))
    };

    function Eo(a) {
        return K(Do(a), P(function(b) {
            return b.map(function(c) {
                return Math.round(c)
            })
        }))
    };
    var Fo = function(a, b) {
        this.A = b;
        this.ka = xo.prototype.ka;
        this.ra = xo.prototype.ra;
        this.map = xo.prototype.map;
        this.ta = xo.prototype.ta;
        this.clock = a
    };
    Fo.prototype.ja = function(a) {
        return a.active
    };
    Fo.prototype.qa = function() {
        return this.A
    };
    da.Object.defineProperties(Fo.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !1
            }
        }
    });

    function Go(a, b) {
        return b.g(P(function(c) {
            return new Fo(a.i, {
                timestamp: a.i.now(),
                value: c
            })
        }))
    };

    function Ho(a, b) {
        return 1 <= a ? !0 : 0 >= a ? !1 : a >= b
    };

    function Io(a) {
        return function(b) {
            return b.g(If(a), P(function(c) {
                var d = t(c);
                c = d.next().value;
                d = d.next().value;
                return {
                    timestamp: c.timestamp,
                    value: Ho(c.value, d)
                }
            }))
        }
    };
    var Jo = P(function(a) {
        if ("omid" === a.value.Y) {
            if ("nio" === a.value.R) return "omio";
            if ("geo" === a.value.R) return "omgeo"
        }
        return "geo" === a.value.R || "nio" === a.value.R ? a.value.Y : a.value.R
    });

    function Ko() {
        return K(T(function(a, b) {
            return 0 < b
        }), Lo, W(-1), V())
    }
    var Lo = K(T(function(a) {
        return !isNaN(a)
    }), lf(function(a, b) {
        return isNaN(a) ? b : Math.min(a, b)
    }, NaN), V());
    var Mo = po(K(P(function(a) {
        return a.T.width * a.T.height / (a.ca.width * a.ca.height)
    }), P(function(a) {
        return isFinite(a) ? Math.min(1, a) : 0
    })));

    function No(a, b, c) {
        return a ? R([b, c]).g(T(function(d) {
            var e = t(d);
            d = e.next().value;
            e = e.next().value;
            return d.timestamp.equals(e.timestamp)
        }), P(function(d) {
            var e = t(d);
            d = e.next().value;
            e = e.next().value;
            return d.value > e.value ? d : e
        })) : b
    }

    function Oo(a) {
        return function(b) {
            var c = b.g(ro),
                d = b.g(Mo);
            return a instanceof L ? a.g(X(function(e) {
                return No(e, c, d)
            })) : No(a.value, c, d)
        }
    };
    var Po = K(po(P(function(a) {
        a = a.Yc ? a.Yc * a.G.width * a.G.height / (a.P.width * a.P.height) : a.T.width * a.T.height / (a.P.width * a.P.height);
        return isFinite(a) ? a : 0
    })));

    function Qo(a, b, c, d) {
        var e = d.ad,
            f = d.je,
            g = d.Dg,
            k = d.mf,
            h = d.Ee,
            l = d.bg,
            m = d.dd,
            r = d.experimentState;
        b = Ro(a, c, b);
        c = So(a, c);
        d = To(b, r);
        r = Uo(a, e, l, d, r, b);
        var q = r.g(P(function(B) {
                return B.value
            }), V(), Y(a, 1), lf(function(B, U) {
                return Math.max(B, U)
            }, 0)),
            v = r.g(P(function(B) {
                return B.value
            }), Ko(), Y(a, 1)),
            w = b.g(so, P(function(B) {
                return B.value
            }), Qe(2), V(), Y(a, 1));
        g = Vo(a, b, g, k);
        var A = g.g(W(!1), V(), P(function(B) {
            return B ? h : f
        }));
        k = r.g(Io(A), V(), Y(a, 1));
        var D = R([k, b]).g(T(function(B) {
            var U = t(B);
            B = U.next().value;
            U = U.next().value;
            return B.timestamp.equals(U.timestamp)
        }), P(function(B) {
            var U = t(B);
            B = U.next().value;
            U = U.next().value;
            return {
                visible: B.value,
                geometry: U.value.G
            }
        }), lf(function(B, U) {
            return !U.visible && B.visible ? B : U
        }, {
            visible: !1,
            geometry: li
        }), P(function(B) {
            return B.geometry
        }), W(li), Y(a, 1), V(mi));
        l = l instanceof L ? l.g(V(), hf()) : vd;
        A = R([l, A]).g(hf());
        var C = b.g(T(function(B) {
                return "ns" !== B.value.Y && "ns" !== B.value.R
            }), lf(function(B) {
                return B + 1
            }, 0), W(0), Y(a, 1)),
            S = c.g(hf(!0), W(!1), Y(a, 1));
        S = R([m, S]).g(P(function(B) {
            var U = t(B);
            B = U.next().value;
            U = U.next().value;
            return B && !U
        }), Y(a, 1));
        var pa = b.g(Po, V()),
            ia = pa.g(P(function(B) {
                return B.value
            }), lf(function(B, U) {
                return Math.max(B, U)
            }, 0), V(), Y(a, 1)),
            E = pa.g(P(function(B) {
                return B.value
            }), Ko(), Y(a, 1));
        return {
            Re: l,
            zc: A,
            Ba: {
                yi: b,
                cg: b.g(Jo),
                Uc: D.g(V(mi)),
                visible: k.g(V(vo)),
                Ue: r.g(V(vo)),
                ag: q,
                bi: v,
                qf: b.g(Tn, V(nb)),
                Vi: pa,
                Uh: ia,
                ai: E,
                Zc: c,
                X: (new Z(new M)).V(a),
                Uf: g,
                ad: e,
                dd: m,
                Hf: S,
                Xi: C,
                Rh: w,
                Ed: d
            }
        }
    }

    function So(a, b) {
        return b.g(T(function() {
            return !1
        }), P(function(c) {
            return c
        }), Ae(function(c) {
            return (new Z(c)).V(a)
        }))
    }

    function To(a, b) {
        b = b.g(P(function(d) {
            return d.M
        }));
        a = R([a, b]).g(P(function(d) {
            var e = t(d);
            d = e.next().value;
            e = e.next().value;
            if (0 !== e && 1 !== e && d.value.isIntersecting) return d.value.Xf
        }), V());
        b = a.g(P(function(d) {
            return void 0 === d ? !0 : d
        }), lf(function(d, e) {
            return d || !e
        }, !1));
        var c = a.g(lf(function(d, e) {
            return void 0 === e ? d : e ? !1 : null != d ? d : !0
        }, void 0), P(function(d) {
            return !!d
        }));
        return Bd(a, b, c).g(P(function(d) {
            var e = t(d);
            d = e.next().value;
            var f = e.next().value;
            e = e.next().value;
            var g = 0;
            if (void 0 === d) return 0;
            d &&
                (g |= 1);
            d || (g |= 2);
            f && (g |= 4);
            e && (g |= 8);
            return g
        }))
    }

    function Ro(a, b, c) {
        return b.g(pf(vd), Y(a, 1)).g(V(function(d, e) {
            return vo(d, e, $n)
        }), W({
            timestamp: c.now(),
            value: Zn
        }), Y(a, 1))
    }

    function Uo(a, b, c, d, e, f) {
        c = f.g(Oo(c), po(P(function(g) {
            return Cn(g)
        })), Y(a, 1));
        if (b instanceof Z) return c;
        e = e.g(P(function(g) {
            return g.M
        }));
        return R([c, b, d, e]).g(P(function(g) {
            var k = t(g);
            g = k.next().value;
            var h = k.next().value,
                l = k.next().value;
            k = 3 === k.next().value && 0 !== (l & 2);
            return {
                timestamp: h.timestamp.maximum(g.timestamp),
                value: h.value || k ? 0 : g.value
            }
        }), V(vo), Y(a, 10))
    }

    function Vo(a, b, c, d) {
        b = [b.g(P(function(e) {
            return 242500 <= e.value.G.width * e.value.G.height
        }))];
        c instanceof L && b.push(c.g(P(function(e) {
            return !!e
        })));
        c = R(b);
        return d ? c.g(P(function(e) {
            return e.some(function(f) {
                return f
            })
        }), W(!1), V(), Y(a, 1)) : (new Z(!1)).V(a)
    };
    var Wo = function(a) {
            this.i = a;
            this.Ad = null;
            this.timeout = new M
        },
        Yo = function(a, b) {
            Xo(a);
            a.Ad = a.i.setTimeout(function() {
                return void a.timeout.next()
            }, b)
        },
        Xo = function(a) {
            null !== a.Ad && (a.i.clearTimeout(a.Ad), a.Ad = null)
        };

    function Zo(a, b, c, d) {
        var e = $o.xg,
            f = new Wo(b);
        c = c.g(W(void 0), X(function() {
            Xo(f);
            return d
        })).g(P(function(g) {
            Xo(f);
            var k = g.A,
                h = g.active;
            k.value >= e || !h || (h = b.now(), h = Math.max(0, me(h, k.timestamp)), Yo(f, Math.max(0, e - k.value - h)));
            return g.map(function(l) {
                return l >= e
            })
        }));
        return R([c, td(f.timeout, N(void 0))]).g(P(function(g) {
            return t(g).next().value
        }), Cf(function(g) {
            return !g.ka().value
        }, !0), Y(a, 1))
    };

    function ap(a) {
        var b = new Ao(a, {
            timestamp: a.now(),
            value: 0
        }, !1);
        return K(Do(a), lf(function(c, d) {
            return c.A.value > d.A.value ? new Ao(a, c.A, !1) : d
        }, b), P(function(c) {
            return c.map(function(d) {
                return Math.round(d)
            })
        }))
    };

    function bp(a) {
        return function(b) {
            return K(Io(N(b)), ap(a))
        }
    };

    function cp(a) {
        return function(b) {
            return K(po(P(function(c) {
                return Ho(c, b)
            })), Co(a), P(function(c) {
                return c.map(function(d) {
                    return Math.round(d)
                })
            }))
        }
    };

    function dp(a) {
        return a.map(function(b) {
            return b.map(function(c) {
                return [c]
            })
        }).reduce(function(b, c) {
            return b.ta(c).map(function(d) {
                return d.flat()
            })
        })
    }

    function ep(a, b) {
        return a.ta(b).map(function(c) {
            var d = t(c);
            c = d.next().value;
            d = d.next().value;
            return c - d
        })
    }

    function fp(a, b, c, d, e, f) {
        var g = gp;
        if (1 < g.length)
            for (var k = 0; k < g.length - 1; k++)
                if (g[k] < g[k + 1]) throw Error();
        k = f.g(W(void 0), X(function() {
            return d.g(Eo(a))
        }), V(function(h, l) {
            return h.ja(l)
        }), Y(b, 1));
        f = f.g(W(void 0), X(function() {
            return d.g(ap(a))
        }), V(function(h, l) {
            return h.ja(l)
        }), Y(b, 1));
        return {
            rc: e.g(W(void 0), X(function() {
                return c.g(Un(bp(a), g))
            }), P(dp), V(function(h, l) {
                return h.ja(l)
            }), Y(b, 1)),
            Cc: e.g(W(void 0), X(function() {
                return c.g(Un(cp(a), g), P(function(h) {
                    return h.map(function(l, m) {
                        return 0 < m ?
                            ep(l, h[m - 1]) : l
                    })
                }))
            }), P(dp), V(function(h, l) {
                return h.ja(l)
            }), Y(b, 1)),
            qc: f,
            jb: k.g(V(function(h, l) {
                return h.ja(l)
            }), Y(b, 1))
        }
    };

    function hp(a) {
        var b;
        if (b = ip(a)) b = !jp(a, "abgcp") && !jp(a, "abgc") && !("string" === typeof a.id && "abgb" === a.id) && !("string" === typeof a.id && "mys-abgc" === a.id) && !jp(a, "cbb");
        return b
    }

    function jp(a, b) {
        return a.classList ? a.classList.contains(b) : -1 < (" " + a.className + " ").indexOf(" " + b + " ")
    }

    function ip(a) {
        try {
            var b = a.getBoundingClientRect();
            return b && 30 <= b.height && 30 <= b.width
        } catch (c) {
            return !1
        }
    }

    function kp(a, b) {
        if (void 0 === a.j || !a.j.children) return a;
        for (var c = mb(a.j.children); c.length;) {
            var d = b ? c.filter(hp) : c.filter(ip);
            if (1 === d.length) return new Uh(d[0]);
            if (1 < d.length) break;
            c = pb(c, function(e) {
                return mb(e.children)
            })
        }
        return a
    }

    function lp(a, b, c, d, e) {
        if (c) return {
            Tc: b,
            vb: N(null)
        };
        c = b.element.g(P(function(f) {
            a: if (void 0 === f.j || ip(f.j)) f = {
                    pd: f,
                    vb: "mue"
                };
                else {
                    var g = kp(f, e);
                    if (void 0 !== g.j && ip(g.j)) f = {
                        pd: g,
                        vb: "ie"
                    };
                    else {
                        if (d || a.ue)
                            if (g = a.document.querySelector(".GoogleActiveViewInnerContainer")) {
                                f = {
                                    pd: new Uh(g),
                                    vb: "ce"
                                };
                                break a
                            }
                        f = {
                            pd: f,
                            vb: "mue"
                        }
                    }
                }return f
        }), wf());
        return {
            Tc: {
                xb: b.xb,
                element: c.g(P(function(f) {
                    return f.pd
                }))
            },
            vb: c.g(P(function(f) {
                return f.vb
            }))
        }
    };

    function mp(a, b, c, d) {
        var e = d.ad,
            f = d.je,
            g = d.Dg,
            k = d.mf,
            h = d.Ee,
            l = d.bg,
            m = d.dd,
            r = d.experimentState;
        b = np(a, c, b);
        c = op(a, c);
        d = pp(b, r);
        r = qp(a, e, l, d, r, b);
        var q = r.g(P(function(E) {
                return E.value
            }), V(), Y(a, 1), lf(function(E, B) {
                return Math.max(E, B)
            }, 0)),
            v = r.g(P(function(E) {
                return E.value
            }), Ko(), Y(a, 1)),
            w = b.g(so, P(function(E) {
                return E.value
            }), Qe(2), V(), Y(a, 1));
        g = rp(a, b, g, k);
        var A = g.g(W(!1), V(), P(function(E) {
            return E ? h : f
        }));
        k = r.g(Io(A), V(), Y(a, 1));
        var D = R([k, b]).g(T(function(E) {
            var B = t(E);
            E = B.next().value;
            B = B.next().value;
            return E.timestamp.equals(B.timestamp)
        }), P(function(E) {
            var B = t(E);
            E = B.next().value;
            B = B.next().value;
            return {
                visible: E.value,
                geometry: B.value.G
            }
        }), lf(function(E, B) {
            return !B.visible && E.visible ? E : B
        }, {
            visible: !1,
            geometry: li
        }), P(function(E) {
            return E.geometry
        }), W(li), Y(a, 1), V(mi));
        l = l instanceof L ? l.g(V(), hf()) : vd;
        A = R([l, A]).g(hf());
        var C = b.g(T(function(E) {
                return "ns" !== E.value.Y && "ns" !== E.value.R
            }), lf(function(E) {
                return E + 1
            }, 0), W(0), Y(a, 1)),
            S = c.g(hf(!0), W(!1), Y(a, 1));
        S = R([m, S]).g(P(function(E) {
            var B = t(E);
            E = B.next().value;
            B = B.next().value;
            return E && !B
        }), Y(a, 1));
        var pa = b.g(Po, V()),
            ia = pa.g(P(function(E) {
                return E.value
            }), lf(function(E, B) {
                return Math.max(E, B)
            }, 0), V(), Y(a, 1));
        a = pa.g(P(function(E) {
            return E.value
        }), Ko(), Y(a, 1));
        return {
            Re: l,
            zc: A,
            Ba: {
                yi: b,
                cg: b.g(Jo),
                Uc: D.g(V(mi)),
                visible: k.g(V(vo)),
                Ue: r.g(V(vo)),
                ag: q,
                bi: v,
                qf: b.g(Tn, V(nb)),
                Vi: pa,
                Uh: ia,
                ai: a,
                Zc: c,
                X: b.g(P(function(E) {
                    return E.value.X
                })),
                Uf: g,
                ad: e,
                dd: m,
                Hf: S,
                Xi: C,
                Rh: w,
                Ed: d
            }
        }
    }

    function op(a, b) {
        return b.g(T(function() {
            return !1
        }), P(function(c) {
            return c
        }), Ae(function(c) {
            return (new Z(c)).V(a)
        }))
    }

    function np(a, b, c) {
        return b.g(pf(vd), Y(a, 1)).g(V(function(d, e) {
            return vo(d, e, $n)
        }), W({
            timestamp: c.now(),
            value: Zn
        }), Y(a, 1))
    }

    function qp(a, b, c, d, e, f) {
        c = f.g(Oo(c), po(P(function(g) {
            return Cn(g)
        })), Y(a, 1));
        if (b instanceof Z) return c;
        e = e.g(P(function(g) {
            return g.M
        }));
        return R([c, b, d, e]).g(P(function(g) {
            var k = t(g);
            g = k.next().value;
            var h = k.next().value,
                l = k.next().value;
            k = 3 === k.next().value && 0 !== (l & 2);
            return {
                timestamp: h.timestamp.maximum(g.timestamp),
                value: h.value || k ? 0 : g.value
            }
        }), V(vo), Y(a, 1))
    }

    function rp(a, b, c, d) {
        b = [b.g(P(function(e) {
            return 242500 <= e.value.G.width * e.value.G.height
        }))];
        c instanceof L && b.push(c.g(P(function(e) {
            return !!e
        })));
        c = R(b);
        return d ? c.g(P(function(e) {
            return e.some(function(f) {
                return f
            })
        }), W(!1), V(), Y(a, 1)) : (new Z(!1)).V(a)
    }

    function pp(a, b) {
        b = b.g(P(function(d) {
            return d.M
        }));
        a = R([a, b]).g(P(function(d) {
            var e = t(d);
            d = e.next().value;
            e = e.next().value;
            if (0 !== e && 1 !== e && d.value.isIntersecting) return d.value.Xf
        }), V());
        b = a.g(P(function(d) {
            return void 0 === d ? !0 : d
        }), lf(function(d, e) {
            return d || !e
        }, !1));
        var c = a.g(lf(function(d, e) {
            return void 0 === e ? d : e ? !1 : null != d ? d : !0
        }, void 0), P(function(d) {
            return !!d
        }));
        return Bd(a, b, c).g(P(function(d) {
            var e = t(d);
            d = e.next().value;
            var f = e.next().value;
            e = e.next().value;
            var g = 0;
            if (void 0 === d) return 0;
            d &&
                (g |= 1);
            d || (g |= 2);
            f && (g |= 4);
            e && (g |= 8);
            return g
        }))
    };
    var sp = K(Mm("data-google-av-itpl"), P(function(a) {
        return Number(a)
    }), P(function(a) {
        return isNaN(a) ? 1 : a
    }));
    var tp = {
            aj: "addEventListener",
            jj: "getMaxSize",
            kj: "getScreenSize",
            lj: "getState",
            mj: "getVersion",
            xj: "removeEventListener",
            tj: "isViewable"
        },
        up = function(a, b) {
            this.xa = null;
            this.Ih = new M;
            b = b || this.Yi;
            var c = a.ue,
                d = !a.Gb;
            if (c && d) {
                var e = a.global.top.mraid;
                if (e) {
                    this.Rc = b(e);
                    this.xa = e;
                    this.wb = 3;
                    return
                }
            }(a = a.global.mraid) ? (this.Rc = b(a), this.xa = a, this.wb = c ? d ? 2 : 1 : 0) : (this.wb = -1, this.Rc = 2)
        };
    up.prototype.addEventListener = function(a, b) {
        return this.Rb("addEventListener", a, b)
    };
    up.prototype.removeEventListener = function(a, b) {
        return this.Rb("removeEventListener", a, b)
    };
    up.prototype.If = function() {
        var a = this.Rb("getVersion");
        return "string" === typeof a ? a : ""
    };
    up.prototype.getState = function() {
        var a = this.Rb("getState");
        return "string" === typeof a ? a : ""
    };
    var vp = function(a) {
            a = a.Rb("isViewable");
            return "boolean" === typeof a ? a : !1
        },
        wp = function(a) {
            if (a.xa) return a = a.xa.AFMA_LIDAR, "string" === typeof a ? a : void 0
        };
    up.prototype.Yi = function(a) {
        return a ? a.IS_GMA_SDK ? Object.values(tp).every(function(b) {
            return "function" === typeof a[b]
        }) ? 0 : 1 : 2 : 1
    };
    up.prototype.Rb = function(a) {
        var b = y.apply(1, arguments);
        if (this.xa) try {
            return this.xa[a].apply(this.xa, u(b))
        } catch (c) {
            this.Ih.next(a)
        }
    };
    da.Object.defineProperties(up.prototype, {
        yf: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                if (this.xa) {
                    var a = this.xa.AFMA_LIDAR_EXP_1;
                    return void 0 === a ? void 0 : !!a
                }
            },
            set: function(a) {
                this.xa && (this.xa.AFMA_LIDAR_EXP_1 = a)
            }
        }
    });

    function xp(a, b) {
        return -1 !== (new up(a)).wb ? (new Z(!0)).V(a.h) : b.g(Mm("data-google-av-inapp"), P(function(c) {
            return null !== c
        }), Y(a.h, 1))
    };
    var zp = function(a, b) {
            var c = this;
            this.i = a;
            this.Fe = this.md = null;
            this.Ci = b.g(V()).subscribe(function(d) {
                yp(c);
                c.Fe = d
            })
        },
        Ap = function(a, b) {
            yp(a);
            a.md = a.i.setTimeout(function() {
                var c;
                return void(null == (c = a.Fe) ? void 0 : c.next())
            }, b)
        },
        yp = function(a) {
            null !== a.md && a.i.clearTimeout(a.md);
            a.md = null
        };
    zp.prototype.ba = function() {
        yp(this);
        this.Ci.unsubscribe();
        this.Fe = null
    };

    function Bp(a, b, c, d, e) {
        var f = $o.xg;
        var g = void 0 === g ? new zp(b, d) : g;
        return (new L(function(k) {
            var h = c.g(W(void 0), X(function() {
                return Cp(e)
            })).g(P(function(l) {
                var m = l.value;
                l = l.timestamp;
                var r = m.visible;
                m = m.jb;
                var q = m >= f;
                q || !r ? yp(g) : (l = Math.max(0, me(b.now(), l)), Ap(g, Math.max(0, f - m - l)));
                return q
            }), lf(function(l, m) {
                return m || l
            }, !1), V()).subscribe(k);
            return function() {
                g.ba();
                h.unsubscribe()
            }
        })).g(Cf(function(k) {
            return !k
        }, !0), Y(a, 1))
    }

    function Cp(a) {
        return Fn([a, a.g(Vn())]).g(P(function(b) {
            var c = t(b);
            b = c.next().value;
            c = c.next().value;
            return {
                timestamp: b.timestamp,
                value: {
                    visible: b.value,
                    jb: c.value
                }
            }
        }), V(function(b, c) {
            return vo(b, c, function(d, e) {
                return d.jb === e.jb && d.visible === e.visible
            })
        }))
    };

    function Dp(a, b) {
        return {
            Qd: b.g(Mm("data-google-av-adk")),
            Oc: b.g(Mm("data-google-av-btr"), V(), P(function(c) {
                return null === c ? [] : c.split("|").filter(function(d) {
                    return "" !== d
                })
            })),
            Zd: b.g(Mm("data-google-av-cpmav"), V(), P(function(c) {
                return null === c ? [] : c.split("|").filter(function(d) {
                    return "" !== d
                })
            })),
            af: b.g(Mm("data-google-av-vrus"), V(), P(function(c) {
                return null === c ? [] : c.split("|").filter(function(d) {
                    return "" !== d
                })
            })),
            fh: sn(a, b),
            flags: b.g(Mm("data-google-av-flags"), V()),
            Za: xp(a, b),
            ze: b.g(Jn("cr", function(c) {
                return "1" ===
                    c
            }), V()),
            Oh: b.g(Jn("omid", function(c) {
                return "1" === c
            }), V()),
            we: b.g(sp),
            metadata: b.g(Mm("data-google-av-metadata")),
            Ta: b.g(Tm),
            Ga: b.g(Nm),
            Zi: b.g(Jn("la", function(c) {
                return "1" === c
            }), V()),
            ob: b.g(Mm("data-google-av-turtlex"), P(function(c) {
                return null !== c
            }), V()),
            Ce: b.g(Mm("data-google-av-vattr"), P(function(c) {
                return null !== c
            }), V())
        }
    };

    function Ep() {
        return K(In(), lf(function(a, b) {
            return Math.max(a, b)
        }, 0), P(function(a) {
            return Math.round(a)
        }))
    };

    function Fp(a) {
        return K(Io(N(a)), Ep())
    };

    function Gp(a, b, c, d, e) {
        c = c.g(P(function() {
            return !1
        }));
        d = R([e, d]).g(X(function(f) {
            f = t(f).next().value;
            return Hp(b, f)
        }));
        return td(N(!1), c, d).g(V(), Y(a.h, 1))
    }

    function Hp(a, b) {
        return a.g(P(function(c) {
            return b || 0 === c || 2 === c
        }))
    };
    var Ip = [33, 32],
        Jp = K(sp, P(function(a) {
            return 0 <= Ip.indexOf(a)
        }), V());

    function Kp(a, b, c, d, e, f) {
        var g = c.g(P(function(h) {
                return 9 === h
            })),
            k = b.element.g(Jp);
        c = e.g(T(function(h) {
            return h
        }), X(function() {
            return R([g, k])
        }), P(function(h) {
            h = t(h);
            var l = h.next().value;
            return !h.next().value || l
        }), V());
        f = R([c, d.g(V()), f]).g(P(function(h) {
            var l = t(h);
            h = l.next().value;
            var m = l.next().value;
            l = l.next().value;
            return lp(a, b, !h, m, l)
        }), tf(1), Cc());
        d = f.g(P(function(h) {
            return h.Tc
        }));
        f = f.g(X(function(h) {
            return h.vb
        }), W(null), V(), Y(a.h, 1));
        return {
            Pa: d,
            bc: f
        }
    };

    function Lp(a) {
        var b = void 0 === b ? !1 : b;
        return K(X(function(c) {
            return ji(a.document, c, b)
        }), Y(a.h, 1))
    };
    var Mp = function(a, b, c, d, e, f) {
        this.oc = b.element.g(Lp(a), Y(a.h, 1));
        this.rg = Gp(a, c, b.element, this.oc, d);
        c = Kp(a, b, e, d, this.rg, f);
        d = c.bc;
        this.Pa = c.Pa;
        this.bc = d;
        this.bf = td((new Z(1)).V(a.h), b.element.g(Qe(1), P(function() {
            return 2
        }), Y(a.h, 1)), this.oc.g(Qe(1), P(function() {
            return 3
        }), Y(a.h, 1)), this.rg.g(T(Boolean), Qe(1), P(function() {
            return 0
        }), Y(a.h, 1))).g(Cf(function(g) {
            return 0 !== g
        }, !0), Y(a.h, 0))
    };

    function Np(a, b) {
        return a && 0 === b ? 15 : a || 1 !== b ? null : 14
    }

    function Op(a, b, c) {
        return b instanceof L ? b.g(X(function(d) {
            return (d = Np(d, c)) ? wc(new Wd(d)) : a
        })) : (b = Np(b.value, c)) ? wc(new Wd(b)) : a
    };

    function Pp(a) {
        var b = new Wd(13);
        if (1 > a.length) return {
            sf: rc,
            Vd: rc
        };
        var c = new M;
        return {
            sf: a.slice(1).reduce(function(d, e) {
                return d.g(Ae(function(f) {
                    c.next(f);
                    return e
                }))
            }, a[0]).g(Ae(function(d) {
                c.next(d);
                return wc(b)
            }), of (new M), Cc()),
            Vd: c
        }
    };
    var Qp = function() {};
    var Rp = function(a, b) {
        this.context = a;
        this.Pi = b
    };
    x(Rp, Qp);
    Rp.prototype.Xa = function(a, b) {
        var c = this.Pi.map(function(f) {
                return f.Xa(a, b)
            }),
            d = Pp(c.map(function(f) {
                return f.Ya
            })),
            e = d.Vd.g(Sp());
        return {
            Ya: d.sf.g(Y(this.context.h, 1)),
            Va: Object.assign.apply(Object, [{
                Se: e,
                Rj: d.Vd
            }].concat(u(c.map(function(f) {
                return f.Va
            }))))
        }
    };
    var Sp = function() {
        return lf(function(a, b) {
            b instanceof Wd ? a.push(b.Xh) : a.push(-1);
            return a
        }, [])
    };

    function Tp(a, b) {
        var c = a.g( of (new M), Cc());
        return X(function(d) {
            return c.g(b(d))
        })
    };

    function Up(a, b) {
        var c = void 0 === c ? function() {
            var f = (yh(a.global) ? a.global.innerWidth : 0) || a.qe() || 0,
                g = (yh(a.global) ? a.global.innerHeight : 0) || a.ne() || 0;
            return {
                left: 0,
                top: 0,
                width: f,
                height: g
            }
        } : c;
        var d = a.Gb ? ii(a.document) ? a.Nh ? null : wc(new Wd(5)) : wc(new Wd(4)) : wc(new Wd(3));
        if (d) return d;
        var e = new M;
        return td(N({}), b, e).g(P(function() {
            var f = Vp(a, c);
            return {
                timestamp: a.i.now(),
                value: {
                    Y: "iem",
                    ca: f,
                    P: f,
                    X: e,
                    ea: {
                        x: 0,
                        y: 0
                    }
                }
            }
        }), Y(a.h, 1))
    }

    function Vp(a, b) {
        b = b();
        var c = th(document),
            d = function(q, v) {
                return !!a.document.elementFromPoint(q, v)
            },
            e = Math.floor(b.left - c.x),
            f = Math.floor(b.top - c.y),
            g = Math.floor(b.left + b.width - c.x),
            k = Math.floor(b.top + b.height - c.y);
        b = d(e, f);
        c = d(g, k);
        if (b && c) return {
            top: f,
            left: e,
            width: g - e,
            height: k - f
        };
        var h = d(g, f),
            l = d(e, k);
        if (b) k = Wp(f, k, function(q) {
            return d(e, q)
        }), g = Wp(e, g, function(q) {
            return d(q, f)
        });
        else if (h) k = Wp(f, k, function(q) {
            return d(g, q)
        }), e = Wp(g, e, function(q) {
            return d(q, f)
        });
        else if (l) f = Wp(k, f, function(q) {
            return d(e,
                q)
        }), g = Wp(e, g, function(q) {
            return d(q, k)
        });
        else if (c) f = Wp(k, f, function(q) {
            return d(g, q)
        }), e = Wp(g, e, function(q) {
            return d(q, k)
        });
        else {
            var m = Math.floor((e + g) / 2),
                r = Math.floor((f + k) / 2);
            if (!d(m, r)) return {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            };
            f = Wp(r, f, function(q) {
                return d(m, q)
            });
            k = Wp(r, k, function(q) {
                return d(m, q)
            });
            e = Wp(m, e, function(q) {
                return d(q, r)
            });
            g = Wp(m, g, function(q) {
                return d(q, r)
            })
        }
        return {
            top: f,
            left: e,
            width: g - e,
            height: k - f
        }
    }

    function Wp(a, b, c) {
        if (c(b)) return b;
        for (var d = 15; d--;) {
            var e = Math.floor((a + b) / 2);
            if (e === a || e === b) break;
            c(e) ? a = e : b = e
        }
        return a
    };
    var Xp = function(a, b) {
        this.context = a;
        this.Ra = b
    };
    x(Xp, Qp);
    Xp.prototype.Xa = function(a, b) {
        var c = Tp(Up(this.context, this.Ra), bo(this.context, b.Ta));
        return {
            Ya: Op(a.Pa.g(c), b.Za, 0),
            Va: {}
        }
    };

    function Yp(a, b) {
        if (a.Gb) return wc(new Wd(6));
        var c = new M;
        return td(N({}), b, c).g(P(function() {
            return {
                timestamp: a.i.now(),
                value: {
                    Y: "geo",
                    ca: Zp(a),
                    P: Em(a, !0),
                    X: c,
                    ea: {
                        x: 0,
                        y: 0
                    }
                }
            }
        }), Gh(a.h))
    }

    function Zp(a) {
        var b = Em(a, !1);
        if (!a.ue || !yh(a.global.parent) || a.global.parent === a.global) return b;
        var c = new Bm(a.global.parent, a.Ka);
        c.H = a.H;
        c = Zp(c);
        a = a.global.frameElement.getBoundingClientRect();
        return ni(oi(ni(c, a), {
            x: b.left - a.left,
            y: b.top - a.top
        }), b)
    };
    var $p = function(a, b) {
        this.context = a;
        this.Ra = b
    };
    x($p, Qp);
    $p.prototype.Xa = function(a, b) {
        var c = Tp(Yp(this.context, this.Ra), bo(this.context, b.Ta));
        return {
            Ya: Op(a.Pa.g(c), b.Za, 0),
            Va: {}
        }
    };
    var aq = function(a, b, c) {
        c = void 0 === c ? ho(a, b) : c;
        this.context = a;
        this.Lh = c
    };
    x(aq, Qp);
    aq.prototype.Xa = function(a, b) {
        var c = this.Lh(b.experimentState);
        return {
            Ya: Op(a.Pa.g(c, lo(this.context)), b.Za, 0),
            Va: {}
        }
    };

    function bq(a, b, c, d, e) {
        var f = void 0 === f ? new up(a) : f;
        var g = void 0 === g ? Qf(a.i, 500) : g;
        var k = void 0 === k ? Qf(a.i, 100) : k;
        e = N(f).g(cq(c), Ff(function(h) {
            d.next(h.wb)
        }), dq(a, k), eq(a), fq(a, e), tf(1), Cc());
        f = new M;
        b = td(N({}), b, f);
        return e.g(gq(a, f, b, g, c), Y(a.h, 1))
    }

    function fq(a, b) {
        return K(function(c) {
            return R([c, b])
        }, Ge(function(c) {
            c = t(c);
            var d = c.next().value;
            return 9 !== c.next().value || vp(d) ? N(!0) : hq(a, d, "viewableChange").g(T(function(e) {
                return t(e).next().value
            }), Qe(1))
        }), P(function(c) {
            return t(c).next().value
        }))
    }

    function cq(a) {
        return X(function(b) {
            if (-1 === b.wb) return a.next("if"), wc(new Wd(7));
            if (0 !== b.Rc) switch (b.Rc) {
                case 1:
                    return a.next("mm"), wc(new Wd(18));
                case 2:
                    return a.next("ng"), wc(new Wd(17));
                default:
                    return a.next("i"), wc(new Wd(8))
            }
            return N(b)
        })
    }

    function dq(a, b) {
        return Ge(function() {
            var c = a.eg;
            return "complete" === gi(a.document) ? N(!0) : c.g(Ge(function() {
                return b
            }))
        })
    }
    var eq = function(a) {
        return X(function(b) {
            return "loading" !== b.getState() ? N(b) : hq(a, b, "ready").g(P(function() {
                return b
            }))
        })
    };

    function gq(a, b, c, d, e) {
        return X(function(f) {
            var g = wp(f);
            if ("string" !== typeof g) return e.next("nc"), wc(new Wd(9));
            void 0 !== f.yf && (f.yf = !0);
            g = hq(a, f, g, iq);
            var k = {
                version: f.If(),
                wb: f.wb
            };
            g = g.g(P(function(l) {
                return jq.apply(null, [a, b, f, k].concat(u(l)))
            }));
            var h = d.g(Ff(function() {
                e.next("mt")
            }), X(function() {
                return wc(new Wd(10))
            }));
            g = yd(g, h);
            return R([g, c]).g(P(function(l) {
                l = t(l).next().value;
                return Object.assign({}, l, {
                    timestamp: a.i.now()
                })
            }))
        })
    }

    function iq(a, b) {
        return (null === b || "number" === typeof b) && (null === a || !!a && "number" === typeof a.height && "number" === typeof a.width && "number" === typeof a.x && "number" === typeof a.y)
    }

    function jq(a, b, c, d, e, f) {
        e = e ? {
            left: e.x,
            top: e.y,
            width: e.width,
            height: e.height
        } : li;
        c = c.Rb("getMaxSize");
        var g = null != c && "number" === typeof c.width && "number" === typeof c.height ? c : {
            width: 0,
            height: 0
        };
        c = {
            left: 0,
            top: 0,
            width: -1,
            height: -1
        };
        if (g) {
            var k = Number(String(g.width));
            g = Number(String(g.height));
            c = isNaN(k) || isNaN(g) ? c : {
                left: 0,
                top: 0,
                width: k,
                height: g
            }
        }
        a = {
            value: {
                ca: e,
                P: c,
                Y: "mraid",
                X: b,
                ea: {
                    x: 0,
                    y: 0
                }
            },
            timestamp: a.i.now()
        };
        return Object.assign({}, a, d, {
            Cj: f
        })
    }

    function hq(a, b, c, d) {
        d = void 0 === d ? function() {
            return !0
        } : d;
        return (new L(function(e) {
            var f = a.B.Ub(745, function() {
                e.next(y.apply(0, arguments))
            });
            b.addEventListener(c, f);
            return function() {
                b.removeEventListener(c, f)
            }
        })).g(T(function(e) {
            return d.apply(null, u(e))
        }))
    };
    var kq = function(a, b) {
        this.context = a;
        this.Ra = b
    };
    x(kq, Qp);
    kq.prototype.Xa = function(a, b) {
        var c = new yc(1),
            d = new yc(1),
            e = Tp(bq(this.context, this.Ra, c, d, b.Ta), bo(this.context, b.Ta));
        return {
            Ya: Op(a.Pa.g(e), b.Za, 1),
            Va: {
                Ge: c.g(Y(this.context.h, 1)),
                He: d.g(Y(this.context.h, 1))
            }
        }
    };

    function lq(a) {
        return ["backgrounded", "notFound", "hidden", "noOutputDevice"].includes(a)
    };

    function mq() {
        var a = Error;
        return fm(function(b) {
            return b instanceof a
        }, function() {
            return em(a)
        })
    };

    function nq(a, b) {
        var c = void 0 === c ? null : c;
        var d = new M,
            e = void 0,
            f = a.le,
            g = d.g(P(function() {
                return e ? Object.assign({}, e, {
                    timestamp: a.i.now()
                }) : null
            }), T(function(h) {
                return null !== h
            }), P(function(h) {
                return h
            }));
        b = R([td(f, g), b]);
        var k = c;
        return b.g(T(function(h) {
            h = t(h).next().value;
            null === k && (k = h.value.Rg);
            return h.value.Rg === k
        }), Ff(function(h) {
            return void(e = t(h).next().value)
        }), P(function(h) {
            var l = t(h);
            h = l.next().value;
            l = l.next().value;
            try {
                var m = h.value.data,
                    r = h.timestamp,
                    q = m.viewport,
                    v, w, A = Object.assign({},
                        q, {
                            width: null != (v = null == q ? void 0 : q.width) ? v : 0,
                            height: null != (w = null == q ? void 0 : q.height) ? w : 0,
                            x: 0,
                            y: 0,
                            Mj: q ? q.width * q.height : 0
                        }),
                    D = oq(A),
                    C = m.adView,
                    S = C.measuringElement && C.containerGeometry ? oq(C.containerGeometry) : oq(C.geometry),
                    pa = oq(C.geometry),
                    ia = C.reasons.some(lq),
                    E = ia ? li : oq(C.onScreenGeometry),
                    B;
                l && (B = C.percentageInView / 100);
                l && ia && (B = 0);
                return {
                    timestamp: r,
                    value: {
                        Y: "omid",
                        ca: S,
                        P: D,
                        X: d,
                        R: "omid",
                        G: pa,
                        ea: {
                            x: S.left,
                            y: S.top
                        },
                        T: E,
                        Yc: B
                    }
                }
            } catch (Qb) {
                w = Qb;
                m = mq();
                r = gm;
                gm = void 0;
                q = [];
                v = m(w, q);
                !v && q && (w = "Expected " +
                    m.Jf() + ", got " + dm(w), q.push(w));
                v || hm.apply(null, [void 0, r, "Guard " + m.Jf() + " failed:"].concat(u(q.reverse())));
                var U, ub;
                m = null != (ub = null == (U = Qb) ? void 0 : U.message) ? ub : "An unknown error occurred";
                U = "Error while processing geometryChange event: " + JSON.stringify(h.value) + "; " + m;
                throw Error(U);
            }
        }), tf(1), Cc())
    }

    function oq(a) {
        var b, c, d, e;
        return {
            left: Math.floor(null != (b = null == a ? void 0 : a.x) ? b : 0),
            top: Math.floor(null != (c = null == a ? void 0 : a.y) ? c : 0),
            width: Math.floor(null != (d = null == a ? void 0 : a.width) ? d : 0),
            height: Math.floor(null != (e = null == a ? void 0 : a.height) ? e : 0)
        }
    };

    function pq(a, b, c, d) {
        c = void 0 === c ? vd : c;
        var e = a.h;
        if (null === b) return wc(new Wd(20));
        if (!b.validate()) return wc(new Wd(21));
        var f;
        d = qq(e, b, d).g(P(function(g) {
            var k = g.value;
            g = g.timestamp;
            var h = b.i,
                l = a.i;
            if (h.timeline !== g.timeline) throw new ae;
            g = new ke(g.value - h.now().value + l.now().value, l.timeline);
            return f = {
                value: k,
                timestamp: g
            }
        }));
        return td(d, c.g(P(function() {
            return f
        }))).g(T(function(g) {
            return void 0 !== g
        }), P(function(g) {
            return g
        }), Y(a.h, 1))
    }

    function qq(a, b, c) {
        return nq(b, c).g(Y(a, 1), P(function(d) {
            return {
                timestamp: d.timestamp,
                value: {
                    ea: {
                        x: d.value.G.left,
                        y: d.value.G.top
                    },
                    ca: d.value.T,
                    P: d.value.P,
                    Y: d.value.R,
                    X: d.value.X
                }
            }
        }))
    };
    var rq = function(a, b, c) {
        this.rb = a;
        this.Z = b;
        this.Ra = c
    };
    x(rq, Qp);
    rq.prototype.Xa = function(a, b) {
        var c = b.Ta;
        b = pq(this.Z, this.rb, this.Ra, b.dg);
        c = Tp(b, bo(this.Z, c));
        return {
            Ya: a.Pa.g(c),
            Va: {}
        }
    };
    var sq = function(a, b, c) {
        this.rb = a;
        this.Z = b;
        this.ph = c
    };
    x(sq, Qp);
    sq.prototype.Xa = function(a, b) {
        var c = pq(this.Z, this.rb, void 0, b.dg);
        b = ko(this.Z, b.experimentState, this.ph);
        c = Tp(c, b);
        return {
            Ya: a.Pa.g(c),
            Va: {}
        }
    };

    function tq(a) {
        return a.document.ni.g(P(function(b) {
            return "visible" === b
        }), V(), Y(a.h, 1))
    };
    var uq;
    uq = ["av.key", "js", "20231116"].slice(-1)[0].substring(0, 8);

    function vq(a, b, c) {
        var d;
        return b.g(V(), X(function(e) {
            return c.g(P(function() {
                if (!d) {
                    d = !0;
                    try {
                        e.next()
                    } finally {
                        d = !1
                    }
                }
                return !0
            }))
        }), W(!1), Y(a.h, 1))
    };

    function wq(a) {
        return K(po(P(function(b) {
            return Ho(b, a)
        })), Hn(), P(function(b) {
            return Math.round(b)
        }))
    };

    function xq(a, b, c, d, e) {
        var f = gp;
        if (1 < f.length)
            for (var g = 0; g < f.length - 1; g++)
                if (f[g] < f[g + 1]) throw Error();
        g = e.g(W(void 0), X(function() {
            return c.g(Vn())
        }), V(), Y(a, 1));
        e = e.g(W(void 0), X(function() {
            return c.g(Ep())
        }), V(), Y(a, 1));
        return {
            rc: d.g(W(void 0), X(function() {
                return b.g(Un(Fp, f))
            }), V(nb), Y(a, 1)),
            Cc: d.g(W(void 0), X(function() {
                return b.g(Un(wq, f), P(function(k) {
                    return k.map(function(h, l) {
                        return 0 < l ? h - k[l - 1] : h
                    })
                }))
            }), V(nb), Y(a, 1)),
            qc: e,
            jb: g.g(V(vo), Y(a, 1))
        }
    };

    function yq(a, b, c) {
        var d = c.g(P(function(e) {
            return {
                value: e,
                timestamp: a.i.now()
            }
        }), V(vo));
        return b instanceof L ? b.g(V(), X(function(e) {
            return e ? (new Z({
                value: !1,
                timestamp: a.i.now()
            })).V(a.h) : d
        })) : !1 === b.value ? d : new Z(!1)
    }

    function zq(a, b, c, d, e, f, g) {
        var k = $o;
        b = b instanceof L ? b.g(W(!1), V()) : b;
        var h = !(wh() || xh());
        c = yq(a, c, d);
        a = f.Pa.g(En(a.h));
        return Object.assign({}, k, {
            ad: c,
            Dg: e,
            mf: h,
            bg: b,
            dd: a,
            experimentState: g
        })
    };

    function Aq(a) {
        a = a.global;
        if ("undefined" === typeof a.__google_lidar_) return a.__google_lidar_ = 1, !1;
        a.__google_lidar_ = Number(a.__google_lidar_) + 1;
        var b = a.__google_lidar_adblocks_count_;
        if ("number" === typeof b && 0 < b && (a = a.__google_lidar_radf_, "function" === typeof a)) try {
            a()
        } catch (c) {}
        return !0
    }

    function Bq(a) {
        var b = a.global;
        b.osdlfm = function() {
            return b.__google_lidar_radf_
        };
        if (void 0 !== b.__google_lidar_radf_) return rc;
        b.__google_lidar_adblocks_count_ = 1;
        var c = new M;
        b.__google_lidar_radf_ = function() {
            return void c.next(a)
        };
        return c.g(Rg(a.B, 743))
    };
    var Cq = function(a) {
        var b = this;
        this.Be = !1;
        this.Le = [];
        this.Ke = [];
        a(function(c) {
            b.Be = !0;
            b.Di = c;
            b.evaluate()
        }, function(c) {
            b.zi = c;
            b.evaluate()
        })
    };
    Cq.prototype.evaluate = function() {
        var a = this.Di,
            b = this.zi;
        if (void 0 !== b || this.Be) this.Be && this.Le.forEach(function(c) {
            return void c(a)
        }), void 0 !== b && this.Ke.forEach(function(c) {
            return void c(b)
        }), this.Le = [], this.Ke = []
    };
    Cq.prototype.then = function(a) {
        this.Le.push(a);
        this.evaluate();
        return this
    };
    Cq.prototype.catch = function(a) {
        this.Ke.push(a);
        this.evaluate();
        return this
    };
    var Dq = function(a) {
        this.children = a;
        this.mb = !1;
        this.Wd = []
    };
    Dq.prototype.complete = function() {
        var a = this;
        this.mb = !0;
        this.Wd.forEach(function(b) {
            return void b(a)
        });
        this.Wd.splice(0)
    };
    Dq.prototype.onComplete = function(a) {
        this.mb ? a(this) : this.Wd.push(a)
    };
    Dq.prototype.hb = function(a) {
        var b = this.children.map(function(c) {
            return c.hb(a)
        });
        return void 0 === b.find(function(c) {
            return 2 !== c
        }) ? 2 : this.ia ? 0 : b.some(function(c) {
            return 1 === c
        }) ? 1 : 0
    };
    da.Object.defineProperties(Dq.prototype, {
        ia: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.mb
            }
        }
    });
    var Eq = function() {
        var a = y.apply(0, arguments);
        Dq.call(this, a);
        var b = this;
        this.events = a;
        var c = this.events.length;
        this.events.forEach(function(d) {
            d.onComplete(function() {
                0 === --c && b.complete()
            })
        })
    };
    x(Eq, Dq);
    Eq.prototype.clone = function() {
        return new(Function.prototype.bind.apply(Eq, [null].concat(u(this.events.map(function(a) {
            return a.clone()
        })))))
    };
    Eq.prototype.Ve = function(a, b) {
        var c = this;
        if (!this.ia) {
            var d = this.events.find(function(e) {
                return 1 === e.hb(a)
            });
            void 0 !== d && d.Ve(a, function() {
                c.ia || b()
            })
        }
    };
    var Fq = function(a, b) {
        Dq.call(this, []);
        this.ge = a;
        this.jd = Symbol(b);
        this.oi = a
    };
    x(Fq, Dq);
    Fq.prototype.clone = function() {
        var a = new Fq(this.oi, this.jd.description);
        a.jd = this.jd;
        return a
    };
    Fq.prototype.hb = function(a) {
        return a !== this.event ? 2 : this.ia || 0 === this.ge ? 0 : 1
    };
    Fq.prototype.Ve = function(a, b) {
        1 === this.hb(a) && (this.ge--, b(), 0 === this.ge && this.complete())
    };
    da.Object.defineProperties(Fq.prototype, {
        event: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.jd
            }
        }
    });
    var Gq = function(a) {
        Fq.call(this, 1, a)
    };
    x(Gq, Fq);
    var Hq = function(a, b, c) {
        var d = y.apply(3, arguments);
        this.Sc = a;
        this.mh = b;
        this.be = c;
        this.pc = new Set;
        this.Kb = d;
        if (!this.Sc.Z) throw Error("va");
        this.context = this.Sc.Z;
        var e = d.reduce(function(k, h) {
            h.subscribedEvents.forEach(function(l) {
                return void k.add(l)
            });
            return k
        }, new Set);
        e = t(e.values());
        for (var f = e.next(), g = {}; !f.done; g = {
                ie: g.ie
            }, f = e.next()) {
            g.ie = f.value;
            f = d.filter(function(k) {
                return function(h) {
                    return 0 <= h.controlledEvents.indexOf(k.ie)
                }
            }(g));
            if (0 === f.length) throw Error("wa");
            if (1 < f.length) throw Error("xa");
        }
    };
    Hq.prototype.start = function() {
        var a = this;
        this.Kb.forEach(function(b) {
            return void b.start(a.Sc)
        });
        this.be.start(this.Sc, this.xh.bind(this), this.hc.bind(this), function() {})
    };
    Hq.prototype.ba = function() {
        var a = this;
        this.be.ba();
        this.pc.forEach(function(b) {
            return void a.hc(b)
        });
        this.Kb.forEach(function(b) {
            return void b.ba()
        })
    };
    var Iq = function(a, b) {
        b = {
            measuringCreativeIds: [].concat(u(a.pc.values())).map(function(c) {
                return a.context.dc.Na(c)
            }),
            hasCreativeSourceCompleted: !!a.be.vd,
            colleagues: a.Kb.map(function(c) {
                return {
                    name: c.name,
                    controlledEvents: c.controlledEvents.map(function(d) {
                        var e;
                        return null != (e = d.description) ? e : "n/a"
                    }),
                    subscribedEvents: c.subscribedEvents.map(function(d) {
                        var e;
                        return null != (e = d.description) ? e : "n/a"
                    })
                }
            }),
            ephemeralCreativeStateChanges: b
        };
        b = {
            specMajor: 2,
            specMinor: 0,
            specPatch: 0,
            instanceId: a.context.dc.Na(a.context.xb),
            timestamp: me(a.context.i.now(), new ke(0, a.context.i.timeline)),
            mediatorState: b
        };
        Ud(a.context, b)
    };
    Hq.prototype.xh = function(a, b, c) {
        var d = this;
        if (!this.pc.has(a)) {
            var e = this.mh.clone();
            this.pc.add(a);
            Iq(this, {});
            this.Kb.forEach(function(f) {
                f.Lf(a, b, c, function(g, k, h) {
                    var l = d.context.dc.Na(a),
                        m = me(d.context.i.now(), new ke(0, d.context.i.timeline)),
                        r, q = null != (r = g.description) ? r : "n/a";
                    if (0 > f.controlledEvents.indexOf(g) || 1 !== e.hb(g)) return h(!1), r = {}, Iq(d, (r[l] = {
                        events: [{
                            timestamp: m,
                            description: q,
                            status: 1
                        }]
                    }, r)), new Cq(function(w) {
                        return void w()
                    });
                    var v = new Cq(function(w) {
                        e.Ve(g, function() {
                            d.Kb.filter(function(A) {
                                return 0 <=
                                    A.subscribedEvents.indexOf(g)
                            }).forEach(function(A) {
                                return void A.handleEvent(a, g, k)
                            });
                            w()
                        })
                    });
                    return new Cq(function(w) {
                        v.then(function() {
                            h(!0);
                            var A = {};
                            Iq(d, (A[l] = {
                                events: [{
                                    timestamp: m,
                                    description: q,
                                    status: 2
                                }]
                            }, A));
                            w()
                        })
                    })
                })
            })
        }
    };
    Hq.prototype.hc = function(a) {
        this.pc.delete(a);
        this.Kb.forEach(function(b) {
            b.hc(a)
        });
        Iq(this, {})
    };
    var Jq = function(a) {
            this.key = a;
            this.defaultValue = !1;
            this.valueType = "boolean"
        },
        Kq = function(a) {
            this.key = a;
            this.defaultValue = 0;
            this.valueType = "number"
        };
    var Lq = new Jq("45430027"),
        Mq = new Jq("100006"),
        Nq = new Kq("45362137"),
        Oq = new Jq("45377435"),
        Pq = new Kq("45411635"),
        Qq = new Jq("45372163"),
        Rq = new Jq("45407241"),
        Sq = new Jq("45382077"),
        Tq = new Jq("45407239"),
        Uq = new Jq("45407240"),
        Vq = new Jq("45427308");
    var Wq = new Kq("45389692");
    var xk = function(a) {
        im.call(this, a)
    };
    x(xk, im);
    xk.prototype.me = function() {
        return Dk(this, 4, !0)
    };
    xk.Ca = "ads.branding.measurement.client.serving.integrations.active_view.ActiveViewMetadata";
    var Xq = [0, Yl, -2, Xl];
    xk.makeCrossSerializerComparisonsCompatible = jm(xk, Xq);
    var Yq = [0, Ul, -3];
    var Zq = [0, Sl, Ul, -1, bm, Rl, Sl];
    var $q = function(a) {
        im.call(this, a)
    };
    x($q, im);
    $q.prototype.getType = function() {
        var a = 0;
        a = void 0 === a ? 0 : a;
        var b = nk(this, 6);
        b = null == b ? b : Number.isFinite(b) ? b | 0 : void 0;
        return Ck(b, a)
    };
    $q.Ca = "ads.geo.GeoTargetMessage";
    $q.kg = [17, 18];
    var ar = [0, $l, -4, bm, Xl, Ul, Rl, $l, Rl, $l, Ul, $l, -1, Yq, am, Tl, $l, Sl, -1, Ul, -1, Sl, Rl, Zq];
    $q.makeCrossSerializerComparisonsCompatible = jm($q, ar);
    var br = function(a) {
        im.call(this, a)
    };
    x(br, im);
    br.prototype.me = function() {
        return Dk(this, 3, !0)
    };
    br.Ca = "ads.branding.measurement.client.serving.integrations.reach.ReachMetadata";
    var cr = [0, Yl, -1, Xl, ar];
    br.makeCrossSerializerComparisonsCompatible = jm(br, cr);
    var dr = function(a) {
        im.call(this, a)
    };
    x(dr, im);
    dr.Ca = "ads.branding.measurement.client.serving.IntegratorMetadata";
    var er = [0, cr, Xq],
        fr = function(a, b) {
            return function(c, d) {
                a: {
                    if ($k.length) {
                        var e = $k.pop();
                        Yk(e, d);
                        Ok(e.l, c, d);
                        c = e
                    } else c = new Zk(c, d);
                    try {
                        var f = new a,
                            g = f.u;
                        pl(b)(g, c);
                        sj && delete g[sj];
                        var k = f;
                        break a
                    } finally {
                        c.Ef()
                    }
                    k = void 0
                }
                return k
            }
        }(dr, er);
    dr.makeCrossSerializerComparisonsCompatible = jm(dr, er);
    var gr = function() {
            this.Df = {}
        },
        hr = function(a, b) {
            a = a.Df[b.key];
            if ("proto" === b.valueType) {
                try {
                    var c = JSON.parse(a);
                    if (Array.isArray(c)) return c
                } catch (d) {}
                return b.defaultValue
            }
            return typeof a === typeof b.defaultValue ? a : b.defaultValue
        };
    var ir = function() {
        this.vf = new Map
    };
    ir.prototype.start = function(a, b, c, d) {
        var e = this;
        if (void 0 === this.vd && a.Z) {
            var f = a.Z;
            this.tf = d;
            a = Aq(f);
            c = Bq(f);
            c = Wm(f, c);
            this.vd = (a ? rc : c.g(P(function(g) {
                var k = void 0 === k ? Symbol() : k;
                return Object.freeze({
                    xb: k,
                    element: (new Z(g)).V(f.h)
                })
            }), Om())).subscribe(function(g) {
                var k = g.xb;
                e.vf.set(k, g);
                g.element.g(Qe(1)).subscribe(function(h) {
                    var l = Lm(h, "data-google-av-flags"),
                        m = new gr;
                    if (null !== l) try {
                        var r = JSON.parse(l)[0];
                        l = "";
                        for (var q = 0; q < r.length; q++) l += String.fromCharCode(r.charCodeAt(q) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(q %
                            10));
                        m.Df = JSON.parse(l)
                    } catch (Fa) {}
                    var v, w, A, D, C, S, pa, ia, E, B, U, ub;
                    r = {
                        Zg: null != (v = null == m ? void 0 : hr(m, Mq)) ? v : !1,
                        sh: null != (w = null == m ? void 0 : hr(m, Nq)) ? w : 0,
                        th: null != (A = null == m ? void 0 : hr(m, Oq)) ? A : !1,
                        Gi: null != (D = null == m ? void 0 : hr(m, Qq)) ? D : !1,
                        Ni: null != (C = null == m ? void 0 : hr(m, Sq)) ? C : !1,
                        eh: null != (S = null == m ? void 0 : hr(m, Wq)) ? S : 0,
                        Wi: null != (pa = null == m ? void 0 : hr(m, Tq)) ? pa : !1,
                        Ag: null != (ia = null == m ? void 0 : hr(m, Uq)) ? ia : !1,
                        Ii: null != (E = null == m ? void 0 : hr(m, Rq)) ? E : !1,
                        M: null != (B = null == m ? void 0 : hr(m, Pq)) ? B : 0,
                        Tj: null != (U =
                            null == m ? void 0 : hr(m, Vq)) ? U : !1,
                        Fj: null != (ub = null == m ? void 0 : hr(m, Lq)) ? ub : !1
                    };
                    h = Lm(h, "data-google-av-ufs-integrator-metadata");
                    a: {
                        if (null !== h) try {
                            var Qb = fr(h);
                            break a
                        } catch (Fa) {}
                        Qb = new dr
                    }
                    b(k, Qb, r)
                })
            });
            a && this.ba()
        }
    };
    ir.prototype.ba = function() {
        var a, b;
        null == (a = this.vd) || null == (b = a.unsubscribe) || b.call(a);
        this.vd = void 0;
        var c;
        null == (c = this.tf) || c.call(this);
        this.tf = void 0
    };
    var jr = function(a) {
        im.call(this, a)
    };
    x(jr, im);
    var kr = function(a, b) {
        return Ik(a, 1, b)
    };
    jr.Ca = "contentads.bow.rendering.client.TurtleDoveReportingData";
    jr.makeCrossSerializerComparisonsCompatible = jm(jr, [0, Yl, Ul, Yl, -5, bm]);

    function lr() {
        var a = Fb();
        return a ? kb("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;WebOS".split(";"), function(b) {
            return vb(a, b)
        }) || vb(a, "OMI/") && !vb(a, "XiaoMi/") ? !0 : vb(a, "Presto") && vb(a, "Linux") && !vb(a, "X11") && !vb(a, "Android") && !vb(a, "Mobi") : !1
    };
    var $o = Object.freeze({
            xg: 1E3,
            je: .5,
            Ee: .3
        }),
        gp = Object.freeze([1, .75, $o.je, $o.Ee, 0]),
        jn = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&bin=7&v=" + uq,
        mr = function(a, b, c, d, e, f) {
            this.wi = a;
            this.Ib = b;
            this.Of = c;
            this.Zb = d;
            this.Kc = e;
            this.Lc = f;
            this.name = "rxlidar";
            this.Vh = new yc;
            this.controlledEvents = [];
            this.subscribedEvents = [];
            this.ce = new yc;
            this.controlledEvents.push(this.Of, this.Zb, this.Kc, this.Lc)
        };
    n = mr.prototype;
    n.start = function(a) {
        if (void 0 === this.re && a.Z) {
            var b;
            if (null != (b = this.Ib)) var c = b;
            else {
                b = a.Z;
                var d = null != (c = a.rb) ? c : null;
                c = {
                    lh: .01,
                    Yh: Qf(b.i, 36E5),
                    Ra: b.i.Oa(100).g(Y(b.h, 1)),
                    rb: d
                }
            }
            this.Ib = c;
            a = a.Z;
            this.re = nr(a, this.ce.g(Y(a.h, 1)), this.Ib.lh, this.Ib.Yh, this.Ib.Ra, this.Ib.rb, this.Of, this.Zb, this.Kc, this.Lc).subscribe(this.Vh)
        }
    };
    n.ba = function() {
        this.ce.complete();
        var a;
        null == (a = this.re) || a.unsubscribe();
        this.re = void 0
    };
    n.Lf = function(a, b, c, d) {
        rk(b, xk, 2) && !zk(b, xk, 2).me() || this.ce.next(Object.assign({}, this.wi.vf.get(a), {
            metadata: b,
            experimentState: c,
            Sj: a,
            kb: d
        }))
    };
    n.hc = function() {};
    n.handleEvent = function() {};

    function nr(a, b, c, d, e, f, g, k, h, l) {
        var m = tq(a).g(P(function(q) {
                return !q
            })),
            r = new Rp(a, [new aq(a, gp), new $p(a, e), new Xp(a, e), new sq(f, a, gp), new rq(f, a, e), new kq(a, e)]);
        return Zm(a, b, function(q, v) {
            var w = Dp(q, v.element),
                A = w.Qd,
                D = w.Oc,
                C = w.Zd,
                S = w.af,
                pa = w.fh,
                ia = w.Za,
                E = w.Oh,
                B = w.we,
                U = w.ze,
                ub = w.Ta,
                Qb = w.Ga,
                Fa = w.Zi,
                Vl = w.ob;
            w = w.Ce;
            var Mf, jb = null != (Mf = Gk(yk(v.metadata), 3)) ? Mf : "";
            Mf = kr(new jr, atob(jb)).eb();
            jb = (new Z(v.experimentState)).V(q.h);
            var Tb = jb.g(P(function(G) {
                    return G.Ni
                })),
                Ga = ia.g(Ce(E), P(function(G) {
                    var Ra =
                        t(G);
                    G = Ra.next().value;
                    Ra = Ra.next().value;
                    (G = G || Ra) || ((G = vb(Fb(), "CrKey") || vb(Fb(), "PlayStation") || vb(Fb(), "Roku") || lr() || vb(Fb(), "Xbox")) || (G = Fb(), G = vb(G, "AppleTV") || vb(G, "Apple TV") || vb(G, "CFNetwork") || vb(G, "tvOS")), G || (G = Fb(), G = vb(G, "sdk_google_atv_x86") || vb(G, "Android TV")));
                    return G
                }));
            E = new Mp(q, v, pa, ia, ub, Tb);
            Tb = jb.g(P(function(G) {
                return G.Zg
            }));
            Tb = r.Xa(E, {
                Za: ia,
                experimentState: v.experimentState,
                Ta: ub,
                dg: Tb
            });
            var Ha = Tb.Ya,
                ie = Tb.Va;
            Tb = ie.Ge;
            var Nr = ie.He;
            ie = ie.Se;
            var wb = zq(q, U, Ga, m, Fa, E, jb);
            Fa = mp(q.h, q.i, Ha, wb);
            Ga = xq(q.h, Fa.Ba.Ue, Fa.Ba.visible, Fa.Re, Fa.zc);
            var ed = Bp(q.h, q.i, Fa.zc, Fa.Ba.X, Fa.Ba.visible);
            Ha = Qo(q.h, q.i, Ha, wb);
            wb = fp(q.i, q.h, Ha.Ba.Ue, Ha.Ba.visible, Ha.Re, Ha.zc);
            var Nf = {
                    Ze: Zo(q.h, q.i, Ha.zc, wb.qc)
                },
                Th = jb.g(P(function(G) {
                    return G.th
                }), W(!1));
            Ha = Dn(q.h, Th, Object.assign({}, Ha.Ba, wb, Nf), Object.assign({}, Fa.Ba, {
                Ze: Go(q, ed),
                rc: Go(q, Ga.rc),
                Cc: Go(q, Ga.Cc),
                qc: Go(q, Ga.qc),
                jb: Ga.jb.g(P(function(G) {
                    return new Fo(q.i, G)
                }))
            }));
            Ga = oo(q, d.g(hf("t")));
            ed = null !== f && f.validate();
            wb = (ed ? f.Ji : vd).g(Y(q.h,
                1), hf("u"));
            Ga = yd(Ga, wb);
            ed = (ed ? f.te.g(Qe(1), hf(!0), W(!1)) : (new Z(!0)).V(q.h)).g(X(function(G) {
                return G ? new L(function(Ra) {
                    v.kb(g, {}, function(Or) {
                        Ra.next(Or);
                        Ra.complete()
                    })
                }) : vd
            }), W(!1), Y(q.h, 1));
            wb = vq(q, Ha.X, Ga.g(T(function(G) {
                return null !== G
            })));
            Nf = or(q, E, A);
            Th = pr(q, Ga, v.element);
            var Rr = Nf.Sg.g(W({
                    x: 0,
                    y: 0
                })),
                Sr = jb.g(P(function(G) {
                    return G.Gi
                }), W(!1), V(), Ff(function(G) {
                    Ch = G
                }), Y(q.h, 1)),
                Wl = B.g(P(function(G) {
                    return 40 === G || 41 === G
                }));
            return Object.assign({}, {
                H: new Z(q.H),
                fd: new Z("lidar2"),
                Ri: new Z("lidartos"),
                Wg: new Z(uq),
                Vg: new Z(7),
                Yd: new Z(q.validate() ? null : new Xd),
                ah: new Z(hi(q.document)),
                va: new Z(ln),
                zf: Ga,
                wg: Ga,
                Oj: wb,
                Mf: ed,
                kb: new Z(v.kb),
                Zb: new Z(k),
                Kc: new Z(h),
                Lc: new Z(l),
                dh: new Z(q.Gb ? 1 : void 0),
                gh: new Z(q.Xg ? 1 : void 0),
                Za: ia,
                ob: Vl,
                Cd: new Z(Mf),
                ub: Vl.g(T(function(G) {
                    return G
                }), P(function() {
                    return q.ub.bind(q)
                })),
                Ge: Tb.g(Y(q.h, 1)),
                He: Nr.g(Y(q.h, 1)),
                rh: jb.g(P(function(G) {
                    return G.sh
                })),
                Qf: Sr,
                Ce: w,
                Mh: Wl,
                Eh: jb.g(P(function(G) {
                    return G.eh
                })),
                uh: new Z(new Sf(q, new Xg(q))),
                vg: new Z(Ch && (new Bh(q)).L({
                    Bb: "GET"
                })),
                Mi: new Z(Number(v.experimentState.Ag) << 0 + Number(v.experimentState.Wi) << 1 + Number(v.experimentState.Ii) << 2),
                bh: v.element.g(P(function(G) {
                    return null !== G
                })),
                ed: Qb,
                Si: Qb,
                Zd: C.g(W([])),
                af: S.g(W([])),
                Bh: C.g(P(function(G) {
                    return 0 < G.length ? !0 : null
                }), W(null), V()),
                Oc: D.g(W([]), Y(q.h, 1)),
                Jj: jb,
                Qd: A,
                bc: E.bc,
                we: B.g(W(0), Y(q.h, 1)),
                Wh: pa,
                Ta: ub.g(W(0), Y(q.h, 1)),
                Dc: Wl.g(P(function(G) {
                    return G ? An : kn
                })),
                Vb: new Z(Bn),
                ze: U,
                Rf: E.oc.g(En(q.h)),
                bf: E.bf
            }, Ha, {
                Uc: R([Ha.Uc, Rr]).g(P(function(G) {
                    var Ra = t(G);
                    G = Ra.next().value;
                    Ra = Ra.next().value;
                    return oi(G, Ra)
                }), V(mi))
            }, Nf, {
                Ec: Qh(q),
                Ch: Th,
                Se: ie,
                Ed: Fa.Ba.Ed
            })
        }, hn(a, c))
    }

    function or(a, b, c) {
        var d = void 0 === d ? Ja : d;
        var e, f;
        d = (null == (e = d.performance) ? void 0 : null == (f = e.timing) ? void 0 : f.navigationStart) || 0;
        return Object.assign({}, {
            Qg: new Z(d),
            Pg: Sn(a, b)
        }, Rn(a, b, c))
    }

    function pr(a, b, c) {
        return b.g(T(function(d) {
            return null !== d
        }), X(function() {
            return c
        }), P(function(d) {
            var e = Pm(a);
            return 0 < e.length && 0 <= e.indexOf(d)
        }), P(function(d) {
            return !d
        }))
    };

    function qr(a) {
        var b = Rh(a);
        return b ? b.g(P(function(c) {
            var d;
            c = null == (d = Bk(c).find(function(g) {
                return "Google Chrome" === Gk(g, 1)
            })) ? void 0 : Gk(d, 2);
            if (!c) return !1;
            var e = t(c.split(".").map(function(g) {
                return Number(g)
            }));
            d = e.next().value;
            c = e.next().value;
            var f = e.next().value;
            e = e.next().value;
            return void 0 === d || void 0 === c || void 0 === f || void 0 === e ? !1 : 117 === d && 5938 === f && 149 <= e || 118 === d && 5993 === f && 32 <= e || 119 === d && 6034 <= f || 120 <= d ? !0 : !1
        })) : Ih.V(a.h)
    };
    var rr = function(a, b) {
        var c = void 0 === c ? [a] : c;
        var d = void 0 === d ? [b] : d;
        this.xi = b;
        this.subscribedEvents = c;
        this.controlledEvents = d;
        this.name = "reach";
        this.uc = new Map
    };
    n = rr.prototype;
    n.start = function(a) {
        this.context = a.Z
    };
    n.ba = function() {
        this.uc.forEach(function(a) {
            return void a.ba()
        });
        this.uc.clear()
    };
    n.Lf = function(a, b, c, d) {
        var e = this;
        if (!rk(b, br, 1) || zk(b, br, 1).me()) {
            var f = this.context;
            f && c.Ag && f.sharedStorage && qr(f).g(Qe(1)).subscribe(function(g) {
                g && (g = new sr(f, b, e.xi, c, d), e.uc.set(a, g))
            })
        }
    };
    n.hc = function(a) {
        var b;
        null == (b = this.uc.get(a)) || b.ba();
        this.uc.delete(a)
    };
    n.handleEvent = function() {};
    var sr = function(a, b, c, d, e) {
            var f = this;
            this.context = a;
            this.metadata = b;
            this.experimentState = d;
            e(c, {}, function(g) {
                g && (tr(f, 2), tr(f, 1))
            })
        },
        tr = function(a, b) {
            var c, d, e, f, g, k, h, l, m;
            Ba(function(r) {
                h = {
                    canaryMode: b,
                    experimentState: a.experimentState,
                    escapedQueryId: null != (g = null == (c = zk(a.metadata, br, 1)) ? void 0 : Fk(c)) ? g : "",
                    clientsideModelFilename: null == (d = zk(a.metadata, br, 1)) ? void 0 : Gk(d, 1),
                    geoTargetMessage: null != (k = null == (e = zk(a.metadata, br, 1)) ? void 0 : null == (f = zk(e, $q, 4)) ? void 0 : f.eb()) ? k : void 0
                };
                l = btoa(JSON.stringify(h));
                m = a.context.sg[0];
                return ta(r, ki(a.context.document, m, l), 0)
            })
        };
    sr.prototype.ba = function() {};

    function ur(a, b) {
        if (!b) throw Error("ya`" + a);
        if ("string" !== typeof b && !(b instanceof String)) throw Error("za`" + a);
        if ("" === b.trim()) throw Error("Aa`" + a);
    }

    function vr(a) {
        if (!a) throw Error("Da`functionToExecute");
    }

    function wr(a, b) {
        if (null == b) throw Error("Ba`" + a);
        if ("number" !== typeof b || isNaN(b)) throw Error("Ca`" + a);
        if (0 > b) throw Error("Ea`" + a);
    };

    function xr() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.4.8-google_20230803")
    }

    function yr() {
        for (var a = ["1", "4", "8"], b = ["1", "0", "3"], c = 0; 3 > c; c++) {
            var d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };
    var zr = function(a, b, c, d) {
            this.Kf = a;
            this.method = b;
            this.version = c;
            this.args = d
        },
        Ar = function(a) {
            return !!a && void 0 !== a.omid_message_guid && void 0 !== a.omid_message_method && void 0 !== a.omid_message_version && "string" === typeof a.omid_message_guid && "string" === typeof a.omid_message_method && "string" === typeof a.omid_message_version && (void 0 === a.omid_message_args || void 0 !== a.omid_message_args)
        },
        Br = function(a) {
            return new zr(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
        };
    zr.prototype.eb = function() {
        var a = {};
        a = (a.omid_message_guid = this.Kf, a.omid_message_method = this.method, a.omid_message_version = this.version, a);
        void 0 !== this.args && (a.omid_message_args = this.args);
        return a
    };
    var Cr = function(a) {
        this.Bd = a
    };
    Cr.prototype.eb = function() {
        return JSON.stringify(void 0)
    };
    var Dr = function(a) {
        return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
            try {
                var c = a.frames && !!a.frames[b]
            } catch (d) {
                c = !1
            }
            return c
        })
    };

    function Er(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function Fr() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = 16 * Math.random() | 0;
            return "y" === a ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function Gr() {
        var a = y.apply(0, arguments);
        Hr(function() {
            throw new(Function.prototype.bind.apply(Error, [null, "Could not complete the test successfully - "].concat(u(a))));
        }, function() {
            return console.error.apply(console, u(a))
        })
    }

    function Hr(a, b) {
        "undefined" !== typeof jasmine && jasmine ? a() : "undefined" !== typeof console && console && console.error && b()
    };
    var Ir = function() {
        if ("undefined" !== typeof omidGlobal && omidGlobal) return omidGlobal;
        if ("undefined" !== typeof global && global) return global;
        if ("undefined" !== typeof window && window) return window;
        if ("undefined" !== typeof globalThis && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("Fa");
    }();
    var Jr = function(a) {
        this.Bd = a;
        this.handleExportedMessage = Jr.prototype.yh.bind(this)
    };
    x(Jr, Cr);
    Jr.prototype.sendMessage = function(a, b) {
        b = void 0 === b ? this.Bd : b;
        if (!b) throw Error("Ga");
        b.handleExportedMessage(a.eb(), this)
    };
    Jr.prototype.yh = function(a, b) {
        if (Ar(a) && this.onMessage) this.onMessage(Br(a), b)
    };

    function Kr(a) {
        return null != a && "undefined" !== typeof a.top && null != a.top
    }

    function Lr(a) {
        if (a === Ir) return !1;
        try {
            if ("undefined" === typeof a.location.hostname) return !0
        } catch (b) {
            return !0
        }
        return !1
    };
    var Mr = function(a, b) {
        this.Bd = b = void 0 === b ? Ir : b;
        var c = this;
        a.addEventListener("message", function(d) {
            if ("object" === typeof d.data) {
                var e = d.data;
                if (Ar(e) && d.source && c.onMessage) c.onMessage(Br(e), d.source)
            }
        })
    };
    x(Mr, Cr);
    Mr.prototype.sendMessage = function(a, b) {
        b = void 0 === b ? this.Bd : b;
        if (!b) throw Error("Ga");
        b.postMessage(a.eb(), "*")
    };
    var Pr = ["omid", "v1_VerificationServiceCommunication"],
        Qr = ["omidVerificationProperties", "serviceWindow"];

    function Tr(a, b) {
        return b.reduce(function(c, d) {
            return c && c[d]
        }, a)
    };
    var Ur = function(a) {
        if (!a) {
            var b;
            "undefined" === typeof b && "undefined" !== typeof window && window && (b = window);
            b = Kr(b) ? b : Ir;
            var c = void 0 === c ? Dr : c;
            a = [];
            var d = Tr(b, Qr);
            d && a.push(d);
            a.push(Kr(b) ? b.top : Ir);
            a: {
                a = t(a);
                for (var e = a.next(); !e.done; e = a.next()) {
                    b: {
                        d = b;e = e.value;
                        var f = c;
                        if (!Lr(e)) try {
                            var g = Tr(e, Pr);
                            if (g) {
                                var k = new Jr(g);
                                break b
                            }
                        } catch (h) {}
                        k = f(e) ? new Mr(d, e) : null
                    }
                    if (d = k) {
                        a = d;
                        break a
                    }
                }
                a = null
            }
        }
        if (this.ac = a) this.ac.onMessage = this.zh.bind(this);
        else if (c = (c = Ir.omid3p) && "function" === typeof c.registerSessionObserver &&
            "function" === typeof c.addEventListener ? c : null) this.tc = c;
        this.Ai = this.Bi = 0;
        this.Ud = {};
        this.se = [];
        this.gd = (c = Ir.omidVerificationProperties) ? c.injectionId : void 0
    };
    Ur.prototype.L = function() {
        return !(!this.ac && !this.tc)
    };
    var xe = function(a, b, c) {
        vr(b);
        a.tc ? a.tc.registerSessionObserver(b, c, a.gd) : a.Sb("addSessionListener", b, c, a.gd)
    };
    Ur.prototype.addEventListener = function(a, b) {
        ur("eventType", a);
        vr(b);
        this.tc ? this.tc.addEventListener(a, b, this.gd) : this.Sb("addEventListener", b, a, this.gd)
    };
    var Pf = function(a, b, c, d) {
            ur("url", b);
            Ir.document && Ir.document.createElement ? Vr(a, b, c, d) : a.Sb("sendUrl", function(e) {
                e && c ? c() : !e && d && d()
            }, b)
        },
        Vr = function(a, b, c, d) {
            var e = Ir.document.createElement("img");
            a.se.push(e);
            var f = function(g) {
                var k = a.se.indexOf(e);
                0 <= k && a.se.splice(k, 1);
                g && g()
            };
            e.addEventListener("load", f.bind(a, c));
            e.addEventListener("error", f.bind(a, d));
            e.src = b
        };
    Ur.prototype.setTimeout = function(a, b) {
        vr(a);
        wr("timeInMillis", b);
        if (Wr()) return Ir.setTimeout(a, b);
        var c = this.Bi++;
        this.Sb("setTimeout", a, c, b);
        return c
    };
    Ur.prototype.clearTimeout = function(a) {
        wr("timeoutId", a);
        Wr() ? Ir.clearTimeout(a) : this.ng("clearTimeout", a)
    };
    Ur.prototype.setInterval = function(a, b) {
        vr(a);
        wr("timeInMillis", b);
        if (Xr()) return Ir.setInterval(a, b);
        var c = this.Ai++;
        this.Sb("setInterval", a, c, b);
        return c
    };
    Ur.prototype.clearInterval = function(a) {
        wr("intervalId", a);
        Xr() ? Ir.clearInterval(a) : this.ng("clearInterval", a)
    };
    var Wr = function() {
            return "function" === typeof Ir.setTimeout && "function" === typeof Ir.clearTimeout
        },
        Xr = function() {
            return "function" === typeof Ir.setInterval && "function" === typeof Ir.clearInterval
        };
    Ur.prototype.zh = function(a) {
        var b = a.method,
            c = a.Kf;
        a = a.args;
        if ("response" === b && this.Ud[c]) {
            var d = xr() && yr() ? a ? a : [] : a && "string" === typeof a ? JSON.parse(a) : [];
            this.Ud[c].apply(this, d)
        }
        "error" === b && window.console && Gr(a)
    };
    Ur.prototype.ng = function(a) {
        this.Sb.apply(this, [a, null].concat(u(y.apply(1, arguments))))
    };
    Ur.prototype.Sb = function(a, b) {
        var c = y.apply(2, arguments);
        if (this.ac) {
            var d = Fr();
            b && (this.Ud[d] = b);
            var e = "VerificationService." + a;
            c = xr() && yr() ? c : JSON.stringify(c);
            this.ac.sendMessage(new zr(d, e, "1.4.8-google_20230803", c))
        }
    };
    var Yr = void 0;
    if (Yr = void 0 === Yr ? "undefined" === typeof omidExports ? null : omidExports : Yr) {
        var Zr = ["OmidVerificationClient"];
        Zr.slice(0, Zr.length - 1).reduce(Er, Yr)[Zr[Zr.length - 1]] = Ur
    };
    var $r = Ng(null !== "av.key_js_20231116_RC01".match(/^m\d{10}$/g) ? "av.key_js_20231116_RC01" : "current"),
        as = new Bm(void 0, void 0, void 0, $r),
        bs;
    a: {
            var cs = !1;cs = void 0 === cs ? !1 : cs;
            try {
                var ds = new Ur;
                bs = new Pg(ds, "doubleclickbygoogle.com-omid", cs, void 0, $r);
                break a
            } catch (a) {}
            bs = void 0
        }
        (function(a, b) {
            var c = new Gq("impression"),
                d = new Gq("begin to render"),
                e = new Gq("unmeasurable"),
                f = new Gq("viewable"),
                g = new Gq("reach vpid"),
                k = new Eq(c, g, d, f, e),
                h = new ir;
            b = new mr(h, b, c.event, d.event, e.event, f.event);
            c = new rr(c.event, g.event);
            var l = new Hq(a, k, h, b, c);
            l.start();
            return {
                ba: function() {
                    return void l.ba()
                },
                colleagues: {
                    Qj: b,
                    Nj: c
                }
            }
        })({
            Z: as,
            rb: bs
        });
}).call(this);