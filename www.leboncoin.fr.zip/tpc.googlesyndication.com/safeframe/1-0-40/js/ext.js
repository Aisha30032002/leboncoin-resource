(function() {
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var aa = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ba = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        ca = ba(this),
        da = function(a, b) {
            if (b) a: {
                var c = ca;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && aa(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        },
        ea = function(a) {
            return a.raw = a
        },
        fa = "function" == typeof Object.assign ? Object.assign : function(a, b) {
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
            }
            return a
        };
    da("Object.assign", function(a) {
        return a || fa
    });
    var ha = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        f;
    if ("function" == typeof Object.setPrototypeOf) f = Object.setPrototypeOf;
    else {
        var g;
        a: {
            var ia = {
                    a: !0
                },
                ja = {};
            try {
                ja.__proto__ = ia;
                g = ja.a;
                break a
            } catch (a) {}
            g = !1
        }
        f = g ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ka = f,
        h = function(a, b) {
            a.prototype = ha(b.prototype);
            a.prototype.constructor = a;
            if (ka) ka(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.S = b.prototype
        },
        la = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        },
        k = this || self,
        m = function(a) {
            var b = typeof a;
            return "object" == b && null != a || "function" == b
        },
        ma = function(a, b, c) {
            return a.call.apply(a.bind, arguments)
        },
        na = function(a, b, c) {
            if (!a) throw Error();
            if (2 < arguments.length) {
                var d = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var e = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(e, d);
                    return a.apply(b, e)
                }
            }
            return function() {
                return a.apply(b, arguments)
            }
        },
        n = function(a, b, c) {
            Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? n = ma : n = na;
            return n.apply(null, arguments)
        },
        p = function(a, b) {
            a = a.split(".");
            var c = k;
            a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
            for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        },
        r = function(a) {
            return a
        };
    var oa = Array.prototype.forEach ? function(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    } : function(a, b) {
        for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    };
    var t = function(a, b) {
            this.m = a === pa && b || "";
            this.g = qa
        },
        ra = function(a) {
            return a instanceof t && a.constructor === t && a.g === qa ? a.m : "type_error:Const"
        },
        qa = {},
        pa = {};
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    var v;
    var w = function(a, b) {
        this.g = b === sa ? a : ""
    };
    w.prototype.toString = function() {
        return this.g + ""
    };
    var ta = function(a) {
            return a instanceof w && a.constructor === w ? a.g : "type_error:TrustedResourceUrl"
        },
        sa = {},
        x = function(a) {
            if (void 0 === v) {
                var b = null;
                var c = k.trustedTypes;
                if (c && c.createPolicy) {
                    try {
                        b = c.createPolicy("goog#html", {
                            createHTML: r,
                            createScript: r,
                            createScriptURL: r
                        })
                    } catch (d) {
                        k.console && k.console.error(d.message)
                    }
                    v = b
                } else v = b
            }
            a = (b = v) ? b.createScriptURL(a) : a;
            return new w(a, sa)
        };

    function ua(a) {
        var b = la.apply(1, arguments);
        if (0 === b.length) return x(a[0]);
        for (var c = [a[0]], d = 0; d < b.length; d++) c.push(encodeURIComponent(b[d])), c.push(a[d + 1]);
        return x(c.join(""))
    };
    var va = function(a, b) {
        var c = void 0 === c ? {} : c;
        this.error = a;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror";
        this.meta = c
    };
    var wa = function(a, b) {
        var c = window;
        c.addEventListener && c.addEventListener.call(c, a, b, !1)
    };
    var y = function() {
        var a = document.body.offsetHeight;
        this.width = document.body.offsetWidth;
        this.height = a
    };
    y.prototype.aspectRatio = function() {
        return this.width / this.height
    };
    y.prototype.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    y.prototype.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    y.prototype.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var xa = function(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    var z = function(a, b, c, d) {
            this.o = a;
            this.j = b;
            this.g = c;
            this.m = d
        },
        A = function(a) {
            return new z(a.o, a.j, a.g, a.m)
        };
    z.prototype.ceil = function() {
        this.o = Math.ceil(this.o);
        this.j = Math.ceil(this.j);
        this.g = Math.ceil(this.g);
        this.m = Math.ceil(this.m);
        return this
    };
    z.prototype.floor = function() {
        this.o = Math.floor(this.o);
        this.j = Math.floor(this.j);
        this.g = Math.floor(this.g);
        this.m = Math.floor(this.m);
        return this
    };
    z.prototype.round = function() {
        this.o = Math.round(this.o);
        this.j = Math.round(this.j);
        this.g = Math.round(this.g);
        this.m = Math.round(this.m);
        return this
    };
    ({})[3] = x(ra(new t(pa, "https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js")));
    ({})[3] = x(ra(new t(pa, "https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js")));
    var ya = function(a, b) {
            this.g = a;
            this.m = b || Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ Date.now()).toString(36)
        },
        za = function(a) {
            var b = {};
            oa(a, function(c) {
                b[c.g] = c.m
            });
            return b
        },
        Aa = function() {
            var a = B.goog_safeframe_hlt,
                b = [];
            a && xa(a, function(c, d) {
                b.push(new ya(parseInt(d, 10), c))
            });
            return b
        };
    var Ba = ea(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]),
        Ca = function() {
            var a = void 0 === a ? "jserror" : a;
            var b = void 0 === b ? .01 : b;
            var c = void 0 === c ? ua(Ba) : c;
            this.j = a;
            this.m = b;
            this.g = c
        };
    var Da = function() {};
    var D = function(a, b, c, d, e, l) {
        this.A = a;
        this.status = 1;
        this.o = b;
        this.j = c;
        this.I = d;
        this.F = !!e;
        this.B = Math.random();
        this.g = {};
        this.m = null;
        this.G = n(this.H, this);
        this.C = l
    };
    h(D, Da);
    D.prototype.H = function(a) {
        if (!("*" !== this.j && a.origin !== this.j || !this.F && a.source != this.o)) {
            var b = null;
            try {
                b = JSON.parse(a.data)
            } catch (c) {}
            if (m(b) && (a = b.i, b.c === this.A && a != this.B)) {
                if (2 !== this.status) try {
                    this.status = 2, Ea(this), this.m && (this.m(), this.m = null)
                } catch (c) {}
                a = b.s;
                b = b.p;
                if ("string" === typeof a && ("string" === typeof b || m(b)) && this.g.hasOwnProperty(a)) this.g[a](b)
            }
        }
    };
    var Ea = function(a) {
        var b = {};
        b.c = a.A;
        b.i = a.B;
        a.C && (b.e = a.C);
        a.o.postMessage(JSON.stringify(b), a.j)
    };
    D.prototype.D = function() {
        if (1 === this.status) {
            try {
                this.o.postMessage && Ea(this)
            } catch (a) {}
            window.setTimeout(n(this.D, this), 50)
        }
    };
    D.prototype.connect = function(a) {
        a && (this.m = a);
        wa("message", this.G);
        this.I && this.D()
    };
    var Fa = function(a, b, c) {
        var d = {};
        d.c = a.A;
        d.i = a.B;
        d.s = b;
        d.p = c;
        try {
            a.o.postMessage(JSON.stringify(d), a.j)
        } catch (e) {}
    };
    var Ga = function(a, b, c, d, e, l, u) {
        this.j = A(a);
        this.m = A(b);
        this.g = u ? A(u) : null;
        this.C = c;
        this.o = A(d);
        this.A = e;
        this.B = l
    };
    Ga.prototype.u = function() {
        var a = {
            windowCoords_t: this.j.o,
            windowCoords_r: this.j.j,
            windowCoords_b: this.j.g,
            windowCoords_l: this.j.m,
            frameCoords_t: this.m.o,
            frameCoords_r: this.m.j,
            frameCoords_b: this.m.g,
            frameCoords_l: this.m.m,
            styleZIndex: this.C,
            allowedExpansion_t: this.o.o,
            allowedExpansion_r: this.o.j,
            allowedExpansion_b: this.o.g,
            allowedExpansion_l: this.o.m,
            xInView: this.A,
            yInView: this.B
        };
        this.g && (a.posCoords_t = this.g.o, a.posCoords_b = this.g.g, a.posCoords_l = this.g.m, a.posCoords_r = this.g.j);
        return JSON.stringify(a)
    };
    var E = function(a) {
        a = JSON.parse(a);
        if (!(m(a) && "number" === typeof a.windowCoords_t && "number" === typeof a.windowCoords_r && "number" === typeof a.windowCoords_b && "number" === typeof a.windowCoords_l && "number" === typeof a.frameCoords_t && "number" === typeof a.frameCoords_r && "number" === typeof a.frameCoords_b && "number" === typeof a.frameCoords_l && "string" === typeof a.styleZIndex && "number" === typeof a.allowedExpansion_t && "number" === typeof a.allowedExpansion_r && "number" === typeof a.allowedExpansion_b && "number" === typeof a.allowedExpansion_l && "number" === typeof a.xInView && 0 <= a.xInView && 1 >= a.xInView && "number" === typeof a.yInView && 0 <= a.yInView && 1 >= a.yInView) || void 0 !== a.posCoords_t && "number" !== typeof a.posCoords_t || void 0 !== a.posCoords_b && "number" !== typeof a.posCoords_b || void 0 !== a.posCoords_r && "number" !== typeof a.posCoords_r || void 0 !== a.posCoords_l && "number" !== typeof a.posCoords_l || void 0 !== a.posCoords_t && (void 0 === a.posCoords_b || void 0 === a.posCoords_l || void 0 === a.posCoords_r)) throw Error("Cannot parse JSON geometry");
        var b = new z(a.windowCoords_t, a.windowCoords_r, a.windowCoords_b, a.windowCoords_l),
            c = new z(a.frameCoords_t, a.frameCoords_r, a.frameCoords_b, a.frameCoords_l),
            d = new z(a.allowedExpansion_t, a.allowedExpansion_r, a.allowedExpansion_b, a.allowedExpansion_l),
            e;
        void 0 !== a.posCoords_t && (e = new z(a.posCoords_t, a.posCoords_r, a.posCoords_b, a.posCoords_l));
        return new Ga(b, c, a.styleZIndex, d, a.xInView, a.yInView, e)
    };
    var Ha = function(a) {
            this.m = a;
            this.A = null;
            this.g = this.status = 0;
            this.o = null;
            this.H = "sfchannel" + a
        },
        F = function(a) {
            return 1 == a.status || 2 == a.status
        };
    var Ia = function() {
        this.g = G
    };
    Ia.prototype.u = function() {
        return JSON.stringify(this.g)
    };
    var Ja = function() {
        var a = H.expandByPush,
            b = H.readCookie,
            c = H.writeCookie;
        this.g = H.expandByOverlay;
        this.m = a;
        this.j = b;
        this.o = c
    };
    Ja.prototype.u = function() {
        return JSON.stringify({
            expandByOverlay: this.g,
            expandByPush: this.m,
            readCookie: this.j,
            writeCookie: this.o
        })
    };
    var Oa = function() {
        var a = B.uid,
            b = B.hostPeerName,
            c = Ka,
            d = La,
            e = Ma,
            l = B.reportCreativeGeometry,
            u = B.isDifferentSourceWindow,
            q = Na,
            C = B.sentinel,
            I = B.pbjsAdConfig;
        q = void 0 === q ? [] : q;
        this.A = a;
        this.B = b;
        this.C = c;
        this.o = d;
        this.j = e;
        this.F = l;
        this.m = u;
        this.G = q;
        this.g = void 0 === C ? "" : C;
        this.D = void 0 === I ? "" : I
    };
    Oa.prototype.u = function() {
        var a = {};
        a = (a.uid = this.A, a.hostPeerName = this.B, a.initialGeometry = this.C.u(), a.permissions = this.o.u(), a.metadata = this.j.u(), a.reportCreativeGeometry = this.F, a.isDifferentSourceWindow = this.m, a.goog_safeframe_hlt = za(this.G), a);
        this.g && (a.sentinel = this.g);
        this.D && (a.pbjsAdConfig = this.D);
        return JSON.stringify(a)
    };
    var Pa = /^([^;]+);(\d+);([\s\S]*)$/;

    function J(a) {
        return "number" === typeof a || "string" === typeof a
    }
    var K = function(a, b) {
        this.g = a;
        this.m = b
    };
    K.prototype.u = function(a) {
        this.m && a && (a.sentinel = this.m);
        return JSON.stringify(a)
    };
    var Qa = function(a, b, c) {
        K.call(this, a, void 0 === c ? "" : c);
        this.version = b
    };
    h(Qa, K);
    Qa.prototype.u = function() {
        return K.prototype.u.call(this, {
            uid: this.g,
            version: this.version
        })
    };
    var Ra = function(a, b, c, d) {
        K.call(this, a, void 0 === d ? "" : d);
        this.o = b;
        this.j = c
    };
    h(Ra, K);
    Ra.prototype.u = function() {
        return K.prototype.u.call(this, {
            uid: this.g,
            initialWidth: this.o,
            initialHeight: this.j
        })
    };
    var Sa = function(a, b, c) {
        K.call(this, a, void 0 === c ? "" : c);
        this.description = b
    };
    h(Sa, K);
    Sa.prototype.u = function() {
        return K.prototype.u.call(this, {
            uid: this.g,
            description: this.description
        })
    };
    var L = function(a, b, c, d) {
        K.call(this, a, void 0 === d ? "" : d);
        this.j = b;
        this.push = c
    };
    h(L, K);
    L.prototype.u = function() {
        return K.prototype.u.call(this, {
            uid: this.g,
            expand_t: this.j.o,
            expand_r: this.j.j,
            expand_b: this.j.g,
            expand_l: this.j.m,
            push: this.push
        })
    };
    var Ta = function(a, b) {
        K.call(this, a, void 0 === b ? "" : b)
    };
    h(Ta, K);
    Ta.prototype.u = function() {
        return K.prototype.u.call(this, {
            uid: this.g
        })
    };
    var Ua = function(a, b, c) {
        K.call(this, a, void 0 === c ? "" : c);
        this.j = b
    };
    h(Ua, K);
    Ua.prototype.u = function() {
        return K.prototype.u.call(this, {
            uid: this.g,
            shrink_t: this.j.o,
            shrink_r: this.j.j,
            shrink_b: this.j.g,
            shrink_l: this.j.m
        })
    };
    var Va = function(a, b, c, d) {
        K.call(this, a, void 0 === d ? "" : d);
        this.j = b;
        this.push = c
    };
    h(Va, K);
    Va.prototype.u = function() {
        return K.prototype.u.call(this, {
            uid: this.g,
            resize_t: this.j.o,
            resize_r: this.j.j,
            resize_b: this.j.g,
            resize_l: this.j.m,
            push: this.push
        })
    };
    var M = function(a, b, c) {
        K.call(this, a, void 0 === c ? "" : c);
        this.o = b
    };
    h(M, K);
    M.prototype.u = function() {
        var a = {
            uid: this.g,
            newGeometry: this.o.u()
        };
        return K.prototype.u.call(this, a)
    };
    var Wa = function(a) {
            a = JSON.parse(a);
            if (!m(a) || !J(a.uid) || "string" !== typeof a.newGeometry) throw Error("Cannot parse JSON message");
            var b = E(a.newGeometry);
            return new M(a.uid, b, a.sentinel)
        },
        Xa = function(a, b, c, d, e, l) {
            M.call(this, a, c, void 0 === l ? "" : l);
            this.A = b;
            this.j = d;
            this.push = e
        };
    h(Xa, M);
    Xa.prototype.u = function() {
        var a = {
            uid: this.g,
            success: this.A,
            newGeometry: this.o.u(),
            expand_t: this.j.o,
            expand_r: this.j.j,
            expand_b: this.j.g,
            expand_l: this.j.m,
            push: this.push
        };
        this.m && (a.sentinel = this.m);
        return JSON.stringify(a)
    };
    var Ya = function(a, b, c, d) {
        M.call(this, a, c, void 0 === d ? "" : d);
        this.j = b
    };
    h(Ya, M);
    Ya.prototype.u = function() {
        var a = {
            uid: this.g,
            success: this.j,
            newGeometry: this.o.u()
        };
        this.m && (a.sentinel = this.m);
        return JSON.stringify(a)
    };
    var Za = function(a, b, c, d, e) {
        M.call(this, a, c, void 0 === e ? "" : e);
        this.j = b;
        this.A = d
    };
    h(Za, M);
    Za.prototype.u = function() {
        var a = {
            uid: this.g,
            success: this.j,
            newGeometry: this.o.u(),
            expand_t: this.A.o,
            expand_r: this.A.j,
            expand_b: this.A.g,
            expand_l: this.A.m
        };
        this.m && (a.sentinel = this.m);
        return JSON.stringify(a)
    };
    var $a = function(a, b, c, d) {
        K.call(this, a, void 0 === d ? "" : d);
        this.width = b;
        this.height = c
    };
    h($a, K);
    $a.prototype.u = function() {
        return K.prototype.u.call(this, {
            uid: this.g,
            width: this.width,
            height: this.height
        })
    };
    var O = function(a) {
        Ha.call(this, a.A);
        this.D = a.o;
        this.N = a.j;
        this.F = null;
        this.C = [];
        this.B = 0;
        this.A = a.C;
        this.j = a.g;
        this.o = new D(this.H, window.parent, a.B, !0, a.m, this.j);
        var b = n(this.L, this);
        this.o.g.expand_response = b;
        b = n(this.I, this);
        this.o.g.collapse_response = b;
        b = n(this.G, this);
        this.o.g.resize_response = b;
        b = n(this.G, this);
        this.o.g.shrink_response = b;
        b = n(this.M, this);
        this.o.g.geometry_update = b;
        this.o.connect(n(this.O, this));
        this.status = 1;
        N(this, "init_done", new Qa(this.m, "1-0-40", this.j));
        a.F && (a = n(O.prototype.K, this), wa("load", a), wa("resize", a))
    };
    h(O, Ha);
    O.prototype.register = function(a, b, c) {
        this.status = 2;
        this.F = c;
        N(this, "register_done", new Ra(this.m, a, b, this.j))
    };
    var P = function(a, b) {
        N(a, "report_error", new Sa(a.m, b, a.j))
    };
    O.prototype.O = function() {
        for (var a = 0; a < this.C.length; a++) Fa(this.o, this.C[a].type, this.C[a].message.u())
    };
    O.prototype.L = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (3 != this.g) throw Error("Container is not expanding");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!m(b) || !J(b.uid) || "boolean" !== typeof b.success || "string" !== typeof b.newGeometry || "number" !== typeof b.expand_t || "number" !== typeof b.expand_r || "number" !== typeof b.expand_b || "number" !== typeof b.expand_l || "boolean" !== typeof b.push) throw Error("Cannot parse JSON message");
            var c = E(b.newGeometry);
            var d = new Xa(b.uid, b.success, c, new z(b.expand_t, b.expand_r, b.expand_b, b.expand_l), b.push, b.sentinel);
            if (this.m != d.g) throw Error("Wrong source container");
            this.g = d.A ? 2 : 0;
            this.A = d.o;
            Q(this, d.A ? "expanded" : "failed", d.push ? "exp-push" : "exp-ovr", "", {
                t: d.j.o,
                r: d.j.j,
                b: d.j.g,
                l: d.j.m,
                push: d.push
            })
        } catch (e) {}
    };
    O.prototype.G = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (5 != this.g) throw Error("Container is not resizing");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            try {
                var b = JSON.parse(a);
                if (!m(b) || !J(b.uid) || "boolean" !== typeof b.success || "string" !== typeof b.newGeometry) throw Error("Cannot parse JSON message");
                var c = E(b.newGeometry);
                var d = new Ya(b.uid, b.success, c, b.sentinel)
            } catch (u) {
                var e = JSON.parse(a);
                if (!m(e) || !J(e.uid) || "boolean" !== typeof e.success || "string" !== typeof e.newGeometry || "number" !== typeof e.expand_t || "number" !== typeof e.expand_r || "number" !== typeof e.expand_b || "number" !== typeof e.expand_l) throw Error("Cannot parse JSON message");
                var l = E(e.newGeometry);
                d = new Za(e.uid, e.success, l, new z(e.expand_t, e.expand_r, e.expand_b, e.expand_l), e.sentinel)
            }
            if (this.m != d.g) throw Error("Wrong source container");
            this.g = d.j ? 4 : 0;
            this.A = d.o;
            Q(this, d.j ? "resized" : "failed", "resize", "", {})
        } catch (u) {}
    };
    O.prototype.I = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (1 != this.g) throw Error("Container is not collapsing");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = Wa(a);
            if (this.m != b.g) throw Error("Wrong source container");
            this.g = 0;
            this.A = b.o;
            Q(this, "collapsed", "collapse", "")
        } catch (c) {}
    };
    O.prototype.M = function(a) {
        try {
            if (!F(this)) throw Error("Container is not initialized or registered");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = Wa(a);
            if (this.m != b.g) throw Error("Wrong source container");
            this.A = b.o;
            Q(this, "geom-update", "", "")
        } catch (c) {}
    };
    var Q = function(a, b, c, d, e) {
            if (null !== a.F) try {
                a.F(b, {
                    cmd: c,
                    reason: d,
                    info: e
                })
            } catch (l) {
                P(a, "Could not manage to call user-supplied callback")
            }
        },
        S = function(a, b, c, d) {
            setTimeout(n(function() {
                Q(this, a, b, c, d)
            }, R), 0)
        },
        N = function(a, b, c) {
            2 === a.o.status ? Fa(a.o, b, c.u()) : a.C.push({
                type: b,
                message: c
            })
        },
        ab = function(a) {
            var b = new y;
            N(a, "creative_geometry_update", new $a(a.m, b.width, b.height, a.j))
        };
    O.prototype.J = function() {
        2 == this.B && ab(this);
        this.B = 0
    };
    O.prototype.K = function() {
        switch (this.B) {
            case 0:
                ab(this);
                setTimeout(n(this.J, this), 200);
                this.B = 1;
                break;
            case 1:
                this.B = 2
        }
    };

    function bb() {
        var a = void 0 === a ? k : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    var cb = function(a, b) {
            b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
            2048 > b.length && b.push(a)
        },
        db = function(a, b, c) {
            var d = !1;
            d = void 0 === d ? !1 : d;
            var e = window,
                l = "undefined" !== typeof queueMicrotask;
            return function() {
                d && l && queueMicrotask(function() {
                    e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                    e.google_rum_task_id_counter += 1
                });
                var u = bb(),
                    q = 3;
                try {
                    var C = b.apply(this, arguments)
                } catch (I) {
                    q = 13;
                    if (!c) throw I;
                    c(a, I)
                } finally {
                    e.google_measure_js_timing && u && cb(Object.assign({}, {
                        label: a.toString(),
                        value: u,
                        duration: (bb() || 0) - u,
                        type: q
                    }, d && l && {
                        taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                    }), e)
                }
                return C
            }
        },
        T = function(a, b) {
            return db(a, b, function(c, d) {
                var e = new Ca;
                var l = void 0 === l ? e.m : l;
                var u = void 0 === u ? e.j : u;
                if (!(Math.random() > l || (d.error && d.meta && d.id || (d = new va(d, {
                        context: c,
                        id: u
                    })), k.google_js_errors = k.google_js_errors || [], k.google_js_errors.push(d), k.error_rep_loaded))) {
                    c = k.document;
                    l = x(ta(e.g).toString());
                    e = c;
                    e = void 0 === e ? document : e;
                    e = e.createElement("script");
                    e.src = ta(l);
                    var q, C;
                    (q = (l = null == (C = (q = (e.ownerDocument && e.ownerDocument.defaultView || window).document).querySelector) ? void 0 : C.call(q, "script[nonce]")) ? l.nonce || l.getAttribute("nonce") || "" : "") && e.setAttribute("nonce", q);
                    (q = c.getElementsByTagName("script")[0]) && q.parentNode && q.parentNode.insertBefore(e, q);
                    k.error_rep_loaded = !0
                }
            })
        };
    var eb = function(a, b, c) {
            if (2 == R.status) P(R, "Called register multiple times");
            else if ("number" !== typeof a || 0 >= a) P(R, "Invalid initial width");
            else if ("number" !== typeof b || 0 >= b) P(R, "Invalid initial height");
            else {
                var d = null;
                if (null != c) {
                    if ("function" !== typeof c) {
                        P(R, "Invalid callback function");
                        return
                    }
                    d = c
                }
                R.register(a, b, d)
            }
        },
        fb = function() {
            return F(R) ? {
                "exp-ovr": R.D.g,
                "exp-push": R.D.m,
                "read-cookie": R.D.j,
                "write-cookie": R.D.o
            } : (P(R, "Called supports on bad container"), null)
        },
        gb = function() {
            if (!F(R)) return P(R, "Called geom on bad container"), null;
            var a = R.A,
                b = {
                    win: {
                        t: a.j.o,
                        r: a.j.j,
                        b: a.j.g,
                        l: a.j.m,
                        w: a.j.j - a.j.m,
                        h: a.j.g - a.j.o
                    },
                    self: {
                        t: a.m.o,
                        r: a.m.j,
                        b: a.m.g,
                        l: a.m.m,
                        w: a.m.j - a.m.m,
                        h: a.m.g - a.m.o,
                        z: parseInt(a.C, 10),
                        xiv: a.A,
                        yiv: a.B,
                        iv: a.A * a.B
                    },
                    exp: {
                        t: a.o.o,
                        r: a.o.j,
                        b: a.o.g,
                        l: a.o.m,
                        xs: !1,
                        yx: !1
                    }
                };
            a.g && (b.pos = {
                t: a.g.o,
                r: a.g.j,
                b: a.g.g,
                l: a.g.m,
                w: a.g.j - a.g.m,
                h: a.g.g - a.g.o
            });
            return b
        },
        hb = function() {
            if (!F(R)) return P(R, "Called inViewPercentage on bad container"), null;
            var a = R.A;
            return a.A * a.B * 100
        },
        ib = function() {
            if (!F(R)) return P(R, "Called status on bad container"), null;
            switch (R.g) {
                case 0:
                    return "collapsed";
                case 1:
                    return "collapsing";
                case 2:
                    return "expanded";
                case 3:
                    return "expanding";
                case 4:
                    return "resized";
                case 5:
                    return "resizing";
                default:
                    return null
            }
        },
        jb = function(a, b) {
            if (!F(R)) return P(R, "Called meta on bad container"), null;
            if ("string" !== typeof a || /^[\s\xa0]*$/.test(null == a ? "" : String(a))) return P(R, "Invalid property name"), null;
            var c = "shared";
            if (null != b) {
                if ("string" !== typeof b || /^[\s\xa0]*$/.test(null == b ? "" : String(b))) return P(R, "Invalid owner key"), null;
                c = b
            }
            b = R.N;
            return null == b.g[c] || null == b.g[c][a] ? null : b.g[c][a]
        },
        kb = function(a, b) {
            2 == R.status ? "string" !== typeof a || /^[\s\xa0]*$/.test(a) ? P(R, "Invalid cookie name") : ((a = null == b) || !(a = m(b) && "string" === typeof b.info) || (a = null == b.expires) || (a = b.expires, a = m(a) && "function" == typeof a.getFullYear), a ? (S("unsupported", null != b ? "write-cookie" : "read-cookie", "$sf.ext.cookie is not supported", b), P(R, "Used unsupported cookie operations")) : (S("failed", "write-cookie", "Invalid $sf.ext.cookie arguments", b), P(R, "Invalid cookie data"))) : P(R, "Called cookie on unregistered container")
        },
        lb = function(a) {
            if (2 == R.status)
                if (0 == R.g)
                    if (m(a) && (null != a.t || null != a.r || null != a.b || null != a.l) && (null == a.t || "number" === typeof a.t && 0 <= a.t) && (null == a.r || "number" === typeof a.r && 0 <= a.r) && (null == a.b || "number" === typeof a.b && 0 <= a.b) && (null == a.l || "number" === typeof a.l && 0 <= a.l) && (null == a.push || "boolean" === typeof a.push)) {
                        var b = new z(a.t || 0, a.r || 0, a.b || 0, a.l || 0);
                        a = a.push || !1;
                        var c = R;
                        c.g = 3;
                        N(c, "expand_request", new L(c.m, b, a, c.j))
                    } else S("failed", m(a) && "boolean" === typeof a.push && 1 == a.push ? "exp-push" : "exp-ovr", "Invalid $sf.ext.expand arguments", a), P(R, "Invalid expand data");
            else P(R, "Called expand on uncollapsed container");
            else P(R, "Called expand on unregistered container")
        },
        mb = function(a) {
            if (2 == R.status)
                if (1 == R.g || 3 == R.g || 5 == R.g) P(R, "Called resize on container in incorrect state.");
                else {
                    var b = !m(a) || null == a.t && null == a.r && null == a.b && null == a.l || null != a.t && "number" !== typeof a.t || null != a.r && "number" !== typeof a.r || null != a.b && "number" !== typeof a.b || null != a.l && "number" !== typeof a.l ? null : a;
                    if (b) {
                        a = new z(b.t || 0, b.r || 0, b.b || 0, b.l || 0);
                        b = b.push || !1;
                        var c = R;
                        0 < a.o || 0 < a.g || 0 < a.j || 0 < a.m ? (c.g = 3, N(c, "expand_request", new L(c.m, a, b, c.j))) : (c.g = 5, N(c, "shrink_request", new Ua(c.m, new z(-a.o, -a.j, -a.g, -a.m), c.j)));
                        N(c, "resize_request", new Va(c.m, a, b, c.j))
                    } else S("failed", "resize", "Invalid $sf.ext.resize arguments", a), P(R, "Invalid resize data")
                }
            else P(R, "Called resize on unregistered container")
        },
        nb = function() {
            if (2 == R.status) {
                var a;
                (a = 2 == R.g) || (a = 4 == R.g);
                a ? (a = R, a.g = 1, N(a, "collapse_request", new Ta(a.m, a.j))) : P(R, "Called collapse on collapsed container")
            } else P(R, "Called collapse on unregistered container")
        },
        ob = null,
        pb = !1;
    try {
        pb = !!k.sf_.cfg._context.ampcontextVersion
    } catch (a) {}
    var U = window,
        qb = !(U != U.parent && U.parent == U.top);
    try {
        var V, rb;
        if (k.sf_) V = k.sf_.cfg, rb = k.sf_.v;
        else {
            var sb, tb = window.name,
                W = Pa.exec(tb);
            if (null === W) throw Error("Cannot parse serialized data. " + tb.substring(0, 50));
            var X = +W[2],
                Y = W[3];
            if (X > Y.length) throw Error("Parsed content size doesn't match. " + X + ":" + Y.length);
            sb = {
                R: W[1],
                content: Y.substr(0, X),
                P: Y.substr(X)
            };
            V = JSON.parse(sb.P);
            rb = sb.R
        }
        var ub = rb,
            vb, B = V;
        if ("string" !== typeof B.uid && "number" !== typeof B.uid || "string" !== typeof B.hostPeerName || "string" !== typeof B.initialGeometry || "string" !== typeof B.permissions || "string" !== typeof B.metadata || "boolean" !== typeof B.reportCreativeGeometry || "boolean" !== typeof B.isDifferentSourceWindow || null != B.sentinel && "string" !== typeof B.sentinel || (null == B.pbjsAdConfig || "string" === typeof B.pbjsAdConfig) && B.goog_safeframe_hlt && !m(B.goog_safeframe_hlt)) throw Error("Cannot parse config");
        var Ka = E(B.initialGeometry),
            H = JSON.parse(B.permissions);
        if (!m(H) || "boolean" !== typeof H.expandByOverlay || "boolean" !== typeof H.expandByPush || "boolean" !== typeof H.readCookie || "boolean" !== typeof H.writeCookie) throw Error("Cannot parse JSON permissions");
        var La = new Ja,
            Z = JSON.parse(B.metadata),
            wb;
        (wb = !m(Z)) || (wb = !!(!m(Z.shared) || "string" !== typeof Z.shared.sf_ver || "number" !== typeof Z.shared.ck_on || "string" !== typeof Z.shared.flash_ver || Z.shared.canonical_url && "string" !== typeof Z.shared.canonical_url || Z.shared.amp && (!m(Z.shared.amp) || Z.shared.amp.canonical_url && "string" !== typeof Z.shared.amp.canonical_url)));
        if (wb) throw Error("Cannot parse JSON metadata");
        var G = {
            shared: {
                sf_ver: Z.shared.sf_ver,
                ck_on: Z.shared.ck_on,
                flash_ver: Z.shared.flash_ver
            }
        };
        Z.shared.canonical_url && (G.shared.canonical_url = Z.shared.canonical_url);
        Z.shared.amp && (G.shared.is_amp = !0, G.shared.canonical_url = Z.shared.amp.canonical_url);
        var Ma = new Ia,
            Na = Aa();
        vb = new Oa;
        if (!vb.g && "1-0-40" != ub) throw Error("Host has different version from ext container");
        ob = new O(vb);
        if (pb || !qb) p("$sf.ext.register", T(441, eb)), p("$sf.ext.supports", T(443, fb)), p("$sf.ext.geom", T(438, gb)), p("$sf.ext.inViewPercentage", T(439, hb)), p("$sf.ext.status", T(442, ib)), p("$sf.ext.meta", T(440, jb)), p("$sf.ext.cookie", T(436, kb)), p("$sf.ext.expand", T(437, lb)), p("$sf.ext.collapse", T(435, nb)), ob.j && p("$sf.ext.resize", mb);
        V.pbjsAdConfig && p("$sf.ext.pbjsAdConfig", V.pbjsAdConfig)
    } catch (a) {}
    k.sf_ = void 0;
    window.name = "";
    var R = ob;
}).call(this);