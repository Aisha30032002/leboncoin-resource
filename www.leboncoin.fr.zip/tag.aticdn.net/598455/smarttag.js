;
(function() {
    var dfltPluginCfg = {};
    var dfltGlobalCfg = {
        "site": 598455,
        "log": "",
        "logSSL": "",
        "domain": "ati-host.net",
        "collectDomain": "logw360.ati-host.net",
        "collectDomainSSL": "logws1360.ati-host.net",
        "userIdOrigin": "server",
        "pixelPath": "/hit.xiti",
        "disableCookie": false,
        "disableStorage": false,
        "cookieSecure": false,
        "cookieDomain": "",
        "preview": false,
        "plgs": ["Campaigns", "Clicks", "ContextVariables", "IdentifiedVisitor", "InternalSearch", "MvTesting", "Offline", "OnSiteAds", "Page", "SalesTracker", "ClientSideUserId", "Privacy"],
        "lazyLoadingPath": "",
        "documentLevel": "document",
        "redirect": false,
        "activateCallbacks": true,
        "medium": "",
        "ignoreEmptyChapterValue": true,
        "base64Storage": false,
        "sendHitWhenOptOut": true,
        "forceHttp": false,
        "requestMethod": "GET",
        "maxHitSize": 2000,
        "urlPropertyAuto": false,
        "urlPropertyQueryString": false
    };
    (function(a) {
        a.ATInternet = a.ATInternet || {};
        a.ATInternet.Tracker = a.ATInternet.Tracker || {};
        a.ATInternet.Tracker.Plugins = a.ATInternet.Tracker.Plugins || {}
    })(window);
    var Utils = function() {
        function a(h) {
            var b = typeof h;
            if ("object" !== b || null === h) return "string" === b && (h = '"' + h + '"'), String(h);
            var e, f, c = [],
                d = h.constructor === Array;
            for (e in h) h.hasOwnProperty(e) && (f = h[e], b = typeof f, "function" !== b && "undefined" !== b && ("string" === b ? f = '"' + f.replace(/[^\\]"/g, '\\"') + '"' : "object" === b && null !== f && (f = a(f)), c.push((d ? "" : '"' + e + '":') + String(f))));
            return (d ? "[" : "{") + String(c) + (d ? "]" : "}")
        }

        function g(a) {
            return null === a ? "" : (a + "").replace(c, "")
        }

        function k(a) {
            var m, e = null;
            return (a = g(a + "")) &&
                !g(a.replace(b, function(a, h, b, c) {
                    m && h && (e = 0);
                    if (0 === e) return a;
                    m = b || h;
                    e += !c - !b;
                    return ""
                })) ? Function("return " + a)() : null
        }
        var d = this,
            b = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g,
            c = RegExp("^[\\x20\\t\\r\\n\\f]+|((?:^|[^\\\\])(?:\\\\.)*)[\\x20\\t\\r\\n\\f]+$", "g");
        d.isLocalStorageAvailable = function() {
            try {
                var a = localStorage;
                a.setItem("__storage_test__", "__storage_test__");
                a.removeItem("__storage_test__");
                return !0
            } catch (b) {
                return !1
            }
        };
        d.isBeaconMethodAvailable = function() {
            return window.navigator && "function" === typeof window.navigator.sendBeacon
        };
        d.Base64 = {
            _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
            encode: function(a) {
                var b = "",
                    e, f, c, n, p, l, s = 0;
                for (a = d.Base64._utf8_encode(a); s < a.length;) e = a.charCodeAt(s++), f = a.charCodeAt(s++), c = a.charCodeAt(s++), n = e >> 2, e = (e & 3) << 4 | f >> 4, p = (f & 15) << 2 | c >> 6, l = c & 63, isNaN(f) ? p = l = 64 : isNaN(c) && (l = 64), b = b + this._keyStr.charAt(n) + this._keyStr.charAt(e) + this._keyStr.charAt(p) + this._keyStr.charAt(l);
                return b
            },
            decode: function(a) {
                var b = "",
                    e, f, c, n, p, l = 0;
                for (a = a.replace(/[^A-Za-z0-9\+\/\=]/g, ""); l < a.length;) e = this._keyStr.indexOf(a.charAt(l++)), f = this._keyStr.indexOf(a.charAt(l++)), n = this._keyStr.indexOf(a.charAt(l++)), p = this._keyStr.indexOf(a.charAt(l++)), e = e << 2 | f >> 4, f = (f & 15) << 4 | n >> 2, c = (n & 3) << 6 | p, b += String.fromCharCode(e), 64 != n && (b += String.fromCharCode(f)), 64 != p && (b += String.fromCharCode(c));
                return b = d.Base64._utf8_decode(b)
            },
            _utf8_encode: function(a) {
                a = a.replace(/\r\n/g, "\n");
                for (var b = "", e = 0; e <
                    a.length; e++) {
                    var f = a.charCodeAt(e);
                    128 > f ? b += String.fromCharCode(f) : (127 < f && 2048 > f ? b += String.fromCharCode(f >> 6 | 192) : (b += String.fromCharCode(f >> 12 | 224), b += String.fromCharCode(f >> 6 & 63 | 128)), b += String.fromCharCode(f & 63 | 128))
                }
                return b
            },
            _utf8_decode: function(a) {
                for (var b = "", e = 0, f, c, d; e < a.length;) f = a.charCodeAt(e), 128 > f ? (b += String.fromCharCode(f), e++) : 191 < f && 224 > f ? (c = a.charCodeAt(e + 1), b += String.fromCharCode((f & 31) << 6 | c & 63), e += 2) : (c = a.charCodeAt(e + 1), d = a.charCodeAt(e + 2), b += String.fromCharCode((f & 15) << 12 |
                    (c & 63) << 6 | d & 63), e += 3);
                return b
            }
        };
        d.loadScript = function(a, b) {
            var e;
            b = b || function() {};
            e = document.createElement("script");
            e.type = "text/javascript";
            e.src = a.url;
            e.async = !1;
            e.defer = !1;
            e.onload = e.onreadystatechange = function(a) {
                a = a || window.event;
                if ("load" === a.type || /loaded|complete/.test(e.readyState) && (!document.documentMode || 9 > document.documentMode)) e.onload = e.onreadystatechange = e.onerror = null, b(null, a)
            };
            e.onerror = function(a) {
                e.onload = e.onreadystatechange = e.onerror = null;
                b({
                    msg: "script not loaded",
                    event: a
                })
            };
            var f = document.head || document.getElementsByTagName("head")[0];
            f.insertBefore(e, f.lastChild)
        };
        d.cloneSimpleObject = function(a, b) {
            if ("object" !== typeof a || null === a || a instanceof Date) return a;
            var e = new a.constructor,
                f;
            for (f in a) a.hasOwnProperty(f) && (void 0 === f || b && void 0 === a[f] || (e[f] = d.cloneSimpleObject(a[f])));
            return e
        };
        d.isEmptyObject = function(a) {
            for (var b in a)
                if (a.hasOwnProperty(b)) return !1;
            return !0
        };
        d.isObject = function(a) {
            return null !== a && "object" === typeof a && !(a instanceof Array)
        };
        d.ATVALUE = "_ATVALUE";
        d.ATPREFIX = "_ATPREFIX";
        d.object2Flatten = function(a, b, e, f, c) {
            var n = {},
                p = "",
                l = "",
                s = [],
                g = "",
                r = 0,
                u;
            for (u in a)
                if (a.hasOwnProperty(u))
                    if (n = d.splitProtocolAndKey(u, c), p = n.prefix || f || "", l = (b ? b + "_" : "") + n.key, d.isObject(a[u])) d.object2Flatten(a[u], l, e, p, c);
                    else {
                        s = l.split("_");
                        g = "";
                        for (r = 0; r < s.length; r++) n = d.splitProtocolAndKey(s[r], c), p = n.prefix || p, g += n.key + (r < s.length - 1 ? "_" : "");
                        l = g || l;
                        e[l] = e[l] || {};
                        e[l][d.ATVALUE] = a[u];
                        e[l][d.ATPREFIX] = p
                    }
        };
        d.flatten2Object = function(a, b, e) {
            b = b.split("_");
            var f, c;
            for (c = 0; c <
                b.length - 1; c++) f = b[c], a[f] || (a[f] = {}), a = a[f];
            if (a.hasOwnProperty(d.ATVALUE)) {
                f = a[d.ATVALUE];
                var n = a[d.ATPREFIX];
                delete a[d.ATVALUE];
                delete a[d.ATPREFIX];
                a.$ = {};
                a.$[d.ATVALUE] = f;
                a.$[d.ATPREFIX] = n
            }
            e = d.cloneSimpleObject(e);
            a[b[c]] ? a[b[c]].$ = e : a[b[c]] = e
        };
        d.getFormattedObject = function(a) {
            var b = {},
                e, f;
            for (f in a) a.hasOwnProperty(f) && (a[f].hasOwnProperty(d.ATVALUE) ? (e = a[f][d.ATPREFIX] ? a[f][d.ATPREFIX] + ":" + f : f, b[e] = a[f][d.ATVALUE]) : b[f] = d.getFormattedObject(a[f]));
            return b
        };
        d.completeFstLevelObj = function(a,
            b, e) {
            if (a) {
                if (b)
                    for (var f in b) !b.hasOwnProperty(f) || a[f] && !e || (a[f] = b[f])
            } else a = b;
            return a
        };
        d.getObjectKeys = function(a) {
            var b = [],
                e;
            for (e in a) a.hasOwnProperty(e) && b.push(e);
            return b
        };
        d.objectToLowercase = function(a) {
            var b = {},
                e;
            for (e in a) a.hasOwnProperty(e) && (d.isObject(a[e]) ? b[e.toLowerCase()] = d.objectToLowercase(a[e]) : b[e.toLowerCase()] = a[e]);
            return b
        };
        d.splitProtocolAndKey = function(a, b) {
            var e, f;
            2 > a.length || ":" !== a[1] ? (e = "", f = a) : 4 > a.length || ":" !== a[3] ? (e = a.substring(0, 1), f = a.substring(2, a.length)) :
                (e = a.substring(0, 3), f = a.substring(4, a.length));
            b && (e = e.toLowerCase(), f = f.toLowerCase());
            return {
                prefix: e,
                key: f
            }
        };
        d.jsonSerialize = function(b) {
            try {
                return "undefined" !== typeof JSON && JSON.stringify ? JSON.stringify(b) : a(b)
            } catch (c) {
                return null
            }
        };
        d.jsonParse = function(a) {
            try {
                return "undefined" !== typeof JSON && JSON.parse ? JSON.parse(a + "") : k(a)
            } catch (b) {
                return null
            }
        };
        d.trim = function(a) {
            try {
                return String.prototype.trim ? a.trim() : a.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "")
            } catch (b) {
                return a
            }
        };
        d.arrayIndexOf =
            function(a, b) {
                if (Array.prototype.indexOf) {
                    var c = -1;
                    "undefined" !== typeof a.indexOf(b) && (c = a.indexOf(b));
                    return c
                }
                return function(a) {
                    if (null == this) throw new TypeError;
                    var b = Object(this),
                        h = b.length >>> 0;
                    if (0 === h) return -1;
                    var c = 0;
                    1 < arguments.length && (c = Number(arguments[1]), c != c ? c = 0 : 0 != c && Infinity != c && -Infinity != c && (c = (0 < c || -1) * Math.floor(Math.abs(c))));
                    if (c >= h) return -1;
                    for (c = 0 <= c ? c : Math.max(h - Math.abs(c), 0); c < h; c++)
                        if (c in b && b[c] === a) return c;
                    return -1
                }.apply(a, [b])
            };
        d.uuid = function() {
            function a(f) {
                var h =
                    Math.random();
                try {
                    c && (h = b.getRandomValues(new Uint32Array(1))[0] / Math.pow(2, 32))
                } catch (d) {}
                return Math.floor((9 * h + 1) * Math.pow(10, f - 1))
            }
            var b = window.crypto || window.msCrypto,
                c = null !== b && "object" === typeof b;
            return {
                v4: function() {
                    try {
                        if (c) return ([1E7] + -1E3 + -4E3 + -8E3 + -1E11).replace(/[018]/g, function(a) {
                            return (a ^ b.getRandomValues(new Uint32Array(1))[0] & 15 >> a / 4).toString(16)
                        })
                    } catch (a) {}
                    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
                        var b = 16 * Math.random() | 0;
                        return ("x" === a ? b : b & 3 |
                            8).toString(16)
                    })
                },
                num: function(b) {
                    var c = new Date,
                        e = function(a) {
                            a -= 100 * Math.floor(a / 100);
                            return 10 > a ? "0" + a : String(a)
                        };
                    return e(c.getHours()) + "" + e(c.getMinutes()) + "" + e(c.getSeconds()) + "" + a(b - 6)
                }
            }
        };
        d.isPreview = function() {
            return window.navigator && "preview" === window.navigator.loadPurpose
        };
        d.isPrerender = function(a) {
            var b, c = !1,
                f = ["webkit", "ms"];
            if ("prerender" === document.visibilityState) b = "visibilitychange";
            else
                for (var g = 0; g < f.length; g++) "prerender" === document[f[g] + "VisibilityState"] && (b = f[g] + "visibilitychange");
            if ("undefined" !== typeof b) {
                var n = function(c) {
                    a(c);
                    d.removeEvtListener(document, b, n)
                };
                d.addEvtListener(document, b, n);
                c = !0
            }
            return c
        };
        d.addEvtListener = function(a, b, c) {
            a.addEventListener ? a.addEventListener(b, c, !1) : a.attachEvent && a.attachEvent("on" + b, c)
        };
        d.removeEvtListener = function(a, b, c) {
            a.removeEventListener ? a.removeEventListener(b, c, !1) : a.detachEvent && a.detachEvent("on" + b, c)
        };
        d.hashcode = function(a) {
            var b = 0;
            if (0 === a.length) return b;
            for (var c = 0; c < a.length; c++) var f = a.charCodeAt(c),
                b = (b << 5) - b + f,
                b = b | 0;
            return b
        };
        d.setLocation = function(a) {
            var b = a.location;
            a = window[a.target] || window;
            b && (a.location.href = b)
        };
        d.dispatchCallbackEvent = function(a) {
            var b;
            if ("function" === typeof window.Event) b = new Event("ATCallbackEvent");
            else try {
                b = document.createEvent("Event"), b.initEvent && b.initEvent("ATCallbackEvent", !0, !0)
            } catch (c) {}
            b && "function" === typeof document.dispatchEvent && (b.name = a, document.dispatchEvent(b))
        };
        d.addCallbackEvent = function(a) {
            d.addEvtListener(document, "ATCallbackEvent", a)
        };
        d.removeCallbackEvent = function(a) {
            d.removeEvent("ATCallbackEvent",
                a)
        };
        (function() {
            function a(b, c) {
                c = c || {
                    bubbles: !1,
                    cancelable: !1,
                    detail: void 0
                };
                var f;
                try {
                    f = document.createEvent("CustomEvent"), f.initCustomEvent(b, c.bubbles, c.cancelable, c.detail)
                } catch (h) {}
                return f
            }
            "function" === typeof window.CustomEvent ? window.ATCustomEvent = window.CustomEvent : ("function" === typeof window.Event && (a.prototype = window.Event.prototype), window.ATCustomEvent = a)
        })();
        d.addEvent = function(a, b, c, f) {
            d[a] = new ATCustomEvent(a, {
                detail: {
                    name: b,
                    id: c
                }
            });
            d.addEvtListener(document, a, f)
        };
        d.removeEvent =
            function(a, b) {
                d.removeEvtListener(document, a, b)
            };
        d.dispatchEvent = function(a, b) {
            d[a] = d[a] || new ATCustomEvent(a, {
                detail: {
                    name: b,
                    id: -1
                }
            });
            try {
                document.dispatchEvent(d[a])
            } catch (c) {}
        };
        d.privacy = new function() {
            function a(b, c) {
                var f = [],
                    e, h;
                e = {};
                for (var l = 0; l < b.length; l++) {
                    e = {};
                    d.object2Flatten(b[l], null, e, null, !0);
                    for (var m in e) e.hasOwnProperty(m) && -1 === d.arrayIndexOf(c, m) && delete e[m];
                    if (!d.isEmptyObject(e)) {
                        h = {};
                        for (var g in e) e.hasOwnProperty(g) && d.flatten2Object(h, g, e[g]);
                        e = d.getFormattedObject(h);
                        f.push(e)
                    }
                }
                return f
            }

            function b(a, c, f) {
                1 < a.length ? ("undefined" === typeof c[a[0]] && (c[a[0]] = {}), b(a.slice(1, a.length), c[a[0]], f)) : c[a[0]] = f
            }

            function c(a, b, f, h, l) {
                var d = h ? h : {};
                if (!a || "object" !== typeof a || a instanceof Array)
                    if ("undefined" !== typeof a && 0 <= f.indexOf(l) || "undefined" === typeof f) d[l] = a;
                    else
                        for (b = 0; b < f.length; b++) {
                            if (l && 0 === l.indexOf(f[b])) {
                                d[l] = a;
                                break
                            }
                        } else
                            for (var m in a) a.hasOwnProperty(m) && c(a[m], b, f, d, (l ? l + b : "") + m);
                if (void 0 === h) return d
            }

            function f(a, f, h) {
                for (var l = [], g = 0; g < a.length; g++) {
                    var w;
                    w = c(a[g], h, f);
                    var s = h,
                        n = {},
                        p = void 0;
                    for (p in w)
                        if (w.hasOwnProperty(p)) {
                            var q = p.split(s);
                            b(q, n, w[p])
                        }
                    w = n;
                    d.isEmptyObject(w) || l.push(w)
                }
                return l
            }

            function g(a, b) {
                var c = "",
                    f = {
                        key: "",
                        flattenedProperty: ""
                    };
                switch (!0) {
                    case 0 === a.indexOf("stc_"):
                        c = "stc_";
                        break;
                    case 0 === a.indexOf("stc/"):
                        c = "stc/";
                        break;
                    case 0 === a.indexOf("events_"):
                        c = "events_";
                        break;
                    case 0 === a.indexOf("context_"):
                        c = "context_";
                        break;
                    default:
                        f.key = a
                }
                if (c) {
                    var e = c.substring(0, c.length - 1);
                    f.key = e;
                    0 > b.indexOf(e) && (f.flattenedProperty = a.substring(c.length))
                }
                return f
            }

            function n(a) {
                for (var b = [], c = {}, f = 0; f < a.length; f++)
                    if ("string" === typeof a[f]) {
                        var e = {};
                        if (-1 < a[f].indexOf("#")) {
                            var h = a[f].split("#");
                            h[0] === s && (e = g(h[1], a))
                        } else e = g(a[f], a);
                        e.key && 0 > b.indexOf(e.key) && b.push(e.key);
                        e.flattenedProperty && (c[e.key] = (c[e.key] || []).concat(e.flattenedProperty))
                    } else
                        for (var l in a[f]) a[f].hasOwnProperty(l) && (0 > b.indexOf(l) && b.push(l), 0 > a.indexOf(l) && (c[l] = (c[l] || []).concat(a[f][l])));
                return {
                    keys: b,
                    values: c
                }
            }
            var p = this,
                l = {
                    storageParams: null,
                    bufferParams: null
                },
                s = "";
            p.CONSENTNO =
                "Consent-NO";
            p.ALL = "*";
            p.testStorageParam = function(a, b) {
                var c;
                if (l.storageParams instanceof Array) {
                    for (var f, e = l.storageParams.length - 1; 0 <= e; e--)
                        if (f = l.storageParams[e], "string" === typeof f) {
                            if (f === a || f === p.ALL) return {
                                toSetInStorage: !0
                            }
                        } else {
                            a: {
                                c = a;
                                var h = b,
                                    d = void 0,
                                    m = void 0;
                                for (m in f)
                                    if (f.hasOwnProperty(m) && c === m) {
                                        if (!h) {
                                            c = !0;
                                            break a
                                        }
                                        d = [];
                                        f[m] instanceof Array ? d = f[m] : d.push(f[m]);
                                        for (var g = 0; g < d.length; g++)
                                            if (d[g] === h) {
                                                c = !0;
                                                break a
                                            }
                                    }
                                c = !1
                            }
                            if (c) return {
                                toSetInStorage: !0
                            }
                        }
                    return {
                        toSetInStorage: !1
                    }
                }
                return {
                    toSetInStorage: !0
                }
            };
            p.processStorageParams = function(a, b, c) {
                if (c) {
                    c = c();
                    var f = n(l.storageParams);
                    if (f.keys[0] !== p.ALL)
                        for (var e in c)
                            if (c.hasOwnProperty(e) && void 0 !== c[e])
                                if (-1 === d.arrayIndexOf(f.keys, e)) a && a(e);
                                else if (d.isObject(c[e])) {
                        var h = e,
                            m = c[e].val,
                            g = f.values[e],
                            s = a,
                            q = b;
                        if ("undefined" !== typeof g) {
                            var k = [];
                            g instanceof Array ? k = g : k.push(g);
                            g = void 0;
                            for (g in m) m.hasOwnProperty(g) && -1 === d.arrayIndexOf(k, g) && s && s([h, g]);
                            s && q && d.isEmptyObject(q(h)) && s(h)
                        }
                    }
                }
            };
            p.testBufferParam = function(b, c) {
                var e, m;
                if (l.bufferParams instanceof Array) {
                    e = n(l.bufferParams);
                    for (m = 0; m < e.keys.length; m++)
                        if (e.keys[m] === b || e.keys[m] === p.ALL)
                            if (e.values.hasOwnProperty(e.keys[m])) {
                                var g = {};
                                g[e.keys[m]] = e.values[e.keys[m]];
                                a: {
                                    e = b;m = c;
                                    if (d.isObject(g)) {
                                        var w = void 0,
                                            s = [],
                                            q = !1,
                                            k = w = w = void 0;
                                        for (k in g)
                                            if (g.hasOwnProperty(k) && e === k && (w = m, "string" === typeof w && (w = d.jsonParse(w) || w), "object" === typeof w)) {
                                                w instanceof Array ? (s = w, q = !0) : s.push(w);
                                                w = "stc" === e ? f(s, g[k], "/") : "events" === e || "context" === e ? f(s, g[k], "_") : a(s, g[k]);
                                                0 === w.length ? (e = !1, m = void 0) : (w = q ?
                                                    w : w[0], e = !0, m = d.jsonSerialize(w));
                                                break a
                                            }
                                    }
                                    e = !1;m = void 0
                                }
                                if (e) return {
                                    toSetInBuffer: !0,
                                    value: m
                                };
                                break
                            } else return {
                                toSetInBuffer: !0,
                                value: c
                            };
                    return {
                        toSetInBuffer: !1
                    }
                }
                return {
                    toSetInBuffer: !0,
                    value: c
                }
            };
            p.processBufferParams = function(b, c, e) {
                if (c) {
                    c = c();
                    var m = n(l.bufferParams);
                    if (m.keys[0] !== p.ALL)
                        for (var g in c)
                            if (c.hasOwnProperty(g))
                                if (-1 === d.arrayIndexOf(m.keys, g)) b && b(g);
                                else {
                                    var s = g,
                                        q = c[g],
                                        k = m.values[g],
                                        y = b,
                                        H = e;
                                    if ("undefined" !== typeof k && "undefined" !== typeof q) {
                                        var E = [],
                                            B = q._value,
                                            F = [],
                                            I = !1,
                                            D = void 0,
                                            D = void 0;
                                        k instanceof Array ? E = k : E.push(k);
                                        "string" === typeof B && (B = d.jsonParse(B) || B);
                                        "object" === typeof B && (B instanceof Array ? (F = B, I = !0) : F.push(B), D = "stc" === s ? f(F, E, "/") : "events" === s || "context" === s ? f(F, E, "_") : a(F, E), 0 === D.length ? y && y(s) : (D = I ? D : D[0], H && H(s, d.jsonSerialize(D), q._options)))
                                    }
                                }
                }
            };
            p.setMode = function(a) {
                s = a
            };
            p.setParameters = function(a) {
                l = a
            };
            p.getParameters = function() {
                return l
            };
            p.resetParameters = function() {
                l = {
                    storageParams: null,
                    bufferParams: null
                }
            }
        };
        d.optedOut = null;
        d.addOptOutEvent = function(a,
            b) {
            d.addEvent("ATOptOutEvent", "clientsideuserid", a, b)
        };
        d.removeOptOutEvent = function(a) {
            d.removeEvent("ATOptOutEvent", a)
        };
        d.dispatchOptOutEvent = function(a) {
            d.optedOut = a;
            d.dispatchEvent("ATOptOutEvent", "clientsideuserid")
        };
        d.userOptedOut = function() {
            d.dispatchOptOutEvent(!0)
        };
        d.userOptedIn = function() {
            d.dispatchOptOutEvent(!1)
        };
        d.isOptedOut = function() {
            if (null === d.optedOut) {
                var a;
                a: {
                    a = null;d.isLocalStorageAvailable() && (a = localStorage.getItem("atuserid"));
                    if (null === a) {
                        var b = /(?:^| )atuserid=([^;]+)/.exec(document.cookie);
                        null !== b && (a = b[1])
                    }
                    if (null !== a) try {
                        a = decodeURIComponent(a)
                    } catch (c) {}
                    if (a && (a = d.jsonParse(a) || d.jsonParse(d.Base64.decode(a)), null !== a)) {
                        a = "OPT-OUT" === a.val;
                        break a
                    }
                    a = !1
                }
                d.optedOut = a
            }
            return !!d.optedOut
        };
        d.consentReceived = function(a) {
            d.consent = !!a
        };
        d.consent = !0;
        d.isTabOpeningAction = function(a) {
            var b = !1;
            a && (a.ctrlKey || a.shiftKey || a.metaKey || a.button && 1 === a.button) && (b = !0);
            return b
        };
        d.CLICKS_REDIRECTION = "redirection";
        d.CLICKS_FORM = "form";
        d.CLICKS_MAILTO = "mailto"
    };
    ATInternet.Utils = new Utils;
    var BuildManager = function(a) {
            var g = this,
                k = 0,
                d = 0,
                b = ["dz"],
                c = "",
                h = function(a, b, c, f, e, h, d) {
                    a = "&" + a + "=";
                    return {
                        param: a,
                        paramSize: a.length,
                        str: b,
                        strSize: b.length,
                        truncate: c,
                        multihit: f,
                        separator: e || "",
                        encode: h,
                        last: d
                    }
                },
                m = function(a, b) {
                    var c = "",
                        f = 0,
                        e = 0,
                        h = 0,
                        f = -1,
                        d = null,
                        m = null,
                        g;
                    for (g in a) a.hasOwnProperty(g) && (d = a[g]) && (f = b - e, d.last && null !== m ? m[g] = d : d.strSize + d.paramSize <= f ? (c += d.param + d.str, e += d.paramSize + d.strSize) : (m = m || {}, m[g] = d, d.truncate && (h = f - d.paramSize, d.separator && (f = d.str.substring(0, f), f = d.encode ?
                        f.lastIndexOf(encodeURIComponent(d.separator)) : f.lastIndexOf(d.separator), 0 < f && (h = f)), c += d.param + d.str.substring(0, h), e += d.paramSize + d.str.substring(0, h).length, m[g].str = d.str.substring(h, d.strSize), m[g].strSize = m[g].str.length)));
                    return [c, m]
                },
                e = function(c, f, e) {
                    var g = "",
                        r = function(c) {
                            if (c === {}) return [];
                            var f = [],
                                e;
                            e = {};
                            var l = !1,
                                s = void 0,
                                r, n, q, k, p, u, v, z, G = "",
                                x;
                            for (x in c)
                                if (c.hasOwnProperty(x))
                                    if (u = p = k = q = !1, r = c[x]._value, n = c[x]._options || {}, "boolean" === typeof n.encode && (q = n.encode), "function" === typeof r &&
                                        (r = r()), r = r instanceof Array ? r.join(n.separator || ",") : "object" === typeof r ? ATInternet.Utils.jsonSerialize(r) : "undefined" === typeof r ? "undefined" : r.toString(), q && (r = encodeURIComponent(r)), -1 < ATInternet.Utils.arrayIndexOf(b, x) ? k = !0 : "boolean" === typeof n.truncate && (k = n.truncate), "boolean" === typeof n.multihit && (p = n.multihit), "boolean" === typeof n.last && (u = n.last), r = h(x, r, k, p, n.separator, q, u), p) d -= r.paramSize + r.strSize, G += r.param + r.str;
                                    else if (u) r.paramSize + r.strSize > d && (r.str = r.str.substring(0, d - r.paramSize),
                                r.strSize = r.str.length), v = x, z = r;
                            else if (e[x] = r, e[x].paramSize + e[x].strSize > d && !e[x].truncate) {
                                a.emit("Tracker:Hit:Build:Error", {
                                    lvl: "ERROR",
                                    msg: 'Too long parameter: "' + e[x].param + '"',
                                    details: {
                                        value: e[x].str
                                    }
                                });
                                l = !0;
                                s = x;
                                break
                            }
                            v && (e[v] = z);
                            e = [e, l, s, G];
                            c = e[0];
                            l = e[1];
                            g = e[3];
                            l && (e = e[2], c = c[e], c.str = c.str.substring(0, d - c.paramSize), c.strSize = c.str.length, l = {}, l.mherr = h("mherr", "1", !1, !1, "", !1, !1), l[e] = c, c = l);
                            c = m(c, d);
                            if (null === c[1]) f = c[0];
                            else
                                for (f.push(c[0]); null !== c[1];) c = m(c[1], d), f.push(c[0]);
                            return f
                        },
                        n = "";
                    a.buffer.presentInFilters(f, "hitType") || (f = a.buffer.addInFilters(f, "hitType", ["page"]));
                    f = a.buffer.addInFilters(f, "hitType", ["all"]);
                    var q, k;
                    if (ATInternet.Utils.isObject(c)) {
                        f = a.buffer.addInFilters(f, "permanent", !0);
                        f = a.buffer.get(f, !0);
                        for (q in c) c.hasOwnProperty(q) && (n = {}, c[q] && "object" === typeof c[q] && c[q].hasOwnProperty("_value") ? (k = c[q]._value, c[q].hasOwnProperty("_options") && (n = c[q]._options)) : k = c[q], k = ATInternet.Utils.privacy.testBufferParam(q, k), k.toSetInBuffer && (f[q] = {
                            _value: k.value,
                            _options: n
                        }));
                        n = r(f)
                    } else
                        for (q in f = a.buffer.get(f, !0), n = r(f), f) f.hasOwnProperty(q) && (f[q]._options && f[q]._options.permanent || a.buffer.del(q));
                    e && e(n, g)
                };
            g.getCollectDomain = function() {
                var b = "",
                    b = a.getConfig("logSSL") || a.getConfig("log"),
                    c = a.getConfig("domain");
                return b = b && c ? b + "." + c : a.getConfig("collectDomainSSL") || a.getConfig("collectDomain")
            };
            var f = function(b) {
                    var c = "",
                        f = a.getConfig("baseURL");
                    if (f) c = f;
                    else {
                        var f = g.getCollectDomain(),
                            e = a.getConfig("pixelPath"),
                            e = e || "/";
                        "/" !== e.charAt(0) && (e = "/" +
                            e);
                        f && (c = (a.getConfig("forceHttp") ? "http://" : "https://") + f + e)
                    }
                    f = a.getConfig("site");
                    c && f ? b && b(null, c + "?s=" + f) : b && b({
                        message: "Config error"
                    })
                },
                q = function(a, b, c) {
                    f(function(f, h) {
                        f ? c && c(f) : (d = k - (h.length + 27), e(a, b, function(a, b) {
                            var f = [],
                                e = ATInternet.Utils.uuid().num(13);
                            if (a instanceof Array)
                                for (var d = 1; d <= a.length; d++) f.push(h + b + "&mh=" + d + "-" + a.length + "-" + e + a[d - 1]);
                            else f.push(h + b + a);
                            c && c(null, f)
                        }))
                    })
                },
                n = function(b, c, f, e, h, d, m) {
                    return function() {
                        return function(g) {
                            a.emit(b, {
                                lvl: h,
                                details: {
                                    hit: c,
                                    method: f,
                                    event: g,
                                    isMultiHit: d,
                                    elementType: m
                                }
                            });
                            e && e()
                        }
                    }()
                };
            g.send = function(b, c, f, e, h) {
                q(b, c, function(b, c) {
                    if (b) a.emit("Tracker:Hit:Build:Error", {
                        lvl: "ERROR",
                        msg: b.message,
                        details: {}
                    }), f && f();
                    else
                        for (var d = 0; d < c.length; d++) g.sendUrl(c[d], f, e, h)
                })
            };
            k = Math.max(a.getConfig("maxHitSize") || 0, 2E3);
            d = Math.max(a.getConfig("maxHitSize") || 0, 2E3);
            c = a.getConfig("requestMethod");
            g.sendUrl = function(b, f, e, h) {
                var d = -1 < b.indexOf("&mh=");
                e = e || c;
                ATInternet.Utils.isOptedOut() && !a.getConfig("sendHitWhenOptOut") ? n("Tracker:Hit:Sent:NoTrack",
                    b, e, f, "INFO", d, h)() : "POST" === e && ATInternet.Utils.isBeaconMethodAvailable() ? (h = "Tracker:Hit:Sent:Error", e = "ERROR", window.navigator.sendBeacon(b, null) && (h = "Tracker:Hit:Sent:Ok", e = "INFO"), n(h, b, "POST", f, e, d, "")()) : (e = new Image, e.onload = n("Tracker:Hit:Sent:Ok", b, "GET", f, "INFO", d, h), e.onerror = n("Tracker:Hit:Sent:Error", b, "GET", f, "ERROR", d, h), e.src = b)
            }
        },
        TriggersManager = function() {
            function a(a, c, h) {
                for (var d = [], e = 0; e < a.length; e++) a[e].callback(c, h), a[e].singleUse || d.push(a[e]);
                return d
            }

            function g(a, c, h,
                d) {
                var e = a.shift();
                if ("*" === e) return c["*"] = c["*"] || [], c["*"].push({
                    callback: h,
                    singleUse: d
                }), c["*"].length - 1;
                if (0 === a.length) return g([e, "*"], c, h, d);
                c["*"] = c["*"] || [];
                c[e] = c[e] || {};
                return g(a, c[e], h, d)
            }

            function k(b, c, h, d) {
                var e = c.shift();
                "*" !== e && (0 === c.length ? k(b, [e, "*"], h, d) : h[e] && (h[e]["*"] = a(h[e]["*"], b, d), k(b, c, h[e], d)))
            }
            var d = {};
            this.on = function(a, c, h) {
                h = h || !1;
                return g(a.split(":"), d, c, h)
            };
            this.emit = function(b, c) {
                d["*"] && (d["*"] = a(d["*"], b, c));
                k(b, b.split(":"), d, c)
            }
        },
        PluginsManager = function(a) {
            var g = {},
                k = {},
                d = 0,
                b = {},
                c = 0,
                h = function(a) {
                    var b = !1;
                    g[a] && (b = !0);
                    return b
                },
                m = this.unload = function(b) {
                    h(b) ? (g[b] = void 0, a.emit("Tracker:Plugin:Unload:" + b + ":Ok", {
                        lvl: "INFO"
                    })) : a.emit("Tracker:Plugin:Unload:" + b + ":Error", {
                        lvl: "ERROR",
                        msg: "not a known plugin"
                    });
                    return a
                },
                e = this.load = function(b, c) {
                    "function" === typeof c ? "undefined" === typeof a.getConfig.plgAllowed || 0 === a.getConfig.plgAllowed.length || -1 < a.getConfig.plgAllowed.indexOf(b) ? (g[b] = new c(a), k[b] && h(b) && (k[b] = !1, d--, h(b + "_ll") && m(b + "_ll"), 0 === d && a.emit("Tracker:Plugin:Lazyload:File:Complete", {
                        lvl: "INFO",
                        msg: "LazyLoading triggers are finished"
                    })), a.emit("Tracker:Plugin:Load:" + b + ":Ok", {
                        lvl: "INFO"
                    })) : a.emit("Tracker:Plugin:Load:" + b + ":Error", {
                        lvl: "ERROR",
                        msg: "Plugin not allowed",
                        details: {}
                    }) : a.emit("Tracker:Plugin:Load:" + b + ":Error", {
                        lvl: "ERROR",
                        msg: "not a function",
                        details: {
                            obj: c
                        }
                    });
                    return a
                },
                f = this.isLazyloading = function(a) {
                    return a ? !0 === k[a] : 0 !== d
                },
                q = function(a) {
                    return !h(a) && !f(a) && h(a + "_ll")
                },
                n = function(b) {
                    k[b] = !0;
                    d++;
                    ATInternet.Utils.loadScript({
                        url: a.getConfig("lazyLoadingPath") + b + ".js"
                    })
                },
                p = function(a) {
                    return q(a) ? (n(a), !0) : !1
                },
                l = function(a) {
                    b[a] ? b[a]++ : b[a] = 1;
                    c++
                },
                s = function(a, b, c, f) {
                    var e = null;
                    b = b.split(".");
                    h(a) && g[a][b[0]] && (e = 1 < b.length && g[a][b[0]][b[1]] ? g[a][b[0]][b[1]].apply(g[a], c) : g[a][b[0]].apply(g[a], c));
                    f && f(e)
                },
                t = function(f, e, d, h) {
                    l(f);
                    a.onTrigger("Tracker:Plugin:Load:" + f + ":Ok", function() {
                        s(f, e, d, function(e) {
                            b[f]--;
                            c--;
                            0 === c && a.emit("Tracker:Plugin:Lazyload:Exec:Complete", {
                                lvl: "INFO",
                                msg: "All exec waiting for lazyloading are done"
                            });
                            h && h(e)
                        })
                    }, !0)
                },
                r = function(a) {
                    for (var b = {
                            mcount: 0,
                            plugins: {}
                        }, c = 0; c < a.length; c++) g.hasOwnProperty(a[c]) || (b.mcount++, b.plugins[a[c]] = !0);
                    return b
                };
            this.isExecWaitingLazyloading = function() {
                return 0 !== c
            };
            a.exec = this.exec = function(a, b, c, e) {
                q(a) ? (t(a, b, c, e), n(a)) : f(a) ? t(a, b, c, e) : s(a, b, c, e)
            };
            this.waitForDependencies = function(b, c) {
                var f = r(b);
                if (0 === f.mcount) a.emit("Tracker:Plugin:Dependencies:Loaded", {
                    lvl: "INFO",
                    details: {
                        dependencies: b
                    }
                }), c();
                else
                    for (var e in f.plugins) f.plugins.hasOwnProperty(e) && (a.emit("Tracker:Plugin:Dependencies:Error", {
                        lvl: "WARNING",
                        msg: "Missing plugin " + e
                    }), a.onTrigger("Tracker:Plugin:Load:" + e, function(a, b) {
                        var e = a.split(":"),
                            d = e[3];
                        "Ok" === e[4] && (f.plugins[d] = !1, f.mcount--, 0 === f.mcount && c())
                    }, !0), p(e))
            };
            this.init = function() {
                for (var a in ATInternet.Tracker.pluginProtos) ATInternet.Tracker.pluginProtos.hasOwnProperty(a) && e(a, ATInternet.Tracker.pluginProtos[a])
            }
        },
        CallbacksManager = function(a) {
            var g = this,
                k = {},
                d = function(b) {
                    if (b.name) {
                        var c = !0,
                            d = a.getConfig("callbacks");
                        "undefined" !== typeof d && (d.include instanceof Array &&
                            -1 === ATInternet.Utils.arrayIndexOf(d.include, b.name) && (c = !1), d.exclude instanceof Array && -1 !== ATInternet.Utils.arrayIndexOf(d.exclude, b.name) && (c = !1));
                        ATInternet.Callbacks && ATInternet.Callbacks.hasOwnProperty(b.name) && (d = {}, d[b.name] = {
                            "function": ATInternet.Callbacks[b.name]
                        }, c && g.load(b.name, d[b.name]["function"]), ATInternet.Tracker.callbackProtos[b.name] || (ATInternet.Tracker.callbackProtos[b.name] = d[b.name]))
                    }
                };
            g.load = function(b, c) {
                "function" === typeof c ? (new c(a), a.emit("Tracker:Callback:Load:" +
                    b + ":Ok", {
                        lvl: "INFO",
                        details: {
                            obj: c
                        }
                    })) : a.emit("Tracker:Callback:Load:" + b + ":Error", {
                    lvl: "ERROR",
                    msg: "not a function",
                    details: {
                        obj: c
                    }
                });
                return a
            };
            g.init = function() {
                if (a.getConfig("activateCallbacks")) {
                    var b = a.getConfig("callbacks");
                    if ("undefined" !== typeof b && b.include instanceof Array)
                        for (var c = 0; c < b.include.length; c++) ATInternet.Callbacks && ATInternet.Callbacks.hasOwnProperty(b.include[c]) && (k[b.include[c]] = {
                                "function": ATInternet.Callbacks[b.include[c]]
                            }, ATInternet.Tracker.callbackProtos[b.include[c]] ||
                            (ATInternet.Tracker.callbackProtos[b.include[c]] = k[b.include[c]]));
                    else
                        for (c in ATInternet.Callbacks) ATInternet.Callbacks.hasOwnProperty(c) && (k[c] = {
                            "function": ATInternet.Callbacks[c]
                        }, ATInternet.Tracker.callbackProtos[c] || (ATInternet.Tracker.callbackProtos[c] = k[c]));
                    if ("undefined" !== typeof b && b.exclude instanceof Array)
                        for (c = 0; c < b.exclude.length; c++) delete k[b.exclude[c]];
                    for (var h in k) k.hasOwnProperty(h) && k[h] && g.load(h, k[h]["function"]);
                    ATInternet.Utils.addCallbackEvent(d)
                }
            };
            g.removeCallbackEvent =
                function() {
                    ATInternet.Utils.removeCallbackEvent(d)
                }
        },
        BufferManager = function(a) {
            var g = this,
                k = {};
            g.set = function(a, b, d) {
                b = ATInternet.Utils.privacy.testBufferParam(a, b);
                b.toSetInBuffer && (d = d || {}, d.hitType = d.hitType || ["page"], k[a] = {
                    _value: b.value,
                    _options: d
                })
            };
            var d = function(a, b, d) {
                    return (a = ATInternet.Utils.cloneSimpleObject(a[b])) && !d ? a._value : a
                },
                b = function h(a, b) {
                    if (!(a && b instanceof Array && a instanceof Array)) return [];
                    if (0 === a.length) return b;
                    var f = a[0],
                        d, g = [],
                        p = ATInternet.Utils.cloneSimpleObject(a);
                    p.shift();
                    for (var l = 0; l < b.length; l++)
                        if ("object" !== typeof f[1]) k[b[l]] && k[b[l]]._options[f[0]] === f[1] && g.push(b[l]);
                        else {
                            d = f[1].length;
                            for (var s = 0; s < d; s++)
                                if (k[b[l]] && k[b[l]]._options[f[0]] instanceof Array && 0 <= ATInternet.Utils.arrayIndexOf(k[b[l]]._options[f[0]], f[1][s])) {
                                    g.push(b[l]);
                                    break
                                }
                        }
                    return h(p, g)
                };
            g.get = function(a, g) {
                var e = {};
                if ("string" === typeof a) e = d(k, a, g);
                else
                    for (var f = b(a, ATInternet.Utils.getObjectKeys(k)), q = 0; q < f.length; q++) e[f[q]] = d(k, f[q], g);
                return e
            };
            g.presentInFilters = function(a,
                b) {
                return a && 0 !== a.length ? a[0][0] === b ? !0 : g.presentInFilters(a.slice(1), b) : !1
            };
            g.addInFilters = function(a, b, e, f) {
                if (!a || 0 === a.length) return f ? [] : [
                    [b, e]
                ];
                var d = a[0][0],
                    n = a[0][1];
                d === b && (n instanceof Array && -1 === ATInternet.Utils.arrayIndexOf(n, e[0]) && n.push(e[0]), f = !0);
                return [
                    [d, n]
                ].concat(g.addInFilters(a.slice(1), b, e, f))
            };
            g.del = function(a) {
                k[a] = void 0
            };
            g.clear = function() {
                k = {}
            }
        },
        PropertiesManager = function(a) {
            var g = this,
                k = {};
            g.setProp = function(a, b, c) {
                "undefined" !== typeof a && (k[a] = {
                    value: b,
                    persistent: !!c
                })
            };
            g.setProps = function(a, b) {
                if (ATInternet.Utils.isObject(a))
                    for (var c in a) a.hasOwnProperty(c) && g.setProp(c, a[c], b)
            };
            g.delProp = function(d, b) {
                "undefined" !== typeof k[d] && delete k[d];
                !b && a.delParam(d.toLowerCase())
            };
            g.delProps = function(a) {
                for (var b in k) k.hasOwnProperty(b) && g.delProp(b, a)
            };
            g.getProp = function(a) {
                k = k || {};
                return k[a]
            };
            g.getProps = function() {
                return k
            }
        },
        Tag = function(a, g, k) {
            g = g || {};
            var d = this;
            d.version = "5.28.1";
            var b = ATInternet.Utils.cloneSimpleObject(g);
            d.triggers = new TriggersManager(d);
            d.emit =
                d.triggers.emit;
            d.onTrigger = d.triggers.on;
            var c = ATInternet.Utils.cloneSimpleObject(dfltGlobalCfg) || {},
                h;
            for (h in a) a.hasOwnProperty(h) && (c[h] = a[h]);
            d.getConfig = function(a) {
                return c[a]
            };
            d.setConfig = function(a, b, h) {
                void 0 !== c[a] && h || (d.emit("Tracker:Config:Set:" + a, {
                    lvl: "INFO",
                    details: {
                        bef: c[a],
                        aft: b
                    }
                }), c[a] = b)
            };
            d.configPlugin = function(a, b, h) {
                c[a] = c[a] || {};
                for (var g in b) b.hasOwnProperty(g) && void 0 === c[a][g] && (c[a][g] = b[g]);
                h && (h(c[a]), d.onTrigger("Tracker:Config:Set:" + a, function(a, b) {
                    h(b.details.aft)
                }));
                return c[a]
            };
            d.getAllContext = function() {
                return b
            };
            d.getContext = function(a) {
                return b[a]
            };
            d.setContext = function(a, c) {
                d.emit("Tracker:Context:Set:" + a, {
                    lvl: "INFO",
                    details: {
                        bef: b[a],
                        aft: c
                    }
                });
                b[a] = c
            };
            d.delContext = function(a, c) {
                d.emit("Tracker:Context:Deleted:" + a + ":" + c, {
                    lvl: "INFO",
                    details: {
                        key1: a,
                        key2: c
                    }
                });
                if (a) b.hasOwnProperty(a) && (c ? b[a] && b[a].hasOwnProperty(c) && (b[a][c] = void 0) : b[a] = void 0);
                else if (c)
                    for (var h in b) b.hasOwnProperty(h) && b[h] && b[h].hasOwnProperty(c) && (b[h][c] = void 0)
            };
            d.plugins = new PluginsManager(d);
            d.buffer = new BufferManager(d);
            d.setParam = d.buffer.set;
            d.getParams = function(a) {
                return d.buffer.get(a, !1)
            };
            d.getParam = d.buffer.get;
            d.delParam = d.buffer.del;
            d.builder = new BuildManager(d);
            d.sendUrl = d.builder.sendUrl;
            d.callbacks = new CallbacksManager(d);
            d.properties = new PropertiesManager(d);
            d.setProp = d.properties.setProp;
            d.setProps = d.properties.setProps;
            d.delProp = d.properties.delProp;
            d.delProps = d.properties.delProps;
            d.getProp = d.properties.getProp;
            d.getProps = d.properties.getProps;
            d.sendHit = function(a, b, c,
                h, g) {
                var l = d.getProps(),
                    m, k;
                for (k in l) l.hasOwnProperty(k) && (m = l[k].value, l[k].persistent ? d.setParam(k.toLowerCase(), m, {
                    permanent: !0,
                    hitType: ["all"],
                    encode: !0
                }) : (ATInternet.Utils.isObject(a) ? a[k.toLowerCase()] = {
                    _value: m,
                    _options: {
                        hitType: ["all"],
                        encode: !0
                    }
                } : d.setParam(k.toLowerCase(), m, {
                    hitType: ["all"],
                    encode: !0
                }), d.delProp(k, !0)));
                d.builder.send(a, b, c, h, g)
            };
            ATInternet.Utils.privacy.resetParameters();
            d.setParam("ts", function() {
                return (new Date).getTime()
            }, {
                permanent: !0,
                hitType: ["all"]
            });
            (d.getConfig("disableCookie") ||
                d.getConfig("disableStorage")) && d.setParam("idclient", ATInternet.Utils.privacy.CONSENTNO, {
                permanent: !0,
                hitType: ["all"]
            });
            d.getConfig("medium") && d.setParam("medium", d.getConfig("medium"), {
                permanent: !0,
                hitType: ["all"]
            });
            if (d.getConfig("urlPropertyAuto") && "undefined" !== typeof window && "undefined" !== typeof window.location) {
                h = (d.getConfig("urlPropertyQueryString") ? window.location.href : window.location.protocol + "//" + window.location.host + window.location.pathname).replace(/[<>]/g, "").substring(0, 1600).replace(/&/g,
                    "$").replace(/#/g, "\u00b5");
                var m = d.getContext("page") || {};
                m.url = window.encodeURIComponent(h);
                d.setContext("page", m);
                d.setParam("page_url", h, {
                    permanent: !0,
                    hitType: "page click publisher selfPromotion onSiteAdsClick onSiteAdsImpression InternalSearch mvtesting richmedia".split(" ")
                })
            }
            d.plugins.init();
            d.callbacks.init();
            d.emit("Tracker:Ready", {
                lvl: "INFO",
                msg: "Tracker initialized",
                details: {
                    tracker: d,
                    args: {
                        config: a,
                        context: g,
                        callback: k
                    }
                }
            });
            k && k(d);
            ATInternet.Tracker.instances.push(d)
        };
    ATInternet.Tracker.Tag = Tag;
    ATInternet.Tracker.instances = [];
    ATInternet.Tracker.pluginProtos = {};
    ATInternet.Tracker.addPlugin = function(a, g) {
        g = g || ATInternet.Tracker.Plugins[a];
        if (!ATInternet.Tracker.pluginProtos[a]) {
            ATInternet.Tracker.pluginProtos[a] = g;
            for (var k = 0; k < ATInternet.Tracker.instances.length; k++) ATInternet.Tracker.instances[k].plugins.load(a, g)
        }
    };
    ATInternet.Tracker.delPlugin = function(a) {
        if (ATInternet.Tracker.pluginProtos[a]) {
            ATInternet.Tracker.pluginProtos[a] = void 0;
            for (var g = 0; g < ATInternet.Tracker.instances.length; g++) ATInternet.Tracker.instances[g].plugins.unload(a)
        }
    };
    ATInternet.Tracker.callbackProtos = {};
}).call(window);
(function() {
    var dfltPluginCfg = {
        "lifetime": 30,
        "lastPersistence": true,
        "domainAttribution": true,
        "enableUTMTracking": true,
        "UTMParameters": ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content"],
        "querystringPrefix": "at_"
    };
    var dfltGlobalCfg = {
        "visitLifetime": 30,
        "redirectionLifetime": 30
    };
    ATInternet.Tracker.Plugins.Campaigns = function(a) {
        a.setConfig("visitLifetime", dfltGlobalCfg.visitLifetime, !0);
        a.setConfig("redirectionLifetime", dfltGlobalCfg.redirectionLifetime, !0);
        var g = {},
            k, d;
        a.configPlugin("Campaigns", dfltPluginCfg || {}, function(a) {
            g = a
        });
        var b, c, h, m, e, f, q, n, p, l, s, t, r, u = function() {
                var b = function(a) {
                        var b = "";
                        a && (b = isNaN(a) && -1 === a.search(/^\[(.*?)\]$/g) && -1 === a.search(/^\d+\[(.*?)\]$/g) ? "[" + a + "]" : a);
                        return b
                    },
                    c = function(a) {
                        var b = a; - 1 !== a.search(/[-]/g) && -1 === a.search(/^\[(.*?)\]$/g) &&
                            (b = "[" + a + "]");
                        return b
                    },
                    f = function(a) {
                        for (;
                            "-" === a.charAt(a.length - 1);) a = a.substring(0, a.length - 1);
                        return a
                    };
                this.SponsoredLinks = function() {
                    var e = {
                            google: "goo",
                            yahoo: "ysm",
                            miva: "miv",
                            orange: "wan",
                            msn: "msn",
                            mirago: "mir",
                            sklik: "skl",
                            adfox: "adf",
                            etarget: "etg",
                            yandex: "yan",
                            ebay: "eba",
                            searchalliance: "sal",
                            bing: "bin",
                            naver: "nav",
                            baidu: "bdu",
                            qwant: "qwt",
                            waze: "waz",
                            amazon: "amz"
                        },
                        d = {
                            search: "s",
                            content: "c"
                        };
                    this.atMedium = "sl";
                    this.atTerm = this.atNetwork = this.atVariant = this.atCreation = this.atPlatform = this.atCampaign =
                        "";
                    this.format = function() {
                        var a = "sec",
                            h = b(this.atCampaign),
                            l = e[this.atPlatform] || c(this.atPlatform),
                            g = b(this.atCreation),
                            m = b(this.atVariant),
                            r = d[this.atNetwork] || c(this.atNetwork),
                            n = b(this.atTerm);
                        return f(a + ("-" + h + "-" + l + "-" + g + "-" + m + "-" + r + "-" + n))
                    };
                    this.setProperties = function(b) {
                        this.atCampaign = a.utils.getQueryStringValue(g.querystringPrefix + "campaign", b) || "";
                        this.atPlatform = a.utils.getQueryStringValue(g.querystringPrefix + "platform", b) || "";
                        this.atCreation = a.utils.getQueryStringValue(g.querystringPrefix +
                            "creation", b) || "";
                        this.atVariant = a.utils.getQueryStringValue(g.querystringPrefix + "variant", b) || "";
                        this.atNetwork = a.utils.getQueryStringValue(g.querystringPrefix + "network", b) || "";
                        this.atTerm = a.utils.getQueryStringValue(g.querystringPrefix + "term", b) || "";
                        a.setContext("campaigns_events", {
                            $: this.atMedium,
                            campaign: this.atCampaign,
                            platform: this.atPlatform,
                            creation: this.atCreation,
                            variant: this.atVariant,
                            network: this.atNetwork,
                            term: this.atTerm
                        })
                    }
                };
                this.Email = function() {
                    var e = {
                        acquisition: "erec",
                        retention: "epr",
                        promotion: "es"
                    };
                    this.atMedium = "email";
                    this.atSendTime = this.atRecipientList = this.atRecipientId = this.atLink = this.atSendDate = this.atCreation = this.atCampaign = this.atEmailtype = "";
                    this.format = function() {
                        var a = e[this.atEmailtype] || e.promotion,
                            d = b(this.atCampaign),
                            h = b(this.atCreation),
                            l = c(this.atSendDate),
                            g = b(this.atLink),
                            m = c(this.atRecipientId) + (this.atRecipientList ? "@" + c(this.atRecipientList) : ""),
                            r = c(this.atSendTime);
                        return f(a + ("-" + d + "-" + h + "-" + l + "-" + g + "-" + m + "-" + r))
                    };
                    this.setProperties = function(b) {
                        this.atEmailtype =
                            a.utils.getQueryStringValue(g.querystringPrefix + "emailtype", b) || "";
                        this.atCampaign = a.utils.getQueryStringValue(g.querystringPrefix + "campaign", b) || "";
                        this.atCreation = a.utils.getQueryStringValue(g.querystringPrefix + "creation", b) || "";
                        this.atSendDate = a.utils.getQueryStringValue(g.querystringPrefix + "send_date", b) || "";
                        this.atLink = a.utils.getQueryStringValue(g.querystringPrefix + "link", b) || "";
                        this.atRecipientId = a.utils.getQueryStringValue(g.querystringPrefix + "recipient_id", b) || "";
                        this.atRecipientList = a.utils.getQueryStringValue(g.querystringPrefix +
                            "recipient_list", b) || "";
                        this.atSendTime = a.utils.getQueryStringValue(g.querystringPrefix + "send_time", b) || "";
                        a.setContext("campaigns_events", {
                            $: this.atMedium,
                            emailtype: this.atEmailtype,
                            campaign: this.atCampaign,
                            creation: this.atCreation,
                            send_date: this.atSendDate,
                            link: this.atLink,
                            recipient_id: this.atRecipientId,
                            recipient_list: this.atRecipientList,
                            send_time: this.atSendTime
                        })
                    }
                };
                this.Affiliate = function() {
                    this.atMedium = "affiliate";
                    this.atVariant = this.atCreation = this.atFormat = this.atIdentifier = this.atType =
                        this.atCampaign = "";
                    this.format = function() {
                        var a = "al",
                            c = b(this.atCampaign),
                            e = b(this.atType),
                            d = b(this.atIdentifier),
                            h = b(this.atFormat),
                            l = b(this.atCreation),
                            g = b(this.atVariant);
                        return f(a + ("-" + c + "-" + e + "-" + d + "-" + h + "-" + l + "-" + g))
                    };
                    this.setProperties = function(b) {
                        this.atCampaign = a.utils.getQueryStringValue(g.querystringPrefix + "campaign", b) || "";
                        this.atType = a.utils.getQueryStringValue(g.querystringPrefix + "type", b) || "";
                        this.atIdentifier = a.utils.getQueryStringValue(g.querystringPrefix + "identifier", b) || "";
                        this.atFormat =
                            a.utils.getQueryStringValue(g.querystringPrefix + "format", b) || "";
                        this.atCreation = a.utils.getQueryStringValue(g.querystringPrefix + "creation", b) || "";
                        this.atVariant = a.utils.getQueryStringValue(g.querystringPrefix + "variant", b) || "";
                        a.setContext("campaigns_events", {
                            $: this.atMedium,
                            campaign: this.atCampaign,
                            type: this.atType,
                            identifier: this.atIdentifier,
                            format: this.atFormat,
                            creation: this.atCreation,
                            variant: this.atVariant
                        })
                    }
                };
                this.Display = function() {
                    this.atMedium = "display";
                    this.atDetailPlacement = this.atGeneralPlacement =
                        this.atChannel = this.atFormat = this.atVariant = this.atCreation = this.atCampaign = "";
                    this.format = function() {
                        var a = "ad",
                            c = b(this.atCampaign),
                            e = b(this.atCreation),
                            d = b(this.atVariant),
                            h = b(this.atFormat),
                            l = b(this.atChannel),
                            g = b(this.atGeneralPlacement),
                            m = b(this.atDetailPlacement);
                        return f(a + ("-" + c + "-" + e + "-" + d + "-" + h + "-" + l + "-" + g + "-" + m))
                    };
                    this.setProperties = function(b) {
                        this.atCampaign = a.utils.getQueryStringValue(g.querystringPrefix + "campaign", b) || "";
                        this.atCreation = a.utils.getQueryStringValue(g.querystringPrefix +
                            "creation", b) || "";
                        this.atVariant = a.utils.getQueryStringValue(g.querystringPrefix + "variant", b) || "";
                        this.atFormat = a.utils.getQueryStringValue(g.querystringPrefix + "format", b) || "";
                        this.atChannel = a.utils.getQueryStringValue(g.querystringPrefix + "channel", b) || "";
                        this.atGeneralPlacement = a.utils.getQueryStringValue(g.querystringPrefix + "general_placement", b) || "";
                        this.atDetailPlacement = a.utils.getQueryStringValue(g.querystringPrefix + "detail_placement", b) || "";
                        a.setContext("campaigns_events", {
                            $: this.atMedium,
                            campaign: this.atCampaign,
                            creation: this.atCreation,
                            variant: this.atVariant,
                            format: this.atFormat,
                            channel: this.atChannel,
                            general_placement: this.atGeneralPlacement,
                            detail_placement: this.atDetailPlacement
                        })
                    }
                };
                this.Custom = function() {
                    this.atCustom4 = this.atCustom3 = this.atCustom2 = this.atCustom1 = this.atCampaign = this.atMedium = "";
                    this.format = function() {
                        var a = "";
                        /\d+$/.test(this.atMedium) && (a = /\d+$/.exec(this.atMedium)[0]);
                        var a = "cs" + a,
                            c = b(this.atCampaign),
                            e = b(this.atCustom1),
                            d = b(this.atCustom2),
                            h = b(this.atCustom3),
                            l = b(this.atCustom4);
                        return f(a + ("-" + c + "-" + e + "-" + d + "-" + h + "-" + l))
                    };
                    this.setProperties = function(b) {
                        this.atMedium = a.utils.getQueryStringValue(g.querystringPrefix + "medium", b) || "";
                        this.atCampaign = a.utils.getQueryStringValue(g.querystringPrefix + "campaign", b) || "";
                        this.atCustom1 = a.utils.getQueryStringValue(g.querystringPrefix + "custom1", b) || "";
                        this.atCustom2 = a.utils.getQueryStringValue(g.querystringPrefix + "custom2", b) || "";
                        this.atCustom3 = a.utils.getQueryStringValue(g.querystringPrefix + "custom3", b) || "";
                        this.atCustom4 =
                            a.utils.getQueryStringValue(g.querystringPrefix + "custom4", b) || "";
                        a.setContext("campaigns_events", {
                            $: this.atMedium,
                            campaign: this.atCampaign,
                            custom1: this.atCustom1,
                            custom2: this.atCustom2,
                            custom3: this.atCustom3,
                            custom4: this.atCustom4
                        })
                    }
                };
                this.medium = {
                    sl: this.SponsoredLinks,
                    email: this.Email,
                    affiliate: this.Affiliate,
                    display: this.Display
                }
            },
            v = function(b, c) {
                var f = a.getContext("campaigns") || {};
                f[b] = c;
                a.setContext("campaigns", f)
            },
            z = function() {
                var b = a.utils.getLocation(),
                    c = function() {
                        for (var c = g.UTMParameters,
                                f, e = 0; e < c.length; e++)(f = a.utils.getQueryStringValue(c[e], b)) && v(c[e], f)
                    };
                (function() {
                    var c = a.utils.getQueryStringValue(g.querystringPrefix + "medium", b);
                    if (c) {
                        var f = new u,
                            c = "function" === typeof f.medium[c] ? new f.medium[c] : new f.Custom;
                        c.setProperties(b);
                        q = c.format()
                    } else q = a.utils.getQueryStringValue("xtor", b);
                    n = a.utils.getQueryStringValue("xtdt", b);
                    p = a.utils.getQueryStringValue("xts", b)
                })();
                g.enableUTMTracking && c()
            },
            w = function(b, c) {
                var f = a.storage[d](b);
                if (null !== f) return "object" === typeof f && !(f instanceof Array);
                a.storage[k](b, {}, c);
                return !0
            };
        (function() {
            a.plugins.waitForDependencies(["Storage", "Utils"], function() {
                k = "set" + (g.domainAttribution ? "" : "Private");
                d = "get" + (g.domainAttribution ? "" : "Private");
                b = a.storage[d](["atredir", "gopc"]);
                c = a.storage[d](["atredir", "gopc_err"]);
                h = a.storage[d](["atredir", "camp"]);
                a.storage.del(["atredir", "gopc"]);
                a.storage.del(["atredir", "gopc_err"]);
                a.storage.del(["atredir", "camp"]);
                m = a.storage[d](["atsession", "histo_camp"]);
                e = a.storage[d](["atreman", "camp"]);
                f = a.storage[d](["atreman",
                    "date"
                ]);
                z();
                l = a.getContext("forcedCampaign");
                s = !!a.getConfig("redirect");
                t = !!(q && n && p);
                r = !1;
                if (t) {
                    var u = (new Date).getTime() / 6E4;
                    r = !s && p !== a.getConfig("site") || 0 > u - n || u - n >= a.getConfig("visitLifetime")
                }
                u = l || h || q;
                if (s && u && w("atredir", {
                        path: "/",
                        end: a.getConfig("redirectionLifetime")
                    })) {
                    a.storage[k](["atredir", "camp"], u);
                    var A = u = !1;
                    l || (h ? (u = b, A = c) : (u = t, A = r));
                    a.storage[k](["atredir", "gopc"], u);
                    a.storage[k](["atredir", "gopc_err"], A)
                }!s && e && (v("xtor", e), u = (new Date).getTime() / 36E5, u = Math.floor(u - f), v("roinbh",
                    0 <= u ? u : 0));
                s || (u = null, u = h ? b ? l || u : l || h : t ? l : l || q || u, m && m instanceof Array && -1 < m.indexOf(u) && (u = null), u && v("xto", u));
                if (!s && !l) {
                    var y;
                    h ? c && (y = h) : r && (y = q);
                    y && v("pgt", y)
                }
                if (!s && (y = h ? l || h : l || q || null) && !(!l && !h && t && r || !l && h && b && c)) {
                    if ((!m || m instanceof Array && 0 > m.indexOf(y)) && w("atsession", {
                            path: "/",
                            session: 60 * a.getConfig("visitLifetime")
                        })) a.storage[k](["atsession", "histo_camp"], m && m.push(y) ? m : [y]);
                    e && !g.lastPersistence || !w("atreman", {
                        path: "/",
                        session: 86400 * g.lifetime
                    }) || (a.storage[k](["atreman", "camp"],
                        y), a.storage[k](["atreman", "date"], (new Date).getTime() / 36E5))
                }
                a.emit("Campaigns:process:done", {
                    lvl: "INFO"
                })
            })
        })()
    };
    ATInternet.Tracker.addPlugin("Campaigns");
}).call(window);
(function() {
    var dfltPluginCfg = {};
    var dfltGlobalCfg = {
        "storageMode": "cookie"
    };
    ATInternet.Tracker.Plugins.Storage = function(a) {
        var g = this,
            k = {},
            d = !1,
            b = null;
        a.configPlugin("Storage", dfltPluginCfg || {}, function(a) {
            k = a;
            "localStorage" === k.storageMode && (d = ATInternet.Utils.isLocalStorageAvailable())
        });
        var c = {},
            h = function(b) {
                return a.getConfig("base64Storage") ? ATInternet.Utils.Base64.encode(b) : encodeURIComponent(b)
            },
            m = function(b) {
                return a.getConfig("base64Storage") ? ATInternet.Utils.Base64.decode(b) : decodeURIComponent(b)
            },
            e = function() {
                this.getData = function(a) {
                    var b = null;
                    (a = RegExp("(?:^| )" +
                        a + "=([^;]+)").exec(document.cookie) || null) && (b = m(a[1]));
                    return b
                };
                this.setData = function(b) {
                    var c = !1;
                    if (b.name && "string" === typeof b.name) {
                        var d = b.options || {},
                            e = d.end || {},
                            f = d.domain || a.getConfig("cookieDomain"),
                            g = d.secure || a.getConfig("cookieSecure"),
                            k = ATInternet.Utils.jsonSerialize(b),
                            k = b.name + "=" + h(k),
                            k = k + (d.path && "string" === typeof d.path ? ";path=" + d.path : ""),
                            k = k + (f && "string" === typeof f ? ";domain=" + f : "") + (g && "boolean" === typeof g ? ";secure" : "");
                        "function" === typeof e.toUTCString ? k += ";expires=" + e.toUTCString() :
                            "number" === typeof e && (k += ";max-age=" + e.toString());
                        document.cookie = k;
                        this.getData(b.name) && (c = !0)
                    }
                    return c
                }
            };
        b = d ? new function() {
                var a = function(a) {
                        var b = +new Date,
                            c = !1,
                            d;
                        a.options && ("undefined" !== typeof a.options.expires ? d = a.options.expires : (a = a.options.end || {}, "function" === typeof a.getTime ? d = a.getTime() : "number" === typeof a && (d = b + 1E3 * a)));
                        "number" === typeof d && b >= d && (c = !0);
                        return {
                            itemToDelete: c,
                            timestamp: d
                        }
                    },
                    b = function(a) {
                        var b = !1;
                        try {
                            localStorage.removeItem(a), b = !0
                        } catch (c) {}
                        return b
                    };
                this.getData =
                    function(c) {
                        var d = null,
                            e = localStorage.getItem(c);
                        if (e) {
                            var e = m(e),
                                f = ATInternet.Utils.jsonParse(e);
                            f && "object" === typeof f ? a(f).itemToDelete && b(c) || (delete f.options.expires, d = ATInternet.Utils.jsonSerialize(f)) : d = e
                        }
                        return d
                    };
                this.setData = function(c) {
                    var d = !1;
                    if (c.name && "string" === typeof c.name) {
                        var e = a(c);
                        "number" === typeof e.timestamp && (c.options.expires = e.timestamp);
                        var f = ATInternet.Utils.jsonSerialize(c);
                        if (e.itemToDelete) d = b(c.name);
                        else try {
                            localStorage.setItem(c.name, h(f)), d = !0
                        } catch (g) {}
                    }
                    return d
                }
            } :
            new e;
        var f = function(c, d) {
                var e = !1;
                c && "object" === typeof c && (d || ATInternet.Utils.consent && !a.getConfig("disableCookie") && !a.getConfig("disableStorage")) && (e = b.setData(c));
                return e
            },
            q = function(a, b, c) {
                a = {
                    name: a,
                    val: b
                };
                c && c.session && "number" === typeof c.session && (c.end = c.session);
                a.options = c || {};
                return a
            },
            n = function(c) {
                var d = null,
                    e = null;
                a.getConfig("disableCookie") || a.getConfig("disableStorage") || !c || "string" !== typeof c || (e = b.getData(c));
                (c = e) && (d = ATInternet.Utils.jsonParse(c));
                return d
            },
            p = function(a,
                b) {
                var c = ATInternet.Utils.cloneSimpleObject(a);
                return f(c, b) ? ATInternet.Utils.jsonParse(ATInternet.Utils.jsonSerialize(a)) : null
            },
            l = function(a, b, d) {
                if (!d && c[a]) d = c[a];
                else if (d = n(a)) d.options = d.options || {}, d.options.session && "number" === typeof d.options.session && (d.options.end = d.options.session, p(d, !1)), c[a] = d;
                return d ? b ? (a = null, !d || "object" !== typeof d.val || d.val instanceof Array || void 0 === d.val[b] || (a = d.val[b]), a) : d.val : null
            },
            s = function(a, b, d, e, f) {
                if (b) {
                    if (f = n(a)) !f || "object" !== typeof f.val || f.val instanceof
                    Array ? f = null : "undefined" === typeof d ? delete f.val[b] : f.val[b] = d, f && (f = p(f, e))
                } else f = f || {}, f = q(a, d, f), f = p(f, e);
                return f ? (c[a] = f, f.val) : null
            },
            t = function(a, b) {
                if (b) s(a, b, void 0, !0, null);
                else {
                    c[a] = void 0;
                    var d = q(a, "", {
                        end: new Date("Thu, 01 Jan 1970 00:00:00 UTC"),
                        path: "/"
                    });
                    f(d, !0)
                }
            };
        a.storage = {};
        a.storage.getAll = function() {
            return c
        };
        a.storage.get = g.get = function(a, b) {
            b = !!b;
            return a instanceof Array ? l(a[0], a[1], b) : l(a, "", b)
        };
        a.storage.getPrivate = g.getPrivate = function(b, c) {
            b instanceof Array ? b[0] += a.getConfig("site") :
                b += a.getConfig("site");
            return g.get(b, c)
        };
        a.storage.set = g.set = function(a, b, c, d) {
            var e;
            a instanceof Array ? (e = a[0], a = a[1], c = null) : (e = a, a = null);
            return ATInternet.Utils.privacy.testStorageParam(e, a).toSetInStorage || d ? s(e, a, b, d, c) : null
        };
        a.storage.setPrivate = g.setPrivate = function(b, c, d) {
            b instanceof Array ? b[0] += a.getConfig("site") : b += a.getConfig("site");
            return g.set(b, c, d)
        };
        a.storage.del = g.del = function(a) {
            a instanceof Array ? t(a[0], a[1]) : t(a, "")
        };
        a.storage.delPrivate = g.delPrivate = function(b) {
            b instanceof
            Array ? b[0] += a.getConfig("site") : b += a.getConfig("site");
            g.del(b)
        };
        a.storage.cacheInvalidation = g.cacheInvalidation = function() {
            c = {}
        }
    };
    ATInternet.Tracker.addPlugin("Storage");
}).call(window);
(function() {
    var dfltPluginCfg = {};
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.Utils = function(a) {
        var g = this,
            k = {};
        a.utils = {};
        a.utils.getQueryStringValue = g.getQueryStringValue = function(a, c) {
            var d = ATInternet.Utils.hashcode(c).toString();
            if (!k[d]) {
                k[d] = {};
                for (var g = RegExp("[&#?]{1}([^&=#?]*)=([^&#]*)?", "g"), e = g.exec(c); null !== e;) k[d][e[1]] = e[2], e = g.exec(c)
            }
            return k[d].hasOwnProperty(a) ? k[d][a] : null
        };
        a.utils.manageChapters = g.manageChapters = function(b, c, d) {
            var g = "";
            if (b)
                for (var e = a.getConfig("ignoreEmptyChapterValue"), f = "", k = 1; k < parseInt(d, 10) + 1; k++) f = b[c +
                    k] || "", g = e ? g + (f ? f + "::" : "") : g + (b.hasOwnProperty(c + k) ? f + "::" : "");
            return g
        };
        a.utils.getDocumentLevel = g.getDocumentLevel = function() {
            var b = a.getConfig("documentLevel");
            if (b) {
                if (0 > b.indexOf(".")) return window[b] || document;
                b = b.split(".");
                return window[b[0]][b[1]] || document
            }
            return document
        };
        a.utils.getLocation = g.getLocation = function() {
            return g.getDocumentLevel().location.href
        };
        a.utils.getHostName = g.getHostName = function() {
            return g.getDocumentLevel().location.hostname
        };
        a.dispatchIndex = {};
        a.dispatchStack = [];
        a.dispatchEventFor = {};
        var d = 0;
        a.dispatchSubscribe = function(b) {
            return a.dispatchIndex[b] ? !1 : (a.dispatchStack.push(b), a.dispatchIndex[b] = !0)
        };
        a.dispatchSubscribed = function(b) {
            return !0 === a.dispatchIndex[b]
        };
        a.addSpecificDispatchEventFor = function(b) {
            return a.dispatchEventFor[b] ? !1 : (a.dispatchEventFor[b] = !0, d++, !0)
        };
        a.processSpecificDispatchEventFor = function(b) {
            a.dispatchEventFor[b] && (a.dispatchEventFor[b] = !1, d--, 0 === d && (a.dispatchEventFor = {}, a.emit("Tracker:Plugin:SpecificEvent:Exec:Complete", {
                lvl: "INFO"
            })))
        };
        a.dispatch = function(b, c) {
            var g = function() {
                    for (var d = "", f = null; 0 < a.dispatchStack.length;) d = a.dispatchStack.pop(), 0 === a.dispatchStack.length && (f = b), a[d].onDispatch(f, c);
                    a.dispatchIndex = {};
                    a.delContext(void 0, "customObject")
                },
                k = function() {
                    if (a.plugins.isExecWaitingLazyloading()) a.onTrigger("Tracker:Plugin:Lazyload:Exec:Complete", function() {
                        g()
                    }, !0);
                    else g()
                };
            if (0 === d) k();
            else a.onTrigger("Tracker:Plugin:SpecificEvent:Exec:Complete", function() {
                k()
            }, !0)
        };
        a.dispatchRedirect = function(b) {
            var c = !0,
                d = "",
                g =
                null;
            b && (g = null, b.hasOwnProperty("event") && (g = b.event || window.event), !ATInternet.Utils.isTabOpeningAction(g) && b.elem && a.plugins.exec("TechClicks", "manageClick", [b.elem, g], function(a) {
                c = a.preservePropagation;
                d = a.elementType
            }), g = b.callback);
            a.dispatch(g, d);
            return c
        };
        a.manageSend = function(b) {
            if (!ATInternet.Utils.isPreview() || a.getConfig("preview")) ATInternet.Utils.isPrerender(function(a) {
                b(a)
            }) || b()
        };
        a.processTagObject = function(b, c, d) {
            if ((b = a.getParam(b, !0)) && b._options.permanent) {
                for (var g = !1, e = b._options.hitType || [], f = 0; f < e.length; f++)
                    if (-1 !== ATInternet.Utils.arrayIndexOf(c.concat("all"), e[f])) {
                        g = !0;
                        break
                    }
                g && (d = ATInternet.Utils.completeFstLevelObj(b._value || {}, d, !0))
            }
            return d
        };
        a.processContextObjectAndSendHit = function(b, c, d, g) {
            var e = {
                    hitType: c.hitType,
                    encode: c.encode,
                    separator: c.separator,
                    truncate: c.truncate
                },
                f = a.getParam(b, !0);
            if (f) {
                for (var k = !1, n = f._options.hitType || [], p = 0; p < n.length; p++)
                    if (-1 !== ATInternet.Utils.arrayIndexOf(c.hitType.concat("all"), n[p])) {
                        k = !0;
                        break
                    }
                k ? (k = ATInternet.Utils.cloneSimpleObject(f),
                    k._value = ATInternet.Utils.completeFstLevelObj(k._value || {}, d, !0), a.setParam(b, k._value, e), a.manageSend(function() {
                        a.sendHit(null, [
                            ["hitType", c.hitType]
                        ], g, c.requestMethod, c.elementType)
                    }), f._options.permanent && a.setParam(b, f._value, f._options)) : (a.setParam(b, d, e), a.manageSend(function() {
                    a.sendHit(null, [
                        ["hitType", c.hitType]
                    ], g, c.requestMethod, c.elementType)
                }), a.setParam(b, f._value, f._options))
            } else a.setParam(b, d, e), a.manageSend(function() {
                a.sendHit(null, [
                        ["hitType", c.hitType]
                    ], g, c.requestMethod,
                    c.elementType)
            })
        }
    };
    ATInternet.Tracker.addPlugin("Utils");
}).call(window);
(function() {
    var dfltPluginCfg = {
        "clicksAutoManagementEnabled": true,
        "clicksAutoManagementTimeout": 500
    };
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.TechClicks = function(a) {
        var g = this,
            k = ["Tracker:Hit:Sent:Ok", "Tracker:Hit:Sent:Error", "Tracker:Hit:Sent:NoTrack"],
            d, b, c = !1;
        a.configPlugin("TechClicks", dfltPluginCfg || {}, function(a) {
            d = a.clicksAutoManagementEnabled;
            b = a.clicksAutoManagementTimeout
        });
        var h = function(a) {
                if (!c) switch (c = !0, a.target) {
                    case "_top":
                        window.top.location.href = a.url;
                        break;
                    case "_parent":
                        window.parent.location.href = a.url;
                        break;
                    default:
                        window.location.href = a.url
                }
            },
            m = function(a) {
                a.mailto ? g.timeout = setTimeout(function() {
                    window.location.href =
                        a.mailto
                }, a.timeout) : a.form ? g.timeout = setTimeout(function() {
                    a.form.submit()
                }, a.timeout) : a.url && (g.timeout = setTimeout(function() {
                    h({
                        url: a.url,
                        target: a.target
                    })
                }, a.timeout))
            },
            e = function(b) {
                for (var c = 0; c < k.length; c++) a.onTrigger(k[c], function(a, c) {
                    b && b(c)
                })
            },
            f = function(a) {
                for (var c, d = "_self"; a;) {
                    if (a.href && 0 === a.href.indexOf("http")) {
                        c = a.href.split('"').join('\\"');
                        d = a.target ? a.target : d;
                        break
                    }
                    a = a.parentNode
                }
                c && (e(function(a) {
                    a.details.isMultiHit || a.details.elementType !== ATInternet.Utils.CLICKS_REDIRECTION ||
                        (g.timeout && clearTimeout(g.timeout), h({
                            url: c,
                            target: d
                        }))
                }), m({
                    url: c,
                    target: d,
                    timeout: b
                }))
            },
            q = function(a) {
                for (var c = a; c && "FORM" !== c.nodeName;) c = c.parentNode;
                c && (e(function(a) {
                    a.details.isMultiHit || a.details.elementType !== ATInternet.Utils.CLICKS_FORM || (g.timeout && clearTimeout(g.timeout), c.submit())
                }), m({
                    form: c,
                    timeout: b
                }))
            },
            n = function(a) {
                for (var c = a; c && !(c.href && 0 <= c.href.indexOf("mailto:"));) c = c.parentNode;
                c && (e(function(a) {
                    a.details.isMultiHit || a.details.elementType !== ATInternet.Utils.CLICKS_MAILTO ||
                        (g.timeout && clearTimeout(g.timeout), window.location.href = c.href)
                }), m({
                    mailto: c.href,
                    timeout: b
                }))
            },
            p = function(a) {
                for (var b = a; b;) {
                    if (b.href) {
                        if (0 <= b.href.indexOf("mailto:")) return ATInternet.Utils.CLICKS_MAILTO;
                        if (0 === b.href.indexOf("http")) return ATInternet.Utils.CLICKS_REDIRECTION
                    } else if ("FORM" === b.nodeName) {
                        var c = a;
                        a = !1;
                        c && (b = c.tagName || "", b = b.toLowerCase(), "form" === b ? a = !0 : (c = c.getAttribute("type") || "", c = c.toLowerCase(), "button" === b ? "reset" !== c && "button" !== c && (a = !0) : "input" === b && "submit" === c && (a = !0)));
                        if (a) return ATInternet.Utils.CLICKS_FORM;
                        break
                    }
                    b = b.parentNode
                }
                return ""
            };
        g.isFormSubmit = function(a) {
            for (; a;) {
                if ("FORM" === a.nodeName) return !0;
                a = a.parentNode
            }
            return !1
        };
        a.techClicks = {};
        a.techClicks.manageClick = g.manageClick = function(a, b) {
            var c = !0,
                e = "";
            if (d && a) {
                var g;
                a: {
                    for (e = a; e;) {
                        if ("function" === typeof e.getAttribute && ("_blank" === e.getAttribute("target") || "no" === e.getAttribute("data-atclickmanagement"))) {
                            g = !0;
                            break a
                        }
                        e = e.parentNode
                    }
                    e = a;g = window.location.href;
                    for (var h; e;) {
                        if ((h = e.href) && 0 <= h.indexOf("#") &&
                            g.substring(0, 0 <= g.indexOf("#") ? g.indexOf("#") : g.length) === h.substring(0, h.indexOf("#"))) {
                            g = !0;
                            break a
                        }
                        e = e.parentNode
                    }
                    g = !1
                }
                e = p(a);
                if (!g && e) {
                    switch (e) {
                        case ATInternet.Utils.CLICKS_MAILTO:
                            n(a);
                            c = !1;
                            break;
                        case ATInternet.Utils.CLICKS_FORM:
                            q(a);
                            c = !1;
                            break;
                        case ATInternet.Utils.CLICKS_REDIRECTION:
                            f(a), c = !1
                    }
                    b && (g = b.defaultPrevented, "function" === typeof b.isDefaultPrevented && (g = b.isDefaultPrevented()), g || b.preventDefault && b.preventDefault())
                }
            }
            return {
                preservePropagation: c,
                elementType: e
            }
        };
        a.techClicks.deactivateAutoManagement =
            function() {
                d = !1
            }
    };
    ATInternet.Tracker.addPlugin("TechClicks");
}).call(window);
(function() {
    var dfltPluginCfg = {
        "requestMethod": "POST"
    };
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.Clicks = function(a) {
        var g = {};
        a.configPlugin("Clicks", dfltPluginCfg || {}, function(a) {
            g = a
        });
        var k = function(a) {
                var b = "";
                switch (a) {
                    case "exit":
                        b = "S";
                        break;
                    case "download":
                        b = "T";
                        break;
                    case "action":
                        b = "A";
                        break;
                    case "navigation":
                        b = "N"
                }
                return b
            },
            d = function(b) {
                return a.utils.manageChapters(b, "chapter", 3) + (b.name ? b.name : "")
            },
            b = function(b, h) {
                var m = {
                        p: d(b),
                        s2: b.level2 || "",
                        click: k(b.type) || ""
                    },
                    e = ["click"],
                    f = a.getContext("page") || {};
                m.pclick = d(f);
                m.s2click = f.level2 || "";
                if (f = b.customObject) f =
                    a.processTagObject("stc", e, f), m.stc = {
                        _value: ATInternet.Utils.jsonSerialize(f),
                        _options: {
                            hitType: e,
                            encode: !0,
                            separator: ",",
                            truncate: !0
                        }
                    };
                a.sendHit(m, [
                    ["hitType", e]
                ], b.callback, g.requestMethod, h)
            };
        a.click = {};
        a.clickListener = {};
        a.click.send = function(c) {
            c = c || {};
            var d = !0,
                m = "",
                e = null;
            c.hasOwnProperty("event") && (e = c.event || window.event);
            !c.elem || "POST" === g.requestMethod && ATInternet.Utils.isBeaconMethodAvailable() || ATInternet.Utils.isTabOpeningAction(e) || (m = a.techClicks.manageClick(c.elem, e), d = m.preservePropagation,
                m = m.elementType);
            b(c, m);
            return d
        };
        a.clickListener.send = function(c) {
            c = c || {};
            if (c.elem) {
                var d = "click",
                    m = "";
                a.plugins.exec("TechClicks", "isFormSubmit", [c.elem], function(a) {
                    d = a ? "submit" : "click"
                });
                ATInternet.Utils.addEvtListener(c.elem, d, function(e) {
                    "POST" === g.requestMethod && ATInternet.Utils.isBeaconMethodAvailable() || ATInternet.Utils.isTabOpeningAction(e) || (m = a.techClicks.manageClick(c.elem, e).elementType);
                    b(c, m)
                })
            }
        };
        a.click.set = function(b) {
            b = b || {};
            a.dispatchSubscribe("click");
            a.setContext("click", {
                name: d(b),
                level2: b.level2 || "",
                customObject: b.customObject
            });
            a.setParam("click", k(b.type) || "", {
                hitType: ["click"]
            })
        };
        a.click.onDispatch = function(b, h) {
            var m = ["click"],
                e = a.getContext("click") || {},
                f = a.getContext("page") || {};
            a.setParam("pclick", d(f), {
                hitType: m
            });
            a.setParam("s2click", f.level2 || "", {
                hitType: m
            });
            a.setParam("p", e.name, {
                hitType: m
            });
            a.setParam("s2", e.level2, {
                hitType: m
            });
            (e = e.customObject) ? a.processContextObjectAndSendHit("stc", {
                hitType: m,
                encode: !0,
                separator: ",",
                truncate: !0,
                requestMethod: g.requestMethod,
                elementType: h
            }, e, b): a.manageSend(function() {
                a.sendHit(null, [
                    ["hitType", m]
                ], b, g.requestMethod, h)
            });
            a.delContext("click")
        }
    };
    ATInternet.Tracker.addPlugin("Clicks");
}).call(window);
(function() {
    var dfltPluginCfg = {
        "domainAttribution": true
    };
    var dfltGlobalCfg = {
        "redirectionLifetime": 30
    };
    ATInternet.Tracker.Plugins.ContextVariables = function(a) {
        var g = "",
            k = null,
            d, b = "",
            c = "",
            h = {};
        a.configPlugin("ContextVariables", dfltPluginCfg || {}, function(a) {
            h = a
        });
        a.setConfig("redirectionLifetime", dfltGlobalCfg.redirectionLifetime, !0);
        var m = function(b, c) {
                var f = null;
                a.plugins.exec("Storage", b, c, function(a) {
                    f = a
                });
                return f
            },
            e = function() {
                a.setParam("vtag", a.version, {
                    permanent: !0,
                    hitType: ["all"]
                })
            },
            f = function() {
                a.setParam("ptag", "js", {
                    permanent: !0,
                    hitType: ["all"]
                })
            },
            q = function() {
                var b = "";
                try {
                    b += window.screen.width +
                        "x" + window.screen.height + "x" + window.screen.pixelDepth + "x" + window.screen.colorDepth
                } catch (c) {}
                a.setParam("r", b, {
                    permanent: !0,
                    hitType: ["all"]
                })
            },
            n = function() {
                var b = "";
                window.innerWidth ? b += window.innerWidth + "x" + window.innerHeight : document.body && document.body.offsetWidth && (b += document.body.offsetWidth + "x" + document.body.offsetHeight);
                a.setParam("re", b, {
                    permanent: !0,
                    hitType: ["all"]
                })
            },
            p = function() {
                window.navigator && a.setParam("lng", window.navigator.language || window.navigator.userLanguage, {
                    permanent: !0,
                    hitType: ["all"]
                })
            },
            l = function() {
                var b = ATInternet.Utils.uuid().num(13);
                a.setParam("idp", b, {
                    permanent: !0,
                    hitType: ["page", "clickzone"]
                })
            },
            s = function() {
                window.navigator && a.setParam("jv", window.navigator.javaEnabled() ? "1" : "0", {
                    hitType: ["page"]
                })
            },
            t = function() {
                a.setParam("hl", function() {
                    var a = new Date;
                    return a.getHours() + "x" + a.getMinutes() + "x" + a.getSeconds()
                }, {
                    permanent: !0,
                    hitType: ["all"]
                })
            },
            r = function(a) {
                (a = d ? d : "acc_dir" === g ? "" : null !== g ? g : "acc_dir" === k ? "" : k ? k : a ? a.referrer : "") && (a = a.replace(/[<>]/g, "").substring(0,
                    1600).replace(/&/g, "$"));
                return a
            },
            u = function() {
                var b = a.utils.getDocumentLevel();
                a.setParam("ref", r(b), {
                    permanent: !0,
                    last: !0,
                    hitType: ["page", "ecommerce", "avinsights", "events"]
                })
            },
            v = function() {
                b = "set" + (h.domainAttribution ? "" : "Private");
                c = "get" + (h.domainAttribution ? "" : "Private");
                var r = a.utils.getLocation();
                g = a.utils.getQueryStringValue("xtref", r);
                void 0 === g && (g = "");
                d = a.getContext("forcedReferer");
                if (a.getConfig("redirect")) {
                    var r = a.utils.getDocumentLevel(),
                        r = d ? d : null !== g ? g : r ? r.referrer : "acc_dir",
                        v;
                    if (v = r) {
                        v = {
                            path: "/",
                            end: a.getConfig("redirectionLifetime")
                        };
                        var C = m(c, ["atredir"]);
                        null !== C ? v = "object" === typeof C && !(C instanceof Array) : (m(b, ["atredir", {}, v]), v = !0)
                    }
                    v && m(b, [
                        ["atredir", "ref"], r
                    ])
                } else k = m(c, [
                    ["atredir", "ref"]
                ]), m("del", [
                    ["atredir", "ref"]
                ]), e(), f(), q(), n(), t(), p(), l(), s(), u();
                a.emit("ContextVariables:Ready", {
                    lvl: "INFO"
                })
            };
        a.contextVariables = {};
        a.contextVariables.params = {};
        a.contextVariables.params.vtag = e;
        a.contextVariables.params.ptag = f;
        a.contextVariables.params.r = q;
        a.contextVariables.params.re =
            n;
        a.contextVariables.params.lng = p;
        a.contextVariables.params.idp = l;
        a.contextVariables.params.jv = s;
        a.contextVariables.params.hl = t;
        a.contextVariables.params.ref = u;
        a.contextVariables.setAll = v;
        a.plugins.waitForDependencies(["Storage", "Utils"], v)
    };
    ATInternet.Tracker.addPlugin("ContextVariables");
}).call(window);
(function() {
    var dfltPluginCfg = {
        "lifetime": 395,
        "domainAttribution": true
    };
    var dfltGlobalCfg = {
        "redirectionLifetime": 30
    };
    ATInternet.Tracker.Plugins.IdentifiedVisitor = function(a) {
        var g = null,
            k = null,
            d = null,
            b = null,
            c = "",
            h = "",
            m = null,
            e = null,
            f = "",
            q = "",
            n = "",
            p = {};
        a.configPlugin("IdentifiedVisitor", dfltPluginCfg || {}, function(a) {
            p = a
        });
        a.setConfig("redirectionLifetime", dfltGlobalCfg.redirectionLifetime, !0);
        var l = function(b, c) {
                var f = null;
                a.plugins.exec("Storage", b, c, function(a) {
                    f = a
                });
                return f
            },
            s = function(a, b) {
                var c = l(q, [a, !0]);
                if (null !== c) return "object" === typeof c && !(c instanceof Array);
                l(f, [a, {}, b]);
                return !0
            },
            t = function(a, b) {
                s("atidvisitor", {
                    path: "/",
                    session: 86400 * p.lifetime
                }) && l(f, [
                    ["atidvisitor", a], b
                ])
            },
            r = function(b, c, f) {
                a.setParam(b, c, {
                    hitType: ["all"],
                    permanent: !0
                });
                f && t(b, c)
            },
            u = function() {
                var a = function(a, b) {
                        /-/.test(b) ? (a.category = b.split("-")[0], a.id = b.split("-")[1]) : a.id = b
                    },
                    b = {
                        category: "",
                        id: ""
                    };
                a(b, h || e);
                var f = {
                    category: "",
                    id: ""
                };
                a(f, c || m);
                f.id ? (f.category && r("ac", f.category, !0), r("at", f.id, !0)) : g && (r("at", g, !1), d && r("ac", d, !1));
                b.id ? (b.category && r("ac", b.category, !0), r("an", b.id, !0)) : k && r("anc", d + "-" + k, !1)
            };
        a.plugins.waitForDependencies(["Storage",
            "Utils"
        ], function() {
            f = p.domainAttribution ? "set" : "setPrivate";
            q = p.domainAttribution ? "get" : "getPrivate";
            n = p.domainAttribution ? "del" : "delPrivate";
            var r = a.utils.getLocation();
            c = a.utils.getQueryStringValue("xtat", r);
            h = a.utils.getQueryStringValue("xtan", r);
            a.getConfig("redirect") ? (c || h) && s("atredir", {
                path: "/",
                end: a.getConfig("redirectionLifetime")
            }) && (h && l(f, [
                ["atredir", "an"], h
            ]), c && l(f, [
                ["atredir", "at"], c
            ])) : (m = l(q, [
                    ["atredir", "at"]
                ]), e = l(q, [
                    ["atredir", "an"]
                ]), l(n, [
                    ["atredir", "at"]
                ]), l(n, [
                    ["atredir", "an"]
                ]),
                g = l(q, [
                    ["atidvisitor", "at"]
                ]), k = l(q, [
                    ["atidvisitor", "an"]
                ]), d = l(q, [
                    ["atidvisitor", "ac"]
                ]), b = l(q, [
                    ["atidvisitor", "vrn"]
                ]), u(), r = "-" + a.getConfig("site") + "-", RegExp(r).test(b) || (b = (b || "") + r, t("vrn", b), r = a.getContext("page") || {}, r.vrn = 1, a.setContext("page", r)));
            a.emit("IdentifiedVisitor:Ready", {
                lvl: "INFO",
                details: {
                    storageRedirectTextual: m,
                    storageRedirectNumeric: e,
                    storageTextual: g,
                    storageNumeric: k,
                    storageCategory: d,
                    storageVrn: b
                }
            })
        });
        a.identifiedVisitor = {};
        a.identifiedVisitor.set = function(a) {
            a = a || {};
            var b =
                a.id;
            a = a.category;
            "number" === typeof b ? r("an", b.toString(), !0) : "string" === typeof b && r("at", b, !0);
            "undefined" !== typeof a && r("ac", a, !0)
        };
        a.identifiedVisitor.unset = function() {
            for (var b = ["an", "at", "ac"], c = 0; c < b.length; c++) l(n, [
                ["atidvisitor", b[c]]
            ]), a.delParam(b[c]);
            a.delParam("anc")
        }
    };
    ATInternet.Tracker.addPlugin("IdentifiedVisitor");
}).call(window);
(function() {
    var dfltPluginCfg = {
        "urlKeyword": "",
        "urlResultPageNumber": "",
        "urlResultPosition": ""
    };
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.InternalSearch = function(a) {
        var g = {};
        a.configPlugin("InternalSearch", dfltPluginCfg || {}, function(a) {
            g = a
        });
        a.internalSearch = {};
        a.internalSearch.set = function(g) {
            g = g || {};
            var d = {},
                b = d,
                c = g;
            c.hasOwnProperty("keyword") && (b.keyword = c.keyword);
            b = d;
            g.hasOwnProperty("resultPageNumber") && (b.resultPageNumber = g.resultPageNumber);
            g = a.getContext("InternalSearch") || {};
            d = ATInternet.Utils.completeFstLevelObj(d, g);
            "undefined" === typeof d.resultPageNumber && (d.resultPageNumber = "1");
            a.setContext("InternalSearch",
                d)
        };
        a.internalSearch.send = function(g) {
            g = g || {};
            var d = !0,
                b = "",
                c = null;
            g.hasOwnProperty("event") && (c = g.event || window.event);
            !ATInternet.Utils.isTabOpeningAction(c) && g.elem && (b = a.techClicks.manageClick(g.elem, c), d = b.preservePropagation, b = b.elementType);
            c = {
                np: "undefined" !== typeof g.resultPageNumber ? g.resultPageNumber : "1",
                click: "IS"
            };
            g.hasOwnProperty("keyword") && (c.mc = g.keyword);
            g.hasOwnProperty("resultPosition") && (c.mcrg = g.resultPosition);
            var h = a.getContext("page") || {};
            h.level2 && (c.s2 = h.level2);
            a.sendHit(c, [
                ["hitType", ["InternalSearch"]]
            ], g.callback, null, b);
            return d
        };
        a.plugins.waitForDependencies(["Utils"], function() {
            var k;
            if (g.urlKeyword) {
                var d = document.location.href;
                k = {};
                var b = a.utils.getQueryStringValue(g.urlKeyword, d);
                b && (k.keyword = b);
                g.urlResultPageNumber && (b = a.utils.getQueryStringValue(g.urlResultPageNumber, d), k.resultPageNumber = b || "1")
            }
            k && a.setContext("InternalSearch", k);
            a.emit("InternalSearch:Ready", {
                lvl: "INFO",
                details: {
                    config: {
                        urlKeyword: g.urlKeyword,
                        urlResultPageNumber: g.urlResultPageNumber
                    },
                    url: d,
                    data: k
                }
            })
        })
    };
    ATInternet.Tracker.addPlugin("InternalSearch");
}).call(window);
(function() {
    var dfltPluginCfg = {};
    var dfltGlobalCfg = {};
    window.ATInternet.Tracker.Plugins.MvTesting = function(a) {
        var g = 0,
            k = function(a, b) {
                var d = "";
                a.hasOwnProperty(b) && (d = a[b], d = void 0 === d ? "" : d + "");
                return d
            },
            d = function(a) {
                return "object" === typeof a && !(a instanceof Array)
            },
            b = function(b) {
                return a.utils.manageChapters(b, "chapter", 3) + (b.name ? b.name : "")
            };
        a.mvTesting = {};
        a.mvTesting.set = function(b) {
            if (d(b) && !ATInternet.Utils.isEmptyObject(b)) {
                a.dispatchSubscribe("mvTesting");
                var g = k(b, "test"),
                    m = k(b, "waveId");
                b = k(b, "creation");
                a.setParam("abmvc", g + "-" + m + "-" + b, {
                    hitType: ["mvtesting"]
                })
            }
        };
        a.mvTesting.add = function(b) {
            if (d(b) && !ATInternet.Utils.isEmptyObject(b)) {
                a.dispatchSubscribe("mvTesting");
                var h = k(b, "variable");
                b = k(b, "version");
                g++;
                a.setParam("abmv" + g, h + "-" + b, {
                    hitType: ["mvtesting"]
                })
            }
        };
        a.mvTesting.onDispatch = function(c) {
            var d = a.getContext("page") || {};
            a.setParam("p", b(d), {
                hitType: ["mvtesting"]
            });
            a.setParam("s2", d.level2 || "", {
                hitType: ["mvtesting"]
            });
            a.setParam("type", "mvt", {
                hitType: ["mvtesting"]
            });
            a.sendHit(null, [
                ["hitType", ["mvtesting"]]
            ], c, null, null)
        }
    };
    window.ATInternet.Tracker.addPlugin("MvTesting");
}).call(window);
(function() {
    var dfltPluginCfg = {
        "storageCapacity": 1,
        "storageMode": "required",
        "timeout": 500
    };
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.Offline = function(a) {
        function g(b, f, p, l) {
            if (window.navigator && window.navigator.onLine) {
                var s = h();
                if (0 < s.length) {
                    var t = s.shift();
                    c({
                        hits: s
                    });
                    d || (a.onTrigger("Tracker:Hit:Sent:Ok", function(a, c) {
                        b && c.details.hit === b || g(b, f, p, l)
                    }, !1), a.onTrigger("Tracker:Hit:Sent:Error", function(a, c) {
                        b && c.details.hit === b || g(b, f, p, l)
                    }, !1), d = !0);
                    a.sendUrl(t, null, "GET", l)
                } else b && (a.utils.getQueryStringValue("a", b) ? setTimeout(function() {
                    a.sendUrl(b, null, null, null)
                }, k.timeout) : a.sendUrl(b, f, p, l))
            } else b &&
                (e(m(b)), f && f())
        }
        var k = {},
            d = !1;
        a.configPlugin("Offline", dfltPluginCfg || {}, function(a) {
            k = a
        });
        var b = function() {
                var a = localStorage.getItem("ATOffline"),
                    b = {
                        hits: [],
                        length: 0
                    };
                if (a) {
                    var c = ATInternet.Utils.jsonParse(a) || {
                        hits: []
                    };
                    b.hits = c.hits;
                    b.length = a.length
                }
                return b
            },
            c = function(a) {
                try {
                    localStorage.setItem("ATOffline", ATInternet.Utils.jsonSerialize(a))
                } catch (b) {}
            },
            h = function() {
                return b().hits
            },
            m = function(a) {
                if (a) {
                    a = a.split(/&ref=\.*/i);
                    var b = "&cn=offline&olt=" + String(Math.floor((new Date).getTime() / 1E3));
                    a = a[0] + b + (a[1] ? "&ref=" + a[1] : "")
                }
                return a
            },
            e = function(a) {
                var f = b(),
                    d = a.length,
                    e = !0;
                if (4 * ((f.length || 11) + d) > 1048576 * k.storageCapacity) {
                    var e = !1,
                        g = f.hits.shift();
                    if ("undefined" !== typeof g)
                        for (var e = !0, h = g.length; h < d;)
                            if (g = f.hits.shift(), "undefined" !== typeof g) h += g.length;
                            else {
                                e = !1;
                                break
                            }
                }
                e && (f.hits.push(a), c({
                    hits: f.hits
                }))
            },
            f = function(b) {
                a.builder.sendUrl = function(a, c, f, d) {
                    b || window.navigator && !window.navigator.onLine ? (e(m(a)), c && c()) : g(a, c, f, d)
                }
            };
        a.offline = {};
        a.offline.getLength = function() {
            return 4 *
                b().length
        };
        a.offline.remove = function() {
            c({
                hits: []
            })
        };
        a.offline.get = h;
        a.offline.send = function() {
            g(null, null, "GET")
        };
        a.plugins.waitForDependencies(["Utils"], function() {
            var b = ATInternet.Utils.isLocalStorageAvailable(),
                c;
            window.navigator && (c = window.navigator.onLine);
            b && "undefined" !== typeof c && ("required" === k.storageMode ? f(!1) : "always" === k.storageMode && f(!0));
            a.emit("Offline:Ready", {
                lvl: "INFO",
                details: {
                    isLocalStorageAvailable: b,
                    storageMode: k.storageMode,
                    isOnline: c
                }
            })
        })
    };
    window.ATInternet.Tracker.addPlugin("Offline");
}).call(window);
(function() {
    var dfltPluginCfg = {};
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.OnSiteAds = function(a) {
        var g = this,
            k = "",
            d = function(b) {
                return a.utils.manageChapters(b, "chapter", 3) + (b.name ? b.name : "")
            },
            b = function(a, b) {
                return a && a[b] ? a[b] : ""
            },
            c = function(a, c) {
                var d = b(a, c);
                if (d) {
                    var e = b(a, "prefix");
                    if (d.campaignId) {
                        var e = e || "PUB",
                            g = b(d, "campaignId"),
                            h = b(d, "creation"),
                            k = b(d, "variant"),
                            r = b(d, "format"),
                            m = b(d, "generalPlacement"),
                            v = b(d, "detailedPlacement"),
                            z = b(d, "advertiserId"),
                            d = b(d, "url");
                        return e + "-" + g + "-" + h + "-" + k + "-" + r + "-" + m + "-" + v + "-" + z + "-" + d
                    }
                    if (d.adId) return e =
                        e || "INT", g = b(d, "adId"), h = b(d, "format"), d = b(d, "productId"), e + "-" + g + "-" + h + "||" + d
                }
                return ""
            },
            h = function(b, d) {
                b = b || {};
                var e = ["onSiteAdsImpression"],
                    g = {};
                g.ati = {
                    _value: c(b, "impression"),
                    _options: {
                        hitType: e,
                        truncate: !0
                    }
                };
                g.type = "AT";
                ATInternet.Utils.isPreview() && a.getConfig("preview") && (g.pvw = 1);
                var h = b.customObject;
                h && (h = a.processTagObject("stc", e, h), g.stc = {
                    _value: ATInternet.Utils.jsonSerialize(h),
                    _options: {
                        hitType: e,
                        encode: !0,
                        separator: ",",
                        truncate: !0
                    }
                });
                a.manageSend(function() {
                    a.sendHit(g, [
                        ["hitType",
                            e
                        ]
                    ], b.callback, null, d)
                })
            },
            m = function(b, c) {
                var d = a.buffer.get("ati", !0) || {};
                d._value = "string" === typeof d._value ? [d._value] : d._value || [];
                d._options = d._options || {
                    truncate: !0,
                    hitType: [c, "page"]
                };
                d._value.push(b);
                a.buffer.set("ati", d._value, d._options)
            },
            e = function(b, d) {
                b = b || {};
                b.click ? a.setParam("atc", c(b, "click"), {
                    truncate: !0,
                    hitType: [d, "page"]
                }) : b.impression && a.setParam("ati", c(b, "impression"), {
                    truncate: !0,
                    hitType: [d, "page"]
                });
                if (b.customObject) {
                    a.setContext("onsiteads", {
                        customObject: b.customObject
                    });
                    var e = a.getContext("page") || {};
                    e.customObject = ATInternet.Utils.completeFstLevelObj(e.customObject, b.customObject, !1);
                    a.setContext("page", e)
                }
                a.dispatchSubscribe("onSiteAds")
            };
        a.selfPromotion = {};
        a.publisher = {};
        a.publisher.set = function(a) {
            e(a, "publisher")
        };
        a.selfPromotion.set = function(a) {
            e(a, "selfPromotion")
        };
        a.publisher.add = function(b) {
            m(c(b, "impression"), "publisher");
            a.dispatchSubscribe("onSiteAds")
        };
        a.selfPromotion.add = function(b) {
            m(c(b, "impression"), "selfPromotion");
            a.dispatchSubscribe("onSiteAds")
        };
        g.advertEvent = function(b) {
            b = b || {};
            var e = !0,
                g = "",
                k = null;
            b.hasOwnProperty("event") && (k = b.event || window.event);
            !ATInternet.Utils.isTabOpeningAction(k) && b.elem && (g = a.techClicks.manageClick(b.elem, k), e = g.preservePropagation, g = g.elementType);
            if (b.click) {
                b = b || {};
                var k = ["onSiteAdsClick"],
                    l = a.getContext("page") || {},
                    s = {};
                s.atc = {
                    _value: c(b, "click"),
                    _options: {
                        truncate: !0
                    }
                };
                s.type = "AT";
                s.patc = d(l);
                s.s2atc = l.level2 || "";
                if (l = b.customObject) l = a.processTagObject("stc", k, l), s.stc = {
                    _value: ATInternet.Utils.jsonSerialize(l),
                    _options: {
                        hitType: k,
                        encode: !0,
                        separator: ",",
                        truncate: !0
                    }
                };
                a.sendHit(s, [
                    ["hitType", k]
                ], b.callback, null, g)
            } else b.impression && h(b, g);
            return e
        };
        a.publisher.send = function(a) {
            return g.advertEvent(a)
        };
        a.selfPromotion.send = function(a) {
            return g.advertEvent(a)
        };
        a.onSiteAds = {};
        a.onSiteAds.onDispatch = function(b, c) {
            if (!a.dispatchSubscribed("page")) {
                a.setParam("type", "AT", {
                    hitType: ["publisher", "selfPromotion"]
                });
                var e = a.getContext("page") || {};
                a.getParam("atc") && (a.setParam("patc", d(e), {
                        hitType: ["publisher", "selfPromotion"]
                    }),
                    a.setParam("s2atc", e.level2 || "", {
                        hitType: ["publisher", "selfPromotion"]
                    }));
                ATInternet.Utils.isPreview() && a.getConfig("preview") && a.setParam("pvw", 1);
                var g = ["publisher", "selfPromotion"];
                (e = (a.getContext("onsiteads") || {}).customObject) ? a.processContextObjectAndSendHit("stc", {
                    hitType: g,
                    encode: !0,
                    separator: ",",
                    truncate: !0,
                    elementType: c
                }, e, b): a.manageSend(function() {
                    a.sendHit(null, [
                        ["hitType", g]
                    ], b, null, c)
                })
            }
        };
        a.plugins.waitForDependencies(["Utils", "TechClicks"], function() {
            k = document.location.href;
            var b =
                a.utils.getQueryStringValue("xtatc", k);
            b && a.setParam("atc", b, {
                hitType: ["publisher", "selfPromotion", "page"]
            });
            a.emit("OnSiteAds:Ready", {
                lvl: "INFO",
                details: {
                    href: k
                }
            })
        })
    };
    ATInternet.Tracker.addPlugin("OnSiteAds");
}).call(window);
(function() {
    var dfltPluginCfg = {};
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.Page = function(a) {
        var g = ["pageId", "chapterLabel", "update"],
            k = ["pid", "pchap", "pidt"],
            d = ["page", "site"],
            b = ["f", "x"],
            c = function(b) {
                return a.utils.manageChapters(b, "chapter", 3) + (b.name ? b.name : "")
            },
            h = function(a, b, c) {
                b ? a = b : a || "undefined" === typeof c || (a = c);
                return a
            },
            m = function(a, b, c) {
                b.hasOwnProperty(c) && (a[c] = h(a[c], b[c], void 0))
            },
            e = function(c, f, e) {
                if (f)
                    for (var g = 0; g < d.length; g++)
                        if (f.hasOwnProperty(d[g]) && f[d[g]])
                            for (var h in f[d[g]]) f[d[g]].hasOwnProperty(h) && (e ? c[b[g] + h] = f[d[g]][h] :
                                a.setParam(b[g] + h, f[d[g]][h]))
            },
            f = function(b, c, d) {
                if (c) {
                    var f = a.utils.manageChapters(c, "chapter", 3);
                    f && (c.chapterLabel = f.replace(/::$/gi, ""));
                    for (f = 0; f < k.length; f++) c.hasOwnProperty(g[f]) && (d ? b[k[f]] = c[g[f]] : a.setParam(k[f], c[g[f]]))
                }
            },
            q = function(b, c, f) {
                if (c && c.keywords instanceof Array) {
                    var d = c.keywords.length;
                    if (0 < d) {
                        for (var e = "", g = 0; g < d; g++) e += "[" + c.keywords[g] + "]" + (g < d - 1 ? "|" : "");
                        f ? b.tag = e : a.setParam("tag", e)
                    }
                }
            },
            n = function(b, c, d) {
                if (c) {
                    var f, e = function(a) {
                        return a ? a : "0"
                    };
                    f = "" + (e(c.category1) + "-");
                    f += e(c.category2) + "-";
                    f += e(c.category3);
                    d ? b.ptype = f : a.setParam("ptype", f)
                }
            },
            p = function(b, c, f) {
                if (c)
                    for (var d in c) c.hasOwnProperty(d) && "undefined" !== typeof c[d] && (f ? b[d] = c[d] : a.setParam(d, c[d]))
            };
        a.customVars = {};
        a.customVars.set = function(b) {
            var c = a.getContext("page") || {},
                f = c.customVars;
            if (f) {
                if (b)
                    for (var d in b) b.hasOwnProperty(d) && (f[d] = ATInternet.Utils.completeFstLevelObj(f[d], b[d], !0))
            } else f = b;
            c.customVars = f;
            a.setContext("page", c)
        };
        a.dynamicLabel = {};
        a.dynamicLabel.set = function(b) {
            var c = a.getContext("page") || {};
            c.dynamicLabel = ATInternet.Utils.completeFstLevelObj(c.dynamicLabel, b, !0);
            a.setContext("page", c)
        };
        a.tags = {};
        a.tags.set = function(b) {
            var c = a.getContext("page") || {};
            c.tags = ATInternet.Utils.completeFstLevelObj(c.tags, b, !0);
            a.setContext("page", c)
        };
        a.customTreeStructure = {};
        a.customTreeStructure.set = function(b) {
            var c = a.getContext("page") || {};
            c.customTreeStructure = ATInternet.Utils.completeFstLevelObj(c.customTreeStructure, b, !0);
            a.setContext("page", c)
        };
        a.page = {};
        a.page.reset = function() {
            a.delContext("page")
        };
        a.page.set = function(b) {
            b = b || {};
            a.dispatchSubscribe("page");
            var c = a.getContext("page") || {};
            c.name = h(c.name, b.name, "");
            c.level2 = h(c.level2, b.level2, "");
            m(c, b, "chapter1");
            m(c, b, "chapter2");
            m(c, b, "chapter3");
            c.customObject = ATInternet.Utils.completeFstLevelObj(c.customObject, b.customObject, !0);
            a.setContext("page", c)
        };
        a.page.send = function(b) {
            b = b || {};
            var d = !0,
                g = "",
                r = {
                    p: c(b),
                    s2: b.level2 || ""
                },
                k = b.customObject;
            if (k) {
                var v = ["page"],
                    k = a.processTagObject("stc", v, k);
                r.stc = {
                    _value: ATInternet.Utils.jsonSerialize(k),
                    _options: {
                        hitType: v,
                        encode: !0,
                        separator: ",",
                        truncate: !0
                    }
                }
            }
            k = a.getContext("page") || {};
            k.vrn && (r.vrn = k.vrn, a.delContext("page", "vrn"));
            v = a.getContext("InternalSearch") || {};
            "undefined" !== typeof v.keyword && (r.mc = ATInternet.Utils.cloneSimpleObject(v.keyword), "undefined" !== typeof v.resultPageNumber && (r.np = ATInternet.Utils.cloneSimpleObject(v.resultPageNumber)), a.delContext("InternalSearch"));
            ATInternet.Utils.isPreview() && a.getConfig("preview") && (r.pvw = 1);
            e(r, b.customVars, !0);
            f(r, b.dynamicLabel, !0);
            q(r,
                b.tags, !0);
            n(r, b.customTreeStructure, !0);
            v = a.getContext("campaigns") || {};
            p(r, v, !0);
            a.delContext("campaigns");
            v = null;
            b && b.hasOwnProperty("event") && (v = b.event || window.event);
            !ATInternet.Utils.isTabOpeningAction(v) && b.elem && (v = a.techClicks.manageClick(b.elem, v), d = v.preservePropagation, g = v.elementType);
            a.manageSend(function() {
                a.sendHit(r, null, b.callback, null, g)
            });
            k.name = h(k.name, b.name, "");
            k.level2 = h(k.level2, b.level2, "");
            m(k, b, "chapter1");
            m(k, b, "chapter2");
            m(k, b, "chapter3");
            a.setContext("page", k);
            return d
        };
        a.page.onDispatch = function(b, d) {
            var g = a.getContext("page") || {},
                h = a.getContext("InternalSearch") || {};
            a.setParam("p", c(g));
            a.setParam("s2", g.level2 || "");
            g.vrn && (a.setParam("vrn", g.vrn), a.delContext("page", "vrn"));
            "undefined" !== typeof h.keyword && (a.setParam("mc", ATInternet.Utils.cloneSimpleObject(h.keyword)), "undefined" !== typeof h.resultPageNumber && a.setParam("np", ATInternet.Utils.cloneSimpleObject(h.resultPageNumber)), a.delContext("InternalSearch"));
            ATInternet.Utils.isPreview() && a.getConfig("preview") &&
                a.setParam("pvw", 1);
            e(null, g.customVars, !1);
            f(null, g.dynamicLabel, !1);
            q(null, g.tags, !1);
            n(null, g.customTreeStructure, !1);
            h = a.getContext("campaigns") || {};
            p(null, h, !1);
            a.delContext("campaigns");
            var k = ["page"];
            (g = g.customObject) ? a.processContextObjectAndSendHit("stc", {
                hitType: k,
                encode: !0,
                separator: ",",
                truncate: !0,
                elementType: d
            }, g, b): a.manageSend(function() {
                a.sendHit(null, [
                    ["hitType", k]
                ], b, null, d)
            })
        }
    };
    ATInternet.Tracker.addPlugin("Page");
}).call(window);
(function() {
    var dfltPluginCfg = {};
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.SalesTracker = function(a) {
        var g = 0,
            k = function(b, c, d) {
                b.hasOwnProperty(d) && (b = b[d], a.setParam(c, void 0 === b || null === b ? "" : b + "", {
                    hitType: ["page"]
                }))
            },
            d = function(b) {
                return a.utils.manageChapters(b, "chapter", 3) + (b.name ? b.name : "")
            };
        a.order = {};
        a.cart = {};
        a.aisle = {};
        a.salesTracker = {};
        a.product = {};
        a.order.set = function(b) {
            var c = !1;
            if (ATInternet.Utils.isObject(b) && !ATInternet.Utils.isEmptyObject(b)) {
                c = !0;
                a.dispatchSubscribe("page");
                a.dispatchSubscribe("salesTracker");
                k(b, "cmd", "orderId");
                k(b, "roimt", "turnover");
                k(b, "st", "status");
                "boolean" === typeof b.newCustomer ? a.setParam("newcus", b.newCustomer ? "1" : "0", {
                    hitType: ["page"]
                }) : b.newCustomer && "undefined" === typeof a.getParams("newcus") && a.setParam("newcus", "0", {
                    hitType: ["page"]
                });
                var d = b.amount;
                ATInternet.Utils.isObject(d) && (k(d, "mtht", "amountTaxFree"), k(d, "mtttc", "amountTaxIncluded"), k(d, "tax", "taxAmount"));
                d = b.delivery;
                ATInternet.Utils.isObject(d) && (k(d, "fp", "shippingFeesTaxIncluded"), k(d, "fpht", "shippingFeesTaxFree"), k(d, "dl", "deliveryMethod"));
                k(b, "mp", "paymentMethod");
                d = b.discount;
                ATInternet.Utils.isObject(d) && (k(d, "dsc", "discountTaxIncluded"), k(d, "dscht", "discountTaxFree"), k(d, "pcd", "promotionalCode"));
                "boolean" === typeof b.confirmationRequired ? a.setParam("tp", b.confirmationRequired ? "pre1" : "", {
                    hitType: ["page"]
                }) : b.confirmationRequired && "undefined" === typeof a.getParams("tp") && a.setParam("tp", "", {
                    hitType: ["page"]
                });
                b = b.orderCustomVariables;
                if (b instanceof Array)
                    for (d = 0; d < b.length; d++) k(b, "o" + (d + 1), d)
            }
            return c
        };
        a.cart.set = function(b) {
            var c = !1;
            ATInternet.Utils.isObject(b) && !ATInternet.Utils.isEmptyObject(b) && (c = !0, a.dispatchSubscribe("page"), a.dispatchSubscribe("salesTracker"), k(b, "idcart", "cartId"), "boolean" === typeof b.isBasketPage ? "pre1" !== a.getParams("tp") && a.setParam("tp", b.isBasketPage ? "cart" : "", {
                hitType: ["page"]
            }) : b.isBasketPage && "undefined" === typeof a.getParams("tp") && a.setParam("tp", "", {
                hitType: ["page"]
            }));
            return c
        };
        a.cart.add = function(b) {
            var c = !1;
            if (ATInternet.Utils.isObject(b) && !ATInternet.Utils.isEmptyObject(b) && (c = !0, b = b.product,
                    ATInternet.Utils.isObject(b))) {
                g++;
                var d = g,
                    m = b.productId ? b.productId : "",
                    e = b.category ? b.category + "::" : "",
                    f = a.utils.manageChapters(b, "category", 6);
                f && (e = f);
                a.setParam("pdt" + d, e + m, {
                    hitType: ["page"]
                });
                k(b, "qte" + d, "quantity");
                k(b, "mt" + d, "unitPriceTaxIncluded");
                k(b, "mtht" + d, "unitPriceTaxFree");
                k(b, "dsc" + d, "discountTaxIncluded");
                k(b, "dscht" + d, "discountTaxFree");
                k(b, "pcode" + d, "promotionalCode")
            }
            return c
        };
        a.aisle.set = function(b) {
            var c = !1;
            ATInternet.Utils.isObject(b) && !ATInternet.Utils.isEmptyObject(b) && (c = !0, a.dispatchSubscribe("page"), b = a.utils.manageChapters(b, "level", 6), b = b.replace(/::$/gi, ""), a.setParam("aisl", b, {
                hitType: ["page"]
            }));
            return c
        };
        a.product.add = function(b) {
            var c = !1,
                d;
            if (d = ATInternet.Utils.isObject(b))
                if (d = !ATInternet.Utils.isEmptyObject(b)) {
                    a: {
                        d = ["productId"];
                        for (var g = 0; g < d.length; g++)
                            if (void 0 === b[d[g]]) {
                                d = !0;
                                break a
                            }
                        d = !1
                    }
                    d = !d
                }
            d && (c = !0, d = "", (g = a.utils.manageChapters(b, "category", 6)) && (d = g), d += b.productId, b = a.getContext("product") || {}, b.viewedProducts ? b.viewedProducts.push(d) : b.viewedProducts = [d], a.setContext("product", b), a.dispatchSubscribe("salesTracker"));
            return c
        };
        a.salesTracker.onDispatch = function(b) {
            var c = a.getContext("product");
            if (c && c.viewedProducts) {
                var g = ["product"],
                    k = a.getContext("page");
                "undefined" !== typeof k && (a.setParam("p", d(k), {
                    hitType: g
                }), a.setParam("s2", k.level2 || "", {
                    hitType: g
                }));
                a.setParam("pdtl", c.viewedProducts.join("|"), {
                    truncate: !0,
                    hitType: g
                });
                a.setParam("type", "pdt", {
                    hitType: g
                });
                a.sendHit(null, [
                    ["hitType", g]
                ], b, null, null)
            }
        }
    };
    ATInternet.Tracker.addPlugin("SalesTracker");
}).call(window);
(function() {
    var dfltPluginCfg = {
        "clientSideMode": "required",
        "userIdCookieDuration": 395,
        "userIdExpirationMode": "fixed",
        "optOut": "OPT-OUT",
        "userIdStorageName": "atuserid",
        "userIdHitName": "idclient",
        "itpCompliant": false,
        "baseDomain": ""
    };
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.ClientSideUserId = function(a) {
        var g = {},
            k = !1,
            d = !1,
            b = null,
            c = -1;
        a.configPlugin("ClientSideUserId", dfltPluginCfg || {}, function(a) {
            g = a
        });
        var h = function() {
                var b = g.baseDomain;
                if (!b) {
                    var c = a.getConfig("cookieDomain");
                    c && (b = c, "." === b.charAt(0) && (b = b.substring(1, b.length)))
                }
                var c = a.builder.getCollectDomain(),
                    f = a.utils.getHostName();
                return !!(b && c && f && -1 !== c.indexOf(b) && -1 !== f.indexOf(b))
            },
            m = function() {
                b = {
                    contextUserId: void 0,
                    storageUserId: null,
                    finalUserId: null,
                    isFromTrackerContext: !1,
                    forceStorage: !1,
                    optout: {
                        isOptedout: !1,
                        fromStorage: !1
                    }
                }
            },
            e = function() {
                if ("relative" === g.userIdExpirationMode || "fixed" === g.userIdExpirationMode && null === b.storageUserId || b.isFromTrackerContext) {
                    var c = new Date;
                    c.setTime(c.getTime() + 864E5 * g.userIdCookieDuration);
                    a.storage.set(g.userIdStorageName, b.finalUserId, {
                        end: c,
                        path: "/"
                    }, b.forceStorage);
                    ATInternet.Utils.consent && !b.isFromTrackerContext && b.finalUserId !== a.storage.get(g.userIdStorageName, !0) && a.setParam(g.userIdHitName, b.finalUserId + "-NO", {
                        multihit: !0,
                        permanent: !0,
                        hitType: ["all"]
                    })
                }
            },
            f = function() {
                a.setParam(g.userIdHitName, b.finalUserId, {
                    multihit: !0,
                    permanent: !0,
                    hitType: ["all"]
                });
                e()
            },
            q = function() {
                m();
                var c = !1;
                null === ATInternet.Utils.optedOut ? a.storage.get(g.userIdStorageName, !0) === g.optOut ? c = ATInternet.Utils.optedOut = !0 : ATInternet.Utils.optedOut = !1 : !1 === ATInternet.Utils.optedOut && (a.getParam(g.userIdHitName) === g.optOut && a.delParam(g.userIdHitName), a.storage.get(g.userIdStorageName, !0) === g.optOut && a.storage.del(g.userIdStorageName));
                b.optout.isOptedout =
                    ATInternet.Utils.optedOut;
                b.optout.fromStorage = c;
                b.contextUserId = a.getContext("userIdentifier");
                b.storageUserId = a.storage.get("atuserid", !0);
                c = !1;
                if ("required" === g.clientSideMode) {
                    var e = "";
                    window.navigator && (e = window.navigator.userAgent);
                    if (/Safari/.test(e) && !/Chrome/.test(e) || /iPhone|iPod|iPad/.test(e)) c = !0
                } else "always" === g.clientSideMode && (c = !0);
                d = c;
                c = !1;
                if (!a.getConfig("forceHttp") && g.itpCompliant && "undefined" === typeof b.contextUserId && !b.optout.isOptedout) switch (g.clientSideMode) {
                    case "never":
                        c =
                            h();
                        break;
                    case "always":
                    case "required":
                        d && null !== b.storageUserId || (c = h())
                }(k = c) || !d && !b.optout.isOptedout && "undefined" === typeof b.contextUserId ? a.setConfig("userIdOrigin", "server") : (a.setConfig("userIdOrigin", "client"), b.isFromTrackerContext = !1, b.forceStorage = !1, b.optout.isOptedout ? (b.finalUserId = g.optOut, b.isFromTrackerContext = !b.optout.fromStorage, b.forceStorage = !0) : a.getConfig("disableCookie") || a.getConfig("disableStorage") ? (b.finalUserId = a.getParam(g.userIdHitName), b.isFromTrackerContext = !0) :
                    "undefined" !== typeof b.contextUserId ? (b.finalUserId = b.contextUserId, b.isFromTrackerContext = !0) : b.finalUserId = null !== b.storageUserId ? b.storageUserId : ATInternet.Utils.uuid().v4(), f())
            },
            n = function(a) {
                a && (a = a.detail) && "clientsideuserid" === a.name && a.id === c && q()
            };
        (function() {
            a.plugins.waitForDependencies(["Storage", "Utils"], function() {
                var a = ATInternet.Utils.uuid();
                c = parseInt(a.num(8));
                ATInternet.Utils.removeOptOutEvent(n);
                ATInternet.Utils.addOptOutEvent(c, n);
                q()
            })
        })();
        a.clientSideUserId = {};
        a.clientSideUserId.set =
            function(a) {
                b.optout.isOptedout || (b.finalUserId = a, b.isFromTrackerContext = !0, b.forceStorage = !1, f())
            };
        a.clientSideUserId.store = function() {
            b.finalUserId = a.getParam(g.userIdHitName) || b.finalUserId;
            null !== b.finalUserId && b.finalUserId !== ATInternet.Utils.privacy.CONSENTNO && b.finalUserId !== b.storageUserId && (b.isFromTrackerContext = !0, b.forceStorage = !0, e())
        };
        a.clientSideUserId.get = function() {
            b.finalUserId = a.getParam(g.userIdHitName) || b.finalUserId;
            return b.finalUserId
        };
        a.clientSideUserId.clear = function() {
            m();
            a.delParam(g.userIdHitName);
            a.storage.del(g.userIdStorageName)
        }
    };
    ATInternet.Tracker.addPlugin("ClientSideUserId");
}).call(window);
(function() {
    var dfltPluginCfg = {
        "authorityStorageName": "atauthority",
        "authorities": {
            "default": {
                "name": "default",
                "optin": {
                    "name": "optin",
                    "storageDuration": 397,
                    "trackerSettings": {
                        "disableStorage": false,
                        "disableCookie": false
                    },
                    "add": {
                        "buffer": {
                            "visitorConsent": {
                                "param": "vc",
                                "value": true
                            },
                            "visitorMode": {
                                "param": "vm",
                                "value": "optin"
                            }
                        }
                    },
                    "include": {
                        "storage": "*",
                        "buffer": "*"
                    }
                },
                "optout": {
                    "name": "optout",
                    "storageDuration": 397,
                    "trackerSettings": {
                        "disableStorage": false,
                        "disableCookie": false
                    },
                    "add": {
                        "buffer": {
                            "visitorConsent": {
                                "param": "vc",
                                "value": false
                            },
                            "visitorMode": {
                                "param": "vm",
                                "value": "optout"
                            }
                        }
                    },
                    "include": {
                        "storage": ["atuserid", "atauthority"],
                        "buffer": ["s", "idclient", "ts", "vc", "vm", "click", "type", "olt", "cn", "mh"]
                    }
                },
                "no-consent": {
                    "name": "no-consent",
                    "storageDuration": 0,
                    "trackerSettings": {
                        "disableStorage": true,
                        "disableCookie": true
                    },
                    "add": {
                        "buffer": {
                            "visitorConsent": {
                                "param": "vc",
                                "value": false
                            },
                            "visitorMode": {
                                "param": "vm",
                                "value": "no-consent"
                            },
                            "idclient": {
                                "param": "idclient",
                                "value": "Consent-NO"
                            }
                        }
                    },
                    "include": {
                        "storage": [],
                        "buffer": ["s", "idclient", "ts", "vc", "vm", "click", "type", "olt", "cn", "mh"]
                    }
                },
                "random": {
                    "name": "random",
                    "storageDuration": 0,
                    "trackerSettings": {
                        "disableStorage": false,
                        "disableCookie": false
                    },
                    "add": {
                        "buffer": {
                            "visitorConsent": {
                                "param": "vc",
                                "value": false
                            },
                            "visitorMode": {
                                "param": "vm",
                                "value": "before-consent"
                            }
                        }
                    },
                    "include": {
                        "storage": [],
                        "buffer": ["s", "idclient", "p", "vtag", "ptag", "ts", "vc", "vm", "ref", "xto", "click", "type", "olt", "cn", "mh"]
                    }
                }
            },
            "cnil": {
                "name": "cnil",
                "exempt": {
                    "name": "exempt",
                    "storageDuration": 397,
                    "trackerSettings": {
                        "disableStorage": false,
                        "disableCookie": false
                    },
                    "add": {
                        "buffer": {
                            "visitorConsent": {
                                "param": "vc",
                                "value": false
                            },
                            "visitorMode": {
                                "param": "vm",
                                "value": "exempt"
                            }
                        }
                    },
                    "include": {
                        "storage": ["atuserid", "atauthority"],
                        "buffer": ["s", "idclient", "p", "vtag", "ptag", "ts", "vc", "vm", "click", "type", "olt", "cn", "mh", "ref"]
                    }
                }
            }
        },
        "parametersToInclude": []
    };
    var dfltGlobalCfg = {};
    ATInternet.Tracker.Plugins.Privacy = function(a) {
        var g = function(d) {
                function b() {
                    if (p && l) {
                        var b = new Date;
                        b.setTime(b.getTime() + 864E5 * l.storageDuration);
                        a.storage.set(t.authorityStorageName, {
                            authority_name: p.name,
                            visitor_mode: l.name
                        }, {
                            end: b,
                            path: "/"
                        })
                    }
                }

                function c(c) {
                    l && (0 < l.storageDuration ? c ? b() : (c = a.storage.get(t.authorityStorageName, !0), null === c ? b() : "object" === typeof c && (c.authority_name === p.name && c.visitor_mode === l.name || b())) : a.storage.del(t.authorityStorageName))
                }

                function g() {
                    ATInternet.Utils.privacy.processStorageParams(function(b) {
                            a.storage.del(b)
                        },
                        function(b) {
                            return a.storage.get(b, !0) || a.storage.getPrivate(b, !0)
                        },
                        function() {
                            return a.storage.getAll()
                        }, n.getVisitorMode().name)
                }

                function k() {
                    ATInternet.Utils.privacy.processBufferParams(function(b) {
                        a.delParam(b)
                    }, function() {
                        return a.getParams([])
                    }, function(b, c, d) {
                        a.setParam(b, c, d)
                    }, n.getVisitorMode().name)
                }

                function e(a, b, c) {
                    if (l && l.include) {
                        l.include[b] instanceof Array ? a instanceof Array ? l.include[b] = l.include[b].concat(a) : a && l.include[b].push(a) : l.include[b] !== ATInternet.Utils.privacy.ALL && (a instanceof Array ? l.include[b] = a : a && (l.include[b] = [a]));
                        a = s;
                        var d = b + "Params",
                            f = l.include[b];
                        b = [];
                        for (var e = {}, g = 0; g < f.length; g++)
                            if ("object" === typeof f[g])
                                for (var h in f[g]) f[g].hasOwnProperty(h) && (e[h] = (e[h] || []).concat(f[g][h]));
                            else b.push(f[g]);
                        for (var k in e) e.hasOwnProperty(k) && (h = {}, h[k] = e[k], b.push(h));
                        a[d] = b;
                        ATInternet.Utils.privacy.setParameters(s);
                        c && c()
                    }
                }

                function f(b, d, f, e) {
                    if (t.authorities && t.authorities[b] && t.authorities[b][d]) {
                        f && a.clientSideUserId.clear();
                        e && n.setVisitorOptin();
                        p = t.authorities[b];
                        l = p[d];
                        ATInternet.Utils.privacy.setMode(d);
                        if (l)
                            for (var w in l.trackerSettings) l.trackerSettings.hasOwnProperty(w) && a.setConfig(w, l.trackerSettings[w]);
                        if (l && l.add)
                            for (var C in l.add.buffer) l.add.buffer.hasOwnProperty(C) && a.setParam(l.add.buffer[C].param, l.add.buffer[C].value, {
                                multihit: !0,
                                permanent: !0,
                                hitType: ["all"]
                            });
                        if (l && l.include) {
                            for (var A in l.include) l.include.hasOwnProperty(A) && (b = l.include[A] instanceof Array ? l.include[A] : [l.include[A]], s[A + "Params"] = b);
                            ATInternet.Utils.privacy.setParameters(s);
                            c(!1)
                        }
                        0 < t.parametersToInclude.length && (n.extendIncludeStorage(t.parametersToInclude), n.extendIncludeBuffer(t.parametersToInclude));
                        g();
                        k();
                        q()
                    }
                }

                function q() {
                    for (var b = s.bufferParams, c = b.length, d = 0; d < c; d++) {
                        var f = b[d];
                        if (f === ATInternet.Utils.privacy.ALL) {
                            a.contextVariables.setAll();
                            break
                        }(f = a.contextVariables.params[f]) && f()
                    }
                }
                var n = this,
                    p = null,
                    l = null,
                    s = {
                        storageParams: [],
                        bufferParams: []
                    },
                    t = d;
                n.setVisitorOptout = function() {
                    ATInternet.Utils.consentReceived(!0);
                    f("default", "optout", !1, !1);
                    ATInternet.Utils.userOptedOut()
                };
                n.setVisitorOptin = function() {
                    ATInternet.Utils.consentReceived(!0);
                    a.clientSideUserId.store();
                    f("default", "optin", !1, !1);
                    ATInternet.Utils.userOptedIn()
                };
                n.setVisitorRandomID = function() {
                    ATInternet.Utils.consentReceived(!1);
                    f("default", "random", !1, !1);
                    ATInternet.Utils.userOptedIn()
                };
                n.setVisitorMode = function(a, b, c) {
                    var d = !0;
                    "cnil" === a && "exempt" === b ? d = !1 : "boolean" === typeof c && (d = c);
                    d && p && l && (d = a !== p.name || b !== l.name);
                    f(a, b, d, !0)
                };
                n.getAuthority = function() {
                    return p
                };
                n.getVisitorMode = function() {
                    return l
                };
                n.addAuthority = function(a) {
                    a && "object" === typeof a && (t.authorities = t.authorities || {}, t.authorities[a.name] = a)
                };
                n.extendIncludeStorage = function(a) {
                    e(a, "storage", g)
                };
                n.extendIncludeBuffer = function(a) {
                    e(a, "buffer", k);
                    q()
                };
                n.updateStorageDuration = function(a) {
                    l && (l.storageDuration = a, c(!0))
                };
                (function() {
                    var b = a.storage.get([t.authorityStorageName, "authority_name"], !0),
                        c = a.storage.get([t.authorityStorageName, "visitor_mode"], !0);
                    b && c && ("default" === b ? "optin" === c ? n.setVisitorOptin() : "optout" === c ? n.setVisitorOptout() :
                        "random" === c ? n.setVisitorRandomID() : n.setVisitorMode(b, c) : n.setVisitorMode(b, c))
                })()
            },
            k = null;
        a.privacy = {
            setVisitorOptout: function() {},
            setVisitorOptin: function() {},
            setVisitorRandomID: function() {},
            setVisitorMode: function() {},
            getAuthority: function() {},
            getVisitorMode: function() {},
            addAuthority: function() {},
            extendIncludeStorage: function() {},
            extendIncludeBuffer: function() {},
            updateStorageDuration: function() {}
        };
        (function() {
            a.plugins.waitForDependencies(["Storage", "Utils", "ClientSideUserId", "ContextVariables"],
                function() {
                    var d = null;
                    a.configPlugin("Privacy", dfltPluginCfg || {}, function(a) {
                        d = ATInternet.Utils.cloneSimpleObject(a)
                    });
                    null !== d && (k = new g(d), a.privacy.setVisitorOptout = k.setVisitorOptout, a.privacy.setVisitorOptin = k.setVisitorOptin, a.privacy.setVisitorRandomID = k.setVisitorRandomID, a.privacy.setVisitorMode = k.setVisitorMode, a.privacy.getAuthority = k.getAuthority, a.privacy.getVisitorMode = k.getVisitorMode, a.privacy.addAuthority = k.addAuthority, a.privacy.extendIncludeStorage = k.extendIncludeStorage, a.privacy.extendIncludeBuffer =
                        k.extendIncludeBuffer, a.privacy.updateStorageDuration = k.updateStorageDuration)
                })
        })()
    };
    ATInternet.Tracker.addPlugin("Privacy");
}).call(window);
if (typeof window.ATInternet.onTrackerLoad === 'function') {
    window.ATInternet.onTrackerLoad();
}