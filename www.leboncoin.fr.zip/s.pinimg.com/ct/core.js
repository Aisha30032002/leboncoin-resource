! function(t) {
    var i = {};

    function r(n) {
        var e;
        return (i[n] || (e = i[n] = {
            i: n,
            l: !1,
            exports: {}
        }, t[n].call(e.exports, e, e.exports, r), e.l = !0, e)).exports
    }
    r.m = t, r.c = i, r.d = function(n, e, t) {
        r.o(n, e) || Object.defineProperty(n, e, {
            enumerable: !0,
            get: t
        })
    }, r.r = function(n) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(n, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(n, "u", {
            value: !0
        })
    }, r.t = function(e, n) {
        if (1 & n && (e = r(e)), 8 & n) return e;
        if (4 & n && "object" == typeof e && e && e.u) return e;
        var t = Object.create(null);
        if (r.r(t), Object.defineProperty(t, "default", {
                enumerable: !0,
                value: e
            }), 2 & n && "string" != typeof e)
            for (var i in e) r.d(t, i, function(n) {
                return e[n]
            }.bind(null, i));
        return t
    }, r.n = function(n) {
        var e = n && n.u ? function() {
            return n.default
        } : function() {
            return n
        };
        return r.d(e, "a", e), e
    }, r.o = function(n, e) {
        return Object.prototype.hasOwnProperty.call(n, e)
    }, r.p = "", r(r.s = 2)
}([function(n, e) {
    function t(n, e) {
        return function(n) {
            if (Array.isArray(n)) return n
        }(n) || function(n, e) {
            var t = null == n ? null : "undefined" != typeof Symbol && n[Symbol.iterator] || n["@@iterator"];
            if (null != t) {
                var i, r, o = [],
                    a = !0,
                    c = !1;
                try {
                    for (t = t.call(n); !(a = (i = t.next()).done) && (o.push(i.value), !e || o.length !== e); a = !0);
                } catch (n) {
                    c = !0, r = n
                } finally {
                    try {
                        a || null == t.return || t.return()
                    } finally {
                        if (c) throw r
                    }
                }
                return o
            }
        }(n, e) || function(n, e) {
            var t;
            if (n) return "string" == typeof n ? i(n, e) : "Map" === (t = "Object" === (t = Object.prototype.toString.call(n).slice(8, -1)) && n.constructor ? n.constructor.name : t) || "Set" === t ? Array.from(n) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? i(n, e) : void 0
        }(n, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function i(n, e) {
        (null == e || e > n.length) && (e = n.length);
        for (var t = 0, i = new Array(e); t < e; t++) i[t] = n[t];
        return i
    }
    var r = {};
    r.LIST = {
        FP_LOCAL_STORAGE: {
            chance: 100,
            uri: "fp_localStorage"
        },
        DERIVED_EPIK: {
            chance: 100,
            uri: "pin-derived-epik"
        },
        SCRAPE_LISTENERS: {
            chance: 100,
            uri: "pin-scrape-listeners"
        },
        FETCH_API_V3: {
            chance: 0,
            uri: "pin-fetch-api-v3"
        },
        SEND_LOGS: {
            chance: 100,
            uri: "pin-log-errors"
        },
        CHECK_CSP: {
            chance: 5,
            uri: "pin-check-csp"
        },
        DEDUPE_AEM_ELIGIBLE_ARRAY: {
            chance: 100,
            uri: "pin-dedupe-aem-eligible-array"
        },
        CHECK_AUTO_UPGRADED: {
            chance: 100,
            uri: "pin-check-auto-upgraded"
        }
    };
    for (var o = 0, a = Object.entries(r.LIST); o < a.length; o++) {
        var c = t(a[o], 2),
            u = c[0],
            c = c[1];
        "true" === new URLSearchParams(window.location.search).get(c.uri) && (r.LIST[u].chance = 100)
    }
    r.isInRampPercentage = function(n) {
        return 100 * Math.random() < (n || 0)
    }, n.exports = r
}, function(n, e, t) {
    var i = t(0),
        r = {},
        o = "unknown";

    function a(n) {
        n.version = o, 100 * Math.random() < (i.LIST.SEND_LOGS.chance || 0) && r.v(n)
    }
    r.setVersion = function(n) {
        o = n
    }, r.v = function(n) {
        var e = new window.XMLHttpRequest;
        e.withCredentials = !1, e.onerror = function() {
            console.error("Error message failed to send")
        }, e.open("POST", "https://ct.pinterest.com/stats/", !1), e.setRequestHeader("Content-Type", "application/json"), e.send(JSON.stringify(n))
    }, r.error = function(n, e) {
        var t = {
            messageType: "ERROR",
            message: n,
            log: "[".concat(2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "Empty", "]")
        };
        e.hasOwnProperty("stack") ? t.log += "[".concat(e.stack, "]") : t.log += "[".concat(e.message, "]"), a(t)
    }, r.info = function(n, e) {
        a({
            messageType: "INFO",
            message: n,
            log: "[".concat(2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "Empty", "][").concat(e, "]")
        })
    }, n.exports = r
}, function(n, e, t) {
    var i, r, o, a;
    i = document, r = t(0), o = t(1), a = t(3), (t = i.createElement("script")).async = !0, o.setVersion("74d80534"), r.isInRampPercentage(r.LIST.SEND_LOGS.chance) && (t.onerror = function() {
        o.error("Failed to load ".concat("74d80534"), new Error("failed to load main.js"))
    }), r.isInRampPercentage(r.LIST.CHECK_CSP.chance) && (document.onsecuritypolicyviolation = function(n) {
        a.sendEventInfo(n)
    }), t.src = "https://s.pinimg.com/ct/lib/main.74d80534.js", (r = i.getElementsByTagName("script")[0]).parentNode.insertBefore(t, r)
}, function(n, e, t) {
    var i = {},
        r = t(1),
        o = /https?:\/\/s\.pinimg\.com\/ct\/lib\/main\.[0-9a-f]{8}\.js/g;
    i.sendEventInfo = function(n) {
        var e, t;
        n && n.blockedURI && "https://s.pinimg.com/ct/lib/main.74d80534.js" === n.blockedURI && (e = "Directive: " + n.effectiveDirective + " Disposition: " + n.disposition + " Blocked URI: " + n.blockedURI, n.originalPolicy ? (t = i.h(n.originalPolicy)) && 0 < t.length ? (e += " main file(s) allowed: " + t.join(" "), r.info("csp violation main file(s) allowed - " + n.disposition, e)) : r.info("csp violation no main file allowed - " + n.disposition, e) : r.info("csp violation original policy not available", e))
    }, i.h = function(n) {
        return n ? n.match(o) : null
    }, n.exports = i
}]);