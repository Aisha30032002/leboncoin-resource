! function() {
    try {
        window.didomiRemoteConfig = {
            "notices": [{
                "notice_id": "r9VU4Gy5",
                "default": false,
                "platform": "web",
                "targets": ["*.leboncoin.fr", "*.bon-coin.net"],
                "config": {
                    "app": {
                        "name": "Leboncoin",
                        "logoUrl": "https://img8.leboncoin.fr/FrontTools/didomi/lbc-logo.png",
                        "vendors": {
                            "iab": {
                                "all": false,
                                "stacks": {
                                    "ids": [],
                                    "auto": false
                                },
                                "enabled": true,
                                "exclude": [],
                                "include": [280, 73, 215, 742, 41, 250, 505, 69, 281, 84, 223, 467, 358, 301, 303, 568, 639, 512, 625, 628, 497, 596, 769, 713, 670, 541, 706, 579, 620, 423, 617, 652, 720, 690, 655, 658, 210, 665, 719, 89, 72, 702, 226, 707, 193, 66, 385, 67, 791, 161, 794, 162, 316, 253, 716, 797, 79, 144, 812, 777, 59, 114, 807, 124, 435, 887, 813, 60, 278, 284, 295, 925, 744, 314, 911, 62, 321, 93, 102, 142, 209, 234, 916, 402, 830, 972, 345, 945, 368, 373, 381, 388, 559, 412, 11, 34, 317, 666, 416, 12, 149, 39, 40, 231, 241, 413, 565, 126, 244, 21, 45, 85, 23, 266, 431, 434, 1025, 83, 26, 98, 177, 185, 475, 1, 654, 51, 1112, 468, 498, 501, 506, 511, 484, 546, 550, 569, 384, 133, 199, 1126, 349, 179, 621, 70, 4, 790, 263, 152, 667, 677, 28, 365, 63, 746, 315, 183, 109, 200, 108, 382, 13, 772, 30, 31, 57, 631, 10, 157, 184, 192, 804, 469, 854, 856, 128, 78, 885, 319, 482, 2, 14, 15, 16, 20, 24, 27, 32, 36, 42, 49, 50, 52, 53, 61, 71, 129, 243, 1232, 77, 80, 82, 91, 92, 94, 95, 97, 100, 101, 110, 131, 132, 138, 140, 153, 154, 155, 195, 165, 202, 203, 216, 227, 238, 254, 259, 264, 272, 275, 119, 122, 285, 76, 436, 25, 68, 120, 130, 793, 814, 127, 418, 663],
                                "version": 2,
                                "minorVersion": 2,
                                "restrictions": [{
                                    "id": "TJhbP6rd",
                                    "vendors": {
                                        "ids": [],
                                        "type": "all"
                                    },
                                    "purposeId": "geolocation_data",
                                    "restrictionType": "disallow"
                                }, {
                                    "id": "9mqnLxdf",
                                    "vendors": {
                                        "ids": [],
                                        "type": "all"
                                    },
                                    "purposeId": "device_characteristics",
                                    "restrictionType": "disallow"
                                }, {
                                    "id": "ZTTLZiKA",
                                    "vendors": {
                                        "ids": [],
                                        "type": "all"
                                    },
                                    "purposeId": "create_content_profile",
                                    "restrictionType": "disallow"
                                }, {
                                    "id": "afpDG74B",
                                    "vendors": {
                                        "ids": [],
                                        "type": "all"
                                    },
                                    "purposeId": "select_personalized_content",
                                    "restrictionType": "disallow"
                                }, {
                                    "id": "g2XXew7d",
                                    "vendors": {
                                        "ids": [],
                                        "type": "all"
                                    },
                                    "purposeId": "measure_content_performance",
                                    "restrictionType": "disallow"
                                }],
                                "gvlSpecificationVersion": 3
                            },
                            "didomi": ["facebook", "google"],
                            "custom": [{
                                "id": "maytricsg-AS35Yam9",
                                "name": "Maytrics GmbH",
                                "policyUrl": "https://maytrics.com/node/2",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2956,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "lbcfrance",
                                "name": "LBC FRANCE",
                                "policyUrl": "",
                                "purposeIds": ["experienceutilisateur", "mesureaudience", "necessaires", "personnalisationmarketing", "prix"],
                                "legIntPurposeIds": [],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "revlifter-cRpMnp5x",
                                "name": "RevLifter Ltd",
                                "policyUrl": "https://www.revlifter.com/privacy-policy",
                                "purposeIds": ["cookies"],
                                "legIntPurposeIds": [],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "didomi",
                                "name": "Didomi",
                                "policyUrl": "https://privacy.didomi.io/",
                                "purposeIds": ["cookies"],
                                "legIntPurposeIds": [],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "akamai",
                                "name": "Akamai",
                                "policyUrl": "http://www.akamai.com/compliance/privacy",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 70,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "tailtarget",
                                "name": "TailTarget",
                                "policyUrl": "",
                                "purposeIds": ["cookies", "create_ads_profile", "create_content_profile", "improve_products", "market_research", "measure_content_performance", "select_basic_ads", "select_personalized_ads", "select_personalized_content", "measure_ad_performance"],
                                "legIntPurposeIds": [],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "spongecell",
                                "name": "Spongecell",
                                "policyUrl": "",
                                "purposeIds": ["cookies", "create_ads_profile", "create_content_profile", "improve_products", "market_research", "measure_ad_performance", "measure_content_performance", "select_basic_ads", "select_personalized_ads", "select_personalized_content"],
                                "legIntPurposeIds": [],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "zanox",
                                "name": "Zanox",
                                "policyUrl": "",
                                "purposeIds": ["cookies", "create_ads_profile", "create_content_profile", "improve_products", "market_research", "measure_ad_performance", "measure_content_performance", "select_basic_ads", "select_personalized_ads", "select_personalized_content"],
                                "legIntPurposeIds": [],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "navegg",
                                "name": "Navegg",
                                "policyUrl": "https://www.navegg.com/en/privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 1570,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "at-internet",
                                "name": "AT Internet",
                                "policyUrl": "https://www.atinternet.com/societe/rgpd-et-vie-privee/collecte-de-donnees-sur-les-sites-dat-internet/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 587,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "purposela-3w4ZfKKD",
                                "name": "PurposeLab, LLC",
                                "policyUrl": "https://purposelab.com/privacy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "infectious-media",
                                "name": "Infectious Media",
                                "policyUrl": "https://impressiondesk.com/privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "maxcdn-iUMtNqcL",
                                "name": "MaxCDN",
                                "policyUrl": "https://www.stackpath.com/legal/privacy-statement/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 1027,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "cloudflare",
                                "name": "CloudFlare",
                                "policyUrl": "https://www.cloudflare.com/security-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 1097,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "intimate-merger",
                                "name": "Intimate Merger",
                                "policyUrl": "https://corp.intimatemerger.com/privacypolicy-en/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2279,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "advanse-H6qbaxnQ",
                                "name": "Advanse",
                                "policyUrl": "http://advanseads.com/privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 1188,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "snapinc-yhYnJZfT",
                                "name": "Snap Inc.",
                                "policyUrl": "https://www.snap.com/en-US/privacy/privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2572,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "retargeter-beacon",
                                "name": "ReTargeter / Sellpoints Inc.",
                                "policyUrl": "https://retargeter.com/service-privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2216,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "turbo",
                                "name": "Turbo S.r.l.",
                                "policyUrl": "http://www.turboadv.com/white-rabbit-privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "crutchfiel-hJd2mxEQ",
                                "name": "Crutchfield",
                                "policyUrl": "https://www.crutchfield.com/support/privacy.aspx",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2103,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "cablatoli-nRmVawp2",
                                "name": "Cablato Limited",
                                "policyUrl": "https://cablato.com/privacy",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 1878,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "viant-47x2Yhf7",
                                "name": "Viant",
                                "policyUrl": "https://viantinc.com/privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2343,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "createjs",
                                "name": "CreateJS",
                                "policyUrl": "https://createjs.com/legal/privacy.html",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2072,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "netscore-YnRdcgWL",
                                "name": "Netscore",
                                "policyUrl": "http://netscore.pl/polityka-prywatnosci/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2477,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "branch-V2dEBRxJ",
                                "name": "Branch",
                                "policyUrl": "https://branch.io/policies/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2605,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "sfr-Mdpi7kfN",
                                "name": "SFR",
                                "policyUrl": "http://www.sfr.fr/securite-confidentialite.html",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 1870,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "appsflyer-YrPdGF63",
                                "name": "AppsFlyer",
                                "policyUrl": "https://www.appsflyer.com/privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2577,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "hasoffer-8YyMTtXi",
                                "name": "HasOffer - Tune, Inc",
                                "policyUrl": "https://www.hasoffers.com/privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2821,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "lkqd-cU9QmB6W",
                                "name": "LKQD",
                                "policyUrl": "https://www.nexstardigital.com/privacy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2411,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "swaven-LYBrimAZ",
                                "name": "Swaven",
                                "policyUrl": "http://www.swaven.com/cookie-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2791,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "squeezely-De3zTEU6",
                                "name": "Squeezely",
                                "policyUrl": "https://squeezely.tech/privacy",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2901,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "fortvision-ie6bXTw9",
                                "name": "FORTVISION",
                                "policyUrl": "http://fortvision.com/POC/index.html",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 3106,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "adimo-PhUVm6FE",
                                "name": "Adimo",
                                "policyUrl": "https://adimo.co/privacy-policy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "oscarocom-FRchNdnH",
                                "name": "OSCARO COM",
                                "policyUrl": "https://www.oscaro.com/fr/info/securite-confidentialite",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2927,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "geoladgmb-LJCyKiCF",
                                "name": "geolad GmbH",
                                "policyUrl": "https://geolad.com/privacy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2947,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "retency-CLerZiGL",
                                "name": "RETENCY",
                                "policyUrl": "http://www.retency.com/stats/fr/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2966,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "illumatec-ChtEB4ek",
                                "name": "Illuma Technology Limited",
                                "policyUrl": "https://www.weareilluma.com/endddd",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 3078,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "adjustgmb-pccNdJBQ",
                                "name": "Adjust GmbH",
                                "policyUrl": "https://www.adjust.com/terms/gdpr/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 2822,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "adlightni-tWZGrehT",
                                "name": "Ad Lightning",
                                "policyUrl": "https://www.adlightning.com/privacy",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 3253,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "ignitiono-LVAMZdnj",
                                "name": "Ignition One",
                                "policyUrl": "https://www.ignitionone.com/privacy-policy/gdpr-subject-access-requests/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": [],
                                "namespaces": {
                                    "google": {
                                        "id": 338,
                                        "current": true
                                    }
                                }
                            }, {
                                "id": "undertone-TLjqdTpf",
                                "name": "Undertone",
                                "policyUrl": "https://www.undertone.com/privacy/",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "rockerbox-fTM8EJ9P",
                                "name": "Rockerbox",
                                "policyUrl": "https://www.rockerbox.com/privacy-shield",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }, {
                                "id": "affilinet",
                                "name": "affilinet",
                                "policyUrl": "https://www.affili.net/de/footeritem/datenschutz",
                                "purposeIds": ["cookies", "create_ads_profile", "select_personalized_ads"],
                                "legIntPurposeIds": ["improve_products", "market_research", "measure_ad_performance", "select_basic_ads"],
                                "usesNonCookieAccess": false,
                                "lang_urls": []
                            }],
                            "google": {
                                "fullATP": false
                            }
                        },
                        "privacyPolicyURL": "https://www.leboncoin.fr/dc/cookies/",
                        "essentialPurposes": ["necessaires"],
                        "gdprAppliesGlobally": true,
                        "gdprAppliesWhenUnknown": false,
                        "customPurposes": [{
                            "id": "experienceutilisateur",
                            "name": {
                                "en": "Amélioration de l'expérience utilisateur",
                                "fr": "Amélioration de l'expérience utilisateur"
                            },
                            "description": {
                                "en": "Ces cookies vous permettent de bénéficier d’une meilleure expérience sur notre site et nos applications en profitant d’améliorations génériques qui ne sont pas liées à votre profil ou de tester ces dernières. Ils nous permettent par exemple de conserver vos coordonnées pour pré-remplir le formulaire de contact.",
                                "fr": "Ces cookies vous permettent de bénéficier d’une meilleure expérience sur notre site et nos applications en profitant d’améliorations génériques qui ne sont pas liées à votre profil ou de tester ces dernières. Ils nous permettent par exemple de conserver vos coordonnées pour pré-remplir le formulaire de contact."
                            }
                        }, {
                            "id": "mesureaudience",
                            "name": {
                                "en": "Mesure d'audience",
                                "fr": "Mesure d'audience"
                            },
                            "description": {
                                "en": "Ces cookies servent à réaliser des statistiques pour mesurer et analyser l'audience de notre site et de nos applications (ex. fréquentation du site, nombre de pages vues, temps moyen par visite, etc.) et nous aident ainsi à améliorer la qualité de nos services.\n\nNous utilisons notamment AT Internet, un outil de mesure d’audience bénéficiant d’une exemption au consentement conformément aux exigences de la CNIL.  Pour en savoir plus, consultez nos politiques de confidentialité et cookies.",
                                "fr": "Ces cookies servent à réaliser des statistiques pour mesurer et analyser l'audience de notre site et de nos applications (ex. fréquentation du site, nombre de pages vues, temps moyen par visite, etc.) et nous aident ainsi à améliorer la qualité de nos services.\n\nNous utilisons notamment AT Internet, un outil de mesure d’audience bénéficiant d’une exemption au consentement conformément aux exigences de la CNIL.  Pour en savoir plus, consultez nos politiques de confidentialité et cookies."
                            }
                        }, {
                            "id": "necessaires",
                            "name": {
                                "en": "Nécessaires au fonctionnement du service",
                                "fr": "Nécessaires au fonctionnement du service"
                            },
                            "description": {
                                "en": "Ces cookies sont indispensables aux fonctionnalités essentielles du service et ne peuvent pas être désactivés. Il s’agit par exemple de conserver vos paramètres d’affichage ou encore la configuration de vos choix sur les cookies. Ils sont également utilisés pour vous fournir certaines fonctionnalités complémentaires lorsque vous les activez, par exemple enregistrer vos annonces et vos agences favorites sans être connecté.",
                                "fr": "Ces cookies sont indispensables aux fonctionnalités essentielles du service et ne peuvent pas être désactivés. Il s’agit par exemple de conserver vos paramètres d’affichage ou encore la configuration de vos choix sur les cookies. \n\nIls sont également utilisés pour vous fournir certaines fonctionnalités complémentaires lorsque vous les activez, par exemple enregistrer vos annonces et vos agences favorites sans être connecté."
                            }
                        }, {
                            "id": "personnalisationmarketing",
                            "name": {
                                "en": "Personnalisation des communications marketing",
                                "fr": "Personnalisation des communications marketing"
                            },
                            "description": {
                                "en": "Ces cookies vous permettent de bénéficier de communications marketing personnalisées par rapport à votre profil. ",
                                "fr": "Ces cookies vous permettent de bénéficier de communications marketing personnalisées par rapport à votre profil. "
                            }
                        }, {
                            "id": "prix",
                            "name": {
                                "en": "Offres promotionnelles personnalisées",
                                "fr": "Offres promotionnelles personnalisées"
                            },
                            "description": {
                                "en": "Ces cookies sont susceptibles de vous faire bénéficier d’offres promotionnelles personnalisées selon votre profil.",
                                "fr": "Ces cookies sont susceptibles de vous faire bénéficier d’offres promotionnelles personnalisées selon votre profil."
                            }
                        }],
                        "apiKey": "758b10ac-a0a7-421d-b3a2-f77eaa2897e8",
                        "deploymentId": "3pRgmgEE",
                        "consentDuration": 15811200
                    },
                    "user": {
                        "bots": {
                            "consentRequired": false
                        }
                    },
                    "theme": {
                        "css": "#didomi-notice {\n    border-top: .2rem solid #e6ebef !important;\n}\n#didomi-notice .didomi-notice-data-processing-container{\n    display: none;\n}\n#didomi-notice #buttons {\n    flex-direction: column-reverse !important;\n    align-items: stretch !important;\n}\n\n#didomi-notice #buttons .didomi-dismiss-button {\n    margin-bottom: 1.5rem !important;\n    text-decoration: none !important;\n}\n\n#didomi-notice #buttons .didomi-dismiss-button:hover {\n    background-color: #369 !important;\n    border-color: #369 !important;\n}\n\n\n#didomi-notice #buttons .didomi-learn-more-button {\n    background-color: #ffffff !important;\n    border-color: #4183d7 !important;\n    color: #4183d7 !important;\n}\n\n#didomi-notice #buttons .didomi-learn-more-button:hover {\n    color: #369 !important;\n    background-color: rgba(51,102,153,.1) !important;\n    border-color: #369 !important;\n}\n\n#didomi-notice #buttons button {\n    border-radius: 4px !important;\n    padding: 0.5rem 2rem !important;\n    font-size: 14px !important;\n    margin-right: 0 !important;\n    min-height: 4rem!important;\n    box-sizing: border-box!important;\n}\n\n#didomi-notice .didomi-notice__interior-border {\n    max-width: 1066px!important;\n    margin: 0 auto!important;\n}\n\n#didomi-notice .didomi-notice__interior-border #text {\n    font-size: 1.1rem !important;\n}\n\n#didomi-host .didomi-consent-popup__backdrop {\n    background: rgba(0,0,0,0.7) !important;\n}\n\n#didomi-host .didomi-consent-popup__exterior-border {\n    border: none !important;\n}\n\n#didomi-host .didomi-consent-popup__dialog {\n    border: none !important;\n    border-radius: 0 !important;\n}\n\n#didomi-consent-popup .didomi-consent-popup-actions button {\n    border-radius: 4px !important;\n    padding: 0.5rem 2rem !important;\n    font-size: 14px !important;\n    min-height: 4rem!important;\n    box-sizing: border-box!important;\n}\n\n#didomi-host button span,\n#didomi-host .didomi-no-link-style span {\n    pointer-events: none !important;\n}\n\n#didomi-consent-popup .didomi-consent-popup-actions .didomi-button-standard {\n    background-color: #ffffff !important;\n    border-color: #4183d7 !important;\n    color: #4183d7 !important;\n}\n\n#didomi-consent-popup .didomi-consent-popup-actions .didomi-button-standard:hover {\n    color: #369 !important;\n    background-color: rgba(51,102,153,.1) !important;\n    border-color: #369 !important;\n}\n\n#didomi-host #didomi-notice a {\n    color: #4183d7 !important;\n    text-decoration: none !important;\n}\n\n#didomi-host #didomi-notice a:hover {\n    color: #369 !important;\n    text-decoration: underline !important;\n}\n\n#didomi-host .didomi-components-radio__option {\n    border-radius: 3px!important;\n    box-shadow: none!important;\n}\n\n#didomi-host .didomi-components-radio__option.didomi-components-radio__option--agree {\n    background-color: #f56b2a!important;\n    border-color: #f56b2a!important;\n}\n\n#didomi-host .didomi-components-radio__option.didomi-components-radio__option--disagree {\n    background-color: #cad1d9!important;\n    border-color: #cad1d9!important;\n}\n\n#didomi-host button.didomi-consent-popup-view-vendors-list-link {\n    border-color: #4083d7!important;\n    color: #4083d7!important;\n    border-radius: 4px!important;\n    box-shadow: none!important;\n}\n\n#didomi-host button.didomi-consent-popup-view-vendors-list-link:hover {\n    border-color: #369!important;\n    background-color: rgba(51,102,153,.1) !important;\n    color: #369!important;\n}\n\n#didomi-host button.didomi-components-button.didomi-button.didomi-components-button--color.didomi-button-highlight:hover {\n    border-color: #369!important;\n    background-color: #369!important;\n}\n\n#didomi-host .didomi-consent-popup-body .didomi-consent-popup-body__explanation a {\n    text-decoration: none !important;\n}\n\n#didomi-host .didomi-consent-popup-body .didomi-consent-popup-body__explanation a:hover {\n    text-decoration: underline !important;\n    color: #369!important;\n}\n\n#didomi-host #didomi-notice.didomi-regular-notice.shape-banner {\n    padding: 2em 1em !important;\n}\n\n.didomi-screen-small .didomi-notice__interior-border.didomi-border,\n.didomi-screen-xsmall .didomi-notice__interior-border.didomi-border {\n    border-top: none!important;\n}\n\n#didomi-host .didomi-screen-small #didomi-notice.didomi-regular-notice.shape-banner,\n#didomi-host .didomi-screen-xsmall #didomi-notice.didomi-regular-notice.shape-banner {\n    padding: 0em !important;\n}\n\n#didomi-host .didomi-consent-popup-footer.didomi-popup-footer img[alt=\"\"Logo Didomi\"\"] {\n    display: none;\n}\n\n.didomi-screen-small #didomi-notice #buttons.didomi-buttons {\n    flex-direction: row !important;\n}\n\n.didomi-screen-small #didomi-notice #buttons .didomi-dismiss-button {\n    margin-bottom: 0!important;\n}\n\n.didomi-screen-small #didomi-notice #buttons .didomi-button {\n    max-width: 150px;\n    margin: 0 1rem;\n}\n#didomi-host .didomi-popup-container {\n    border-color: transparent !important;\n}\n#didomi-host .didomi-exterior-border {\n    border-color: rgba(51,102,153,.1)!important;\n}\n\n#didomi-host #buttons > #didomi-notice-learn-more-button {\n    color: #fff !important;\n    background: rgb(65, 131, 215) !important;\n    border-color: rgba(65, 131, 215, 0.3) !important;\n}\n\n#didomi-host #buttons > #didomi-notice-learn-more-button:hover {\n    border-color: #369!important;\n    background-color: #369!important;\n}\n\n.didomi-continue-without-agreeing:before {\n    content: \"Continuer sans accepter\";\n    font-size: 14px;\n}\n\n.didomi-continue-without-agreeing {\n    position: absolute;\n    top: 130px;\n    min-width: 20px;\n    color: rgb(65, 131, 215) !important;\n    border: none!important;\n    border-radius: 0px;\n    background: transparent !important;\n    background-color: transparent !important;\n    display: inline;\n    border-color: none !important;\n    border-width: 0  !important;\n    padding-left: 0px !important;\n    padding-right: 0px !important;\n    margin-right: 0!important;\n    font-weight: 700!important;\n    margin-bottom: 0!important;\n    font-size: 0!important;\n    left: 0;\n    right: 0;\n    text-align: center;\n\n    /* TEST POPUP 2 */\n    text-decoration: none;\n}\n\n.didomi-mobile .didomi-continue-without-agreeing {\n    top: 100px;\n}\n\n#didomi-host #buttons > #didomi-notice-disagree-button span {\n    display: flex;\n    padding: 0 5px;\n}\n\n#didomi-host #buttons > #didomi-notice-disagree-button:focus {\n    outline: 0;\n    box-shadow:none;\n}\n\n#didomi-host #buttons > #didomi-notice-disagree-button:focus span {\n    outline: 1px auto #4d90fe;\n}\n\n/* #didomi-host #buttons > #didomi-notice-learn-more-button {\n    background-color: rgb(65, 131, 215) !important;\n    color: #fff !important;\n    border-color: rgba(65, 131, 215, 0.3) !important;\n}\n\n#didomi-host #buttons > #didomi-notice-learn-more-button:hover {\n    border-color: #369!important;\n    background-color: #369!important;\n} */\n\n/*\n#didomi-host #buttons > #didomi-notice-disagree-button::before {\n    display: block;\n    position: relative;\n    width: 16px;\n    height: 16px;\n  background-image: url(\"\"data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDYuMC1jMDAyIDc5LjE2NDQ2MCwgMjAyMC8wNS8xMi0xNjowNDoxNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDIxLjIgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjQwREIxQkMwMjVCNzExRUI4REZGQ0Q0NjQ3M0E3RjM5IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjQwREIxQkMxMjVCNzExRUI4REZGQ0Q0NjQ3M0E3RjM5Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NDBEQjFCQkUyNUI3MTFFQjhERkZDRDQ2NDczQTdGMzkiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NDBEQjFCQkYyNUI3MTFFQjhERkZDRDQ2NDczQTdGMzkiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7UG9NOAAAA+ElEQVR42oyTPQvCMBCGL0dFRZGCGATpL3Do4lDBqX/ZWVedBAcnB4cqaEX8RkUh5gpC1TTXQCC9u+e9tu9FTGZztVhuIAx86daqW8ixDqdLYziexrLuAq7WO3g+X6ADESVywhExh+MFsNdpy4LjPHSgyImk4CIxxCK9dtj1PU7kFyaGWKQkJ5IFU04opb67jHThSxcWdGHgexTPgv8EDCJJjH6YCTYKpERiLZI8axg0bLQZM/0SGWdOIO0zdaZtmxNkrJK0bRYjZxVnMXI+c3Mi9sezFbZYnMyJ6A/G6nq7AwebRCrlEmCrWf/47OW5zqnPAWLfAgwAM0koeSKKem4AAAAASUVORK5CYII=\"\"); background-repeat :no-repeat;\n  background-position:  center center;\n  font-size: 20px;\n}\n#didomi-host #buttons > #didomi-notice-disagree-button > span {\n    display: none;\n}*/\n#didomi-host #buttons {\n    margin-bottom: 15px !important;\n}\n#didomi-host .didomi-popup-notice .didomi-popup-notice-logo{\n    margin-bottom: 15px;\n    width: 100% !important;\n    max-width: 200px;\n}\n\n@media screen and (min-width: 599px) and (min-width:1022px) {\n    #didomi-host #buttons {\n        margin-bottom: 15px !important;\n    }\n}\n\n@media screen and (min-width: 481px) and (max-width: 600px) {\n    .didomi-screen-xsmall #didomi-notice #buttons.didomi-buttons {\n        flex-direction: row !important;\n    }\n\n    .didomi-screen-xsmall #didomi-notice #buttons .didomi-dismiss-button {\n        margin-bottom: 0!important;\n    }\n\n    .didomi-screen-xsmall #didomi-notice #buttons .didomi-button {\n        max-width: 150px;\n        margin: 0 1rem;\n    }\n\n    #didomi-host .didomi-screen-xsmall #didomi-notice.didomi-regular-notice #buttons.multiple button {\n        margin: 0 1rem;\n    }\n}\n\n@media screen and (max-width: 1024px) {\n    #didomi-host #buttons > #didomi-notice-disagree-button {\n        bottom: 0px;\n        left: 7px;\n    }\n}\n\n@media screen and (max-width: 598px) {\n    #didomi-host #buttons > #didomi-notice-disagree-button {\n        margin-top: 0 !important;\n    }\n}\n\n#didomi-host {\n    -webkit-tap-highlight-color: transparent!important;\n    -webkit-text-stroke-color: transparent!important;\n}\n\n#didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-footer .didomi-consent-popup-actions:not(.didomi-buttons-all) {\n    align-items: flex-end;\n}\n\n/* To fix issue on scroll for IOS webview */\n.didomi-popup-open.didomi-popup-open-ios {\n    position: initial;\n    overflow: auto!important;\n}\n#didomi-host #didomi-vendor-liveramp .didomi-vendors-iab-label {\n\n   display: none !important;\n\n}\n#didomi-host #didomi-vendor-97 .didomi-vendors-iab-label {\n\n   display: none !important;\n\n}",
                        "font": "Open Sans, Arial, sans-serif",
                        "color": "#4183d7",
                        "linkColor": "#4183d7"
                    },
                    "notice": {
                        "content": {
                            "popup": {
                                "fr": "<p style=\"text-align: justify;\"> Pour leboncoin, votre expérience sur notre site est une priorité. C'est pourquoi nous utilisons des cookies et autres traceurs pour vous fournir notre service, le personnaliser, en mesurer l’audience et améliorer votre expérience.<br> Sur la base de votre consentement des informations liées à votre navigation sur notre site (telle que l’IP, les pages visitées etc.) sont stockées et/ou lues sur votre terminal  par leboncoin et ses <a href=\"javascript:Didomi.preferences.show('vendors')\">{numberOfPartners} partenaires</a>, ces derniers pouvant également associer ces informations à vos données personnelles sur la base de votre consentement ou de leur intérêt légitime, auquel vous pouvez vous opposer en cliquant sur le bouton « Personnaliser »,  afin de diffuser des publicités personnalisées, mesurer leurs performances, obtenir des données d'audience en lien avec cette publicité et développer et améliorer les produits.<br>En cliquant sur “Accepter”, vous consentez à l’utilisation de cookies pour l’ensemble des finalités ci-dessus. Vous pouvez également configurer vos choix finalité par finalité en cliquant sur “Personnaliser” ou refuser en cliquant sur \"Continuer sans accepter\". Vous pouvez changer d'avis à tout moment en cliquant sur <a id=\"vpc_ma\" href=\"{privacyPolicyURL}\" target=\"_blank\" style=\"text-decoration:none;\">Vie privée & cookies</a> figurant en bas de chaque page. </p>"
                            }
                        },
                        "position": "popup",
                        "closeOnClick": true,
                        "closeOnScroll": false,
                        "showDataProcessing": false,
                        "closeOnScrollThreshold": 0,
                        "daysBeforeShowingAgain": 183,
                        "closeOnScrollThresholdType": "",
                        "closeOnClickNavigationDelay": 0,
                        "enableBulkActionOnPurposes": true,
                        "type": "optin",
                        "denyOptions": {
                            "link": true,
                            "cross": false,
                            "button": "none"
                        },
                        "denyAsLink": true,
                        "denyAppliesToLI": true
                    },
                    "languages": {
                        "default": "fr",
                        "enabled": ["fr"]
                    },
                    "preferences": {
                        "content": {
                            "text": {
                                "fr": "<p align=\"justify\">Lorsque vous utilisez notre service, des informations sont collectées grâce à des cookies et autres traceurs. Nous utilisons ces informations pour les finalités détaillées ci-dessous. Vous pouvez avoir plus d'informations en cliquant sur chaque finalité et faire votre choix par finalité, à l’exception des traceurs nécessaires au bon fonctionnement de notre service. \n<br/><br/>Par ailleurs, nous et nos partenaires utilisons des cookies à des fins de publicité personnalisée dans le cadre du standard de transparence et de consentement proposé par l’Interactive Advertising Bureau (<a id=\"vpc_ma\" href=\"https://www.iabfrance.com/article/iab-france\" target=\"_blank\" style=\"text-decoration:none;\">IAB</a>). Certains de ces partenaires ont choisi de traiter vos données sur la base de leur intérêt légitime, vous pouvez vous opposer par finalité.\n<br/><br/>Vos choix sont exclusivement valables sur le navigateur que vous utilisez actuellement. Si vous supprimez vos cookies, nous ne serons plus en mesure de connaître vos choix et vous solliciterons à nouveau. Pour en savoir plus sur l’utilisation des cookies et de vos données personnelles lors de votre utilisation du service, consultez notre page <a id=\"vpc_ma\" href=\"{privacyPolicyURL}\" target=\"_blank\" style=\"text-decoration:none;\">Vie privée & cookies</a>.</p>"
                            },
                            "title": {
                                "fr": "Vos choix concernant les cookies"
                            },
                            "textVendors": {
                                "fr": "Vous pouvez définir vos préférences de consentement pour chaque partenaire listé ci-dessous individuellement. Cliquez sur le nom d'un partenaire pour obtenir plus d'informations sur les données collectées et leurs utilisations. Certains partenaires utilisent les données sur la base de leur intérêt légitime, vous pouvez refuser ces utilisations en exerçant votre droit d’opposition."
                            }
                        },
                        "categories": [{
                            "type": "purpose",
                            "purposeId": "necessaires"
                        }, {
                            "type": "purpose",
                            "purposeId": "mesureaudience"
                        }, {
                            "type": "purpose",
                            "purposeId": "experienceutilisateur"
                        }, {
                            "id": "2fFFcc",
                            "name": {
                                "en": "Personnalisation des offres et communications marketing",
                                "fr": "Personnalisation des offres et communications marketing"
                            },
                            "type": "category",
                            "children": [{
                                "type": "purpose",
                                "purposeId": "prix"
                            }, {
                                "type": "purpose",
                                "purposeId": "personnalisationmarketing"
                            }],
                            "expanded": false,
                            "description": {
                                "en": "Ces cookies vous permettent de bénéficier de communications et/ou d'offres promotionnelles adaptées à votre profil, votre navigation, vos centres d’intérêts et vos usages de notre service. \n",
                                "fr": "Ces cookies vous permettent de bénéficier de communications et/ou d'offres promotionnelles adaptées à votre profil, votre navigation, vos centres d’intérêts et vos usages de notre service. "
                            }
                        }, {
                            "id": "qB2C83",
                            "name": {
                                "en": "Publicité personnalisée",
                                "fr": "Publicité personnalisée"
                            },
                            "type": "category",
                            "children": [{
                                "type": "purpose",
                                "purposeId": "cookies"
                            }, {
                                "type": "purpose",
                                "purposeId": "geolocation_data"
                            }, {
                                "type": "purpose",
                                "purposeId": "device_characteristics"
                            }, {
                                "type": "purpose",
                                "purposeId": "select_basic_ads"
                            }, {
                                "type": "purpose",
                                "purposeId": "create_ads_profile"
                            }, {
                                "type": "purpose",
                                "purposeId": "select_personalized_ads"
                            }, {
                                "type": "purpose",
                                "purposeId": "measure_ad_performance"
                            }, {
                                "type": "purpose",
                                "purposeId": "create_content_profile"
                            }, {
                                "type": "purpose",
                                "purposeId": "select_personalized_content"
                            }, {
                                "type": "purpose",
                                "purposeId": "measure_content_performance"
                            }, {
                                "type": "purpose",
                                "purposeId": "market_research"
                            }, {
                                "type": "purpose",
                                "purposeId": "improve_products"
                            }],
                            "expanded": false,
                            "description": {
                                "en": "Nous et nos partenaires utilisons des cookies à des fins de publicité personnalisée dans le cadre du standard de transparence et de consentement proposé par l’Interactive Advertising Bureau (<a id=\"vpc_ma\" href=\"https://www.iabfrance.com/article/iab-france\" target=\"_blank\" style=\"text-decoration:none;\">IAB</a>). Des informations peuvent également être utilisées pour des études de marchés sur les audiences qui ont vu les publicités. Enfin, les données peuvent être utilisées pour améliorer les systèmes et logiciels existants et pour développer de nouveaux produits.",
                                "fr": "Nous et nos partenaires utilisons des cookies à des fins de publicité personnalisée dans le cadre du standard de transparence et de consentement proposé par l’Interactive Advertising Bureau (<a id=\"vpc_ma\" href=\"https://www.iabfrance.com/article/iab-france\" target=\"_blank\" style=\"text-decoration:none;\">IAB</a>). Des informations peuvent également être utilisées pour des études de marchés sur les audiences qui ont vu les publicités. Enfin, les données peuvent être utilisées pour améliorer les systèmes et logiciels existants et pour développer de nouveaux produits."
                            }
                        }, {
                            "type": "purpose",
                            "purposeId": "use_limited_data_to_select_content"
                        }],
                        "showWhenConsentIsMissing": false,
                        "denyAppliesToLI": true
                    },
                    "regulations": {},
                    "integrations": {
                        "vendors": {
                            "google": {
                                "enable": false,
                                "refresh": true,
                                "eprivacy": false,
                                "passTargetingVariables": false
                            },
                            "salesforce-dmp": {
                                "enable": false,
                                "namespace": null
                            },
                            "refreshOnConsent": false
                        }
                    },
                    "regulation": {
                        "name": "gdpr",
                        "group": {
                            "name": "optin"
                        }
                    },
                    "version": "1.0.0"
                }
            }]
        }
    } catch (o) {
        console.error("Didomi - Invalid remote config")
    }
}();
! function() {
    try {
        window.didomiCountry = "IN", window.didomiRegion = "TN", window.didomiGeoRegulations = ["gdpr"]
    } catch (o) {
        console.error("Didomi - Invalid country")
    }
}();
! function() {
    var e, t = {
            908: function(e) {
                e.exports = function e(t) {
                    var d = "noModule" in HTMLScriptElement.prototype,
                        i = t.didomiOnLoad ? "54107da99f32815551f74076e6e6a61678ef4609" : "7e0e4e88d0225db89a578b31aa627050b4ce1e0d",
                        n = t.document.getElementsByTagName("head");
                    if (n.length > 0) {
                        var o = t.document.createElement("link");
                        o.rel = "preload", o.as = "script";
                        var r = t.document.createElement("script"),
                            a = t.didomiConfig && t.didomiConfig.sdkPath ? t.didomiConfig.sdkPath : "https://sdk.privacy-center.org/",
                            s = t.didomiOnLoad ? "" : d ? "sdk/" + i + "/modern/" : "sdk/" + i + "/legacy/";
                        r.type = "text/javascript", r.async = !0;
                        var c = a + s + "sdk." + i + ".js";
                        o.href = c, r.src = c, r.charset = "utf-8";
                        var p = n[0];
                        p.appendChild(o), p.appendChild(r)
                    } else setTimeout(e.bind(this, t), 5)
                }
            }
        },
        d = {};

    function i(e) {
        var n = d[e];
        if (void 0 !== n) return n.exports;
        var o = d[e] = {
            exports: {}
        };
        return t[e](o, o.exports, i), o.exports
    }
    e = i(908), window.Didomi || e(window)
}();