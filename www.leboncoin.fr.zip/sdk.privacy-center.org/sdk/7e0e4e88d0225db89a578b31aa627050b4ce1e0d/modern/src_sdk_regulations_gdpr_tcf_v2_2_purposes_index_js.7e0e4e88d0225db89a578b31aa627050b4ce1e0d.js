"use strict";
(self.webpackChunkDidomi = self.webpackChunkDidomi || []).push([
    ["src_sdk_regulations_gdpr_tcf_v2_2_purposes_index_js"], {
        94712: function(i, s, e) {
            e.r(s), e.d(s, {
                iabFeatures: function() {
                    return c
                },
                iabPurposesDidomiIdMap: function() {
                    return n
                },
                iabSpecialPurposes: function() {
                    return p
                },
                iabStacks: function() {
                    return o
                },
                purposes: function() {
                    return a
                },
                specialFeatures: function() {
                    return r
                }
            });
            var _ = JSON.parse('{"purposes":[{"id":1,"name":"purpose_1_name","description":"purpose_1_description","illustrations":["purpose_1_illustrations_0"]},{"id":2,"name":"purpose_2_name","description":"purpose_2_description","illustrations":["purpose_2_illustrations_0","purpose_2_illustrations_1"]},{"id":3,"name":"purpose_3_name","description":"purpose_3_description","illustrations":["purpose_3_illustrations_0","purpose_3_illustrations_1"]},{"id":4,"name":"purpose_4_name","description":"purpose_4_description","illustrations":["purpose_4_illustrations_0","purpose_4_illustrations_1"]},{"id":5,"name":"purpose_5_name","description":"purpose_5_description","illustrations":["purpose_5_illustrations_0","purpose_5_illustrations_1"]},{"id":6,"name":"purpose_6_name","description":"purpose_6_description","illustrations":["purpose_6_illustrations_0","purpose_6_illustrations_1"]},{"id":7,"name":"purpose_7_name","description":"purpose_7_description","illustrations":["purpose_7_illustrations_0","purpose_7_illustrations_1"]},{"id":8,"name":"purpose_8_name","description":"purpose_8_description","illustrations":["purpose_8_illustrations_0","purpose_8_illustrations_1"]},{"id":9,"name":"purpose_9_name","description":"purpose_9_description","illustrations":["purpose_9_illustrations_0","purpose_9_illustrations_1"]},{"id":10,"name":"purpose_10_name","description":"purpose_10_description","illustrations":["purpose_10_illustrations_0","purpose_10_illustrations_1"]},{"id":11,"name":"purpose_11_name","description":"purpose_11_description","illustrations":["purpose_11_illustrations_0","purpose_11_illustrations_1"]}],"specialPurposes":[{"id":1,"name":"special_purpose_1_name","description":"special_purpose_1_description","illustrations":["special_purpose_1_illustrations_0"]},{"id":2,"name":"special_purpose_2_name","description":"special_purpose_2_description","illustrations":["special_purpose_2_illustrations_0"]}],"features":[{"id":1,"name":"feature_1_name","description":"feature_1_description","illustrations":[]},{"id":2,"name":"feature_2_name","description":"feature_2_description","illustrations":[]},{"id":3,"name":"feature_3_name","description":"feature_3_description","illustrations":[]}],"specialFeatures":[{"id":1,"name":"special_feature_1_name","description":"special_feature_1_description","illustrations":[]},{"id":2,"name":"special_feature_2_name","description":"special_feature_2_description","illustrations":[]}],"stacks":[{"id":1,"name":"stack_1_name","description":"stack_1_description"},{"id":2,"name":"stack_2_name","description":"stack_2_description"},{"id":3,"name":"stack_3_name","description":"stack_3_description"},{"id":4,"name":"stack_4_name","description":"stack_4_description"},{"id":5,"name":"stack_5_name","description":"stack_5_description"},{"id":6,"name":"stack_6_name","description":"stack_6_description"},{"id":7,"name":"stack_7_name","description":"stack_7_description"},{"id":8,"name":"stack_8_name","description":"stack_8_description"},{"id":9,"name":"stack_9_name","description":"stack_9_description"},{"id":10,"name":"stack_10_name","description":"stack_10_description"},{"id":11,"name":"stack_11_name","description":"stack_11_description"},{"id":12,"name":"stack_12_name","description":"stack_12_description"},{"id":13,"name":"stack_13_name","description":"stack_13_description"},{"id":14,"name":"stack_14_name","description":"stack_14_description"},{"id":15,"name":"stack_15_name","description":"stack_15_description"},{"id":16,"name":"stack_16_name","description":"stack_16_description"},{"id":17,"name":"stack_17_name","description":"stack_17_description"},{"id":18,"name":"stack_18_name","description":"stack_18_description"},{"id":19,"name":"stack_19_name","description":"stack_19_description"},{"id":20,"name":"stack_20_name","description":"stack_20_description"},{"id":21,"name":"stack_21_name","description":"stack_21_description"},{"id":22,"name":"stack_22_name","description":"stack_22_description"},{"id":23,"name":"stack_23_name","description":"stack_23_description"},{"id":24,"name":"stack_24_name","description":"stack_24_description"},{"id":25,"name":"stack_25_name","description":"stack_25_description"},{"id":26,"name":"stack_26_name","description":"stack_26_description"},{"id":27,"name":"stack_27_name","description":"stack_27_description"},{"id":28,"name":"stack_28_name","description":"stack_28_description"},{"id":29,"name":"stack_29_name","description":"stack_29_description"},{"id":30,"name":"stack_30_name","description":"stack_30_description"},{"id":31,"name":"stack_31_name","description":"stack_31_description"},{"id":32,"name":"stack_32_name","description":"stack_32_description"},{"id":33,"name":"stack_33_name","description":"stack_33_description"},{"id":34,"name":"stack_34_name","description":"stack_34_description"},{"id":35,"name":"stack_35_name","description":"stack_35_description"},{"id":36,"name":"stack_36_name","description":"stack_36_description"},{"id":37,"name":"stack_37_name","description":"stack_37_description"},{"id":38,"name":"stack_38_name","description":"stack_38_description"},{"id":39,"name":"stack_39_name","description":"stack_39_description"},{"id":40,"name":"stack_40_name","description":"stack_40_description"},{"id":41,"name":"stack_41_name","description":"stack_41_description"},{"id":42,"name":"stack_42_name","description":"stack_42_description"},{"id":43,"name":"stack_43_name","description":"stack_43_description"}]}'),
                t = e(16619),
                n = _.purposes.map((i => {
                    var {
                        id: s
                    } = i;
                    return {
                        [t.oM[s]]: s
                    }
                })).reduce(((i, s) => Object.assign(i, s)), {}),
                {
                    purposes: a,
                    specialFeatures: r,
                    specialPurposes: p,
                    features: c,
                    stacks: o
                } = _
        }
    }
]);