/*! For license information please see sdk.7e0e4e88d0225db89a578b31aa627050b4ce1e0d.js.LICENSE.txt */ ! function() {
    var e, t, s, i, n = {
            86119: function(e, t, s) {
                var i = function() {
                    function e(e, t) {
                        for (var s = 0; s < t.length; s++) {
                            var i = t[s];
                            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, s, i) {
                        return s && e(t.prototype, s), i && e(t, i), t
                    }
                }();
                var n = s(97501),
                    r = function() {
                        function e(t) {
                            ! function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, e), t = t || {}, this.issuer = t.issuer || null, this.user_id = t.user_id || null, this.user_id_type = t.user_id_type || null, this.user_id_hash_method = t.user_id_hash_method || null, this.consents = t.consents || [], this.version = 1
                        }
                        return i(e, [{
                            key: "toObject",
                            value: function() {
                                return {
                                    issuer: this.issuer,
                                    user_id: this.user_id,
                                    user_id_type: this.user_id_type,
                                    user_id_hash_method: this.user_id_hash_method,
                                    consents: this.consents,
                                    version: this.version
                                }
                            }
                        }, {
                            key: "toJSON",
                            value: function() {
                                return JSON.stringify(this.toObject())
                            }
                        }, {
                            key: "toCompressedJSON",
                            value: function() {
                                var e = this.toObject(),
                                    t = {
                                        issuer: e.issuer,
                                        user_id: e.user_id,
                                        user_id_type: e.user_id_type,
                                        user_id_hash_method: e.user_id_hash_method,
                                        version: e.version,
                                        purposes: {
                                            enabled: [],
                                            disabled: []
                                        },
                                        vendors: {
                                            enabled: [],
                                            disabled: []
                                        }
                                    },
                                    s = {},
                                    i = {};
                                for (var n in e.consents)
                                    if (e.consents.hasOwnProperty(n)) {
                                        var r = e.consents[n],
                                            o = r.purpose,
                                            a = r.vendors;
                                        i[o] = {};
                                        var u = !0;
                                        for (var d in a)
                                            if (a.hasOwnProperty(d)) {
                                                var l = a[d];
                                                u = u && !1 === l.status, s[l.id] || (s[l.id] = {
                                                    id: l.id,
                                                    purposes: {}
                                                }), s[l.id].purposes[o] = l.status, i[o][l.id] = l.status
                                            }
                                        u ? t.purposes.disabled.push(o) : t.purposes.enabled.push(o)
                                    }
                                var p = Object.keys(s);
                                for (var c in p)
                                    if (p.hasOwnProperty(c)) {
                                        var f = p[c],
                                            v = !0;
                                        for (var h in t.purposes.enabled)
                                            if (t.purposes.enabled.hasOwnProperty(h)) {
                                                var g = t.purposes.enabled[h];
                                                v = v && !0 === s[f].purposes[g]
                                            }
                                        v ? t.vendors.enabled.push(s[f].id) : t.vendors.disabled.push(s[f].id)
                                    }
                                return JSON.stringify(t)
                            }
                        }, {
                            key: "toBase64",
                            value: function() {
                                return n.encode(this.toJSON())
                            }
                        }, {
                            key: "toCompressedBase64",
                            value: function() {
                                return n.encode(this.toCompressedJSON())
                            }
                        }, {
                            key: "setConsentStatus",
                            value: function(e, t, s) {
                                var i = this.consents.find((function(e) {
                                    return e.purpose === t
                                }));
                                i || (i = {
                                    purpose: t,
                                    vendors: []
                                }, this.consents.push(i));
                                var n = i.vendors.find((function(e) {
                                    return e.id === s
                                }));
                                n || (n = {
                                    id: s,
                                    status: void 0
                                }, i.vendors.push(n)), n.status = e
                            }
                        }, {
                            key: "getConsentStatus",
                            value: function(e, t) {
                                var s = this.consents.find((function(t) {
                                    return t.purpose === e
                                }));
                                if (s) {
                                    var i = s.vendors.find((function(e) {
                                        return e.id === t
                                    }));
                                    if (i) return i.status;
                                    var n = s.vendors.find((function(e) {
                                        return "*" === e.id
                                    }));
                                    if (n) return n.status
                                }
                            }
                        }]), e
                    }();

                function o(e) {
                    if (!e) return null;
                    var t = void 0;
                    try {
                        t = JSON.parse(e)
                    } catch (e) {
                        return null
                    }
                    return t.purposes || t.vendors ? null : new r(t)
                }

                function a(e) {
                    if (!e) return null;
                    var t = void 0;
                    try {
                        t = JSON.parse(e)
                    } catch (e) {
                        return null
                    }
                    if (t.consents || !t.purposes || !t.vendors || !t.purposes.enabled || !t.purposes.disabled || !t.vendors.enabled || !t.vendors.disabled) return null;
                    var s = new r({
                        issuer: t.issuer,
                        user_id: t.user_id,
                        user_id_type: t.user_id_type,
                        user_id_hash_method: t.user_id_hash_method,
                        consents: [],
                        version: t.version
                    });
                    for (var i in t.purposes.enabled)
                        if (t.purposes.enabled.hasOwnProperty(i)) {
                            var n = t.purposes.enabled[i];
                            for (var o in t.vendors.enabled)
                                if (t.vendors.enabled.hasOwnProperty(o)) {
                                    var a = t.vendors.enabled[o];
                                    s.setConsentStatus(!0, n, a)
                                }
                            for (var u in t.vendors.disabled)
                                if (t.vendors.disabled.hasOwnProperty(u)) {
                                    var d = t.vendors.disabled[u];
                                    s.setConsentStatus(!1, n, d)
                                }
                        }
                    for (var l in t.purposes.disabled)
                        if (t.purposes.disabled.hasOwnProperty(l)) {
                            var p = t.purposes.disabled[l];
                            for (var c in t.vendors.enabled)
                                if (t.vendors.enabled.hasOwnProperty(c)) {
                                    var f = t.vendors.enabled[c];
                                    s.setConsentStatus(!1, p, f)
                                }
                            for (var v in t.vendors.disabled)
                                if (t.vendors.disabled.hasOwnProperty(v)) {
                                    var h = t.vendors.disabled[v];
                                    s.setConsentStatus(!1, p, h)
                                }
                        }
                    return s
                }
                e.exports = {
                    CWT: r,
                    CWTFromBase64: function(e) {
                        if (!e) return null;
                        try {
                            return o(n.decode(e))
                        } catch (e) {
                            return null
                        }
                    },
                    CWTFromCompressedBase64: function(e) {
                        if (!e) return null;
                        try {
                            return a(n.decode(e))
                        } catch (e) {
                            return null
                        }
                    },
                    CWTFromJSON: o,
                    CWTFromCompressedJSON: a,
                    Purposes: {
                        Cookies: "cookies",
                        CookiesAnalytics: "cookies_analytics",
                        CookiesMarketing: "cookies_marketing",
                        CookiesSocial: "cookies_social",
                        AdvertisingPersonalization: "advertising_personalization",
                        Analytics: "analytics",
                        ContentPersonalization: "content_personalization",
                        DeviceAccess: "device_access",
                        OfflineMatch: "offline_match",
                        LinkDevices: "link_devices",
                        PreciseGeo: "precise_geo"
                    }
                }
            },
            35618: function(e, t, s) {
                "use strict";

                function i() {
                    throw new Error("Cycle detected")
                }

                function n() {
                    if (a > 1) a--;
                    else {
                        for (var e, t = !1; void 0 !== o;) {
                            var s = o;
                            for (o = void 0, u++; void 0 !== s;) {
                                var i = s.o;
                                if (s.o = void 0, s.f &= -3, !(8 & s.f) && f(s)) try {
                                    s.c()
                                } catch (s) {
                                    t || (e = s, t = !0)
                                }
                                s = i
                            }
                        }
                        if (u = 0, a--, t) throw e
                    }
                }
                s.d(t, {
                    Fl: function() {
                        return m
                    },
                    MZ: function() {
                        return p
                    },
                    cE: function() {
                        return w
                    },
                    td: function() {
                        return c
                    }
                });
                var r = void 0;
                var o = void 0,
                    a = 0,
                    u = 0,
                    d = 0;

                function l(e) {
                    if (void 0 !== r) {
                        var t = e.n;
                        if (void 0 === t || t.t !== r) return t = {
                            i: 0,
                            S: e,
                            p: r.s,
                            n: void 0,
                            t: r,
                            e: void 0,
                            x: void 0,
                            r: t
                        }, void 0 !== r.s && (r.s.n = t), r.s = t, e.n = t, 32 & r.f && e.S(t), t;
                        if (-1 === t.i) return t.i = 0, void 0 !== t.n && (t.n.p = t.p, void 0 !== t.p && (t.p.n = t.n), t.p = r.s, t.n = void 0, r.s.n = t, r.s = t), t
                    }
                }

                function p(e) {
                    this.v = e, this.i = 0, this.n = void 0, this.t = void 0
                }

                function c(e) {
                    return new p(e)
                }

                function f(e) {
                    for (var t = e.s; void 0 !== t; t = t.n)
                        if (t.S.i !== t.i || !t.S.h() || t.S.i !== t.i) return !0;
                    return !1
                }

                function v(e) {
                    for (var t = e.s; void 0 !== t; t = t.n) {
                        var s = t.S.n;
                        if (void 0 !== s && (t.r = s), t.S.n = t, t.i = -1, void 0 === t.n) {
                            e.s = t;
                            break
                        }
                    }
                }

                function h(e) {
                    for (var t = e.s, s = void 0; void 0 !== t;) {
                        var i = t.p; - 1 === t.i ? (t.S.U(t), void 0 !== i && (i.n = t.n), void 0 !== t.n && (t.n.p = i)) : s = t, t.S.n = t.r, void 0 !== t.r && (t.r = void 0), t = i
                    }
                    e.s = s
                }

                function g(e) {
                    p.call(this, void 0), this.x = e, this.s = void 0, this.g = d - 1, this.f = 4
                }

                function m(e) {
                    return new g(e)
                }

                function b(e) {
                    var t = e.u;
                    if (e.u = void 0, "function" == typeof t) {
                        a++;
                        var s = r;
                        r = void 0;
                        try {
                            t()
                        } catch (t) {
                            throw e.f &= -2, e.f |= 8, S(e), t
                        } finally {
                            r = s, n()
                        }
                    }
                }

                function S(e) {
                    for (var t = e.s; void 0 !== t; t = t.n) t.S.U(t);
                    e.x = void 0, e.s = void 0, b(e)
                }

                function C(e) {
                    if (r !== this) throw new Error("Out-of-order effect");
                    h(this), r = e, this.f &= -2, 8 & this.f && S(this), n()
                }

                function y(e) {
                    this.x = e, this.u = void 0, this.s = void 0, this.o = void 0, this.f = 32
                }

                function w(e) {
                    var t = new y(e);
                    try {
                        t.c()
                    } catch (e) {
                        throw t.d(), e
                    }
                    return t.d.bind(t)
                }
                p.prototype.h = function() {
                    return !0
                }, p.prototype.S = function(e) {
                    this.t !== e && void 0 === e.e && (e.x = this.t, void 0 !== this.t && (this.t.e = e), this.t = e)
                }, p.prototype.U = function(e) {
                    if (void 0 !== this.t) {
                        var t = e.e,
                            s = e.x;
                        void 0 !== t && (t.x = s, e.e = void 0), void 0 !== s && (s.e = t, e.x = void 0), e === this.t && (this.t = s)
                    }
                }, p.prototype.subscribe = function(e) {
                    var t = this;
                    return w((function() {
                        var s = t.value,
                            i = 32 & this.f;
                        this.f &= -33;
                        try {
                            e(s)
                        } finally {
                            this.f |= i
                        }
                    }))
                }, p.prototype.valueOf = function() {
                    return this.value
                }, p.prototype.toString = function() {
                    return this.value + ""
                }, p.prototype.toJSON = function() {
                    return this.value
                }, p.prototype.peek = function() {
                    return this.v
                }, Object.defineProperty(p.prototype, "value", {
                    get: function() {
                        var e = l(this);
                        return void 0 !== e && (e.i = this.i), this.v
                    },
                    set: function(e) {
                        if (r instanceof g && function() {
                                throw new Error("Computed cannot have side-effects")
                            }(), e !== this.v) {
                            u > 100 && i(), this.v = e, this.i++, d++, a++;
                            try {
                                for (var t = this.t; void 0 !== t; t = t.x) t.t.N()
                            } finally {
                                n()
                            }
                        }
                    }
                }), (g.prototype = new p).h = function() {
                    if (this.f &= -3, 1 & this.f) return !1;
                    if (32 == (36 & this.f)) return !0;
                    if (this.f &= -5, this.g === d) return !0;
                    if (this.g = d, this.f |= 1, this.i > 0 && !f(this)) return this.f &= -2, !0;
                    var e = r;
                    try {
                        v(this), r = this;
                        var t = this.x();
                        (16 & this.f || this.v !== t || 0 === this.i) && (this.v = t, this.f &= -17, this.i++)
                    } catch (e) {
                        this.v = e, this.f |= 16, this.i++
                    }
                    return r = e, h(this), this.f &= -2, !0
                }, g.prototype.S = function(e) {
                    if (void 0 === this.t) {
                        this.f |= 36;
                        for (var t = this.s; void 0 !== t; t = t.n) t.S.S(t)
                    }
                    p.prototype.S.call(this, e)
                }, g.prototype.U = function(e) {
                    if (void 0 !== this.t && (p.prototype.U.call(this, e), void 0 === this.t)) {
                        this.f &= -33;
                        for (var t = this.s; void 0 !== t; t = t.n) t.S.U(t)
                    }
                }, g.prototype.N = function() {
                    if (!(2 & this.f)) {
                        this.f |= 6;
                        for (var e = this.t; void 0 !== e; e = e.x) e.t.N()
                    }
                }, g.prototype.peek = function() {
                    if (this.h() || i(), 16 & this.f) throw this.v;
                    return this.v
                }, Object.defineProperty(g.prototype, "value", {
                    get: function() {
                        1 & this.f && i();
                        var e = l(this);
                        if (this.h(), void 0 !== e && (e.i = this.i), 16 & this.f) throw this.v;
                        return this.v
                    }
                }), y.prototype.c = function() {
                    var e = this.S();
                    try {
                        if (8 & this.f) return;
                        if (void 0 === this.x) return;
                        var t = this.x();
                        "function" == typeof t && (this.u = t)
                    } finally {
                        e()
                    }
                }, y.prototype.S = function() {
                    1 & this.f && i(), this.f |= 1, this.f &= -9, b(this), v(this), a++;
                    var e = r;
                    return r = this, C.bind(this, e)
                }, y.prototype.N = function() {
                    2 & this.f || (this.f |= 2, this.o = o, o = this)
                }, y.prototype.d = function() {
                    this.f |= 8, 1 & this.f || S(this)
                }
            },
            58946: function(e, t, s) {
                "use strict";
                s.d(t, {
                    q: function() {
                        return r
                    }
                });
                var i = s(35618),
                    n = s(68534),
                    r = (0, i.Fl)((() => {
                        var e, t = null == (e = n.e.value) ? void 0 : e.apiKey;
                        if (t) return t;
                        var s = document.getElementById("spcloader");
                        if (s && s.getAttribute) {
                            var i = s.getAttribute("data-key");
                            if ("string" == typeof i && i.length > 0) return i
                        }
                    }))
            },
            68534: function(e, t, s) {
                "use strict";
                s.d(t, {
                    e: function() {
                        return o
                    }
                });
                var i = s(16148),
                    n = s(35618),
                    r = s(26926),
                    o = (0, n.Fl)((() => {
                        var e, t;
                        return (0, r.rd)((null == (e = i.noticeConfig.value) ? void 0 : e.website) || {}, (null == (t = i.noticeConfig.value) ? void 0 : t.app) || {})
                    }))
            },
            92308: function(e, t, s) {
                "use strict";
                s.d(t, {
                    $: function() {
                        return n
                    }
                });
                var i = s(68534),
                    n = (0, s(35618).Fl)((() => {
                        var e;
                        return (null == (e = i.e.value) ? void 0 : e.disabledPurposes) || []
                    }))
            },
            25010: function(e, t, s) {
                "use strict";
                s.d(t, {
                    P: function() {
                        return r
                    }
                });
                var i = s(68534),
                    n = s(44071),
                    r = (0, s(35618).Fl)((() => {
                        var e, t = null == (e = i.e.value) ? void 0 : e.essentialPurposes;
                        return t && Array.isArray(t) ? t.filter(Boolean).filter((e => {
                            var t, s;
                            return "custom" === (null == (t = n.s.value) || null == (s = t[e]) ? void 0 : s.namespace)
                        })) : []
                    }))
            },
            92171: function(e, t, s) {
                "use strict";
                s.d(t, {
                    s: function() {
                        return u
                    }
                });
                var i = s(35618),
                    n = s(86889),
                    r = s(44071),
                    o = s(92308),
                    a = s(74385),
                    u = (0, i.Fl)((() => {
                        var e, t = [];
                        for (var s of n.r.value)
                            if (s && s.purposeIds)
                                for (var i of s.purposeIds) {
                                    var u, d = null == (u = r.s.value) ? void 0 : u[i];
                                    !d || t.includes(d.id) || o.$.value.includes(d.id) || t.push(d.id)
                                }
                        if (null != (e = a.F.value) && e.length) {
                            var l = a.F.value.map((e => e.id));
                            t = [...new Set(l.concat(t))]
                        }
                        return t
                    }))
            },
            75211: function(e, t, s) {
                "use strict";
                s.d(t, {
                    L: function() {
                        return i
                    }
                });
                var i = (e, t) => 0 !== e.length && 0 !== t.length && e.every((e => -1 !== t.indexOf(e)))
            },
            98291: function(e, t, s) {
                "use strict";
                s.d(t, {
                    v: function() {
                        return r
                    }
                });
                var i = s(44071),
                    n = s(92171),
                    r = e => n.s.value.map((e => {
                        var t;
                        return null == (t = i.s.value) ? void 0 : t[e]
                    })).filter((t => !e || (null == t ? void 0 : t.namespace) === e)).filter((e => "object" == typeof e))
            },
            82041: function(e, t, s) {
                "use strict";
                s.d(t, {
                    h: function() {
                        return u
                    }
                });
                var i = s(35618),
                    n = s(68534),
                    r = s(3370),
                    o = s(1151),
                    a = s(16619),
                    u = (0, i.Fl)((() => {
                        var e, t, s, i, u = null == (e = n.e.value) || null == (t = e.vendors) ? void 0 : t.iab;
                        if (!u) return [];
                        var d, l, p = [];
                        (Array.isArray(u) && (p = u), u === Object(u) && u.all) ? p.push(...null == (d = o.z.value) || null == (l = d.vendors) ? void 0 : l.map((e => e.id))): u.include && Array.isArray(u.include) && p.push(...u.include);
                        u.exclude && Array.isArray(u.exclude) && (p = p.filter((e => !u.exclude.includes(e))));
                        var c = null == (s = u.include) ? void 0 : s.includes(a.OE.google),
                            f = null == (i = u.exclude) ? void 0 : i.includes(a.OE.google);
                        return p = p.map((e => {
                            var t, s;
                            return null == (t = r.I.value) || null == (s = t[e]) ? void 0 : s.id
                        })).filter(Boolean), !u.all && !c || f || p.push("google"), p
                    }))
            },
            23721: function(e, t, s) {
                "use strict";
                s.d(t, {
                    V: function() {
                        return r
                    }
                });
                var i = s(35618),
                    n = s(86889),
                    r = (0, i.Fl)((() => {
                        var e;
                        return null == (e = n.r.value) ? void 0 : e.filter((e => {
                            var {
                                legIntPurposeIds: t
                            } = e;
                            return t.length > 0
                        })).map((e => {
                            var {
                                id: t
                            } = e;
                            return t
                        }))
                    }))
            },
            95071: function(e, t, s) {
                "use strict";
                s.d(t, {
                    O: function() {
                        return l
                    }
                });
                var i = s(35618),
                    n = s(82041),
                    r = s(68534),
                    o = s(38893).H.map((e => e.id)).concat("google"),
                    a = (0, i.Fl)((() => {
                        var e, t, s = null == r.e || null == (e = r.e.value) || null == (t = e.vendors) ? void 0 : t.didomi;
                        return s && Array.isArray(s) ? s.filter((e => o.includes(e))) : []
                    })),
                    u = s(21753),
                    d = (0, i.Fl)((() => {
                        var e, t, s;
                        return null != (e = u.A.value) && e.length ? null == (t = u.A.value) || null == (s = t.filter((e => {
                            var t;
                            return !(null != e && null != (t = e.namespaces) && t.didomi)
                        }))) ? void 0 : s.map((e => e.id)) : []
                    })),
                    l = (0, i.Fl)((() => [...new Set([...n.h.value || [], ...a.value || [], ...d.value || []])]))
            },
            86889: function(e, t, s) {
                "use strict";
                s.d(t, {
                    r: function() {
                        return a
                    }
                });
                var i = s(35618),
                    n = s(95071),
                    r = s(3370),
                    o = s(26926),
                    a = (0, i.Fl)((() => {
                        var e, t, s;
                        return null == (e = n.O.value) || !e.length || (0, o.xb)(r.I.value) ? [] : null == (t = n.O.value) || null == (s = t.map((e => {
                            var t;
                            return null == (t = r.I.value) ? void 0 : t[e]
                        }))) ? void 0 : s.filter(Boolean)
                    }))
            },
            99005: function(e, t, s) {
                "use strict";
                s.d(t, {
                    i: function() {
                        return o
                    }
                });
                var i = s(35618),
                    n = s(25010),
                    r = s(21753),
                    o = (0, i.Fl)((() => {
                        var e;
                        return (null == (e = r.A.value) ? void 0 : e.reduce(((e, t) => {
                            var {
                                id: s,
                                purposeIds: i
                            } = t;
                            return i.length > 0 && i.every((e => n.P.value.includes(e))) && e.push(s), e
                        }), [])) || []
                    }))
            },
            20849: function(e, t, s) {
                "use strict";
                s.d(t, {
                    J: function() {
                        return o
                    }
                });
                var i = s(35618),
                    n = s(25010),
                    r = s(21753),
                    o = (0, i.Fl)((() => {
                        var e;
                        return (null == (e = r.A.value) ? void 0 : e.reduce(((e, t) => {
                            var {
                                id: s,
                                legIntPurposeIds: i
                            } = t;
                            return i.length > 0 && i.every((e => n.P.value.includes(e))) && e.push(s), e
                        }), [])) || []
                    }))
            },
            36660: function(e, t, s) {
                "use strict";
                s.d(t, {
                    L: function() {
                        return o
                    }
                });
                var i = s(35618),
                    n = s(68534),
                    r = s(26926),
                    o = (0, i.Fl)((() => {
                        var e, t = null == (e = n.e.value) ? void 0 : e.consentString,
                            s = null == t ? void 0 : t.version;
                        return (0, r.LH)(s) ? {
                            version: s,
                            signatureEnabled: !0 === (null == t ? void 0 : t.signatureEnabled),
                            isDidomiConsentStringEncodingEnabled: !0
                        } : (void 0 !== s && console.error("Didomi - The Didomi Consent String version [" + s + "] is invalid"), {
                            version: void 0,
                            signatureEnabled: !1,
                            isDidomiConsentStringEncodingEnabled: !1
                        })
                    }))
            },
            52649: function(e, t, s) {
                "use strict";
                s.d(t, {
                    K: function() {
                        return a
                    }
                });
                var i = s(35618),
                    n = s(68534),
                    r = s(34155),
                    o = s(28854),
                    a = (0, i.Fl)((() => {
                        var e, t = "ctv" === (null == o.q ? void 0 : o.q.platform),
                            s = !(null == (e = n.e.value) || !e.ctvEnabled);
                        return (() => {
                            if (r.env.CTV) return !0;
                            try {
                                var e = navigator.userAgent.match(/AppleTV/i) || navigator.userAgent.match(/CrKey/i) || navigator.userAgent.match(/GoogleTV/i) || navigator.userAgent.match(/HbbTV/i) || navigator.userAgent.match(/SmartTV/i) || navigator.userAgent.match(/SMART-TV/i) || navigator.userAgent.match(/DTV/i) || navigator.userAgent.match(/LG/i) || navigator.userAgent.match(/GTV/i) || navigator.userAgent.match(/Viera/i) || navigator.userAgent.match(/NETTV/i) || navigator.userAgent.match(/PHILIPSTV/i) || navigator.userAgent.match(/POV_TV/i) || navigator.userAgent.match(/Roku/i) || navigator.userAgent.match(/Samsung/i) || navigator.userAgent.match(/SmartHub/i) || navigator.userAgent.match(/Espial/i) || navigator.userAgent.match(/SonyDTV/i) || navigator.userAgent.match(/Opera TV/i);
                                return Boolean(e)
                            } catch (e) {
                                return console.error("Didomi - There was a problem checking if the user is on a TV device. Error: " + e.message), !1
                            }
                        })() && (t || s)
                    }))
            },
            74385: function(e, t, s) {
                "use strict";
                s.d(t, {
                    F: function() {
                        return o
                    }
                });
                var i = s(87462),
                    n = s(35618),
                    r = s(68534),
                    o = (0, n.Fl)((() => {
                        var e, t, s = null == (e = r.e.value) ? void 0 : e.customPurposes,
                            n = [];
                        if (s && Array.isArray(s))
                            for (var o of s) t = o.id, /^[A-Za-z0-9-_]+$/.test(t) ? n.push((0, i.Z)({}, o, {
                                namespace: "custom"
                            })) : console.error('Didomi - The purpose id "' + o.id + '" is not valid. Ignoring it.');
                        return n
                    }))
            },
            96730: function(e, t, s) {
                "use strict";
                s.d(t, {
                    z: function() {
                        return n
                    }
                });
                var i = s(44071),
                    n = e => {
                        var t;
                        return null == (t = i.s.value) ? void 0 : t[e]
                    }
            },
            44071: function(e, t, s) {
                "use strict";
                s.d(t, {
                    s: function() {
                        return c
                    }
                });
                var i = s(87462),
                    n = s(35618),
                    r = s(16619),
                    o = s(74385),
                    a = s(8861),
                    u = (0, n.Fl)((() => {
                        var e, t, s;
                        return null != (e = a.c.value) && null != (t = e.purposes) && t.length ? null == (s = a.c.value) ? void 0 : s.purposes.map((e => (0, i.Z)({}, e, {
                            id: r.oM[e.id],
                            namespace: "iab"
                        }))) : []
                    })),
                    d = s(1151),
                    l = (0, n.Fl)((() => {
                        var e, {
                            specialFeatures: t
                        } = d.z.value || {};
                        return !!t && Array.isArray(t) && !(null == (e = a.c.value) || !e.specialFeatures) ? null == t ? void 0 : t.map((e => {
                            var t, s;
                            return (0, i.Z)({}, null == (t = a.c.value) || null == (s = t.specialFeatures) ? void 0 : s.find((t => t.id === e.id)), {
                                id: r.GY[e.id],
                                namespace: "iab",
                                isSpecialFeature: !0
                            })
                        })) : []
                    })),
                    p = [{
                        id: r.o7.CookiesAnalytics
                    }, {
                        id: r.o7.CookiesMarketing
                    }, {
                        id: r.o7.CookiesSocial
                    }],
                    c = (0, n.Fl)((() => {
                        var e = [...p, ...u.value || [], ...l.value || [], ...o.F.value || []];
                        if (null == e || !e.length) return {};
                        var t = {};
                        for (var s of e)
                            if ("custom" === s.namespace) {
                                var n, a, d = r.oM[null == s || null == (n = s.namespaces) ? void 0 : n.iab2];
                                if (!!t[d]) t[d] = (0, i.Z)({}, t[d], {
                                    namespaces: (0, i.Z)({}, null == (a = t[d]) ? void 0 : a.namespaces, null == s ? void 0 : s.namespaces)
                                });
                                else t[s.id] = s
                            } else t[s.id] = s;
                        return t
                    }))
            },
            90327: function(e, t, s) {
                "use strict";
                s.d(t, {
                    L: function() {
                        return r
                    }
                });
                var i = s(35618),
                    n = s(17832),
                    r = (0, i.Fl)((() => {
                        var e;
                        return (null == (e = n._.value) ? void 0 : e.filter((e => {
                            var t, s;
                            return !!e.namespaces && (Object.keys(e.namespaces).includes("google") && !(null == e || null == (t = e.namespaces) || null == (s = t.google) || !s.current))
                        }))) || []
                    }))
            },
            21753: function(e, t, s) {
                "use strict";
                s.d(t, {
                    A: function() {
                        return o
                    }
                });
                var i = s(87462),
                    n = s(68534),
                    r = s(44071),
                    o = (0, s(35618).Fl)((() => {
                        var e, t, s = e => {
                                var t;
                                return !(null == (t = r.s.value) || !t[e])
                            },
                            o = null == (e = n.e.value) || null == (t = e.vendors) ? void 0 : t.custom,
                            a = [];
                        if (o && Array.isArray(o))
                            for (var u of o) {
                                var d = (u.purposeIds || []).filter(s),
                                    l = (u.legIntPurposeIds || []).filter(s);
                                (d.length > 0 || l.length > 0) && a.push((0, i.Z)({}, u, {
                                    purposeIds: d,
                                    legIntPurposeIds: l,
                                    id: "c:" + u.id,
                                    namespace: "custom"
                                }))
                            }
                        return a
                    }))
            },
            38893: function(e, t, s) {
                "use strict";
                s.d(t, {
                    H: function() {
                        return r
                    }
                });
                var i = s(16619),
                    n = Object.keys(i.f3),
                    r = [{
                        id: "*",
                        name: "Any",
                        purposeIds: ["cookies"],
                        legIntPurposeIds: []
                    }, {
                        id: "amazon",
                        name: "Amazon",
                        purposeIds: n,
                        legIntPurposeIds: [],
                        policyUrl: "https://aps.amazon.com/aps/privacy-policy/index.html",
                        namespace: "didomi"
                    }, {
                        id: "facebook",
                        name: "Facebook",
                        purposeIds: [i.o7.Cookies, i.o7.CreateAdsProfile, i.o7.SelectPersonalizedAds],
                        legIntPurposeIds: [i.o7.SelectBasicAds, i.o7.MeasureAdPerformance, i.o7.MarketResearch, i.o7.ImproveProducts],
                        policyUrl: "https://www.facebook.com/about/privacy/update",
                        namespace: "didomi",
                        namespaces: {
                            google: {
                                current: !0,
                                id: 89
                            }
                        }
                    }, {
                        id: "twitter",
                        name: "Twitter",
                        purposeIds: ["cookies"],
                        legIntPurposeIds: [],
                        policyUrl: "https://twitter.com/privacy",
                        namespace: "didomi"
                    }, {
                        id: "whatsapp",
                        name: "Whatsapp",
                        purposeIds: ["cookies"],
                        legIntPurposeIds: [],
                        policyUrl: "https://www.whatsapp.com/legal/#privacy-policy",
                        namespace: "didomi"
                    }, {
                        id: "google-adsense",
                        name: "Google Adsense",
                        purposeIds: n,
                        legIntPurposeIds: [],
                        policyUrl: "https://policies.google.com/technologies/partner-sites",
                        namespace: "didomi"
                    }, {
                        id: "google-adx",
                        name: "Google Adx",
                        purposeIds: n,
                        legIntPurposeIds: [],
                        policyUrl: "https://policies.google.com/technologies/partner-sites",
                        namespace: "didomi"
                    }, {
                        id: "google-dfp",
                        name: "Google DFP",
                        purposeIds: n,
                        legIntPurposeIds: [],
                        policyUrl: "https://policies.google.com/technologies/partner-sites",
                        namespace: "didomi"
                    }, {
                        id: "addthis",
                        name: "AddThis",
                        purposeIds: n,
                        legIntPurposeIds: [],
                        policyUrl: "http://www.addthis.com/privacy",
                        namespace: "didomi"
                    }, {
                        id: "salesforce",
                        name: "Salesforce",
                        purposeIds: n,
                        legIntPurposeIds: [],
                        policyUrl: "https://www.salesforce.com/company/privacy/",
                        namespace: "didomi"
                    }]
            },
            17832: function(e, t, s) {
                "use strict";
                s.d(t, {
                    _: function() {
                        return o
                    }
                });
                var i = s(35618),
                    n = s(3370),
                    r = s(26926),
                    o = (0, i.Fl)((() => (0, r.VO)(n.I.value) || []))
            },
            3370: function(e, t, s) {
                "use strict";
                s.d(t, {
                    I: function() {
                        return C
                    }
                });
                var i = s(87462),
                    n = s(35618),
                    r = s(38893),
                    o = s(1151),
                    a = s(62382),
                    u = s(67336),
                    d = s(15813),
                    l = s(18111),
                    p = s(55974),
                    c = s(26926),
                    f = (0, n.Fl)((() => {
                        var {
                            vendors: e
                        } = o.z.value || {};
                        if (!e || !Array.isArray(e)) return [];
                        var t, s, n = r.H.map((e => (e => {
                                if ("iab" === e.namespace) {
                                    var t = (0, c.hj)(e.id) ? e.id : parseInt(e.id, 10);
                                    if (t) return t
                                } else if (e.namespaces) {
                                    if ((0, c.hj)(e.namespaces.iab)) return e.namespaces.iab;
                                    if ((0, c.hj)(e.namespaces.iab2)) return e.namespaces.iab2
                                }
                                return null
                            })(e))),
                            f = e.filter((e => !n.includes(e.id)));
                        return t = f, null != (s = a.s.value) && s.length ? t.reduce(((e, t) => {
                            var n = (0, i.Z)({}, t, {
                                purposeIds: t.purposeIds.filter((e => !(0, u.E)(e, t.id, "req-li", s, !1))),
                                legIntPurposeIds: t.legIntPurposeIds.filter((e => !(0, u.E)(e, t.id, "req-consent", s, !1))),
                                specialFeatureIds: t.specialFeatureIds.filter((e => !(0, u.E)(e, t.id, "disallow", s, !0)))
                            });
                            return n.purposeIds = (0, p.hg)([...n.purposeIds, ...(0, d.j)(t, "req-consent", s)]), n.legIntPurposeIds = (0, p.hg)([...n.legIntPurposeIds, ...(0, d.j)(t, "req-li", s)]), (0, l.u)(n) || e.push(n), e
                        }), []) : t
                    })),
                    v = s(16619),
                    h = {
                        id: "google",
                        name: "Google Advertising Products",
                        policyUrl: "https://policies.google.com/privacy",
                        namespace: "didomi"
                    },
                    g = s(72424),
                    m = s(21753),
                    b = s(68534),
                    S = (e, t) => {
                        e && t && (t.purposeIds = e.purposeIds, t.legIntPurposeIds = e.legIntPurposeIds)
                    },
                    C = (0, n.Fl)((() => {
                        var e, t, s, n, o, a, u, d, l, p, c, C, y = (null == (e = window) || null == (t = e.didomiConfig) || null == (s = t.website) || null == (n = s.vendors) || null == (o = n.iab) ? void 0 : o.vendorList) || (null == (a = window) || null == (u = a.didomiConfig) || null == (d = u.app) || null == (l = d.vendors) || null == (p = l.iab) ? void 0 : p.vendorList) || f.value,
                            w = (null == (c = b.e.value) || null == (C = c.vendors) ? void 0 : C.overrideVendors) || [],
                            I = Object.keys(w),
                            _ = [...r.H, ...null == y ? void 0 : y.map((e => (e => {
                                var t = [];
                                return t.push(...(e.purposeIds || []).map((e => (0, v.ry)(e)))), t.push(...(e.specialFeatureIds || []).map((e => (0, v.x6)(e)))), (0, i.Z)({}, e, {
                                    namespace: "iab",
                                    purposeIds: t,
                                    legIntPurposeIds: (e.legIntPurposeIds || []).map((e => (0, v.ry)(e))),
                                    flexiblePurposeIds: (e.flexiblePurposeIds || []).map((e => (0, v.ry)(e)))
                                }, e.id === v.OE.google && (0, i.Z)({}, h, {
                                    namespaces: {
                                        iab2: v.OE.google
                                    }
                                }))
                            })(e))), ...m.A.value],
                            P = {},
                            A = _.find((e => "google" === e.id));
                        for (var k of _) {
                            if (k.policyUrl && (k.policyUrl = (0, g.X2)(k.policyUrl)), "custom" === k.namespace) {
                                var T, E;
                                (0, v.DL)(k) && S(A, k);
                                var L, U = (null == k || null == (T = k.namespaces) ? void 0 : T.didomi) || (null == k || null == (E = k.namespaces) ? void 0 : E.iab2);
                                if (!!P[U]) P[U] = (0, i.Z)({}, P[U], {
                                    namespaces: (0, i.Z)({}, null == (L = P[U]) ? void 0 : L.namespaces, null == k ? void 0 : k.namespaces)
                                });
                                else P[k.id] = k
                            } else "didomi" === k.namespace ? ((0, v.DL)(k) && S(A, k), P[k.id] = k) : P[k.id] = k;
                            I.includes(k.id) && (P[k.id] = (0, i.Z)({}, P[k.id], w[k.id]))
                        }
                        return P
                    }))
            },
            63205: function(e, t, s) {
                "use strict";
                s.d(t, {
                    j8: function() {
                        return u
                    },
                    V2: function() {
                        return d
                    },
                    H: function() {
                        return l
                    },
                    hS: function() {
                        return o
                    },
                    xS: function() {
                        return a
                    },
                    on: function() {
                        return p
                    },
                    IH: function() {
                        return c
                    },
                    Wp: function() {
                        return r
                    }
                });
                var i = s(99865),
                    n = (0, i.EventEmitter)().setMaxListeners(50),
                    r = e => {
                        n.setMaxListeners(e)
                    },
                    o = () => n.maxListeners,
                    a = e => n.listenerCount(e),
                    u = function(e) {
                        for (var t = arguments.length, s = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) s[i - 1] = arguments[i];
                        n.emit(e, ...s)
                    },
                    d = (e, t) => {
                        (e => !e || e >= 400)(e) && u("api.error", {
                            id: t,
                            reason: "number" == typeof e && e >= 400 ? "response.error" : "request.failure"
                        })
                    },
                    l = function(e) {
                        for (var t = arguments.length, s = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) s[i - 1] = arguments[i];
                        window.didomiOnReady = window.didomiOnReady || [], window.didomiOnReady.push((() => {
                            u(e, ...s)
                        }))
                    },
                    p = (e, t) => {
                        n.on(e, t)
                    },
                    c = (e, t) => {
                        n.once(e, t)
                    }
            },
            8861: function(e, t, s) {
                "use strict";
                s.d(t, {
                    c: function() {
                        return i
                    },
                    d: function() {
                        return n
                    }
                });
                var i = (0, s(35618).td)(null),
                    n = e => {
                        i.value = e
                    }
            },
            1151: function(e, t, s) {
                "use strict";
                s.d(t, {
                    N: function() {
                        return n
                    },
                    z: function() {
                        return i
                    }
                });
                var i = (0, s(35618).td)(null),
                    n = e => {
                        i.value = e
                    }
            },
            77122: function(e, t, s) {
                "use strict";
                s.d(t, {
                    m: function() {
                        return d
                    }
                });
                var i = s(35618),
                    n = s(68534),
                    r = s(26926),
                    o = s(8861),
                    a = s(1151),
                    u = s(23605),
                    d = (0, i.Fl)((() => {
                        var e, t, s = null == (e = n.e.value) || null == (t = e.vendors) ? void 0 : t.iab,
                            i = {
                                majorVersion: u.t.defaultTCFVersion,
                                minorVersion: null,
                                semVersion: u.t.defaultTCFVersion
                            };
                        if (s && !(0, r.xb)(s)) {
                            var {
                                version: o,
                                minorVersion: a
                            } = s;
                            o && (i.majorVersion = o, i.minorVersion = a || null, i.semVersion = void 0 !== a ? parseFloat(o + "." + a) : o)
                        }
                        return i
                    }));
                (0, i.cE)((() => {
                    var e, t, i, n, r, u, l, p, c, f, v, h, g, m, b, S, C, y, w, I, _ = d.value.semVersion;
                    null != (e = window) && null != (t = e.didomiConfig) && null != (i = t.website) && null != (n = i.vendors) && null != (r = n.iab) && r.vendorList || null != (u = window) && null != (l = u.didomiConfig) && null != (p = l.app) && null != (c = p.vendors) && null != (f = c.iab) && f.vendorList ? (0, a.N)((null == (v = window) || null == (h = v.didomiConfig) || null == (g = h.website) || null == (m = g.vendors) || null == (b = m.iab) ? void 0 : b.vendorList) || (null == (S = window) || null == (C = S.didomiConfig) || null == (y = C.app) || null == (w = y.vendors) || null == (I = w.iab) ? void 0 : I.vendorList)) : s(44618)("./v" + _ + "/vendors/iab-core").then((e => {
                        var {
                            default: t
                        } = e;
                        (0, a.N)(t)
                    })).catch((() => {}));
                    s(57710)("./v" + _ + "/purposes/index.js").then((e => {
                        (0, o.d)(e)
                    })).catch((() => {}))
                }))
            },
            62382: function(e, t, s) {
                "use strict";
                s.d(t, {
                    s: function() {
                        return f
                    }
                });
                var i = s(68534),
                    n = s(35618),
                    r = s(26926),
                    o = s(16619),
                    a = ["all", "list"],
                    u = ["allow", "disallow", "req-consent", "req-li"],
                    d = (0, r.VO)(o.nU),
                    l = e => {
                        if (!e) return !1;
                        var {
                            id: t,
                            purposeId: s,
                            vendors: i,
                            restrictionType: n
                        } = e;
                        return (e => {
                            var {
                                restrictionId: t,
                                vendorRestrictionType: s,
                                vendorRestrictionRanges: i,
                                restrictionType: n,
                                restrictionPurposeId: r,
                                vendorIds: l
                            } = e, p = d.includes(r), c = p ? o.eb[r] : o.q1[r];
                            if ("string" != typeof t || 0 === t.length) return console.error('Didomi - Invalid restriction ID "' + t + '" provided for publisher restrictions'), !1;
                            if (void 0 === c) return console.error('Didomi - Invalid purpose ID or special feature ID "' + r + '" provided for publisher restrictions'), !1;
                            if (p) {
                                if ("all" !== s) return console.error("Didomi - Only vendor restriction type 'all' is valid for special features"), !1;
                                if ("disallow" !== n) return console.error("Didomi - Only restriction type 'disallow' is valid for special features"), !1
                            } else {
                                if (void 0 === s || -1 === a.indexOf(s)) return console.error('Didomi - Invalid vendor restriction type "' + s + '" provided for publisher restrictions'), !1;
                                if ("list" === s)
                                    if (Array.isArray(l) && 0 !== l.length) {
                                        if (!l.every((e => "number" == typeof e))) return console.error("Didomi - Vendor IDs for publisher restrictions should be numerical values"), !1
                                    } else {
                                        if (!Array.isArray(i) || 0 === i.length) return console.error("Didomi - Invalid vendor restriction ranges provided for publisher restrictions"), !1;
                                        if (i.map((e => {
                                                var t = Object.keys(e);
                                                return "object" == typeof e && -1 !== t.indexOf("start") && -1 !== t.indexOf("end") && e.start < e.end
                                            })).filter((e => !0 === e)).length !== i.length) return console.error("Didomi - Invalid vendor restriction ranges provided for publisher restrictions. Each vendor restriction must contain 'start' and 'end' key"), !1
                                    }
                                if ("string" != typeof n || -1 === u.indexOf(n)) return console.error('Didomi - Invalid restriction type "' + n + '" provided for publisher restrictions'), !1;
                                if ("cookies" === r && ("req-consent" === n || "req-li" === n)) return console.error("Didomi - Only restriction types 'allow' or 'disallow' are valid for the purpose 'cookies'"), !1
                            }
                            return !0
                        })({
                            restrictionId: t,
                            vendorRestrictionType: null == i ? void 0 : i.type,
                            vendorRestrictionRanges: null == i ? void 0 : i.ranges,
                            restrictionType: n,
                            restrictionPurposeId: s,
                            vendorIds: null == i ? void 0 : i.ids
                        })
                    },
                    p = (e, t, s, i, n) => {
                        if ("all" === t) return "allow" === e ? [] : n;
                        var r = "allow" === e,
                            o = new Set;
                        return s && (r ? n.forEach((e => {
                            s.includes(e) || o.add(e)
                        })) : s.forEach((e => {
                            o.add(e)
                        }))), i && i.forEach((e => {
                            var {
                                start: t,
                                end: s
                            } = e;
                            if (r) n.forEach((e => {
                                (e < t || e > s) && o.add(e)
                            }));
                            else
                                for (var i = t; i <= s; i++) o.add(i)
                        })), Array.from(o)
                    },
                    c = s(1151),
                    f = (0, n.Fl)((() => {
                        var e, t, s, n = null == (e = i.e.value) || null == (t = e.vendors) || null == (s = t.iab) ? void 0 : s.restrictions;
                        return Array.isArray(n) ? n.filter(l).map((e => {
                            var t, s;
                            return ((e, t) => {
                                var {
                                    id: s,
                                    purposeId: i,
                                    vendors: n,
                                    restrictionType: r
                                } = e, o = null == n ? void 0 : n.type, a = null == n ? void 0 : n.ranges, u = null == n ? void 0 : n.ids;
                                return {
                                    id: s,
                                    purposeId: i,
                                    vendors: p(r, o, u, a, t),
                                    restrictionType: r,
                                    vendorRestrictionType: o
                                }
                            })(e, null == (t = c.z.value) || null == (s = t.vendors) ? void 0 : s.map((e => {
                                var {
                                    id: t
                                } = e;
                                return t
                            })))
                        })) : []
                    }))
            },
            67336: function(e, t, s) {
                "use strict";
                s.d(t, {
                    E: function() {
                        return n
                    }
                });
                var i = s(16619),
                    n = function(e, t, s, n, r) {
                        void 0 === r && (r = !1);
                        var o = ((e, t) => "string" != typeof e ? t ? (0, i.x6)(e) : (0, i.ry)(e) : e)(e, r),
                            a = n.filter(((e, t) => s => s.purposeId === e && s.vendors.includes(t))(o, t));
                        return a.some((e => ["disallow", "allow", s].includes(e.restrictionType)))
                    }
            },
            18111: function(e, t, s) {
                "use strict";
                s.d(t, {
                    u: function() {
                        return i
                    }
                });
                var i = e => 0 === e.purposeIds.length && 0 === e.legIntPurposeIds.length && 0 === e.specialPurposeIds.length
            },
            44891: function(e, t, s) {
                "use strict";
                s.d(t, {
                    N: function() {
                        return i
                    },
                    k: function() {
                        return n
                    }
                });
                var i = void 0 === navigator.globalPrivacyControl ? void 0 : Boolean(navigator.globalPrivacyControl),
                    n = void 0 !== i
            },
            67376: function(e, t, s) {
                "use strict";
                s.d(t, {
                    X: function() {
                        return a
                    }
                });
                var i = s(35618),
                    n = s(18979),
                    r = s(98741),
                    o = s(16148),
                    a = (0, i.Fl)((() => {
                        var e, t, s, i = null == (e = o.noticeConfig.value) ? void 0 : e.languages;
                        if (null != i && i.default) {
                            var a;
                            if (null != (a = n.m.value) && a.includes(i.default)) return i.default;
                            var u = (0, r.Hg)(i.default);
                            if (u) return u;
                            console.error("Didomi - Default language '" + i.default+"' must be in the list of enabled languages")
                        }
                        return null == (t = n.m.value) || !t.length || null != (s = n.m.value) && s.includes(r.k$) ? r.k$ : n.m.value[0]
                    }))
            },
            18979: function(e, t, s) {
                "use strict";
                s.d(t, {
                    m: function() {
                        return o
                    }
                });
                var i = s(35618),
                    n = s(98741),
                    r = s(16148),
                    o = (0, i.Fl)((() => {
                        var e, t = null == (e = r.noticeConfig.value) ? void 0 : e.languages;
                        if (!t) return n.xP;
                        if (Array.isArray(t.enabled) && t.enabled.length > 0) {
                            var s = [];
                            for (var i of t.enabled)
                                if (n.xP.includes(i)) s.push(i);
                                else {
                                    var o = (0, n.Hg)(i);
                                    o ? s.push(o) : console.error("Didomi - The language " + i + " is not supported")
                                }
                            if (s.length > 0) return s
                        }
                    }))
            },
            98741: function(e, t, s) {
                "use strict";
                s.d(t, {
                    Hg: function() {
                        return a
                    },
                    k$: function() {
                        return n
                    },
                    rm: function() {
                        return u
                    },
                    xP: function() {
                        return r
                    }
                });
                var i = s(26926),
                    n = "en",
                    r = ["ca", "de", "en", "es", "fr", "hr", "it", "nl", "pt", "fi", "cs", "pl", "ro", "el", "hu", "da", "sk", "bg", "sl", "lt", "sv", "et", "lv", "tr", "ru", "uk", "ja", "vi", "ar", "zh-TW", "zh-CN", "sr", "ko", "th", "ms", "az-AZ", "bn-IN", "fil", "he", "hi-IN", "id", "mk-MK", "pt-BR", "sw", "no", "ar-JO", "de-AT", "de-CH", "en-GB", "en-NZ", "fr-BE", "fr-CA", "nl-BE"],
                    o = {
                        zh: "CN",
                        az: "AZ",
                        bn: "IN",
                        hi: "IN",
                        mk: "MK",
                        pt: "BR"
                    },
                    a = e => {
                        if (!(0, i.HD)(e)) return null;
                        var [t] = e.split("-"), s = o[t];
                        return s ? t + "-" + s : null
                    },
                    u = e => -1 !== r.indexOf(e) ? e : e.slice(0, 2)
            },
            59303: function(e, t, s) {
                "use strict";
                s.d(t, {
                    S: function() {
                        return a
                    }
                });
                var i = s(35618),
                    n = s(18979),
                    r = s(67376),
                    o = s(98741),
                    a = (0, i.Fl)((() => {
                        var e, t = navigator.languages && navigator.languages[0] || navigator.language || navigator.userLanguage,
                            s = (0, o.rm)(t);
                        return null != (e = n.m.value) && e.includes(s) ? s : r.X.value
                    }))
            },
            16148: function(e, t, s) {
                "use strict";
                s.r(t), s.d(t, {
                    getNoticeConfigValue: function() {
                        return d
                    },
                    noticeConfig: function() {
                        return o
                    },
                    overrideNoticeConfig: function() {
                        return a
                    },
                    updateNoticeConfig: function() {
                        return u
                    },
                    updateNoticeConfigValue: function() {
                        return l
                    }
                });
                var i = s(87462),
                    n = s(35618),
                    r = s(26926),
                    o = (0, n.td)({}),
                    a = e => {
                        var t = Object.assign({}, o.value || {});
                        o.value = (0, i.Z)({}, t, e || {})
                    },
                    u = e => {
                        var t = Object.assign({}, o.value || {});
                        o.value = (0, r.ZB)(t, e || {})
                    },
                    d = function(e, t) {
                        return void 0 === t && (t = void 0), (0, r.U2)(o.value, e) || t
                    },
                    l = (e, t) => {
                        var s = o.value;
                        (0, r.t8)(s, e, t), o.value = s
                    }
            },
            98401: function(e, t, s) {
                "use strict";
                s.d(t, {
                    notice: function() {
                        return a
                    }
                });
                var i = s(35618),
                    n = s(26926),
                    r = s(16148),
                    o = {
                        enable: !0,
                        daysBeforeShowingAgain: 0,
                        closeOnClick: !1,
                        closeOnClickNavigationDelay: 0,
                        closeOnScroll: !1,
                        closeOnScrollThresholdType: "percent",
                        closeOnScrollThreshold: 30,
                        closeOnClickBackdrop: !1,
                        type: "info",
                        position: "panel-bottom-right",
                        textAlignment: "left",
                        logoAlignment: "center",
                        learnMore: !0,
                        learnMoreURL: null,
                        learnMorePosition: null,
                        showDataProcessing: !1,
                        palette: {
                            notice: {
                                background: "#ffffff",
                                text: null
                            },
                            button: {
                                background: null,
                                border: "rgba(34, 34, 34, 0.2)",
                                text: null
                            },
                            hightlightButton: {
                                background: null,
                                border: "rgba(34, 34, 34, 0.2)",
                                text: null
                            }
                        },
                        canCloseAndIgnore: !1,
                        denyAsPrimary: !0,
                        denyAsLink: !1,
                        denyAppliesToLI: !1,
                        denyOptions: null,
                        enableBulkActionOnPurposes: !1
                    },
                    a = (0, i.Fl)((() => {
                        var e, t, s, i, a, u, d = (0, n.rd)(o, (null == (e = r.noticeConfig.value) ? void 0 : e.notice) || {});
                        return d.denyAsPrimary = d.denyOptions ? "primary" === d.denyOptions.button : !0 === d.denyAsPrimary, d.type = null == d || null == (t = d.denyOptions) || !t.button || "none" === (null == d || null == (s = d.denyOptions) ? void 0 : s.button) || null == d || null == (i = d.denyOptions) || !i.link || null != d && d.type ? null == d ? void 0 : d.type : "optin", "ccpa" === (null == (a = r.noticeConfig.value) || null == (u = a.regulation) ? void 0 : u.name) && (d.type = "optout"), d.position = d.position || "top", d.daysBeforeShowingAgain = parseInt("" + ((null == d ? void 0 : d.daysBeforeShowingAgain) || 0), 10), d
                    }))
            },
            58123: function(e, t, s) {
                "use strict";
                s.d(t, {
                    c: function() {
                        return d
                    }
                });
                var i = s(87462),
                    n = s(35618),
                    r = s(26926),
                    o = s(16148),
                    a = {
                        enable: !0,
                        defaultChoice: void 0,
                        enableAllButtons: !0,
                        showWhenConsentIsMissing: !1,
                        canCloseWhenConsentIsMissing: !0,
                        view: "preferences",
                        preferencesView: "purposes",
                        information: {
                            enable: !1,
                            content: {
                                text: {}
                            }
                        },
                        categories: [],
                        denyAppliesToLI: !0,
                        controlType: void 0,
                        combineLIAndConsent: !1,
                        content: {
                            instructions: void 0
                        },
                        vendorsListModal: {
                            isOpen: !1,
                            title: null,
                            vendors: []
                        }
                    },
                    u = e => {
                        if (e.purposeId || e.id) {
                            if (/^[A-Za-z0-9-_]+$/.test(e.id)) {
                                if (e.children) {
                                    var t = [];
                                    for (var s of e.children) {
                                        var i = u(s);
                                        i && t.push(i)
                                    }
                                    e.children = t
                                }
                                return e
                            }
                            return console.error('Didomi - The category ID "' + e.id + '" is not valid. Ignoring it.'), null
                        }
                        return console.error("Didomi - The category/purpose ID is undefined. Ignoring it."), null
                    },
                    d = (0, n.Fl)((() => {
                        var e, t, s = (0, r.rd)(a, (null == (e = o.noticeConfig.value) ? void 0 : e.preferences) || {});
                        s.showWhenConsentIsMissing = !(null == s || !s.showWhenConsentIsMissing), !0 === (null == s ? void 0 : s.information.enable) && (s.view = "information"), s.information = (0, i.Z)({}, s.information, {
                            enable: !(null == s || null == (t = s.information) || !t.enable)
                        });
                        var n = [];
                        if (null != s && s.categories)
                            for (var d of s.categories) {
                                var l = u(d);
                                l && n.push(l)
                            }
                        return s.categories = n, s
                    }))
            },
            28854: function(e, t, s) {
                "use strict";
                s.d(t, {
                    q: function() {
                        return o
                    }
                });
                var i, n, r, o = (r = null == (i = window.didomiRemoteConfig) || null == (n = i.notices) ? void 0 : n[0]) && "object" == typeof r ? r : null
            },
            54912: function(e, t, s) {
                "use strict";
                s.r(t), s.d(t, {
                    getSDKConfigValue: function() {
                        return a
                    },
                    sdkConfig: function() {
                        return o
                    }
                });
                var i = s(35618),
                    n = s(16148),
                    r = s(26926),
                    o = (0, i.Fl)((() => {
                        var e, t, s, i, o = (0, r.I8)({
                            apiPath: "https://api.privacy-center.org/v1",
                            customSDKPath: "https://sdk.privacy-center.org/custom/",
                            sdkPathForTCFVendorsStorageDisclosures: "https://sdk.privacy-center.org/",
                            iabGlobalCookiesDomain: "didomi.mgr.consensu.org",
                            globalCookiesProtocol: "https",
                            pmpSdkPath: "https://pmp-sdk.privacy-center.org",
                            events: {
                                sampleSizes: {
                                    pageview: .03,
                                    consentAsked: .1,
                                    consentGiven: 1,
                                    uiActionPreferencesPurposes: 1,
                                    uiActionPreferencesVendors: 1,
                                    uiActionPreferencesPurposeChanged: 1,
                                    uiActionPreferencesVendorChanged: 1,
                                    uiActionPreferencesShownPersonalDataTypes: 1,
                                    uiActionPreferencesSPIChanged: 1
                                }
                            },
                            metrics: {
                                monitoringDidomiOnLoadSampleSize: .1
                            }
                        });
                        return "string" == typeof(null == (e = n.noticeConfig.value) ? void 0 : e.apiPath) && null != (t = n.noticeConfig.value) && t.apiPath && (o.apiPath = n.noticeConfig.value.apiPath), "string" == typeof(null == (s = n.noticeConfig.value) ? void 0 : s.sdkPath) && null != (i = n.noticeConfig.value) && i.sdkPath && (o.sdkPath = n.noticeConfig.value.sdkPath), o
                    })),
                    a = e => o.value[e]
            },
            53017: function(e, t, s) {
                "use strict";
                s.d(t, {
                    I: function() {
                        return n
                    }
                });
                var i = s(16148),
                    n = (0, s(35618).Fl)((() => {
                        var e, t, s = null == (e = i.noticeConfig.value) || null == (t = e.cookies) ? void 0 : t.iabCookieName;
                        return "string" == typeof s && s.length > 0 ? s : "euconsent-v2"
                    }))
            },
            55082: function(e, t, s) {
                "use strict";
                s.d(t, {
                    X: function() {
                        return i
                    },
                    g: function() {
                        return n
                    }
                });
                var i = !1,
                    n = () => {
                        i = !0
                    }
            },
            91604: function(e, t, s) {
                "use strict";
                s.d(t, {
                    Z: function() {
                        return i
                    }
                });
                class i {
                    constructor(e, t, s) {
                        this.store = e, this.actions = t, this.services = s || {}
                    }
                }
            },
            75e3: function(e, t, s) {
                "use strict";
                s.d(t, {
                    H$: function() {
                        return a
                    },
                    IR: function() {
                        return r
                    },
                    d5: function() {
                        return d
                    },
                    dH: function() {
                        return o
                    },
                    eb: function() {
                        return l
                    },
                    vK: function() {
                        return u
                    },
                    xJ: function() {
                        return n
                    }
                });
                var i = s(22222),
                    n = e => e.mixedRegulationPreferences.spiPurposes,
                    r = (0, i.P1)(n, (e => e.map((e => {
                        var {
                            id: t
                        } = e;
                        return t
                    })))),
                    o = e => e.mixedRegulationPreferences.vendors,
                    a = e => e.mixedRegulationPreferences.purposesState,
                    u = e => e.mixedRegulationPreferences.vendorsState,
                    d = e => e.mixedRegulationPreferences.spiPurposesState,
                    l = (0, i.P1)(n, (e => e.length > 0))
            },
            61122: function(e, t, s) {
                "use strict";
                s.r(t), s.d(t, {
                    actions: function() {
                        return a
                    },
                    initialState: function() {
                        return o
                    }
                });
                var i = s(87462),
                    n = s(71654),
                    r = (new Date).toISOString(),
                    o = {
                        consent: {
                            user_id: (0, n.Z)(),
                            created: r,
                            updated: r,
                            vendors: {
                                enabled: [],
                                disabled: []
                            },
                            purposes: {
                                enabled: [],
                                disabled: []
                            },
                            vendors_li: {
                                enabled: [],
                                disabled: []
                            },
                            purposes_li: {
                                enabled: [],
                                disabled: []
                            },
                            dns: void 0,
                            dnsd: void 0,
                            version: null,
                            ac: void 0,
                            sync: void 0
                        },
                        iab: {
                            consentString: null,
                            consentStringPresentFromStorage: !1,
                            decodedAdditionalConsent: void 0
                        },
                        mixed: {
                            user_id: (0, n.Z)(),
                            created: r,
                            updated: r,
                            vendors: {
                                enabled: [],
                                disabled: []
                            },
                            vendors_li: {
                                enabled: [],
                                disabled: []
                            },
                            purposes: {
                                enabled: [],
                                disabled: []
                            },
                            purposes_li: {
                                enabled: [],
                                disabled: []
                            }
                        },
                        mixedTokenPresentFromStorage: !1,
                        tokenUserAuthParams: {}
                    },
                    a = () => ({
                        setConsentByVendor: (e, t) => ({
                            consentByVendor: t
                        }),
                        setConsent: (e, t) => ({
                            consent: t
                        }),
                        setTokenUserAuthParams: (e, t) => ({
                            tokenUserAuthParams: t
                        }),
                        setVersion: (e, t) => (0, i.Z)({}, e, {
                            consent: (0, i.Z)({}, e.consent, {
                                version: t
                            })
                        }),
                        setMixed: (e, t) => ({
                            mixed: t
                        }),
                        setConsentString: (e, t) => (0, i.Z)({}, e, {
                            iab: {
                                consentString: t
                            }
                        }),
                        setConsentStringPresentFromStorage: (e, t) => ({
                            iab: (0, i.Z)({}, e.iab, {
                                consentStringPresentFromStorage: !0 === t
                            })
                        }),
                        setLastSyncDate: (e, t) => ({
                            consent: (0, i.Z)({}, e.consent, {
                                sync: t
                            })
                        }),
                        setDecodedAdditionalConsent: (e, t) => ({
                            iab: (0, i.Z)({}, e.iab, {
                                decodedAdditionalConsent: t
                            })
                        })
                    })
            },
            48766: function(e, t, s) {
                "use strict";
                s.d(t, {
                    L8: function() {
                        return l
                    },
                    Pe: function() {
                        return p
                    },
                    fi: function() {
                        return c
                    },
                    jq: function() {
                        return u
                    },
                    z5: function() {
                        return f
                    },
                    zz: function() {
                        return d
                    }
                });
                var i = s(22222),
                    n = s(49756),
                    r = s(55974),
                    o = s(99005),
                    a = s(20849),
                    u = e => e.iab.consentStringPresentFromStorage,
                    d = (0, i.P1)((e => e.consent.updated), n.Z),
                    l = e => e.iab.decodedAdditionalConsent,
                    p = (0, i.P1)((e => e.consent.sync), n.Z),
                    c = e => e.tokenUserAuthParams,
                    f = e => {
                        var t = (0, r.hg)([...o.i.value, ...a.J.value]),
                            s = e.disabled.filter((e => -1 === t.indexOf(e)));
                        return {
                            enabledVendors: [...e.enabled, ...t],
                            disabledVendors: s
                        }
                    }
            },
            78461: function(e, t, s) {
                "use strict";
                s.d(t, {
                    NK: function() {
                        return f
                    },
                    Q$: function() {
                        return T
                    },
                    QH: function() {
                        return A
                    },
                    Rh: function() {
                        return P
                    },
                    Tq: function() {
                        return _
                    },
                    do: function() {
                        return v
                    },
                    vr: function() {
                        return k
                    }
                });
                var i = s(22222),
                    n = s(26926),
                    r = s(48766),
                    o = s(4108),
                    a = s(55974),
                    u = s(3370),
                    d = s(90327),
                    l = s(95071),
                    p = s(25010),
                    c = s(75211);

                function f(e) {
                    return (0, n.U2)(e, "consent")
                }

                function v(e) {
                    return (0, n.U2)(e, "iab.consentString")
                }

                function h(e) {
                    return (0, n.U2)(e, "consent.purposes.enabled", [])
                }

                function g(e) {
                    return (0, n.U2)(e, "consent.vendors.enabled", [])
                }

                function m(e) {
                    return (0, n.U2)(e, "consent.purposes_li.enabled", [])
                }

                function b(e) {
                    return (0, n.U2)(e, "consent.vendors_li.enabled", [])
                }
                var S = (0, i.P1)([h, m, o.sN], ((e, t, s) => {
                        var i = (0, a.hg)([...e, ...t, ...p.P.value]),
                            n = s.filter((e => -1 === i.indexOf(e)));
                        return {
                            enabled: i,
                            disabled: n
                        }
                    })),
                    C = (0, i.P1)([g, function(e) {
                        return (0, n.U2)(e, "consent.vendors.disabled", [])
                    }, function(e) {
                        return (0, n.U2)(e, "consent.vendors_li.enabled", [])
                    }, function(e) {
                        return (0, n.U2)(e, "consent.vendors_li.disabled", [])
                    }], ((e, t, s, i) => (0, a.hg)([...e, ...t, ...s, ...i, ...l.O.value]))),
                    y = (0, i.P1)([h, g, C], ((e, t, s) => {
                        var i = t.filter((t => {
                                var s;
                                return !(null == (s = u.I.value) || !s[t]) && (0, c.L)(u.I.value[t].purposeIds, [...e, ...p.P.value])
                            })),
                            n = s.filter((e => -1 === i.indexOf(e)));
                        return {
                            enabled: i,
                            disabled: n
                        }
                    })),
                    w = (0, i.P1)([m, b, C], ((e, t, s) => {
                        var i = t.filter((t => {
                                var s;
                                return !(null == (s = u.I.value) || !s[t]) && (0, c.L)((0, n.Ri)(u.I.value[t].legIntPurposeIds), [...e, ...p.P.value])
                            })),
                            r = s.filter((e => -1 === i.indexOf(e)));
                        return {
                            enabled: i,
                            disabled: r
                        }
                    })),
                    I = (0, i.P1)([h, m, g, b, C], ((e, t, s, i, r) => {
                        var o = (0, a.hg)([...s, ...i]).filter((s => {
                                var i;
                                if (null != (i = u.I.value) && i[s]) {
                                    var r = [...(0, n.Ri)(u.I.value[s].purposeIds), ...(0, n.Ri)(u.I.value[s].legIntPurposeIds)],
                                        o = [...e, ...t, ...p.P.value];
                                    return (0, c.L)(r, o)
                                }
                                return !1
                            })),
                            d = r.filter((e => -1 === o.indexOf(e)));
                        return {
                            enabled: o,
                            disabled: d
                        }
                    })),
                    _ = (0, i.P1)([f, v, r.L8, S, I, y, w], ((e, t, s, i, r, o, a) => ({
                        purposes: {
                            consent: {
                                enabled: (0, n.U2)(e, "purposes.enabled"),
                                disabled: (0, n.U2)(e, "purposes.disabled")
                            },
                            legitimate_interest: {
                                enabled: (0, n.U2)(e, "purposes_li.enabled"),
                                disabled: (0, n.U2)(e, "purposes_li.disabled")
                            },
                            global: i,
                            essential: p.P.value
                        },
                        vendors: {
                            consent: {
                                enabled: (0, n.U2)(e, "vendors.enabled"),
                                disabled: (0, n.U2)(e, "vendors.disabled")
                            },
                            legitimate_interest: {
                                enabled: (0, n.U2)(e, "vendors_li.enabled"),
                                disabled: (0, n.U2)(e, "vendors_li.disabled")
                            },
                            global: r,
                            global_consent: o,
                            global_li: a
                        },
                        user_id: e.user_id,
                        created: e.created,
                        updated: e.updated,
                        consent_string: t,
                        addtl_consent: s
                    }))),
                    P = (0, i.P1)([f], (e => {
                        var t, s = [],
                            i = null == (t = d.L.value) ? void 0 : t.map((e => {
                                var {
                                    id: t
                                } = e;
                                return t
                            })),
                            {
                                vendors: r,
                                vendors_li: o
                            } = e,
                            a = e => -1 !== i.indexOf(e),
                            u = r.enabled.filter(a),
                            l = o.enabled.filter(a);
                        for (var p of d.L.value) {
                            var c = p.purposeIds.length > 0,
                                f = p.legIntPurposeIds.length > 0;
                            (c || f) && (c && -1 === u.indexOf(p.id) || f && -1 === l.indexOf(p.id) || s.push((0, n.U2)(p, "namespaces.google.id")))
                        }
                        return s.filter(((e, t) => s.indexOf(e) == t))
                    })),
                    A = e => (0, n.U2)(e.cookies.thirdPartyCookiesData, "iabConsentString"),
                    k = e => e.cookies.localCookiesData.iabConsentString,
                    T = e => !0 === e.cookies.secure
            },
            14119: function(e, t, s) {
                "use strict";
                s.d(t, {
                    $P: function() {
                        return c
                    },
                    Ex: function() {
                        return v
                    },
                    PR: function() {
                        return u
                    },
                    _e: function() {
                        return a
                    },
                    cY: function() {
                        return f
                    },
                    eN: function() {
                        return d
                    },
                    kw: function() {
                        return l
                    },
                    s_: function() {
                        return p
                    }
                });
                var i = s(22222),
                    n = s(48766),
                    r = s(4108),
                    o = s(71409),
                    a = e => !0 === e.user.isBot,
                    u = e => e.user || {},
                    d = e => e.user.synchronizedUsers,
                    l = e => e.user.dcsUser,
                    p = (0, i.P1)((e => e.user.ignoreConsentBefore), n.zz, ((e, t) => !!(e && e < new Date && t < e))),
                    c = (e, t) => ((e, t) => (0, i.P1)(r.NV, (e => (0, o.pw)(t, e)))(e))(e, t) || ((e, t) => (0, i.P1)(r.bo, (e => (0, o.pw)(t, e) && (0, o.xi)(t)))(e))(e, t),
                    f = e => e.user.organizationUserId,
                    v = e => {
                        var {
                            user: {
                                organizationUserId: t,
                                organizationUserIdAuthAlgorithm: s,
                                organizationUserIdAuthSid: i,
                                organizationUserIdAuthSalt: n,
                                organizationUserIdAuthDigest: r,
                                organizationUserIdExp: o,
                                organizationUserIdIv: a
                            }
                        } = e;
                        return {
                            organizationUserId: t,
                            organizationUserIdAuthAlgorithm: s,
                            organizationUserIdAuthSid: i,
                            organizationUserIdAuthSalt: n,
                            organizationUserIdAuthDigest: r,
                            organizationUserIdExp: o,
                            organizationUserIdIv: a
                        }
                    }
            },
            4108: function(e, t, s) {
                "use strict";
                s.d(t, {
                    AT: function() {
                        return h
                    },
                    Ax: function() {
                        return E
                    },
                    Be: function() {
                        return C
                    },
                    EC: function() {
                        return T
                    },
                    Eh: function() {
                        return L
                    },
                    G9: function() {
                        return y
                    },
                    I9: function() {
                        return f
                    },
                    NV: function() {
                        return A
                    },
                    Q2: function() {
                        return v
                    },
                    Qj: function() {
                        return b
                    },
                    T5: function() {
                        return O
                    },
                    _0: function() {
                        return S
                    },
                    bh: function() {
                        return I
                    },
                    bo: function() {
                        return k
                    },
                    f$: function() {
                        return D
                    },
                    jo: function() {
                        return m
                    },
                    jw: function() {
                        return V
                    },
                    m6: function() {
                        return P
                    },
                    q6: function() {
                        return p
                    },
                    rr: function() {
                        return c
                    },
                    sN: function() {
                        return _
                    },
                    th: function() {
                        return U
                    },
                    uE: function() {
                        return x
                    },
                    wG: function() {
                        return g
                    }
                });
                var i = s(87462),
                    n = s(22222),
                    r = s(44071),
                    o = s(55974),
                    a = s(86889),
                    u = s(25010),
                    d = s(92308),
                    l = s(92171),
                    p = e => e.website.enabledTCFAPIErrorLogging,
                    c = e => e.website.google.additionalConsent.positive,
                    f = e => e.website.google.additionalConsent.negative,
                    v = e => e.website.google.fullATP,
                    h = e => e.website.tcfEnabled,
                    g = () => {
                        var e;
                        return null == (e = l.s.value) ? void 0 : e.filter((e => !u.P.value.includes(e)))
                    },
                    m = () => {
                        var e = [];
                        for (var t of a.r.value)
                            if (Array.isArray(t.purposeIds))
                                for (var s of t.purposeIds) - 1 !== e.indexOf(s) || d.$.value.includes(s) || e.push(s);
                        return e
                    },
                    b = () => {
                        var e = [];
                        for (var t of a.r.value)
                            if (Array.isArray(t.legIntPurposeIds))
                                for (var s of t.legIntPurposeIds) - 1 !== e.indexOf(s) || d.$.value.includes(s) || e.push(s);
                        return e
                    },
                    S = (0, n.P1)(m, (e => e.map((e => (0, i.Z)({}, r.s.value[e], {
                        legalBasis: "consent"
                    }))).filter((e => {
                        var {
                            id: t
                        } = e;
                        return t
                    })))),
                    C = (0, n.P1)(b, (e => e.map((e => (0, i.Z)({}, r.s.value[e], {
                        legalBasis: "legitimate_interest"
                    }))).filter((e => {
                        var {
                            id: t
                        } = e;
                        return t
                    })))),
                    y = (0, n.P1)(m, b, ((e, t) => {
                        var s = [...e, ...t];
                        return l.s.value.filter((e => -1 === s.indexOf(e))).map((e => (0, i.Z)({}, r.s.value[e], {
                            legalBasis: "consent"
                        }))).filter((e => {
                            var {
                                id: t
                            } = e;
                            return t
                        }))
                    })),
                    w = (0, n.P1)(y, (e => e.map((e => d.$.value.includes(e.id) ? null : e.id)).filter((e => null != e)))),
                    I = (0, n.P1)(b, (e => e.filter((e => !u.P.value.includes(e))))),
                    _ = (0, n.P1)(b, m, w, ((e, t, s) => (0, o.hg)([...e, ...t, ...s, ...u.P.value]))),
                    P = e => e.website.publisherCountryCode,
                    A = e => e.website.consentDuration,
                    k = e => e.website.deniedConsentDuration,
                    T = (0, n.P1)(A, (e => e / 86400)),
                    E = e => e.website.deploymentId,
                    L = (0, n.P1)((e => {
                        var t;
                        return null == (t = e.website) ? void 0 : t.customDomain
                    }), (e => {
                        var t, s, i;
                        return null == (t = e.events) || null == (s = t.template) || null == (i = s.source) ? void 0 : i.domain
                    }), ((e, t) => e || t || location.host || "com.app.generic")),
                    U = ((0, n.P1)((e => {
                        var t;
                        return null == (t = e.website) ? void 0 : t.version
                    }), (e => void 0 !== e)), e => {
                        var t, s, i;
                        return null == (t = e.website) || null == (s = t.regulation) || null == (i = s.group) ? void 0 : i.name
                    }),
                    O = (0, n.P1)(U, (e => "mixed" === e)),
                    x = (0, n.P1)(U, (e => "optin" === e)),
                    D = (0, n.P1)(U, (e => "optout" === e)),
                    V = e => {
                        var t;
                        return null == (t = e.website) ? void 0 : t.ouidAsPrimaryIfPresent
                    }
            },
            58027: function(e, t, s) {
                "use strict";
                s.d(t, {
                    Nw: function() {
                        return ae
                    },
                    fw: function() {
                        return ce
                    },
                    cr: function() {
                        return pe
                    }
                });
                var i = {};
                s.r(i), s.d(i, {
                    actions: function() {
                        return A
                    },
                    initialState: function() {
                        return P
                    }
                });
                var n = {};
                s.r(n), s.d(n, {
                    actions: function() {
                        return T
                    },
                    initialState: function() {
                        return k
                    }
                });
                var r = {};
                s.r(r), s.d(r, {
                    actions: function() {
                        return L
                    },
                    initialState: function() {
                        return E
                    }
                });
                var o = {};
                s.r(o), s.d(o, {
                    actions: function() {
                        return O
                    },
                    initialState: function() {
                        return U
                    }
                });
                var a = {};
                s.r(a), s.d(a, {
                    actions: function() {
                        return D
                    },
                    initialState: function() {
                        return x
                    }
                });
                var u = {};
                s.r(u), s.d(u, {
                    actions: function() {
                        return R
                    },
                    initialState: function() {
                        return V
                    }
                });
                var d = {};
                s.r(d), s.d(d, {
                    actions: function() {
                        return F
                    },
                    initialState: function() {
                        return N
                    }
                });
                var l = {};
                s.r(l), s.d(l, {
                    actions: function() {
                        return M
                    },
                    initialState: function() {
                        return B
                    }
                });
                var p = {};
                s.r(p), s.d(p, {
                    actions: function() {
                        return z
                    },
                    initialState: function() {
                        return j
                    }
                });
                var c = {};
                s.r(c), s.d(c, {
                    actions: function() {
                        return G
                    },
                    initialState: function() {
                        return Z
                    }
                });
                var f = {};
                s.r(f), s.d(f, {
                    actions: function() {
                        return W
                    },
                    initialState: function() {
                        return H
                    }
                });
                var v = {};
                s.r(v), s.d(v, {
                    actions: function() {
                        return J
                    },
                    initialState: function() {
                        return K
                    }
                });
                var h = {};
                s.r(h), s.d(h, {
                    actions: function() {
                        return $
                    },
                    initialState: function() {
                        return Q
                    }
                });
                var g = {};
                s.r(g), s.d(g, {
                    actions: function() {
                        return X
                    },
                    initialState: function() {
                        return Y
                    }
                });
                var m = {};
                s.r(m), s.d(m, {
                    actions: function() {
                        return te
                    },
                    initialState: function() {
                        return ee
                    }
                });
                var b = {};
                s.r(b), s.d(b, {
                    actions: function() {
                        return ie
                    },
                    initialState: function() {
                        return se
                    }
                });
                var S = {};
                s.r(S), s.d(S, {
                    actions: function() {
                        return re
                    },
                    initialState: function() {
                        return ne
                    }
                });
                var C = s(94798),
                    y = s.n(C),
                    w = s(27867),
                    I = (s(91042), s(61218), s(26926)),
                    _ = s(87462),
                    P = {
                        user: {
                            isBot: !1,
                            authToken: null,
                            organizationId: null,
                            organizationUserId: null,
                            bots: {
                                consentRequired: !0,
                                types: ["crawlers", "performance"],
                                extraUserAgents: []
                            },
                            externalConsent: {
                                enabled: !1,
                                value: null
                            },
                            ignoreConsentBefore: null,
                            organizationUserIdAuthAlgorithm: null,
                            organizationUserIdAuthSid: null,
                            organizationUserIdAuthSalt: null,
                            organizationUserIdAuthDigest: null,
                            organizationUserIdExp: null,
                            organizationUserIdIv: null,
                            synchronizedUsers: [],
                            dcsUser: null
                        }
                    },
                    A = () => ({
                        setUserConfig: (e, t) => (0, _.Z)({}, e, {
                            user: (0, I.ZB)(e.user || {}, t)
                        }),
                        setUserId: (e, t) => (0, _.Z)({}, e, {
                            user: (0, _.Z)({}, e.user, {
                                id: t
                            })
                        })
                    }),
                    k = {
                        sync: {
                            enabled: !1,
                            delayNotice: !0,
                            timeout: 3e3,
                            frequency: 86400
                        }
                    },
                    T = () => ({
                        setSyncConfig: (e, t) => (0, _.Z)({}, e, {
                            sync: (0, I.ZB)(e.sync, t)
                        })
                    }),
                    E = {
                        consentNotice: {
                            show: !1,
                            showOnUILoad: !1
                        }
                    },
                    L = () => ({
                        showConsentNotice: e => ({
                            consentNotice: (0, _.Z)({}, e.consentNotice, {
                                show: !0
                            })
                        }),
                        showConsentNoticeOnLoad: e => ({
                            consentNotice: (0, _.Z)({}, e.consentNotice, {
                                showOnUILoad: !0
                            })
                        }),
                        hideConsentNotice: e => ({
                            consentNotice: (0, _.Z)({}, e.consentNotice, {
                                show: !1,
                                showOnUILoad: !1
                            })
                        }),
                        setConsentNoticeConfig: (e, t) => ({
                            consentNotice: (0, I.rd)(e.consentNotice, t)
                        })
                    }),
                    U = {
                        consentPopup: {
                            enable: !0,
                            open: !1,
                            defaultChoice: void 0,
                            enableAllButtons: !0,
                            showWhenConsentIsMissing: !1,
                            canCloseWhenConsentIsMissing: !0,
                            view: "preferences",
                            preferencesView: "purposes",
                            information: {
                                enable: !1,
                                content: {
                                    text: {}
                                }
                            },
                            denyAppliesToLI: !0,
                            controlType: void 0,
                            combineLIAndConsent: !1,
                            content: {
                                instructions: void 0
                            }
                        }
                    },
                    O = () => ({
                        hideConsentPopup: e => ({
                            consentPopup: (0, _.Z)({}, e.consentPopup, {
                                open: !1
                            })
                        }),
                        showConsentPopup: e => ({
                            consentPopup: (0, _.Z)({}, e.consentPopup, {
                                open: !0
                            })
                        }),
                        switchViewConsentPopup: (e, t) => ({
                            consentPopup: (0, _.Z)({}, e.consentPopup, {
                                view: t
                            })
                        }),
                        switchPreferencesViewConsentPopup: (e, t) => ({
                            consentPopup: (0, _.Z)({}, e.consentPopup, {
                                preferencesView: t
                            })
                        }),
                        setConsentPopupConfig: (e, t) => ({
                            consentPopup: (0, I.rd)(e.consentPopup, t)
                        })
                    }),
                    x = {
                        ctvPreferences: {}
                    },
                    D = () => ({
                        setCtvPreferencesConfig: (e, t) => ({
                            ctvPreferences: (0, I.rd)(e.ctvPreferences, t)
                        })
                    }),
                    V = {
                        website: {
                            name: null,
                            apiKey: null,
                            providerKey: null,
                            privacyPolicyURL: null,
                            ignoreCountry: !1,
                            purposes: [],
                            disabledPurposes: [],
                            vendors: [],
                            customSDK: null,
                            enableGlobalConsentForAllVendorsAndPurposes: !1,
                            alwaysDisplayActionButtons: !1,
                            regulations: {
                                ccpa: {
                                    enabled: !1
                                },
                                gdpr: {
                                    enabled: !0,
                                    additionalCountries: []
                                }
                            },
                            openDialogsCount: 0,
                            iabTCFCMPID: s(23605).t.defaultCMPID,
                            enabledTCFAPIErrorLogging: !1,
                            google: {
                                additionalConsent: {
                                    positive: null,
                                    negative: null
                                },
                                fullATP: !1
                            },
                            publisherCountryCode: null,
                            consentDuration: 31622400,
                            consentString: void 0,
                            vendorsIdToNumMap: void 0,
                            purposesNumToIdMap: void 0,
                            purposesIdToNumMap: void 0,
                            ouidAsPrimaryIfPresent: !1,
                            tcfEnabled: void 0,
                            tcfVersion: null
                        }
                    },
                    R = () => ({
                        setIgnoreCountry: (e, t) => ({
                            website: (0, I.rd)(e.website, {
                                ignoreCountry: t
                            })
                        }),
                        setPrivacyPolicyURL: (e, t) => ({
                            website: (0, I.rd)(e.website, {
                                privacyPolicyURL: t
                            })
                        }),
                        setWebsiteConfig: (e, t) => ({
                            website: (0, I.rd)(e.website, t)
                        }),
                        setProviderKey: (e, t) => ({
                            website: (0, I.rd)(e.website, {
                                providerKey: t
                            })
                        }),
                        setAPIKey: (e, t) => ({
                            website: (0, I.rd)(e.website, {
                                apiKey: t
                            })
                        }),
                        setOpenDialogsCount: (e, t) => ({
                            website: (0, I.rd)(e.website, {
                                openDialogsCount: t
                            })
                        })
                    }),
                    N = {
                        experiment: {
                            config: null,
                            id: null,
                            size: null,
                            group: null,
                            startDate: null
                        }
                    },
                    F = () => ({
                        setExperimentConfig: (e, t) => ({
                            experiment: (0, _.Z)({}, e.experiment, {
                                config: t
                            })
                        }),
                        setExperimentGroup: (e, t) => ({
                            experiment: (0, _.Z)({}, e.experiment, {
                                group: t
                            })
                        }),
                        setExperimentID: (e, t) => ({
                            experiment: (0, _.Z)({}, e.experiment, {
                                id: t
                            })
                        }),
                        setExperimentSize: (e, t) => ({
                            experiment: (0, _.Z)({}, e.experiment, {
                                size: t
                            })
                        }),
                        setExperimentStartDate: (e, t) => ({
                            experiment: (0, _.Z)({}, e.experiment, {
                                startDate: t
                            })
                        })
                    }),
                    B = {
                        cookies: {
                            storageSources: {
                                cookies: !0,
                                localStorage: !0
                            },
                            isSameSiteRequired: (0, s(97758).vg)(window),
                            secure: !1
                        }
                    },
                    M = () => ({
                        setStorageConfig: (e, t) => ({
                            cookies: (0, I.rd)(e.cookies, t)
                        })
                    }),
                    j = {
                        cookies: {
                            group: {
                                enabled: !1,
                                customDomain: null
                            },
                            thirdPartyCookiesData: null
                        }
                    },
                    z = () => ({
                        setThirdPartyCookiesConfig: (e, t) => ({
                            cookies: (0, I.rd)(e.cookies, t)
                        }),
                        setThirdPartyCookiesData: (e, t) => ({
                            cookies: (0, I.rd)(e.cookies, {
                                thirdPartyCookiesData: t
                            })
                        })
                    }),
                    Z = {
                        cookies: {
                            local: {
                                customDomain: (0, s(76192).Gx)(document.location.hostname)
                            },
                            localCookiesData: {}
                        }
                    },
                    G = () => ({
                        setLocalCookiesConfig: (e, t) => ({
                            cookies: (0, I.rd)(e.cookies, t)
                        }),
                        setLocalCookiesData: (e, t) => ({
                            cookies: (0, I.rd)(e.cookies, {
                                localCookiesData: t
                            })
                        })
                    }),
                    q = s(61122),
                    H = {
                        remoteConsents: {},
                        pendingConsents: {},
                        isUserAuthenticated: !1,
                        callbackURL: null,
                        authProtocol: null
                    },
                    W = () => ({
                        loadRemoteConsents: (e, t) => (0, _.Z)({}, e, {
                            remoteConsents: (0, I.rd)(e.remoteConsents, t)
                        }),
                        setUserAuthenticated: (e, t) => (0, _.Z)({}, e, {
                            isUserAuthenticated: t
                        }),
                        setCallbackURL: (e, t) => (0, _.Z)({}, e, {
                            callbackURL: t
                        }),
                        setAuthProtocol: (e, t) => (0, _.Z)({}, e, {
                            authProtocol: t
                        }),
                        setRemoteConsents: (e, t) => (0, _.Z)({}, e, {
                            remoteConsents: (0, _.Z)({}, e.remoteConsents, {
                                consents: (0, I.rd)(e.remoteConsents.consents, t)
                            })
                        }),
                        setPendingConsent: (e, t) => {
                            var {
                                purposeId: s,
                                preferenceId: i,
                                channelId: n,
                                data: r
                            } = t, o = null, a = null;
                            s ? (o = s, a = "consents.purposes." + s, i && (o += "_" + i, a += ".preferences." + i), n && (o += "_" + n, a += ".channels." + n)) : n && (o = n, a = "consents.channels." + n);
                            var {
                                metadata: u = {},
                                enabled: d
                            } = (0, I.U2)(e.remoteConsents, "" + a, {}), l = {
                                enabled: d,
                                metadata: u
                            };
                            r.metadata = void 0 === r.metadata ? {} : r.metadata;
                            var p = {
                                purposeId: s,
                                preferenceId: i,
                                channelId: n,
                                data: (0, I.rd)((0, I.rd)(l, (0, I.U2)(e.pendingConsents, o + ".data", {})), r)
                            };
                            return JSON.stringify(p.data) !== JSON.stringify(l) ? (0, _.Z)({}, e, {
                                pendingConsents: (0, _.Z)({}, e.pendingConsents, {
                                    [o]: p
                                })
                            }) : e.pendingConsents[o] ? (0, _.Z)({}, e, {
                                pendingConsents: (0, _.Z)({}, Object.keys(e.pendingConsents).filter((e => e !== o)).reduce(((t, s) => (t[s] = e.pendingConsents[s], t)), {}))
                            }) : e
                        },
                        resetPendingConsents: e => (0, _.Z)({}, e, {
                            pendingConsents: {}
                        })
                    }),
                    K = {
                        events: {
                            sampleSizes: {},
                            template: {
                                source: {
                                    type: "sdk-web",
                                    domain: location.host
                                },
                                user: {
                                    agent: navigator.userAgent,
                                    id_type: "uuid"
                                }
                            }
                        }
                    },
                    J = () => ({
                        setEventsConfig: (e, t) => ({
                            events: (0, I.rd)(e.events, t)
                        })
                    }),
                    Q = {
                        ui: {
                            loading: !1,
                            loaded: !1,
                            rendered: !1,
                            module: null
                        }
                    },
                    $ = () => ({
                        loadingUI: e => ({
                            ui: (0, _.Z)({}, e.ui, {
                                loading: !0
                            })
                        }),
                        loadedUI: e => ({
                            ui: (0, _.Z)({}, e.ui, {
                                loaded: !0,
                                loading: !1
                            })
                        }),
                        renderedUI: e => ({
                            ui: (0, _.Z)({}, e.ui, {
                                rendered: !0
                            })
                        }),
                        setUIModule: (e, t) => ({
                            ui: (0, _.Z)({}, e.ui, {
                                module: t
                            })
                        })
                    }),
                    Y = {
                        components: {
                            helpersEnabled: !1,
                            componentsEnabled: !1,
                            version: 1
                        }
                    },
                    X = () => ({
                        setComponentsConfig: (e, t) => ({
                            components: (0, I.rd)(e.components, t)
                        })
                    }),
                    ee = {
                        mixedRegulationPreferences: {
                            spiPurposes: [],
                            categories: [],
                            categoriesState: {},
                            purposesState: {},
                            spiPurposesState: {},
                            allSPIUseState: !1,
                            vendors: [],
                            allVendorsState: !0,
                            vendorsState: {}
                        }
                    },
                    te = () => ({
                        setSPIPurposes: (e, t) => ({
                            mixedRegulationPreferences: (0, _.Z)({}, e.mixedRegulationPreferences, {
                                spiPurposes: t
                            })
                        }),
                        setPurposeState: (e, t, s) => ({
                            mixedRegulationPreferences: (0, _.Z)({}, e.mixedRegulationPreferences, {
                                purposesState: (0, _.Z)({}, e.mixedRegulationPreferences.purposesState, {
                                    [t]: s
                                })
                            })
                        }),
                        setSPIPurposesState: (e, t, s) => ({
                            mixedRegulationPreferences: (0, _.Z)({}, e.mixedRegulationPreferences, {
                                spiPurposesState: (0, _.Z)({}, e.mixedRegulationPreferences.spiPurposesState, {
                                    [t]: s
                                })
                            })
                        }),
                        setCategoryState: (e, t, s) => {
                            var i;
                            return {
                                mixedRegulationPreferences: (0, _.Z)({}, e.mixedRegulationPreferences, {
                                    categoriesState: (0, _.Z)({}, null == (i = e.mixedRegulationPreferences) ? void 0 : i.categoriesState, {
                                        [t]: s
                                    })
                                })
                            }
                        },
                        setVendorState: (e, t, s) => ({
                            mixedRegulationPreferences: (0, _.Z)({}, e.mixedRegulationPreferences, {
                                vendorsState: (0, _.Z)({}, e.mixedRegulationPreferences.vendorsState, {
                                    [t]: s
                                })
                            })
                        }),
                        setAllVendorsState: (e, t) => ({
                            mixedRegulationPreferences: (0, _.Z)({}, e.mixedRegulationPreferences, {
                                allVendorsState: t
                            })
                        }),
                        setAllSPIUseState: (e, t) => ({
                            mixedRegulationPreferences: (0, _.Z)({}, e.mixedRegulationPreferences, {
                                allSPIUseState: t
                            })
                        }),
                        setVendors: (e, t) => ({
                            mixedRegulationPreferences: (0, _.Z)({}, e.mixedRegulationPreferences, {
                                vendors: t
                            })
                        }),
                        setCategories: (e, t) => ({
                            mixedRegulationPreferences: (0, _.Z)({}, e.mixedRegulationPreferences, {
                                categories: t
                            })
                        })
                    }),
                    se = {
                        ced: {
                            loaded: !1,
                            loading: !1
                        }
                    },
                    ie = () => ({
                        loadingCED: e => ({
                            ced: (0, _.Z)({}, e.ced, {
                                loading: !0
                            })
                        }),
                        loadedCED: e => ({
                            ced: (0, _.Z)({}, e.ced, {
                                loaded: !0,
                                loading: !1
                            })
                        })
                    }),
                    ne = {
                        signature: {
                            dcsUserId: null,
                            value: null
                        }
                    },
                    re = () => ({
                        setSignature: (e, t) => ({
                            signature: {
                                dcsUserId: t.dcsUserId,
                                value: t.signature
                            }
                        })
                    }),
                    oe = [i, n, r, o, a, u, d, l, p, c, q, f, v, h, g, m, b, S],
                    ae = {};
                for (var ue of oe) ae[Object.keys(ue.initialState)[0]] = ue.actions;

                function de(e) {
                    var t = {};
                    for (var s of oe)(0, I.ZB)(t, (0, w.kv)(s.actions, e));
                    return t
                }
                var le = function(e) {
                        var t = e || function() {
                                var e = {};
                                for (var t of oe)(0, I.ZB)(e, t.initialState);
                                return e
                            }(),
                            s = y()(t, []);
                        return {
                            store: s,
                            actions: de(s)
                        }
                    }(),
                    pe = le.store,
                    ce = le.actions
            },
            55974: function(e, t, s) {
                "use strict";
                s.d(t, {
                    B9: function() {
                        return n
                    },
                    hg: function() {
                        return i
                    }
                });
                var i = e => {
                        var t = [];
                        return new Set(e).forEach((e => t.push(e))), t
                    },
                    n = e => {
                        if (!(e.length < 1)) {
                            var t = e[0];
                            return e.some((e => e !== t)) ? null : t
                        }
                    }
            },
            97758: function(e, t, s) {
                "use strict";
                s.d(t, {
                    dH: function() {
                        return o
                    },
                    pD: function() {
                        return r
                    },
                    vg: function() {
                        return n
                    }
                });
                var i = /Chrome\/([0-9]{2,3})\./i;

                function n(e) {
                    return function(e) {
                        var t = e.chrome,
                            s = e.navigator,
                            i = s.vendor,
                            n = void 0 !== e.opr,
                            r = s.userAgent.indexOf("Edge") > -1;
                        return !s.userAgent.match("CriOS") && null != t && "Google Inc." === i && !1 === n && !1 === r
                    }(e) && (t = e.navigator.userAgent, ((s = i.exec(t)) ? parseInt(s[1], 10) : null) >= 79);
                    var t, s
                }

                function r() {
                    return !("function" == typeof Set && "function" == typeof Symbol && "function" == typeof Object.assign && "function" == typeof [].find && "function" == typeof [].flatMap && "function" == typeof Array.from && "function" == typeof Promise && "function" == typeof [].includes && "function" == typeof Number.isInteger && "function" == typeof "".repeat && "function" == typeof WeakSet && "function" == typeof Object.values && "function" == typeof "".includes && "function" == typeof "".startsWith && "function" == typeof(new class extends class {} {
                        method() {}
                    }).method && 1 === new Map([
                        ["key", "value"]
                    ]).size)
                }

                function o() {
                    return "function" != typeof Object.defineProperty || "function" != typeof Object.hasOwn || "function" != typeof "".replaceAll
                }
            },
            60457: function(e, t, s) {
                "use strict";
                s.d(t, {
                    SH: function() {
                        return a
                    }
                });
                var i = e => e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#039;"),
                    n = e => {
                        if ("object" == typeof e) {
                            var t = JSON.stringify(e);
                            return JSON.parse(i(t))
                        }
                        return "string" == typeof e ? i(e) : e
                    };

                function r(e) {
                    return Array.isArray(e) ? e.map((e => n(e))) : "string" == typeof e ? n(e) : e
                }

                function o(e, t, s, i) {
                    if (i && i.data) {
                        var n, o = "string" == typeof i.data;
                        try {
                            n = o ? JSON.parse(i.data) : i.data
                        } catch (e) {
                            return
                        }
                        if (n[e]) {
                            var a = n[e];
                            s(a.command, r(a.parameter), ((e, s) => {
                                var n = {
                                    [t]: {
                                        returnValue: e,
                                        success: s,
                                        callId: a.callId
                                    }
                                };
                                i.source && "function" == typeof i.source.postMessage ? i.source.postMessage(o ? JSON.stringify(n) : n, "*") : window.postMessage(o ? JSON.stringify(n) : n, "*")
                            }))
                        }
                    }
                }

                function a(e, t, s, i) {
                    if (window.addEventListener ? window.addEventListener("message", o.bind(this, e, t, s), !1) : window.attachEvent("onmessage", o.bind(this, e, t, s)), window.DidomiSanitizing = {
                            sanitizeString: r
                        }, Array.isArray(i) && i.length > 0)
                        for (var n of i) s(n.command, r(n.parameter), n.callback, n.version, !0)
                }
            },
            23605: function(e, t, s) {
                "use strict";
                s.d(t, {
                    t: function() {
                        return i
                    }
                });
                var i = {
                    defaultTCFVersion: 2,
                    IABPolicyUrl: "https://iabeurope.eu/iab-europe-transparency-consent-framework-policies/",
                    tcfVersion2_2: 2.2,
                    defaultCMPID: 7,
                    defaultCMPVersion: 1,
                    didomiConsentStringSchemaMinorVersion: 1,
                    didomiConsentStringSchemaMajorVersion: 2
                }
            },
            49756: function(e, t, s) {
                "use strict";
                s.d(t, {
                    F: function() {
                        return r
                    },
                    Z: function() {
                        return n
                    }
                });
                var i = new RegExp("([0-9]{4})(-([0-9]{2})(-([0-9]{2})(T([0-9]{2}):([0-9]{2})(:([0-9]{2})(\\.([0-9]+))?)?(Z|(([-+])([0-9]{2}):([0-9]{2})))?)?)?)?");

                function n(e) {
                    if ("string" != typeof e) return null;
                    var t = e.match(i);
                    if (null === t) return null;
                    var s = 0,
                        n = new Date(t[1], 0, 1);
                    t[3] && n.setMonth(t[3] - 1), t[5] && n.setDate(t[5]), t[7] && n.setHours(t[7]), t[8] && n.setMinutes(t[8]), t[10] && n.setSeconds(t[10]), t[12] && n.setMilliseconds(1e3 * ("0." + t[12])), t[14] && (s = 60 * t[16] + parseInt(t[17], 10), s *= "-" === t[15] ? 1 : -1), s -= n.getTimezoneOffset();
                    var r = n.getTime() + 60 * s * 1e3;
                    return new Date(r)
                }

                function r(e, t) {
                    void 0 === t && (t = 13);
                    var s = n(e);
                    if (!s) return !0;
                    var i = (new Date).getTime() - s.getTime();
                    return i > 0 && i >= 30 * t * 864e5
                }
            },
            23561: function(e, t, s) {
                "use strict";
                s.d(t, {
                    aB: function() {
                        return n
                    },
                    j7: function() {
                        return r
                    }
                });
                var i = s(26926),
                    n = e => (0, i.hj)(e) && e > 0,
                    r = e => null == e ? void 0 : e.sort(((e, t) => {
                        var {
                            name: s
                        } = e, {
                            name: i
                        } = t;
                        return s.localeCompare(i)
                    }))
            },
            16619: function(e, t, s) {
                "use strict";
                s.d(t, {
                    DL: function() {
                        return v
                    },
                    GY: function() {
                        return p
                    },
                    MB: function() {
                        return h
                    },
                    OE: function() {
                        return S
                    },
                    Xo: function() {
                        return b
                    },
                    eb: function() {
                        return l
                    },
                    f3: function() {
                        return a
                    },
                    nU: function() {
                        return d
                    },
                    o7: function() {
                        return n
                    },
                    oM: function() {
                        return o
                    },
                    q1: function() {
                        return r
                    },
                    rP: function() {
                        return m
                    },
                    ry: function() {
                        return u
                    },
                    x1: function() {
                        return c
                    },
                    x6: function() {
                        return g
                    },
                    xf: function() {
                        return f
                    }
                });
                var i = s(26926),
                    n = {
                        Cookies: "cookies",
                        CookiesAnalytics: "cookies_analytics",
                        CookiesMarketing: "cookies_marketing",
                        CookiesSocial: "cookies_social",
                        AdvertisingPersonalization: "advertising_personalization",
                        Analytics: "analytics",
                        ContentPersonalization: "content_personalization",
                        AdDelivery: "ad_delivery",
                        DeviceAccess: "device_access",
                        OfflineMatch: "offline_match",
                        LinkDevices: "link_devices",
                        PreciseGeo: "precise_geo",
                        SelectBasicAds: "select_basic_ads",
                        CreateAdsProfile: "create_ads_profile",
                        SelectPersonalizedAds: "select_personalized_ads",
                        CreateContentProfile: "create_content_profile",
                        SelectPersonalizedContent: "select_personalized_content",
                        MeasureAdPerformance: "measure_ad_performance",
                        MeasureContentPerformance: "measure_content_performance",
                        MarketResearch: "market_research",
                        ImproveProducts: "improve_products",
                        UseLimitedDataToSelectContent: "use_limited_data_to_select_content"
                    },
                    r = {
                        [n.Cookies]: 1,
                        [n.CookiesAnalytics]: 1,
                        [n.CookiesMarketing]: 1,
                        [n.CookiesSocial]: 1,
                        [n.SelectBasicAds]: 2,
                        [n.CreateAdsProfile]: 3,
                        [n.SelectPersonalizedAds]: 4,
                        [n.CreateContentProfile]: 5,
                        [n.SelectPersonalizedContent]: 6,
                        [n.MeasureAdPerformance]: 7,
                        [n.MeasureContentPerformance]: 8,
                        [n.MarketResearch]: 9,
                        [n.ImproveProducts]: 10,
                        [n.UseLimitedDataToSelectContent]: 11
                    },
                    o = {
                        1: n.Cookies,
                        2: n.SelectBasicAds,
                        3: n.CreateAdsProfile,
                        4: n.SelectPersonalizedAds,
                        5: n.CreateContentProfile,
                        6: n.SelectPersonalizedContent,
                        7: n.MeasureAdPerformance,
                        8: n.MeasureContentPerformance,
                        9: n.MarketResearch,
                        10: n.ImproveProducts,
                        11: n.UseLimitedDataToSelectContent
                    },
                    a = {
                        [n.Cookies]: 1,
                        [n.SelectBasicAds]: 2,
                        [n.CreateAdsProfile]: 3,
                        [n.SelectPersonalizedAds]: 4,
                        [n.CreateContentProfile]: 5,
                        [n.SelectPersonalizedContent]: 6,
                        [n.MeasureAdPerformance]: 7,
                        [n.MeasureContentPerformance]: 8,
                        [n.MarketResearch]: 9,
                        [n.ImproveProducts]: 10
                    };

                function u(e) {
                    for (var t of Object.keys(r))
                        if (String(e) === String(r[t])) return t;
                    return null
                }
                var d = {
                        GeolocationData: "geolocation_data",
                        DeviceCharacteristics: "device_characteristics"
                    },
                    l = {
                        [d.GeolocationData]: 1,
                        [d.DeviceCharacteristics]: 2
                    },
                    p = {
                        1: d.GeolocationData,
                        2: d.DeviceCharacteristics
                    },
                    c = Object.keys(l);
                Object.keys(a);

                function f(e) {
                    return "iab" === e.namespace || !!e.namespaces && (!!e.namespaces.iab || !!e.namespaces.iab2)
                }

                function v(e) {
                    return !!(0, i.U2)(e, "namespaces.google.current")
                }

                function h(e) {
                    if ("iab" === e.namespace) {
                        var t = "number" == typeof e.id ? e.id : parseInt(e.id, 10);
                        if (t) return t
                    } else if (e.namespaces) {
                        if ("number" == typeof e.namespaces.iab) return e.namespaces.iab;
                        if ("number" == typeof e.namespaces.iab2) return e.namespaces.iab2
                    }
                    return null
                }

                function g(e) {
                    for (var t of c)
                        if (String(e) === String(l[t])) return t;
                    return null
                }
                var m = e => (0, i.U2)(r, [e]);

                function b(e, t, s, i, n) {
                    var r = {},
                        o = {};
                    for (var a of s) {
                        var d = a.id;
                        r[d] = !1;
                        var l = u(d);
                        l && (r[d] = -1 !== e.indexOf(l))
                    }
                    for (var p of i) {
                        var c = h(p);
                        c && (o[c] = -1 !== t.indexOf(p.id) || -1 !== t.indexOf(c))
                    }
                    return {
                        iabPurposesStatus: r,
                        iabVendorsStatus: o
                    }
                }
                var S = {
                    google: 755,
                    salesforce: 506
                }
            },
            15813: function(e, t, s) {
                "use strict";
                s.d(t, {
                    j: function() {
                        return n
                    }
                });
                var i = s(67336),
                    n = (e, t, s) => {
                        if (!s || 0 === s.length) return [];
                        var n = ((e, t) => e.flexiblePurposeIds.filter((s => e[t].includes(s))))(e, "req-consent" === t ? "legIntPurposeIds" : "purposeIds");
                        return n.filter((n => {
                            var r = (0, i.E)(n, e.id, "disallow", s),
                                o = (0, i.E)(n, e.id, t, s);
                            return !r && o
                        }))
                    }
            },
            26926: function(e, t, s) {
                "use strict";
                s.d(t, {
                    hc: function() {
                        return h
                    },
                    cO: function() {
                        return g
                    },
                    I8: function() {
                        return p
                    },
                    vZ: function() {
                        return f
                    },
                    ZB: function() {
                        return l
                    },
                    rd: function() {
                        return c
                    },
                    U2: function() {
                        return u()
                    },
                    Ri: function() {
                        return y
                    },
                    Xm: function() {
                        return w
                    },
                    xb: function() {
                        return v
                    },
                    hj: function() {
                        return S
                    },
                    PO: function() {
                        return d
                    },
                    HD: function() {
                        return C
                    },
                    LH: function() {
                        return I
                    },
                    ei: function() {
                        return b
                    },
                    t8: function() {
                        return r
                    },
                    VO: function() {
                        return m
                    }
                });
                var i = s(64063),
                    n = s.n(i);

                function r(e, t, s) {
                    t.split && (t = t.split("."));
                    for (var i, n, r = 0, o = t.length, a = e; r < o && "__proto__" !== (n = t[r++]) && "constructor" !== n && "prototype" !== n;) a = a[n] = r === o ? s : typeof(i = a[n]) == typeof t ? i : 0 * t[r] != 0 || ~("" + t[r]).indexOf(".") ? {} : []
                }
                var o = s(23605),
                    a = s(26905),
                    u = s.n(a);

                function d(e) {
                    return "object" == typeof e && null !== e && e.constructor === Object
                }

                function l(e, t) {
                    for (var s in t) t.hasOwnProperty(s) && (s in e && d(e[s]) && d(t[s]) ? l(e[s], t[s]) : e[s] = t[s]);
                    return e
                }

                function p(e) {
                    return e = "object" == typeof e ? e : {}, JSON.parse(JSON.stringify(e))
                }

                function c(e, t) {
                    return l(p(e), t)
                }

                function f(e, t) {
                    return n()(e, t)
                }

                function v(e) {
                    return e && e.constructor === Object && 0 === Object.keys(e).length
                }

                function h(e) {
                    return Object.keys(e).reduce(((t, s) => t && !e[s]), !0)
                }

                function g(e, t) {
                    if (!Array.isArray(e) || !Array.isArray(t)) return !1;
                    if (e.length !== t.length) return !1;
                    for (var s of e)
                        if (-1 === t.indexOf(s)) return !1;
                    for (var i of t)
                        if (-1 === e.indexOf(i)) return !1;
                    return !0
                }

                function m(e) {
                    return "function" == typeof Object.values ? Object.values(e) : Object.keys(e).map((t => e[t]))
                }

                function b(e, t) {
                    return t.reduce(((t, s) => (e.hasOwnProperty(s) && (t[s] = e[s]), t)), {})
                }

                function S(e) {
                    return !isNaN(e) && ("number" == typeof e || e instanceof Number)
                }

                function C(e) {
                    return "string" == typeof e || e instanceof String
                }

                function y(e) {
                    return Array.isArray(e) ? e : []
                }

                function w(e) {
                    return e ? Object.keys(e).reduce(((t, s) => {
                        if (!0 === e[s]) {
                            var i = Number(s);
                            isNaN(i) || t.push(i)
                        }
                        return t
                    }), []) : []
                }
                var I = e => S(e) && o.t.didomiConsentStringSchemaMinorVersion <= e && e <= o.t.didomiConsentStringSchemaMajorVersion
            },
            40911: function(e, t, s) {
                "use strict";
                s.d(t, {
                    c: function() {
                        return n
                    },
                    y: function() {
                        return r
                    }
                });
                var i = s(15861);

                function n(e, t) {
                    void 0 === t && (t = !1), t ? setTimeout(e, 0) : e()
                }

                function r(e) {
                    return o.apply(this, arguments)
                }

                function o() {
                    return (o = (0, i.Z)((function*(e) {
                        return void 0 === e && (e = !1), e ? new Promise((e => {
                            setTimeout(e, 0)
                        })) : Promise.resolve()
                    }))).apply(this, arguments)
                }
            },
            72424: function(e, t, s) {
                "use strict";

                function i(e) {
                    return "string" != typeof e || 0 === e.indexOf("javascript:") || /^https?:\/\//i.test(e) || (e = "http://" + e), e
                }

                function n(e) {
                    return e.replace(/^https?:\/\//, "")
                }

                function r() {
                    return (new Date).toISOString()
                }

                function o(e) {
                    return new Date(Date.UTC(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate()))
                }

                function a() {
                    return "7e0e4e88d0225db89a578b31aa627050b4ce1e0d"
                }

                function u(e) {
                    var t = Math.round((new Date - e) / 864e5);
                    if (t < 0) throw new Error("The date " + e + " cannot be in the future");
                    return t
                }

                function d() {
                    return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream
                }

                function l(e, t, s) {
                    if (!e || s < t) return !1;
                    var i = 0,
                        n = setInterval((() => {
                            i += t, e((() => clearInterval(n))), i >= s && clearInterval(n)
                        }), t);
                    return !0
                }

                function p(e, t) {
                    void 0 === t && (t = "");
                    var s = {},
                        i = document.createElement("a");
                    i.href = e;
                    for (var n = i.search.substring(1).split("&"), r = 0; r < n.length; r++) {
                        var o = n[r].split("=");
                        if (o[0] && -1 !== o[0].indexOf(t)) try {
                            s[o[0]] = decodeURIComponent(o[1])
                        } catch (e) {
                            console.error('Didomi - Invalid JSON from query-string parameter "' + o[0] + '": ' + e.message)
                        }
                    }
                    return s
                }

                function c(e) {
                    return decodeURI(window.location.search).replace("?", "").split("&").filter(String).map((e => e.split("="))).reduce(((e, t) => {
                        var [s, i] = t;
                        return e[s] = i, e
                    }), {})[e]
                }
                s.d(t, {
                    D6: function() {
                        return u
                    },
                    G4: function() {
                        return r
                    },
                    Ph: function() {
                        return n
                    },
                    X2: function() {
                        return i
                    },
                    Y7: function() {
                        return f
                    },
                    bo: function() {
                        return a
                    },
                    gn: function() {
                        return d
                    },
                    s6: function() {
                        return c
                    },
                    u4: function() {
                        return l
                    },
                    vl: function() {
                        return p
                    },
                    wh: function() {
                        return o
                    }
                });
                var f = e => function() {
                    try {
                        e(...arguments)
                    } catch (e) {
                        console.error("Callback error at TCF API execution", e)
                    }
                }
            },
            76192: function(e, t, s) {
                "use strict";

                function i(e) {
                    var t = ("; " + document.cookie).split("; " + e + "=");
                    return 2 !== t.length ? void 0 : t.pop().split(";").shift()
                }
                s.d(t, {
                    Gx: function() {
                        return o
                    },
                    Nw: function() {
                        return p
                    },
                    Pe: function() {
                        return f
                    },
                    d8: function() {
                        return a
                    },
                    ej: function() {
                        return i
                    },
                    iN: function() {
                        return l
                    },
                    kT: function() {
                        return u
                    },
                    o$: function() {
                        return c
                    },
                    t0: function() {
                        return d
                    }
                });
                var n = "ac|ad|ae|af|ag|ai|al|am|an|ao|aq|ar|as|at|au|aw|ax|az|ba|bb|be|bf|bg|bh|bi|bj|bm|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|cl|cm|cn|co|cr|cu|cv|cw|cx|cz|de|dj|dk|dm|do|dz|ec|ee|eg|es|et|eu|fi|fm|fo|fr|ga|gb|gd|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gs|gt|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|im|in|io|iq|ir|is|it|je|jo|jp|kg|ki|km|kn|kp|kr|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mh|mk|ml|mn|mo|mp|mq|mr|ms|mt|mu|mv|mw|mx|my|na|nc|ne|nf|ng|nl|no|nr|nu|nz|om|pa|pe|pf|ph|pk|pl|pm|pn|pr|ps|pt|pw|py|qa|re|ro|rs|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sx|sy|sz|tc|td|tf|tg|th|tj|tk|tl|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|yt".split("|"),
                    r = "co|com|edu|gov|net|mil|org|nom|sch|caa|res|off|gob|int|tur|ip6|uri|urn|asn|act|nsw|qld|tas|vic|pro|biz|adm|adv|agr|arq|art|ato|bio|bmd|cim|cng|cnt|ecn|eco|emp|eng|esp|etc|eti|far|fnd|fot|fst|g12|ggf|imb|ind|inf|jor|jus|leg|lel|mat|med|mus|not|ntr|odo|ppg|psc|psi|qsl|rec|slg|srv|teo|tmp|trd|vet|zlg|web|ltd|sld|pol|fin|k12|lib|pri|aip|fie|eun|sci|prd|cci|pvt|mod|idv|rel|sex|gen|nic|abr|bas|cal|cam|emr|fvg|laz|lig|lom|mar|mol|pmn|pug|sar|sic|taa|tos|umb|vao|vda|ven|mie|北海道|和歌山|神奈川|鹿児島|ass|rep|tra|per|ngo|soc|grp|plc|its|air|and|bus|can|ddr|jfk|mad|nrw|nyc|ski|spy|tcm|ulm|usa|war|fhs|vgs|dep|eid|fet|fla|flå|gol|hof|hol|sel|vik|cri|iwi|ing|abo|fam|gok|gon|gop|gos|aid|atm|gsm|sos|elk|waw|est|aca|bar|cpa|jur|law|sec|plo|www|bir|cbg|jar|khv|msk|nov|nsk|ptz|rnd|spb|stv|tom|tsk|udm|vrn|cmw|kms|nkz|snz|pub|fhv|red|ens|nat|rns|rnu|bbs|tel|bel|kep|nhs|dni|fed|isa|nsn|gub|e12|tec|орг|обр|упр|alt|nis|jpn|mex|ath|iki|nid|gda|inc".split("|");

                function o(e) {
                    for (var t = (e = e.replace(/^www\./, "")).split("."); t.length > 3;) t.shift();
                    return 3 === t.length && (t[1].length > 2 && t[2].length > 2 || -1 === r.indexOf(t[1]) || t[1].length > 3 && -1 !== n.indexOf(t[2])) && t.shift(), t.join(".")
                }

                function a(e, t, s, i, n, r, o) {
                    var a = new Date;
                    a.setDate(a.getDate() + (s || 365));
                    var u = [e + "=" + t, "expires=" + a.toUTCString(), "path=" + (o || "/")];
                    i && u.push("domain=" + i), n && u.push("SameSite=" + n), !0 === r && "https:" === location.protocol && u.push("Secure"), document.cookie = u.join(";")
                }

                function u(e, t, s) {
                    var i = [e + "=", "expires=Thu, 01 Jan 1970 00:00:01 GMT", "path=" + (s || "/")];
                    t && i.push("domain=" + t), document.cookie = i.join(";")
                }

                function d(e) {
                    return null == e ? void 0 : e.split(".")[0]
                }

                function l(e) {
                    var t = null == e ? void 0 : e.split(".")[2];
                    return t && (t = t.split("~")[0]), t
                }

                function p(e) {
                    return null == e ? void 0 : e.split(".")[1]
                }

                function c(e) {
                    return null == e ? void 0 : e.split("~")[1]
                }

                function f(e) {
                    var t = null == e ? void 0 : e.split(".")[3];
                    if (t) {
                        var s = parseInt(t.split("~")[0], 10);
                        return new Date(s).toISOString()
                    }
                    return null
                }
            },
            11281: function(e, t, s) {
                "use strict";
                s.d(t, {
                    EV: function() {
                        return v
                    },
                    Wq: function() {
                        return c
                    },
                    Y9: function() {
                        return f
                    },
                    YN: function() {
                        return g
                    },
                    gO: function() {
                        return m
                    },
                    id: function() {
                        return h
                    }
                });
                var i = s(76192),
                    n = s(47725),
                    r = {
                        path: "/",
                        expiry: 365
                    },
                    o = {
                        cookies: !0,
                        localStorage: !0
                    },
                    a = {
                        organizationUserId: "o",
                        organizationUserIdAuthAlgorithm: "a",
                        organizationUserIdAuthDigest: "d",
                        organizationUserIdAuthSalt: "s",
                        organizationUserIdAuthSid: "si",
                        organizationUserIdExp: null,
                        organizationUserIdIv: "i"
                    },
                    u = Object.keys(a).filter((e => !!a[e])).reduce(((e, t) => (e[a[t]] = t, e)), {}),
                    d = {
                        "hash-md5": 1,
                        "hash-sha1": 2,
                        "hash-sha256": 3,
                        "hmac-sha1": 4,
                        "hmac-sha256": 5,
                        "aes-256-cbc": 6
                    },
                    l = Object.keys(d).reduce(((e, t) => (e[d[t]] = t, e)), {}),
                    p = ["hash-md5", "hash-sha1", "hash-sha256", "hmac-sha1", "hmac-sha256"];

                function c(e, t) {
                    var s, r;
                    return void 0 === t && (t = o), t.cookies && (s = (0, i.ej)(e)), t.localStorage && (r = (0, n.le)(e)), s || r
                }

                function f(e, t, s) {
                    var r, a, u, d;
                    return void 0 === s && (s = o), s.cookies && (r = (0, i.ej)(e), a = (0, i.ej)(t), r && a) ? {
                        didomiToken: r,
                        iabConsentString: a
                    } : s.localStorage && (u = (0, n.le)(e), d = (0, n.le)(t), u && d) ? {
                        didomiToken: u,
                        iabConsentString: d
                    } : {
                        didomiToken: r || u,
                        iabConsentString: a || d
                    }
                }

                function v(e, t, s, a, u, d, l, p) {
                    if (void 0 === s && (s = null), void 0 === a && (a = o), void 0 === u && (u = !1), void 0 === d && (d = !1), a.cookies) {
                        var c = null;
                        d && (u ? (c = "None", p = !0) : c = "Lax"), (0, i.d8)(e, t, void 0 === l ? r.expiry : l, s, c, p, r.path)
                    }
                    a.localStorage && (0, n.D$)(e, t)
                }

                function h(e, t) {
                    void 0 === t && (t = null), (0, i.kT)(e, t), (0, n.VA)(e)
                }

                function g(e) {
                    var t = {},
                        s = e.organizationUserIdAuthAlgorithm;
                    return !s || function(e) {
                        return -1 !== p.indexOf(e)
                    }(s) ? t.organizationUserId = e.organizationUserId : t = e, Object.keys(t).reduce(((e, s) => (a[s] && t[s] && (e[a[s]] = "organizationUserIdAuthAlgorithm" === s && d[t[s]] || t[s]), e)), {})
                }

                function m(e) {
                    return Object.keys(e).reduce(((t, s) => (u[s] && e[s] && (t[u[s]] = "a" === s && l[e[s]] || e[s]), t)), {})
                }
            },
            47725: function(e, t, s) {
                "use strict";

                function i(e) {
                    return o() ? window.localStorage.getItem(e) : null
                }

                function n(e, t) {
                    if (o()) try {
                        window.localStorage.setItem(e, t)
                    } catch (e) {}
                }

                function r(e) {
                    o() && window.localStorage.removeItem(e)
                }

                function o() {
                    try {
                        return !!window.localStorage
                    } catch (e) {
                        return !1
                    }
                }
                s.d(t, {
                    D$: function() {
                        return n
                    },
                    VA: function() {
                        return r
                    },
                    le: function() {
                        return i
                    }
                })
            },
            71409: function(e, t, s) {
                "use strict";
                s.d(t, {
                    $A: function() {
                        return d
                    },
                    Kw: function() {
                        return a
                    },
                    eI: function() {
                        return l
                    },
                    pw: function() {
                        return p
                    },
                    qB: function() {
                        return u
                    },
                    xi: function() {
                        return c
                    }
                });
                var i = s(26926),
                    n = s(49756),
                    r = s(43427);

                function o(e, t) {
                    return "object" == typeof e && (e[t] || (e[t] = {}), e[t].disabled || (e[t].disabled = []), e[t].enabled || (e[t].enabled = [])), e
                }

                function a(e, t) {
                    try {
                        var s;
                        return o(s = t && "function" == typeof t ? t(e) : JSON.parse(r.DS.atob(e)), "purposes"), o(s, "purposes_li"), o(s, "vendors"), o(s, "vendors_li"), s
                    } catch (e) {
                        return null
                    }
                }

                function u(e, t) {
                    if (e[t]) {
                        var s = Array.isArray(e[t].enabled) && e[t].enabled.length,
                            i = Array.isArray(e[t].disabled) && e[t].disabled.length;
                        s || i ? s ? i || delete e[t].disabled : delete e[t].enabled : delete e[t]
                    }
                    return e
                }

                function d(e, t, s) {
                    if (void 0 === t && (t = []), !e || "object" != typeof e) return null;
                    var n = (0, i.I8)(e),
                        o = (0, i.U2)(n, "vendors.enabled"),
                        a = (0, i.U2)(n, "vendors.disabled"),
                        d = (0, i.U2)(n, "vendors_li.enabled"),
                        l = (0, i.U2)(n, "vendors_li.disabled"),
                        p = e => e && "number" != typeof e;
                    if (Array.isArray(o) && (n.vendors.enabled = o.filter(p)), Array.isArray(d) && (n.vendors_li.enabled = d.filter(p)), Array.isArray(a) && (n.vendors.disabled = a.filter(p)), Array.isArray(l) && (n.vendors_li.disabled = l.filter(p)), t.length) {
                        var c = (0, i.U2)(e, "purposes.enabled"),
                            f = (0, i.U2)(e, "purposes.disabled"),
                            v = (0, i.U2)(e, "purposes_li.enabled"),
                            h = (0, i.U2)(e, "purposes_li.disabled"),
                            g = e => -1 === t.indexOf(e);
                        Array.isArray(c) && c.length && (n.purposes.enabled = n.purposes.enabled.filter(g)), Array.isArray(f) && f.length && (n.purposes.disabled = n.purposes.disabled.filter(g)), Array.isArray(v) && v.length && (n.purposes_li.enabled = n.purposes_li.enabled.filter(g)), Array.isArray(h) && h.length && (n.purposes_li.disabled = n.purposes_li.disabled.filter(g))
                    }
                    return u(n, "purposes"), u(n, "purposes_li"), u(n, "vendors"), u(n, "vendors_li"), s && "function" == typeof s ? s(n) : r.DS.btoa(JSON.stringify(n))
                }

                function l(e) {
                    try {
                        var t = e.split(".")[1];
                        return JSON.parse(r.DS.decode(t))
                    } catch (e) {
                        return console.error("Unable to parse JWT token", e), null
                    }
                }

                function p(e, t) {
                    if (!e || !e.updated) return !1;
                    var s = (0, n.Z)(e.updated);
                    return !!s && ((new Date).getTime() - s.getTime()) / 1e3 >= t
                }

                function c(e) {
                    var t = [...(0, i.U2)(e, "vendors.enabled", []), ...(0, i.U2)(e, "purposes.enabled", [])],
                        s = [...(0, i.U2)(e, "vendors.disabled", []), ...(0, i.U2)(e, "purposes.disabled", [])];
                    return 0 === t.length && s.length > 0
                }
            },
            24961: function(e, t, s) {
                "use strict";
                s.d(t, {
                    Z: function() {
                        return i
                    }
                });
                class i {
                    constructor(e, t, s) {
                        this.userStatus = this.getConsentsAndLegitimateInterests(e()), this.setUserStatus = t, this.action = s
                    }
                    getConsentsAndLegitimateInterests(e) {
                        return {
                            purposesConsents: e.purposes.consent,
                            vendorsConsents: e.vendors.consent,
                            vendorsLegitimateInterests: e.vendors.legitimate_interest,
                            purposesLegitimateInterests: e.purposes.legitimate_interest
                        }
                    }
                    enablePurpose(e) {
                        -1 === this.userStatus.purposesConsents.enabled.indexOf(e) && this.userStatus.purposesConsents.enabled.push(e);
                        var t = this.userStatus.purposesConsents.disabled.indexOf(e);
                        return -1 !== t && this.userStatus.purposesConsents.disabled.splice(t, 1), this
                    }
                    enablePurposes() {
                        for (var e = arguments.length, t = new Array(e), s = 0; s < e; s++) t[s] = arguments[s];
                        for (var i of t) this.enablePurpose(i);
                        return this
                    }
                    disablePurpose(e) {
                        -1 === this.userStatus.purposesConsents.disabled.indexOf(e) && this.userStatus.purposesConsents.disabled.push(e);
                        var t = this.userStatus.purposesConsents.enabled.indexOf(e);
                        return -1 !== t && this.userStatus.purposesConsents.enabled.splice(t, 1), this
                    }
                    disablePurposes() {
                        for (var e = arguments.length, t = new Array(e), s = 0; s < e; s++) t[s] = arguments[s];
                        for (var i of t) this.disablePurpose(i);
                        return this
                    }
                    enableVendor(e) {
                        -1 === this.userStatus.vendorsConsents.enabled.indexOf(e) && this.userStatus.vendorsConsents.enabled.push(e);
                        var t = this.userStatus.vendorsConsents.disabled.indexOf(e);
                        return -1 !== t && this.userStatus.vendorsConsents.disabled.splice(t, 1), this
                    }
                    enableVendors() {
                        for (var e = arguments.length, t = new Array(e), s = 0; s < e; s++) t[s] = arguments[s];
                        for (var i of t) this.enableVendor(i);
                        return this
                    }
                    disableVendor(e) {
                        -1 === this.userStatus.vendorsConsents.disabled.indexOf(e) && this.userStatus.vendorsConsents.disabled.push(e);
                        var t = this.userStatus.vendorsConsents.enabled.indexOf(e);
                        return -1 !== t && this.userStatus.vendorsConsents.enabled.splice(t, 1), this
                    }
                    disableVendors() {
                        for (var e = arguments.length, t = new Array(e), s = 0; s < e; s++) t[s] = arguments[s];
                        for (var i of t) this.disableVendor(i);
                        return this
                    }
                    enableVendorLegitimateInterests(e) {
                        -1 === this.userStatus.vendorsLegitimateInterests.enabled.indexOf(e) && this.userStatus.vendorsLegitimateInterests.enabled.push(e);
                        var t = this.userStatus.vendorsLegitimateInterests.disabled.indexOf(e);
                        return -1 !== t && this.userStatus.vendorsLegitimateInterests.disabled.splice(t, 1), this
                    }
                    enableVendorsLegitimateInterests() {
                        for (var e = arguments.length, t = new Array(e), s = 0; s < e; s++) t[s] = arguments[s];
                        for (var i of t) this.enableVendorLegitimateInterests(i);
                        return this
                    }
                    disableVendorLegitimateInterests(e) {
                        -1 === this.userStatus.vendorsLegitimateInterests.disabled.indexOf(e) && this.userStatus.vendorsLegitimateInterests.disabled.push(e);
                        var t = this.userStatus.vendorsLegitimateInterests.enabled.indexOf(e);
                        return -1 !== t && this.userStatus.vendorsLegitimateInterests.enabled.splice(t, 1), this
                    }
                    disableVendorsLegitimateInterests() {
                        for (var e = arguments.length, t = new Array(e), s = 0; s < e; s++) t[s] = arguments[s];
                        for (var i of t) this.disableVendorLegitimateInterests(i);
                        return this
                    }
                    enablePurposeLegitimateInterest(e) {
                        -1 === this.userStatus.purposesLegitimateInterests.enabled.indexOf(e) && this.userStatus.purposesLegitimateInterests.enabled.push(e);
                        var t = this.userStatus.purposesLegitimateInterests.disabled.indexOf(e);
                        return -1 !== t && this.userStatus.purposesLegitimateInterests.disabled.splice(t, 1), this
                    }
                    enablePurposesLegitimateInterests() {
                        for (var e = arguments.length, t = new Array(e), s = 0; s < e; s++) t[s] = arguments[s];
                        for (var i of t) this.enablePurposeLegitimateInterest(i);
                        return this
                    }
                    disablePurposeLegitimateInterest(e) {
                        -1 === this.userStatus.purposesLegitimateInterests.disabled.indexOf(e) && this.userStatus.purposesLegitimateInterests.disabled.push(e);
                        var t = this.userStatus.purposesLegitimateInterests.enabled.indexOf(e);
                        return -1 !== t && this.userStatus.purposesLegitimateInterests.enabled.splice(t, 1), this
                    }
                    disablePurposesLegitimateInterests() {
                        for (var e = arguments.length, t = new Array(e), s = 0; s < e; s++) t[s] = arguments[s];
                        for (var i of t) this.disablePurposeLegitimateInterest(i);
                        return this
                    }
                    commit() {
                        var e = {
                            purposes: {
                                consent: this.userStatus.purposesConsents,
                                legitimate_interest: this.userStatus.purposesLegitimateInterests
                            },
                            vendors: {
                                consent: this.userStatus.vendorsConsents,
                                legitimate_interest: this.userStatus.vendorsLegitimateInterests
                            },
                            action: this.action
                        };
                        this.setUserStatus(e)
                    }
                }
            },
            71654: function(e, t, s) {
                "use strict";

                function i() {
                    var e = Math.round((new Date).getTime()).toString(16);
                    return (e.substring(0, 8) + "-" + e.substring(8) + "x-6xxx-yxxx-xxxxxxxxxxxx").replace(/[xy]/g, (e => {
                        var t = 16 * Math.random() | 0;
                        return ("x" === e ? t : 3 & t | 8).toString(16)
                    }))
                }
                s.d(t, {
                    Z: function() {
                        return i
                    }
                })
            },
            27223: function(e, t, s) {
                "use strict";
                s.r(t), s.d(t, {
                    iabFeatures: function() {
                        return u
                    },
                    iabPurposesDidomiIdMap: function() {
                        return l
                    },
                    iabSpecialPurposes: function() {
                        return a
                    },
                    iabStacks: function() {
                        return d
                    },
                    purposes: function() {
                        return r
                    },
                    specialFeatures: function() {
                        return o
                    }
                });
                var i = JSON.parse('{"purposes":[{"id":1,"name":"purpose_1_name","description":"purpose_1_description","descriptionLegal":"purpose_1_description_legal"},{"id":2,"name":"purpose_2_name","description":"purpose_2_description","descriptionLegal":"purpose_2_description_legal"},{"id":3,"name":"purpose_3_name","description":"purpose_3_description","descriptionLegal":"purpose_3_description_legal"},{"id":4,"name":"purpose_4_name","description":"purpose_4_description","descriptionLegal":"purpose_4_description_legal"},{"id":5,"name":"purpose_5_name","description":"purpose_5_description","descriptionLegal":"purpose_5_description_legal"},{"id":6,"name":"purpose_6_name","description":"purpose_6_description","descriptionLegal":"purpose_6_description_legal"},{"id":7,"name":"purpose_7_name","description":"purpose_7_description","descriptionLegal":"purpose_7_description_legal"},{"id":8,"name":"purpose_8_name","description":"purpose_8_description","descriptionLegal":"purpose_8_description_legal"},{"id":9,"name":"purpose_9_name","description":"purpose_9_description","descriptionLegal":"purpose_9_description_legal"},{"id":10,"name":"purpose_10_name","description":"purpose_10_description","descriptionLegal":"purpose_10_description_legal"}],"specialPurposes":[{"id":1,"name":"special_purpose_1_name","description":"special_purpose_1_description","descriptionLegal":"special_purpose_1_description_legal"},{"id":2,"name":"special_purpose_2_name","description":"special_purpose_2_description","descriptionLegal":"special_purpose_2_description_legal"}],"features":[{"id":1,"name":"feature_1_name","description":"feature_1_description","descriptionLegal":"feature_1_description_legal"},{"id":2,"name":"feature_2_name","description":"feature_2_description","descriptionLegal":"feature_2_description_legal"},{"id":3,"name":"feature_3_name","description":"feature_3_description","descriptionLegal":"feature_3_description_legal"}],"specialFeatures":[{"id":1,"name":"special_feature_1_name","description":"special_feature_1_description","descriptionLegal":"special_feature_1_description_legal"},{"id":2,"name":"special_feature_2_name","description":"special_feature_2_description","descriptionLegal":"special_feature_2_description_legal"}],"stacks":[{"id":1,"name":"stack_1_name","description":"stack_1_description"},{"id":2,"name":"stack_2_name","description":"stack_2_description"},{"id":3,"name":"stack_3_name","description":"stack_3_description"},{"id":4,"name":"stack_4_name","description":"stack_4_description"},{"id":5,"name":"stack_5_name","description":"stack_5_description"},{"id":6,"name":"stack_6_name","description":"stack_6_description"},{"id":7,"name":"stack_7_name","description":"stack_7_description"},{"id":8,"name":"stack_8_name","description":"stack_8_description"},{"id":9,"name":"stack_9_name","description":"stack_9_description"},{"id":10,"name":"stack_10_name","description":"stack_10_description"},{"id":11,"name":"stack_11_name","description":"stack_11_description"},{"id":12,"name":"stack_12_name","description":"stack_12_description"},{"id":13,"name":"stack_13_name","description":"stack_13_description"},{"id":14,"name":"stack_14_name","description":"stack_14_description"},{"id":15,"name":"stack_15_name","description":"stack_15_description"},{"id":16,"name":"stack_16_name","description":"stack_16_description"},{"id":17,"name":"stack_17_name","description":"stack_17_description"},{"id":18,"name":"stack_18_name","description":"stack_18_description"},{"id":19,"name":"stack_19_name","description":"stack_19_description"},{"id":20,"name":"stack_20_name","description":"stack_20_description"},{"id":21,"name":"stack_21_name","description":"stack_21_description"},{"id":22,"name":"stack_22_name","description":"stack_22_description"},{"id":23,"name":"stack_23_name","description":"stack_23_description"},{"id":24,"name":"stack_24_name","description":"stack_24_description"},{"id":25,"name":"stack_25_name","description":"stack_25_description"},{"id":26,"name":"stack_26_name","description":"stack_26_description"},{"id":27,"name":"stack_27_name","description":"stack_27_description"},{"id":28,"name":"stack_28_name","description":"stack_28_description"},{"id":29,"name":"stack_29_name","description":"stack_29_description"},{"id":30,"name":"stack_30_name","description":"stack_30_description"},{"id":31,"name":"stack_31_name","description":"stack_31_description"},{"id":32,"name":"stack_32_name","description":"stack_32_description"},{"id":33,"name":"stack_33_name","description":"stack_33_description"},{"id":34,"name":"stack_34_name","description":"stack_34_description"},{"id":35,"name":"stack_35_name","description":"stack_35_description"},{"id":36,"name":"stack_36_name","description":"stack_36_description"},{"id":37,"name":"stack_37_name","description":"stack_37_description"},{"id":38,"name":"stack_38_name","description":"stack_38_description"},{"id":39,"name":"stack_39_name","description":"stack_39_description"},{"id":40,"name":"stack_40_name","description":"stack_40_description"},{"id":41,"name":"stack_41_name","description":"stack_41_description"},{"id":42,"name":"stack_42_name","description":"stack_42_description"}]}'),
                    n = s(16619),
                    {
                        purposes: r,
                        specialFeatures: o,
                        specialPurposes: a,
                        features: u,
                        stacks: d
                    } = i,
                    l = i.purposes.map((e => {
                        var {
                            id: t
                        } = e;
                        return {
                            [n.oM[t]]: t
                        }
                    })).reduce(((e, t) => Object.assign(e, t)), {})
            },
            67301: function(e, t, s) {
                "use strict";
                s.d(t, {
                    Z: function() {
                        return ft
                    }
                });
                var i, n, r, o, a, u, d, l, p, c, f, v, h, g, m, b, S, C, y, w, I, _, P, A = s(87462);
                class k extends Error {
                    constructor(e) {
                        super(e), this.name = "DecodingError"
                    }
                }
                class T extends Error {
                    constructor(e) {
                        super(e), this.name = "EncodingError"
                    }
                }
                class E extends Error {
                    constructor(e) {
                        super(e), this.name = "GVLError"
                    }
                }
                class L extends Error {
                    constructor(e, t, s) {
                        void 0 === s && (s = ""), super("invalid value " + t + " passed for " + e + " " + s), this.name = "TCModelError"
                    }
                }
                class U {
                    static encode(e) {
                        if (!/^[0-1]+$/.test(e)) throw new T("Invalid bitField");
                        var t = e.length % this.LCM;
                        e += t ? "0".repeat(this.LCM - t) : "";
                        for (var s = "", i = 0; i < e.length; i += this.BASIS) s += this.DICT[parseInt(e.substr(i, this.BASIS), 2)];
                        return s
                    }
                    static decode(e) {
                        if (!/^[A-Za-z0-9\-_]+$/.test(e)) throw new k("Invalidly encoded Base64URL string");
                        for (var t = "", s = 0; s < e.length; s++) {
                            var i = this.REVERSE_DICT.get(e[s]).toString(2);
                            t += "0".repeat(this.BASIS - i.length) + i
                        }
                        return t
                    }
                }
                U.DICT = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", U.REVERSE_DICT = new Map([
                    ["A", 0],
                    ["B", 1],
                    ["C", 2],
                    ["D", 3],
                    ["E", 4],
                    ["F", 5],
                    ["G", 6],
                    ["H", 7],
                    ["I", 8],
                    ["J", 9],
                    ["K", 10],
                    ["L", 11],
                    ["M", 12],
                    ["N", 13],
                    ["O", 14],
                    ["P", 15],
                    ["Q", 16],
                    ["R", 17],
                    ["S", 18],
                    ["T", 19],
                    ["U", 20],
                    ["V", 21],
                    ["W", 22],
                    ["X", 23],
                    ["Y", 24],
                    ["Z", 25],
                    ["a", 26],
                    ["b", 27],
                    ["c", 28],
                    ["d", 29],
                    ["e", 30],
                    ["f", 31],
                    ["g", 32],
                    ["h", 33],
                    ["i", 34],
                    ["j", 35],
                    ["k", 36],
                    ["l", 37],
                    ["m", 38],
                    ["n", 39],
                    ["o", 40],
                    ["p", 41],
                    ["q", 42],
                    ["r", 43],
                    ["s", 44],
                    ["t", 45],
                    ["u", 46],
                    ["v", 47],
                    ["w", 48],
                    ["x", 49],
                    ["y", 50],
                    ["z", 51],
                    ["0", 52],
                    ["1", 53],
                    ["2", 54],
                    ["3", 55],
                    ["4", 56],
                    ["5", 57],
                    ["6", 58],
                    ["7", 59],
                    ["8", 60],
                    ["9", 61],
                    ["-", 62],
                    ["_", 63]
                ]), U.BASIS = 6, U.LCM = 24;
                class O {
                    has(e) {
                        return O.langSet.has(e)
                    }
                    forEach(e) {
                        O.langSet.forEach(e)
                    }
                    get size() {
                        return O.langSet.size
                    }
                }
                O.langSet = new Set(["BG", "CA", "CS", "DA", "DE", "EL", "EN", "ES", "ET", "FI", "FR", "HR", "HU", "IT", "JA", "LT", "LV", "MT", "NL", "NO", "PL", "PT", "RO", "RU", "SK", "SL", "SV", "TR", "ZH"]);
                class x {}
                x.cmpId = "cmpId", x.cmpVersion = "cmpVersion", x.consentLanguage = "consentLanguage", x.consentScreen = "consentScreen", x.created = "created", x.supportOOB = "supportOOB", x.isServiceSpecific = "isServiceSpecific", x.lastUpdated = "lastUpdated", x.numCustomPurposes = "numCustomPurposes", x.policyVersion = "policyVersion", x.publisherCountryCode = "publisherCountryCode", x.publisherCustomConsents = "publisherCustomConsents", x.publisherCustomLegitimateInterests = "publisherCustomLegitimateInterests", x.publisherLegitimateInterests = "publisherLegitimateInterests", x.publisherConsents = "publisherConsents", x.publisherRestrictions = "publisherRestrictions", x.purposeConsents = "purposeConsents", x.purposeLegitimateInterests = "purposeLegitimateInterests", x.purposeOneTreatment = "purposeOneTreatment", x.specialFeatureOptins = "specialFeatureOptins", x.useNonStandardStacks = "useNonStandardStacks", x.vendorConsents = "vendorConsents", x.vendorLegitimateInterests = "vendorLegitimateInterests", x.vendorListVersion = "vendorListVersion", x.vendorsAllowed = "vendorsAllowed", x.vendorsDisclosed = "vendorsDisclosed", x.version = "version";
                class D {
                    clone() {
                        var e = new this.constructor;
                        return Object.keys(this).forEach((t => {
                            var s = this.deepClone(this[t]);
                            void 0 !== s && (e[t] = s)
                        })), e
                    }
                    deepClone(e) {
                        var t = typeof e;
                        if ("number" === t || "string" === t || "boolean" === t) return e;
                        if (null !== e && "object" === t) {
                            if ("function" == typeof e.clone) return e.clone();
                            if (e instanceof Date) return new Date(e.getTime());
                            if (void 0 !== e[Symbol.iterator]) {
                                var s = [];
                                for (var i of e) s.push(this.deepClone(i));
                                return e instanceof Array ? s : new e.constructor(s)
                            }
                            var n = {};
                            for (var r in e) e.hasOwnProperty(r) && (n[r] = this.deepClone(e[r]));
                            return n
                        }
                    }
                }! function(e) {
                    e[e.NOT_ALLOWED = 0] = "NOT_ALLOWED", e[e.REQUIRE_CONSENT = 1] = "REQUIRE_CONSENT", e[e.REQUIRE_LI = 2] = "REQUIRE_LI"
                }(i || (i = {}));
                class V extends D {
                    constructor(e, t) {
                        super(), this.purposeId_ = void 0, this.restrictionType = void 0, void 0 !== e && (this.purposeId = e), void 0 !== t && (this.restrictionType = t)
                    }
                    static unHash(e) {
                        var t = e.split(this.hashSeparator),
                            s = new V;
                        if (2 !== t.length) throw new L("hash", e);
                        return s.purposeId = parseInt(t[0], 10), s.restrictionType = parseInt(t[1], 10), s
                    }
                    get hash() {
                        if (!this.isValid()) throw new Error("cannot hash invalid PurposeRestriction");
                        return "" + this.purposeId + V.hashSeparator + this.restrictionType
                    }
                    get purposeId() {
                        return this.purposeId_
                    }
                    set purposeId(e) {
                        this.purposeId_ = e
                    }
                    isValid() {
                        return Number.isInteger(this.purposeId) && this.purposeId > 0 && (this.restrictionType === i.NOT_ALLOWED || this.restrictionType === i.REQUIRE_CONSENT || this.restrictionType === i.REQUIRE_LI)
                    }
                    isSameAs(e) {
                        return this.purposeId === e.purposeId && this.restrictionType === e.restrictionType
                    }
                }
                V.hashSeparator = "-";
                class R extends D {
                    constructor() {
                        super(...arguments), this.bitLength = 0, this.map = new Map, this.gvl_ = void 0
                    }
                    has(e) {
                        return this.map.has(e)
                    }
                    isOkToHave(e, t, s) {
                        var n, r = !0;
                        if (null != (n = this.gvl) && n.vendors) {
                            var o = this.gvl.vendors[s];
                            if (o)
                                if (e === i.NOT_ALLOWED) r = o.legIntPurposes.includes(t) || o.purposes.includes(t);
                                else if (o.flexiblePurposes.length) switch (e) {
                                case i.REQUIRE_CONSENT:
                                    r = o.flexiblePurposes.includes(t) && o.legIntPurposes.includes(t);
                                    break;
                                case i.REQUIRE_LI:
                                    r = o.flexiblePurposes.includes(t) && o.purposes.includes(t)
                            } else r = !1;
                            else r = !1
                        }
                        return r
                    }
                    add(e, t) {
                        if (this.isOkToHave(t.restrictionType, t.purposeId, e)) {
                            var s = t.hash;
                            this.has(s) || (this.map.set(s, new Set), this.bitLength = 0), this.map.get(s).add(e)
                        }
                    }
                    restrictPurposeToLegalBasis(e, t) {
                        void 0 === t && (t = Array.from(this.gvl.vendorIds));
                        var s = e.hash;
                        if (this.has(s)) {
                            var i = this.map.get(s);
                            for (var n of t) i.add(n)
                        } else this.map.set(s, new Set(t)), this.bitLength = 0
                    }
                    getVendors(e) {
                        var t = [];
                        if (e) {
                            var s = e.hash;
                            this.has(s) && (t = Array.from(this.map.get(s)))
                        } else {
                            var i = new Set;
                            this.map.forEach((e => {
                                Array.from(e).forEach((e => {
                                    i.add(e)
                                }))
                            })), t = Array.from(i)
                        }
                        return t.sort(((e, t) => e - t))
                    }
                    getRestrictionType(e, t) {
                        var s;
                        return this.getRestrictions(e).forEach((e => {
                            e.purposeId === t && (void 0 === s || s > e.restrictionType) && (s = e.restrictionType)
                        })), s
                    }
                    vendorHasRestriction(e, t) {
                        for (var s = !1, i = this.getRestrictions(e), n = 0; n < i.length && !s; n++) s = t.isSameAs(i[n]);
                        return s
                    }
                    getMaxVendorId() {
                        var e = 0;
                        return this.map.forEach((t => {
                            var s = Array.from(t);
                            e = Math.max(s[s.length - 1], e)
                        })), e
                    }
                    getRestrictions(e) {
                        var t = [];
                        return this.map.forEach(((s, i) => {
                            e ? s.has(e) && t.push(V.unHash(i)) : t.push(V.unHash(i))
                        })), t
                    }
                    getPurposes() {
                        var e = new Set;
                        return this.map.forEach(((t, s) => {
                            e.add(V.unHash(s).purposeId)
                        })), Array.from(e)
                    }
                    remove(e, t) {
                        var s = t.hash,
                            i = this.map.get(s);
                        i && (i.delete(e), 0 == i.size && (this.map.delete(s), this.bitLength = 0))
                    }
                    set gvl(e) {
                        this.gvl_ || (this.gvl_ = e, this.map.forEach(((e, t) => {
                            var s = V.unHash(t);
                            Array.from(e).forEach((t => {
                                this.isOkToHave(s.restrictionType, s.purposeId, t) || e.delete(t)
                            }))
                        })))
                    }
                    get gvl() {
                        return this.gvl_
                    }
                    isEmpty() {
                        return 0 === this.map.size
                    }
                    get numRestrictions() {
                        return this.map.size
                    }
                }! function(e) {
                    e.COOKIE = "cookie", e.WEB = "web", e.APP = "app"
                }(n || (n = {})),
                function(e) {
                    e.CORE = "core", e.VENDORS_DISCLOSED = "vendorsDisclosed", e.VENDORS_ALLOWED = "vendorsAllowed", e.PUBLISHER_TC = "publisherTC"
                }(r || (r = {}));
                class N {}
                N.ID_TO_KEY = [r.CORE, r.VENDORS_DISCLOSED, r.VENDORS_ALLOWED, r.PUBLISHER_TC], N.KEY_TO_ID = {
                    [r.CORE]: 0,
                    [r.VENDORS_DISCLOSED]: 1,
                    [r.VENDORS_ALLOWED]: 2,
                    [r.PUBLISHER_TC]: 3
                }, o = Symbol.iterator;
                class F extends D {
                    constructor() {
                        super(...arguments), this.bitLength = 0, this.maxId_ = 0, this.set_ = new Set
                    }*[o]() {
                        for (var e = 1; e <= this.maxId; e++) yield [e, this.has(e)]
                    }
                    toArray() {
                        for (var e = new Array(0), t = 1; t <= this.maxId; t++) e.push([t, this.has(t)]);
                        return e
                    }
                    values() {
                        return this.set_.values()
                    }
                    get maxId() {
                        return this.maxId_
                    }
                    has(e) {
                        return this.set_.has(e)
                    }
                    unset(e) {
                        Array.isArray(e) ? e.forEach((e => this.unset(e))) : "object" == typeof e ? this.unset(Object.keys(e).map((e => Number(e)))) : (this.set_.delete(Number(e)), this.bitLength = 0, e === this.maxId && (this.maxId_ = 0, this.set_.forEach((e => {
                            this.maxId_ = Math.max(this.maxId, e)
                        }))))
                    }
                    isIntMap(e) {
                        var t = "object" == typeof e;
                        return t = t && Object.keys(e).every((t => {
                            var s = Number.isInteger(parseInt(t, 10));
                            return s = (s = s && this.isValidNumber(e[t].id)) && void 0 !== e[t].name
                        }))
                    }
                    isValidNumber(e) {
                        return parseInt(e, 10) > 0
                    }
                    isSet(e) {
                        var t = !1;
                        return e instanceof Set && (t = Array.from(e).every(this.isValidNumber)), t
                    }
                    set(e) {
                        if (Array.isArray(e)) e.forEach((e => this.set(e)));
                        else if (this.isSet(e)) this.set(Array.from(e));
                        else if (this.isIntMap(e)) this.set(Object.keys(e).map((e => Number(e))));
                        else {
                            if (!this.isValidNumber(e)) throw new L("set()", e, "must be positive integer array, positive integer, Set<number>, or IntMap");
                            this.set_.add(e), this.maxId_ = Math.max(this.maxId, e), this.bitLength = 0
                        }
                    }
                    empty() {
                        this.set_ = new Set
                    }
                    forEach(e) {
                        for (var t = 1; t <= this.maxId; t++) e(this.has(t), t)
                    }
                    get size() {
                        return this.set_.size
                    }
                    setAll(e) {
                        this.set(e)
                    }
                }
                a = x.cmpId, u = x.cmpVersion, d = x.consentLanguage, l = x.consentScreen, p = x.created, c = x.isServiceSpecific, f = x.lastUpdated, v = x.policyVersion, h = x.publisherCountryCode, g = x.publisherLegitimateInterests, m = x.publisherConsents, b = x.purposeConsents, S = x.purposeLegitimateInterests, C = x.purposeOneTreatment, y = x.specialFeatureOptins, w = x.useNonStandardStacks, I = x.vendorListVersion, _ = x.version;
                class B {}
                B[a] = 12, B[u] = 12, B[d] = 12, B[l] = 6, B[p] = 36, B[c] = 1, B[f] = 36, B[v] = 6, B[h] = 12, B[g] = 24, B[m] = 24, B[b] = 24, B[S] = 24, B[C] = 1, B[y] = 12, B[w] = 1, B[I] = 12, B[_] = 6, B.anyBoolean = 1, B.encodingType = 1, B.maxId = 16, B.numCustomPurposes = 6, B.numEntries = 12, B.numRestrictions = 12, B.purposeId = 6, B.restrictionType = 2, B.segmentType = 3, B.singleOrRange = 1, B.vendorId = 16;
                class M {
                    static encode(e, t) {
                        var s;
                        if ("string" == typeof e && (e = parseInt(e, 10)), (s = e.toString(2)).length > t || e < 0) throw new T(e + " too large to encode into " + t);
                        return s.length < t && (s = "0".repeat(t - s.length) + s), s
                    }
                    static decode(e, t) {
                        if (t !== e.length) throw new k("invalid bit length");
                        return parseInt(e, 2)
                    }
                }
                class j {
                    static encode(e, t) {
                        return M.encode(Math.round(e.getTime() / 100), t)
                    }
                    static decode(e, t) {
                        if (t !== e.length) throw new k("invalid bit length");
                        var s = new Date;
                        return s.setTime(100 * M.decode(e, t)), s
                    }
                }
                class z {
                    static encode(e) {
                        return String(Number(e))
                    }
                    static decode(e) {
                        return "1" === e
                    }
                }
                class Z {
                    static encode(e, t) {
                        for (var s = "", i = 1; i <= t; i++) s += z.encode(e.has(i));
                        return s
                    }
                    static decode(e, t) {
                        if (e.length !== t) throw new k("bitfield encoding length mismatch");
                        for (var s = new F, i = 1; i <= t; i++) z.decode(e[i - 1]) && s.set(i);
                        return s.bitLength = e.length, s
                    }
                }
                class G {
                    static encode(e, t) {
                        var s = (e = e.toUpperCase()).charCodeAt(0) - 65,
                            i = e.charCodeAt(1) - 65;
                        if (s < 0 || s > 25 || i < 0 || i > 25) throw new T("invalid language code: " + e);
                        if (t % 2 == 1) throw new T("numBits must be even, " + t + " is not valid");
                        return t /= 2, M.encode(s, t) + M.encode(i, t)
                    }
                    static decode(e, t) {
                        if (t !== e.length || e.length % 2) throw new k("invalid bit length for language");
                        var s = e.length / 2,
                            i = M.decode(e.slice(0, s), s) + 65,
                            n = M.decode(e.slice(s), s) + 65;
                        return String.fromCharCode(i) + String.fromCharCode(n)
                    }
                }
                class q {
                    static encode(e) {
                        var t = M.encode(e.numRestrictions, B.numRestrictions);
                        if (!e.isEmpty()) {
                            var s = Array.from(e.gvl.vendorIds),
                                i = (e, t) => {
                                    var i = s.indexOf(e);
                                    return s.indexOf(t) - i > 1
                                };
                            e.getRestrictions().forEach((s => {
                                t += M.encode(s.purposeId, B.purposeId), t += M.encode(s.restrictionType, B.restrictionType);
                                for (var n = e.getVendors(s), r = n.length, o = 0, a = 0, u = "", d = 0; d < r; d++) {
                                    var l = n[d];
                                    if (0 === a && (o++, a = l), d === r - 1 || i(l, n[d + 1])) {
                                        var p = !(l === a);
                                        u += z.encode(p), u += M.encode(a, B.vendorId), p && (u += M.encode(l, B.vendorId)), a = 0
                                    }
                                }
                                t += M.encode(o, B.numEntries), t += u
                            }))
                        }
                        return t
                    }
                    static decode(e) {
                        var t = 0,
                            s = new R,
                            i = M.decode(e.substr(t, B.numRestrictions), B.numRestrictions);
                        t += B.numRestrictions;
                        for (var n = 0; n < i; n++) {
                            var r = M.decode(e.substr(t, B.purposeId), B.purposeId);
                            t += B.purposeId;
                            var o = M.decode(e.substr(t, B.restrictionType), B.restrictionType);
                            t += B.restrictionType;
                            var a = new V(r, o),
                                u = M.decode(e.substr(t, B.numEntries), B.numEntries);
                            t += B.numEntries;
                            for (var d = function() {
                                    var i = z.decode(e.substr(t, B.anyBoolean));
                                    t += B.anyBoolean;
                                    var n = M.decode(e.substr(t, B.vendorId), B.vendorId);
                                    if (t += B.vendorId, i) {
                                        var r = M.decode(e.substr(t, B.vendorId), B.vendorId);
                                        if (t += B.vendorId, r < n) throw new k("Invalid RangeEntry: endVendorId " + r + " is less than " + n);
                                        var o = Array.from({
                                            length: r - n + 1
                                        }, ((e, t) => n + t));
                                        s.restrictPurposeToLegalBasis(a, o)
                                    } else s.restrictPurposeToLegalBasis(a, [n])
                                }, l = 0; l < u; l++) d()
                        }
                        return s.bitLength = t, s
                    }
                }! function(e) {
                    e[e.FIELD = 0] = "FIELD", e[e.RANGE = 1] = "RANGE"
                }(P || (P = {}));
                class H {
                    static encode(e) {
                        var t, s = [],
                            i = [],
                            n = M.encode(e.maxId, B.maxId),
                            r = "",
                            o = B.maxId + B.encodingType,
                            a = o + e.maxId,
                            u = 2 * B.vendorId + B.singleOrRange + B.numEntries,
                            d = o + B.numEntries;
                        return e.forEach(((n, o) => {
                            (r += z.encode(n), (t = e.maxId > u && d < a) && n) && (e.has(o + 1) ? 0 === i.length && (i.push(o), d += B.singleOrRange, d += B.vendorId) : (i.push(o), d += B.vendorId, s.push(i), i = []))
                        })), t ? (n += String(P.RANGE), n += this.buildRangeEncoding(s)) : (n += String(P.FIELD), n += r), n
                    }
                    static decode(e, t) {
                        var s, i = 0,
                            n = M.decode(e.substr(i, B.maxId), B.maxId);
                        i += B.maxId;
                        var r = M.decode(e.charAt(i), B.encodingType);
                        if (i += B.encodingType, r === P.RANGE) {
                            if (s = new F, 1 === t) {
                                if ("1" === e.substr(i, 1)) throw new k("Unable to decode default consent=1");
                                i++
                            }
                            var o = M.decode(e.substr(i, B.numEntries), B.numEntries);
                            i += B.numEntries;
                            for (var a = 0; a < o; a++) {
                                var u = z.decode(e.charAt(i));
                                i += B.singleOrRange;
                                var d = M.decode(e.substr(i, B.vendorId), B.vendorId);
                                if (i += B.vendorId, u) {
                                    var l = M.decode(e.substr(i, B.vendorId), B.vendorId);
                                    i += B.vendorId;
                                    for (var p = d; p <= l; p++) s.set(p)
                                } else s.set(d)
                            }
                        } else {
                            var c = e.substr(i, n);
                            i += n, s = Z.decode(c, n)
                        }
                        return s.bitLength = i, s
                    }
                    static buildRangeEncoding(e) {
                        var t = e.length,
                            s = M.encode(t, B.numEntries);
                        return e.forEach((e => {
                            var t = 1 === e.length;
                            s += z.encode(!t), s += M.encode(e[0], B.vendorId), t || (s += M.encode(e[1], B.vendorId))
                        })), s
                    }
                }

                function W() {
                    return {
                        [x.version]: M,
                        [x.created]: j,
                        [x.lastUpdated]: j,
                        [x.cmpId]: M,
                        [x.cmpVersion]: M,
                        [x.consentScreen]: M,
                        [x.consentLanguage]: G,
                        [x.vendorListVersion]: M,
                        [x.policyVersion]: M,
                        [x.isServiceSpecific]: z,
                        [x.useNonStandardStacks]: z,
                        [x.specialFeatureOptins]: Z,
                        [x.purposeConsents]: Z,
                        [x.purposeLegitimateInterests]: Z,
                        [x.purposeOneTreatment]: z,
                        [x.publisherCountryCode]: G,
                        [x.vendorConsents]: H,
                        [x.vendorLegitimateInterests]: H,
                        [x.publisherRestrictions]: q,
                        segmentType: M,
                        [x.vendorsDisclosed]: H,
                        [x.vendorsAllowed]: H,
                        [x.publisherConsents]: Z,
                        [x.publisherLegitimateInterests]: Z,
                        [x.numCustomPurposes]: M,
                        [x.publisherCustomConsents]: Z,
                        [x.publisherCustomLegitimateInterests]: Z
                    }
                }
                class K {
                    constructor(e, t) {
                        if (this[1] = [r.CORE], this[2] = [r.CORE], 2 === e.version)
                            if (e.isServiceSpecific) this[2].push(r.PUBLISHER_TC);
                            else {
                                var s = !(!t || !t.isForVendors);
                                s && !0 !== e[x.supportOOB] || this[2].push(r.VENDORS_DISCLOSED), s && (e[x.supportOOB] && e[x.vendorsAllowed].size > 0 && this[2].push(r.VENDORS_ALLOWED), this[2].push(r.PUBLISHER_TC))
                            }
                    }
                }
                class J {
                    static encode(e, t) {
                        var s;
                        try {
                            s = this.fieldSequence[String(e.version)][t]
                        } catch (s) {
                            throw new T("Unable to encode version: " + e.version + ", segment: " + t)
                        }
                        var i = "";
                        t !== r.CORE && (i = M.encode(N.KEY_TO_ID[t], B.segmentType));
                        var n = W();
                        return s.forEach((s => {
                            var r = e[s],
                                o = n[s],
                                a = B[s];
                            void 0 === a && this.isPublisherCustom(s) && (a = Number(e[x.numCustomPurposes]));
                            try {
                                i += o.encode(r, a)
                            } catch (e) {
                                throw new T("Error encoding " + t + "->" + s + ": " + e.message)
                            }
                        })), U.encode(i)
                    }
                    static decode(e, t, s) {
                        var i = U.decode(e),
                            n = 0;
                        s === r.CORE && (t.version = M.decode(i.substr(n, B[x.version]), B[x.version])), s !== r.CORE && (n += B.segmentType);
                        var o = this.fieldSequence[String(t.version)][s],
                            a = W();
                        return o.forEach((e => {
                            var s = a[e],
                                r = B[e];
                            if (void 0 === r && this.isPublisherCustom(e) && (r = Number(t[x.numCustomPurposes])), 0 !== r) {
                                var o = i.substr(n, r);
                                if (t[e] = s === H ? s.decode(o, t.version) : s.decode(o, r), Number.isInteger(r)) n += r;
                                else {
                                    if (!Number.isInteger(t[e].bitLength)) throw new k(e);
                                    n += t[e].bitLength
                                }
                            }
                        })), t
                    }
                    static isPublisherCustom(e) {
                        return 0 === e.indexOf("publisherCustom")
                    }
                }
                J.fieldSequence = new class {
                    constructor() {
                        this[1] = {
                            [r.CORE]: [x.version, x.created, x.lastUpdated, x.cmpId, x.cmpVersion, x.consentScreen, x.consentLanguage, x.vendorListVersion, x.purposeConsents, x.vendorConsents]
                        }, this[2] = {
                            [r.CORE]: [x.version, x.created, x.lastUpdated, x.cmpId, x.cmpVersion, x.consentScreen, x.consentLanguage, x.vendorListVersion, x.policyVersion, x.isServiceSpecific, x.useNonStandardStacks, x.specialFeatureOptins, x.purposeConsents, x.purposeLegitimateInterests, x.purposeOneTreatment, x.publisherCountryCode, x.vendorConsents, x.vendorLegitimateInterests, x.publisherRestrictions],
                            [r.PUBLISHER_TC]: [x.publisherConsents, x.publisherLegitimateInterests, x.numCustomPurposes, x.publisherCustomConsents, x.publisherCustomLegitimateInterests],
                            [r.VENDORS_ALLOWED]: [x.vendorsAllowed],
                            [r.VENDORS_DISCLOSED]: [x.vendorsDisclosed]
                        }
                    }
                };
                class Q {
                    static process(e, t) {
                        var s = e.gvl;
                        if (!s) throw new T("Unable to encode TCModel without a GVL");
                        if (!s.isReady) throw new T("Unable to encode TCModel tcModel.gvl.readyPromise is not resolved");
                        (e = e.clone()).consentLanguage = s.language.toUpperCase(), (null == t ? void 0 : t.version) > 0 && (null == t ? void 0 : t.version) <= this.processor.length ? e.version = t.version : e.version = this.processor.length;
                        var i = e.version - 1;
                        if (!this.processor[i]) throw new T("Invalid version: " + e.version);
                        return this.processor[i](e, s)
                    }
                }
                Q.processor = [e => e, (e, t) => {
                    e.publisherRestrictions.gvl = t, e.purposeLegitimateInterests.unset(1);
                    var s = new Map;
                    return s.set("legIntPurposes", e.vendorLegitimateInterests), s.set("purposes", e.vendorConsents), s.forEach(((s, n) => {
                        s.forEach(((r, o) => {
                            if (r) {
                                var a = t.vendors[o];
                                if (!a || a.deletedDate) s.unset(o);
                                else if (0 === a[n].length)
                                    if ("legIntPurposes" === n && 0 === a.purposes.length && 0 === a.legIntPurposes.length && a.specialPurposes.length > 0);
                                    else if (e.isServiceSpecific)
                                    if (0 === a.flexiblePurposes.length) s.unset(o);
                                    else {
                                        for (var u = e.publisherRestrictions.getRestrictions(o), d = !1, l = 0, p = u.length; l < p && !d; l++) d = u[l].restrictionType === i.REQUIRE_CONSENT && "purposes" === n || u[l].restrictionType === i.REQUIRE_LI && "legIntPurposes" === n;
                                        d || s.unset(o)
                                    }
                                else s.unset(o)
                            }
                        }))
                    })), e.vendorsDisclosed.set(t.vendors), e
                }];
                var $, Y, X, ee, te, se, ie, ne, re, oe, ae = s(15861);
                class ue {
                    static absCall(e, t, s, i) {
                        return new Promise(((n, r) => {
                            var o = new XMLHttpRequest;
                            o.withCredentials = s, o.addEventListener("load", (() => {
                                if (o.readyState == XMLHttpRequest.DONE)
                                    if (o.status >= 200 && o.status < 300) {
                                        var e = o.response;
                                        if ("string" == typeof e) try {
                                            e = JSON.parse(e)
                                        } catch (e) {}
                                        n(e)
                                    } else r(new Error("HTTP Status: " + o.status + " response type: " + o.responseType))
                            })), o.addEventListener("error", (() => {
                                r(new Error("error"))
                            })), o.addEventListener("abort", (() => {
                                r(new Error("aborted"))
                            })), null === t ? o.open("GET", e, !0) : o.open("POST", e, !0), o.responseType = "json", o.timeout = i, o.ontimeout = () => {
                                r(new Error("Timeout " + i + "ms " + e))
                            }, o.send(t)
                        }))
                    }
                    static post(e, t, s, i) {
                        return void 0 === s && (s = !1), void 0 === i && (i = 0), this.absCall(e, JSON.stringify(t), s, i)
                    }
                    static fetch(e, t, s) {
                        return void 0 === t && (t = !1), void 0 === s && (s = 0), this.absCall(e, null, t, s)
                    }
                }
                class de extends D {
                    static set baseUrl(e) {
                        if (/^https?:\/\/vendorlist\.consensu\.org\//.test(e)) throw new E("Invalid baseUrl!  You may not pull directly from vendorlist.consensu.org and must provide your own cache");
                        e.length > 0 && "/" !== e[e.length - 1] && (e += "/"), this.baseUrl_ = e
                    }
                    static get baseUrl() {
                        return this.baseUrl_
                    }
                    constructor(e) {
                        super(), this.readyPromise = void 0, this.gvlSpecificationVersion = void 0, this.vendorListVersion = void 0, this.tcfPolicyVersion = void 0, this.lastUpdated = void 0, this.purposes = void 0, this.specialPurposes = void 0, this.features = void 0, this.specialFeatures = void 0, this.isReady_ = !1, this.vendors_ = void 0, this.vendorIds = void 0, this.fullVendorList = void 0, this.byPurposeVendorMap = void 0, this.bySpecialPurposeVendorMap = void 0, this.byFeatureVendorMap = void 0, this.bySpecialFeatureVendorMap = void 0, this.stacks = void 0, this.lang_ = void 0, this.isLatest = !1;
                        var t = de.baseUrl;
                        if (this.lang_ = de.DEFAULT_LANGUAGE, this.isVendorList(e)) this.populate(e), this.readyPromise = Promise.resolve();
                        else {
                            if (!t) throw new E("must specify GVL.baseUrl before loading GVL json");
                            if (e > 0) {
                                var s = e;
                                de.CACHE.has(s) ? (this.populate(de.CACHE.get(s)), this.readyPromise = Promise.resolve()) : (t += de.versionedFilename.replace("[VERSION]", String(s)), this.readyPromise = this.fetchJson(t))
                            } else de.CACHE.has(de.LATEST_CACHE_KEY) ? (this.populate(de.CACHE.get(de.LATEST_CACHE_KEY)), this.readyPromise = Promise.resolve()) : (this.isLatest = !0, this.readyPromise = this.fetchJson(t + de.latestFilename))
                        }
                    }
                    static emptyLanguageCache(e) {
                        var t = !1;
                        return void 0 === e && de.LANGUAGE_CACHE.size > 0 ? (de.LANGUAGE_CACHE = new Map, t = !0) : "string" == typeof e && this.consentLanguages.has(e.toUpperCase()) && (de.LANGUAGE_CACHE.delete(e.toUpperCase()), t = !0), t
                    }
                    static emptyCache(e) {
                        var t = !1;
                        return Number.isInteger(e) && e >= 0 ? (de.CACHE.delete(e), t = !0) : void 0 === e && (de.CACHE = new Map, t = !0), t
                    }
                    cacheLanguage() {
                        de.LANGUAGE_CACHE.has(this.lang_) || de.LANGUAGE_CACHE.set(this.lang_, {
                            purposes: this.purposes,
                            specialPurposes: this.specialPurposes,
                            features: this.features,
                            specialFeatures: this.specialFeatures,
                            stacks: this.stacks
                        })
                    }
                    fetchJson(e) {
                        var t = this;
                        return (0, ae.Z)((function*() {
                            try {
                                t.populate(yield ue.fetch(e))
                            } catch (e) {
                                throw new E(e.message)
                            }
                        }))()
                    }
                    getJson() {
                        return JSON.parse(JSON.stringify({
                            gvlSpecificationVersion: this.gvlSpecificationVersion,
                            vendorListVersion: this.vendorListVersion,
                            tcfPolicyVersion: this.tcfPolicyVersion,
                            lastUpdated: this.lastUpdated,
                            purposes: this.purposes,
                            specialPurposes: this.specialPurposes,
                            features: this.features,
                            specialFeatures: this.specialFeatures,
                            stacks: this.stacks,
                            vendors: this.fullVendorList
                        }))
                    }
                    changeLanguage(e) {
                        var t = this;
                        return (0, ae.Z)((function*() {
                            var s = e.toUpperCase();
                            if (!de.consentLanguages.has(s)) throw new E("unsupported language " + e);
                            if (s !== t.lang_)
                                if (t.lang_ = s, de.LANGUAGE_CACHE.has(s)) {
                                    var i = de.LANGUAGE_CACHE.get(s);
                                    for (var n in i) i.hasOwnProperty(n) && (t[n] = i[n])
                                } else {
                                    var r = de.baseUrl + de.languageFilename.replace("[LANG]", e);
                                    try {
                                        yield t.fetchJson(r), t.cacheLanguage()
                                    } catch (e) {
                                        throw new E("unable to load language: " + e.message)
                                    }
                                }
                        }))()
                    }
                    get language() {
                        return this.lang_
                    }
                    isVendorList(e) {
                        return void 0 !== e && void 0 !== e.vendors
                    }
                    populate(e) {
                        this.purposes = e.purposes, this.specialPurposes = e.specialPurposes, this.features = e.features, this.specialFeatures = e.specialFeatures, this.stacks = e.stacks, this.isVendorList(e) && (this.gvlSpecificationVersion = e.gvlSpecificationVersion, this.tcfPolicyVersion = e.tcfPolicyVersion, this.vendorListVersion = e.vendorListVersion, this.lastUpdated = e.lastUpdated, "string" == typeof this.lastUpdated && (this.lastUpdated = new Date(this.lastUpdated)), this.vendors_ = e.vendors, this.fullVendorList = e.vendors, this.mapVendors(), this.isReady_ = !0, this.isLatest && de.CACHE.set(de.LATEST_CACHE_KEY, this.getJson()), de.CACHE.has(this.vendorListVersion) || de.CACHE.set(this.vendorListVersion, this.getJson())), this.cacheLanguage()
                    }
                    mapVendors(e) {
                        this.byPurposeVendorMap = {}, this.bySpecialPurposeVendorMap = {}, this.byFeatureVendorMap = {}, this.bySpecialFeatureVendorMap = {}, Object.keys(this.purposes).forEach((e => {
                            this.byPurposeVendorMap[e] = {
                                legInt: new Set,
                                consent: new Set,
                                flexible: new Set
                            }
                        })), Object.keys(this.specialPurposes).forEach((e => {
                            this.bySpecialPurposeVendorMap[e] = new Set
                        })), Object.keys(this.features).forEach((e => {
                            this.byFeatureVendorMap[e] = new Set
                        })), Object.keys(this.specialFeatures).forEach((e => {
                            this.bySpecialFeatureVendorMap[e] = new Set
                        })), Array.isArray(e) || (e = Object.keys(this.fullVendorList).map((e => +e))), this.vendorIds = new Set(e), this.vendors_ = e.reduce(((e, t) => {
                            var s = this.vendors_[String(t)];
                            return s && void 0 === s.deletedDate && (s.purposes.forEach((e => {
                                this.byPurposeVendorMap[String(e)].consent.add(t)
                            })), s.specialPurposes.forEach((e => {
                                this.bySpecialPurposeVendorMap[String(e)].add(t)
                            })), s.legIntPurposes.forEach((e => {
                                this.byPurposeVendorMap[String(e)].legInt.add(t)
                            })), s.flexiblePurposes && s.flexiblePurposes.forEach((e => {
                                this.byPurposeVendorMap[String(e)].flexible.add(t)
                            })), s.features.forEach((e => {
                                this.byFeatureVendorMap[String(e)].add(t)
                            })), s.specialFeatures.forEach((e => {
                                this.bySpecialFeatureVendorMap[String(e)].add(t)
                            })), e[t] = s), e
                        }), {})
                    }
                    getFilteredVendors(e, t, s, i) {
                        var n = e.charAt(0).toUpperCase() + e.slice(1),
                            r = {};
                        return ("purpose" === e && s ? this["by" + n + "VendorMap"][String(t)][s] : this["by" + (i ? "Special" : "") + n + "VendorMap"][String(t)]).forEach((e => {
                            r[String(e)] = this.vendors[String(e)]
                        })), r
                    }
                    getVendorsWithConsentPurpose(e) {
                        return this.getFilteredVendors("purpose", e, "consent")
                    }
                    getVendorsWithLegIntPurpose(e) {
                        return this.getFilteredVendors("purpose", e, "legInt")
                    }
                    getVendorsWithFlexiblePurpose(e) {
                        return this.getFilteredVendors("purpose", e, "flexible")
                    }
                    getVendorsWithSpecialPurpose(e) {
                        return this.getFilteredVendors("purpose", e, void 0, !0)
                    }
                    getVendorsWithFeature(e) {
                        return this.getFilteredVendors("feature", e)
                    }
                    getVendorsWithSpecialFeature(e) {
                        return this.getFilteredVendors("feature", e, void 0, !0)
                    }
                    get vendors() {
                        return this.vendors_
                    }
                    narrowVendorsTo(e) {
                        this.mapVendors(e)
                    }
                    get isReady() {
                        return this.isReady_
                    }
                    clone() {
                        var e = new de(this.getJson());
                        return this.lang_ !== de.DEFAULT_LANGUAGE && e.changeLanguage(this.lang_), e
                    }
                    static isInstanceOf(e) {
                        return "object" == typeof e && "function" == typeof e.narrowVendorsTo
                    }
                }
                de.LANGUAGE_CACHE = new Map, de.CACHE = new Map, de.LATEST_CACHE_KEY = 0, de.DEFAULT_LANGUAGE = "EN", de.consentLanguages = new O, de.baseUrl_ = void 0, de.latestFilename = "vendor-list.json", de.versionedFilename = "archives/vendor-list-v[VERSION].json", de.languageFilename = "purposes-[LANG].json";
                class le extends D {
                    constructor(e) {
                        super(), this.isServiceSpecific_ = !1, this.supportOOB_ = !0, this.useNonStandardStacks_ = !1, this.purposeOneTreatment_ = !1, this.publisherCountryCode_ = "AA", this.version_ = 2, this.consentScreen_ = 0, this.policyVersion_ = 2, this.consentLanguage_ = "EN", this.cmpId_ = 0, this.cmpVersion_ = 0, this.vendorListVersion_ = 0, this.numCustomPurposes_ = 0, this.gvl_ = void 0, this.created = void 0, this.lastUpdated = void 0, this.specialFeatureOptins = new F, this.purposeConsents = new F, this.purposeLegitimateInterests = new F, this.publisherConsents = new F, this.publisherLegitimateInterests = new F, this.publisherCustomConsents = new F, this.publisherCustomLegitimateInterests = new F, this.customPurposes = void 0, this.vendorConsents = new F, this.vendorLegitimateInterests = new F, this.vendorsDisclosed = new F, this.vendorsAllowed = new F, this.publisherRestrictions = new R, e && (this.gvl = e), this.updated()
                    }
                    set gvl(e) {
                        de.isInstanceOf(e) || (e = new de(e)), this.gvl_ = e, this.publisherRestrictions.gvl = e
                    }
                    get gvl() {
                        return this.gvl_
                    }
                    set cmpId(e) {
                        if (e = Number(e), !(Number.isInteger(e) && e > 1)) throw new L("cmpId", e);
                        this.cmpId_ = e
                    }
                    get cmpId() {
                        return this.cmpId_
                    }
                    set cmpVersion(e) {
                        if (e = Number(e), !(Number.isInteger(e) && e > -1)) throw new L("cmpVersion", e);
                        this.cmpVersion_ = e
                    }
                    get cmpVersion() {
                        return this.cmpVersion_
                    }
                    set consentScreen(e) {
                        if (e = Number(e), !(Number.isInteger(e) && e > -1)) throw new L("consentScreen", e);
                        this.consentScreen_ = e
                    }
                    get consentScreen() {
                        return this.consentScreen_
                    }
                    set consentLanguage(e) {
                        this.consentLanguage_ = e
                    }
                    get consentLanguage() {
                        return this.consentLanguage_
                    }
                    set publisherCountryCode(e) {
                        if (!/^([A-z]){2}$/.test(e)) throw new L("publisherCountryCode", e);
                        this.publisherCountryCode_ = e.toUpperCase()
                    }
                    get publisherCountryCode() {
                        return this.publisherCountryCode_
                    }
                    set vendorListVersion(e) {
                        if ((e = Number(e) >> 0) < 0) throw new L("vendorListVersion", e);
                        this.vendorListVersion_ = e
                    }
                    get vendorListVersion() {
                        return this.gvl ? this.gvl.vendorListVersion : this.vendorListVersion_
                    }
                    set policyVersion(e) {
                        if (this.policyVersion_ = parseInt(e, 10), this.policyVersion_ < 0) throw new L("policyVersion", e)
                    }
                    get policyVersion() {
                        return this.gvl ? this.gvl.tcfPolicyVersion : this.policyVersion_
                    }
                    set version(e) {
                        this.version_ = parseInt(e, 10)
                    }
                    get version() {
                        return this.version_
                    }
                    set isServiceSpecific(e) {
                        this.isServiceSpecific_ = e
                    }
                    get isServiceSpecific() {
                        return this.isServiceSpecific_
                    }
                    set useNonStandardStacks(e) {
                        this.useNonStandardStacks_ = e
                    }
                    get useNonStandardStacks() {
                        return this.useNonStandardStacks_
                    }
                    set supportOOB(e) {
                        this.supportOOB_ = e
                    }
                    get supportOOB() {
                        return this.supportOOB_
                    }
                    set purposeOneTreatment(e) {
                        this.purposeOneTreatment_ = e
                    }
                    get purposeOneTreatment() {
                        return this.purposeOneTreatment_
                    }
                    setAllVendorConsents() {
                        this.vendorConsents.set(this.gvl.vendors)
                    }
                    unsetAllVendorConsents() {
                        this.vendorConsents.empty()
                    }
                    setAllVendorsDisclosed() {
                        this.vendorsDisclosed.set(this.gvl.vendors)
                    }
                    unsetAllVendorsDisclosed() {
                        this.vendorsDisclosed.empty()
                    }
                    setAllVendorsAllowed() {
                        this.vendorsAllowed.set(this.gvl.vendors)
                    }
                    unsetAllVendorsAllowed() {
                        this.vendorsAllowed.empty()
                    }
                    setAllVendorLegitimateInterests() {
                        this.vendorLegitimateInterests.set(this.gvl.vendors)
                    }
                    unsetAllVendorLegitimateInterests() {
                        this.vendorLegitimateInterests.empty()
                    }
                    setAllPurposeConsents() {
                        this.purposeConsents.set(this.gvl.purposes)
                    }
                    unsetAllPurposeConsents() {
                        this.purposeConsents.empty()
                    }
                    setAllPurposeLegitimateInterests() {
                        this.purposeLegitimateInterests.set(this.gvl.purposes)
                    }
                    unsetAllPurposeLegitimateInterests() {
                        this.purposeLegitimateInterests.empty()
                    }
                    setAllSpecialFeatureOptins() {
                        this.specialFeatureOptins.set(this.gvl.specialFeatures)
                    }
                    unsetAllSpecialFeatureOptins() {
                        this.specialFeatureOptins.empty()
                    }
                    setAll() {
                        this.setAllVendorConsents(), this.setAllPurposeLegitimateInterests(), this.setAllSpecialFeatureOptins(), this.setAllPurposeConsents(), this.setAllVendorLegitimateInterests()
                    }
                    unsetAll() {
                        this.unsetAllVendorConsents(), this.unsetAllPurposeLegitimateInterests(), this.unsetAllSpecialFeatureOptins(), this.unsetAllPurposeConsents(), this.unsetAllVendorLegitimateInterests()
                    }
                    get numCustomPurposes() {
                        var e = this.numCustomPurposes_;
                        if ("object" == typeof this.customPurposes) {
                            var t = Object.keys(this.customPurposes).sort(((e, t) => Number(e) - Number(t)));
                            e = parseInt(t.pop(), 10)
                        }
                        return e
                    }
                    set numCustomPurposes(e) {
                        if (this.numCustomPurposes_ = parseInt(e, 10), this.numCustomPurposes_ < 0) throw new L("numCustomPurposes", e)
                    }
                    updated() {
                        var e = new Date,
                            t = new Date(Date.UTC(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate()));
                        this.created = t, this.lastUpdated = t
                    }
                }
                le.consentLanguages = de.consentLanguages;
                class pe {
                    static encode(e, t) {
                        var s, i = "";
                        return e = Q.process(e, t), (s = Array.isArray(null == t ? void 0 : t.segments) ? t.segments : new K(e, t)["" + e.version]).forEach(((t, n) => {
                            var r = "";
                            n < s.length - 1 && (r = "."), i += J.encode(e, t) + r
                        })), i
                    }
                    static decode(e, t) {
                        var s = e.split("."),
                            i = s.length;
                        t || (t = new le);
                        for (var n = 0; n < i; n++) {
                            var r = s[n],
                                o = U.decode(r.charAt(0)).substr(0, B.segmentType),
                                a = N.ID_TO_KEY[M.decode(o, B.segmentType).toString()];
                            J.decode(r, t, a)
                        }
                        return t
                    }
                }! function(e) {
                    e.PING = "ping", e.GET_TC_DATA = "getTCData", e.GET_IN_APP_TC_DATA = "getInAppTCData", e.GET_VENDOR_LIST = "getVendorList", e.ADD_EVENT_LISTENER = "addEventListener", e.REMOVE_EVENT_LISTENER = "removeEventListener"
                }($ || ($ = {})),
                function(e) {
                    e.STUB = "stub", e.LOADING = "loading", e.LOADED = "loaded", e.ERROR = "error"
                }(Y || (Y = {})),
                function(e) {
                    e.VISIBLE = "visible", e.HIDDEN = "hidden", e.DISABLED = "disabled"
                }(X || (X = {})),
                function(e) {
                    e.TC_LOADED = "tcloaded", e.CMP_UI_SHOWN = "cmpuishown", e.USER_ACTION_COMPLETE = "useractioncomplete"
                }(ee || (ee = {}));
                class ce {
                    constructor(e, t, s, i) {
                        this.listenerId = void 0, this.callback = void 0, this.next = void 0, this.param = void 0, this.success = !0, Object.assign(this, {
                            callback: e,
                            listenerId: s,
                            param: t,
                            next: i
                        });
                        try {
                            this.respond()
                        } catch (e) {
                            this.invokeCallback(null)
                        }
                    }
                    invokeCallback(e) {
                        var t = null !== e;
                        "function" == typeof this.next ? this.callback(this.next, e, t) : this.callback(e, t)
                    }
                }
                class fe extends ce {
                    respond() {
                        this.throwIfParamInvalid(), this.invokeCallback(new be(this.param, this.listenerId))
                    }
                    throwIfParamInvalid() {
                        if (!(void 0 === this.param || Array.isArray(this.param) && this.param.every(Number.isInteger))) throw new Error("Invalid Parameter")
                    }
                }
                class ve {
                    constructor(e) {
                        this.name = void 0, this.recalculations = void 0, this.cache = void 0, this.name = e, this.recalculations = 0, this.cache = new Map
                    }
                    get(e, t) {
                        var s = this.cache.get(e);
                        if (s) return s;
                        for (var i = arguments.length, n = new Array(i > 2 ? i - 2 : 0), r = 2; r < i; r++) n[r - 2] = arguments[r];
                        return s = t(...n), this.cache.set(e, s), this.recalculations++, s
                    }
                    clear() {
                        this.cache.clear(), this.recalculations = 0
                    }
                    size() {
                        return this.cache.size
                    }
                }
                class he {
                    static reset() {
                        delete this.cmpId, delete this.cmpVersion, delete this.eventStatus, delete this.gdprApplies, delete this.tcModel, delete this.tcString, delete this.tcfPolicyVersion, this.cmpStatus = Y.LOADING, this.disabled = !1, this.displayStatus = X.HIDDEN, this.eventQueue.clear(), this.restrictionsCache.clear()
                    }
                }
                he.apiVersion = "2", he.tcfPolicyVersion = void 0, he.eventQueue = new class {
                    constructor() {
                        this.eventQueue = new Map, this.queueNumber = 0
                    }
                    add(e) {
                        return this.eventQueue.set(this.queueNumber, e), this.queueNumber++
                    }
                    remove(e) {
                        return this.eventQueue.delete(e)
                    }
                    exec() {
                        this.eventQueue.forEach(((e, t) => {
                            new fe(e.callback, e.param, t, e.next)
                        }))
                    }
                    clear() {
                        this.queueNumber = 0, this.eventQueue.clear()
                    }
                    get size() {
                        return this.eventQueue.size
                    }
                }, he.cmpStatus = Y.LOADING, he.disabled = !1, he.displayStatus = X.HIDDEN, he.cmpId = void 0, he.cmpVersion = void 0, he.eventStatus = void 0, he.gdprApplies = void 0, he.tcModel = void 0, he.tcString = void 0, he.restrictionsCache = new class {
                    constructor() {
                        this.cacheBuckets = void 0, this.cacheBuckets = new Map
                    }
                    getBucket(e) {
                        var t = this.cacheBuckets.get(e);
                        return t || (t = new ve(e), this.cacheBuckets.set(e, t)), t
                    }
                    clear() {
                        this.cacheBuckets.forEach((e => e.clear()))
                    }
                    numberOfBuckets() {
                        return this.cacheBuckets.size
                    }
                    size() {
                        var e = 0;
                        return this.cacheBuckets.forEach((t => e += t.size())), e
                    }
                };
                class ge {
                    constructor() {
                        this.cmpId = he.cmpId, this.cmpVersion = he.cmpVersion, this.gdprApplies = he.gdprApplies, this.tcfPolicyVersion = he.tcfPolicyVersion
                    }
                }
                class me extends ge {
                    constructor() {
                        super(...arguments), this.cmpStatus = Y.ERROR
                    }
                }
                class be extends ge {
                    constructor(e, t) {
                        super(), this.tcString = void 0, this.listenerId = void 0, this.eventStatus = void 0, this.cmpStatus = void 0, this.isServiceSpecific = void 0, this.useNonStandardStacks = void 0, this.publisherCC = void 0, this.purposeOneTreatment = void 0, this.outOfBand = void 0, this.purpose = void 0, this.vendor = void 0, this.specialFeatureOptins = void 0, this.publisher = void 0, this.eventStatus = he.eventStatus, this.cmpStatus = he.cmpStatus, this.listenerId = t;
                        var s = he.restrictionsCache.getBucket(this.constructor.name);
                        if (he.gdprApplies) {
                            var i = he.tcModel;
                            this.tcString = he.tcString, this.isServiceSpecific = i.isServiceSpecific, this.useNonStandardStacks = i.useNonStandardStacks, this.purposeOneTreatment = i.purposeOneTreatment, this.publisherCC = i.publisherCountryCode;
                            var n = s.get(this.tcString, this.createRestrictions.bind(this), i.publisherRestrictions);
                            this.outOfBand = {
                                allowedVendors: this.createVectorField(i.vendorsAllowed, e),
                                disclosedVendors: this.createVectorField(i.vendorsDisclosed, e)
                            }, this.purpose = {
                                consents: this.createVectorField(i.purposeConsents),
                                legitimateInterests: this.createVectorField(i.purposeLegitimateInterests)
                            }, this.vendor = {
                                consents: this.createVectorField(i.vendorConsents, e),
                                legitimateInterests: this.createVectorField(i.vendorLegitimateInterests, e)
                            }, this.specialFeatureOptins = this.createVectorField(i.specialFeatureOptins), this.publisher = {
                                consents: this.createVectorField(i.publisherConsents),
                                legitimateInterests: this.createVectorField(i.publisherLegitimateInterests),
                                customPurpose: {
                                    consents: this.createVectorField(i.publisherCustomConsents),
                                    legitimateInterests: this.createVectorField(i.publisherCustomLegitimateInterests)
                                },
                                restrictions: n
                            }
                        }
                    }
                    createRestrictions(e) {
                        var t = {};
                        if (e.numRestrictions > 0)
                            for (var s = e.getMaxVendorId(), i = function() {
                                    var s = n.toString();
                                    e.getRestrictions(n).forEach((e => {
                                        var i = e.purposeId.toString();
                                        t[i] || (t[i] = {}), t[i][s] = e.restrictionType
                                    }))
                                }, n = 1; n <= s; n++) i();
                        return t
                    }
                    createVectorField(e, t) {
                        return t ? t.reduce(((t, s) => (t[String(s)] = e.has(Number(s)), t)), {}) : [...e].reduce(((e, t) => (e[t[0].toString(10)] = t[1], e)), {})
                    }
                }
                class Se extends be {
                    constructor(e) {
                        super(e), delete this.outOfBand
                    }
                    createVectorField(e) {
                        return [...e].reduce(((e, t) => e += t[1] ? "1" : "0"), "")
                    }
                    createRestrictions(e) {
                        var t = {};
                        if (e.numRestrictions > 0) {
                            var s = e.getMaxVendorId();
                            e.getRestrictions().forEach((e => {
                                t[e.purposeId.toString()] = "_".repeat(s)
                            }));
                            for (var i = function(s) {
                                    var i = s + 1;
                                    e.getRestrictions(i).forEach((e => {
                                        var i = e.restrictionType.toString(),
                                            n = e.purposeId.toString(),
                                            r = t[n].substr(0, s),
                                            o = t[n].substr(s + 1);
                                        t[n] = r + i + o
                                    }))
                                }, n = 0; n < s; n++) i(n)
                        }
                        return t
                    }
                }
                class Ce extends ge {
                    constructor() {
                        super(), this.cmpLoaded = !0, this.cmpStatus = he.cmpStatus, this.displayStatus = he.displayStatus, this.apiVersion = String(he.apiVersion), this.gvlVersion = void 0, he.tcModel && he.tcModel.vendorListVersion && (this.gvlVersion = +he.tcModel.vendorListVersion)
                    }
                }
                te = $.PING, se = $.GET_TC_DATA, ie = $.GET_IN_APP_TC_DATA, ne = $.GET_VENDOR_LIST, re = $.ADD_EVENT_LISTENER, oe = $.REMOVE_EVENT_LISTENER;
                class ye {}
                ye[te] = class extends ce {
                    respond() {
                        this.invokeCallback(new Ce)
                    }
                }, ye[se] = fe, ye[ie] = class extends fe {
                    respond() {
                        this.throwIfParamInvalid(), this.invokeCallback(new Se(this.param))
                    }
                }, ye[ne] = class extends ce {
                    respond() {
                        var e, t = he.tcModel,
                            s = t.vendorListVersion;
                        void 0 === this.param && (this.param = s), (e = this.param === s && t.gvl ? t.gvl : new de(this.param)).readyPromise.then((() => {
                            this.invokeCallback(e.getJson())
                        }))
                    }
                }, ye[re] = class extends fe {
                    respond() {
                        this.listenerId = he.eventQueue.add({
                            callback: this.callback,
                            param: this.param,
                            next: this.next
                        }), super.respond()
                    }
                }, ye[oe] = class extends ce {
                    respond() {
                        this.invokeCallback(he.eventQueue.remove(this.param))
                    }
                };
                class we {
                    static has(e) {
                        return "string" == typeof e && (e = Number(e)), this.set_.has(e)
                    }
                }
                we.set_ = new Set([0, 2, void 0, null]);
                var Ie = "__tcfapi";
                class _e {
                    constructor(e) {
                        if (this.callQueue = void 0, this.customCommands = void 0, e) {
                            var t = $.ADD_EVENT_LISTENER;
                            if (null != e && e[t]) throw new Error("Built-In Custom Commmand for " + t + " not allowed: Use " + $.GET_TC_DATA + " instead");
                            if (t = $.REMOVE_EVENT_LISTENER, null != e && e[t]) throw new Error("Built-In Custom Commmand for " + t + " not allowed");
                            null != e && e[$.GET_TC_DATA] && (e[$.ADD_EVENT_LISTENER] = e[$.GET_TC_DATA]), this.customCommands = e
                        }
                        try {
                            this.callQueue = window[Ie]() || []
                        } catch (e) {
                            this.callQueue = []
                        } finally {
                            window[Ie] = this.apiCall.bind(this), this.purgeQueuedCalls()
                        }
                    }
                    apiCall(e, t, s) {
                        for (var i = arguments.length, n = new Array(i > 3 ? i - 3 : 0), r = 3; r < i; r++) n[r - 3] = arguments[r];
                        if ("string" != typeof e) s(null, !1);
                        else if (we.has(t)) {
                            if ("function" != typeof s) throw new Error("invalid callback function");
                            he.disabled ? s(new me, !1) : this.isCustomCommand(e) || this.isBuiltInCommand(e) ? this.isCustomCommand(e) && !this.isBuiltInCommand(e) ? this.customCommands[e](s, ...n) : e === $.PING ? this.isCustomCommand(e) ? new ye[e](this.customCommands[e], n[0], null, s) : new ye[e](s, n[0]) : void 0 === he.tcModel ? this.callQueue.push([e, t, s, ...n]) : this.isCustomCommand(e) && this.isBuiltInCommand(e) ? new ye[e](this.customCommands[e], n[0], null, s) : new ye[e](s, n[0]) : s(null, !1)
                        } else s(null, !1)
                    }
                    purgeQueuedCalls() {
                        var e = this.callQueue;
                        this.callQueue = [], e.forEach((e => {
                            window[Ie](...e)
                        }))
                    }
                    isCustomCommand(e) {
                        return this.customCommands && "function" == typeof this.customCommands[e]
                    }
                    isBuiltInCommand(e) {
                        return void 0 !== ye[e]
                    }
                }
                class Pe {
                    constructor(e, t, s, i) {
                        void 0 === s && (s = !1), this.callResponder = void 0, this.isServiceSpecific = void 0, this.numUpdates = 0, this.throwIfInvalidInt(e, "cmpId", 2), this.throwIfInvalidInt(t, "cmpVersion", 0), he.cmpId = e, he.cmpVersion = t, he.tcfPolicyVersion = 2, this.isServiceSpecific = !!s, this.callResponder = new _e(i)
                    }
                    throwIfInvalidInt(e, t, s) {
                        if (!("number" == typeof e && Number.isInteger(e) && e >= s)) throw new Error("Invalid " + t + ": " + e)
                    }
                    update(e, t) {
                        if (void 0 === t && (t = !1), he.disabled) throw new Error("CmpApi Disabled");
                        he.cmpStatus = Y.LOADED, t ? (he.displayStatus = X.VISIBLE, he.eventStatus = ee.CMP_UI_SHOWN) : void 0 === he.tcModel ? (he.displayStatus = X.DISABLED, he.eventStatus = ee.TC_LOADED) : (he.displayStatus = X.HIDDEN, he.eventStatus = ee.USER_ACTION_COMPLETE), he.gdprApplies = null !== e, he.gdprApplies ? ("" === e ? (he.tcModel = new le, he.tcModel.cmpId = he.cmpId, he.tcModel.cmpVersion = he.cmpVersion) : he.tcModel = pe.decode(e), he.tcModel.isServiceSpecific = this.isServiceSpecific, he.tcfPolicyVersion = Number(he.tcModel.policyVersion), he.tcString = e) : he.tcModel = null, 0 === this.numUpdates ? this.callResponder.purgeQueuedCalls() : he.eventQueue.exec(), this.numUpdates++
                    }
                    disable() {
                        he.disabled = !0, he.cmpStatus = Y.ERROR
                    }
                }
                var Ae = s(11281),
                    ke = s(91604),
                    Te = s(60457),
                    Ee = s(16619),
                    Le = s(26926),
                    Ue = s(55974),
                    Oe = function(e, t) {
                        void 0 === t && (t = 2);
                        var s = {};
                        return e.map((e => {
                            s[e.id] = (0, A.Z)({}, e, {
                                name: "",
                                description: ""
                            }, 2 === t && {
                                descriptionLegal: ""
                            }, 2.2 === t && {
                                illustrations: []
                            })
                        })), s
                    },
                    xe = function(e, t) {
                        void 0 === t && (t = 2);
                        var s = {};
                        return e.map((e => {
                            s[e.id] = (0, A.Z)({
                                id: e.id,
                                purposes: e.purposeIds,
                                flexiblePurposes: e.flexiblePurposeIds,
                                specialPurposes: e.specialPurposeIds,
                                legIntPurposes: e.legIntPurposeIds,
                                features: e.featureIds,
                                specialFeatures: e.specialFeatureIds,
                                name: ""
                            }, 2 === t && {
                                policyUrl: ""
                            }, 2.2 === t && {
                                urls: [],
                                dataRetention: {},
                                dataDeclaration: []
                            })
                        })), s
                    },
                    De = s(23721),
                    Ve = s(8861),
                    Re = s(17832),
                    Ne = e => {
                        var t = new F;
                        return t.set(e.filter((e => e))), U.encode(H.encode(t))
                    },
                    Fe = e => {
                        var t = [];
                        return H.decode(U.decode(e)).set_.forEach((e => t.push(e))), t
                    },
                    Be = (e, t) => {
                        var s = !0;
                        for (var i of t.purposeIds) s = s && -1 !== e.purposes.enabled.indexOf(i);
                        for (var n of t.legIntPurposeIds) s = s && -1 !== e.purposes_li.enabled.indexOf(n);
                        if (t.specialFeatureIds)
                            for (var r of t.specialFeatureIds) {
                                (0, Ee.x6)(r) && (s = s && -1 !== e.purposes.enabled.indexOf(r))
                            }
                        return s
                    },
                    Me = (e, t, s, i) => {
                        var {
                            negative: n,
                            positive: r
                        } = t, o = -1 !== e.vendors.enabled.indexOf("google"), a = -1 !== e.vendors_li.enabled.indexOf("google"), u = i.purposeIds.length > 0, d = i.legIntPurposeIds.length > 0;
                        return (u && o || !u) && (d && a || !d) && s ? r || "1~7.12.35.62.66.70.89.93.108.122.144.149.153.162.167.184.196.221.241.253.259.272.311.317.323.326.338.348.350.415.440.448.449.482.486.491.494.495.540.571.574.585.587.588.590.725.733.780.817.839.864.867.932.938.981.986.1031.1033.1051.1092.1097.1126.1127.1170.1171.1186.1201.1204.1205.1211.1215.1230.1232.1236.1248.1276.1290.1301.1313.1344.1364.1365.1415.1419.1428.1449.1451.1509.1558.1564.1570.1577.1591.1651.1669.1712.1716.1720.1721.1725.1733.1753.1765.1799.1810.1834.1842.1870.1878.1889.1896.1911.1922.1929.2012.2072.2078.2079.2109.2177.2202.2253.2290.2299.2316.2357.2373.2526.2531.2571.2572.2575.2628.2663.2677.2776.2778.2779.2985.3033.3052.3154" : n || ""
                    },
                    je = (e, t) => e.length > 0 && t ? "1~" + e.join(".") : "",
                    ze = e => e.reduce(((e, t) => (0, A.Z)({}, e, {
                        [t.id]: (0, Le.U2)(t, "namespaces.google.id")
                    })), {}),
                    Ze = e => e.reduce(((e, t) => (0, A.Z)({}, e, {
                        [(0, Le.U2)(t, "namespaces.google.id")]: t.id
                    })), {}),
                    Ge = e => -1 !== (null == e ? void 0 : e.toISOString().indexOf("T00:00:00.000Z")),
                    qe = s(4108),
                    He = s(78461),
                    We = s(48766),
                    Ke = s(72424),
                    Je = e => {
                        var t;
                        return null == (t = e.website) ? void 0 : t.iabTCFCMPID
                    },
                    Qe = s(23605),
                    $e = e => {
                        switch (e) {
                            case "allow":
                            case "disallow":
                                return 0;
                            case "req-consent":
                                return 1;
                            case "req-li":
                                return 2
                        }
                    },
                    Ye = s(67336),
                    Xe = s(59303),
                    et = s(63205),
                    tt = s(58123),
                    st = s(36660),
                    it = s(15813),
                    nt = s(62382),
                    rt = s(18111),
                    ot = s(3370),
                    at = s(90327),
                    ut = s(35618),
                    dt = s(95071),
                    lt = (0, ut.Fl)((() => {
                        var e, t, s;
                        if (null == (e = dt.O.value) || !e.length || null == (t = at.L.value) || !t.length) return [];
                        return null == (s = at.L.value) ? void 0 : s.filter((e => {
                            var {
                                id: t
                            } = e;
                            return dt.O.value.includes(t)
                        }))
                    })),
                    pt = s(77122),
                    ct = s(53017);
                class ft extends ke.Z {
                    constructor(e, t, s) {
                        super(e, t, s), this.cmpApi = void 0, this.__tcfapi = void 0, this.encodedTCString = void 0, this.tcfApiInitialized = !1, this.iabVendorListWithAppliedRestrictions = {}, this.defaultConsentString = void 0, this.iabVendorListCore = {}
                    }
                    init() {
                        var e;
                        !0 === window.gdprAppliesGlobally && this.actions.setIgnoreCountry(!0), this.googleVendor = null == (e = ot.I.value) ? void 0 : e.google, this.stubVersion = this.getStubVersion()
                    }
                    getIABVisiblePurposesMap() {
                        return Ee.f3
                    }
                    isErrorLoggingEnabled() {
                        return !0 === (0, qe.q6)(this.store.getState())
                    }
                    getConsentData() {
                        return {
                            consentData: this.isConsentRequired || this.encodedTCString ? this.encodedTCString : "",
                            gdprApplies: this.isConsentRequired,
                            hasGlobalScope: !1
                        }
                    }
                    setupPublicAPIFromStoredItem() {
                        var e = this.services.UserService.isConsentRequired(),
                            t = e ? Ae.Wq(ct.I.value, this.services.StorageService.getStorageSources()) : null;
                        (t || !t && !e) && this.setupPublicAPI(e, t)
                    }
                    setupPublicAPIFromLocalStore() {
                        var e = this.services.UserService.isConsentRequired(),
                            t = e ? this.services.StorageService.getConsentStringFromLocalStore() : null;
                        if (!t && e) {
                            var s;
                            this.store.getState();
                            this.defaultConsentString = function(e, t, s, i, n, r, o) {
                                var a;
                                void 0 === o && (o = !0);
                                var u = t().map((e => {
                                        var {
                                            id: t
                                        } = e;
                                        return t
                                    })),
                                    d = (0, Le.I8)(s());
                                return o && (d.purposes_li.enabled.push(...u), d.vendors_li.enabled.push(...De.V.value)), d.vendors.disabled.push(...e), i(d, n, (null == (a = Ve.c.value) ? void 0 : a.purposes) || [], Re._.value, !0)
                            }(dt.O.value, this.services.WebsiteService.getPurposesBasedOnLegitimateInterest.bind(this.services.WebsiteService), this.services.StorageService.getTokenFromLocalStore.bind(this), this.tokenToIABConsentString.bind(this), Xe.S.value, 0, !(null != (s = tt.c.value) && s.combineLIAndConsent)), this.services.StorageService.setConsentStringToLocalStore(this.defaultConsentString), t = this.defaultConsentString
                        }
                        this.setupPublicAPI(e, t)
                    }
                    getAdditionalConsentString() {
                        var e = this.store.getState();
                        return ((e, t, s, i, n) => {
                            var {
                                negative: r,
                                positive: o
                            } = s, a = Be(t, e);
                            return n ? je(i, a) : Me(t, {
                                negative: r,
                                positive: o
                            }, a, e)
                        })(this.googleVendor, (0, He.NK)(e), {
                            negative: (0, qe.I9)(e),
                            positive: (0, qe.rr)(e)
                        }, (0, He.Rh)(e), (0, qe.Q2)(e))
                    }
                    setAdditionalConsentString() {
                        this.services.UserService.isConsentRequired() && this.actions.setDecodedAdditionalConsent(this.getAdditionalConsentString())
                    }
                    appendAdditionalConsentString(e) {
                        return e && this.googleVendor && (e.addtlConsent = (0, We.L8)(this.store.getState())), e
                    }
                    getTCData(e, t, s) {
                        if (t && t.gdprApplies && "tcloaded" === t.eventStatus && t.tcString === this.defaultConsentString) {
                            if (null !== t.listenerId) return null;
                            t.eventStatus = "cmpuishown"
                        }
                        e(this.appendAdditionalConsentString(t), s)
                    }
                    getStubVersion() {
                        var e;
                        return (null == (e = window.__tcfapi) ? void 0 : e.stubVersion) || 1
                    }
                    setupPublicAPI(e, t) {
                        this.actions.setVersion(Qe.t.defaultTCFVersion), !this.tcfApiInitialized && this.services.WebsiteService.isTCFEnabled() && (this.tcfApiInitialized = !0, this.isConsentRequired = e, this.cmpApi = new Pe(Je(this.store.getState()), Qe.t.defaultCMPVersion, !0, {
                            getTCData: this.getTCData.bind(this)
                        }), this.setCmpApiTcModel(!1, t), this.__tcfapi = this.cmpApi.callResponder, window.__tcfapi = (e, t, s, i) => this.handleCommand(e, i, s, t, !1), e && ((0, et.on)("notice.shown", (() => this.setCmpApiTcModel(!0, this.services.StorageService.getConsentStringFromLocalStore() || this.defaultConsentString))), (0, et.on)("notice.hidden", (() => this.setCmpApiTcModel(!1, this.services.StorageService.getConsentStringFromLocalStore() || this.defaultConsentString))), (0, et.on)("internal.consent.changed", (() => {
                            this.setCmpApiTcModel(!1, this.services.StorageService.getConsentStringFromLocalStore())
                        }))), (0, Te.SH)("__tcfapiCall", "__tcfapiReturn", this.handleCommand.bind(this), window.__tcfapiBuffer))
                    }
                    setCmpApiTcModel(e, t) {
                        return this.cmpApi ? (this.setAdditionalConsentString(), this.encodedTCString === t && this.uiVisible === e ? null : (this.uiVisible = e, this.encodedTCString = t, void this.cmpApi.update(t, e))) : null
                    }
                    handleCommand(e, t, s, i, n) {
                        if ("function" == typeof s) {
                            if (-1 === s.toString().indexOf("postMessage") && n && 1 === this.stubVersion) {
                                var r = t;
                                t = i, i = r
                            }
                            i = this.formatTcfApiCallVersion(i), this.isErrorLoggingEnabled() ? this.__tcfapi.apiCall(e, i, (0, Ke.Y7)(s), t) : this.__tcfapi.apiCall(e, i, s, t)
                        }
                    }
                    formatTcfApiCallVersion(e) {
                        return "null" === e ? null : e
                    }
                    importIABTexts() {
                        return new Promise
                    }
                    getIABVendorListCore(e) {
                        if (!e) return this.iabVendorListCore;
                        if (!(0, Le.xb)(this.iabVendorListWithAppliedRestrictions)) return this.iabVendorListWithAppliedRestrictions;
                        var t = nt.s.value;
                        return 0 === t.length ? this.iabVendorListCore : (this.iabVendorListWithAppliedRestrictions = (0, A.Z)({}, this.iabVendorListCore, {
                            vendors: this.iabVendorListCore.vendors.map((e => {
                                var s = (0, A.Z)({}, e, {
                                    purposeIds: e.purposeIds.filter((s => !(0, Ye.E)(s, e.id, "req-li", t, !1))),
                                    legIntPurposeIds: e.legIntPurposeIds.filter((s => !(0, Ye.E)(s, e.id, "req-consent", t, !1))),
                                    specialFeatureIds: e.specialFeatureIds.filter((s => !(0, Ye.E)(s, e.id, "disallow", t, !0)))
                                });
                                return s.purposeIds = (0, Ue.hg)([...s.purposeIds, ...(0, it.j)(e, "req-consent", t)]), s.legIntPurposeIds = (0, Ue.hg)([...s.legIntPurposeIds, ...(0, it.j)(e, "req-li", t)]), !(0, rt.u)(s) && s
                            })).filter(Boolean)
                        }), this.iabVendorListWithAppliedRestrictions)
                    }
                    getGVLVendorListData() {
                        var e = this.getIABVendorListCore(!1);
                        return {
                            vendorListVersion: e.vendorListVersion,
                            lastUpdated: e.lastUpdated,
                            gvlSpecificationVersion: e.gvlSpecificationVersion,
                            tcfPolicyVersion: e.tcfPolicyVersion,
                            purposes: Oe(e.purposes, pt.m.value.semVersion),
                            specialPurposes: Oe(e.specialPurposes, pt.m.value.semVersion),
                            features: Oe(e.features, pt.m.value.semVersion),
                            specialFeatures: Oe(e.specialFeatures, pt.m.value.semVersion),
                            stacks: Oe(e.stacks, pt.m.value.semVersion),
                            vendors: xe(e.vendors, pt.m.value.semVersion)
                        }
                    }
                    tokenToIABConsentString(e, t, s, i, n, r) {
                        var o;
                        void 0 === r && (r = null);
                        var a = this.store.getState(),
                            u = new Set(Ee.x1),
                            d = (0, Le.U2)(e, "purposes.enabled") || [],
                            l = d.filter((e => u.has(e))),
                            p = (0, Le.U2)(e, "vendors.enabled") || [],
                            c = (0, Le.U2)(e, "vendors_li.enabled") || [],
                            f = (0, Le.U2)(e, "purposes_li.enabled") || [],
                            v = (0, Ke.wh)(new Date((0, Le.U2)(e, "created"))),
                            h = (0, Ke.wh)(new Date((0, Le.U2)(e, "updated"))),
                            g = (0, qe.m6)(a),
                            {
                                iabPurposesStatus: m,
                                iabVendorsStatus: b
                            } = (0, Ee.Xo)(d, p, s, i, 2),
                            {
                                iabPurposesStatus: S,
                                iabVendorsStatus: C
                            } = (0, Ee.Xo)(f, c, s, i, 2),
                            y = this.getGVLVendorListData(),
                            w = new de(y),
                            I = new le(w);
                        I.vendorListVersion = y.vendorListVersion, I.cmpId = r || Je(a), I.cmpVersion = Qe.t.defaultCMPVersion, I.created = v, I.lastUpdated = h, I.consentScreen = 1, I.consentLanguage = t, I.isServiceSpecific = !0, g && (I.publisherCountryCode = g);
                        var _ = (0, Le.Xm)(m),
                            P = (0, Le.Xm)(S),
                            A = (0, Le.Xm)(b),
                            k = (0, Le.Xm)(C);
                        if (I.purposeConsents.set(_), I.purposeLegitimateInterests.set(P), I.vendorConsents.set(A), I.vendorLegitimateInterests.set(k), I.publisherConsents.set(_), I.publisherLegitimateInterests.set(P), I.specialFeatureOptins.set(l.map((e => Ee.eb[e]))), (null == (o = nt.s.value) ? void 0 : o.length) > 0)
                            for (var T of nt.s.value) {
                                var E = new V;
                                if (E.purposeId = (0, Ee.rP)(T.purposeId), void 0 !== E.purposeId)
                                    if (E.restrictionType = $e(T.restrictionType), "all" === T.vendorRestrictionType) I.publisherRestrictions.restrictPurposeToLegalBasis(E);
                                    else
                                        for (var L of T.vendors) I.publisherRestrictions.add(L, E)
                            }
                        return n ? pe.encode(I) : I
                    }
                    decodeIABConsentString(e, t) {
                        try {
                            var s = pe.decode(e);
                            return t && s.cmpId !== Je(this.store.getState()) && s.cmpId !== Qe.t.defaultCMPID ? null : s
                        } catch (e) {
                            return null
                        }
                    }
                    getMaxVendorID() {
                        var e = Object.keys(this.getGVLVendorListData().vendors).map((e => parseInt(e)));
                        return Math.max(...e)
                    }
                    getVendorsAndPurposesStatuses(e, t, s) {
                        var i, {
                                vendorConsents: n,
                                vendorLegitimateInterests: r,
                                purposeConsents: o,
                                purposeLegitimateInterests: a,
                                specialFeatureOptins: u
                            } = e,
                            d = [];
                        n.set_.forEach((e => {
                            e !== Ee.OE.google && d.push(e)
                        }));
                        var l = t.filter((e => -1 === d.indexOf(e))),
                            p = [];
                        o.set_.forEach((e => p.push(e)));
                        var c = p.map((e => (0, Ee.ry)(e, 2))),
                            f = Object.keys(s).filter((e => -1 === c.indexOf(e))),
                            v = [];
                        r.set_.forEach((e => {
                            e !== Ee.OE.google && v.push(e)
                        }));
                        var h = t.filter((e => -1 === v.indexOf(e))),
                            g = [];
                        a.set_.forEach((e => g.push(e)));
                        var m = g.map((e => (0, Ee.ry)(e, 2))),
                            b = Object.keys(s).filter((e => -1 === m.indexOf(e))),
                            S = this.store.getState(),
                            C = (0, qe.jo)(S);
                        if (null != (i = st.L.value) && i.isDidomiConsentStringEncodingEnabled) {
                            var y = [];
                            u.set_.forEach((e => y.push(e))), c.push(...y.map((e => (0, Ee.x6)(e)))), f.push(...Ee.x1.filter((e => -1 === c.indexOf(e))).filter((e => -1 !== C.indexOf(e))))
                        }
                        return {
                            enabledIABvendors: d,
                            disabledIABvendors: l,
                            enabledIABpurposes: c,
                            disabledIABpurposes: f,
                            enabledLIIABvendors: v,
                            disabledLIIABvendors: h,
                            enabledLIIABpurposes: m,
                            disabledLIIABpurposes: b
                        }
                    }
                    fixConsentString(e, t) {
                        return void 0 === t && (t = null), t ? ((e, t, s, i, n, r) => {
                            var o;
                            return Ge(t.created) && Ge(t.lastUpdated) && (null == e ? void 0 : e.length) <= 500 ? e : i(s, n, (null == (o = Ve.c.value) ? void 0 : o.purposes) || [], Re._.value, !0)
                        })(e, pe.decode(e), t, this.tokenToIABConsentString.bind(this), Xe.S.value, this.store.getState()) : e
                    }
                    atpTokenFromDidomiToken(e) {
                        return ((e, t) => {
                            if (0 === t.length) return null;
                            var s = t.map((e => {
                                    var {
                                        id: t
                                    } = e;
                                    return t
                                })),
                                i = ze(t),
                                n = e.vendors.enabled.filter((e => -1 !== s.indexOf(e))).map((e => i[e])),
                                r = e.vendors_li.enabled.filter((e => -1 !== s.indexOf(e))).map((e => i[e]));
                            return Ne(n) + "." + Ne(r)
                        })(e, lt.value)
                    }
                    removeATPVendorsFromDidomiToken(e) {
                        var t, s = null == (t = at.L.value) ? void 0 : t.map((e => {
                                var {
                                    id: t
                                } = e;
                                return t
                            })),
                            i = e => -1 === s.indexOf(e);
                        return (0, A.Z)({}, e, {
                            vendors: {
                                enabled: e.vendors.enabled.filter(i),
                                disabled: e.vendors.disabled.filter(i)
                            },
                            vendors_li: {
                                enabled: e.vendors_li.enabled.filter(i),
                                disabled: e.vendors_li.disabled.filter(i)
                            }
                        })
                    }
                    decodeAddtlConsent(e) {
                        return e ? ((e, t) => {
                            var [s, i] = e.split("."), n = Ze(t), r = Fe(s).map((e => n[e])), o = Fe(i).map((e => n[e])), a = t.map((e => {
                                var {
                                    id: t
                                } = e;
                                return t
                            }));
                            return {
                                vendors: {
                                    enabled: r.filter((e => e)),
                                    disabled: a.filter((e => -1 === r.indexOf(e)))
                                },
                                vendors_li: {
                                    enabled: o.filter((e => e)),
                                    disabled: a.filter((e => -1 === o.indexOf(e)))
                                }
                            }
                        })(e, at.L.value) : null
                    }
                }
            },
            39102: function(e, t, s) {
                "use strict";
                s.r(t), s.d(t, {
                    default: function() {
                        return o
                    }
                });
                var i = s(67301),
                    n = s(595),
                    r = s(27223);
                class o extends i.Z {
                    constructor(e, t, s) {
                        super(e, t, s), this.iabVendorListCore = n.default
                    }
                    importIABTexts() {
                        return s.e("iab-texts").then(s.bind(s, 66679))
                    }
                    getIABVisiblePurposesMap() {
                        return r.iabPurposesDidomiIdMap
                    }
                }
            },
            595: function(e, t, s) {
                "use strict";
                s.r(t), s.d(t, {
                    default: function() {
                        return n
                    }
                });
                var i = JSON.parse('{"v":224,"l":"2023-11-16T16:05:29Z","I":2,"V":2,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2],"s":[{"i":1,"p":[1,2,3,4,7,8,9,10],"fp":[7,8,9,10],"sp":[1,2],"f":[1,2,3]},{"i":2,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[2],"sf":[2]},{"i":4,"p":[1,2,3,4,7,9,10],"f":[1,2,3],"sf":[1]},{"i":6,"p":[1,2,3,4,7,9],"sp":[1,2],"f":[3]},{"i":7,"p":[1,3,4,5,6,7,8,9,10],"sp":[1],"f":[3]},{"i":8,"p":[1,3,4],"fp":[2,9],"sp":[1,2],"l":[2,7,8,9],"f":[1,2]},{"i":9,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1]},{"i":10,"p":[1,2,7],"fp":[2,7],"sp":[1,2],"l":[10],"f":[1,3],"sf":[1]},{"i":11,"p":[1,3,4],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3]},{"i":12,"p":[1,2,3,4,7],"sp":[1,2],"f":[1,3],"sf":[1]},{"i":13,"p":[1,2,3,5,7,9,10],"sp":[1,2],"f":[1,2,3]},{"i":14,"p":[1,3,4,9,10],"sp":[1,2],"l":[2,7],"f":[3],"sf":[1,2]},{"i":15,"p":[1,2,3,4,5,6,9,10],"sp":[1,2],"l":[7,8],"f":[2]},{"i":16,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1]},{"i":18,"p":[1,2,3,4,7],"fp":[2,3,4,7],"f":[2,3],"sf":[1,2]},{"i":20,"p":[1,3,4],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2]},{"i":21,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[1,2,3],"sf":[1]},{"i":22,"p":[7,8],"f":[2]},{"i":23,"p":[1,2,3,4],"sp":[1,2],"l":[7,9,10],"f":[1,2,3]},{"i":24,"p":[1,2,3,4,5,6,7,9,10],"sp":[1,2],"f":[1,2,3]},{"i":25,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":26,"p":[1,2,3,4,7,8,9,10],"f":[3]},{"i":27,"p":[1,2,4,7],"fp":[2,7],"sp":[1,2]},{"i":28,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"sf":[1]},{"i":29,"p":[1,2,3,4,7,8,10],"f":[1]},{"i":30,"p":[1,3,4,7],"fp":[2],"sp":[1,2],"l":[2],"f":[2]},{"i":31,"p":[1],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1]},{"i":32,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[2,3],"sf":[1]},{"i":33,"p":[1,3,5],"f":[1,2,3]},{"i":34,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[2,3]},{"i":36,"p":[1,3,4,9],"sp":[1,2],"l":[2,7,10],"f":[1,2,3]},{"i":37,"p":[1,3,4,7],"sp":[1,2],"f":[1,2],"sf":[2]},{"i":39,"p":[1,2,3,4,7,9,10],"fp":[2,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":40,"p":[1,2,3,4,7,9,10],"fp":[2,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":41,"p":[1,2,3,4,5,6,7,10],"sp":[1,2]},{"i":42,"p":[1,2,3,4,5,6,7,8,10],"fp":[2,7,8,10],"sp":[1,2],"f":[1,2,3]},{"i":44,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3]},{"i":45,"p":[1,2,4,7,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":46,"fp":[7,8],"sp":[1,2],"l":[7,8,10],"f":[3]},{"i":47,"p":[1,2,3,4,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2]},{"i":48,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[3]},{"i":49,"p":[1,2,3,4,5,6],"fp":[7,8,9,10],"l":[7,8,9,10],"f":[1,2],"sf":[1]},{"i":50,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[2,3]},{"i":51,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":52,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[1,2,3],"sf":[1]},{"i":53,"p":[1,3,4,5,6,9],"fp":[2,7,8,10],"sp":[1,2],"l":[2,7,8,10],"f":[1,2,3]},{"i":55,"p":[1,2,3,4,5,6,7,8,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":56,"sp":[1,2]},{"i":57,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3]},{"i":58,"p":[1,2,3,4,7,10],"sp":[1,2],"f":[2,3],"sf":[2]},{"i":59,"p":[2],"fp":[2],"sp":[2],"f":[3],"sf":[1]},{"i":60,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3]},{"i":61,"p":[1,2,3,4,7],"fp":[2,7],"sp":[1,2],"f":[3]},{"i":62,"p":[1,2,7],"sp":[1,2]},{"i":63,"sp":[1],"l":[7]},{"i":65,"p":[1,7,8,9,10],"f":[1],"sf":[1]},{"i":66,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":67,"p":[1,3,4],"fp":[2,5,6,7,8,10],"sp":[1,2],"l":[2,5,6,7,8,10],"f":[3],"sf":[1]},{"i":68,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2]},{"i":69,"p":[1,2,7,10],"fp":[2,7,10],"sp":[1,2]},{"i":70,"p":[1,2,3,4,7,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":71,"p":[1,3,4],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3],"sf":[1]},{"i":72,"p":[2,7,9,10],"sp":[1,2]},{"i":73,"p":[1,2,3,4,10],"f":[2],"sf":[1]},{"i":75,"p":[1,2,3,4,8,10],"f":[1]},{"i":76,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":77,"p":[1,7,8,9,10],"f":[1,2,3]},{"i":78,"p":[1,2,3,4,7],"fp":[7],"sp":[1,2],"f":[2,3]},{"i":79,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[1,2,3],"sf":[1]},{"i":80,"p":[1,2],"sp":[1,2],"l":[7]},{"i":81,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2],"sf":[1]},{"i":82,"p":[1,2,3,4,7,9],"fp":[2,7,9,10],"sp":[1,2],"l":[10],"f":[1,3],"sf":[1]},{"i":83,"fp":[8],"sp":[2],"l":[8]},{"i":84,"p":[1,3,9,10]},{"i":85,"p":[1,3,4],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,3],"sf":[1]},{"i":86,"p":[1],"fp":[2,3,4,7],"sp":[1,2],"l":[2,3,4,7,10]},{"i":87,"p":[1,2,3,4,7],"f":[1,2,3]},{"i":88,"p":[1,3,4],"fp":[2,3,4,7,10],"sp":[1,2],"l":[2,7,10],"f":[1,3]},{"i":89,"p":[1],"f":[2]},{"i":90,"p":[1,2,7,9],"sp":[1]},{"i":91,"p":[1,2,3,4,7,9,10],"sp":[1],"f":[1,2,3]},{"i":92,"p":[1,3,5],"fp":[7,8,9],"l":[7,8,9],"f":[1,2]},{"i":93,"p":[1],"fp":[7],"sp":[1],"l":[7]},{"i":94,"p":[1,2,3,4,7,9,10],"fp":[2],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":95,"p":[1,3,5,7,8,9,10],"f":[1,2,3]},{"i":97,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1],"f":[1,2]},{"i":98,"p":[1,2,3,4,5,6],"fp":[7,8,9,10],"sp":[1,2],"l":[7,8,9,10],"f":[1,2],"sf":[1]},{"i":100,"p":[1,2,3,4,9,10],"sp":[1,2],"f":[1,2,3]},{"i":101,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":102,"p":[1],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[1,2,3],"sf":[1]},{"i":104,"p":[1,2,3,4],"sp":[2],"l":[7,8],"f":[1]},{"i":108,"p":[1,2,7,8,9,10],"f":[2,3]},{"i":109,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":110,"p":[1,7,9],"f":[1,2,3]},{"i":111,"p":[1,3,4,9,10],"fp":[2,7,8],"sp":[1,2],"l":[2,7,8],"f":[1]},{"i":114,"p":[1,2,3,4,7,9,10]},{"i":115,"p":[1,2,3,4,7,10],"fp":[2,7,10],"sp":[1,2],"f":[2,3]},{"i":119,"p":[1,3,4,7,8,9,10],"fp":[7,8,9,10],"sp":[1,2],"sf":[1]},{"i":120,"p":[1,3,5,9,10],"sp":[1],"f":[1,2,3]},{"i":122,"p":[1,3,4,5,10],"fp":[2,7,8],"sp":[1,2],"l":[2,7,8]},{"i":124,"p":[1,2,3,4,7],"sp":[1,2],"f":[1],"sf":[1]},{"i":126,"fp":[2,7,10],"sp":[1,2],"l":[2,7,10]},{"i":127,"p":[1,2,3,4,7,8],"sp":[2],"f":[3],"sf":[1]},{"i":128,"p":[1,2,7,9,10],"f":[1,3],"sf":[1]},{"i":129,"p":[1,2,3,4,7,9,10],"f":[1,2,3]},{"i":130,"p":[1,2,3,4,5,6,7,9,10],"sp":[1,2],"f":[1,2]},{"i":131,"p":[1],"f":[2,3]},{"i":132,"p":[1,3,4,7,9,10],"fp":[2],"sp":[1,2],"l":[2],"f":[1,2,3]},{"i":133,"p":[1,3,5,7,9],"f":[1,2,3]},{"i":134,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3]},{"i":136,"p":[1,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10]},{"i":137,"p":[1,3,4,5],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3]},{"i":138,"p":[1,2,3,4,7,10],"fp":[2,7,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":139,"p":[1,2,3,4,7,9,10],"sp":[1,2]},{"i":140,"p":[1,2,3,4,7,10],"sp":[1,2],"f":[2,3],"sf":[1]},{"i":141,"p":[1,2,3,4,5,6,7,8,9],"sp":[1],"f":[1,3],"sf":[1]},{"i":142,"p":[1,3,4,5,6],"fp":[2,8,9],"sp":[1,2],"l":[2,7,8,9,10],"f":[3]},{"i":143,"p":[1,2],"f":[3],"sf":[1]},{"i":144,"p":[1,2,4,7,10],"sp":[2],"f":[3],"sf":[1]},{"i":145,"p":[1],"sp":[1,2],"l":[2,7,8,9,10],"f":[3]},{"i":147,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[7,8,9,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":148,"p":[2,7]},{"i":149,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2],"f":[2,3]},{"i":150,"p":[1,3,4,9,10],"fp":[2,7],"sp":[1,2],"l":[2,7],"f":[2,3]},{"i":151,"p":[1,2,3,4,7],"sf":[1]},{"i":152,"p":[1,9],"fp":[7],"sp":[1],"l":[7]},{"i":153,"p":[1,2,3,4,7,8,9,10],"sp":[1,2],"f":[1,3],"sf":[1,2]},{"i":154,"p":[1,3,4,10],"fp":[2,7],"sp":[1,2],"l":[2,7],"f":[1,3],"sf":[1]},{"i":155,"p":[1,2,3,4,7],"sp":[2]},{"i":156,"p":[1,3,4],"fp":[7],"sp":[1,2],"l":[2,7,10],"f":[2,3],"sf":[1]},{"i":157,"p":[1,2,7,9,10],"sp":[1,2]},{"i":158,"p":[1,2,3,4,7,9,10],"f":[1,2,3],"sf":[1]},{"i":159,"p":[1,2,7],"sp":[1,2]},{"i":160,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":161,"p":[1,2,3,4,7,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":162,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":163,"p":[1,3],"fp":[7,9,10],"sp":[1],"l":[7,9,10],"f":[1,3]},{"i":164,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[2]},{"i":165,"p":[1],"fp":[2,7,8,10],"sp":[1,2],"l":[2,7,8,10],"f":[3],"sf":[2]},{"i":167,"p":[1,9],"f":[1,2,3],"sf":[1,2]},{"i":168,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":170,"p":[7,8,9,10],"fp":[7,8,9,10],"f":[1,2],"sf":[1]},{"i":173,"p":[1,2,3,4,7,9,10],"fp":[2,7,9,10],"sp":[1,2],"f":[1,2,3]},{"i":174,"p":[2,6,7],"fp":[2,7],"sp":[1,2]},{"i":177,"p":[1],"fp":[7,8,10],"sp":[1,2],"l":[7,8,10]},{"i":178,"p":[1,2,3,4,7,8,9,10],"sp":[1,2],"f":[1,3]},{"i":179,"p":[1,2,3,4,9],"sp":[1,2],"l":[7],"sf":[1]},{"i":183,"p":[1,3,4,5,6,8],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3],"sf":[1]},{"i":184,"p":[1,3]},{"i":185,"p":[2,3,4,5,6,7],"f":[1,2,3]},{"i":190,"p":[1,2,3,4,7,8,9,10],"sp":[1,2],"f":[1,3]},{"i":192,"p":[1],"fp":[2,7,8,9,10],"sp":[2],"l":[2,7,8,9,10],"f":[1]},{"i":193,"p":[2,3,4,7,9,10],"f":[2,3],"sf":[1]},{"i":194,"p":[1,2,3,4,7,10],"fp":[2],"sp":[1,2],"f":[3]},{"i":195,"p":[1,3,4],"fp":[2,7],"sp":[1,2],"l":[2,7]},{"i":196,"p":[1,2,3,4,7,9,10],"fp":[2,7,9,10],"sp":[1,2],"f":[2,3],"sf":[1]},{"i":198,"p":[1,2,3,4,7],"fp":[3,4,7]},{"i":199,"p":[1,2,3,4,7,9],"sf":[1]},{"i":200,"p":[1,9],"fp":[2,3,4,7,9,10],"sp":[1,2],"l":[2,3,4,7,10],"f":[2,3]},{"i":202,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[1,2,3],"sf":[1,2]},{"i":203,"fp":[2],"sp":[1,2],"l":[2],"f":[3],"sf":[2]},{"i":205,"l":[7,8,9,10]},{"i":206,"p":[1,2,3,4,7,8,9,10],"fp":[2],"f":[1,2,3],"sf":[1,2]},{"i":208,"p":[2,3,4,7,10],"sp":[2],"f":[1,3],"sf":[1]},{"i":209,"p":[1,2,3,4],"fp":[2,7,10],"sp":[1,2],"l":[7,10],"sf":[1]},{"i":210,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,3],"sf":[2]},{"i":211,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":212,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1]},{"i":213,"p":[1,2,3,5,7,8,9,10],"f":[1,2,3]},{"i":215,"p":[1,7]},{"i":216,"p":[1,2,3,5,7,8,9,10],"sp":[1],"f":[1]},{"i":217,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10]},{"i":218,"p":[1,3,4],"sp":[1],"l":[2,5,6,7,8,9,10],"f":[3],"sf":[1]},{"i":223,"p":[1],"fp":[7,8],"l":[7,8],"f":[2]},{"i":224,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sf":[1]},{"i":226,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":227,"p":[1,2,3,4,7,9,10],"fp":[2,7,9,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":228,"p":[1,2,3,4,5,6],"sp":[1,2],"l":[7,8,10],"f":[3]},{"i":230,"p":[1],"sp":[1,2],"l":[2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":231,"p":[1,3,4],"fp":[2,7,8,10],"sp":[1,2],"l":[2,7,8,10],"f":[2]},{"i":232,"p":[1],"l":[7],"f":[1,2,3]},{"i":234,"p":[1,3,4,9],"sp":[1,2],"l":[2,7,10],"f":[1]},{"i":235,"p":[1,2,3,4,7,9],"fp":[2,3,4,7,9],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":236,"p":[1,2],"fp":[3,4,5,6],"sp":[1,2],"l":[3,4,5,6,7,8],"f":[1]},{"i":237,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":238,"p":[1,3,4,5,6],"fp":[2,7,8],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":239,"p":[1,4],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,3],"sf":[1]},{"i":240,"p":[1],"sp":[1,2],"l":[5,6,8,10]},{"i":241,"p":[1,2,3,4,7,9,10],"fp":[2,7],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":242,"p":[1,2,3,4,7],"f":[3]},{"i":243,"p":[1,2,3,4,7,9,10],"sp":[1],"f":[1,2,3]},{"i":244,"p":[1,2,3,4,7,9,10],"f":[1,2,3]},{"i":246,"p":[1,3,4,8],"fp":[2,7],"sp":[1,2],"l":[2,7]},{"i":248,"p":[1,7],"fp":[2],"sp":[2],"l":[2],"f":[3]},{"i":249,"p":[1,2,4,7,10],"sp":[1,2],"f":[2,3],"sf":[1]},{"i":250,"p":[2,3,4,5,6,7,8,9,10],"sp":[2]},{"i":251,"p":[1],"fp":[2,7],"sp":[1,2],"l":[2,7,10]},{"i":252,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[3],"sf":[1]},{"i":253,"p":[1,3,4,9],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[3],"sf":[1]},{"i":254,"p":[1,2,3,4,7],"sp":[1,2],"f":[3],"sf":[1]},{"i":255,"p":[1,3,4,5,6],"fp":[2,7,8],"sp":[2],"l":[2,7,8]},{"i":256,"p":[1,3,4],"fp":[2],"sp":[1,2],"l":[2,7,9,10],"f":[1,2]},{"i":259,"p":[1,2,3,4,7],"sp":[1,2],"f":[3]},{"i":261,"p":[1],"fp":[3],"sp":[1,2],"l":[3,5,7,8],"f":[1,2]},{"i":262,"p":[1,2,3,4,5,7],"f":[3],"sf":[2]},{"i":263,"p":[1,3,4],"sp":[1,2],"l":[2,7,9,10],"f":[2]},{"i":264,"p":[1,2,3,4,10],"fp":[2],"sp":[1,2],"l":[7],"f":[3]},{"i":265,"p":[1,2,3,4,5,6,7,8],"sp":[1,2],"l":[9,10],"f":[3],"sf":[1]},{"i":266,"p":[1,2,3,4,5,6,7,8,9],"f":[1,2,3]},{"i":270,"p":[1]},{"i":272,"p":[1,2,3,4,7,9,10],"f":[1,2,3],"sf":[1]},{"i":273,"p":[1,4],"sp":[1,2],"l":[7]},{"i":274,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[2]},{"i":275,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":276,"p":[1,3,4,9,10],"fp":[2,7,8],"sp":[1,2],"l":[2,7,8],"f":[1]},{"i":277,"p":[1,2,3,4,5,6,7,8,9],"fp":[8],"sp":[1,2],"l":[10],"f":[1,2,3]},{"i":278,"fp":[7,10],"sp":[1],"l":[7,10],"f":[1,3]},{"i":279,"fp":[2,7],"sp":[1,2],"l":[2,7]},{"i":280,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10]},{"i":281,"p":[1,7,8,9],"fp":[7,8,9],"f":[1,2]},{"i":282,"p":[1],"fp":[2],"sp":[2],"l":[2]},{"i":284,"p":[1,3,4,5,6,10],"sp":[2],"l":[2,7,8,9],"f":[1,2],"sf":[1]},{"i":285,"p":[1,2,4],"fp":[2,7,10],"sp":[1,2],"l":[7,10],"f":[3]},{"i":289,"p":[1,2,3,4,7,9,10],"f":[1],"sf":[1]},{"i":290,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":293,"p":[1],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[3],"sf":[1,2]},{"i":294,"p":[1,2,3,4,7],"fp":[2,7],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":295,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sp":[2],"f":[1,2]},{"i":297,"fp":[2,7,8,10],"sp":[1,2],"l":[2,7,8,10]},{"i":298,"p":[1,2,3,4,7,9,10],"sp":[1],"f":[1],"sf":[1]},{"i":299,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sp":[2],"f":[1,2]},{"i":301,"p":[1,3,4,5,6,9,10],"f":[1,2,3]},{"i":302,"p":[2],"f":[3],"sf":[1]},{"i":303,"p":[1,2,3,4,7,9]},{"i":304,"p":[1,2,3],"f":[1,2,3],"sf":[1]},{"i":308,"p":[1],"sp":[1,2],"l":[2,7],"sf":[1]},{"i":310,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":311,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":312,"p":[1,7,8],"f":[2]},{"i":314,"p":[1,2,3,4,7,9,10],"fp":[2,7,9,10],"sp":[1,2]},{"i":315,"p":[4,10],"sp":[1,2],"l":[2,7],"f":[3],"sf":[1]},{"i":316,"p":[1,2,3,4,5,6,7,8,9,10],"sf":[1]},{"i":317,"p":[1,2,3,4,5,6,7],"sp":[1,2]},{"i":318,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3]},{"i":319,"p":[1],"fp":[2,7],"sp":[1,2],"l":[2,7],"sf":[1]},{"i":321,"p":[1,3,4,5,6,9],"fp":[2,7,8,10],"sp":[1,2],"l":[2,7,8,10],"f":[2]},{"i":323,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":325,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":326,"p":[1,2,3,4,7],"sp":[1,2]},{"i":328,"p":[1,2,3,4,7,8,9,10],"f":[2]},{"i":329,"p":[1,7,8]},{"i":331,"p":[1,3,4,7,8,9,10],"sp":[1,2],"f":[3],"sf":[2]},{"i":333,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":334,"sp":[1,2],"f":[1,3],"sf":[1,2]},{"i":335,"p":[1],"fp":[2,3,4,7,8,9],"sp":[1,2],"l":[2,3,4,7,8,9],"f":[1,3],"sf":[1]},{"i":336,"fp":[2],"sp":[1,2],"l":[2,7,9],"f":[3]},{"i":337,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3]},{"i":343,"p":[1],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,3],"sf":[1]},{"i":345,"p":[1,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":347,"p":[1,7,8,9,10],"f":[3],"sf":[1]},{"i":349,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3]},{"i":350,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1],"f":[1,2,3]},{"i":351,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1],"f":[1,2,3]},{"i":354,"p":[2,3,4],"fp":[7],"sp":[1,2],"l":[7,8,10]},{"i":358,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3]},{"i":359,"p":[3,4,9],"fp":[9],"sp":[1,2],"l":[2,7],"f":[3],"sf":[1]},{"i":360,"p":[1],"fp":[3,5,7,8,9],"l":[3,5,7,8,9],"f":[1,2]},{"i":361,"p":[1,2,4,8,9],"f":[1,2]},{"i":365,"p":[1],"sp":[1],"f":[3]},{"i":368,"p":[1,2,3,4,7,9],"sp":[1],"f":[1,2,3],"sf":[1]},{"i":371,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"sf":[1]},{"i":373,"p":[1,3],"sp":[1],"l":[10],"f":[1,2,3]},{"i":374,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":375,"p":[2,3,4,5,6,7,8,9,10],"f":[3]},{"i":377,"p":[1,2,3,4,5,6,8,9],"fp":[7,10],"sp":[1,2],"l":[7,10],"f":[1,2,3],"sf":[1,2]},{"i":378,"p":[1],"fp":[2,7],"sp":[1,2],"l":[2,7]},{"i":380,"p":[1,2,3,4,5,6,7,8,9],"sp":[1,2]},{"i":381,"p":[1,3,4,5,6,7,9,10],"sp":[1],"l":[2,8],"f":[1,3],"sf":[1,2]},{"i":382,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[3]},{"i":384,"p":[10],"fp":[10],"sp":[1],"f":[1,2]},{"i":385,"p":[1,3,5,9,10],"f":[1,2]},{"i":387,"p":[2,3,4,7],"f":[3]},{"i":388,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":394,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3]},{"i":397,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3]},{"i":402,"p":[1,7],"fp":[7],"f":[3]},{"i":404,"p":[1,7],"sp":[1]},{"i":408,"p":[1,2,7],"fp":[2,7]},{"i":409,"p":[1,2,7,8,9,10],"f":[2]},{"i":410,"p":[1,2,7],"sp":[1,2],"f":[3]},{"i":412,"p":[1,2,3,4,5,6,7,8,9],"fp":[8,9],"f":[1,2,3]},{"i":413,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":415,"sp":[2]},{"i":416,"p":[1,2,3,4,5,6,7,9,10],"f":[1,2,3]},{"i":418,"p":[1,3,4,7,9,10],"fp":[2],"sp":[1,2],"l":[2],"f":[1,2,3],"sf":[1]},{"i":422,"p":[1,7,8]},{"i":423,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2],"sf":[1]},{"i":424,"p":[1,2,3,4,7,9,10]},{"i":427,"p":[1,2,3,4,5,6,7,8],"f":[1],"sf":[1]},{"i":428,"p":[1],"fp":[2,3,4],"sp":[1,2],"l":[2,3,4,7]},{"i":429,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":430,"p":[7],"sp":[1,2],"f":[3]},{"i":431,"sp":[1],"l":[10],"f":[1,3],"sf":[2]},{"i":434,"p":[1,2,3,4,7],"sp":[1,2],"f":[1,3]},{"i":435,"p":[1,3,4,7,9],"sp":[1],"f":[1,2,3],"sf":[1,2]},{"i":436,"p":[1,3,4,5,6,9],"fp":[2,7,8,10],"sp":[1,2],"l":[2,7,8,10],"f":[1,2,3]},{"i":438,"p":[1,2,3,4,7,9,10],"fp":[2,7,9,10],"f":[1,2]},{"i":439,"p":[1,7,9],"f":[3],"sf":[1]},{"i":440,"p":[1,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":444,"p":[1,2,3,4,5,6,7,8,9,10],"f":[3]},{"i":447,"p":[2,3,4,7,9,10],"sf":[1]},{"i":448,"p":[1,2,7,9],"fp":[2,7,9],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":450,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":452,"p":[1,4],"fp":[2,7],"sp":[1,2],"l":[2,7],"f":[1,2]},{"i":454,"p":[1,7,8,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":455,"p":[1,2,3,4,10],"fp":[2,10],"sp":[1,2],"l":[7],"f":[1,2,3],"sf":[1]},{"i":458,"p":[1,2,3,4,7,9,10],"fp":[2,3,4,7,9,10],"sp":[1,2],"f":[3]},{"i":459,"p":[1],"sp":[1,2],"f":[3]},{"i":461,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,9,10],"sp":[1],"f":[1,2,3],"sf":[1]},{"i":462,"p":[1,2,3,4,5,6,9],"fp":[2,3,4,5,6,7,8,9],"sp":[1,2],"l":[7,8],"f":[2],"sf":[2]},{"i":466,"sp":[1,2],"l":[7]},{"i":467,"p":[1],"fp":[7],"l":[7],"f":[2,3]},{"i":468,"p":[1,3],"fp":[7,8,9,10],"sp":[1],"l":[7,8,9,10],"f":[1,2,3]},{"i":469,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":471,"p":[1,2,7,8],"fp":[2,7,8],"sp":[1,2],"f":[3],"sf":[1,2]},{"i":473,"p":[1,2,3,4,7,10],"fp":[2,7,10]},{"i":475,"p":[1,2,3,4,7,9],"sp":[1],"l":[10],"f":[1,3],"sf":[1]},{"i":479,"p":[2,3,4,7,9],"sp":[2],"f":[1,2]},{"i":482,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2],"sf":[1]},{"i":484,"sp":[1],"l":[7,10]},{"i":486,"p":[7],"fp":[7],"sp":[1,2],"f":[3]},{"i":488,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2]},{"i":490,"p":[1,2,3,4,7,10],"fp":[2,7,10],"sp":[1]},{"i":491,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":493,"p":[1,2,3,4,5,6,7,8,9],"fp":[2,7,8,10],"sp":[1,2],"l":[10],"f":[1,2,3]},{"i":495,"p":[2,7,9,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":496,"p":[1,2,4,7,9,10],"sp":[1,2],"f":[3]},{"i":497,"p":[1,3,9],"sp":[2],"f":[1]},{"i":498,"p":[1,2,3,4,6,7,9,10],"sp":[1,2],"f":[1],"sf":[1]},{"i":501,"p":[1,2,3,4,7,9],"f":[1,2]},{"i":502,"fp":[7,10],"sp":[1,2],"l":[7,10]},{"i":505,"p":[1,7,8],"sf":[1]},{"i":506,"p":[1,3,5,7,8,9,10],"f":[1,2]},{"i":507,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":508,"p":[1,7,8,9],"fp":[7,8,9],"sp":[1],"f":[1,2,3]},{"i":509,"p":[1,2,7],"fp":[2,7]},{"i":511,"p":[1,2,3,4,5,7,9],"sp":[1,2],"l":[10],"f":[1,2],"sf":[1]},{"i":512,"p":[1,2,3,4,7,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":516,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":517,"p":[1,2,7,8,9,10],"f":[2,3]},{"i":519,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":520,"p":[1]},{"i":521,"p":[1]},{"i":524,"p":[1,2,3,4,7,9,10],"sp":[2],"f":[2,3],"sf":[1]},{"i":527,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":528,"p":[1,2,3,4,9,10],"sp":[1,2],"l":[7],"f":[1,3]},{"i":530,"p":[2,3,4,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[1,2],"sf":[1]},{"i":531,"p":[1,2,3,4,7],"f":[1,2,3],"sf":[1]},{"i":534,"p":[2,7,8,9,10],"f":[3],"sf":[1]},{"i":535,"p":[1,2,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2]},{"i":536,"p":[1,7,8,9],"f":[1,2,3]},{"i":539,"p":[1,2,3,4,7],"sp":[1,2],"f":[3]},{"i":541,"p":[1],"fp":[2,3,4,7,9,10],"sp":[1,2],"l":[2,3,4,7,9,10],"f":[1,2,3]},{"i":543,"p":[1,3,4,5,6],"sp":[1,2],"l":[2,7,8],"f":[2,3],"sf":[1]},{"i":544,"p":[7],"f":[1,2,3],"sf":[1,2]},{"i":545,"p":[1,3,4,5,6,9],"fp":[2,7,8],"sp":[1,2],"l":[2,7,8,10],"f":[3],"sf":[1,2]},{"i":546,"p":[1,3,7],"sp":[1],"f":[1,2,3],"sf":[1,2]},{"i":547,"p":[1,2,3,4,7],"sp":[1,2]},{"i":549,"p":[1],"sp":[1,2],"f":[1,3]},{"i":550,"p":[1,2],"fp":[9,10],"sp":[2],"l":[9,10],"f":[3]},{"i":553,"p":[1,2,3,4,7,9],"sp":[1],"f":[1,2],"sf":[1]},{"i":554,"p":[7,9,10],"sp":[1],"f":[1,2,3],"sf":[1,2]},{"i":556,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"sf":[1]},{"i":559,"p":[1,2,3,4],"fp":[7,9,10],"sp":[1,2],"l":[7,9,10],"sf":[1]},{"i":561,"p":[1,2,3,4,9,10]},{"i":565,"p":[1,10],"sp":[1],"f":[1,2,3]},{"i":568,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":569,"p":[1,7,8,9,10],"fp":[7,8,9,10],"sf":[1]},{"i":570,"p":[1,3,9,10],"f":[1,2,3]},{"i":571,"p":[1,2,4,7,10],"fp":[2,7,10],"sp":[1,2],"f":[3]},{"i":572,"sp":[1,2],"f":[1,3],"sf":[2]},{"i":573,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2]},{"i":574,"p":[1,7,8,9,10],"sp":[1,2],"f":[1]},{"i":577,"p":[1,2,3,4,6,9],"fp":[2,3,4,5,6,7,8,9],"l":[5,7,8],"f":[1,2,3]},{"i":578,"p":[1],"sp":[1,2],"l":[2,3,4,7,8]},{"i":579,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3]},{"i":580,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3],"sf":[1]},{"i":581,"p":[1,3,4,5,6],"fp":[2],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":584,"p":[1,7,10],"fp":[7,10],"sp":[2],"f":[3],"sf":[2]},{"i":587,"p":[1,2,3,4,7,10],"sf":[1]},{"i":590,"p":[1]},{"i":591,"p":[1,2,4,7],"sp":[2]},{"i":593,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":596,"p":[1,2,3,4,5,6,9,10],"fp":[7,8],"sp":[1,2],"l":[7,8],"sf":[1]},{"i":597,"sp":[2]},{"i":598,"p":[1],"sp":[1,2],"l":[2,7,9],"sf":[1]},{"i":599,"sp":[1],"sf":[1]},{"i":601,"p":[1,2],"sp":[2]},{"i":602,"p":[1,2,3,4,7,8,9,10],"fp":[2,7,8,10],"sp":[1,2],"f":[1,3],"sf":[1]},{"i":606,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2]},{"i":607,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[2,3],"sf":[1]},{"i":609,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":610,"p":[1,2,4,8],"fp":[2,8],"sp":[1,2],"l":[7,9,10],"f":[3],"sf":[1]},{"i":612,"fp":[7],"sp":[1,2],"l":[7]},{"i":613,"p":[10],"fp":[10],"sp":[1,2],"l":[2,7]},{"i":614,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3],"sf":[2]},{"i":615,"sp":[1,2]},{"i":617,"p":[1,2,7,8],"sf":[1]},{"i":618,"p":[1,2,3,4,9,10],"f":[1,2],"sf":[1]},{"i":620,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[2,3],"sf":[1]},{"i":621,"p":[1,3,4,5,6],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":624,"p":[1,9],"f":[1,2,3]},{"i":625,"p":[1,7,8,9],"f":[1]},{"i":626,"p":[1,3,4,7,9,10],"sf":[1]},{"i":628,"p":[1,2,4,7,10],"sp":[1,2],"f":[1,2],"sf":[1,2]},{"i":630,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":631,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2],"sf":[2]},{"i":638,"p":[1,2,4,7],"sp":[2]},{"i":639,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":644,"p":[1,2,3,4,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[3]},{"i":645,"p":[1,2,3,4,5,6,9,10],"l":[7,8],"f":[1,2,3],"sf":[1,2]},{"i":646,"p":[9],"f":[1]},{"i":647,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":648,"p":[1,3,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":649,"p":[1,3,4],"f":[1]},{"i":650,"p":[1,2,3,4,5,6,7,9,10],"sp":[1,2],"sf":[1]},{"i":652,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":653,"p":[1,7,8,9],"f":[3],"sf":[1]},{"i":654,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2]},{"i":655,"p":[1,3,4,10],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9],"f":[1,2,3],"sf":[1,2]},{"i":656,"p":[1,3,4,9],"fp":[7,9,10],"sp":[1,2],"l":[2,7,10]},{"i":657,"p":[1,3],"fp":[2],"sp":[1,2],"l":[2],"f":[1],"sf":[1,2]},{"i":658,"p":[1,2,3,4,7,8,9,10],"fp":[2,7,8,9,10],"sp":[2],"sf":[1]},{"i":659,"p":[1],"sp":[1],"l":[7,8,9],"f":[2],"sf":[2]},{"i":662,"p":[1,2,7],"f":[3],"sf":[1]},{"i":663,"p":[1,2,3,4,7,9],"sp":[1],"f":[1,2,3],"sf":[1]},{"i":664,"p":[1,2,3,4],"sp":[1,2],"l":[7,10],"f":[1,2,3]},{"i":665,"p":[2,7,9,10],"fp":[2,7,9,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":666,"p":[1,2,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[7,8,9,10],"f":[3]},{"i":667,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":668,"p":[1,2,3,4,5,6,7,8,9,10],"f":[2],"sf":[1,2]},{"i":670,"p":[1,2,4,6,7,8,9,10],"f":[3]},{"i":671,"p":[1,3,4,5,6,7,8,9],"sp":[1,2],"l":[2,10],"f":[1,3]},{"i":672,"p":[1,2]},{"i":673,"p":[1,3,4,9,10],"sp":[1,2],"l":[2,7],"f":[3],"sf":[1,2]},{"i":674,"p":[7],"sp":[2]},{"i":675,"p":[2,3,4,7,9],"sp":[2],"f":[3]},{"i":676,"p":[1,2,3,4,5,6,7,8,9],"fp":[7,8,9],"sp":[1,2],"l":[10],"f":[1,2,3],"sf":[2]},{"i":677,"p":[1,2,3,4,5,6],"fp":[2],"sp":[1,2],"l":[7,8,10],"f":[3]},{"i":678,"p":[2],"fp":[2],"sp":[1,2],"l":[7,10],"f":[3],"sf":[1]},{"i":681,"p":[1,9],"sf":[1]},{"i":682,"p":[1,2,3,4],"sp":[2],"l":[7],"f":[1,2,3],"sf":[1,2]},{"i":683,"p":[1,3,4,9],"f":[2,3],"sf":[1]},{"i":684,"p":[1],"fp":[7,8,10],"sp":[2],"l":[7,8,10],"f":[3]},{"i":685,"p":[1,2,3,4,7,9,10],"f":[1,2,3],"sf":[1,2]},{"i":686,"p":[1,2,3,4,7,9],"f":[1,2,3]},{"i":687,"p":[1,2,3,4,5,6,7],"sp":[2],"f":[2,3]},{"i":688,"fp":[7]},{"i":690,"p":[1,2,3,4],"sf":[1]},{"i":691,"p":[2,3,4,5,6,7,8,9,10]},{"i":694,"p":[2,3,4,5,6,8,9,10],"sp":[2],"l":[7],"f":[1]},{"i":697,"p":[1,4,6],"sp":[2],"l":[2,7,8],"f":[1,2],"sf":[1]},{"i":699,"p":[1,2,3,4,9],"sp":[2],"l":[7,10],"f":[1,3]},{"i":702,"p":[1,2,7,8],"fp":[2,7,8],"sp":[1,2],"f":[3]},{"i":703,"p":[1,2,3,4,7,8,9,10],"sp":[1],"f":[2,3],"sf":[2]},{"i":706,"sp":[1,2],"l":[2],"sf":[1]},{"i":707,"p":[1,2,3,4,7,9,10],"sp":[1],"f":[1,2,3],"sf":[1,2]},{"i":708,"p":[1,3,4,5,6,9,10],"sp":[1,2],"l":[2,7,8],"f":[1,2,3],"sf":[1,2]},{"i":709,"p":[1,2,3,4,5,6],"fp":[7,8,9,10],"sp":[1],"l":[7,8,9,10],"f":[1,2,3]},{"i":711,"p":[3,10],"sf":[1]},{"i":712,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":713,"p":[2,4,7],"fp":[2,7]},{"i":714,"p":[1],"fp":[7,8,9],"l":[7,8,9],"f":[3]},{"i":715,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[2,3]},{"i":716,"p":[1,2,3,4,7,9,10],"sp":[1],"f":[1,2,3]},{"i":717,"p":[1,2,3,4,7,9,10],"sp":[1],"f":[1,2,3]},{"i":718,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":719,"p":[1,2,3,4,7,9,10],"sp":[1],"f":[1,2,3]},{"i":720,"p":[1,3,4],"fp":[2,10],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":721,"p":[1,2,3,4,5,6,7],"fp":[2,7,8],"sp":[1,2],"l":[8],"f":[1,3]},{"i":722,"p":[1,7,9],"sp":[1]},{"i":723,"p":[1,2,3,4,7,8],"f":[2]},{"i":724,"p":[1],"sp":[1,2],"l":[7]},{"i":725,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[2,3],"sf":[2]},{"i":726,"p":[1,3,5,7,8,9,10],"fp":[9,10],"f":[1,2,3]},{"i":727,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1]},{"i":728,"p":[1,3,4,5,6],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3],"sf":[1]},{"i":729,"p":[2,3,4,5,6,7,8,9,10],"f":[1,3],"sf":[2]},{"i":730,"p":[1,8],"f":[3],"sf":[2]},{"i":732,"p":[1,3,4],"l":[2,7,9,10]},{"i":733,"p":[1,2,3,4,9],"fp":[2,7,9],"sp":[1,2],"l":[7],"f":[1,3],"sf":[1]},{"i":734,"p":[1,7,8,9],"sp":[1],"f":[1,2,3]},{"i":735,"p":[1,7],"f":[1]},{"i":736,"p":[1],"fp":[7,8,10],"sp":[1,2],"l":[7,8,10],"sf":[1]},{"i":737,"p":[1,2,7]},{"i":738,"p":[1]},{"i":739,"p":[1,2,3,4,5,6,7,8,9,10],"sf":[1]},{"i":740,"p":[1,3,4],"fp":[2,7,8,10],"sp":[1,2],"l":[2,7,8,10],"f":[1,2,3]},{"i":741,"p":[2,7,8,9],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":742,"p":[1,3,5],"f":[1,2,3]},{"i":743,"p":[1,2,3,4,5,6,7,8,9,10],"f":[2,3],"sf":[1]},{"i":744,"p":[1,2,3,4],"fp":[2],"sp":[1,2],"l":[7,10],"f":[3]},{"i":745,"p":[1,3,4,7,9],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":746,"p":[2,3,4,5,7,8],"sp":[2],"f":[1,3],"sf":[1]},{"i":747,"p":[1,2,7,8,9,10],"fp":[2,7,8,9,10],"f":[2,3],"sf":[1,2]},{"i":748,"p":[1,2,7,8,9],"fp":[2,7,8,9],"sp":[1,2],"f":[1,2],"sf":[1]},{"i":749,"p":[1],"fp":[7,10],"sp":[1,2],"l":[7,10]},{"i":750,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[2],"f":[1,2,3],"sf":[1,2]},{"i":751,"fp":[2,7],"sp":[1,2],"l":[2,7]},{"i":753,"p":[1,2,3,4,7,9,10],"fp":[2,3,4,7,9,10],"sp":[1,2],"f":[3]},{"i":754,"p":[1],"sp":[1,2],"l":[2,8,10]},{"i":755,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2]},{"i":756,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[3]},{"i":757,"p":[1,2,3,4,5,7,10],"sp":[1,2]},{"i":758,"p":[1,7,8,9],"f":[2]},{"i":759,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,3]},{"i":760,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[2]},{"i":761,"p":[1,3,5,7,8,9],"f":[1]},{"i":762,"fp":[7,10],"sp":[1,2],"l":[7,10],"f":[3],"sf":[2]},{"i":763,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":764,"p":[1,2,7,8,9,10],"sp":[1,2]},{"i":765,"p":[2,3,4,7,8,9,10],"sp":[1,2],"f":[2]},{"i":766,"p":[1,2],"fp":[2],"sf":[2]},{"i":767,"p":[1,3,4,10],"sp":[1,2],"l":[2,7,9],"f":[1,2,3],"sf":[1]},{"i":768,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":769,"p":[1,8],"f":[1,3]},{"i":770,"p":[1,2,3,4,7,8,9,10],"sp":[1,2],"f":[3]},{"i":771,"p":[1,7,10],"sp":[1,2],"sf":[1]},{"i":772,"sp":[1],"l":[7,8,10]},{"i":773,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[2,3],"sf":[1]},{"i":774,"fp":[2,7],"sp":[1,2],"l":[2,7]},{"i":775,"p":[1,2,3,4,7,8],"sp":[1,2],"f":[3]},{"i":776,"p":[2],"fp":[2]},{"i":777,"p":[1],"fp":[2,3,4,7],"sp":[1,2],"l":[2,3,4,7]},{"i":778,"p":[2,3,4,7],"f":[3]},{"i":779,"p":[1,2,7],"sp":[1,2],"f":[3],"sf":[1]},{"i":780,"p":[1,2,3,4,7,8,9,10],"sp":[1],"f":[3]},{"i":781,"p":[1,3,4,5,6,8,9],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[2,3],"sf":[1,2]},{"i":782,"p":[1,3,7,9,10]},{"i":783,"p":[1,2,3,4,5,6],"f":[1,2,3],"sf":[1,2]},{"i":784,"p":[1],"sp":[1,2],"l":[2,7],"f":[3]},{"i":785,"p":[1,7,9],"sp":[1],"f":[2]},{"i":786,"p":[8]},{"i":787,"p":[1,7],"sp":[1,2]},{"i":788,"p":[1,2,3,4,5,6,7,8,9,10],"f":[2],"sf":[1]},{"i":789,"p":[1,2,3,4,5,6,7,8,9,10],"f":[2],"sf":[1]},{"i":790,"p":[1,3,4],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3],"sf":[1]},{"i":791,"p":[1,2],"fp":[2],"sp":[2]},{"i":792,"p":[1],"fp":[3,7,10],"sp":[1],"l":[3,7,10],"f":[1,2]},{"i":793,"p":[1,2,3,4,7,9,10],"fp":[2,7,9,10],"sp":[1,2],"f":[1]},{"i":794,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":795,"p":[1,2,4,7],"sp":[1,2],"f":[3],"sf":[1]},{"i":796,"p":[1,2,7,8],"fp":[2,7,8],"sp":[1,2],"f":[1,2,3]},{"i":797,"p":[1,7],"fp":[7],"sp":[1,2],"f":[2,3]},{"i":798,"p":[1,2,3,4,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"l":[7],"f":[3],"sf":[2]},{"i":799,"p":[1,2,7,8,9,10],"f":[2,3]},{"i":800,"p":[1,2,3,4,7,8,9,10],"fp":[10],"sp":[1],"f":[2,3],"sf":[2]},{"i":801,"sp":[1,2],"l":[2,7],"f":[3]},{"i":802,"p":[1,3,4,7],"fp":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"l":[2,5,6,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":803,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":804,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1]},{"i":805,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"sf":[1,2]},{"i":806,"p":[1,2,3,4],"sp":[1,2],"l":[7,10],"f":[3]},{"i":807,"p":[3,4],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[3],"sf":[2]},{"i":808,"p":[1,2,3,4,7,9],"sp":[1,2],"f":[3]},{"i":809,"p":[1,2,3,4,7],"sp":[1,2]},{"i":810,"p":[1],"fp":[7],"sp":[1,2],"l":[7],"f":[3]},{"i":811,"p":[1,2,3,4,5,6,7,8,9,10],"sf":[1,2]},{"i":812,"p":[1],"fp":[7,10],"sp":[1],"l":[7,9,10],"f":[1,2,3]},{"i":813,"p":[1,7,8,9,10],"fp":[7,8,9,10],"sp":[1],"f":[2,3],"sf":[2]},{"i":814,"p":[1,2,3,4,7,10],"sp":[1,2],"f":[2]},{"i":815,"p":[1,2,3,4,7,9,10],"sp":[1,2]},{"i":816,"p":[2,10],"sp":[2]},{"i":817,"p":[1,2,3,4,5,6,7,8,9,10],"f":[2]},{"i":818,"p":[1,2,4,7,10]},{"i":819,"p":[1],"fp":[2,7],"sp":[1,2],"l":[2,7]},{"i":820,"p":[1,3,4,5,6,7,8,10],"fp":[10],"f":[1,2]},{"i":821,"p":[1,7],"fp":[7],"sp":[1,2]},{"i":822,"p":[1,2,3,4,7,9,10],"fp":[7],"sp":[2],"f":[1],"sf":[2]},{"i":823,"p":[1,7,8,9],"fp":[7,8,9],"sp":[1,2]},{"i":824,"p":[1,2,3,4,5,6,7,8,10],"sp":[1,2],"f":[2,3],"sf":[2]},{"i":825,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[2,3],"sf":[2]},{"i":826,"p":[7,8],"sp":[1,2]},{"i":827,"p":[1,7],"fp":[7],"f":[2]},{"i":828,"p":[1,3,5,6],"sp":[1,2],"l":[8,9,10],"f":[1,2,3],"sf":[1]},{"i":829,"p":[1,2,3,4,5,6,7,8,9],"f":[2]},{"i":830,"fp":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"l":[2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":831,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2]},{"i":832,"p":[1,7],"f":[1]},{"i":833,"p":[1,2,3,4,5,6,7,8,9,10],"f":[3],"sf":[2]},{"i":834,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3],"sf":[1,2]},{"i":835,"p":[1,2,3,4,7,9],"sp":[1,2]},{"i":836,"p":[1],"fp":[7,8],"l":[7,8,10],"sf":[1]},{"i":837,"p":[1,2,5,6],"fp":[5,6],"l":[7,8]},{"i":838,"sp":[1,2],"l":[2,7,8,10]},{"i":839,"p":[1],"sp":[1,2],"l":[2,7,10],"sf":[1,2]},{"i":840,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[3]},{"i":841,"fp":[7,8,10],"sp":[1,2],"l":[7,8,10]},{"i":842,"p":[1],"sp":[1,2],"f":[3],"sf":[1]},{"i":843,"p":[1],"fp":[7,8],"l":[7,8],"f":[1,2,3],"sf":[1]},{"i":844,"p":[1,2,3,4,7],"sf":[1]},{"i":845,"fp":[7],"sp":[1],"l":[7],"f":[1]},{"i":846,"p":[1,2,3,4,7,10],"fp":[2,3,4,7,10],"sp":[1,2],"sf":[1]},{"i":847,"p":[2,5,6,7,8,9,10]},{"i":848,"p":[1,2,3,4,7,9,10],"sp":[1,2]},{"i":849,"p":[1,2,7],"sp":[2],"f":[1]},{"i":850,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1],"f":[1,2,3],"sf":[2]},{"i":851,"p":[1],"sp":[1,2],"l":[2,7,8,10]},{"i":852,"p":[1,7],"sp":[1],"f":[3]},{"i":853,"fp":[7,8],"sp":[1],"l":[7,8],"sf":[1]},{"i":854,"p":[2,7,8],"sp":[1,2]},{"i":855,"p":[1,3,4],"fp":[2,7],"sp":[1,2],"l":[2,7],"f":[3],"sf":[1]},{"i":856,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10]},{"i":857,"p":[1,3,4],"fp":[2,10],"sp":[1,2],"l":[2,10],"f":[1,2,3]},{"i":858,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[1,2,3]},{"i":859,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":860,"p":[1,2,10],"f":[3],"sf":[1]},{"i":861,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1],"f":[1,2,3],"sf":[2]},{"i":862,"p":[1,2,3,4,5,6,8],"fp":[2],"sp":[1,2],"l":[7,10]},{"i":863,"p":[1,7,8,9],"f":[2,3]},{"i":864,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":865,"p":[1,2,7,8],"sp":[1,2],"f":[3]},{"i":866,"p":[1,2,7],"sp":[2]},{"i":867,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":868,"p":[1,2,3,4,5,6,7,8,9],"f":[3]},{"i":869,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1],"f":[3],"sf":[1]},{"i":870,"p":[1],"f":[3],"sf":[2]},{"i":871,"p":[1,7],"fp":[7],"sp":[1,2],"f":[2,3]},{"i":872,"sp":[2],"l":[2,7]},{"i":873,"l":[7]},{"i":874,"p":[1,2,3,4,5,6,7,8],"sp":[1,2]},{"i":875,"p":[2,4,6,7,8,9,10],"fp":[2,4,6,7,8,9,10],"f":[1]},{"i":876,"p":[1,6],"sp":[1,2],"l":[7,8]},{"i":877,"p":[1,3,5],"f":[1,2,3]},{"i":878,"p":[1],"sp":[1,2],"l":[2,7,8],"f":[3]},{"i":879,"p":[3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3],"sf":[2]},{"i":880,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":881,"p":[1,2,7,8,10],"sp":[2]},{"i":882,"p":[1,3,5,10],"sp":[1],"l":[9],"f":[2,3],"sf":[1]},{"i":883,"p":[1,2,7,8,10],"sp":[1],"f":[3]},{"i":884,"p":[1,3,4,5,6],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":885,"p":[1,3,4,5,6,8,9],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":886,"p":[1,2,4,7],"sp":[2]},{"i":887,"p":[1],"sf":[1]},{"i":888,"p":[1,2,4,7,9,10],"f":[3]},{"i":889,"p":[7,9],"fp":[7,9]},{"i":890,"p":[1,7]},{"i":891,"p":[1,2,3,4,7],"sp":[1,2]},{"i":892,"sp":[1],"f":[1,3],"sf":[1]},{"i":893,"p":[1,7,9],"f":[3]},{"i":894,"p":[2,3,4,5,6,7,8,9,10]},{"i":895,"p":[1,2,3,4,7,9,10],"fp":[3,4,7,9,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":896,"p":[1],"fp":[8,9],"sp":[1],"l":[8,9],"f":[3],"sf":[2]},{"i":897,"p":[1,8,10],"sp":[1],"f":[1,2,3],"sf":[1,2]},{"i":898,"fp":[2,10],"sp":[1,2],"l":[2,10]},{"i":899,"p":[1],"sp":[1]},{"i":900,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2]},{"i":901,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":902,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3],"sf":[1,2]},{"i":903,"p":[9],"f":[3],"sf":[1]},{"i":904,"p":[1],"fp":[2,7,8],"sp":[1,2],"l":[2,7,8,10],"f":[3]},{"i":905,"p":[1,2],"fp":[2],"sp":[1,2],"l":[3,4,5,6,7,8,9,10],"f":[1,3],"sf":[1]},{"i":906,"p":[3,5]},{"i":907,"p":[1],"fp":[7],"sp":[1,2],"l":[7],"f":[2,3]},{"i":908,"p":[1,2,3,4,7,8,9,10],"sp":[1,2],"f":[2,3],"sf":[1,2]},{"i":909,"p":[1,7,9,10],"sp":[1,2],"f":[1,3]},{"i":910,"p":[1,2,3,4,5,6,7,8,10],"fp":[2,5,6,7,8,10],"sp":[1,2],"f":[3]},{"i":911,"sp":[1],"l":[7],"sf":[2]},{"i":912,"p":[2],"sp":[1,2],"l":[7]},{"i":913,"p":[1],"fp":[2],"sp":[1,2],"l":[2],"f":[3],"sf":[2]},{"i":914,"p":[1],"fp":[2,3,4,5,6,7,8],"l":[2,3,4,5,6,7,8]},{"i":915,"p":[1,3,4],"fp":[2,7,10],"sp":[2],"l":[2,7,10],"f":[3]},{"i":916,"fp":[2,3,4,5,6,7,8,10],"sp":[1,2],"l":[2,3,4,5,6,7,8,10],"f":[1,3]},{"i":917,"p":[1,3,4,9],"fp":[2,3,4,7,9],"sp":[1,2],"l":[2,7]},{"i":918,"p":[1,2,5,6],"fp":[2],"sp":[1,2],"l":[7,8,9,10]},{"i":919,"p":[1],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10]},{"i":920,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":921,"p":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3]},{"i":922,"p":[1,2,3,4,7,9,10],"f":[1,2,3],"sf":[1,2]},{"i":923,"l":[7]},{"i":924,"p":[7],"sp":[2]},{"i":925,"l":[7],"f":[2]},{"i":926,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[2,3]},{"i":927,"sp":[2],"l":[7,8]},{"i":928,"p":[1]},{"i":929,"p":[1,2,3,4,7,10],"sp":[2]},{"i":930,"p":[1,2,3,4,7],"sp":[1,2],"f":[1,3],"sf":[1]},{"i":931,"p":[1,8],"sp":[2]},{"i":932,"p":[1,3,4],"fp":[3,4],"sp":[1,2],"l":[2,7,9],"f":[3],"sf":[1]},{"i":933,"p":[7,8,10]},{"i":934,"p":[1,7,8]},{"i":935,"p":[1,3,4,5,6,7,8,10],"fp":[7,8]},{"i":936,"p":[1,2,3,4,5],"f":[1]},{"i":937,"p":[1,2,3,4,7,8,9,10],"fp":[2,7,8],"sp":[1,2],"f":[3],"sf":[1]},{"i":938,"p":[1,2,3,4,7,8,9,10],"fp":[2,7,8],"sp":[1,2],"f":[1,3],"sf":[1]},{"i":939,"p":[1,7,8,9,10],"f":[2,3],"sf":[1]},{"i":940,"l":[7],"f":[1]},{"i":941,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":942,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":943,"p":[1,5,6,7,8,9,10],"f":[2]},{"i":944,"p":[1,2,3,4,7,8,9,10],"sp":[1,2],"f":[3]},{"i":945,"sp":[2],"f":[3]},{"i":946,"p":[1,7],"fp":[7],"sp":[1,2],"f":[2,3]},{"i":947,"p":[1,2,3,4],"sp":[1,2],"l":[7]},{"i":948,"p":[1,2,3,4,7,10],"sp":[1,2]},{"i":949,"fp":[8,9,10],"l":[7,8,9,10]},{"i":950,"sp":[2]},{"i":951,"p":[2,7],"fp":[2,7],"sp":[1,2]},{"i":952,"p":[1,3,4,7,10],"f":[2,3],"sf":[1]},{"i":953,"sp":[2]},{"i":954,"p":[1,2,7],"sp":[1,2]},{"i":955,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":956,"p":[1,2,7,8,10],"sp":[1,2],"f":[1]},{"i":957,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":958,"p":[1,7,8,10]},{"i":959,"p":[1,2,3,4,5,10],"sp":[1],"f":[2],"sf":[1]},{"i":960,"sp":[1,2],"l":[2,7]},{"i":961,"sp":[1,2],"l":[2,3,4,5,6,7,8,9,10],"f":[3],"sf":[1,2]},{"i":962,"p":[1,2,3,4,5,6,7],"sp":[1,2]},{"i":963,"p":[1,2,3,4,5,6,7,8,9,10],"f":[3],"sf":[1,2]},{"i":964,"p":[2,4,7,8,9,10],"sp":[1,2],"f":[3],"sf":[2]},{"i":965,"p":[1],"fp":[10],"l":[10]},{"i":966,"p":[7]},{"i":967,"p":[1,3,4,6,9],"fp":[2,7,8,10],"sp":[1,2],"l":[2,7,8,10],"f":[1,2,3]},{"i":968,"p":[1,3,4,7,10],"sp":[1,2],"f":[2,3]},{"i":969,"fp":[7],"sp":[1,2],"l":[2,7,8],"f":[3],"sf":[2]},{"i":970,"p":[1,4],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[2]},{"i":971,"p":[1,2,3,4,7]},{"i":972,"p":[1,2,3,4,7,10],"sp":[1,2],"f":[2]},{"i":973,"p":[2,4,7,9,10],"f":[3],"sf":[1,2]},{"i":974,"p":[2,3,4,7,8,10],"sp":[1,2],"f":[1,3],"sf":[1]},{"i":975,"p":[8,10],"sp":[1,2]},{"i":976,"p":[1,2,3,4,7,9,10],"f":[1,3],"sf":[1]},{"i":977,"p":[9],"sp":[1],"l":[8]},{"i":978,"p":[1,2,3,4,7],"sf":[1]},{"i":979,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":980,"p":[1,2,4,5,6,7,8,9,10],"sf":[1]},{"i":981,"p":[1,9],"fp":[7],"l":[7],"f":[1,2]},{"i":982,"p":[1,2]},{"i":983,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":984,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[2]},{"i":985,"p":[1,7,9],"f":[1,2,3]},{"i":986,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3]},{"i":987,"p":[1,7],"f":[1,3],"sf":[1]},{"i":988,"p":[1,5,6,8,9,10]},{"i":989,"p":[1],"sp":[1,2],"l":[2,3,4,7,8,10],"f":[3]},{"i":990,"p":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":991,"p":[1,2,3,4,7],"f":[3],"sf":[2]},{"i":992,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1],"sf":[1]},{"i":993,"p":[1,2,3,4,7,8,10],"sf":[1]},{"i":994,"p":[3,4,5,6,9],"fp":[9],"sp":[1,2],"l":[7,8,10],"f":[1,3]},{"i":995,"p":[1,2,4,7],"sp":[1,2]},{"i":996,"p":[1,3,4,5,6,7,8,10],"sp":[1,2],"l":[2]},{"i":997,"p":[1,3,4],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":998,"p":[1,2,3,4,7],"f":[3]},{"i":999,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":1000,"p":[1,7,8],"f":[3],"sf":[2]},{"i":1001,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":1002,"p":[1,2,7,10],"fp":[7,10],"f":[2]},{"i":1003,"p":[1],"fp":[7],"sp":[1,2],"l":[7]},{"i":1004,"p":[1],"sp":[1,2],"l":[2,4,5,6,7,8,9,10],"f":[2,3],"sf":[1,2]},{"i":1005,"sp":[1,2],"l":[7,10]},{"i":1006,"p":[1],"fp":[7],"l":[7],"f":[1]},{"i":1007,"p":[1,2,3,4,5,6],"f":[1]},{"i":1008,"fp":[3,4,5,6,7,8,9,10],"l":[3,4,5,6,7,8,9,10],"f":[1]},{"i":1009,"p":[1,2,7],"sp":[2],"f":[3]},{"i":1010,"p":[2,3,4,5,7,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":1011,"p":[1,2,7],"sp":[1,2],"f":[3],"sf":[1]},{"i":1012,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":1013,"l":[7]},{"i":1014,"sp":[1,2],"l":[7,8,10]},{"i":1015,"p":[1,3,4],"sp":[1,2],"l":[2,7,9,10],"f":[1,2,3],"sf":[1]},{"i":1016,"p":[1,2,3,4,5,6,7,8,10],"fp":[2],"sp":[1,2]},{"i":1017,"p":[1,2,4,6,7,8,10]},{"i":1018,"p":[3,9],"fp":[3,9]},{"i":1019,"p":[7,10],"f":[1]},{"i":1020,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,3]},{"i":1021,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[2]},{"i":1022,"p":[1,2,10],"fp":[2,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":1023,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sf":[2]},{"i":1024,"p":[1,2,3,4,7,9,10],"sp":[1],"f":[1,2,3]},{"i":1025,"p":[1,3,5],"fp":[7,9],"l":[7,9],"f":[1,2,3]},{"i":1026,"p":[2,4,7],"fp":[2,7],"sp":[1,2]},{"i":1027,"p":[1,2,3,4,5,7,10]},{"i":1028,"p":[1,3,4,5,6],"sp":[1,2],"l":[2,7,8,9,10]},{"i":1029,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"f":[1,2]},{"i":1030,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8],"sp":[2],"f":[3]},{"i":1031,"p":[2,3,4,7,9],"f":[2]},{"i":1032,"p":[1,7,8],"sp":[1],"f":[3]},{"i":1033,"p":[1,2],"sp":[1,2],"f":[3]},{"i":1034,"p":[1,2,3,4,5,6,7,8,10],"fp":[2,3,4,5,6,7,8,10],"f":[1,2,3],"sf":[1,2]},{"i":1035,"p":[1,2,3,4,7,9,10],"f":[2,3]},{"i":1036,"p":[1,3,4,9],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":1037,"p":[8],"f":[3]},{"i":1038,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"f":[3]},{"i":1039,"p":[2,3,4],"fp":[9],"sp":[1,2],"l":[7,8,9,10],"sf":[1]},{"i":1040,"p":[1,3,4,7,8,9,10],"f":[1,2]},{"i":1041,"sp":[1,2],"l":[2,7,9],"f":[3]},{"i":1042,"p":[1,2,3,4,5,10],"fp":[4,5,7,8,9],"l":[7,8,9]},{"i":1043,"p":[1],"fp":[2,10],"l":[2,10]},{"i":1044,"sp":[1]},{"i":1045,"p":[7,8,9,10],"sf":[1]},{"i":1046,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":1047,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"f":[1]},{"i":1048,"p":[1,3,4],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[3]},{"i":1049,"p":[1,2,3,4,7,8,9,10],"sp":[1],"f":[1,2,3]},{"i":1050,"p":[1,2,4,7],"fp":[2,7],"sp":[1],"f":[2,3],"sf":[1]},{"i":1051,"p":[1],"sp":[1],"l":[7,8,10],"f":[2,3],"sf":[2]},{"i":1052,"p":[1,7,9],"sf":[1]},{"i":1053,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":1054,"fp":[7],"l":[7]},{"i":1055,"p":[1,7],"sp":[2],"f":[1,2,3]},{"i":1056,"p":[1,2,3,4,7],"sp":[1,2],"sf":[1]},{"i":1057,"p":[1],"fp":[2,9,10],"sp":[1,2],"l":[2,9,10]},{"i":1058,"p":[2,3,4,7,8,9,10],"sp":[1,2],"sf":[1]},{"i":1059,"p":[7,8,9,10],"fp":[7,8,9,10],"f":[1,2]},{"i":1060,"p":[1,2,3,4,7],"sp":[2],"f":[1,3]},{"i":1061,"p":[1,7,8,9]},{"i":1062,"p":[1,2,3,4,7,9,10],"f":[1,2,3]},{"i":1063,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3]},{"i":1064,"p":[1],"fp":[8],"l":[8]},{"i":1065,"sp":[1],"f":[1],"sf":[1]},{"i":1066,"p":[1,3,4],"sp":[1,2],"l":[2,7,10],"f":[2,3],"sf":[1]},{"i":1067,"p":[1,3,4],"sp":[1,2],"l":[2,7,8,10]},{"i":1068,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":1069,"p":[1,3,4],"fp":[2,7,8,10],"sp":[1,2],"l":[2,7,8,10],"sf":[1]},{"i":1070,"p":[1],"fp":[2],"sp":[1,2],"l":[2],"f":[3],"sf":[2]},{"i":1071,"p":[1,3,4],"fp":[2,5,6,7,8,9,10],"sp":[1,2],"l":[2,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":1072,"p":[2,4,6,7,8,9,10],"f":[1,3]},{"i":1073,"p":[1],"sp":[1],"l":[2,7]},{"i":1074,"p":[1,3,4,5,6,7,8,9,10],"f":[3],"sf":[1]},{"i":1075,"fp":[10],"sp":[1,2],"l":[8,9,10]},{"i":1076,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1],"f":[3],"sf":[2]},{"i":1077,"p":[2,3,4,5,6,10],"fp":[5,6,9],"sp":[1,2],"l":[9],"f":[1,2,3],"sf":[1,2]},{"i":1078,"p":[1],"f":[1],"sf":[1]},{"i":1079,"p":[2],"fp":[2],"sp":[1,2],"f":[3],"sf":[1]},{"i":1080,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[2]},{"i":1081,"p":[1],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10]},{"i":1082,"p":[1,2,9],"fp":[2,7,8,9,10],"sp":[1,2],"l":[7,8,10],"f":[3]},{"i":1083,"p":[2],"fp":[2],"sp":[1,2]},{"i":1084,"p":[1,3,4],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":1085,"p":[1,4],"fp":[2,7,8,9],"sp":[2],"l":[2,7,8,9],"f":[3]},{"i":1086,"p":[1],"sp":[1,2],"l":[2,3,4,7,9,10],"f":[1,2,3],"sf":[1,2]},{"i":1087,"p":[1,3,4,5,6,7,8,9,10],"fp":[2],"sp":[1,2],"l":[2],"f":[1,2,3],"sf":[1,2]},{"i":1088,"p":[1],"fp":[10],"sp":[2],"l":[10]},{"i":1089,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3]},{"i":1090,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[2,3]},{"i":1091,"p":[1,2,3,4,7,9,10],"f":[2,3],"sf":[1]},{"i":1092,"p":[1,2,3,4,5,6,7,9,10],"sp":[1,2],"sf":[1]},{"i":1093,"p":[2,7]},{"i":1094,"p":[1],"sp":[1,2],"sf":[1]},{"i":1095,"p":[1,2,3,4,7,9,10],"f":[1,2,3]},{"i":1096,"p":[1,2,3,4,7,9,10],"f":[1,2,3]},{"i":1097,"p":[1,2,3,4,5,6,7,8,10],"fp":[2,7,8,10],"sp":[1,2],"sf":[1]},{"i":1098,"p":[2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3],"sf":[1,2]},{"i":1099,"p":[1],"sf":[1]},{"i":1100,"p":[1]},{"i":1101,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":1102,"p":[1,2,3,4,5,6],"sp":[1,2],"l":[7,8,10],"f":[3]},{"i":1103,"p":[3,5,10],"f":[1,2],"sf":[1]},{"i":1104,"p":[1,2,3,4,8,9],"sf":[1]},{"i":1105,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[2,3],"sf":[1]},{"i":1106,"p":[1,2,3,4,7,10]},{"i":1107,"p":[1,3,4,5,6,9],"sp":[2],"l":[2,7,8,10],"f":[2],"sf":[2]},{"i":1108,"p":[1,2,7,8,9,10],"f":[2,3]},{"i":1109,"p":[1,2,3,4,7],"fp":[2,3,4,7],"f":[1,2,3]},{"i":1110,"p":[1,2,3,4,7,10],"sp":[2],"f":[1,2,3],"sf":[1]},{"i":1111,"p":[2,4,6,7,9,10]},{"i":1112,"p":[1]},{"i":1113,"p":[1,7,8,9,10],"sp":[1,2],"f":[3],"sf":[1,2]},{"i":1114,"p":[1,7]},{"i":1115,"p":[1],"sp":[1],"f":[3]},{"i":1116,"p":[1,2,3,4,7,9,10]},{"i":1117,"p":[1,2,3,4,7,8,9,10],"sp":[1,2]},{"i":1118,"p":[1,2,3,4,5,6,9,10],"fp":[2,3,4,5,6,9,10],"sp":[1,2],"l":[7,8],"f":[3],"sf":[1]},{"i":1119,"p":[3,4,7,9],"f":[2]},{"i":1120,"p":[1,2,3],"sp":[1,2],"l":[7,8,9,10],"f":[3]},{"i":1121,"p":[1,2,3,4,6,8],"sp":[2],"f":[1,2]},{"i":1122,"p":[1,9],"f":[2,3],"sf":[2]},{"i":1123,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":1124,"p":[1,2,3,4,7,9],"f":[1,2,3]},{"i":1125,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[3]},{"i":1126,"p":[1,2,3,4,7,9,10],"fp":[2,7,10],"sp":[1,2],"f":[1,2,3]},{"i":1127,"p":[1,3,7,8,10],"f":[2,3]},{"i":1128,"p":[1,2,3,4,7]},{"i":1129,"sp":[1,2],"l":[8]},{"i":1130,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[3],"sf":[1,2]},{"i":1131,"p":[1,2,3,4,7,9],"sp":[1,2],"l":[10],"f":[3],"sf":[2]},{"i":1132,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"sp":[2],"f":[1,2,3],"sf":[1,2]},{"i":1133,"p":[1,2,7,10],"sp":[1,2],"f":[3]},{"i":1134,"p":[1,2,7],"sp":[1,2],"f":[3]},{"i":1135,"p":[1,2,3,4,5,6],"fp":[2],"sp":[1,2],"l":[7,8]},{"i":1136,"p":[1,2,3,4,7,10],"sp":[2],"f":[1,2,3],"sf":[1]},{"i":1137,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":1138,"p":[1,2,3,4,5,6,8,9,10],"fp":[2,8,9,10],"sp":[1,2],"f":[3],"sf":[2]},{"i":1139,"p":[1,5,6,8,10],"sp":[2],"f":[3]},{"i":1140,"sp":[1,2],"l":[2,7,8,10],"sf":[1]},{"i":1141,"p":[1,9,10],"fp":[9,10],"f":[3]},{"i":1142,"fp":[7,10],"sp":[1],"l":[7,10]},{"i":1143,"p":[1,2,7,10],"sp":[2]},{"i":1144,"p":[1,2,3,4,7,8,9,10],"f":[1,2,3]},{"i":1145,"p":[1,2,3,4,7,8],"sp":[2]},{"i":1146,"p":[7,8,9,10],"f":[2,3]},{"i":1147,"p":[1,2,3,4,5,7],"sp":[1,2],"l":[10],"f":[3],"sf":[1,2]},{"i":1148,"p":[1,2,3,4,5,6,7],"sp":[1,2],"f":[1,3]},{"i":1149,"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[1,3]},{"i":1150,"p":[1,2,3,4,7,10],"fp":[7],"sp":[1,2],"f":[1,2,3]},{"i":1151,"p":[9],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[3],"sf":[1]},{"i":1152,"p":[1],"l":[7,8,9],"sf":[2]},{"i":1153,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,3]},{"i":1154,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[2]},{"i":1155,"p":[7,9],"f":[1,2,3],"sf":[1,2]},{"i":1156,"p":[1,2,3,4,5],"sp":[1,2],"l":[7],"f":[2,3]},{"i":1157,"p":[1,7,10],"sp":[1,2],"f":[3]},{"i":1158,"p":[1,7,9,10],"sp":[1],"f":[1,2,3]},{"i":1159,"p":[3,5,10],"f":[1,2,3]},{"i":1160,"sp":[1,2]},{"i":1161,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2],"sf":[1]},{"i":1162,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[2,3],"sf":[1,2]},{"i":1163,"p":[1,2,3,4,7,9,10],"sp":[1],"f":[1,2,3]},{"i":1164,"p":[1],"sp":[2],"f":[1]},{"i":1165,"p":[1,3,4,5,6],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":1166,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":1167,"p":[1,2,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[3],"sf":[1]},{"i":1168,"p":[3,4],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[3]},{"i":1169,"sp":[1,2],"l":[7,8,10]},{"i":1170,"sp":[1,2],"l":[7,8,9,10]},{"i":1171,"sp":[2],"l":[7,8,10]},{"i":1172,"sp":[1],"f":[1,2,3]},{"i":1173,"p":[1,2,3,4,5,6],"fp":[9],"sp":[1],"l":[9,10],"f":[2,3],"sf":[1]},{"i":1174,"p":[1,2,7,8,9,10],"fp":[2,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1,2]},{"i":1175,"p":[7],"sf":[1]},{"i":1176,"p":[1,3,4,7],"fp":[2,10],"sp":[1,2],"l":[2,10],"f":[2,3],"sf":[1,2]},{"i":1177,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[2,3]},{"i":1178,"p":[1,2,3,4,7],"f":[3],"sf":[2]},{"i":1179,"p":[2,7],"sp":[1]},{"i":1180,"p":[1,3,5]},{"i":1181,"p":[1,8,10],"f":[3],"sf":[1]},{"i":1182,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1]},{"i":1183,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[2]},{"i":1184,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":1185,"p":[1,2,3,4,5,7,9,10],"sp":[1,2],"f":[3]},{"i":1187,"sp":[1,2],"f":[1]},{"i":1188,"p":[1,7,8,10],"fp":[7,8,10],"sp":[1,2]},{"i":1189,"p":[7,10],"sp":[1,2],"sf":[1]},{"i":1190,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,3],"sf":[1]},{"i":1191,"p":[2,3,4],"f":[1],"sf":[1]},{"i":1192,"p":[1,2,3,4],"fp":[7],"sp":[1,2],"l":[7,8,9,10],"f":[3],"sf":[1,2]},{"i":1193,"p":[1,3,4,5,6],"l":[2,7,10],"f":[3]},{"i":1194,"p":[1,2,3,4,7,9],"fp":[2,3,4,7,9,10],"sp":[1,2],"l":[10],"f":[1,2,3],"sf":[1]},{"i":1195,"p":[7,9,10],"fp":[7,9,10]},{"i":1196,"p":[1,2,3,4,5,7,8],"sp":[2],"f":[3]},{"i":1197,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,3,4,5,6,7,8,9,10],"sp":[1],"f":[3],"sf":[1]},{"i":1198,"p":[1,2,4,7,9,10],"fp":[2],"sp":[1,2],"f":[3]},{"i":1199,"p":[1,2,7,8,10],"fp":[10],"sp":[1,2],"f":[3],"sf":[2]},{"i":1200,"p":[1,3,4,5,6,8,9,10],"fp":[2,7],"sp":[1,2],"l":[2,7],"f":[2]},{"i":1201,"p":[2,7,8,10]},{"i":1202,"p":[2,7,10],"fp":[2,7,10],"sp":[2],"f":[3],"sf":[1]},{"i":1203,"fp":[2,7,10],"sp":[1,2],"l":[2,7,10]},{"i":1204,"sp":[1]},{"i":1205,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1]},{"i":1206,"p":[1,7,9],"fp":[7,9],"f":[1,2,3]},{"i":1207,"p":[1],"fp":[2],"l":[2]},{"i":1208,"sp":[2],"l":[7],"f":[3]},{"i":1209,"p":[1,2,3,4,7,9],"sp":[1,2],"f":[2],"sf":[1]},{"i":1210,"p":[1,2],"fp":[2,7,8,9,10],"sp":[1,2],"l":[7,8,9,10],"f":[3],"sf":[1,2]},{"i":1211,"p":[1,2,3,4],"sp":[1,2],"l":[7,10],"f":[3],"sf":[1,2]},{"i":1212,"p":[1,2,3,4,7,10],"sp":[1,2],"f":[3]},{"i":1213,"p":[2,3,4],"f":[1,2,3],"sf":[2]},{"i":1214,"p":[1,3,4],"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10],"f":[1]},{"i":1215,"p":[1,2,3,4,5,6,7,8,9,10],"sp":[1,2],"f":[1,2,3],"sf":[1]},{"i":1216,"p":[1,3,4],"fp":[2,7,10],"sp":[1,2],"l":[2,7,10],"f":[1],"sf":[1]},{"i":1217,"l":[7],"f":[1]},{"i":1218,"p":[1,2,7,10],"sp":[1,2],"f":[1,2,3]},{"i":1219,"sp":[1,2],"l":[7,8]},{"i":1220,"p":[1,3,5,7,9],"f":[1,3]},{"i":1221,"p":[3,4,7,8,9,10],"fp":[7,8,9,10],"sp":[1,2],"l":[2],"f":[2,3]},{"i":1222,"p":[1,2,3,4,7],"sp":[2],"f":[1,2,3],"sf":[2]},{"i":1223,"sp":[1,2],"f":[1,3],"sf":[2]},{"i":1224,"p":[1,2,3,4,5,6,7,8,9,10]},{"i":1225,"sp":[1,2],"f":[1],"sf":[1]},{"i":1226,"p":[1,2,3,4,5,6,7,8,9,10],"fp":[2,7,8,9,10],"f":[1],"sf":[1]},{"i":1227,"p":[1,3,4],"fp":[2,9],"sp":[1,2],"l":[2,7,9,10],"f":[3]},{"i":1228,"fp":[2,7,9,10],"sp":[1,2],"l":[2,7,9,10]},{"i":1229,"p":[1,3,4,5,6],"sp":[1,2],"l":[2,7,8,9,10],"f":[3],"sf":[1]},{"i":1230,"p":[1,3,4,5,6],"fp":[2,7,8,9,10],"sp":[1,2],"l":[2,7,8,9,10],"f":[1,3]},{"i":1231,"p":[1,2,3,7,8,9],"f":[1,2]},{"i":1232,"p":[7,8,10]},{"i":1233,"p":[1,2,7,10],"sp":[1,2],"f":[2,3]},{"i":1234,"sp":[2]},{"i":1235,"p":[1,2,7,10]},{"i":1236,"p":[1],"sp":[1,2],"l":[2,7,10],"f":[3]},{"i":1237,"p":[8,9]},{"i":1238,"p":[1,7,8],"fp":[7,8],"sp":[1],"f":[1]},{"i":1240,"p":[1,2,3,4,5,6],"sp":[1,2],"l":[7,8,10]},{"i":1241,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":1242,"p":[1,2,3,4,5,6,7,8,9,10],"f":[1,2,3],"sf":[1,2]},{"i":1243,"p":[1,2,3,4,5,6],"sp":[1],"l":[7,8,9,10],"f":[3],"sf":[2]},{"i":1244,"p":[3,4],"fp":[2,7,9],"sp":[1,2],"l":[2,7,9],"f":[3]},{"i":1245,"p":[1,10],"fp":[10],"sp":[1,2],"f":[1,3],"sf":[2]},{"i":1246,"p":[1,2,4],"fp":[2,7,10],"sp":[1,2],"l":[7,10],"f":[3]},{"i":1247,"l":[7,8]},{"i":1248,"p":[1,2,3,4,7,9,10],"sp":[1,2],"f":[3]},{"i":1249,"p":[1,2,3,4],"fp":[2,7,9],"sp":[1],"l":[7,9,10],"f":[3],"sf":[1]},{"i":1250,"p":[1,7]},{"i":4176,"sp":[1],"f":[3]},{"i":4202,"p":[1,4],"sp":[1,2],"l":[2,7],"f":[3]}],"st":[{"i":1,"p":[],"sf":[1,2]},{"i":2,"p":[2,7],"sf":[]},{"i":3,"p":[2,3,4],"sf":[]},{"i":4,"p":[2,7,9],"sf":[]},{"i":5,"p":[2,3,7],"sf":[]},{"i":6,"p":[2,4,7],"sf":[]},{"i":7,"p":[2,4,7,9],"sf":[]},{"i":8,"p":[2,3,4,7],"sf":[]},{"i":9,"p":[2,3,4,7,9],"sf":[]},{"i":10,"p":[3,4],"sf":[]},{"i":11,"p":[5,6],"sf":[]},{"i":12,"p":[6,8],"sf":[]},{"i":13,"p":[6,8,9],"sf":[]},{"i":14,"p":[5,6,8],"sf":[]},{"i":15,"p":[5,6,8,9],"sf":[]},{"i":16,"p":[5,6,8,9,10],"sf":[]},{"i":17,"p":[7,8,9],"sf":[]},{"i":18,"p":[7,8],"sf":[]},{"i":19,"p":[7,9],"sf":[]},{"i":20,"p":[7,8,9,10],"sf":[]},{"i":21,"p":[8,9,10],"sf":[]},{"i":22,"p":[8,10],"sf":[]},{"i":23,"p":[2,4,6,7,8],"sf":[]},{"i":24,"p":[2,4,6,7,8,9],"sf":[]},{"i":25,"p":[2,3,4,5,6,7,8],"sf":[]},{"i":26,"p":[2,3,4,5,6,7,8,9],"sf":[]},{"i":27,"p":[3,5],"sf":[]},{"i":28,"p":[2,4,6],"sf":[]},{"i":29,"p":[2,7,8,9],"sf":[]},{"i":30,"p":[2,4,5,6,7,8,9],"sf":[]},{"i":31,"p":[2,4,5,6,7,8,9,10],"sf":[]},{"i":32,"p":[2,5,6,7,8,9],"sf":[]},{"i":33,"p":[2,5,6,7,8,9,10],"sf":[]},{"i":34,"p":[2,5,6,8,9],"sf":[]},{"i":35,"p":[2,5,6,8,9,10],"sf":[]},{"i":36,"p":[2,5,6,7],"sf":[]},{"i":37,"p":[2,5,6,7,10],"sf":[]},{"i":38,"p":[2,3,4,7,10],"sf":[]},{"i":39,"p":[2,3,4,7,9,10],"sf":[]},{"i":40,"p":[2,3,4,7,8,9,10],"sf":[]},{"i":41,"p":[2,3,4,6,7,8,9,10],"sf":[]},{"i":42,"p":[2,3,4,5,6,7,8,9,10],"sf":[]}]}'),
                    n = {
                        vendorListVersion: i.v,
                        lastUpdated: i.l,
                        gvlSpecificationVersion: i.I,
                        tcfPolicyVersion: i.V,
                        purposes: i.p.map((e => ({
                            id: e
                        }))),
                        specialPurposes: i.sp.map((e => ({
                            id: e
                        }))),
                        features: i.f.map((e => ({
                            id: e
                        }))),
                        specialFeatures: i.sf.map((e => ({
                            id: e
                        }))),
                        stacks: i.st.map((e => ({
                            id: e.i,
                            purposeIds: e.p || [],
                            specialFeatureIds: e.sf || []
                        }))),
                        vendors: i.s.map((e => ({
                            id: e.i,
                            purposeIds: e.p || [],
                            flexiblePurposeIds: e.fp || [],
                            specialPurposeIds: e.sp || [],
                            legIntPurposeIds: e.l || [],
                            featureIds: e.f || [],
                            specialFeatureIds: e.sf || []
                        })))
                    }
            },
            97501: function(e, t, s) {
                var i;
                e = s.nmd(e),
                    function(n) {
                        var r = t,
                            o = (e && e.exports, "object" == typeof s.g && s.g);
                        o.global !== o && o.window;
                        var a = function(e) {
                            this.message = e
                        };
                        (a.prototype = new Error).name = "InvalidCharacterError";
                        var u = function(e) {
                                throw new a(e)
                            },
                            d = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                            l = /[\t\n\f\r ]/g,
                            p = {
                                encode: function(e) {
                                    e = String(e), /[^\0-\xFF]/.test(e) && u("The string to be encoded contains characters outside of the Latin1 range.");
                                    for (var t, s, i, n, r = e.length % 3, o = "", a = -1, l = e.length - r; ++a < l;) t = e.charCodeAt(a) << 16, s = e.charCodeAt(++a) << 8, i = e.charCodeAt(++a), o += d.charAt((n = t + s + i) >> 18 & 63) + d.charAt(n >> 12 & 63) + d.charAt(n >> 6 & 63) + d.charAt(63 & n);
                                    return 2 == r ? (t = e.charCodeAt(a) << 8, s = e.charCodeAt(++a), o += d.charAt((n = t + s) >> 10) + d.charAt(n >> 4 & 63) + d.charAt(n << 2 & 63) + "=") : 1 == r && (n = e.charCodeAt(a), o += d.charAt(n >> 2) + d.charAt(n << 4 & 63) + "=="), o
                                },
                                decode: function(e) {
                                    var t = (e = String(e).replace(l, "")).length;
                                    t % 4 == 0 && (t = (e = e.replace(/==?$/, "")).length), (t % 4 == 1 || /[^+a-zA-Z0-9/]/.test(e)) && u("Invalid character: the string to be decoded is not correctly encoded.");
                                    for (var s, i, n = 0, r = "", o = -1; ++o < t;) i = d.indexOf(e.charAt(o)), s = n % 4 ? 64 * s + i : i, n++ % 4 && (r += String.fromCharCode(255 & s >> (-2 * n & 6)));
                                    return r
                                },
                                version: "0.1.0"
                            };
                        void 0 === (i = function() {
                            return p
                        }.call(t, s, t, e)) || (e.exports = i)
                    }()
            },
            26905: function(e) {
                e.exports = function(e, t, s, i, n) {
                    for (t = t.split ? t.split(".") : t, i = 0; i < t.length; i++) e = e ? e[t[i]] : n;
                    return e === n ? s : e
                }
            },
            64063: function(e) {
                "use strict";
                var t = Array.isArray,
                    s = Object.keys,
                    i = Object.prototype.hasOwnProperty;
                e.exports = function e(n, r) {
                    if (n === r) return !0;
                    var o, a, u, d = t(n),
                        l = t(r);
                    if (d && l) {
                        if ((a = n.length) != r.length) return !1;
                        for (o = 0; o < a; o++)
                            if (!e(n[o], r[o])) return !1;
                        return !0
                    }
                    if (d != l) return !1;
                    var p = n instanceof Date,
                        c = r instanceof Date;
                    if (p != c) return !1;
                    if (p && c) return n.getTime() == r.getTime();
                    var f = n instanceof RegExp,
                        v = r instanceof RegExp;
                    if (f != v) return !1;
                    if (f && v) return n.toString() == r.toString();
                    if (n instanceof Object && r instanceof Object) {
                        var h = s(n);
                        if ((a = h.length) !== s(r).length) return !1;
                        for (o = 0; o < a; o++)
                            if (!i.call(r, h[o])) return !1;
                        for (o = 0; o < a; o++)
                            if (!e(n[u = h[o]], r[u])) return !1;
                        return !0
                    }
                    return !1
                }
            },
            49910: function(e, t, s) {
                var i = ["responseType", "withCredentials", "timeout", "onprogress"];

                function n(e, t, s) {
                    e[t] = e[t] || s
                }
                t.ajax = function(e, t) {
                    var r = e.headers || {},
                        o = e.body,
                        a = e.method || (o ? "POST" : "GET"),
                        u = !1,
                        d = function(e) {
                            if (e && s.g.XDomainRequest && !/MSIE 1/.test(navigator.userAgent)) return new XDomainRequest;
                            if (s.g.XMLHttpRequest) return new XMLHttpRequest
                        }(e.cors);

                    function l(e, s) {
                        return function() {
                            u || (t(void 0 === d.status ? e : d.status, 0 === d.status ? "Error" : d.response || d.responseText || s, d), u = !0)
                        }
                    }
                    d.open(a, e.url, !0);
                    var p = d.onload = l(200);
                    d.onreadystatechange = function() {
                        4 === d.readyState && p()
                    }, d.onerror = l(null, "Error"), d.ontimeout = l(null, "Timeout"), d.onabort = l(null, "Abort"), o && (n(r, "X-Requested-With", "XMLHttpRequest"), s.g.FormData && o instanceof s.g.FormData || n(r, "Content-Type", "application/x-www-form-urlencoded"));
                    for (var c = 0, f = i.length; c < f; c++) void 0 !== e[v = i[c]] && (d[v] = e[v]);
                    for (var v in r) d.setRequestHeader(v, r[v]);
                    return d.send(o), d
                }
            },
            34155: function(e) {
                var t, s, i = e.exports = {};

                function n() {
                    throw new Error("setTimeout has not been defined")
                }

                function r() {
                    throw new Error("clearTimeout has not been defined")
                }

                function o(e) {
                    if (t === setTimeout) return setTimeout(e, 0);
                    if ((t === n || !t) && setTimeout) return t = setTimeout, setTimeout(e, 0);
                    try {
                        return t(e, 0)
                    } catch (s) {
                        try {
                            return t.call(null, e, 0)
                        } catch (s) {
                            return t.call(this, e, 0)
                        }
                    }
                }! function() {
                    try {
                        t = "function" == typeof setTimeout ? setTimeout : n
                    } catch (e) {
                        t = n
                    }
                    try {
                        s = "function" == typeof clearTimeout ? clearTimeout : r
                    } catch (e) {
                        s = r
                    }
                }();
                var a, u = [],
                    d = !1,
                    l = -1;

                function p() {
                    d && a && (d = !1, a.length ? u = a.concat(u) : l = -1, u.length && c())
                }

                function c() {
                    if (!d) {
                        var e = o(p);
                        d = !0;
                        for (var t = u.length; t;) {
                            for (a = u, u = []; ++l < t;) a && a[l].run();
                            l = -1, t = u.length
                        }
                        a = null, d = !1,
                            function(e) {
                                if (s === clearTimeout) return clearTimeout(e);
                                if ((s === r || !s) && clearTimeout) return s = clearTimeout, clearTimeout(e);
                                try {
                                    return s(e)
                                } catch (t) {
                                    try {
                                        return s.call(null, e)
                                    } catch (t) {
                                        return s.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function f(e, t) {
                    this.fun = e, this.array = t
                }

                function v() {}
                i.nextTick = function(e) {
                    var t = new Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var s = 1; s < arguments.length; s++) t[s - 1] = arguments[s];
                    u.push(new f(e, t)), 1 !== u.length || d || o(c)
                }, f.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, i.title = "browser", i.browser = !0, i.env = {}, i.argv = [], i.version = "", i.versions = {}, i.on = v, i.addListener = v, i.once = v, i.off = v, i.removeListener = v, i.removeAllListeners = v, i.emit = v, i.prependListener = v, i.prependOnceListener = v, i.listeners = function(e) {
                    return []
                }, i.binding = function(e) {
                    throw new Error("process.binding is not supported")
                }, i.cwd = function() {
                    return "/"
                }, i.chdir = function(e) {
                    throw new Error("process.chdir is not supported")
                }, i.umask = function() {
                    return 0
                }
            },
            61218: function(e, t) {
                "use strict";
                var s = {
                        instance: null
                    },
                    i = [],
                    n = 10;

                function r(e, t) {
                    var s = JSON.parse(t.state),
                        r = Object.keys(s.actionsById).filter((function(e) {
                            return parseInt(e, 10) <= t.payload.id
                        })),
                        o = 0;
                    setTimeout((function t() {
                        ! function(t) {
                            if ("initialState" === t.type) e.setState(s.computedStates[0].state);
                            else {
                                var n = i.find((function(e) {
                                    return t.type === e.key
                                }));
                                n && n.fn()
                            }
                        }(s.actionsById[r[o]].action), ++o >= r.length || setTimeout(t, n)
                    }), 0)
                }

                function o(e) {
                    "DISPATCH" === e.type && ("JUMP_TO_ACTION" === e.payload.type || "JUMP_TO_STATE" === e.payload.type ? this.setState(JSON.parse(e.state)) : "TOGGLE_ACTION" === e.payload.type && r(this, e))
                }

                function a(e, t) {
                    if (!t.initialized) {
                        var i = o.bind(e);
                        s.instance && s.instance.subscribe(i), t.initialized = !0
                    }
                }
                var u = function(e) {
                    return function(t, n) {
                        return function(r) {
                            var o = t(r);
                            a(e, u),
                                function(e, t) {
                                    var s = i.find((function(t) {
                                        return e.name === t.key
                                    }));
                                    s || (s = {
                                        key: e.name,
                                        fn: t
                                    }, i.push(s))
                                }(r, (function() {
                                    return t(r)
                                }));
                            var d = {
                                type: r.name,
                                args: n
                            };
                            return o && o.then ? o.then((function() {
                                return s.instance && s.instance.send(d, e.getState())
                            })) : (s.instance && s.instance.send(d, e.getState()), o)
                        }
                    }
                };
                "object" == typeof window && window.__REDUX_DEVTOOLS_EXTENSION__
            },
            94798: function(e) {
                "use strict";
                var t = function() {
                    return t = Object.assign || function(e) {
                        for (var t, s = 1, i = arguments.length; s < i; s++)
                            for (var n in t = arguments[s]) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                        return e
                    }, t.apply(this, arguments)
                };
                e.exports = function(e, s) {
                    void 0 === e && (e = {}), void 0 === s && (s = null);
                    var i = e || {},
                        n = [];

                    function r() {
                        n.forEach((function(e) {
                            return e(i)
                        }))
                    }
                    return {
                        middleware: s,
                        setState: function(e) {
                            i = t({}, i, "function" == typeof e ? e(i) : e), r()
                        },
                        subscribe: function(e) {
                            return n.push(e),
                                function() {
                                    n.splice(n.indexOf(e), 1)
                                }
                        },
                        getState: function() {
                            return i
                        },
                        reset: function() {
                            i = e, r()
                        }
                    }
                }
            },
            91042: function(e, t) {
                "use strict";

                function s(e, t) {
                    if (null != t) {
                        if (t.then) return t.then(e.setState);
                        e.setState(t)
                    }
                }
            },
            27867: function(e, t) {
                "use strict";

                function s(e, t) {
                    return function() {
                        for (var s = [], i = 0; i < arguments.length; i++) s[i] = arguments[i];
                        return "function" == typeof t.middleware ? t.middleware(t, e, s) : function(e, t) {
                            if (null != t) {
                                if (t.then) return t.then(e.setState);
                                e.setState(t)
                            }
                        }(t, e.apply(void 0, [t.getState()].concat(s)))
                    }
                }
                var i = function() {
                    return i = Object.assign || function(e) {
                        for (var t, s = 1, i = arguments.length; s < i; s++)
                            for (var n in t = arguments[s]) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                        return e
                    }, i.apply(this, arguments)
                };
                t.kv = function(e, t, i) {
                    e = "function" == typeof e ? e(t, i) : e;
                    var n = {};
                    for (var r in e) {
                        var o = e[r];
                        n[r] = s(o, t)
                    }
                    return n
                }, t.Y2 = function() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    return function() {
                        for (var t = [], s = 0; s < arguments.length; s++) t[s] = arguments[s];
                        return e.reduce((function(e, s) {
                            return i({}, e, "function" == typeof s ? s.apply(void 0, t) : s)
                        }), {})
                    }
                }
            },
            22222: function(e, t, s) {
                "use strict";

                function i(e, t) {
                    return e === t
                }
                s.d(t, {
                    P1: function() {
                        return n
                    }
                });
                var n = function(e) {
                    for (var t = arguments.length, s = Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) s[i - 1] = arguments[i];
                    return function() {
                        for (var t = arguments.length, i = Array(t), n = 0; n < t; n++) i[n] = arguments[n];
                        var r = 0,
                            o = i.pop(),
                            a = function(e) {
                                var t = Array.isArray(e[0]) ? e[0] : e;
                                if (!t.every((function(e) {
                                        return "function" == typeof e
                                    }))) {
                                    var s = t.map((function(e) {
                                        return typeof e
                                    })).join(", ");
                                    throw new Error("Selector creators expect all input-selectors to be functions, instead received the following types: [" + s + "]")
                                }
                                return t
                            }(i),
                            u = e.apply(void 0, [function() {
                                return r++, o.apply(null, arguments)
                            }].concat(s)),
                            d = e((function() {
                                for (var e = [], t = a.length, s = 0; s < t; s++) e.push(a[s].apply(null, arguments));
                                return u.apply(null, e)
                            }));
                        return d.resultFunc = o, d.dependencies = a, d.recomputations = function() {
                            return r
                        }, d.resetRecomputations = function() {
                            return r = 0
                        }, d
                    }
                }((function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i,
                        s = null,
                        n = null;
                    return function() {
                        return function(e, t, s) {
                            if (null === t || null === s || t.length !== s.length) return !1;
                            for (var i = t.length, n = 0; n < i; n++)
                                if (!e(t[n], s[n])) return !1;
                            return !0
                        }(t, s, arguments) || (n = e.apply(null, arguments)), s = arguments, n
                    }
                }))
            },
            99865: function(e) {
                function t(e, s) {
                    return e || (e = this instanceof t ? this : {}),
                        function(s, i) {
                            return Object.defineProperties(e, {
                                setMaxListeners: {
                                    value: function(t) {
                                        return i.maxListeners = t, e
                                    }
                                },
                                maxListeners: {
                                    get: function() {
                                        return void 0 === i.maxListeners ? t.defaultMaxListeners : i.maxListeners
                                    }
                                },
                                setLogger: {
                                    value: function(t) {
                                        return i.logger = t, e
                                    }
                                },
                                logger: {
                                    get: function() {
                                        return void 0 === i.logger ? t.logger : i.logger
                                    }
                                },
                                emit: {
                                    value: n
                                },
                                on: {
                                    value: r
                                },
                                once: {
                                    value: function(t, s) {
                                        return s._once = 1, e.on(t, s)
                                    }
                                },
                                off: {
                                    value: o
                                },
                                addListener: {
                                    value: r
                                },
                                removeListener: {
                                    value: o
                                },
                                removeAllListeners: {
                                    value: o
                                },
                                listeners: {
                                    value: function(e) {
                                        return s[e] ? s[e].slice() : []
                                    }
                                },
                                listenerTypes: {
                                    value: a
                                },
                                listenerCount: {
                                    value: function e(t) {
                                        if (!t) {
                                            var i = 0;
                                            return a().forEach((function(t) {
                                                i += e(t)
                                            })), i
                                        }
                                        if ("object" == typeof t && t.length) return a().map((function(t) {
                                            return e(t)
                                        }));
                                        return s[t] && s[t].length || 0
                                    }
                                }
                            });

                            function n(t) {
                                var i, n;
                                if (!("error" !== t || s.error && s.error.length)) throw arguments[1] instanceof Error ? n = arguments[1] : (n = new Error("Unhandled error event: " + arguments[1])).context = arguments[1], n;
                                return !!s[t] && (i = Array.prototype.slice.call(arguments, 1), s[t].slice().forEach((function(s) {
                                    s._once && 1 !== s._once || (s._once++, s.apply(e, i)), s._once && o(t, s)
                                })), e)
                            }

                            function r(t, i) {
                                if (s.newListener && e.emit("newListener", t, i), s[t] = s[t] || [], s[t].push(i), !s[t].warned) {
                                    var n = e.maxListeners;
                                    n && n > 0 && s[t].length > n && (s[t].warned = !0, e.logger.warn("Possible EventEmitter memory leak detected for '%s' event. %d listeners added. Use emitter.setMaxListeners() to increase limit.", t, s[t].length), e.logger.trace && e.logger.trace())
                                }
                                return e
                            }

                            function o(t, i) {
                                if (!i && !s.removeListener) return t ? s[t] && delete s[t] : s = {}, e;
                                if (!t) {
                                    for (var r in s) "removeListener" != r && o(r);
                                    return o("removeListener"), s = {}, e
                                }
                                if (!s[t]) return e;
                                if (!i) {
                                    for (; s[t].length;) o(t, s[t][s[t].length - 1]);
                                    return delete s[t], e
                                }
                                var a = s[t].indexOf(i);
                                return a < 0 || (s[t].splice(a, 1), s.removeListener && n("removeListener", t, i)), e
                            }

                            function a() {
                                return Object.keys(s)
                            }
                        }({}, {
                            logger: s && s.logger,
                            maxListeners: s && s.maxListeners
                        })
                }
                t.EventEmitter = t, t.defaultMaxListeners = 10, t.logger = "object" == typeof console && console || {
                    warn: function() {}
                }, t.setLogger = function(e) {
                    t.logger = e
                }, e.exports = t
            },
            57710: function(e, t, s) {
                var i = {
                    "./v2.2/purposes/index.js": [94712, "src_sdk_regulations_gdpr_tcf_v2_2_purposes_index_js"],
                    "./v2/purposes/index.js": [27223]
                };

                function n(e) {
                    if (!s.o(i, e)) return Promise.resolve().then((function() {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }));
                    var t = i[e],
                        n = t[0];
                    return Promise.all(t.slice(1).map(s.e)).then((function() {
                        return s(n)
                    }))
                }
                n.keys = function() {
                    return Object.keys(i)
                }, n.id = 57710, e.exports = n
            },
            44618: function(e, t, s) {
                var i = {
                    "./v2.2/vendors/iab-core": [64005, "src_sdk_regulations_gdpr_tcf_v2_2_vendors_iab-core_js"],
                    "./v2/vendors/iab-core": [595]
                };

                function n(e) {
                    if (!s.o(i, e)) return Promise.resolve().then((function() {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }));
                    var t = i[e],
                        n = t[0];
                    return Promise.all(t.slice(1).map(s.e)).then((function() {
                        return s(n)
                    }))
                }
                n.keys = function() {
                    return Object.keys(i)
                }, n.id = 44618, e.exports = n
            },
            25334: function(e, t, s) {
                var i = {
                    "./ar-JO/ctv/": [26657, "ui-ctv0"],
                    "./ar/ctv/": [625, "ui-ctv1"],
                    "./az-AZ/ctv/": [36564, "ui-ctv2"],
                    "./bg/ctv/": [39377, "ui-ctv3"],
                    "./bn-IN/ctv/": [51472, "ui-ctv4"],
                    "./ca/ctv/": [47118, "ui-ctv5"],
                    "./cs/ctv/": [90449, "ui-ctv6"],
                    "./da/ctv/": [2613, "ui-ctv7"],
                    "./de-AT/ctv/": [33310, "ui-ctv8"],
                    "./de-CH/ctv/": [60970, "ui-ctv9"],
                    "./de/ctv/": [78044, "ui-ctv10"],
                    "./el/ctv/": [35675, "ui-ctv11"],
                    "./en-GB/ctv/": [15529, "ui-ctv12"],
                    "./en-NZ/ctv/": [35188, "ui-ctv13"],
                    "./en/ctv/": [16427, "ui-ctv14"],
                    "./es/ctv/": [319, "ui-ctv15"],
                    "./et/ctv/": [97055, "ui-ctv16"],
                    "./fi/ctv/": [11026, "ui-ctv17"],
                    "./fil/ctv/": [63650, "ui-ctv18"],
                    "./fr-BE/ctv/": [10139, "ui-ctv19"],
                    "./fr-CA/ctv/": [7071, "ui-ctv20"],
                    "./fr/ctv/": [50671, "ui-ctv21"],
                    "./he/ctv/": [28056, "ui-ctv22"],
                    "./hi-IN/ctv/": [35061, "ui-ctv23"],
                    "./hr/ctv/": [59027, "ui-ctv24"],
                    "./hu/ctv/": [48552, "ui-ctv25"],
                    "./id/ctv/": [72973, "ui-ctv26"],
                    "./it/ctv/": [38066, "ui-ctv27"],
                    "./ja/ctv/": [58693, "ui-ctv28"],
                    "./ko/ctv/": [37558, "ui-ctv29"],
                    "./lt/ctv/": [63067, "ui-ctv30"],
                    "./lv/ctv/": [4325, "ui-ctv31"],
                    "./mk-MK/ctv/": [88775, "ui-ctv32"],
                    "./ms/ctv/": [7524, "ui-ctv33"],
                    "./nl-BE/ctv/": [54235, "ui-ctv34"],
                    "./nl/ctv/": [18512, "ui-ctv35"],
                    "./no/ctv/": [95218, "ui-ctv36"],
                    "./pl/ctv/": [77668, "ui-ctv37"],
                    "./pt-BR/ctv/": [45078, "ui-ctv38"],
                    "./pt/ctv/": [76716, "ui-ctv39"],
                    "./ro/ctv/": [82001, "ui-ctv40"],
                    "./ru/ctv/": [49622, "ui-ctv41"],
                    "./sk/ctv/": [57054, "ui-ctv42"],
                    "./sl/ctv/": [17919, "ui-ctv43"],
                    "./sr/ctv/": [24475, "ui-ctv44"],
                    "./sv/ctv/": [26545, "ui-ctv45"],
                    "./sw/ctv/": [73066, "ui-ctv46"],
                    "./th/ctv/": [58742, "ui-ctv47"],
                    "./tr/ctv/": [70521, "ui-ctv48"],
                    "./uk/ctv/": [73199, "ui-ctv49"],
                    "./vi/ctv/": [36108, "ui-ctv50"],
                    "./zh-CN/ctv/": [73751, "ui-ctv51"],
                    "./zh-TW/ctv/": [89360, "ui-ctv52"]
                };

                function n(e) {
                    if (!s.o(i, e)) return Promise.resolve().then((function() {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }));
                    var t = i[e],
                        n = t[0];
                    return s.e(t[1]).then((function() {
                        return s(n)
                    }))
                }
                n.keys = function() {
                    return Object.keys(i)
                }, n.id = 25334, e.exports = n
            },
            41098: function(e, t, s) {
                var i = {
                    "./ar-JO/web2.2/": [70241, "ui-gdpr-tcf-2-2-ar-JO-web2-2"],
                    "./ar/web2.2/": [96173, "ui-gdpr-tcf-2-2-ar-web2-2"],
                    "./az-AZ/web2.2/": [66475, "ui-gdpr-tcf-2-2-az-AZ-web2-2"],
                    "./bg/web2.2/": [20621, "ui-gdpr-tcf-2-2-bg-web2-2"],
                    "./bn-IN/web2.2/": [21507, "ui-gdpr-tcf-2-2-bn-IN-web2-2"],
                    "./ca/web2.2/": [35293, "ui-gdpr-tcf-2-2-ca-web2-2"],
                    "./cs/web2.2/": [30896, "ui-gdpr-tcf-2-2-cs-web2-2"],
                    "./da/web2.2/": [665, "ui-gdpr-tcf-2-2-da-web2-2"],
                    "./de-AT/web2.2/": [59803, "ui-gdpr-tcf-2-2-de-AT-web2-2"],
                    "./de-CH/web2.2/": [52728, "ui-gdpr-tcf-2-2-de-CH-web2-2"],
                    "./de/web2.2/": [43147, "ui-gdpr-tcf-2-2-de-web2-2"],
                    "./el/web2.2/": [38472, "ui-gdpr-tcf-2-2-el-web2-2"],
                    "./en-GB/web2.2/": [84874, "ui-gdpr-tcf-2-2-en-GB-web2-2"],
                    "./en-NZ/web2.2/": [73258, "ui-gdpr-tcf-2-2-en-NZ-web2-2"],
                    "./en/web2.2/": [62187, "ui-gdpr-tcf-2-2-en-web2-2"],
                    "./es/web2.2/": [64118, "ui-gdpr-tcf-2-2-es-web2-2"],
                    "./et/web2.2/": [57135, "ui-gdpr-tcf-2-2-et-web2-2"],
                    "./fi/web2.2/": [37577, "ui-gdpr-tcf-2-2-fi-web2-2"],
                    "./fil/web2.2/": [41765, "ui-gdpr-tcf-2-2-fil-web2-2"],
                    "./fr-BE/web2.2/": [12560, "ui-gdpr-tcf-2-2-fr-BE-web2-2"],
                    "./fr-CA/web2.2/": [47436, "ui-gdpr-tcf-2-2-fr-CA-web2-2"],
                    "./fr/web2.2/": [12863, "ui-gdpr-tcf-2-2-fr-web2-2"],
                    "./he/web2.2/": [75543, "ui-gdpr-tcf-2-2-he-web2-2"],
                    "./hi-IN/web2.2/": [48882, "ui-gdpr-tcf-2-2-hi-IN-web2-2"],
                    "./hr/web2.2/": [53316, "ui-gdpr-tcf-2-2-hr-web2-2"],
                    "./hu/web2.2/": [5152, "ui-gdpr-tcf-2-2-hu-web2-2"],
                    "./id/web2.2/": [49024, "ui-gdpr-tcf-2-2-id-web2-2"],
                    "./it/web2.2/": [73527, "ui-gdpr-tcf-2-2-it-web2-2"],
                    "./ja/web2.2/": [65886, "ui-gdpr-tcf-2-2-ja-web2-2"],
                    "./ko/web2.2/": [67840, "ui-gdpr-tcf-2-2-ko-web2-2"],
                    "./lt/web2.2/": [56778, "ui-gdpr-tcf-2-2-lt-web2-2"],
                    "./lv/web2.2/": [49326, "ui-gdpr-tcf-2-2-lv-web2-2"],
                    "./mk-MK/web2.2/": [15150, "ui-gdpr-tcf-2-2-mk-MK-web2-2"],
                    "./ms/web2.2/": [93184, "ui-gdpr-tcf-2-2-ms-web2-2"],
                    "./nl-BE/web2.2/": [5262, "ui-gdpr-tcf-2-2-nl-BE-web2-2"],
                    "./nl/web2.2/": [25473, "ui-gdpr-tcf-2-2-nl-web2-2"],
                    "./no/web2.2/": [87761, "ui-gdpr-tcf-2-2-no-web2-2"],
                    "./pl/web2.2/": [68282, "ui-gdpr-tcf-2-2-pl-web2-2"],
                    "./pt-BR/web2.2/": [46814, "ui-gdpr-tcf-2-2-pt-BR-web2-2"],
                    "./pt/web2.2/": [82443, "ui-gdpr-tcf-2-2-pt-web2-2"],
                    "./ro/web2.2/": [31161, "ui-gdpr-tcf-2-2-ro-web2-2"],
                    "./ru/web2.2/": [50363, "ui-gdpr-tcf-2-2-ru-web2-2"],
                    "./sk/web2.2/": [71118, "ui-gdpr-tcf-2-2-sk-web2-2"],
                    "./sl/web2.2/": [88481, "ui-gdpr-tcf-2-2-sl-web2-2"],
                    "./sr/web2.2/": [12945, "ui-gdpr-tcf-2-2-sr-web2-2"],
                    "./sv/web2.2/": [60468, "ui-gdpr-tcf-2-2-sv-web2-2"],
                    "./sw/web2.2/": [88219, "ui-gdpr-tcf-2-2-sw-web2-2"],
                    "./th/web2.2/": [48802, "ui-gdpr-tcf-2-2-th-web2-2"],
                    "./tr/web2.2/": [56338, "ui-gdpr-tcf-2-2-tr-web2-2"],
                    "./uk/web2.2/": [94939, "ui-gdpr-tcf-2-2-uk-web2-2"],
                    "./vi/web2.2/": [25462, "ui-gdpr-tcf-2-2-vi-web2-2"],
                    "./zh-CN/web2.2/": [60919, "ui-gdpr-tcf-2-2-zh-CN-web2-2"],
                    "./zh-TW/web2.2/": [4742, "ui-gdpr-tcf-2-2-zh-TW-web2-2"]
                };

                function n(e) {
                    if (!s.o(i, e)) return Promise.resolve().then((function() {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }));
                    var t = i[e],
                        n = t[0];
                    return s.e(t[1]).then((function() {
                        return s(n)
                    }))
                }
                n.keys = function() {
                    return Object.keys(i)
                }, n.id = 41098, e.exports = n
            },
            4848: function(e, t, s) {
                var i = {
                    "./ar-JO/web/": [3300, "ui-gdpr-ar-JO-web"],
                    "./ar/web/": [31782, "ui-gdpr-ar-web"],
                    "./az-AZ/web/": [464, "ui-gdpr-az-AZ-web"],
                    "./bg/web/": [50690, "ui-gdpr-bg-web"],
                    "./bn-IN/web/": [31212, "ui-gdpr-bn-IN-web"],
                    "./ca/web/": [16796, "ui-gdpr-ca-web"],
                    "./cs/web/": [18585, "ui-gdpr-cs-web"],
                    "./da/web/": [385, "ui-gdpr-da-web"],
                    "./de-AT/web/": [11474, "ui-gdpr-de-AT-web"],
                    "./de-CH/web/": [44864, "ui-gdpr-de-CH-web"],
                    "./de/web/": [79020, "ui-gdpr-de-web"],
                    "./el/web/": [70755, "ui-gdpr-el-web"],
                    "./en-GB/web/": [49214, "ui-gdpr-en-GB-web"],
                    "./en-NZ/web/": [20097, "ui-gdpr-en-NZ-web"],
                    "./en/web/": [94819, "ui-gdpr-en-web"],
                    "./es/web/": [56161, "ui-gdpr-es-web"],
                    "./et/web/": [49639, "ui-gdpr-et-web"],
                    "./fi/web/": [46846, "ui-gdpr-fi-web"],
                    "./fil/web/": [21782, "ui-gdpr-fil-web"],
                    "./fr-BE/web/": [28816, "ui-gdpr-fr-BE-web"],
                    "./fr-CA/web/": [84670, "ui-gdpr-fr-CA-web"],
                    "./fr/web/": [49821, "ui-gdpr-fr-web"],
                    "./he/web/": [2011, "ui-gdpr-he-web"],
                    "./hi-IN/web/": [15876, "ui-gdpr-hi-IN-web"],
                    "./hr/web/": [99346, "ui-gdpr-hr-web"],
                    "./hu/web/": [79924, "ui-gdpr-hu-web"],
                    "./id/web/": [49702, "ui-gdpr-id-web"],
                    "./it/web/": [72596, "ui-gdpr-it-web"],
                    "./ja/web/": [82180, "ui-gdpr-ja-web"],
                    "./ko/web/": [29013, "ui-gdpr-ko-web"],
                    "./lt/web/": [41799, "ui-gdpr-lt-web"],
                    "./lv/web/": [54108, "ui-gdpr-lv-web"],
                    "./mk-MK/web/": [76499, "ui-gdpr-mk-MK-web"],
                    "./ms/web/": [67338, "ui-gdpr-ms-web"],
                    "./nl-BE/web/": [13894, "ui-gdpr-nl-BE-web"],
                    "./nl/web/": [36724, "ui-gdpr-nl-web"],
                    "./no/web/": [45920, "ui-gdpr-no-web"],
                    "./pl/web/": [46729, "ui-gdpr-pl-web"],
                    "./pt-BR/web/": [12317, "ui-gdpr-pt-BR-web"],
                    "./pt/web/": [51750, "ui-gdpr-pt-web"],
                    "./ro/web/": [35086, "ui-gdpr-ro-web"],
                    "./ru/web/": [82724, "ui-gdpr-ru-web"],
                    "./sk/web/": [84643, "ui-gdpr-sk-web"],
                    "./sl/web/": [20455, "ui-gdpr-sl-web"],
                    "./sr/web/": [53951, "ui-gdpr-sr-web"],
                    "./sv/web/": [32557, "ui-gdpr-sv-web"],
                    "./sw/web/": [40420, "ui-gdpr-sw-web"],
                    "./th/web/": [54343, "ui-gdpr-th-web"],
                    "./tr/web/": [59878, "ui-gdpr-tr-web"],
                    "./uk/web/": [99658, "ui-gdpr-uk-web"],
                    "./vi/web/": [19287, "ui-gdpr-vi-web"],
                    "./zh-CN/web/": [82281, "ui-gdpr-zh-CN-web"],
                    "./zh-TW/web/": [65985, "ui-gdpr-zh-TW-web"]
                };

                function n(e) {
                    if (!s.o(i, e)) return Promise.resolve().then((function() {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }));
                    var t = i[e],
                        n = t[0];
                    return s.e(t[1]).then((function() {
                        return s(n)
                    }))
                }
                n.keys = function() {
                    return Object.keys(i)
                }, n.id = 4848, e.exports = n
            },
            15861: function(e, t, s) {
                "use strict";

                function i(e, t, s, i, n, r, o) {
                    try {
                        var a = e[r](o),
                            u = a.value
                    } catch (e) {
                        return void s(e)
                    }
                    a.done ? t(u) : Promise.resolve(u).then(i, n)
                }

                function n(e) {
                    return function() {
                        var t = this,
                            s = arguments;
                        return new Promise((function(n, r) {
                            var o = e.apply(t, s);

                            function a(e) {
                                i(o, n, r, a, u, "next", e)
                            }

                            function u(e) {
                                i(o, n, r, a, u, "throw", e)
                            }
                            a(void 0)
                        }))
                    }
                }
                s.d(t, {
                    Z: function() {
                        return n
                    }
                })
            },
            87462: function(e, t, s) {
                "use strict";

                function i() {
                    return i = Object.assign ? Object.assign.bind() : function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var s = arguments[t];
                            for (var i in s) Object.prototype.hasOwnProperty.call(s, i) && (e[i] = s[i])
                        }
                        return e
                    }, i.apply(this, arguments)
                }
                s.d(t, {
                    Z: function() {
                        return i
                    }
                })
            },
            63366: function(e, t, s) {
                "use strict";

                function i(e, t) {
                    if (null == e) return {};
                    var s, i, n = {},
                        r = Object.keys(e);
                    for (i = 0; i < r.length; i++) s = r[i], t.indexOf(s) >= 0 || (n[s] = e[s]);
                    return n
                }
                s.d(t, {
                    Z: function() {
                        return i
                    }
                })
            },
            43427: function(e, t, s) {
                "use strict";
                s.d(t, {
                    DS: function() {
                        return j
                    }
                });
                var i, n = "3.7.5",
                    r = n,
                    o = "function" == typeof atob,
                    a = "function" == typeof btoa,
                    u = "function" == typeof Buffer,
                    d = "function" == typeof TextDecoder ? new TextDecoder : void 0,
                    l = "function" == typeof TextEncoder ? new TextEncoder : void 0,
                    p = Array.prototype.slice.call("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="),
                    c = (i = {}, p.forEach(((e, t) => i[e] = t)), i),
                    f = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/,
                    v = String.fromCharCode.bind(String),
                    h = "function" == typeof Uint8Array.from ? Uint8Array.from.bind(Uint8Array) : e => new Uint8Array(Array.prototype.slice.call(e, 0)),
                    g = e => e.replace(/=/g, "").replace(/[+\/]/g, (e => "+" == e ? "-" : "_")),
                    m = e => e.replace(/[^A-Za-z0-9\+\/]/g, ""),
                    b = e => {
                        for (var t, s, i, n, r = "", o = e.length % 3, a = 0; a < e.length;) {
                            if ((s = e.charCodeAt(a++)) > 255 || (i = e.charCodeAt(a++)) > 255 || (n = e.charCodeAt(a++)) > 255) throw new TypeError("invalid character found");
                            r += p[(t = s << 16 | i << 8 | n) >> 18 & 63] + p[t >> 12 & 63] + p[t >> 6 & 63] + p[63 & t]
                        }
                        return o ? r.slice(0, o - 3) + "===".substring(o) : r
                    },
                    S = a ? e => btoa(e) : u ? e => Buffer.from(e, "binary").toString("base64") : b,
                    C = u ? e => Buffer.from(e).toString("base64") : e => {
                        for (var t = [], s = 0, i = e.length; s < i; s += 4096) t.push(v.apply(null, e.subarray(s, s + 4096)));
                        return S(t.join(""))
                    },
                    y = function(e, t) {
                        return void 0 === t && (t = !1), t ? g(C(e)) : C(e)
                    },
                    w = e => {
                        if (e.length < 2) return (t = e.charCodeAt(0)) < 128 ? e : t < 2048 ? v(192 | t >>> 6) + v(128 | 63 & t) : v(224 | t >>> 12 & 15) + v(128 | t >>> 6 & 63) + v(128 | 63 & t);
                        var t = 65536 + 1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320);
                        return v(240 | t >>> 18 & 7) + v(128 | t >>> 12 & 63) + v(128 | t >>> 6 & 63) + v(128 | 63 & t)
                    },
                    I = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g,
                    _ = e => e.replace(I, w),
                    P = u ? e => Buffer.from(e, "utf8").toString("base64") : l ? e => C(l.encode(e)) : e => S(_(e)),
                    A = function(e, t) {
                        return void 0 === t && (t = !1), t ? g(P(e)) : P(e)
                    },
                    k = e => A(e, !0),
                    T = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g,
                    E = e => {
                        switch (e.length) {
                            case 4:
                                var t = ((7 & e.charCodeAt(0)) << 18 | (63 & e.charCodeAt(1)) << 12 | (63 & e.charCodeAt(2)) << 6 | 63 & e.charCodeAt(3)) - 65536;
                                return v(55296 + (t >>> 10)) + v(56320 + (1023 & t));
                            case 3:
                                return v((15 & e.charCodeAt(0)) << 12 | (63 & e.charCodeAt(1)) << 6 | 63 & e.charCodeAt(2));
                            default:
                                return v((31 & e.charCodeAt(0)) << 6 | 63 & e.charCodeAt(1))
                        }
                    },
                    L = e => e.replace(T, E),
                    U = e => {
                        if (e = e.replace(/\s+/g, ""), !f.test(e)) throw new TypeError("malformed base64.");
                        e += "==".slice(2 - (3 & e.length));
                        for (var t, s, i, n = "", r = 0; r < e.length;) t = c[e.charAt(r++)] << 18 | c[e.charAt(r++)] << 12 | (s = c[e.charAt(r++)]) << 6 | (i = c[e.charAt(r++)]), n += 64 === s ? v(t >> 16 & 255) : 64 === i ? v(t >> 16 & 255, t >> 8 & 255) : v(t >> 16 & 255, t >> 8 & 255, 255 & t);
                        return n
                    },
                    O = o ? e => atob(m(e)) : u ? e => Buffer.from(e, "base64").toString("binary") : U,
                    x = u ? e => h(Buffer.from(e, "base64")) : e => h(O(e).split("").map((e => e.charCodeAt(0)))),
                    D = e => x(R(e)),
                    V = u ? e => Buffer.from(e, "base64").toString("utf8") : d ? e => d.decode(x(e)) : e => L(O(e)),
                    R = e => m(e.replace(/[-_]/g, (e => "-" == e ? "+" : "/"))),
                    N = e => V(R(e)),
                    F = e => ({
                        value: e,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0
                    }),
                    B = function() {
                        var e = (e, t) => Object.defineProperty(String.prototype, e, F(t));
                        e("fromBase64", (function() {
                            return N(this)
                        })), e("toBase64", (function(e) {
                            return A(this, e)
                        })), e("toBase64URI", (function() {
                            return A(this, !0)
                        })), e("toBase64URL", (function() {
                            return A(this, !0)
                        })), e("toUint8Array", (function() {
                            return D(this)
                        }))
                    },
                    M = function() {
                        var e = (e, t) => Object.defineProperty(Uint8Array.prototype, e, F(t));
                        e("toBase64", (function(e) {
                            return y(this, e)
                        })), e("toBase64URI", (function() {
                            return y(this, !0)
                        })), e("toBase64URL", (function() {
                            return y(this, !0)
                        }))
                    },
                    j = {
                        version: n,
                        VERSION: r,
                        atob: O,
                        atobPolyfill: U,
                        btoa: S,
                        btoaPolyfill: b,
                        fromBase64: N,
                        toBase64: A,
                        encode: A,
                        encodeURI: k,
                        encodeURL: k,
                        utob: _,
                        btou: L,
                        decode: N,
                        isValid: e => {
                            if ("string" != typeof e) return !1;
                            var t = e.replace(/\s+/g, "").replace(/={0,2}$/, "");
                            return !/[^\s0-9a-zA-Z\+/]/.test(t) || !/[^\s0-9a-zA-Z\-_]/.test(t)
                        },
                        fromUint8Array: y,
                        toUint8Array: D,
                        extendString: B,
                        extendUint8Array: M,
                        extendBuiltins: () => {
                            B(), M()
                        }
                    }
            }
        },
        r = {};

    function o(e) {
        var t = r[e];
        if (void 0 !== t) return t.exports;
        var s = r[e] = {
            id: e,
            loaded: !1,
            exports: {}
        };
        return n[e].call(s.exports, s, s.exports, o), s.loaded = !0, s.exports
    }
    o.m = n, o.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return o.d(t, {
                a: t
            }), t
        }, t = Object.getPrototypeOf ? function(e) {
            return Object.getPrototypeOf(e)
        } : function(e) {
            return e.__proto__
        }, o.t = function(s, i) {
            if (1 & i && (s = this(s)), 8 & i) return s;
            if ("object" == typeof s && s) {
                if (4 & i && s.__esModule) return s;
                if (16 & i && "function" == typeof s.then) return s
            }
            var n = Object.create(null);
            o.r(n);
            var r = {};
            e = e || [null, t({}), t([]), t(t)];
            for (var a = 2 & i && s;
                "object" == typeof a && !~e.indexOf(a); a = t(a)) Object.getOwnPropertyNames(a).forEach((function(e) {
                r[e] = function() {
                    return s[e]
                }
            }));
            return r.default = function() {
                return s
            }, o.d(n, r), n
        }, o.d = function(e, t) {
            for (var s in t) o.o(t, s) && !o.o(e, s) && Object.defineProperty(e, s, {
                enumerable: !0,
                get: t[s]
            })
        }, o.f = {}, o.e = function(e) {
            return Promise.all(Object.keys(o.f).reduce((function(t, s) {
                return o.f[s](e, t), t
            }), []))
        }, o.u = function(e) {
            return e + ".7e0e4e88d0225db89a578b31aa627050b4ce1e0d.js"
        }, o.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")()
            } catch (e) {
                if ("object" == typeof window) return window
            }
        }(), o.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, s = {}, i = "Didomi:", o.l = function(e, t, n, r) {
            if (s[e]) s[e].push(t);
            else {
                var a, u;
                if (void 0 !== n)
                    for (var d = document.getElementsByTagName("script"), l = 0; l < d.length; l++) {
                        var p = d[l];
                        if (p.getAttribute("src") == e || p.getAttribute("data-webpack") == i + n) {
                            a = p;
                            break
                        }
                    }
                a || (u = !0, (a = document.createElement("script")).charset = "utf-8", a.timeout = 120, o.nc && a.setAttribute("nonce", o.nc), a.setAttribute("data-webpack", i + n), a.src = e), s[e] = [t];
                var c = function(t, i) {
                        a.onerror = a.onload = null, clearTimeout(f);
                        var n = s[e];
                        if (delete s[e], a.parentNode && a.parentNode.removeChild(a), n && n.forEach((function(e) {
                                return e(i)
                            })), t) return t(i)
                    },
                    f = setTimeout(c.bind(null, void 0, {
                        type: "timeout",
                        target: a
                    }), 12e4);
                a.onerror = c.bind(null, a.onerror), a.onload = c.bind(null, a.onload), u && document.head.appendChild(a)
            }
        }, o.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        }, o.nmd = function(e) {
            return e.paths = [], e.children || (e.children = []), e
        }, o.p = "https://sdk.privacy-center.org/sdk/7e0e4e88d0225db89a578b31aa627050b4ce1e0d/modern/",
        function() {
            var e = {
                main: 0
            };
            o.f.j = function(t, s) {
                var i = o.o(e, t) ? e[t] : void 0;
                if (0 !== i)
                    if (i) s.push(i[2]);
                    else {
                        var n = new Promise((function(s, n) {
                            i = e[t] = [s, n]
                        }));
                        s.push(i[2] = n);
                        var r = o.p + o.u(t),
                            a = new Error;
                        o.l(r, (function(s) {
                            if (o.o(e, t) && (0 !== (i = e[t]) && (e[t] = void 0), i)) {
                                var n = s && ("load" === s.type ? "missing" : s.type),
                                    r = s && s.target && s.target.src;
                                a.message = "Loading chunk " + t + " failed.\n(" + n + ": " + r + ")", a.name = "ChunkLoadError", a.type = n, a.request = r, i[1](a)
                            }
                        }), "chunk-" + t, t)
                    }
            };
            var t = function(t, s) {
                    var i, n, r = s[0],
                        a = s[1],
                        u = s[2],
                        d = 0;
                    if (r.some((function(t) {
                            return 0 !== e[t]
                        }))) {
                        for (i in a) o.o(a, i) && (o.m[i] = a[i]);
                        if (u) u(o)
                    }
                    for (t && t(s); d < r.length; d++) n = r[d], o.o(e, n) && e[n] && e[n][0](), e[n] = 0
                },
                s = self.webpackChunkDidomi = self.webpackChunkDidomi || [];
            s.forEach(t.bind(null, 0)), s.push = t.bind(null, s.push.bind(s))
        }();
    var a = {};
    ! function() {
        "use strict";
        o.d(a, {
            default: function() {
                return Us
            }
        });
        var e = o(87462),
            t = setTimeout;

        function s() {}

        function i(e) {
            if (!(this instanceof i)) throw new TypeError("Promises must be constructed via new");
            if ("function" != typeof e) throw new TypeError("not a function");
            this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], p(e, this)
        }

        function n(e, t) {
            for (; 3 === e._state;) e = e._value;
            0 !== e._state ? (e._handled = !0, i._immediateFn((function() {
                var s = 1 === e._state ? t.onFulfilled : t.onRejected;
                if (null !== s) {
                    var i;
                    try {
                        i = s(e._value)
                    } catch (e) {
                        return void u(t.promise, e)
                    }
                    r(t.promise, i)
                } else(1 === e._state ? r : u)(t.promise, e._value)
            }))) : e._deferreds.push(t)
        }

        function r(e, t) {
            try {
                if (t === e) throw new TypeError("A promise cannot be resolved with itself.");
                if (t && ("object" == typeof t || "function" == typeof t)) {
                    var s = t.then;
                    if (t instanceof i) return e._state = 3, e._value = t, void d(e);
                    if ("function" == typeof s) return void p((n = s, r = t, function() {
                        n.apply(r, arguments)
                    }), e)
                }
                e._state = 1, e._value = t, d(e)
            } catch (t) {
                u(e, t)
            }
            var n, r
        }

        function u(e, t) {
            e._state = 2, e._value = t, d(e)
        }

        function d(e) {
            2 === e._state && 0 === e._deferreds.length && i._immediateFn((function() {
                e._handled || i._unhandledRejectionFn(e._value)
            }));
            for (var t = 0, s = e._deferreds.length; t < s; t++) n(e, e._deferreds[t]);
            e._deferreds = null
        }

        function l(e, t, s) {
            this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = s
        }

        function p(e, t) {
            var s = !1;
            try {
                e((function(e) {
                    s || (s = !0, r(t, e))
                }), (function(e) {
                    s || (s = !0, u(t, e))
                }))
            } catch (e) {
                if (s) return;
                s = !0, u(t, e)
            }
        }
        i.prototype.catch = function(e) {
            return this.then(null, e)
        }, i.prototype.then = function(e, t) {
            var i = new this.constructor(s);
            return n(this, new l(e, t, i)), i
        }, i.prototype.finally = function(e) {
            var t = this.constructor;
            return this.then((function(s) {
                return t.resolve(e()).then((function() {
                    return s
                }))
            }), (function(s) {
                return t.resolve(e()).then((function() {
                    return t.reject(s)
                }))
            }))
        }, i.all = function(e) {
            return new i((function(t, s) {
                if (!e || void 0 === e.length) throw new TypeError("Promise.all accepts an array");
                var i = Array.prototype.slice.call(e);
                if (0 === i.length) return t([]);
                var n = i.length;

                function r(e, o) {
                    try {
                        if (o && ("object" == typeof o || "function" == typeof o)) {
                            var a = o.then;
                            if ("function" == typeof a) return void a.call(o, (function(t) {
                                r(e, t)
                            }), s)
                        }
                        i[e] = o, 0 == --n && t(i)
                    } catch (e) {
                        s(e)
                    }
                }
                for (var o = 0; o < i.length; o++) r(o, i[o])
            }))
        }, i.resolve = function(e) {
            return e && "object" == typeof e && e.constructor === i ? e : new i((function(t) {
                t(e)
            }))
        }, i.reject = function(e) {
            return new i((function(t, s) {
                s(e)
            }))
        }, i.race = function(e) {
            return new i((function(t, s) {
                for (var i = 0, n = e.length; i < n; i++) e[i].then(t, s)
            }))
        }, i._immediateFn = "function" == typeof setImmediate && function(e) {
            setImmediate(e)
        } || function(e) {
            t(e, 0)
        }, i._unhandledRejectionFn = function(e) {
            "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", e)
        };
        var c = i,
            f = function() {
                if ("undefined" != typeof self) return self;
                if ("undefined" != typeof window) return window;
                if (void 0 !== o.g) return o.g;
                throw new Error("unable to locate global object")
            }();
        f.Promise || (f.Promise = c);
        var v = o(16148),
            h = o(26926),
            g = o(72424),
            m = ["notice.enable", "notice.showDataProcessing", "experiment.group", "app.vendors.iab.version", "app.alwaysDisplayActionButtons", "user.externalConsent.value", "sync.enabled"],
            b = () => {
                var e = "didomiConfig",
                    t = window.location.href;
                if (!t.includes(e)) return null;
                var s, i = (0, g.vl)(t, e),
                    n = {};
                if (i.hasOwnProperty(e)) try {
                    n = JSON.parse(i[e])
                } catch (t) {
                    console.error('Didomi - Invalid JSON from query-string parameter "' + e + '": ' + t.message)
                }
                for (var r in i)
                    if (r.startsWith(e + ".") && !r.includes("__proto__") && !r.includes("constructor")) try {
                        var o = JSON.parse(i[r]);
                        (0, h.t8)(n, r.replace(e + ".", ""), o)
                    } catch (t) {
                        var a = i[r];
                        (0, h.t8)(n, r.replace(e + ".", ""), a)
                    }
                return s = n, m.reduce(((e, t) => {
                    var i = (0, h.U2)(s, t);
                    return void 0 !== i && (e = e || {}, (0, h.t8)(e, t, i)), e
                }), null)
            },
            S = o(28854),
            C = o(35618),
            y = (0, C.td)(null),
            w = e => {
                y.value = e
            },
            I = () => {
                var e, t = {};
                null != S.q && S.q.config && "object" == typeof(null == S.q ? void 0 : S.q.config) && (0, h.ZB)(t, S.q.config), window.didomiConfig && "object" == typeof window.didomiConfig && (0, h.ZB)(t, window.didomiConfig);
                var s, i, n = b();
                (n && (0, h.ZB)(t, n), null != (e = t) && e.notice) && (void 0 === (null == (s = t) || null == (i = s.notice) ? void 0 : i.showWhenGPCIsEnabled) && (0, h.t8)(t, "notice.showWhenGPCIsEnabled", !0));
                var r = (e => {
                    var t;
                    if ("object" == typeof(null == e ? void 0 : e.configByCountry) && null != (t = y.value) && t.country) {
                        var s, i = null == e ? void 0 : e.configByCountry[null == (s = y.value) ? void 0 : s.country.toUpperCase()];
                        if (i) return i
                    }
                })(t);
                r && (t = (0, h.ZB)(t, r));
                var o = (e => {
                    var t;
                    if (null == e ? void 0 : e.version) return null == e || null == (t = e.regulation) ? void 0 : t.name;
                    var s, i, n, r, o, a, u, d, l, p = (null == e ? void 0 : e.regulations) || (null == e || null == (s = e.website) ? void 0 : s.regulations) || (null == e || null == (i = e.app) ? void 0 : i.regulations) || {},
                        c = (null == (n = p.gdpr) ? void 0 : n.additionalCountries) || [],
                        f = Array.isArray(window.didomiGeoRegulations) ? window.didomiGeoRegulations : [],
                        v = "US" === (null == (r = y.value) ? void 0 : r.country) && "CA" === (null == (o = y.value) ? void 0 : o.region),
                        h = !(null == p || null == (a = p.ccpa) || !a.enabled),
                        g = !!p && (null == (u = window) ? void 0 : u.gdprAppliesGlobally) || (null == c ? void 0 : c.includes(null == (d = y.value) ? void 0 : d.country)) || (null == f ? void 0 : f.includes("gdpr")),
                        m = !!p && !!window.gdprAppliesGlobally || !(null == p || null == (l = p.gdpr) || !l.enabled);
                    return v && h ? "ccpa" : g && m ? "gdpr" : null
                })(t);
                return o && (0, h.t8)(t, "regulation.name", o), t
            },
            _ = o(54912),
            P = o(59303);

        function A(e, t) {
            try {
                return performance.mark("didomi:" + e, t)
            } catch (e) {}
        }
        var k = o(58027),
            T = o(86119),
            E = o(24961);
        class L {
            constructor(e) {
                this.parameters = {
                    filters: (0, h.U2)(e, "filters", []),
                    first: (0, h.U2)(e, "first", !1),
                    distinctUntilChanged: (0, h.U2)(e, "distinctUntilChanged", !1),
                    currentValue: (0, h.U2)(e, "currentValue"),
                    hasCurrentValue: (0, h.U2)(e, "hasCurrentValue", !1)
                }, this.subscribers = []
            }
            clone(e) {
                var t = new L(e);
                return this.subscribe(t.next.bind(t)), t
            }
            distinctUntilChanged() {
                return this.clone((0, e.Z)({}, this.parameters, {
                    distinctUntilChanged: !0
                }))
            }
            filter(t) {
                if ("function" != typeof t) throw new Error("You must pass a Function to filter an observable");
                return this.clone((0, e.Z)({}, this.parameters, {
                    filters: [...this.parameters.filters, t]
                }))
            }
            first() {
                return this.clone((0, e.Z)({}, this.parameters, {
                    first: !0
                }))
            }
            subscribe(e) {
                if ("function" != typeof e) throw new Error("You must pass a Function to subscribe to an observable");
                var t = this,
                    s = function s(i) {
                        e(i), !0 === t.parameters.first && s.unsubscribe()
                    };
                return s.unsubscribe = function() {
                    var e = t.subscribers.indexOf(s); - 1 !== e && t.subscribers.splice(e, 1)
                }, this.subscribers.push(s), s
            }
            next(e) {
                for (var t of this.parameters.filters)
                    if (!0 !== t(e)) return;
                if (!0 !== this.parameters.distinctUntilChanged || !0 !== this.parameters.hasCurrentValue || e !== this.parameters.currentValue) {
                    for (var s of this.subscribers) s(e);
                    this.parameters.currentValue = e, this.parameters.hasCurrentValue = !0
                }
            }
        }
        class U extends L {
            constructor(t, s) {
                super((0, e.Z)({}, t, {
                    currentValue: s,
                    hasCurrentValue: !0
                }))
            }
            clone(e) {
                var t = new U(e, this.parameters.currentValue);
                return this.subscribe(t.next.bind(t)), t
            }
            getValue() {
                return this.parameters.currentValue
            }
            subscribe(e) {
                var t = super.subscribe(e);
                for (var s of this.parameters.filters)
                    if (!0 !== s(this.parameters.currentValue)) return;
                t(this.parameters.currentValue)
            }
        }
        var O = o(91604),
            x = o(16619),
            D = o(14119),
            V = o(78461),
            R = o(4108),
            N = o(63205),
            F = (0, C.Fl)((() => {
                var e, t = null == (e = v.noticeConfig.value) ? void 0 : e.hooks;
                return t && "object" == typeof t.functions ? t.functions : null
            })),
            B = function(e, t) {
                return void 0 === t && (t = void 0), F.value && F.value[e] && "function" == typeof F.value[e] ? F.value[e] : t
            },
            M = o(23605),
            j = o(23721),
            z = o(3370),
            Z = o(95071),
            G = o(25010),
            q = o(92171);
        class H extends O.Z {
            getUserConsentTokenDeprecated() {
                return (0, T.CWTFromCompressedJSON)(JSON.stringify(this.services.StorageService.getTokenFromLocalStore()))
            }
            getUserConsentStatusForAll() {
                var e = this.services.StorageService.getTokenFromLocalStore(),
                    t = e.purposes.enabled || [],
                    s = e.purposes.disabled || [];
                return {
                    purposes: {
                        enabled: [...t, ...G.P.value],
                        disabled: [...s]
                    },
                    vendors: {
                        enabled: [...e.vendors.enabled || []],
                        disabled: [...e.vendors.disabled || []]
                    }
                }
            }
            getUserConsentStatus(e, t) {
                var s, i, n, r;
                t = parseInt(t, 10) || t;
                var o = this.services.StorageService.getTokenFromLocalStore(),
                    a = (null == (s = o.purposes) ? void 0 : s.enabled) || [],
                    u = (null == (i = o.purposes) ? void 0 : i.disabled) || [],
                    d = G.P.value,
                    l = (null == (n = o.vendors) ? void 0 : n.enabled) || [],
                    p = (null == (r = o.vendors) ? void 0 : r.disabled) || [];
                return -1 !== d.indexOf(e) && -1 !== l.indexOf(t) || (-1 !== a.indexOf(e) && -1 !== l.indexOf(t) || (-1 === d.indexOf(e) && -1 === a.indexOf(e) && -1 === u.indexOf(e) || -1 === l.indexOf(t) && -1 === p.indexOf(t)) && void 0)
            }
            hasAllConsentStatus(e, t) {
                var s = [];
                for (var i of e) "consent" === i.legalBasis ? s.push(this.getUserConsentStatusByPurpose(i.id)) : "legitimate_interest" === i.legalBasis && s.push(this.getLegitimateInterestStatusForPurpose(i.id));
                for (var n of t) Array.isArray(n.purposeIds) && n.purposeIds.length > 0 && s.push(this.getUserConsentStatusByVendor(n.id)), Array.isArray(n.legIntPurposeIds) && n.legIntPurposeIds.length > 0 && s.push(this.getLegitimateInterestStatusForVendor(n.id));
                return !1 === s.some((e => void 0 === e))
            }
            hasAnyConsentStatus() {
                var e, t, s, i, n = this.services.StorageService.getTokenFromLocalStore(),
                    r = (null == (e = n.purposes) ? void 0 : e.enabled) || [],
                    o = (null == (t = n.purposes) ? void 0 : t.disabled) || [],
                    a = (null == (s = n.vendors) ? void 0 : s.enabled) || [],
                    u = (null == (i = n.vendors) ? void 0 : i.disabled) || [];
                return r.length > 0 || o.length > 0 || a.length > 0 || u.length > 0
            }
            hasAnyLegitimateInterestStatus() {
                var e, t, s, i, n = this.services.StorageService.getTokenFromLocalStore(),
                    r = (null == (e = n.purposes_li) ? void 0 : e.enabled) || [],
                    o = (null == (t = n.purposes_li) ? void 0 : t.disabled) || [],
                    a = (null == (s = n.vendors_li) ? void 0 : s.enabled) || [],
                    u = (null == (i = n.vendors_li) ? void 0 : i.disabled) || [];
                return r.length > 0 || o.length > 0 || a.length > 0 || u.length > 0
            }
            hasAnyStatus() {
                return this.hasAnyConsentStatus() || this.hasAnyLegitimateInterestStatus()
            }
            getUserConsentStatusForAllPurposesByVendor(e) {
                e = parseInt(e, 10) || e;
                var t = (0, h.U2)(this.store.getState(), "consentByVendor." + e + ".consentToAllPurposes");
                if ("boolean" == typeof t) return t
            }
            getObservableOnUserConsentStatusForAllPurposesByVendor(e) {
                var t = new U(null, this.getUserConsentStatusForAllPurposesByVendor(e)),
                    s = (0, N.xS)();
                return s >= (0, N.hS)() && (0, N.Wp)(s + 1), (0, N.on)("internal.consent.changed", (() => {
                    t.next(this.getUserConsentStatusForAllPurposesByVendor(e))
                })), t.distinctUntilChanged()
            }
            getLegitimateInterestStatusForVendor(e) {
                var t, s;
                e = parseInt(e, 10) || e;
                var i = this.services.StorageService.getTokenFromLocalStore(),
                    n = (null == (t = i.vendors_li) ? void 0 : t.enabled) || [],
                    r = (null == (s = i.vendors_li) ? void 0 : s.disabled) || [];
                return -1 !== n.indexOf(e) || -1 === r.indexOf(e) && void 0
            }
            getUserStatusForVendor(e) {
                var t, s = null == (t = z.I.value) ? void 0 : t[e];
                if (s) {
                    var i = !0,
                        n = !0;
                    return Array.isArray(s.legIntPurposeIds) && s.legIntPurposeIds.length > 0 && (i = this.getLegitimateInterestStatusForVendor(s.id)), Array.isArray(s.purposeIds) && s.purposeIds.length > 0 && (n = this.getUserConsentStatusByVendor(s.id)), "1.0.0" === (0, v.getNoticeConfigValue)("version") && (0, R.T5)(this.store.getState()) ? i : i && n
                }
            }
            getUserStatusForVendorAndLinkedPurposes(e) {
                var t, s = null == (t = z.I.value) ? void 0 : t[e],
                    i = B("isVendorEnabled");
                if (i) {
                    var n, r, o, a, u = this.services.StorageService.getTokenFromLocalStore();
                    return i({
                        vendor: s,
                        enabledPurposes: null == (n = u.purposes) ? void 0 : n.enabled,
                        disabledPurposes: null == (r = u.purposes) ? void 0 : r.disabled,
                        enabledVendors: null == (o = u.vendors) ? void 0 : o.enabled,
                        disabledVendors: null == (a = u.vendors) ? void 0 : a.disabled
                    })
                }
                if (s) {
                    var d = !0,
                        l = !0;
                    return Array.isArray(s.legIntPurposeIds) && s.legIntPurposeIds.length > 0 && (d = s.legIntPurposeIds.reduce(((e, t) => !1 === e ? e : this.getLegitimateInterestStatusForPurpose(t)), !0)), Array.isArray(s.purposeIds) && s.purposeIds.length > 0 && (l = s.purposeIds.reduce(((e, t) => !1 === e ? e : this.getUserConsentStatusByPurpose(t)), !0)), this.getUserStatusForVendor(e) && d && l
                }
            }
            getUserConsentStatusByVendor(e) {
                var t, s;
                e = parseInt(e, 10) || e;
                var i = this.services.StorageService.getTokenFromLocalStore(),
                    n = (null == (t = i.vendors) ? void 0 : t.enabled) || [],
                    r = (null == (s = i.vendors) ? void 0 : s.disabled) || [];
                return -1 !== n.indexOf(e) || -1 === r.indexOf(e) && void 0
            }
            getUserConsentStatusByPurpose(e) {
                var t, s, i = this.services.StorageService.getTokenFromLocalStore(),
                    n = (null == (t = i.purposes) ? void 0 : t.enabled) || [],
                    r = (null == (s = i.purposes) ? void 0 : s.disabled) || [];
                return -1 !== G.P.value.indexOf(e) || (-1 !== n.indexOf(e) || -1 === r.indexOf(e) && void 0)
            }
            getLegitimateInterestStatusForPurpose(e) {
                var t, s, i = this.services.StorageService.getTokenFromLocalStore(),
                    n = (null == (t = i.purposes_li) ? void 0 : t.enabled) || [],
                    r = (null == (s = i.purposes_li) ? void 0 : s.disabled) || [];
                return -1 !== G.P.value.indexOf(e) || (-1 !== n.indexOf(e) || -1 === r.indexOf(e) && void 0)
            }
            getUndefinedPurposes() {
                var e, t, s, i = this.services.StorageService.getTokenFromLocalStore(),
                    n = [...null == (e = i.purposes) ? void 0 : e.enabled, ...null == (t = i.purposes) ? void 0 : t.disabled];
                return null == (s = q.s.value) ? void 0 : s.filter((e => -1 === n.indexOf(e)))
            }
            getCommonConsentStatus(e, t) {
                if (0 !== t.length) {
                    var s = this.getUserConsentStatus(e, t[0].id);
                    for (var i of t.slice(1)) {
                        if (s !== this.getUserConsentStatus(e, i.id)) return
                    }
                    return s
                }
            }
            setUserConsentStatusDeprecated(e, t, s) {
                t = Array.isArray(t) ? t : [t], s = Array.isArray(s) ? s : [s];
                var i = new E.Z(this.getUserStatus.bind(this), this.setUserStatus.bind(this));
                !0 === e ? (i.enablePurposes(...t), i.enableVendors(...s)) : (i.enablePurposes(...this.getUndefinedPurposes()), i.disableVendors(...s)), i.commit(), this.services.NoticeService.hide()
            }
            setUserConsentStatus(e, t, s, i, n, r, o, a, u, d, l) {
                void 0 === e && (e = []), void 0 === t && (t = []), void 0 === s && (s = []), void 0 === i && (i = []), void 0 === n && (n = []), void 0 === r && (r = []), void 0 === o && (o = []), void 0 === a && (a = []), e = Array.isArray(e) ? e : [e], t = Array.isArray(t) ? t : [t], s = Array.isArray(s) ? s : [s], i = Array.isArray(i) ? i : [i], s = s.filter((e => {
                    var t, s = null == (t = z.I.value) ? void 0 : t[e];
                    return !s || s.purposeIds.length > 0
                }));
                var p = this.services.StorageService.getTokenFromLocalStore(),
                    c = (0, h.I8)(p),
                    f = G.P.value,
                    v = e => -1 === f.indexOf(e);
                c.vendors = {
                    enabled: s,
                    disabled: i
                }, c.purposes = {
                    enabled: e.filter(v),
                    disabled: t.filter(v)
                }, c.version = M.t.defaultTCFVersion, c.vendors_li = {
                    enabled: o,
                    disabled: a
                }, c.purposes_li = {
                    enabled: n.filter(v),
                    disabled: r.filter(v)
                }, u && (c.created = u), d && (c.updated = d);
                var g = !!u || !!d;
                (0, h.vZ)(p, c) && !(0, D.s_)(this.store.getState()) || (c = this.services.StorageService.setTokenToStorages(c, !g), this.sendEvents(c, !1, l)), this.removeScrollListener(window.scrollListener)
            }
            sendEvents(e, t, s) {
                void 0 === t && (t = !1);
                var {
                    purposes: i,
                    purposes_li: n,
                    vendors: r,
                    vendors_li: o,
                    created: a,
                    updated: u,
                    dns: d
                } = e;
                "sync" !== s && this.services.EventsService.sendConsentGiven({
                    purposes: i,
                    vendors: r,
                    created: a,
                    updated: u,
                    dns: !0 === d || void 0,
                    from_euconsent: t,
                    action: "string" == typeof s ? s : void 0,
                    purposes_li: n,
                    vendors_li: o
                }, "navigate" === s), (0, N.j8)("internal.consent.changed"), (0, N.j8)("consent.changed", {
                    consentToken: this.getUserConsentTokenDeprecated(),
                    fromEUConsent: t,
                    action: s
                }), this.setBrowserCookieState(e.purposes.enabled)
            }
            removeScrollListener(e) {
                "function" == typeof e && -1 !== String(e).indexOf("Didomi.setUserAgreeToAll()") && window.removeEventListener("scroll", e)
            }
            setBrowserCookieState(e) {
                e.some((e => 0 === e.indexOf("cookies"))) && this.services.CookiesService.enable()
            }
            getUserStatus() {
                return (0, h.I8)((0, V.Tq)(this.store.getState()))
            }
            setUserStatusForAll(e) {
                var {
                    purposesConsentStatus: t,
                    purposesLIStatus: s,
                    vendorsConsentStatus: i,
                    vendorsLIStatus: n,
                    created: r,
                    updated: o,
                    action: a
                } = e, u = this.store.getState(), d = G.P.value, l = (0, R.wG)(u), p = (0, R.bh)(u), c = Z.O.value;
                if (0 !== [...l, ...j.V.value].length && 0 !== c.length || 0 !== d.length) {
                    var f = {};
                    t ? ((0, h.t8)(f, "purposes.consent.enabled", l), (0, h.t8)(f, "purposes.consent.disabled", [])) : ((0, h.t8)(f, "purposes.consent.enabled", []), (0, h.t8)(f, "purposes.consent.disabled", l)), s ? ((0, h.t8)(f, "purposes.legitimate_interest.enabled", p), (0, h.t8)(f, "purposes.legitimate_interest.disabled", [])) : ((0, h.t8)(f, "purposes.legitimate_interest.enabled", []), (0, h.t8)(f, "purposes.legitimate_interest.disabled", p)), i ? ((0, h.t8)(f, "vendors.consent.enabled", c), (0, h.t8)(f, "vendors.consent.disabled", [])) : ((0, h.t8)(f, "vendors.consent.enabled", []), (0, h.t8)(f, "vendors.consent.disabled", c)), n ? ((0, h.t8)(f, "vendors.legitimate_interest.enabled", j.V.value), (0, h.t8)(f, "vendors.legitimate_interest.disabled", [])) : ((0, h.t8)(f, "vendors.legitimate_interest.enabled", []), (0, h.t8)(f, "vendors.legitimate_interest.disabled", j.V.value)), (0, h.t8)(f, "created", r), (0, h.t8)(f, "updated", o), (0, h.t8)(f, "action", a), this.setUserStatus(f)
                }
            }
            setUserStatus(e) {
                this.setUserConsentStatus((0, h.U2)(e, "purposes.consent.enabled", []), (0, h.U2)(e, "purposes.consent.disabled", []), (0, h.U2)(e, "vendors.consent.enabled", []), (0, h.U2)(e, "vendors.consent.disabled", []), (0, h.U2)(e, "purposes.legitimate_interest.enabled", []), (0, h.U2)(e, "purposes.legitimate_interest.disabled", []), (0, h.U2)(e, "vendors.legitimate_interest.enabled", []), (0, h.U2)(e, "vendors.legitimate_interest.disabled", []), (0, h.U2)(e, "created"), (0, h.U2)(e, "updated"), (0, h.U2)(e, "action")), this.services.WebsiteService.shouldConsentBeCollected() || this.services.NoticeService.hide()
            }
        }
        H.Purposes = x.o7, H.prototype.Purposes = x.o7;
        class W extends O.Z {
            getConsentStatusByCookieCategory(e) {
                if (!this.services.UserService.isConsentRequired()) return !0;
                var t = this.services.ConsentService.getUserConsentStatusByPurpose(e);
                return void 0 !== t ? t : !0 === this.services.ConsentService.getUserConsentStatusByPurpose("cookies")
            }
            getAllowedCategories() {
                var e = ["essential"];
                return this.getConsentStatusByCookieCategory("cookies_analytics") && e.push("analytics"), this.getConsentStatusByCookieCategory("cookies_marketing") && e.push("marketing"), this.getConsentStatusByCookieCategory("cookies_social") && e.push("social"), e
            }
            enable() {
                var e = this.getAllowedCategories();
                (0, N.j8)("cookies.enable", e)
            }
        }
        var K = o(49910),
            J = o(58946),
            Q = o(52649),
            $ = o(36660),
            Y = o(77122);
        class X extends O.Z {
            constructor(e, t, s) {
                super(e, t, s), this.sentEvents = {}
            }
            configure(e) {
                var t = {
                    sampleSizes: {}
                };
                e && e.source && (e.source.type && "string" == typeof e.source.type && (0, h.t8)(t, "template.source.type", e.source.type), e.source.domain && "string" == typeof e.source.domain && (0, h.t8)(t, "template.source.domain", e.source.domain));
                var s = (0, _.getSDKConfigValue)("events").sampleSizes;
                for (var i of Object.keys(s)) e && e.sampleSizes && "number" == typeof e.sampleSizes[i] ? t.sampleSizes[i] = e.sampleSizes[i] : t.sampleSizes[i] = s[i];
                this.actions.setEventsConfig(t), window.didomiEventListeners = window.didomiEventListeners || [], window.didomiEventListeners.push({
                    event: "preferences.shownpurposes",
                    listener: this.sendPreferencesPurposesShown.bind(this)
                }, {
                    event: "preferences.shownvendors",
                    listener: this.sendPreferencesVendorsShown.bind(this)
                }, {
                    event: "preferences.clickpurposeagree",
                    listener: this.sendPreferencesPurposeStatusChanged.bind(this)
                }, {
                    event: "preferences.clickpurposedisagree",
                    listener: this.sendPreferencesPurposeStatusChanged.bind(this)
                }, {
                    event: "preferences.clickvendoragree",
                    listener: this.sendPreferencesVendorStatusChanged.bind(this)
                }, {
                    event: "preferences.clickvendordisagree",
                    listener: this.sendPreferencesVendorStatusChanged.bind(this)
                }, {
                    event: "preferences.shownpersonaldatatypes",
                    listener: this.sendPreferencesShownPersonalDataTypes.bind(this)
                }, {
                    event: "preferences.clickspiagree",
                    listener: this.sendPreferencesSPIChanged.bind(this)
                }, {
                    event: "preferences.clickspidisagree",
                    listener: this.sendPreferencesSPIChanged.bind(this)
                })
            }
            customizeEvent(t, s) {
                var i, n, r, o, a, u, d, {
                        includeToken: l = !0,
                        includeUserId: p = !1,
                        organizationUserId: c = null,
                        authorizationParameters: f = {},
                        includeSignature: g = !1
                    } = void 0 === s ? {} : s,
                    m = this.store.getState();
                this.services.WebsiteService.getProviderKey() && (0, h.t8)(t, "source.provider", this.services.WebsiteService.getProviderKey()), J.q.value && (0, h.t8)(t, "source.key", J.q.value);
                var b = null == (i = y.value) ? void 0 : i.country;
                b && (0, h.t8)(t, "user.country", b);
                var S = null == (n = y.value) ? void 0 : n.region;
                S && (0, h.t8)(t, "user.region", S);
                var C = (0, h.U2)(t, "user.regs"),
                    w = C ? [...C] : [];
                "gdpr" === (null == (r = v.noticeConfig.value) || null == (o = r.regulation) ? void 0 : o.name) && w.push("gdpr"), "ccpa" === (null == (a = v.noticeConfig.value) || null == (u = a.regulation) ? void 0 : u.name) && w.push("ccpa"), (0, h.t8)(t, "user.regs", w);
                var I = this.services.StorageService.getTokenFromLocalStore();
                p && I.user_id && (0, h.t8)(t, "user.id", I.user_id), c && (0, h.t8)(t, "user.organization_user_id", c), (0, h.t8)(t, "user", (0, e.Z)({}, t.user, f)), l && I && Object.keys(I).length > 0 && ((0, h.t8)(t, "user.token", I), p || (0, h.t8)(t, "user.token.user_id", null));
                var _ = this.services.ExperimentsService.getCurrentExperiment();
                _ && (0, h.HD)(_.group) && (0, h.HD)(_.id) && (0, h.hj)(_.size) && (t.experiment = _), this.services.WebsiteService.isTCFEnabled() && ((0, h.t8)(t, "user.tcfcs", this.services.StorageService.getConsentStringFromLocalStore()), (0, h.t8)(t, "user.tcfv", Y.m.value.majorVersion));
                var P = (0, R.Ax)(m);
                P && (0, h.t8)(t, "source.deployment_id", P);
                var A = (0, R.Eh)(m);
                if (A && (0, h.t8)(t, "source.domain", A), g && null != (d = $.L.value) && d.signatureEnabled) {
                    var k = this.services.SignatureService.getSignatureParams();
                    k && ((0, h.t8)(t, "user.dcs", k.dcs), (0, h.t8)(t, "user.dcs_user", k.dcsUser))
                }
                return t
            }
            static isUUIDInSample(e, t) {
                return !(!e || 36 !== e.length || !t || "number" != typeof t || t < 0 || t > 1) && parseInt(e.slice(-2), 16) / 255 <= t
            }
            send(e, t, s, i, n) {
                if (void 0 === t && (t = null), void 0 === s && (s = null), void 0 === i && (i = !1), void 0 === n && (n = !0), -1 === (0, h.VO)(this.eventTypes).indexOf(e)) throw new Error("Invalid event type " + e);
                if ("number" == typeof s) {
                    if (!X.isUUIDInSample(this.services.UserService.getId(), s)) return null
                } else s = 1;
                var r = [],
                    o = [{
                        organizationUserId: this.services.UserService.getOrganizationUserId(),
                        authorizationParameters: this.services.SyncService.getAuthorizationParameters(),
                        includeUserId: !0
                    }];
                "consent.given" === e && ((0, D.eN)(this.store.getState()).forEach((e => {
                    o.push({
                        parameters: {
                            action: "multiple-IDs"
                        },
                        organizationUserId: e.organizationUserId,
                        authorizationParameters: this.services.SyncService.getMappedAuthorizationParameters(e)
                    })
                })), o[0].includeSignature = !0);
                return o.forEach((n => {
                    var o = this.customizeEvent((0, h.I8)(this.store.getState().events.template), n);
                    o.type = e, o.rate = s, t && (o.parameters = t), n.parameters && (o.parameters = (0, h.rd)(o.parameters, n.parameters)), (0, h.t8)(o, "source.beacon", !1), !0 === i && "function" == typeof navigator.sendBeacon && (0, h.t8)(o, "source.beacon", !0), r.push(o)
                })), !0 === i && "function" == typeof navigator.sendBeacon ? navigator.sendBeacon((0, _.getSDKConfigValue)("apiPath") + "/events?data_format=json", JSON.stringify(r)) : K.ajax({
                    method: "POST",
                    url: (0, _.getSDKConfigValue)("apiPath") + "/events",
                    body: JSON.stringify(r),
                    headers: {
                        "Content-Type": "application/json"
                    },
                    cors: !0
                }, ((e, t) => this.processEventResponse(e, t))), r
            }
            processEventResponse(e, t) {
                if (201 === e && t) {
                    var s = JSON.parse(t);
                    if (Array.isArray(s)) {
                        var i = s.find((e => e.dcs && e.dcs_user && e.signature));
                        i && this.services.SignatureService.updateCookie({
                            dcsUserId: i.dcs_user,
                            signature: i.signature
                        })
                    }
                } else(0, N.V2)(e, "createEvent")
            }
            sendPageview(e) {
                void 0 === e && (e = !1);
                var t = Q.K.value && sessionStorage.getItem("didomi-page-session-active");
                void 0 !== this.sentEvents[this.eventTypes.pageview] || t || (this.send(this.eventTypes.pageview, null, this.store.getState().events.sampleSizes.pageview, e), this.sentEvents[this.eventTypes.pageview] = !0, Q.K.value && window.sessionStorage.setItem("didomi-page-session-active", !0))
            }
            sendConsentAsked(e, t, s, i, n) {
                void 0 === this.sentEvents[this.eventTypes.consentAsked] && (this.send(this.eventTypes.consentAsked, {
                    purposes: e,
                    vendors: t,
                    position: n,
                    purposes_li: s,
                    vendors_li: i
                }, this.store.getState().events.sampleSizes.consentAsked), this.sentEvents[this.eventTypes.consentAsked] = !0)
            }
            sendConsentGiven(e, t) {
                void 0 === t && (t = !1), this.send(this.eventTypes.consentGiven, e, this.store.getState().events.sampleSizes.consentGiven, t)
            }
            sendPreferencesPurposesShown() {
                var e = this.eventTypes.uiAction + "-preferences.showpurposes";
                void 0 === this.sentEvents[e] && (this.send(this.eventTypes.uiAction, {
                    action: "preferences.shownpurposes"
                }, this.store.getState().events.sampleSizes.uiActionPreferencesPurposes, !1, !1), this.sentEvents[e] = !0)
            }
            sendPreferencesVendorsShown() {
                var e = this.eventTypes.uiAction + "-preferences.showvendors";
                void 0 === this.sentEvents[e] && (this.send(this.eventTypes.uiAction, {
                    action: "preferences.shownvendors"
                }, this.store.getState().events.sampleSizes.uiActionPreferencesVendors, !1, !1), this.sentEvents[e] = !0)
            }
            sendPreferencesPurposeStatusChanged() {
                var e = this.eventTypes.uiAction + "-preferences.purposechanged";
                void 0 === this.sentEvents[e] && (this.send(this.eventTypes.uiAction, {
                    action: "preferences.purposechanged"
                }, this.store.getState().events.sampleSizes.uiActionPreferencesPurposeChanged, !1, !1), this.sentEvents[e] = !0)
            }
            sendPreferencesVendorStatusChanged() {
                var e = this.eventTypes.uiAction + "-preferences.vendorchanged";
                void 0 === this.sentEvents[e] && (this.send(this.eventTypes.uiAction, {
                    action: "preferences.vendorchanged"
                }, this.store.getState().events.sampleSizes.uiActionPreferencesVendorChanged, !1, !1), this.sentEvents[e] = !0)
            }
            sendPreferencesShownPersonalDataTypes() {
                var e = this.eventTypes.uiAction + "-preferences.shownpersonaldatatypes";
                void 0 === this.sentEvents[e] && (this.send(this.eventTypes.uiAction, {
                    action: "preferences.shownpersonaldatatypes"
                }, this.store.getState().events.sampleSizes.uiActionPreferencesShownPersonalDataTypes, !1, !1), this.sentEvents[e] = !0)
            }
            sendPreferencesSPIChanged() {
                var e = this.eventTypes.uiAction + "-preferences.spichanged";
                void 0 === this.sentEvents[e] && (this.send(this.eventTypes.uiAction, {
                    action: "preferences.spichanged"
                }, this.store.getState().events.sampleSizes.uiActionPreferencesSPIChanged, !1, !1), this.sentEvents[e] = !0)
            }
        }
        X.prototype.eventTypes = {
            pageview: "pageview",
            consentAsked: "consent.asked",
            consentGiven: "consent.given",
            uiAction: "ui.action"
        };
        var ee = o(49756);
        class te extends O.Z {
            configure(e) {
                var t = e && e.id && e.config,
                    s = e && "number" == typeof e.size && e.size >= 0 && e.size <= 1,
                    i = !1;
                if (e && (e.group && ("string" != typeof e.group || "test" !== e.group && "control" !== e.group) || (i = !0)), t && s && i) {
                    if (e.config.experiment && delete e.config.experiment, e.startDate) {
                        var n = (0, ee.Z)(e.startDate);
                        return n instanceof Date ? (this.actions.setExperimentConfig(e.config), this.actions.setExperimentID(e.id), this.actions.setExperimentSize(e.size), this.actions.setExperimentStartDate(n), e.group && this.actions.setExperimentGroup(e.group), !0) : (console.log("Didomi - The test start date must be a date formatted as an ISO-8601 string"), !1)
                    }
                    return this.actions.setExperimentConfig(e.config), this.actions.setExperimentID(e.id), this.actions.setExperimentSize(e.size), e.group && this.actions.setExperimentGroup(e.group), !0
                }
                return t ? s ? i || console.log('Didomi - The experiment group must be "control" or "test"') : console.log("Didomi - The test group size must be between 0 and 1") : console.log("Didomi - Experiment requires an ID, a size and a config to run"), !1
            }
            run(e) {
                var {
                    id: t,
                    size: s,
                    config: i,
                    startDate: n,
                    group: r
                } = this.store.getState().experiment;
                if (!t || "number" != typeof s || !i) return null;
                if (!this.isUserPartOfExperiment(n, e.created)) return null;
                var o = r || this.getUserGroup(e.user_id, s);
                return o ? (this.actions.setExperimentGroup(o), "test" === o ? ("3e6e3e05-9201-4614-a13e-b9649d1fa0e4" === J.q.value && "bas-popin-expc" === t && (window && window.utag && window.utag.data && window.utag.data["cp.utag_main__pn"] && parseInt(window.utag.data["cp.utag_main__pn"]) > 1 ? (0, h.t8)(i, "notice.position", "popup") : (0, h.t8)(i, "notice.position", "bottom")), i) : null) : null
            }
            isUserPartOfExperiment(e, t) {
                if (!e) return !0;
                var s = (0, ee.Z)(t);
                return s instanceof Date && e.getTime() <= s.getTime()
            }
            getCurrentExperiment() {
                var e = this.store.getState().experiment;
                return e.id ? {
                    group: e.group,
                    id: e.id,
                    size: e.size,
                    startDate: e.startDate instanceof Date ? e.startDate.toISOString() : null
                } : null
            }
            getUserGroup(e, t) {
                return e && 36 === e.length ? 0 === t ? "control" : parseInt(e.slice(-5), 16) % 1e3 < 1e3 * t ? "test" : "control" : null
            }
        }
        var se = "granted",
            ie = "denied",
            ne = "ad",
            re = "analytics",
            oe = "functionality",
            ae = "personalization",
            ue = "security",
            de = ie;
        var le = [{
            id: "google",
            cls: class {
                constructor(e) {
                    void 0 === e && (e = {}), this.previousGoogleStatusForRefresh = void 0, this.requireCookieConsent = "boolean" != typeof e.eprivacy || e.eprivacy, this.refresh = "boolean" != typeof e.refresh || e.refresh, this.refreshOnConsent = "boolean" != typeof e.refreshOnConsent || e.refreshOnConsent, this.consentPassedToDFPEvents = 0, this.passTargetingVariables = !0 === e.passTargetingVariables
                }
                setConsentStatus(e, t, s, i) {
                    var n = !0 === e ? 0 : 1;
                    window.googletag || (window.googletag = {}), window.googletag.cmd = window.googletag.cmd || [], window.googletag.cmd.push((() => {
                        this.passTargetingVariables && (window.googletag.pubads().setTargeting("iabconsentstring", s), window.googletag.pubads().setTargeting("iabgdprapplies", i ? "1" : "0")), window.googletag.pubads().setPrivacySettings({
                            nonPersonalizedAds: 1 === n
                        })
                    })), window.adsbygoogle || (window.adsbygoogle = []), window.adsbygoogle.requestNonPersonalizedAds = n, (0, N.j8)("integrations.consentpassedtodfp", {
                        consentStatus: e,
                        index: this.consentPassedToDFPEvents
                    }), this.consentPassedToDFPEvents += 1, this.refresh && (!0 === t || this.refreshOnConsent) && (!0 !== e && this.requireCookieConsent || 0 !== this.previousGoogleStatusForRefresh && this.previousGoogleStatusForRefresh !== n && (this.previousGoogleStatusForRefresh = n, this.resumeAdRequests()))
                }
                resumeAdRequests() {
                    window.googletag || (window.googletag = {}), window.googletag.cmd = window.googletag.cmd || [], window.googletag.cmd.push((() => {
                        if (window.googletag.pubadsReady) window.googletag.pubads().refresh();
                        else var e = 0,
                            t = setInterval((() => {
                                e += 40, window.googletag.pubadsReady ? (window.googletag.pubads().refresh(), clearInterval(t)) : e >= 1e4 && clearInterval(t)
                            }), 40)
                    })), window.adsbygoogle || (window.adsbygoogle = []), window.adsbygoogle.pauseAdRequests = 0
                }
            },
            vendorIds: ["google", x.OE.google, "c:google"],
            usesMultipleVendors: !1
        }, {
            id: "salesforce-dmp",
            cls: class {
                constructor(e) {
                    void 0 === e && (e = {}), this.config = e
                }
                setConsentStatus(e, t) {
                    if (!0 !== t) {
                        var s = {
                            dc: !0 === e,
                            al: !0 === e,
                            tg: !0 === e,
                            cd: !0 === e,
                            sh: !0 === e,
                            re: !1
                        };
                        if (window.Krux || ((window.Krux = function() {
                                window.Krux.q.push(arguments)
                            }).q = []), this.config.namespace) {
                            var i = this.config.namespace; - 1 === i.indexOf("ns:") && (i = "ns:" + i), window.Krux(i, "consent:set", s)
                        } else window.Krux("consent:set", s)
                    }
                }
            },
            vendorIds: ["salesforce", x.OE.salesforce, "c:salesforce"],
            usesMultipleVendors: !1
        }, {
            id: "gcm",
            cls: class {
                constructor(e) {
                    void 0 === e && (e = {}), this.config = e, this.dataLayerName = "dataLayer", "string" == typeof e.dataLayerName && e.dataLayerName.length > 0 && (this.dataLayerName = e.dataLayerName), window[this.dataLayerName] || (window[this.dataLayerName] = []), this.setGoogleDeveloperId()
                }
                pushToDataLayer() {
                    window[this.dataLayerName] && "function" == typeof window[this.dataLayerName].push && window[this.dataLayerName].push(arguments)
                }
                setGoogleDeveloperId() {
                    this.pushToDataLayer("set", "developer_id.dMTc4Zm", !0)
                }
                setConsentStatus(e) {
                    if (!0 !== e) {
                        var [t, s] = e;
                        void 0 === t && void 0 === s ? this.handleInitialPageLoad() : this.handleConsentUpdate(t, s)
                    } else this.handleInitialPageLoad()
                }
                handleInitialPageLoad() {
                    !0 === this.config.setDefaultStatus && this.pushToDataLayer("consent", "default", {
                        ad_storage: this.getDefaultGCMPurposeStatus(ne),
                        analytics_storage: this.getDefaultGCMPurposeStatus(re),
                        functionality_storage: this.getDefaultGCMPurposeStatus(oe),
                        personalization_storage: this.getDefaultGCMPurposeStatus(ae),
                        security_storage: this.getDefaultGCMPurposeStatus(ue)
                    })
                }
                handleConsentUpdate(e, t) {
                    this.pushToDataLayer("consent", "update", {
                        ad_storage: this.getGCMPurposeStatus(e),
                        analytics_storage: this.getGCMPurposeStatus(t),
                        functionality_storage: this.getGCMPurposeStatus(e),
                        personalization_storage: this.getGCMPurposeStatus(e),
                        security_storage: this.getGCMPurposeStatus(!0)
                    })
                }
                getGCMPurposeStatus(e) {
                    return !0 === e ? se : ie
                }
                getDefaultGCMPurposeStatus(e) {
                    if ("security" === e) return se;
                    var t = (0, h.U2)(this.config, "defaultStatus." + e);
                    return "boolean" == typeof t ? this.getGCMPurposeStatus(t) : de
                }
            },
            vendorIds: ["google", "c:googleana-4TXnJigR"],
            usesMultipleVendors: !0
        }];
        class pe extends O.Z {
            constructor(e, t, s) {
                super(e, t, s), this.providers = []
            }
            configure(t) {
                void 0 === t && (t = {});
                var s = !1 !== t.refreshOnConsent;
                if (t.vendors) {
                    var i = t.vendors;
                    for (var n of le)
                        if (i[n.id] && !0 === i[n.id].enable) {
                            var r = (0, e.Z)({
                                refreshOnConsent: s
                            }, i[n.id]);
                            this.providers.push({
                                vendorIds: n.vendorIds,
                                provider: new n.cls(r, N.j8.bind(this)),
                                parameters: r,
                                usesMultipleVendors: n.usesMultipleVendors
                            })
                        }
                }
            }
            run() {
                if (!1 === this.services.UserService.isConsentRequired())
                    for (var e of this.providers) e.provider.setConsentStatus(!0, !0, "", !1);
                else this.updateProviders(!0), (0, N.on)("internal.consent.changed", (() => this.updateProviders(!1)))
            }
            updateProviders(e) {
                var t = this.services.TCFService.getConsentData(1);
                for (var s of this.providers) {
                    var i = s.vendorIds.map((e => this.services.ConsentService.getUserConsentStatusForAllPurposesByVendor(e))),
                        n = s.usesMultipleVendors ? i : i.filter((e => void 0 !== e))[0];
                    s.provider.setConsentStatus(n, e, t.consentData, t.gdprApplies)
                }
            }
        }
        var ce = o(98401),
            fe = o(58123);
        class ve extends O.Z {
            configure(e) {
                e && this.actions.setConsentNoticeConfig(e)
            }
            isVisible() {
                return (0, h.U2)(this.store.getState(), "consentNotice.show") || !1
            }
            uiLoaded() {
                var e, t, s;
                !0 === this.store.getState().consentNotice.showOnUILoad && (this.actions.showConsentNotice(), (null != (e = ce.notice.value) && e.enable || null != (t = fe.c.value) && t.showWhenConsentIsMissing) && (null == (s = ce.notice.value) || !s.enable) || (0, N.j8)("notice.shown"))
            }
            show() {
                this.isVisible() || (this.actions.showConsentNoticeOnLoad(), this.services.UIService.show(this.uiLoaded.bind(this)))
            }
            hide() {
                this.isVisible() && (0, N.j8)("notice.hidden"), this.actions.hideConsentNotice()
            }
            close() {
                this.hide(), (0, N.j8)("notice.clickclose")
            }
        }
        class he extends O.Z {
            configure(t) {
                t && this.actions.setConsentPopupConfig((0, e.Z)({}, t))
            }
            isVisible() {
                return (0, h.U2)(this.store.getState(), "consentPopup.open") || !1
            }
            uiLoaded(e) {
                var t, s, i, n;
                "information" === e ? null != (t = fe.c.value) && null != (s = t.information) && s.enable && (this.isVisible() || (0, N.j8)("preferences.shown"), this.actions.showConsentPopup(), this.actions.switchViewConsentPopup(e)) : (this.isVisible() || (0, N.j8)("preferences.shown"), this.actions.showConsentPopup(), -1 !== ["purposes", "vendors", "sensitive-personal-information"].indexOf(e) ? (this.actions.switchViewConsentPopup("preferences"), this.actions.switchPreferencesViewConsentPopup(e)) : null != (i = fe.c.value) && null != (n = i.information) && n.enable ? this.actions.switchViewConsentPopup("information") : (this.actions.switchViewConsentPopup("preferences"), this.actions.switchPreferencesViewConsentPopup("purposes")))
            }
            show(e) {
                this.services.UIService.show(this.uiLoaded.bind(this, e))
            }
            hide() {
                this.isVisible() && (this.actions.hideConsentPopup(), (0, N.j8)("preferences.hidden"))
            }
        }
        class ge {
            constructor(e, t) {
                this.windowVarCall = e, this.windowVarReadys = t || [e], this.createCondition(this.windowVarReadys, window) ? this.loaded = !0 : (this.loaded = !1, this.loading = new Promise((e => {
                    (0, g.u4)((t => {
                        this.createCondition(this.windowVarReadys, window) && (this.loaded = !0, e(), t())
                    }), 100, 3e4)
                })))
            }
            createCondition(e, t) {
                return e.reduce(((e, s) => {
                    var i = Array.isArray(s) ? s.reduce(((e, s) => e || Boolean((0, h.U2)(t, s))), !1) : (0, h.U2)(t, s);
                    return e && Boolean(i)
                }), !0)
            }
            call(e) {
                for (var t = arguments.length, s = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) s[i - 1] = arguments[i];
                if (!this.loaded) return this.loading.then((() => {
                    this.doCall(this.windowVarCall, e, ...s)
                }));
                this.doCall(this.windowVarCall, e, ...s)
            }
            doCall(e, t) {
                var s = (0, h.U2)(window, e, {}),
                    i = s[t];
                if (i && "function" == typeof i) {
                    for (var n = arguments.length, r = new Array(n > 2 ? n - 2 : 0), o = 2; o < n; o++) r[o - 2] = arguments[o];
                    i.call(s, ...r)
                }
            }
        }
        var me = o(76192);
        var be = o(86889),
            Se = {
                adobe: class {
                    constructor() {
                        this.satellite = new ge("_satellite")
                    }
                    setup(e, t) {
                        for (var s in t) this.satellite.call("setVar", s, t[s]);
                        e ? this.satellite.call("track", "didomi-ready") : this.satellite.call("track", "didomi-consent-changed")
                    }
                },
                commandersact: class {
                    constructor() {
                        this.tC = new ge("tC.event", ["tC.domReady", ["tC.event.didomiConsent", "tC.event.didomiReady", "tC.event.didomiConsentChanged"]])
                    }
                    setupVendors(e, t) {
                        this.tC.call("didomiConsent", {}, t), e ? this.tC.call("didomiReady", {}, t) : this.tC.call("didomiConsentChanged", {}, t)
                    }
                    setup(e, t, s, i, n, r, o, a) {
                        this.setupCookies(a), this.setupVendors(e, t)
                    }
                    setupCookies(e) {
                        var t = e.join(",");
                        me.ej("didomi_cookies") !== t && me.d8("didomi_cookies", t, 365)
                    }
                },
                didomi: class {
                    setup(e, t, s, i, n, r, o, a) {
                        for (var u of (window.didomiState = {}, Object.keys(t))) window.didomiState[u] = t[u];
                        "complete" !== document.readyState && window.addEventListener("load", (() => this.enableTags(s, i, n.allowed, a, o.allowed, r.allowed))), this.enableTags(s, i, n.allowed, a, o.allowed, r.allowed)
                    }
                    enableTags(e, t, s, i, n, r) {
                        var o = [{
                                attribute: "data-category",
                                values: i
                            }, {
                                attribute: "data-vendor",
                                values: s
                            }, {
                                attribute: "data-vendor-raw",
                                values: r
                            }, {
                                attribute: "data-purposes",
                                attributeIsList: !0,
                                values: n
                            }],
                            a = {
                                gdpr: e ? 1 : 0,
                                gdpr_consent: t
                            };
                        this.enableTagsByName('script[type="didomi/javascript"]', "script", o, a), this.enableTagsByName('script[type="didomi/html"]', "div", o, a)
                    }
                    enableTagsByName(t, s, i, n) {
                        var r = this,
                            o = document.querySelectorAll(t),
                            a = function(t) {
                                var o = !0;
                                "true" !== t.getAttribute("data-processed") && (i.filter((e => {
                                    var {
                                        attribute: s
                                    } = e;
                                    return t.hasAttribute(s)
                                })).map((s => {
                                    var {
                                        attribute: i,
                                        attributeIsList: a,
                                        values: u
                                    } = s;
                                    if ("immediate" === t.getAttribute("data-loading") || u.length > 0) {
                                        var d = t.getAttribute(i);
                                        if ("data-vendor" === i && (n = (0, e.Z)({}, n, r.addVendorsRelatedMacros(-1 !== u.indexOf(String(d))))), "data-vendor-raw" === i && (n = (0, e.Z)({}, n, r.addVendorsRawRelatedMacros(-1 !== u.indexOf(String(d))))), "immediate" !== t.getAttribute("data-loading"))
                                            if (!0 === a) {
                                                var l = String(d).split(","),
                                                    p = !0;
                                                for (var c of l) c.length > 0 && (p = p && -1 !== u.indexOf(String(c)));
                                                !1 === p && (o = !1)
                                            } else -1 === u.indexOf(String(d)) && (o = !1)
                                    } else o = !1;
                                    return null
                                })), !0 === o && r.replaceTags(s, t, n))
                            };
                        for (var u of o) a(u)
                    }
                    replaceMacros(e, t) {
                        for (var s of Object.keys(e)) {
                            var i = new RegExp("{" + s + "}", "gi");
                            t = t.replace(i, e[s])
                        }
                        return t
                    }
                    replaceTags(e, t, s) {
                        var i = document.createElement(e);
                        for (var n of ("script" === e && (i.type = "text/javascript"), i.innerHTML = this.replaceMacros(s, t.innerHTML), t.attributes)) "type" !== n.name && i.setAttribute(n.name, n.value);
                        t.parentNode.insertBefore(i, t), t.setAttribute("data-processed", !0)
                    }
                    addVendorsRelatedMacros(e) {
                        return {
                            gdpr_consent_vendor: e ? 1 : 0,
                            gdpr_consent_vendor_boolean: e
                        }
                    }
                    addVendorsRawRelatedMacros(e) {
                        return {
                            gdpr_consent_vendor_raw: e ? 1 : 0,
                            gdpr_consent_vendor_boolean_raw: e
                        }
                    }
                },
                gtm: class {
                    constructor(e) {
                        this.dataLayerName = "dataLayer", e && "string" == typeof e.dataLayerName && e.dataLayerName.length > 0 && (this.dataLayerName = e.dataLayerName), window[this.dataLayerName] || (window[this.dataLayerName] = [])
                    }
                    pushToDataLayer(e) {
                        window[this.dataLayerName] && "function" == typeof window[this.dataLayerName].push && window[this.dataLayerName].push(e)
                    }
                    setup(e, t, s, i, n, r, o, a) {
                        this.setupCookies(a), this.setupVendors(e, t)
                    }
                    setupCookies(e) {
                        0 !== e.length && (1 === e.length && "essential" === e[0] || this.pushToDataLayer({
                            event: "didomi-cookies-consent",
                            didomiCookiesConsent: e.join(",")
                        }))
                    }
                    setupVendors(t, s) {
                        this.pushToDataLayer((0, e.Z)({
                            event: "didomi-consent"
                        }, s)), t ? this.pushToDataLayer((0, e.Z)({
                            event: "didomi-ready"
                        }, s)) : this.pushToDataLayer((0, e.Z)({
                            event: "didomi-consent-changed"
                        }, s))
                    }
                },
                tealium: class {
                    constructor() {
                        this.utag = new ge("utag")
                    }
                    setup(t, s) {
                        t ? this.utag.call("link", (0, e.Z)({
                            tealium_event: "didomi-ready"
                        }, s)) : this.utag.call("link", (0, e.Z)({
                            tealium_event: "didomi-consent-changed"
                        }, s))
                    }
                },
                eulerian: class {
                    constructor() {
                        this.vendorsCalled = [], this.isContainerLoaded = !1, this.containerLoading = new Promise((e => {
                            (0, g.u4)((t => {
                                window._oEa && window.EA_collector && window.EA_epmEnd && (window._oEa.cookieset("didomi_eulerian", 1, 1), this.isContainerLoaded = !0, e(), t())
                            }), 100, 3e4)
                        }))
                    }
                    send(e) {
                        var t = window.EA_epmGet().filter((e => !e.noconsent)).map((t => (-1 !== e.didomiVendorsConsent.indexOf(t.name + ",") && -1 === this.vendorsCalled.indexOf(t.name) ? (t.allowed = !0, t.denied = !1, this.vendorsCalled.push(t.name)) : (t.allowed = !1, t.denied = !0), t)));
                        t.filter((e => e.allowed)).length > 0 && (window.EA_epmSet(t), window.EA_epmEnd())
                    }
                    setup(e, t, s, i, n, r, o, a) {
                        this.isContainerLoaded ? this.send(t) : this.containerLoading.then((() => {
                            this.send(t)
                        }))
                    }
                },
                "eulerian-v2": class {
                    constructor() {
                        this.isContainerLoaded = !1, this.containerLoading = new Promise((e => {
                            (0, g.u4)((t => {
                                window._oEa && window.EA_collector && (this.isContainerLoaded = !0, e(), t())
                            }), 100, 3e4)
                        }))
                    }
                    send(e) {
                        var t = e.didomiVendorsConsent.split(",").filter((e => -1 === e.indexOf("iab:"))).join(",");
                        window.EA_collector(["cmp-customvendor-allowed", t])
                    }
                    setup(e, t) {
                        this.isContainerLoaded ? this.send(t) : this.containerLoading.then((() => {
                            this.send(t)
                        }))
                    }
                }
            };
        class Ce extends O.Z {
            constructor(e, t, s) {
                super(e, t, s), this.providers = {}, this.oldAllowedCategories = [], this.oldVendorsByStatus = {
                    allowed: [],
                    unknown: [],
                    denied: []
                }, this.oldPurposesByStatus = {
                    allowed: [],
                    unknown: [],
                    denied: []
                }
            }
            configure(e, t) {
                Se[e] ? this.providers[e] || (this.providers[e] = new Se[e](t)) : console.error('Didomi SDK - The tag manager "' + e + '" is not supported. Possible values: ' + Object.keys(Se).join(", "))
            }
            run() {
                var e = (0, h.VO)(this.providers);
                e.length > 0 && (this.setup(e, !0), (0, N.on)("cookies.enable", (() => {
                    this.setup(e, !1)
                })), (0, N.on)("internal.consent.changed", (() => {
                    this.setup(e, !1)
                })))
            }
            areStatusDifferent(e, t) {
                return !(0, h.cO)(e.allowed, t.allowed) || !(0, h.cO)(e.unknown, t.unknown) || !(0, h.cO)(e.denied, t.denied)
            }
            areCategoriesDifferent(e) {
                return !(0, h.cO)(e, this.oldAllowedCategories)
            }
            getVendorsByStatus() {
                var e = {
                        allowed: [],
                        denied: [],
                        unknown: []
                    },
                    t = {
                        allowed: [],
                        denied: [],
                        unknown: []
                    },
                    s = be.r.value;
                for (var i of s) {
                    var n = this.services.ConsentService.getUserStatusForVendor(i.id),
                        r = this.services.ConsentService.getUserStatusForVendorAndLinkedPurposes(i.id),
                        o = "";
                    o = "didomi" === i.namespace || "iab" === i.namespace ? i.namespace + ":" + i.id : i.id, !0 === r ? e.allowed.push(o) : !1 === r ? e.denied.push(o) : this.services.UserService.isConsentRequired() ? e.unknown.push(o) : e.allowed.push(o), !0 === n ? t.allowed.push(o) : !1 === n ? t.denied.push(o) : this.services.UserService.isConsentRequired() ? t.unknown.push(o) : t.allowed.push(o)
                }
                return {
                    vendorsByStatusWithPurposes: e,
                    vendorsByStatusWithoutPurposes: t
                }
            }
            getPurposesByStatus() {
                var e = [],
                    t = [],
                    s = [],
                    i = q.s.value,
                    n = this.services.WebsiteService.getPurposesBasedOnConsent().map((e => e.id));
                for (var r of i) {
                    var o = -1 !== n.indexOf(r) ? this.services.ConsentService.getUserConsentStatusByPurpose(r) : this.services.ConsentService.getLegitimateInterestStatusForPurpose(r);
                    !0 === o ? e.push(r) : !1 === o ? s.push(r) : this.services.UserService.isConsentRequired() ? t.push(r) : e.push(r)
                }
                return {
                    allowed: e,
                    unknown: t,
                    denied: s
                }
            }
            getCustomVariables(e, t, s, i, n, r) {
                var o = {
                    didomiGDPRApplies: e,
                    didomiIABConsent: t || "",
                    didomiVendorsConsent: this.formatStatusString(s.allowed),
                    didomiVendorsConsentUnknown: this.formatStatusString(s.unknown),
                    didomiVendorsConsentDenied: this.formatStatusString(s.denied),
                    didomiVendorsRawConsent: this.formatStatusString(i.allowed),
                    didomiVendorsRawConsentUnknown: this.formatStatusString(i.unknown),
                    didomiVendorsRawConsentDenied: this.formatStatusString(i.denied),
                    didomiPurposesConsent: this.formatStatusString(n.allowed),
                    didomiPurposesConsentUnknown: this.formatStatusString(n.unknown),
                    didomiPurposesConsentDenied: this.formatStatusString(n.denied),
                    didomiExperimentId: "",
                    didomiExperimentUserGroup: ""
                };
                return r && (o.didomiExperimentId = r.id || "", o.didomiExperimentUserGroup = r.group || ""), o
            }
            formatStatusString(e) {
                return Array.isArray(e) && e.length > 0 ? e.join(",") + "," : ""
            }
            setup(e, t) {
                var s = this.services.CookiesService.getAllowedCategories(),
                    {
                        vendorsByStatusWithPurposes: i,
                        vendorsByStatusWithoutPurposes: n
                    } = this.getVendorsByStatus(),
                    r = this.getPurposesByStatus();
                if (t || this.areStatusDifferent(i, this.oldVendorsByStatus) || this.areStatusDifferent(r, this.oldPurposesByStatus) || this.areCategoriesDifferent(s)) {
                    var o, a, u, d;
                    this.oldVendorsByStatus = i, this.oldPurposesByStatus = r, this.oldAllowedCategories = s;
                    var l = "gdpr" === (null == (o = v.noticeConfig.value) || null == (a = o.regulation) ? void 0 : a.name) ? 1 : 0,
                        p = "gdpr" === (null == (u = v.noticeConfig.value) || null == (d = u.regulation) ? void 0 : d.name) ? this.services.TCFService.getConsentData().consentData : "",
                        c = this.services.ExperimentsService.getCurrentExperiment(),
                        f = this.getCustomVariables(l, p, i, n, r, c);
                    for (var h of e) h.setup(t, f, l, p || "", i, n, r, s, c)
                }
            }
        }
        var ye = o(71409),
            we = {
                crawlers: /googlebot|adsbot|feedfetcher|mediapartners|bingbot|bingpreview|slurp|linkedin|msnbot|teoma|alexabot|exabot|facebot|facebook|twitter|yandex|baidu|duckduckbot|qwant|archive|applebot|addthis|slackbot|reddit|whatsapp|pinterest|moatbot|google-xrawler|crawler|spider|crawling|oncrawl|NETVIGIE|PetalBot|PhantomJS|NativeAIBot|Cocolyzebot|SMTBot|EchoboxBot|Quora-Bot|scraper|BLP_bbot|MAZBot|ScooperBot|BublupBot|Cincraw|HeadlessChrome|diffbot|Google Web Preview|Doximity-Diffbot|Rely Bot|pingbot|cXensebot|PingdomTMS|AhrefsBot|robot|semrush|seenaptic|netvibes|taboolabot|SimplePie|APIs-Google|Google-Read-Aloud|googleweblight|DuplexWeb-Google|Google Favicon|Storebot-Google|TagInspector|Rigor|Bazaarvoice|KlarnaBot|pageburst|naver|iplabel/i,
                performance: /Chrome-Lighthouse|gtmetrix|speedcurve|DareBoost|PTST|StatusCake_Pagespeed_Indev/i
            };

        function Ie(e, t, s) {
            var i = [];
            if (Array.isArray(e))
                for (var n of e) {
                    var r = we[n];
                    r ? i.push(r) : console.error('Didomi - Bot detector - Bot type "' + n + '" does not exist')
                }
            if (Array.isArray(t))
                for (var o of t) try {
                    if (!o || "string" != typeof o) throw new Error("User-Agent cannot be null, undefined or an empty string");
                    i.push(new RegExp(o))
                } catch (e) {
                    console.error('Didomi - Bot detector - User-agent "' + o + '" is not a valid regular expression: ' + e.message)
                }
            return i.filter((e => e.test(s))).length > 0
        }
        var _e = o(47725),
            Pe = o(75e3);
        class Ae extends O.Z {
            configure(e) {
                if (e) {
                    var {
                        authToken: t,
                        organizationUserIdExp: s,
                        ignoreConsentBefore: i
                    } = e;
                    if (t) {
                        var n = (0, ye.eI)(t);
                        n && (e.organizationId = n.organization_id, e.organizationUserId = n.sub)
                    }
                    null !== e.organizationUserId && "" !== e.organizationUserId || (delete e.organizationUserId, console.error('Didomi - Authorization Parameters configuration: Invalid Organization User Id "' + e.organizationUserId + '". The value will be ignored')), s && !(0, h.hj)(s) && (delete e.organizationUserIdExp, console.error('Didomi - Authorization Parameters configuration: Invalid Organization User Digest Expired timestamp "' + s + '". The value will be ignored')), i && (e.ignoreConsentBefore = (0, ee.Z)(i) || null), this.actions.setUserConfig(e)
                }
                var r = (0, h.U2)(this.store.getState(), "user.bots", {});
                this.actions.setUserConfig({
                    isBot: Ie(r.types, r.extraUserAgents, navigator.userAgent)
                })
            }
            getId() {
                return this.services.StorageService.getTokenFromLocalStore().user_id || null
            }
            getAuthToken() {
                var e = this.store.getState();
                if ((0, h.U2)(e, "user.authToken")) return (0, h.U2)(e, "user.authToken");
                var t = (0, g.s6)("token");
                if (t) return t;
                var s = (0, _e.le)("didomi_auth_token");
                return s || null
            }
            getOrganizationId() {
                var e = this.store.getState();
                return (0, h.U2)(e, "user.organizationId") || null
            }
            getAuthorizationParameters() {
                return (0, D.Ex)(this.store.getState())
            }
            getOrganizationUserId() {
                return (0, D.cY)(this.store.getState())
            }
            isConsentRequired() {
                var e, t, s, i, n = this.store.getState();
                if ("ccpa" === (null == (e = v.noticeConfig.value) || null == (t = e.regulation) ? void 0 : t.name)) return !1;
                if ("1.0.0" === (0, v.getNoticeConfigValue)("version")) {
                    var r, o;
                    if ((0, R.T5)(n)) return (0, Pe.eb)(n);
                    if ("none" === (null == (r = v.noticeConfig.value) || null == (o = r.regulation) ? void 0 : o.name)) return !1
                }
                var a = (0, h.U2)(n, "user", {});
                return (!a.bots || !1 !== a.bots.consentRequired || !a.isBot) && (!0 === (0, h.U2)(n, "website.ignoreCountry") || "gdpr" === (null == (s = v.noticeConfig.value) || null == (i = s.regulation) ? void 0 : i.name))
            }
            getExternalConsent() {
                return this.store.getState().user.externalConsent
            }
            loadExternalConsent() {
                var e = this.getExternalConsent();
                if (e.enabled && e.value && "object" == typeof e.value) {
                    var t = e.value;
                    if (t.purposes || t.vendors) this.services.ConsentService.setUserStatus(t);
                    else {
                        var {
                            disabledPurposes: s,
                            disabledVendors: i,
                            enabledPurposes: n,
                            enabledVendors: r,
                            enabledPurposesLegitimateInterests: o,
                            disabledPurposesLegitimateInterests: a,
                            enabledVendorsLegitimateInterests: u,
                            disabledVendorsLegitimateInterests: d,
                            action: l
                        } = t;
                        this.services.ConsentService.setUserConsentStatus(n, s, r, i, o, a, u, d, void 0, void 0, l)
                    }
                }
            }
            getUserId() {
                var e = this.store.getState();
                return (0, h.U2)(e, "user.id") || null
            }
        }
        var ke = o(48766);
        class Te extends O.Z {
            configure(e) {
                if (e) {
                    var t = {};
                    void 0 !== e.ignoreCountry && (t.ignoreCountry = e.ignoreCountry), void 0 !== e.privacyPolicyURL && (t.privacyPolicyURL = e.privacyPolicyURL), void 0 !== e.name && (t.name = e.name), "string" == typeof e.apiKey && (t.apiKey = e.apiKey), "string" == typeof e.providerKey && (t.providerKey = e.providerKey), "string" == typeof e.logoUrl && (t.logoUrl = e.logoUrl), "string" == typeof e.customSDK && (t.customSDK = e.customSDK), "boolean" == typeof e.enableGlobalConsentForAllVendorsAndPurposes && (t.enableGlobalConsentForAllVendorsAndPurposes = e.enableGlobalConsentForAllVendorsAndPurposes), "boolean" == typeof e.alwaysDisplayActionButtons && (t.alwaysDisplayActionButtons = e.alwaysDisplayActionButtons), "boolean" == typeof e.enabledTCFAPIErrorLogging && (t.enabledTCFAPIErrorLogging = e.enabledTCFAPIErrorLogging), "object" == typeof e.regulations && (t.regulations = e.regulations, "object" == typeof e.regulations.gdpr && e.regulations.gdpr.additionalCountries && (Array.isArray(e.regulations.gdpr.additionalCountries) ? t.regulations.gdpr.additionalCountries = e.regulations.gdpr.additionalCountries : t.regulations.gdpr.additionalCountries = [])), "object" == typeof e.regulation && (t.regulation = e.regulation), "string" == typeof e.version && (t.version = e.version);
                    var s = (0, h.U2)(e, "vendors.iab");
                    "boolean" == typeof(0, h.U2)(s, "enabled") && (t.tcfEnabled = (0, h.U2)(s, "enabled"), t.tcfVersion = Y.m.value.semVersion);
                    var i = (0, h.U2)(e, "vendors.google");
                    i && i.additionalConsent && (t.google = {
                        additionalConsent: {
                            positive: "string" == typeof i.additionalConsent.positive ? i.additionalConsent.positive : null,
                            negative: "string" == typeof i.additionalConsent.negative ? i.additionalConsent.negative : null
                        }
                    }), i && void 0 !== i.fullATP && (0, h.t8)(t, "google.fullATP", i.fullATP), "string" == typeof e.country && (t.publisherCountryCode = e.country), "number" == typeof e.consentDuration && e.consentDuration > 0 && (t.consentDuration = e.consentDuration), "number" == typeof e.deniedConsentDuration && e.deniedConsentDuration > 0 && (t.deniedConsentDuration = e.deniedConsentDuration), e.deploymentId && (t.deploymentId = e.deploymentId), e.customDomain && (t.customDomain = e.customDomain);
                    var n = (0, h.U2)(e, "vendors.iab.cmpId");
                    "number" == typeof n && (t.iabTCFCMPID = n), e.ouidAsPrimaryIfPresent && (t.ouidAsPrimaryIfPresent = e.ouidAsPrimaryIfPresent), this.actions.setWebsiteConfig(t)
                }
            }
            numberOfDaysHasExceeded() {
                var e, {
                    token: t
                } = this.services.StorageService.getTokenFromCookies();
                return t = t || {}, (0, g.D6)(new Date(t.updated || null)) >= (null == (e = ce.notice.value) ? void 0 : e.daysBeforeShowingAgain)
            }
            determineConsentNoticeStatus() {
                var e, t, s, i;
                this.shouldNoticeBeShown() ? (this.services.NoticeService.show(), "ccpa" !== (null == (e = v.noticeConfig.value) || null == (t = e.regulation) ? void 0 : t.name) && null != (s = fe.c.value) && s.showWhenConsentIsMissing && this.services.PreferencesService.show()) : (this.services.NoticeService.hide(), null != (i = fe.c.value) && i.showWhenConsentIsMissing && this.services.PreferencesService.hide())
            }
            shouldNoticeBeShown() {
                var e, t;
                return "ccpa" === (null == (e = v.noticeConfig.value) || null == (t = e.regulation) ? void 0 : t.name) ? this.services.CCPAService.shouldShowNotice() : this.shouldConsentBeCollected()
            }
            shouldConsentBeCollected() {
                if (this.services.UserService.isConsentRequired()) {
                    var e = this.store.getState();
                    return !!(0, D.s_)(e) || !0 !== this.services.ConsentService.hasAllConsentStatus(this.getPurposesFromAllLegalBases(), be.r.value) && (!1 === (0, ke.jq)(e) || this.numberOfDaysHasExceeded() || !this.services.ConsentService.hasAnyStatus())
                }
                return !1
            }
            setUserAgreeToAll(e) {
                var t = this.store.getState(),
                    s = G.P.value,
                    i = (0, R.wG)(t),
                    n = (0, R.bh)(t),
                    r = Z.O.value;
                if (0 !== [...i, ...j.V.value].length && 0 !== r.length || 0 !== s.length) {
                    var o = new E.Z(this.services.ConsentService.getUserStatus.bind(this.services.ConsentService), this.services.ConsentService.setUserStatus.bind(this.services.ConsentService), e);
                    o.enablePurposes(...i), o.enableVendors(...r), o.enableVendorsLegitimateInterests(...j.V.value), o.enablePurposesLegitimateInterests(...n), o.commit(), this.services.NoticeService.hide()
                }
            }
            setUserDisagreeToAll(e) {
                var t = this.store.getState(),
                    s = G.P.value,
                    i = (0, R.wG)(t),
                    n = (0, R.bh)(t),
                    r = Z.O.value;
                if (0 !== [...i, ...j.V.value].length && 0 !== r.length || 0 !== s.length) {
                    var o = new E.Z(this.services.ConsentService.getUserStatus.bind(this.services.ConsentService), this.services.ConsentService.setUserStatus.bind(this.services.ConsentService), e);
                    o.disablePurposes(...i), o.disableVendors(...r), o.disableVendorsLegitimateInterests(...j.V.value), o.disablePurposesLegitimateInterests(...n), o.commit(), this.services.NoticeService.hide()
                }
            }
            isUserConsentStatusPartial() {
                var e;
                return !1 !== this.services.UserService.isConsentRequired() && (0 !== (null == (e = be.r.value) ? void 0 : e.length) && !this.services.ConsentService.hasAllConsentStatus(this.getPurposesFromAllLegalBases(), be.r.value))
            }
            getPurposesBasedOnConsent() {
                var e = this.store.getState();
                return [...(0, R._0)(e), ...(0, R.G9)(e)]
            }
            getPurposesBasedOnLegitimateInterest() {
                return (0, R.Be)(this.store.getState())
            }
            getPurposesFromAllLegalBases() {
                return [...this.getPurposesBasedOnConsent(), ...this.getPurposesBasedOnLegitimateInterest()]
            }
            getProviderKey() {
                var e = (0, h.U2)(this.store.getState(), "website.providerKey");
                if (!e) {
                    var t = document.getElementById("spcloader");
                    if (t && t.getAttribute) {
                        var s = t.getAttribute("data-provider");
                        "string" == typeof s && s.length > 0 && (e = s, this.actions.setProviderKey(e))
                    }
                }
                return e
            }
            getCustomSDKKey() {
                return (0, h.U2)(this.store.getState(), "website.customSDK")
            }
            getEnableGlobalConsentForAllVendorsAndPurposes() {
                return (0, h.U2)(this.store.getState(), "website.enableGlobalConsentForAllVendorsAndPurposes")
            }
            shouldAlwaysDisplayActionButtons() {
                return (0, h.U2)(this.store.getState(), "website.alwaysDisplayActionButtons")
            }
            isTCFEnabled() {
                return !1 !== (0, h.U2)(this.store.getState(), "website.tcfEnabled")
            }
            getOpenDialogsCount() {
                return (0, h.U2)(this.store.getState(), "website.openDialogsCount") || 0
            }
            incrementOpenDialogsCount() {
                this.actions.setOpenDialogsCount(this.getOpenDialogsCount() + 1)
            }
            decrementOpenDialogsCount() {
                this.actions.setOpenDialogsCount(this.getOpenDialogsCount() - 1)
            }
        }
        class Ee extends O.Z {
            constructor(e, t, s) {
                super(e, t, s)
            }
            init() {
                this.TCFVersion = M.t.defaultTCFVersion
            }
        }
        var Le = o(11281),
            Ue = o(71654);
        class Oe {
            constructor(e) {
                this.callbacks = {}, this.timeoutCalled = !1;
                var t = document.createElement("iframe");
                t.setAttribute("src", e), t.setAttribute("id", "iframe-cookies-group"), t.setAttribute("style", "display:none"), document.body.appendChild(t), this.iframe = t
            }
            isNotResponding() {
                return this.timeoutCalled
            }
            getType() {
                return "group"
            }
            getTokens(e, t, s, i, n, r, o, a, u) {
                this.iframe.onload = () => {
                    this.postMessageToIframe("getTokens", {
                        name: e,
                        type: t,
                        storageSources: s,
                        isSameSiteRequired: i,
                        TCFVersion: n,
                        expiry: r,
                        secure: o
                    }, a, u)
                }
            }
            setToken(e, t, s, i, n, r) {
                this.postMessageToIframe("setToken", {
                    name: e,
                    value: t,
                    storageSources: s,
                    isSameSiteRequired: i,
                    expiry: n,
                    secure: r
                })
            }
            deleteToken(e) {
                this.postMessageToIframe("deleteToken", {
                    name: e
                })
            }
            postMessageToIframe(e, t, s, i) {
                if (void 0 === i && (i = 4e3), this.iframe && !this.isNotResponding()) {
                    var n = (0, Ue.Z)(),
                        r = this.getType();
                    this.iframe.contentWindow.postMessage({
                        __didomiCall: {
                            call: e,
                            callId: n,
                            type: r,
                            params: t
                        }
                    }, "*"), s && (this.callbacks[n] = s, setTimeout((() => {
                        this.callbacks[n] && (this.callbacks[n](new Error("Timeout")), delete this.callbacks[n], this.timeoutCalled = !0)
                    }), i))
                }
            }
            receiveMessageFromIframe(e) {
                if (e && e.data) {
                    var t;
                    try {
                        t = "string" == typeof e.data ? JSON.parse(e.data) : e.data
                    } catch (e) {
                        return
                    }
                    if (t.__didomiCall) {
                        var s = t.__didomiCall;
                        this.callbacks[s.callId] && this.getType() === s.type && (this.callbacks[s.callId](null, s.params), delete this.callbacks[s.callId])
                    }
                }
            }
        }
        var xe = (0, C.Fl)((() => {
                var e, t, s, i = null == (e = v.noticeConfig.value) || null == (t = e.regulation) ? void 0 : t.name;
                if (null != (s = $.L.value) && s.isDidomiConsentStringEncodingEnabled) return "gdpr" === i ? "didomi_dcs" : "didomi_dcs_" + i;
                if (i && "gdpr" !== i && "ccpa" !== i) {
                    var n, r, o, a = null == (n = v.noticeConfig.value) || null == (r = n.regulation) || null == (o = r.cookies) ? void 0 : o.didomiTokenCookieName;
                    return "string" == typeof a && a.length > 0 ? a : "didomi_token_" + i
                }
                var u, d, l = null == (u = v.noticeConfig.value) || null == (d = u.cookies) ? void 0 : d.didomiTokenCookieName;
                return "string" == typeof l && l.length > 0 ? l : "didomi_token"
            })),
            De = o(53017);
        class Ve extends Ee {
            init() {
                super.init(), this.group = {
                    iframe: null,
                    didomiToken: null,
                    iframeNotResponding: !1,
                    iabConsentString: null
                }, this.callbackCalled = !1, this.iframesCalled = 0, this.iframesError = 0, this.iframesDisabled = 0
            }
            configure(e, t) {
                if (e) {
                    var s = {},
                        i = (0, h.U2)(e, "group"),
                        n = {};
                    void 0 !== i && i === Object(i) && (i.customDomain && "string" == typeof i.customDomain && (n.customDomain = i.customDomain), i.enabled && "boolean" == typeof i.enabled && (n.enabled = i.enabled), s.group = n), this.actions.setThirdPartyCookiesConfig(s), this.storageSources = t
                }
            }
            getStorageSources() {
                return this.store.getState().cookies.storageSources
            }
            isSameSiteRequired() {
                return this.store.getState().cookies.isSameSiteRequired
            }
            createIframe() {
                var e = (0, _.getSDKConfigValue)("globalCookiesProtocol"),
                    t = (0, h.U2)(this.getConfigCookie(), "customDomain"),
                    s = e + "://" + (0, g.Ph)(t) + "/global-cookies/" + (0, g.bo)() + "/global-cookies." + (0, g.bo)() + ".html";
                return new Oe(s)
            }
            initThirdParties(e) {
                if (this.isThirdPartyActive()) {
                    window.addEventListener ? window.addEventListener("message", (e => this.receiveMessageFromIframe(e)), !1) : window.attachEvent("onmessage", (e => this.receiveMessageFromIframe(e)));
                    var t = this.store.getState(),
                        s = (0, V.Q$)(t);
                    this.group.iframe = this.createIframe(), this.group.iframe.getTokens(xe.value, "group", this.storageSources, this.isSameSiteRequired(), this.TCFVersion, (0, R.EC)(t), s, ((t, s) => this.getTokenFromIframe(t, s, e)))
                } else e()
            }
            receiveMessageFromIframe(e) {
                this.isThirdPartyActive() && this.group.iframe.receiveMessageFromIframe(e)
            }
            getConfigCookie() {
                return (0, h.U2)(this.store.getState(), "cookies.group")
            }
            getEnabledCookies() {
                return this.isThirdPartyActive() ? this.getCookie() : null
            }
            getCookie() {
                return {
                    didomiToken: this.group.didomiToken,
                    iabConsentString: this.group.iabConsentString
                }
            }
            setEnabledCookies(e, t) {
                this.isThirdPartyActive() && this.setCookie(e, t)
            }
            hasEnabledThirdParties() {
                return this.isThirdPartyActive()
            }
            setCookie(e, t) {
                var s = this.store.getState(),
                    i = (0, R.EC)(s),
                    n = (0, V.Q$)(s);
                e && this.group.iframe.setToken(xe.value, e, this.storageSources, this.isSameSiteRequired(), i, n), t && this.group.iframe.setToken(De.I.value, t, this.storageSources, this.isSameSiteRequired(), i, n)
            }
            hasTriedLoadingAllEnabledThirdParties() {
                var e = this.isThirdPartyActive() ? 1 : 0;
                return this.iframesCalled === e + this.iframesError + this.iframesDisabled
            }
            isEnabled() {
                var e = this.store.getState();
                return (0, h.U2)(e, "cookies.group.enabled") || !1
            }
            isThirdPartyActive() {
                return this.getConfigCookie().enabled && !1 !== this.isThirdPartySupported() && !0 !== this.group.iframeNotResponding
            }
            isThirdPartySupported() {
                return "false" !== (0, Le.Wq)("didomi_third_party_cookie", this.storageSources)
            }
            getTokenFromIframe(e, t, s) {
                if (void 0 === t && (t = {}), this.iframesCalled += 1, e && "Timeout" === e.message) this.iframesError += 1, this.group.iframeNotResponding = !0, !this.callbackCalled && this.hasTriedLoadingAllEnabledThirdParties() && (this.callbackCalled = !0, s());
                else {
                    if (t.didomi_accept_cookie) {
                        var i = null;
                        t.iab_consent_string && (this[t.didomi_type].iabConsentString = t.iab_consent_string), t.didomi_token && (i = t.didomi_token), this[t.didomi_type].didomiToken = i
                    } else {
                        this.iframesDisabled += 1;
                        var n = this.store.getState(),
                            r = (0, R.EC)(n),
                            o = (0, V.Q$)(n);
                        (0, Le.EV)("didomi_third_party_cookie", !1, this.services.LocalCookiesService.getCookieDomain(), this.storageSources, !1, !1, r, o)
                    }!this.callbackCalled && this.hasTriedLoadingAllEnabledThirdParties() && (this.callbackCalled = !0, s())
                }
            }
            resetIABToken() {
                this.isThirdPartyActive() && this.group.iframe.deleteToken(De.I.value)
            }
        }
        class Re extends Ee {
            configure(e, t) {
                if (e) {
                    var s = {},
                        i = (0, h.U2)(e, "local"),
                        n = {};
                    void 0 !== i && i === Object(i) && ("string" == typeof i.customDomain && (n.customDomain = i.customDomain), s.local = n), this.actions.setLocalCookiesConfig(s), this.storageSources = t
                }
            }
            isSameSiteRequired() {
                return this.store.getState().cookies.isSameSiteRequired
            }
            getLocalCookies() {
                return (0, Le.Y9)(xe.value, De.I.value, this.storageSources)
            }
            setLocalCookies(e, t) {
                var s = this.store.getState(),
                    i = this.getCookieDomain(),
                    n = (0, R.EC)(s),
                    r = (0, V.Q$)(s);
                e && (0, Le.EV)(xe.value, e, i, this.storageSources, !1, this.isSameSiteRequired(), n, r), t && (0, Le.EV)(De.I.value, t, i, this.storageSources, !1, this.isSameSiteRequired(), n, r)
            }
            getCookieDomain() {
                return this.store.getState().cookies.local.customDomain
            }
            resetIABToken() {
                (0, Le.id)(De.I.value, this.getCookieDomain())
            }
        }
        var Ne = o(55974),
            Fe = o(61122);
        class Be extends O.Z {
            getInitialState() {
                return (0, h.I8)(Fe.initialState.consent)
            }
            getUserConsentToken() {
                return (0, h.U2)(this.store.getState(), "consent")
            }
            setConsentToken(e) {
                var t = this.createConsentByVendorFromToken(e);
                this.actions.setConsentByVendor(t), this.actions.setConsent(e)
            }
            setTokenUserAuthParams(e) {
                this.actions.setTokenUserAuthParams(e)
            }
            setConsentString(e) {
                this.actions.setConsentString(e)
            }
            setConsentStringPresentFromStorage(e) {
                this.actions.setConsentStringPresentFromStorage(e)
            }
            getConsentString() {
                return (0, h.U2)(this.store.getState(), "iab.consentString")
            }
            isVendorEnabled(e) {
                var {
                    vendor: t,
                    enabledPurposes: s,
                    essentialPurposes: i,
                    enabledVendors: n
                } = e;
                if (-1 === n.indexOf(t.id)) return !1;
                var r = Array.isArray(t.purposeIds) ? t.purposeIds.filter((e => -1 === i.indexOf(e))) : t.purposeIds;
                for (var o of r)
                    if (-1 === s.indexOf(o)) return !1;
                return !0
            }
            createConsentByVendorFromToken(e) {
                var t = {},
                    {
                        purposes: s,
                        vendors: i,
                        vendors_li: n
                    } = e,
                    r = B("isVendorEnabled", this.isVendorEnabled),
                    o = G.P.value,
                    {
                        enabledVendors: a,
                        disabledVendors: u
                    } = (0, ke.z5)({
                        enabled: (0, Ne.hg)([...i.enabled, ...n.enabled]),
                        disabled: (0, Ne.hg)([...i.disabled, ...n.disabled])
                    });
                return [...a, ...u].forEach((e => {
                    var i, n = null == (i = z.I.value) ? void 0 : i[e];
                    t[e] = {
                        consentToAllPurposes: !n || r({
                            vendor: n,
                            enabledPurposes: s.enabled,
                            disabledPurposes: s.disabled,
                            essentialPurposes: o,
                            enabledVendors: a,
                            disabledVendors: u
                        })
                    }
                })), t
            }
        }
        var Me = {
                setConsent(t, s) {
                    var {
                        purposeId: i,
                        preferenceId: n,
                        channelId: r,
                        data: o = {}
                    } = s, {
                        enabled: a,
                        metadata: u = {},
                        preferenceValue: d
                    } = o, l = (0, h.I8)(t), p = null, c = null;
                    return i ? ((0, h.t8)(l, "purposes." + i + ".id", i), i && n && null != d ? (0, h.t8)(l, "purposes." + i + ".values." + n, {
                        value: d
                    }) : n ? ((0, h.t8)(l, "purposes." + i + ".preferences." + n + ".id", n), r ? (p = "purposes." + i + ".preferences." + n + ".channels." + r, c = r) : (p = "purposes." + i + ".preferences." + n, c = n)) : r ? (p = "purposes." + i + ".channels." + r, c = r) : (p = "purposes." + i, c = i)) : r && (p = "channels." + r, c = r), p && (0, h.t8)(l, p, (0, e.Z)({
                        id: c
                    }, (0, h.U2)(t, "" + p, {}), {
                        metadata: (0, h.ZB)((0, h.U2)(t, p + ".metadata", {}), u),
                        enabled: a
                    })), l
                }
            },
            je = {
                normalizeConsents(t) {
                    void 0 === t && (t = {});
                    var s = {};
                    return t && (t.purposes && Array.isArray(t.purposes) && (s.purposes = {}, t.purposes.forEach((t => {
                        s.purposes[t.id] = (0, e.Z)({}, t, {
                            preferences: {},
                            channels: {}
                        }), t.channels && Array.isArray(t.channels) && t.channels.forEach((i => {
                            s.purposes[t.id].channels[i.id] = (0, e.Z)({}, i)
                        })), t.preferences && Array.isArray(t.preferences) && t.preferences.forEach((i => {
                            s.purposes[t.id].preferences[i.id] = (0, e.Z)({}, i, {
                                channels: {}
                            }), i.channels && Array.isArray(i.channels) && i.channels.forEach((e => {
                                s.purposes[t.id].preferences[i.id].channels[e.id] = e
                            }))
                        }))
                    }))), t.channels && Array.isArray(t.channels) && (s.channels = {}, t.channels.forEach((e => {
                        s.channels[e.id] = e
                    })))), s
                },
                denormalizeConsents(t) {
                    return {
                        purposes: Object.keys(t.purposes || {}).map((s => {
                            var {
                                preferences: i,
                                channels: n
                            } = t.purposes[s];
                            return (0, e.Z)({}, t.purposes[s], {
                                preferences: Object.keys(i || {}).map((t => {
                                    var s = i[t];
                                    return (0, e.Z)({}, s, {
                                        channels: Object.keys(s.channels || {}).map((t => (0, e.Z)({}, s.channels[t])))
                                    })
                                })),
                                channels: Object.keys(n || {}).map((e => n[e]))
                            })
                        })),
                        channels: Object.keys(t.channels || {}).map((e => t.channels[e]))
                    }
                }
            };
        class ze extends O.Z {
            getRemoteConsentsFromAPI(e) {
                var {
                    mergeUsers: t = !1
                } = void 0 === e ? {} : e, s = this.services.UserService.getAuthToken(), i = s && (0, ye.eI)(s);
                return new Promise((e => {
                    if (s && i) {
                        var n = (0, _.getSDKConfigValue)("apiPath") + "/consents/users";
                        if (t) n = n + "/" + i.sub + "?$merge_users=true";
                        K.ajax({
                            method: "GET",
                            url: n,
                            headers: {
                                Authorization: "Bearer " + s,
                                "Content-Type": "application/json"
                            },
                            cors: !0
                        }, ((s, i) => {
                            var n = null;
                            if (404 === s && t) this.actions.setUserAuthenticated(!0), (0, N.j8)("remoteconsent.authenticated", !0);
                            else if (200 === s) {
                                var r;
                                try {
                                    n = JSON.parse(i), t || (n = (0, h.U2)(n, "data", []))[0] && (n = n[0])
                                } catch (e) {}
                                if (n) {
                                    var o = je.normalizeConsents((0, h.U2)(n, "consents", null));
                                    n.consents = o
                                }
                                this.actions.loadRemoteConsents(n), this.actions.setUserAuthenticated(!0), this.actions.setUserId(null == (r = n) ? void 0 : r.id), (0, N.j8)("remoteconsent.authenticated", !0)
                            } else this.actions.setUserAuthenticated(!1), (0, N.j8)("remoteconsent.authenticated", !1), (0, N.V2)(s, "getRemoteConsentUser");
                            (0, N.j8)("remoteconsent.loaded"), e(n)
                        }))
                    } else this.actions.setUserAuthenticated(!1), (0, N.j8)("remoteconsent.loaded"), (0, N.j8)("remoteconsent.authenticated", !1), e(null)
                }))
            }
            getRemoteConsentEventsFromAPI(t) {
                var {
                    cursor: s,
                    query: i
                } = t, n = this.services.UserService.getAuthToken();
                return new Promise((t => {
                    if (n) {
                        var r = (0, e.Z)({}, i || {});
                        s && (r.$cursor = s);
                        var o = Object.keys(r).map((e => e + "=" + encodeURIComponent(r[e]))).join("&");
                        K.ajax({
                            method: "GET",
                            url: (0, _.getSDKConfigValue)("apiPath") + "/consents/events" + (o ? "?" + o : ""),
                            headers: {
                                Authorization: "Bearer " + n,
                                "Content-Type": "application/json"
                            },
                            cors: !0
                        }, ((e, s) => {
                            var i = {};
                            if (200 === e) {
                                try {
                                    i = JSON.parse(s)
                                } catch (e) {}
                                t(i)
                            } else(0, N.V2)(e, "getRemoteConsentEvents");
                            t(i)
                        }))
                    } else t({
                        data: []
                    })
                }))
            }
            setConsent(e, t) {
                var {
                    purposeId: s,
                    preferenceId: i,
                    channelId: n,
                    data: r
                } = t;
                return Me.setConsent(e, {
                    purposeId: s,
                    preferenceId: i,
                    channelId: n,
                    data: r
                })
            }
            getRemoteConsentStatusForAll() {
                return (0, h.I8)((0, h.U2)(this.store.getState(), "remoteConsents"))
            }
            getRemoteConsentEventsForAll(t) {
                return void 0 === t && (t = {}), this.getRemoteConsentEventsFromAPI(t).then((t => {
                    var s = t.data.map((t => (0, e.Z)({}, t, {
                        consents: je.normalizeConsents(t.consents)
                    })));
                    return (0, e.Z)({}, t, {
                        data: s
                    })
                }))
            }
            setRemoteConsentStatusForAll(e) {
                void 0 === e && (e = {});
                var t = this.services.UserService.getAuthToken();
                return new Promise(((s, i) => t ? e.consents && "object" == typeof e.consents ? void K.ajax({
                    method: "POST",
                    url: (0, _.getSDKConfigValue)("apiPath") + "/consents/events",
                    body: JSON.stringify(e),
                    headers: {
                        Authorization: "Bearer " + t,
                        "Content-Type": "application/json"
                    },
                    cors: !0
                }, ((e, t) => {
                    if (201 === e) {
                        var n = {};
                        try {
                            n = JSON.parse(t)
                        } catch (e) {}
                        this.actions.setRemoteConsents(je.normalizeConsents(n.consents)), this.refreshRemoteConsentsFromAPI().then((() => {
                            s()
                        }))
                    } else(0, N.V2)(e, "createRemoteConsentEvent"), i(new Error("Invalid HTTP response code"))
                })) : (console.error("Didomi - Unable to set the remote consent because the consents is empty"), i(new Error("Unable to set the remote consent because the consents is empty"))) : (console.error("Didomi - Unable to set the remote consent because the token is empty"), i(new Error("Unable to set the remote consent because the token is empty")))))
            }
            refreshRemoteConsentsFromAPI(e) {
                return this.getRemoteConsentsFromAPI(e).then((() => {
                    (0, N.j8)("remoteconsent.changed")
                }))
            }
            saveConsentForEntityById(e, t, s, i, n, r, o, a) {
                var u = (0, h.ei)(i, ["enabled", "metadata", "preferenceValue"]),
                    d = this.setConsent({}, {
                        purposeId: e,
                        preferenceId: t,
                        channelId: s,
                        data: u
                    }),
                    l = je.denormalizeConsents(d);
                return this.setRemoteConsentStatusForAll({
                    consents: l,
                    metadata: n,
                    proofs: r,
                    source: o,
                    validation: a
                })
            }
            setPendingConsentForEntityById(e, t, s, i) {
                var n = (0, h.ei)(i, ["enabled", "metadata", "preferenceValue"]);
                this.actions.setPendingConsent({
                    purposeId: e,
                    preferenceId: t,
                    channelId: s,
                    data: n
                }), (0, N.j8)("consent.pendingchanged", {
                    pendingConsents: this.getPendingConsents()
                })
            }
            getPendingConsents() {
                var {
                    pendingConsents: e
                } = this.store.getState();
                return Object.keys(e).map((t => e[t]))
            }
            savePendingConsents(t) {
                void 0 === t && (t = {});
                var s = {};
                this.getPendingConsents().forEach((e => {
                    var {
                        purposeId: t,
                        preferenceId: i,
                        channelId: n,
                        data: r
                    } = e;
                    s = this.setConsent(s, {
                        purposeId: t,
                        preferenceId: i,
                        channelId: n,
                        data: r
                    })
                }));
                var i = je.denormalizeConsents(s);
                return this.setRemoteConsentStatusForAll((0, e.Z)({
                    consents: i
                }, t)).then((() => this.resetPendingConsents()))
            }
            resetPendingConsents() {
                this.actions.resetPendingConsents(), (0, N.j8)("consent.pendingchanged", {
                    pendingConsents: this.getPendingConsents()
                })
            }
            isUserAuthenticated() {
                return (0, h.U2)(this.store.getState(), "isUserAuthenticated")
            }
            getCallbackURL() {
                return (0, h.U2)(this.store.getState(), "callbackURL") || null
            }
            getAuthProtocol() {
                return (0, h.U2)(this.store.getState(), "authProtocol")
            }
            requestAuthenticationURL(e) {
                var {
                    authProviderId: t
                } = void 0 === e ? {} : e, {
                    location: {
                        protocol: s,
                        hostname: i,
                        pathname: n
                    }
                } = document, r = s + "//" + i + n, o = (0, _.getSDKConfigValue)("apiPath"), a = new URL(o);
                return a.pathname = "/auth/initiate", a.searchParams.append("key", J.q.value), a.searchParams.append("privacy_center_url", r), a.searchParams.append("redirect", !1), t && a.searchParams.append("auth_provider_id", t), new Promise((e => {
                    K.ajax({
                        url: a.toString()
                    }, ((t, s) => {
                        if (200 === t) try {
                            var i = JSON.parse(s),
                                n = i.callback,
                                r = i.protocol;
                            this.actions.setCallbackURL(n), this.actions.setAuthProtocol(r), e(n)
                        } catch (t) {
                            console.error("Didomi - " + t.message), e(!1)
                        } else(0, N.V2)(t, "requestAuthentication");
                        e(!1)
                    }))
                }))
            }
            sendLogin(e) {
                var {
                    value: t,
                    channel: s,
                    params: i
                } = e;
                return new Promise(((e, n) => {
                    var r = this.getCallbackURL();
                    if (!r) {
                        var o = "You need to request a callback URL through Didomi.requestAuthenticationURL({ authProviderId })";
                        return console.error("Didomi - " + o), n({
                            error: o
                        })
                    }
                    var a = i ? "&" + encodeURI(Object.keys(i).map((e => "message_params[" + e + "]=" + i[e])).join("&")) : "";
                    K.ajax({
                        method: "GET",
                        url: r + "&channel=" + s + "&id=" + encodeURIComponent(t) + a,
                        cors: !0
                    }, ((t, s) => 200 !== t ? (console.error("Didomi - An error occurred while trying to send the message"), (0, N.V2)(t, "sendMessage"), n({
                        error: s,
                        code: t
                    })) : e()))
                }))
            }
            verifyOtpCode(e) {
                var {
                    organizationUserId: t,
                    code: s,
                    authProviderId: i
                } = void 0 === e ? {} : e, n = (0, _.getSDKConfigValue)("apiPath") + "/auth/protocols/otp/verify", r = new URL(n);
                return r.searchParams.append("key", J.q.value), i && r.searchParams.append("auth_provider_id", i), new Promise(((e, i) => {
                    K.ajax({
                        method: "POST",
                        url: r,
                        body: JSON.stringify({
                            code: s,
                            organization_user_id: t
                        }),
                        headers: {
                            "Content-Type": "application/json"
                        },
                        cors: !0
                    }, ((t, s) => {
                        if (201 !== t) return console.error("Didomi - An error occurred while trying to send the message"), (0, N.V2)(t, "verifyOtpCode"), i({
                            error: s,
                            code: t
                        });
                        var {
                            token: n
                        } = JSON.parse(s);
                        return (0, Le.EV)("didomi_auth_token", n), e({
                            token: n
                        })
                    }))
                }))
            }
        }
        var Ze = o(22222),
            Ge = e => !0 === e.sync.enabled,
            qe = e => !0 === e.sync.delayNotice,
            He = e => e.sync.timeout,
            We = (0, Ze.P1)((e => e.sync.frequency), ke.Pe, ((e, t) => !t || !e || !!(Math.floor((new Date - t) / 1e3) >= e))),
            Ke = (0, Ze.P1)(D.cY, ke.fi, ((e, t) => !(null == t || !t.organizationUserId) && t.organizationUserId !== e)),
            Je = (0, Ze.P1)(Ge, D.cY, D._e, We, Ke, ((e, t, s, i, n) => !0 === e && "string" == typeof t && t.length > 0 && !1 === s && (i || n))),
            Qe = e => e.signature.value,
            $e = o(8861),
            Ye = o(17832),
            Xe = o(1151);
        class et extends O.Z {
            configure(e) {
                if (e) {
                    var t = {};
                    e.storageSources && (t.storageSources = {
                        cookies: !1 !== e.storageSources.cookies,
                        localStorage: !1 !== e.storageSources.localStorage
                    }), t.secure = e.secure, this.actions.setStorageConfig(t), this.services.ThirdPartyCookiesService.configure(e, this.store.getState().cookies.storageSources), this.services.LocalCookiesService.configure(e, this.store.getState().cookies.storageSources)
                }
            }
            getStorageSources() {
                return this.store.getState().cookies.storageSources
            }
            areThirdPartyCookiesEnabled() {
                return this.services.ThirdPartyCookiesService.isEnabled()
            }
            initStorages(e) {
                this.services.ThirdPartyCookiesService.initThirdParties((() => {
                    this.services.CEDService.initDidomiConsentStringEncoderDecoder(e)
                }))
            }
            getNewToken() {
                var e = this.services.LocalStoreService.getInitialState(),
                    t = (0, g.G4)();
                return e.created = t, e.updated = t, e
            }
            createNewToken(e) {
                void 0 === e && (e = null);
                var t = this.getNewToken();
                return e && (0, h.t8)(t, "user_id", e), this.resetIABToken(), this.setTokenToStorages(t), t
            }
            initStoreFromStorage() {
                var e = this.store.getState(),
                    t = this.getTokenFromCookies(),
                    s = t.token,
                    i = this.fixConsentString(t.iabConsentString, s),
                    n = t.didomiTokenCreatedFromIABToken,
                    r = t.userAuthParams,
                    o = t.signature,
                    a = t.dcsUserId;
                return (0, D.$P)(e, s) ? (s = this.reset(s.user_id), n = !1) : s && n ? this.setTokenToStorages(s, !0, r, {
                    signature: o,
                    dcsUserId: a
                }) : s ? (r && this.setTokenUserAuthParams(r), this.services.SignatureService.setSignature({
                    signature: o,
                    dcsUserId: a
                }), this.setTokenToLocalStore(s), this.setConsentStringToLocalStore(i)) : s = this.createNewToken(), this.syncLocalAndThirdPartyStorage(), {
                    token: s,
                    didomiTokenCreatedFromIABToken: n
                }
            }
            fixConsentString(e, t) {
                if (void 0 === t && (t = null), !e) return e;
                var s = this.services.TCFService.fixConsentString(e, t);
                return s !== e ? (this.setCookies({
                    iabConsentString: s
                }), s) : e
            }
            setTokenToStorages(e, t, s, i) {
                void 0 === t && (t = !0), void 0 === s && (s = null), void 0 === i && (i = null), t && (e = this.updateToken(e));
                var n = this.createConsentCookiesFromToken(e);
                return this.setCookies(n), s && this.setTokenUserAuthParams(s), i && this.services.SignatureService.setSignature(i), this.setTokenToLocalStore(e), this.setConsentStringToLocalStore(n.iabConsentString), e
            }
            flushTokenToStorage() {
                var e = this.getTokenFromLocalStore();
                this.setTokenToStorages(e, !1)
            }
            updateToken(e) {
                var t = (0, h.I8)(e),
                    s = (0, g.G4)();
                return t.updated = s, (0, ee.F)(t.created) && (t.created = s), t
            }
            getEncode() {
                var e;
                if (null != (e = $.L.value) && e.isDidomiConsentStringEncodingEnabled) return this.services.CEDService.encode.bind(this.services.CEDService)
            }
            getDecode() {
                var e;
                if (null != (e = $.L.value) && e.isDidomiConsentStringEncodingEnabled) return this.services.CEDService.decode.bind(this.services.CEDService)
            }
            createConsentCookiesFromToken(e) {
                var t = (0, h.I8)(e),
                    s = null,
                    i = (0, h.U2)(t, "vendors.enabled") || [],
                    n = (0, h.U2)(t, "vendors.disabled") || [],
                    r = (0, h.U2)(t, "vendors_li.enabled") || [],
                    o = (0, h.U2)(t, "vendors_li.disabled") || [];
                if (i.length || n.length || r.length || o.length) {
                    var a;
                    s = this.services.TCFService.tokenToIABConsentString(t, P.S.value, (null == (a = $e.c.value) ? void 0 : a.purposes) || [], Ye._.value, !0);
                    var u = this.services.TCFService.atpTokenFromDidomiToken((0, h.I8)(t));
                    t = this.services.TCFService.removeATPVendorsFromDidomiToken(t), u && (t.ac = u)
                }
                var d = Object.keys(this.services.TCFService.getIABVisiblePurposesMap());
                return {
                    iabConsentString: s,
                    didomiTokenAsBase64: (0, ye.$A)(t, d, this.getEncode())
                }
            }
            setCookies(e) {
                var t, {
                        iabConsentString: s,
                        didomiTokenAsBase64: i
                    } = e,
                    n = this.store.getState();
                if (null != (t = $.L.value) && t.isDidomiConsentStringEncodingEnabled) {
                    var r, o = (e => e.signature.dcsUserId)(n) || "",
                        a = Qe(n) ? "~" + Qe(n) : "",
                        u = "",
                        d = (null == (r = (0, ke.Pe)(n)) ? void 0 : r.getTime()) || "";
                    if (Ge(n)) {
                        var l = (0, D.Ex)(n);
                        u = this.services.CEDService.encodeUserAuthParams(l)
                    }
                    i = i + "." + o + "." + u + "." + d + a
                }
                return B("setCookies", (() => {
                    this.services.ThirdPartyCookiesService.hasEnabledThirdParties() ? (this.services.ThirdPartyCookiesService.setEnabledCookies(i, s), this.services.LocalCookiesService.setLocalCookies(null, s)) : this.services.LocalCookiesService.setLocalCookies(i, s)
                }))()
            }
            getCookies() {
                return B("getCookies", (() => {
                    var e = this.services.ThirdPartyCookiesService.getEnabledCookies(),
                        t = this.services.LocalCookiesService.getLocalCookies();
                    return this.setCookiesInLocalStore(e, t), null !== e ? e : t
                }))(this.getNewToken())
            }
            setCookiesInLocalStore(e, t) {
                this.actions.setThirdPartyCookiesData(e), this.actions.setLocalCookiesData(t)
            }
            getTokenFromCookies() {
                var t, s = this.getCookies(),
                    i = null;
                s.iabConsentString && ((i = this.services.TCFService.decodeIABConsentString(s.iabConsentString, !1 === this.services.ThirdPartyCookiesService.hasEnabledThirdParties())) || console.error("Didomi - Failed to decode TCF consent string from cookies: " + s.iabConsentString));
                var n = (0, me.t0)(s.didomiToken) ? (0, ye.Kw)((0, me.t0)(s.didomiToken), this.getDecode()) : null,
                    r = null,
                    o = (0, me.iN)(s.didomiToken),
                    a = (0, me.Pe)(s.didomiToken),
                    u = (0, me.o$)(s.didomiToken),
                    d = (0, me.Nw)(s.didomiToken);
                null != (t = $.L.value) && t.isDidomiConsentStringEncodingEnabled && o && (r = this.services.CEDService.decodeUserAuthParams(o));
                var l = (0, h.U2)(n, "ac"),
                    p = {
                        didomiToken: n,
                        iabToken: i,
                        addtlConsent: l ? this.services.TCFService.decodeAddtlConsent(l) : null
                    },
                    c = this.mergeTokens(p.didomiToken, p.iabToken, p.addtlConsent),
                    f = c ? (0, e.Z)({}, c, {
                        sync: a || c.sync
                    }) : null;
                return {
                    didomiTokenCreatedFromIABToken: c && p.iabToken && !p.didomiToken,
                    token: f,
                    iabConsentString: i ? s.iabConsentString : null,
                    userAuthParams: r,
                    signature: u,
                    dcsUserId: d
                }
            }
            mergeTokens(e, t, s) {
                if (!e && !t && !s) return null;
                var i, n, r, o, a, u = (0, h.I8)(e) || this.services.LocalStoreService.getInitialState();
                if (t) {
                    var d, l = this.services.TCFService.getMaxVendorID(t),
                        p = this.services.TCFService.getIABVisiblePurposesMap(),
                        c = Object.keys(p),
                        f = null == (a = null == (i = Ye._.value) || null == (n = i.filter((e => "iab" !== e.namespace))) ? void 0 : n.filter((e => (0, x.xf)(e))).map((e => (0, x.MB)(e))), d = null == (r = Xe.z.value) || null == (o = r.vendors) ? void 0 : o.filter((e => !a.includes(e.id)))) ? void 0 : d.filter((e => e.id <= l)).map((e => e.id)),
                        v = (0, h.U2)(u, "vendors.enabled", []).filter((e => -1 === f.indexOf(e))),
                        g = (0, h.U2)(u, "vendors.disabled", []).filter((e => -1 === f.indexOf(e))),
                        m = (0, h.U2)(u, "vendors_li.enabled", []).filter((e => -1 === f.indexOf(e))),
                        b = (0, h.U2)(u, "vendors_li.disabled", []).filter((e => -1 === f.indexOf(e))),
                        S = (0, h.U2)(u, "purposes.enabled", []).filter((e => -1 === c.indexOf(e))),
                        C = (0, h.U2)(u, "purposes.disabled", []).filter((e => -1 === c.indexOf(e))),
                        y = (0, h.U2)(u, "purposes_li.enabled", []).filter((e => -1 === c.indexOf(e))),
                        w = (0, h.U2)(u, "purposes_li.disabled", []).filter((e => -1 === c.indexOf(e))),
                        {
                            enabledIABvendors: I,
                            disabledIABvendors: _,
                            enabledIABpurposes: P,
                            disabledIABpurposes: A,
                            enabledLIIABvendors: k,
                            disabledLIIABvendors: T,
                            enabledLIIABpurposes: E,
                            disabledLIIABpurposes: L
                        } = this.services.TCFService.getVendorsAndPurposesStatuses(t, f, p),
                        U = (0, h.U2)(s, "vendors.enabled", []),
                        O = (0, h.U2)(s, "vendors.disabled", []),
                        D = (0, h.U2)(s, "vendors_li.enabled", []),
                        V = (0, h.U2)(s, "vendors_li.disabled", []);
                    (0, h.t8)(u, "vendors.enabled", [...v, ...I, ...U]), (0, h.t8)(u, "vendors.disabled", [...g, ..._, ...O]), (0, h.t8)(u, "vendors_li.enabled", [...m, ...k, ...D]), (0, h.t8)(u, "vendors_li.disabled", [...b, ...T, ...V]), (0, h.t8)(u, "purposes.enabled", [...S, ...P]), (0, h.t8)(u, "purposes.disabled", [...C, ...A]), (0, h.t8)(u, "purposes_li.enabled", [...y, ...E]), (0, h.t8)(u, "purposes_li.disabled", [...w, ...L])
                }
                return u
            }
            getTokenFromLocalStore() {
                return this.services.LocalStoreService.getUserConsentToken()
            }
            setTokenToLocalStore(e) {
                this.services.LocalStoreService.setConsentToken(e)
            }
            setTokenUserAuthParams(e) {
                this.services.LocalStoreService.setTokenUserAuthParams(e)
            }
            getConsentStringFromLocalStore() {
                return this.services.LocalStoreService.getConsentString()
            }
            setConsentStringToLocalStore(e) {
                this.services.LocalStoreService.setConsentString(e)
            }
            syncLocalAndThirdPartyStorage() {
                if (this.services.ThirdPartyCookiesService.hasEnabledThirdParties()) {
                    var e = this.store.getState(),
                        t = (0, V.vr)(e);
                    if (t) {
                        var s = (0, V.QH)(e);
                        s && t !== s && this.services.LocalCookiesService.setLocalCookies(null, s)
                    }
                }
            }
            reset(e) {
                return this.createNewToken(e)
            }
            resetIABToken() {
                B("resetCookies", (() => {
                    this.services.LocalCookiesService.resetIABToken(), this.services.ThirdPartyCookiesService.resetIABToken()
                }))()
            }
        }
        var tt = o(43427),
            st = o(44891);
        class it extends et {
            initStoreFromStorage() {
                var e = this.getTokenFromCookies().token;
                return (0, D.$P)(this.store.getState(), e) ? e = this.reset(e.user_id) : e ? (!0 === st.N && (e = this.createNewToken(e.user_id)), this.setTokenToLocalStore(e)) : e = this.createNewToken(), {
                    token: e
                }
            }
            getTokenFromCookies() {
                var e = this.getCookies();
                return {
                    token: e.didomiToken ? (0, ye.Kw)(e.didomiToken, this.getDecode()) : null
                }
            }
            createNewToken(e) {
                void 0 === e && (e = null);
                var t = this.getNewToken();
                return e && (0, h.t8)(t, "user_id", e), this.setTokenToStorages(t), t
            }
            setTokenToStorages(e, t) {
                void 0 === t && (t = !0), t && (e = this.updateToken(e));
                var s = (0, h.I8)(e);
                (0, ye.qB)(s, "purposes"), (0, ye.qB)(s, "purposes_li"), (0, ye.qB)(s, "vendors"), (0, ye.qB)(s, "vendors_li");
                var i = this.getEncode();
                return this.setCookies({
                    didomiTokenAsBase64: i ? i(s) : tt.DS.btoa(JSON.stringify(s))
                }), this.setTokenToLocalStore(e), e
            }
            getTokenFromLocalStore() {
                return this.store.getState().mixed
            }
            setTokenToLocalStore(e) {
                this.actions.setMixed(e)
            }
            getEncode() {
                var e;
                if (null != (e = $.L.value) && e.isDidomiConsentStringEncodingEnabled) return this.services.CEDService.encode.bind(this.services.CEDService)
            }
            getDecode() {
                var e;
                if (null != (e = $.L.value) && e.isDidomiConsentStringEncodingEnabled) return this.services.CEDService.decode.bind(this.services.CEDService)
            }
            setCookies(e) {
                var {
                    didomiTokenAsBase64: t
                } = e;
                return B("setCookies", (() => {
                    this.services.ThirdPartyCookiesService.hasEnabledThirdParties() ? this.services.ThirdPartyCookiesService.setEnabledCookies(t) : this.services.LocalCookiesService.setLocalCookies(t)
                }))()
            }
        }
        class nt extends Be {
            getInitialState() {
                var e = !1 === st.N ? "agree" : !0 === st.N ? "disagree" : "default",
                    t = (0, h.I8)(Fe.initialState.mixed),
                    s = this.store.getState(),
                    i = (0, Pe.IR)(s),
                    n = (0, R.Qj)(s);
                return "agree" === e ? (t.vendors_li.enabled = j.V.value, t.purposes_li.enabled = n, t.purposes.enabled = i) : "disagree" === e && (t.vendors_li.disabled = j.V.value, t.purposes_li.disabled = n, t.purposes.disabled = i), Object.assign({}, t)
            }
        }
        class rt extends Ve {
            setCookie(e) {
                var t = (0, R.EC)(this.store.getState());
                e && this.group.iframe.setToken(xe.value, e, this.services.StorageService.getStorageSources(), this.isSameSiteRequired(), t)
            }
            setEnabledCookies(e) {
                this.isThirdPartyActive() && this.setCookie(e)
            }
            getEnabledCookies() {
                return this.isThirdPartyActive() ? this.getCookie() : null
            }
            getCookie() {
                return {
                    didomiToken: this.group.didomiToken
                }
            }
            getTokenFromIframe(e, t, s) {
                if (void 0 === t && (t = {}), this.iframesCalled += 1, e && "Timeout" === e.message) this.iframesError += 1, this.group.iframeNotResponding = !0, !this.callbackCalled && this.hasTriedLoadingAllEnabledThirdParties() && (this.callbackCalled = !0, s());
                else {
                    if (t.didomi_accept_cookie) {
                        var i = null;
                        t.didomi_token && (i = t.didomi_token), this[t.didomi_type].didomiToken = i
                    } else this.iframesDisabled += 1, (0, Le.EV)("didomi_third_party_cookie", !1, this.services.LocalCookiesService.getCookieDomain(), this.services.StorageService.getStorageSources(), !1, !1, (0, R.EC)(this.store.getState()));
                    !this.callbackCalled && this.hasTriedLoadingAllEnabledThirdParties() && (this.callbackCalled = !0, s())
                }
            }
        }
        class ot extends Re {
            getLocalCookies() {
                return (0, Le.Y9)(xe.value, null, this.storageSources)
            }
            setLocalCookies(e) {
                var t = this.getCookieDomain(),
                    s = (0, R.EC)(this.store.getState());
                e && (0, Le.EV)(xe.value, e, t, this.services.StorageService.getStorageSources(), !1, this.isSameSiteRequired(), s)
            }
        }
        var at = o(75211),
            ut = e => e.mixed.vendors.enabled || [],
            dt = e => e.mixed.vendors_li.enabled || [],
            lt = e => e.mixed.purposes_li.enabled || [],
            pt = e => e.mixed.purposes.enabled || [],
            ct = (0, Ze.P1)([lt, pt, R.sN], ((e, t, s) => {
                var i = (0, Ne.hg)([...t, ...e]),
                    n = s.filter((e => -1 === i.indexOf(e)));
                return {
                    enabled: i,
                    disabled: n
                }
            })),
            ft = (0, Ze.P1)([ut, e => e.mixed.vendors.disabled || [], dt, e => e.mixed.vendors_li.disabled || []], ((e, t, s, i) => (0, Ne.hg)([...e, ...t, ...s, ...i, ...Z.O.value]))),
            vt = (0, Ze.P1)([pt, ft], ((e, t) => {
                var s = t.filter((t => {
                        var s;
                        return !(null == (s = z.I.value) || !s[t]) && (0, at.L)((0, h.Ri)(z.I.value[t].purposeIds), e)
                    })),
                    i = t.filter((e => -1 === s.indexOf(e)));
                return {
                    enabled: s,
                    disabled: i
                }
            })),
            ht = (0, Ze.P1)([lt, dt, ft], ((e, t, s) => {
                var i = t.filter((t => {
                        var s;
                        return !(null == (s = z.I.value) || !s[t]) && (0, at.L)((0, h.Ri)(z.I.value[t].legIntPurposeIds), e)
                    })),
                    n = s.filter((e => -1 === i.indexOf(e)));
                return {
                    enabled: i,
                    disabled: n
                }
            })),
            gt = (0, Ze.P1)([pt, lt, ut, dt, ft], ((e, t, s, i, n) => {
                var r = (0, Ne.hg)([...s, ...i]).filter((s => {
                        var i;
                        if (null != (i = z.I.value) && i[s]) {
                            var n = [...(0, h.Ri)(z.I.value[s].purposeIds), ...(0, h.Ri)(z.I.value[s].legIntPurposeIds)],
                                r = [...e, ...t];
                            return (0, at.L)(n, r)
                        }
                        return !1
                    })),
                    o = n.filter((e => -1 === r.indexOf(e)));
                return {
                    enabled: r,
                    disabled: o
                }
            })),
            mt = (0, Ze.P1)([e => e.mixed, ct, gt, vt, ht], ((e, t, s, i, n) => ({
                purposes: {
                    consent: {
                        enabled: (0, h.U2)(e, "purposes.enabled"),
                        disabled: (0, h.U2)(e, "purposes.disabled")
                    },
                    legitimate_interest: {
                        enabled: (0, h.U2)(e, "purposes_li.enabled"),
                        disabled: (0, h.U2)(e, "purposes_li.disabled")
                    },
                    global: t
                },
                vendors: {
                    consent: {
                        enabled: (0, h.U2)(e, "vendors.enabled"),
                        disabled: (0, h.U2)(e, "vendors.disabled")
                    },
                    legitimate_interest: {
                        enabled: (0, h.U2)(e, "vendors_li.enabled"),
                        disabled: (0, h.U2)(e, "vendors_li.disabled")
                    },
                    global: s,
                    global_consent: i,
                    global_li: n
                },
                user_id: e.user_id,
                created: e.created,
                updated: e.updated
            })));
        class bt extends H {
            setUserStatus(e) {
                var t = (0, h.U2)(e, "purposes.consent.enabled", []),
                    s = (0, h.U2)(e, "purposes.consent.disabled", []),
                    i = (0, h.U2)(e, "purposes.legitimate_interest.enabled", []),
                    n = (0, h.U2)(e, "purposes.legitimate_interest.disabled", []),
                    r = (0, h.U2)(e, "vendors.legitimate_interest.enabled", []),
                    o = (0, h.U2)(e, "vendors.legitimate_interest.disabled", []),
                    a = (0, h.U2)(e, "created"),
                    u = (0, h.U2)(e, "updated"),
                    d = (0, h.U2)(e, "action"),
                    l = this.services.StorageService.getTokenFromLocalStore(),
                    p = (0, h.I8)(l);
                p.vendors_li = {
                    enabled: r,
                    disabled: o
                }, p.purposes = {
                    enabled: t,
                    disabled: s
                }, p.purposes_li = {
                    enabled: i,
                    disabled: n
                }, a && (p.created = a), u && (p.updated = u);
                var c = !Boolean(a) && !Boolean(u);
                (0, h.vZ)(l, p) && !(0, D.s_)(this.store.getState()) || (p = this.services.StorageService.setTokenToStorages(p, c), this.sendEvents(p, d)), this.removeScrollListener(window.scrollListener)
            }
            getUserStatus() {
                return (0, h.I8)(mt(this.store.getState()))
            }
            setStateFromToken() {
                var e, t, s = this.getUserStatus(),
                    i = s.purposes.consent,
                    n = s.purposes.legitimate_interest,
                    r = s.vendors.legitimate_interest;
                i.enabled.forEach((e => {
                    this.actions.setSPIPurposesState(e, !0)
                })), i.disabled.forEach((e => {
                    this.actions.setSPIPurposesState(e, !1)
                })), n.enabled.forEach((e => {
                    this.actions.setPurposeState(e, !0)
                })), n.disabled.forEach((e => {
                    this.actions.setPurposeState(e, !1)
                })), r.enabled.forEach((e => {
                    this.actions.setVendorState(e, !0)
                })), r.disabled.forEach((e => {
                    this.actions.setVendorState(e, !1)
                })), this.actions.setAllSPIUseState(this.globalStateFromGranularChoices(i.enabled, i.disabled)), this.actions.setAllVendorsState(this.globalStateFromGranularChoices(r.enabled, r.disabled));
                var o = this.store.getState(),
                    a = (0, Pe.H$)(o);
                null == (e = fe.c.value) || null == (t = e.categories) || t.forEach((e => {
                    this.actions.setCategoryState(e.id, (0, Ne.B9)(e.children.map((e => a[e.purposeId]))))
                }))
            }
            globalStateFromGranularChoices(e, t) {
                if (!(e.length > 0 && t.length > 0)) return e.length > 0 && 0 === t.length || !(0 === e.length && t.length > 0) && void 0
            }
            saveUserChoices() {
                var e = this.store.getState(),
                    t = (0, Pe.d5)(e),
                    s = (0, Pe.H$)(e),
                    i = (0, Pe.vK)(e),
                    n = new E.Z(this.getUserStatus.bind(this), this.setUserStatus.bind(this), "click");
                Object.keys(t).forEach((e => {
                    !0 === t[e] ? n.enablePurpose(e) : n.disablePurpose(e)
                })), Object.keys(s).forEach((e => {
                    !0 === s[e] ? n.enablePurposeLegitimateInterest(e) : n.disablePurposeLegitimateInterest(e)
                })), Object.keys(i).forEach((e => {
                    !0 === i[e] ? n.enableVendorLegitimateInterests(e) : n.disableVendorLegitimateInterests(e)
                })), n.commit()
            }
            setUserAgreeToAll(e) {
                var t, s = this.store.getState(),
                    i = (0, R.Qj)(s);
                if (0 !== i.length && null != (t = j.V.value) && t.length) {
                    var n = new E.Z(this.getUserStatus.bind(this), this.setUserStatus.bind(this), e);
                    n.enablePurposesLegitimateInterests(...i), n.enableVendorsLegitimateInterests(...j.V.value), n.commit()
                }
            }
            hasAllConsentStatus(e, t) {
                var s = [];
                for (var i of e) "consent" === i.legalBasis ? s.push(this.getUserConsentStatusByPurpose(i.id)) : "legitimate_interest" === i.legalBasis && s.push(this.getLegitimateInterestStatusForPurpose(i.id));
                for (var n of t) Array.isArray(n.legIntPurposeIds) && n.legIntPurposeIds.length > 0 && s.push(this.getLegitimateInterestStatusForVendor(n.id));
                return !1 === s.some((e => void 0 === e))
            }
            shouldWeSendConsentGiven(e) {
                return "sync" !== e && (!1 !== (0, v.getNoticeConfigValue)("notice.showWhenGPCIsEnabled") || !st.k || this.services.WebsiteService.mixedConsentInformationExists())
            }
            sendEvents(e, t) {
                var {
                    purposes: s,
                    purposes_li: i,
                    vendors: n,
                    vendors_li: r,
                    created: o,
                    updated: a
                } = e;
                this.shouldWeSendConsentGiven(t) && this.services.EventsService.sendConsentGiven({
                    purposes: s,
                    purposes_li: i,
                    vendors: n,
                    vendors_li: r,
                    created: o,
                    updated: a,
                    action: "string" == typeof t ? t : void 0
                }, "navigate" === t), (0, N.j8)("internal.consent.changed"), (0, N.j8)("consent.changed", {
                    fromEUConsent: !1,
                    action: t
                }), this.setBrowserCookieState(i.enabled)
            }
        }
        var St = (0, C.Fl)((() => {
            var e, t;
            return !1 !== (null == v.noticeConfig || null == (e = v.noticeConfig.value) || null == (t = e.notice) ? void 0 : t.showWhenGPCIsEnabled) || !st.k
        }));
        class Ct extends X {
            init() {
                var e, t, s, i, n = this.store.getState().events;
                null != (e = v.noticeConfig.value) && null != (t = e.regulation) && t.name && (0, h.t8)(n, "template.user.regs", [null == (s = v.noticeConfig.value) || null == (i = s.regulation) ? void 0 : i.name]);
                if (this.services.WebsiteService.shouldWeIncludePrivacyControlInEvents()) {
                    var r = {
                        type: st.k ? "gpc" : "none",
                        notice_action: St.value ? "shown" : "hidden"
                    };
                    (0, h.t8)(n, "template.source.privacy_control", r)
                }
                return this.actions.setEventsConfig(n), n.template
            }
        }
        var yt = o(60457);

        function wt(e) {
            return !0 === e ? "Y" : "N"
        }
        class It {
            constructor() {
                this.initialized = !1, this.uspSignal = {
                    ccpaApplies: !1,
                    noticeDisplayed: !1,
                    doNotSell: !1,
                    lspa: !1,
                    string: null
                }
            }
            init(e, t, s, i) {
                this.initialized || (this.initialized = !0, this.setUSPData(e, t, s, i), window.__uspapi = this.handleCommand.bind(this), (0, yt.SH)("__uspapiCall", "__uspapiReturn", this.handleCommand.bind(this), window.__uspapiBuffer))
            }
            getUSPData() {
                return {
                    version: 1,
                    uspString: this.uspSignal.string
                }
            }
            handleCommand(e, t, s) {
                if ("function" == typeof s && "getUSPData" === e) s(this.getUSPData(t), !0)
            }
            setDoNotSellStatus(e) {
                this.setUSPData(this.uspSignal.ccpaApplies, this.uspSignal.noticeDisplayed, e, this.uspSignal.lspa)
            }
            setUSPData(e, t, s, i) {
                this.uspSignal.ccpaApplies = e, this.uspSignal.noticeDisplayed = t, this.uspSignal.doNotSell = s, this.uspSignal.lspa = i, this.uspSignal.ccpaApplies ? this.uspSignal.string = "1" + wt(this.uspSignal.noticeDisplayed) + wt(this.uspSignal.doNotSell) + wt(this.uspSignal.lspa) : this.uspSignal.string = "1---"
            }
        }
        class _t extends O.Z {
            constructor(e, t, s) {
                super(e, t, s), this.USPAPI = new It
            }
            run() {
                var e, t;
                this.USPAPI.init("ccpa" === (null == (e = v.noticeConfig.value) || null == (t = e.regulation) ? void 0 : t.name), !0, this.getDoNotSellStatus(), !0 === (0, h.U2)(this.store.getState(), "website.regulations.ccpa.lspa"))
            }
            getDoNotSellStatus() {
                return !0 === this.services.StorageService.getTokenFromLocalStore().dns
            }
            setDoNotSellStatus(e) {
                if (this.getDoNotSellStatus() !== e) {
                    var t = (0, h.I8)(this.services.StorageService.getTokenFromLocalStore());
                    t.dns = e, this.services.StorageService.setTokenToStorages(t), this.USPAPI.setDoNotSellStatus(e), this.services.ConsentService.sendEvents(t, !1, "click")
                }
            }
            getDoNotSellNoticeDate() {
                return (0, h.U2)(this.services.StorageService.getTokenFromLocalStore(), "dnsd")
            }
            updateDoNotSellNoticeDate() {
                var e = (0, h.I8)(this.services.StorageService.getTokenFromLocalStore());
                e.dnsd = (new Date).toISOString(), this.services.StorageService.setTokenToStorages(e)
            }
            shouldShowNotice() {
                return !this.getDoNotSellNoticeDate()
            }
        }
        class Pt extends _t {
            run() {
                var e, t;
                this.USPAPI.init("ccpa" === (null == (e = v.noticeConfig.value) || null == (t = e.regulation) ? void 0 : t.name), !0, this.getDoNotSellStatus(), !0 === (0, h.U2)(this.store.getState(), "website.regulation.ccpa.lspa"))
            }
        }
        var At = (e, t, s) => {
                e.EventsService = new Ct(t, s, e), e.EventsService.init(), e.LocalStoreService = new nt(t, s, e), e.ThirdPartyCookiesService = new rt(t, s, e), e.LocalCookiesService = new ot(t, s, e), e.StorageService = new it(t, s, e), e.ConsentService = new bt(t, s, e), e.MixedRegulationService.run()
            },
            kt = (e, t, s) => {
                var i, n;
                "ccpa" === (null == (i = v.noticeConfig.value) || null == (n = i.regulation) ? void 0 : n.name) && (e.CCPAService = new Pt(t, s, e))
            };
        class Tt extends Te {
            handleMixedRegulationConsentNoticeStatus() {
                var e = (0, D.PR)(this.store.getState());
                e.bots && !1 === e.bots.consentRequired && e.isBot || (this.mixedConsentInformationExists() ? (this.services.ConsentService.setStateFromToken(), St.value && st.k && this.services.NoticeService.show()) : st.k ? St.value && this.services.NoticeService.show() : this.services.NoticeService.show())
            }
            shouldMixedRegulationNoticeBeShown() {
                var e = (0, D.PR)(this.store.getState());
                return (!e.bots || !1 !== e.bots.consentRequired || !e.isBot) && (this.mixedConsentInformationExists() ? St.value && st.k : st.k || St.value)
            }
            determineConsentNoticeStatus() {
                var e = this.store.getState();
                if ((0, R.T5)(e)) this.handleMixedRegulationConsentNoticeStatus();
                else if ((0, R.f$)(e) && this.services.CCPAService.shouldShowNotice()) this.services.NoticeService.show();
                else if ((0, R.uE)(e) && this.shouldConsentBeCollected()) {
                    var t;
                    this.services.NoticeService.show(), null != (t = fe.c.value) && t.showWhenConsentIsMissing && this.services.PreferencesService.show()
                } else {
                    var s;
                    this.services.NoticeService.hide(), null != (s = fe.c.value) && s.showWhenConsentIsMissing && this.services.PreferencesService.hide()
                }
            }
            shouldNoticeBeShown() {
                var e = this.store.getState();
                return (0, R.T5)(e) ? this.shouldMixedRegulationNoticeBeShown() : (0, R.f$)(e) ? this.services.CCPAService.shouldShowNotice() : !!(0, R.uE)(e) && this.shouldConsentBeCollected()
            }
            getRegulationGroupName() {
                return (0, R.th)(this.store.getState())
            }
            mixedConsentInformationExists() {
                return !0 === this.services.ConsentService.hasAllConsentStatus(this.getPurposesFromAllLegalBases(), be.r.value)
            }
            shouldWeIncludePrivacyControlInEvents() {
                return "mixed" === this.getRegulationGroupName()
            }
        }
        class Et extends O.Z {
            configure(e) {
                var t, s, i;
                if (!e || "object" != typeof e) return null;
                if ("object" == typeof e.configByCountry && null != (t = y.value) && t.country) {
                    var n = e.configByCountry[y.value.country.toUpperCase()];
                    n && (e = (0, h.rd)(e, n))
                }
                if (e.privacyPolicyURL && (0, h.t8)(e, "website.privacyPolicyURL", e.privacyPolicyURL), e.website || e.app) {
                    var r = (0, h.rd)(e.website, e.app);
                    e.regulations && (r.regulations = e.regulations), e.regulation && (r.regulation = e.regulation), e.version && (r.version = e.version, this.services.WebsiteService = new Tt(this.store, this.actions, this.services)), this.services.WebsiteService.configure(r)
                }(this.services.StorageService.configure(e.cookies), "object" == typeof e.user && (Array.isArray(e.synchronizedUsers) && e.synchronizedUsers.length > 0 && (e.user.synchronizedUsers = e.synchronizedUsers), delete e.synchronizedUsers, "object" == typeof e.dcsUser && (e.user.dcsUser = e.dcsUser), delete e.dcsUser, this.services.UserService.configure(e.user)), "object" == typeof e.sync && this.services.SyncService.configure(e.sync), e.notice && this.services.NoticeService.configure(e.notice), e.preferences) && (this.services.PreferencesService.configure(e.preferences), "mixed" === (null == (s = e.regulation) || null == (i = s.group) ? void 0 : i.name) && this.services.MixedRegulationService.configure(e.preferences));
                (this.services.TagManagersService.configure("didomi"), e.tagManager) && (0, h.U2)(e, "tagManager.provider", "").split("|").filter((e => e && "didomi" !== e)).forEach((t => {
                    this.services.TagManagersService.configure(t, e.tagManager)
                }));
                return this.services.ComponentsService.configure(e.components), this.services.EventsService.configure(e.events), e.experiment && this.services.ExperimentsService.configure(e.experiment), e.integrations && this.services.IntegrationsService.configure(e.integrations), (e.website || e.app) && e.version && ((e, t, s) => {
                    "optout" === e.WebsiteService.getRegulationGroupName() && kt(e, t, s), "mixed" === e.WebsiteService.getRegulationGroupName() && At(e, t, s)
                })(this.services, this.store, this.actions), e
            }
        }
        var Lt, Ut = o(15861),
            Ot = () => {
                Lt || ((Lt = document.createElement("div")).id = "didomi-host", Lt.setAttribute("data-nosnippet", "true"), Lt.setAttribute("aria-hidden", "true"), document.body.insertBefore(Lt, document.body.firstChild))
            };
        class xt extends O.Z {
            constructor() {
                super(...arguments), this._uiModule = null, this._postRenderActions = []
            }
            componentWillMount() {
                this._postRenderActions = []
            }
            show(e) {
                void 0 === e && (e = () => {}), this.isRendered() ? e() : (e && this._postRenderActions.push(e), this.isLoading() || this.isLoaded() || this.loadUI(), this.scheduleRender())
            }
            scheduleRender() {
                this.isLoaded() ? this.renderUI() : this.isRenderScheduled() || (0, N.IH)("ui.loaded", (() => {
                    this.renderUI()
                }))
            }
            preLoad() {
                this.isRendered() || this.isLoaded() || this.isLoading() || this.loadUI()
            }
            renderUI() {
                (0, N.IH)("ui.mounted", (() => {
                    this.actions.renderedUI(), this.completePostRenderActions().then((() => {
                        (0, N.j8)("ui.ready")
                    }))
                }));
                try {
                    this._uiModule(Lt, this.store, this.services)
                } catch (e) {
                    throw new Error("Error while rendering the SDK UI: Module not loaded")
                }
            }
            completePostRenderActions() {
                var e = this;
                return (0, Ut.Z)((function*() {
                    e._postRenderActions.length > 0 && Promise.all(e._postRenderActions.map(function() {
                        var e = (0, Ut.Z)((function*(e) {
                            return "function" == typeof e ? yield e(): Promise.resolve()
                        }));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }())).then((() => {
                        e._postRenderActions = []
                    }))
                }))()
            }
            isLoading() {
                return (0, h.U2)(this.store.getState(), "ui.loading") || !1
            }
            isLoaded() {
                return (0, h.U2)(this.store.getState(), "ui.loaded") || !1
            }
            isRenderScheduled() {
                return (0, N.xS)("ui.loaded") >= 1 && !this.isRendered()
            }
            isRendered() {
                return (0, h.U2)(this.store.getState(), "ui.rendered") || !1
            }
            loadUI() {
                return this.actions.loadingUI(), this.importUIModule().then((e => {
                    this._uiModule = e.default, this.actions.loadedUI(), (0, N.j8)("ui.loaded")
                }))
            }
            importUIModule() {
                switch ((0, h.U2)(this.store.getState(), "ui.module")) {
                    case "ccpa":
                        return o.e("ui-ccpa").then(o.bind(o, 24687));
                    case "gdpr":
                        return o(4848)("./" + P.S.value + "/web/");
                    case "gdpr-tcf-2_2":
                        return o(41098)("./" + P.S + "/web2.2/");
                    case "ctv":
                        return o(25334)("./" + P.S.value + "/ctv/");
                    case "cpra":
                        return o.e("ui-cpra").then(o.bind(o, 44001));
                    case "vcdpa":
                        return o.e("ui-vcdpa").then(o.bind(o, 62319));
                    case "cpa":
                        return o.e("ui-cpa").then(o.bind(o, 54700));
                    case "ctdpa":
                        return o.e("ui-ctdpa").then(o.bind(o, 92314))
                }
            }
            setModule(e) {
                this.actions.setUIModule(e)
            }
        }
        class Dt extends O.Z {
            constructor(e, t, s) {
                super(e, t, s), this.componentsList = ["didomi-base-checkbox", "didomi-base-radio", "didomi-block", "didomi-button", "didomi-card", "didomi-cards", "didomi-checkbox", "didomi-checkboxes", "didomi-container", "didomi-email-login", "didomi-header", "didomi-image", "didomi-modal", "didomi-radio", "didomi-radios", "didomi-save", "didomi-text", "didomi-section", "didomi-purpose", "didomi-preference", "didomi-container-headless"]
            }
            configure(e) {
                e || (e = {}), Array.from(document.querySelectorAll(this.componentsList.join(", "))).length > 0 && (e.helpersEnabled = "boolean" != typeof e.helpersEnabled || e.helpersEnabled, e.componentsEnabled = "boolean" != typeof e.componentsEnabled || e.componentsEnabled), this.actions.setComponentsConfig(e)
            }
            getRemoteConsentsAndInitComponentsModule() {
                return this.services.RemoteConsentService.getRemoteConsentsFromAPI({
                    mergeUsers: !0
                }).then((() => {
                    this.initComponentsModule(!0)
                }))
            }
            initComponentsModule(e) {
                void 0 === e && (e = !1);
                var t = (0, _.getSDKConfigValue)("apiPath"),
                    s = this.services.UserService.getUserId(),
                    i = Promise.resolve();
                if ((0, h.U2)(this.store.getState(), "components.helpersEnabled") || e) {
                    var n = (0, h.U2)(this.store.getState(), "components.version");
                    i = this.importComponentsByVersion(n).then((i => (0, i.default)({
                        locale: P.S.value,
                        apiBaseURL: t,
                        loadComponents: (0, h.U2)(this.store.getState(), "components.componentsEnabled") || e,
                        userId: s
                    }).then((e => {
                        Object.assign(window.Didomi, e)
                    }))))
                }
                return i.then((() => {
                    (0, N.j8)("components.loaded")
                }))
            }
            importComponentsByVersion(e) {
                return void 0 === e && (e = 1), 1 === e ? this.importComponentsV1() : this.importComponents(e)
            }
            importComponentsV1() {
                return o.e("components").then(o.bind(o, 50493))
            }
            importComponents(e) {
                var t = (0, _.getSDKConfigValue)("pmpSdkPath");
                return new Promise(((s, i) => {
                    var n = document.createElement("script");
                    n.setAttribute("type", "text/javascript"), n.setAttribute("async", !0), n.setAttribute("charset", "utf-8"), n.setAttribute("src", t + "/v" + e + "/loader/index.js"), window.Didomi.onPMPSDKLoaded = () => {
                        s({
                            default: window.Didomi.initPMPSDK
                        })
                    }, n.onerror = i, document.body.appendChild(n)
                }))
            }
        }
        var Vt = o(63366),
            Rt = ["organizationUserId"],
            Nt = {
                organizationUserId: "organization_user_id",
                organizationUserIdAuthAlgorithm: "organization_user_id_algorithm",
                organizationUserIdAuthSid: "organization_user_id_sid",
                organizationUserIdAuthSalt: "organization_user_id_salt",
                organizationUserIdAuthDigest: "organization_user_id_digest",
                organizationUserIdExp: "organization_user_id_exp",
                organizationUserIdIv: "organization_user_id_iv"
            };
        class Ft extends O.Z {
            constructor(e, t, s) {
                super(e, t, s)
            }
            configure(e) {
                e && this.actions.setSyncConfig(e)
            }
            getMappedAuthorizationParameters(e) {
                var t = {};
                for (var s of Object.keys(Nt)) e && e[s] && (t[Nt[s]] = e[s]);
                return t
            }
            getAuthorizationParameters() {
                var e = (0, D.Ex)(this.store.getState()),
                    t = (0, Vt.Z)(e, Rt);
                return this.getMappedAuthorizationParameters(t)
            }
            getSyncData(t) {
                var {
                    agent: s,
                    apiPath: i,
                    domain: n,
                    organizationUserId: r,
                    token: o,
                    tcfcs: a,
                    tcfv: u,
                    timeout: d,
                    authParams: l,
                    synchronizedUsers: p,
                    tokenUserAuthParams: c,
                    signKey: f,
                    regulations: v
                } = t;
                return new Promise((t => {
                    K.ajax({
                        method: "POST",
                        url: i + "/sync",
                        body: JSON.stringify({
                            source: {
                                domain: n,
                                key: J.q.value,
                                type: "sdk-web"
                            },
                            user: (0, e.Z)({
                                id: o.user_id,
                                organization_user_id: r
                            }, l, {
                                agent: s,
                                token: {
                                    created: o.created,
                                    updated: o.updated,
                                    purposes: o.purposes,
                                    purposes_li: o.purposes_li,
                                    vendors: o.vendors,
                                    vendors_li: o.vendors_li
                                },
                                tcfcs: a,
                                tcfv: u,
                                synchronized_users: p,
                                token_user: c,
                                sign_key: f,
                                regs: v
                            })
                        }),
                        timeout: d,
                        headers: {
                            "Content-Type": "application/json"
                        },
                        cors: !0
                    }, ((e, s) => {
                        if (201 === e) {
                            var i;
                            try {
                                i = JSON.parse(s)
                            } catch (e) {
                                return console.error("Didomi - Error while parsing sync response"), t({
                                    consents: null,
                                    errorMessage: "Error while parsing sync response"
                                })
                            }
                            if (!1 === i.synced) {
                                var {
                                    created: n,
                                    updated: r,
                                    consents: o
                                } = i.user.token, a = r || n;
                                t({
                                    consents: {
                                        created: a,
                                        updated: a,
                                        purposes: {
                                            consent: {
                                                enabled: o.purposes.enabled,
                                                disabled: o.purposes.disabled
                                            },
                                            legitimate_interest: {
                                                enabled: o.purposes_li.enabled,
                                                disabled: o.purposes_li.disabled
                                            }
                                        },
                                        vendors: {
                                            consent: {
                                                enabled: o.vendors.enabled,
                                                disabled: o.vendors.disabled
                                            },
                                            legitimate_interest: {
                                                enabled: o.vendors_li.enabled,
                                                disabled: o.vendors_li.disabled
                                            }
                                        },
                                        action: "sync"
                                    }
                                })
                            } else t({
                                consents: null,
                                regenerateSignature: i.regenerate_signature
                            })
                        } else 404 === e ? t({
                            consents: null,
                            reset: !0
                        }) : (console.error("Didomi - Syncing HTTP error " + e), (0, N.V2)(e, "getSyncData"), t({
                            consents: null,
                            errorMessage: "Syncing HTTP error " + e
                        }))
                    }))
                }))
            }
            run(t) {
                void 0 === t && (t = () => {});
                var s = this.store.getState();
                if (Je(s)) {
                    var i, n, r, o, a = this.services.WebsiteService.isTCFEnabled(),
                        u = [];
                    if (null != (i = v.noticeConfig.value) && null != (n = i.regulation) && n.name) u.push(null == (r = v.noticeConfig.value) || null == (o = r.regulation) ? void 0 : o.name);
                    return this.getSyncData({
                        agent: navigator.userAgent,
                        apiPath: (0, _.getSDKConfigValue)("apiPath"),
                        domain: (0, R.Eh)(s),
                        organizationUserId: (0, D.cY)(s),
                        token: (0, V.NK)(s),
                        tcfcs: a ? (0, V.do)(s) : null,
                        tcfv: a ? Y.m.value.majorVersion : null,
                        timeout: He(s),
                        authParams: this.getAuthorizationParameters(),
                        synchronizedUsers: (0, D.eN)(s).map((t => (0, e.Z)({
                            organization_user_id: t.organizationUserId
                        }, this.getMappedAuthorizationParameters(t)))),
                        tokenUserAuthParams: this.getMappedAuthorizationParameters((0, ke.fi)(s)),
                        signKey: this.services.SignatureService.getCurrentSignatureKey(),
                        regulations: u
                    }).then((e => {
                        this.actions.setLastSyncDate((new Date).toISOString()), e.consents ? (this.services.ConsentService.setUserStatus(e.consents), this.services.StorageService.flushTokenToStorage(), this.services.SignatureService.sign()) : e.reset && (0, R.jw)(s) ? this.services.StorageService.reset() : e.regenerateSignature ? this.services.SignatureService.sign() : this.services.StorageService.flushTokenToStorage(), e.errorMessage ? (0, N.j8)("sync.error", e.errorMessage) : (0, N.j8)("sync.done"), t(), (0, N.H)("sync.ready")
                    })).catch((() => {
                        (0, N.j8)("sync.error", "Error while getting sync data"), t(new Error("Error while getting sync data")), (0, N.H)("sync.ready")
                    }))
                }
                t(), (0, N.H)("sync.ready")
            }
        }
        var Bt = o(96730),
            Mt = o(21753),
            jt = () => {
                var e;
                return (null == (e = Mt.A.value) ? void 0 : e.sort(((e, t) => {
                    var s, i, n = null == (s = e.name) ? void 0 : s.toLowerCase(),
                        r = null == (i = t.name) ? void 0 : i.toLowerCase();
                    return n < r ? -1 : n > r ? 1 : 0
                }))) || []
            };
        class zt extends O.Z {
            constructor() {
                super(...arguments), this.setInitialState = () => {
                    var e, t, s, i = this.store.getState(),
                        n = null == (e = fe.c.value) || null == (t = e.categories) ? void 0 : t.filter((e => "category" === e.type));
                    this.actions.setCategories(n), n.forEach((e => {
                        this.actions.setCategoryState(e.id, !0), e.children.filter((e => "purpose" === e.type)).map((e => this.actions.setPurposeState(e.purposeId, !0)))
                    })), null == (s = jt()) || s.forEach((e => this.actions.setVendorState(e.id, !0))), this.actions.setAllVendorsState(!0), (0, Pe.xJ)(i).forEach((e => this.actions.setSPIPurposesState(e.id, !1))), this.actions.setAllSPIUseState(!1)
                }, this.setAgreeToAll = () => {
                    var e, t, s = this.store.getState();
                    null == (e = fe.c.value) || null == (t = e.categories) || t.forEach((e => {
                        this.actions.setCategoryState(e.id, !0), e.children.filter((e => "purpose" === e.type)).map((e => this.actions.setPurposeState(e.purposeId, !0)))
                    })), (0, Pe.dH)(s).forEach((e => this.actions.setVendorState(e.id, !0))), this.actions.setAllVendorsState(!0), (0, Pe.xJ)(s).forEach((e => this.actions.setSPIPurposesState(e.id, !0))), this.actions.setAllSPIUseState(!0)
                }
            }
            configure(e) {
                var t, s;
                if (e) {
                    var i = null == (t = e.sensitivePersonalInformation) || null == (s = t.categories) ? void 0 : s.map((e => e.children.filter((e => "purpose" === e.type)).map((e => (0, Bt.z)(e.purposeId))).filter((e => void 0 !== e)))).flatMap((e => e));
                    i && this.actions.setSPIPurposes(i), this.actions.setVendors(jt())
                }
            }
            run() {
                this.setInitialState()
            }
        }
        var Zt = e => {
                var t;
                return !0 === (null == e || null == (t = e.ced) ? void 0 : t.loaded)
            },
            Gt = o(44071),
            qt = o(23561),
            Ht = o(74385),
            Wt = (0, C.Fl)((() => {
                var e, t = Object.values(Gt.s.value || {});
                if (null == t || !t.length || null == (e = $.L.value) || !e.isDidomiConsentStringEncodingEnabled) return {
                    purposeToNumericIdMap: {},
                    numberIdToPurposeMap: {}
                };
                var s = {},
                    i = {};
                for (var n of t) {
                    var r, o;
                    (0, qt.aB)(null == n || null == (r = n.namespaces) ? void 0 : r.num) && !i[null == n || null == (o = n.namespaces) ? void 0 : o.num] && (s[n.id] = n.namespaces.num, i[n.namespaces.num] = n.id)
                }
                return {
                    purposeToNumericIdMap: s,
                    numberIdToPurposeMap: i
                }
            }));
        (0, C.cE)((() => {
            var e, t;
            if (null != (e = Ht.F.value) && e.length && null != (t = $.L.value) && t.isDidomiConsentStringEncodingEnabled) {
                var s = [];
                for (var i of Ht.F.value) {
                    var n, r;
                    if ((0, qt.aB)(null == i || null == (n = i.namespaces) ? void 0 : n.num))
                        if (s.includes(null == i || null == (r = i.namespaces) ? void 0 : r.num)) console.error('Didomi - The purpose id "' + (null == i ? void 0 : i.id) + '" has a numeric id that was already registered. Ignoring it.');
                        else {
                            var o;
                            s.push(null == i || null == (o = i.namespaces) ? void 0 : o.num)
                        }
                    else console.error('Didomi - The purpose id "' + (null == i ? void 0 : i.id) + '" has an invalid numeric id. Ignoring it.')
                }
            }
        }));
        var Kt = (0, C.Fl)((() => {
            var e = Object.values(z.I.value || {});
            if (null == e || !e.length || !$.L.value.isDidomiConsentStringEncodingEnabled) return {
                vendorToNumericIdMap: {},
                numberIdToVendorMap: {}
            };
            var t = {},
                s = {};
            for (var i of e) {
                var n;
                (0, qt.aB)(null == i || null == (n = i.namespaces) ? void 0 : n.num) && (t[i.id] = i.namespaces.num, s[i.namespaces.num] = i.id)
            }
            return {
                vendorToNumericIdMap: t,
                numberIdToVendorMap: s
            }
        }));
        (0, C.cE)((() => {
            var e, t;
            if (null != (e = Mt.A.value) && e.length && null != (t = $.L.value) && t.isDidomiConsentStringEncodingEnabled)
                for (var s of Mt.A.value) {
                    var i, n, r = s.purposeIds || [],
                        o = s.legIntPurposeIds || [],
                        a = !r.some((e => {
                            var t, s;
                            return !(0, qt.aB)(null == (t = Gt.s.value[e]) || null == (s = t.namespaces) ? void 0 : s.num)
                        })),
                        u = !o.some((e => {
                            var t, s;
                            return !(0, qt.aB)(null == (t = Gt.s.value[e]) || null == (s = t.namespaces) ? void 0 : s.num)
                        }));
                    if (!a || !u) console.error('Didomi - The vendor with ID "' + ((null == (n = s.id) ? void 0 : n.split("c:")[1]) || s.id) + '" has purposes with invalid numeric IDs and they will not be encoded in the Didomi Consent String.');
                    var d, l = null == (i = s.namespaces) ? void 0 : i.num;
                    if (!(0, qt.aB)(l)) console.error('Didomi - The vendor with ID "' + ((null == (d = s.id) ? void 0 : d.split("c:")[1]) || s.id) + '" has an invalid numeric ID and it will not be encoded in the Didomi Consent String.')
                }
        }));
        class Jt extends O.Z {
            constructor() {
                super(...arguments), this.module = null, this.requests = []
            }
            initDidomiConsentStringEncoderDecoder(e) {
                var t;
                null != (t = $.L.value) && t.isDidomiConsentStringEncodingEnabled ? Zt(this.store.getState()) ? e() : this.load(e) : e()
            }
            encodeUserAuthParams(e) {
                var t = (0, Le.YN)(e);
                return tt.DS.btoa(JSON.stringify(t))
            }
            decodeUserAuthParams(e) {
                try {
                    var t = JSON.parse(tt.DS.atob(e));
                    return (0, Le.gO)(t)
                } catch (e) {
                    return console.error("Didomi - Error while parsing user auth parameters cookie"), {}
                }
            }
            vendorIdsToNumericIds(e) {
                return null == e ? void 0 : e.map((e => {
                    var t;
                    return null == (t = Kt.value) ? void 0 : t.vendorToNumericIdMap[e]
                })).filter((e => e))
            }
            purposeIdsToNumericIds(e) {
                return null == e ? void 0 : e.map((e => {
                    var t;
                    return null == (t = Wt.value) ? void 0 : t.purposeToNumericIdMap[e]
                })).filter((e => e))
            }
            vendorsNumericIdsToIds(e) {
                return null == e ? void 0 : e.map((e => {
                    var t;
                    return null == (t = Kt.value) ? void 0 : t.numberIdToVendorMap[e]
                })).filter((e => e))
            }
            purposeNumericIdsToIds(e) {
                return null == e ? void 0 : e.map((e => {
                    var t;
                    return null == (t = Wt.value) ? void 0 : t.numberIdToPurposeMap[e]
                })).filter((e => e))
            }
            translateEntities(e, t) {
                var s = {
                    enabled: [],
                    disabled: []
                };
                if (!e) return s;
                var {
                    enabled: i,
                    disabled: n
                } = e;
                return i && (s.enabled = t(i)), n && (s.disabled = t(n)), s
            }
            stringsToDates(t) {
                if (t) {
                    var s = (0, e.Z)({}, t);
                    delete s.sync;
                    var {
                        created: i,
                        updated: n,
                        sync: r
                    } = t;
                    return (0, h.HD)(i) && (s.created = new Date(i)), (0, h.HD)(n) && (s.updated = new Date(n)), s
                }
            }
            datesToStrings(t) {
                if (t) {
                    var s = (0, e.Z)({}, t),
                        {
                            created: i,
                            updated: n,
                            sync: r
                        } = t;
                    return i instanceof Date && (s.created = i.toISOString()), n instanceof Date && (s.updated = n.toISOString()), r instanceof Date && (s.sync = r.toISOString()), s
                }
            }
            encode(t) {
                var s, i = this.getCedFactory();
                if (i && t) {
                    var n = null == (s = $.L.value) ? void 0 : s.version,
                        r = this.translateEntities(t.purposes, this.purposeIdsToNumericIds.bind(this)),
                        o = this.translateEntities(t.purposes_li, this.purposeIdsToNumericIds.bind(this)),
                        a = this.translateEntities(t.vendors, this.vendorIdsToNumericIds.bind(this)),
                        u = this.translateEntities(t.vendors_li, this.vendorIdsToNumericIds.bind(this));
                    return i.getEncoder((0, e.Z)({}, this.stringsToDates(t), {
                        vendors: a,
                        purposes: r,
                        vendors_li: u,
                        purposes_li: o
                    }), n).encode()
                }
            }
            decode(t) {
                var s = this.getCedFactory();
                if (s && t) {
                    t = (0, me.t0)(t);
                    var i = s.getDecoder(t).decode(),
                        n = this.translateEntities(i.purposes, this.purposeNumericIdsToIds.bind(this)),
                        r = this.translateEntities(i.purposes_li, this.purposeNumericIdsToIds.bind(this)),
                        o = this.translateEntities(i.vendors, this.vendorsNumericIdsToIds.bind(this)),
                        a = this.translateEntities(i.vendors_li, this.vendorsNumericIdsToIds.bind(this));
                    return (0, e.Z)({}, this.datesToStrings(i), {
                        vendors: o,
                        purposes: n,
                        vendors_li: a,
                        purposes_li: r
                    })
                }
            }
            importDidomiConsentStringEncoderDecoder() {
                return o.e("ced-encoder-decoder").then(o.bind(o, 6506))
            }
            load(e) {
                var t = this;
                return (0, Ut.Z)((function*() {
                    return t.actions.loadingCED(), t.importDidomiConsentStringEncoderDecoder().then((s => {
                        t.module = s, t.actions.loadedCED();
                        var i = t.getCedFactory();
                        for (var n of t.requests) n(i);
                        t.requests = [], e(i), (0, N.j8)("ced.loaded")
                    }))
                }))()
            }
            save(e) {
                this.requests.push(e)
            }
            getCedFactory() {
                var e;
                return null == (e = this.module) ? void 0 : e.CedFactory
            }
            useCedFactory(e) {
                var t = this.store.getState();
                return Zt(t) ? (e(this.getCedFactory()), !0) : ((e => {
                    var t;
                    return !0 === (null == e || null == (t = e.ced) ? void 0 : t.loading)
                })(t) ? this.save(e) : this.load(e), !1)
            }
        }
        class Qt extends O.Z {
            constructor(e, t, s) {
                super(e, t, s)
            }
            setSignature(e) {
                this.actions.setSignature(e)
            }
            updateCookie(e) {
                var {
                    signature: t,
                    dcsUserId: s
                } = e;
                this.actions.setSignature({
                    dcsUserId: s,
                    signature: t
                }), this.services.StorageService.flushTokenToStorage(), (0, N.j8)("signature.consentsigned")
            }
            getSignatureParams() {
                var e = this.store.getState(),
                    t = this.services.StorageService.getCookies(),
                    s = (0, me.t0)(null == t ? void 0 : t.didomiToken),
                    i = (0, D.kw)(e);
                return s && i ? {
                    dcs: s,
                    dcsUser: i.organizationUserId ? this.services.SyncService.getMappedAuthorizationParameters(i) : i
                } : null
            }
            sign() {
                var e;
                if (null != (e = $.L.value) && e.signatureEnabled) {
                    var t = this.getSignatureParams();
                    if (t) {
                        var s = this.store.getState();
                        K.ajax({
                            method: "POST",
                            url: (0, _.getSDKConfigValue)("apiPath") + "/sign",
                            body: JSON.stringify({
                                source: {
                                    domain: (0, R.Eh)(s),
                                    key: J.q.value,
                                    type: "sdk-web"
                                },
                                dcs_user: t.dcsUser,
                                dcs: t.dcs
                            }),
                            headers: {
                                "Content-Type": "application/json"
                            },
                            cors: !0
                        }, ((e, t) => {
                            if (201 === e) {
                                var s = JSON.parse(t);
                                this.updateCookie({
                                    dcsUserId: s.dcs_user,
                                    signature: s.signature
                                })
                            } else(0, N.V2)(e, "createSignature"), (0, N.j8)("signature.error", "Signature generation fail " + e)
                        }))
                    }
                }
            }
            getCurrentSignatureKey() {
                var e = this.getCurrentSignaturePropsFromCookie();
                return e.signature ? e.signature[0] : null
            }
            getCurrentSignaturePropsFromCookie() {
                var e;
                if (null == (e = $.L.value) || !e.signatureEnabled) return {};
                var t = this.services.StorageService.getCookies();
                if (null != t && t.didomiToken) {
                    var s = (0, me.o$)(t.didomiToken),
                        i = (0, me.Nw)(t.didomiToken);
                    if (s && i) return {
                        signature: s,
                        dcsUserId: i
                    }
                }
                return {}
            }
            checkUnsignedConsent() {
                var e, t = this.store.getState();
                if (null != (e = $.L.value) && e.signatureEnabled && (0, D.kw)(t)) {
                    var s = this.services.StorageService.getCookies();
                    null != s && s.didomiToken && s.didomiToken.indexOf("~") < 0 && this.services.StorageService.reset()
                }
            }
        }

        function $t(e) {
            for (var t in e) "function" == typeof e[t].init && e[t].init()
        }
        var Yt = e => function() {
                try {
                    e(...arguments)
                } catch (e) {
                    console.error("Didomi SDK - Error in didomiOnReady function.", e)
                }
            },
            Xt = e => function() {
                try {
                    e(...arguments)
                } catch (e) {
                    console.error("Didomi SDK - Error in didomiOnLoad function.", e)
                }
            };

        function es(e) {
            if (!window.didomiOnReady || !0 !== window.didomiOnReady.stub) {
                if (Array.isArray(window.didomiOnReady))
                    for (var t of window.didomiOnReady) {
                        if ("function" == typeof t) Yt(t)(e)
                    }
                window.didomiOnReady = {
                    stub: !0,
                    push: function() {
                        for (var t = arguments.length, s = new Array(t), i = 0; i < t; i++) s[i] = arguments[i];
                        for (var n of s) {
                            if ("function" == typeof n) Yt(n)(e)
                        }
                    }
                }
            }
        }

        function ts(e, t, s, i, n) {
            t && s ? (! function(e, t, s) {
                var i = document.createElement("script");
                i.id = "spccustom", i.type = "text/javascript", i.async = !0, i.src = "" + e + s + "/" + t + ".js", i.charset = "utf-8";
                var n = document.getElementsByTagName("script")[0];
                n.parentNode.insertBefore(i, n)
            }(e, t, s), i.resume = () => {
                n(), delete i.resume
            }, setTimeout((() => {
                i.resume && console.error("Didomi - 10 seconds timeout for loading custom SDK has expired")
            }), 1e4)) : n()
        }
        class ss {
            constructor() {
                this.delayedEvents = [], this.isReady = !1
            }
            delayUntilReady(e) {
                var t = this;
                return function() {
                    for (var s = arguments.length, i = new Array(s), n = 0; n < s; n++) i[n] = arguments[n];
                    t.isReady ? e(...i) : t.delayedEvents.push(e.bind(null, ...i))
                }
            }
            markAsReady() {
                for (var e of this.delayedEvents) e();
                this.delayedEvents = [], this.isReady = !0
            }
        }

        function is(e, t, s) {
            "object" == typeof s && "string" == typeof s.event && s.event && "function" == typeof s.listener && t(s.event, e.delayUntilReady(s.listener))
        }

        function ns(e, t, s, i) {
            if ("function" == typeof i) {
                var n = (0, h.U2)(e, t);
                "function" != typeof n ? i(null, !1) : i(n.apply(e, Array.isArray(s) ? s : void 0), !0)
            }
        }

        function rs(e) {
            (0, yt.SH)("__cmpCall", "__cmpReturn", ns.bind(this, e), window.__cmpBuffer)
        }
        var os = o(97758),
            as = () => Promise.all([o.e("polyfills").then(o.t.bind(o, 94301, 23)), o.e("polyfills").then(o.t.bind(o, 47834, 23)), o.e("polyfills").then(o.t.bind(o, 5489, 23)), o.e("polyfills").then(o.t.bind(o, 77671, 23)), o.e("polyfills").then(o.t.bind(o, 81817, 23)), o.e("polyfills").then(o.t.bind(o, 62173, 23)), o.e("polyfills").then(o.t.bind(o, 32414, 23)), o.e("polyfills").then(o.t.bind(o, 49810, 23)), o.e("polyfills").then(o.t.bind(o, 68230, 23)), o.e("polyfills").then(o.t.bind(o, 63662, 23)), o.e("polyfills").then(o.t.bind(o, 74577, 23)), o.e("polyfills").then(o.t.bind(o, 3573, 23)), o.e("polyfills").then(o.t.bind(o, 68346, 23)), o.e("polyfills").then(o.t.bind(o, 92007, 23)), o.e("polyfills").then(o.t.bind(o, 27443, 23)), o.e("polyfills").then(o.t.bind(o, 44133, 23))]),
            us = () => Promise.all([o.e("polyfills-ctv").then(o.t.bind(o, 18842, 23)), o.e("polyfills-ctv").then(o.t.bind(o, 11356, 23)), o.e("polyfills-ctv").then(o.t.bind(o, 38534, 23))]);
        var ds = o(40911),
            ls = () => {
                var e, t, s = (e = /didomi_country=([a-zA-Z]{2})/.exec(window.location.search), t = /didomi_region=([a-zA-Z]{2})/.exec(window.location.search), {
                        country: e ? e[1] : null,
                        region: t ? t[1] : null
                    }),
                    i = {
                        country: "string" == typeof window.didomiCountry && 2 === window.didomiCountry.length ? window.didomiCountry.toUpperCase() : null,
                        region: "string" == typeof window.didomiRegion && window.didomiRegion.length > 0 ? window.didomiRegion.toUpperCase() : null
                    },
                    n = {
                        country: s.country || i.country || null,
                        region: s.region || i.region || null
                    };
                w(n.country && "US" !== n.country ? {
                    country: n.country,
                    region: null
                } : n.country && n.region ? {
                    country: n.country,
                    region: n.region
                } : {
                    country: n.country,
                    region: null
                })
            },
            ps = o(55082),
            cs = {
                monitoringDidomiOnLoad: "monitoring.didomi-on-load"
            },
            fs = t => {
                var {
                    type: s,
                    value: i = 1,
                    sampleRate: n = null,
                    dimensions: r = [],
                    beacon: o = !1
                } = t;
                if (!(0, h.VO)(cs).includes(s)) return console.error("Didomi SDK: Invalid metric type " + s), null;
                if (Math.random() > (n || 1)) return null;
                var a = (0, e.Z)({
                    type: s,
                    rate: "number" == typeof n ? n : 1
                }, r && {
                    dimensions: r
                }, i && {
                    value: i
                });
                return (e => {
                    var {
                        data: t,
                        endpoint: s,
                        beacon: i = !1,
                        onSuccess: n,
                        onError: r,
                        errorMessage: o
                    } = e;
                    i && "function" == typeof navigator.sendBeacon ? navigator.sendBeacon(s + "?data_format=json", JSON.stringify(t)) : fetch(s, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(t),
                        mode: "cors"
                    }).then((e => {
                        var t = e.status;
                        return e.text().then((e => {
                            n && n(t, e)
                        }))
                    })).catch((e => {
                        console.error(o || "Didomi SDK: Failed to send data to " + s + ": " + e), r && r(e)
                    }))
                })({
                    data: a,
                    beacon: o,
                    endpoint: (0, _.getSDKConfigValue)("apiPath") + "/metrics",
                    errorMessage: "Didomi SDK: Failed to send metric: " + a.type
                }), a
            },
            vs = {},
            hs = function(e) {
                return void 0 === e && (e = [{
                    key: "unset",
                    value: null
                }]), e.map((e => {
                    switch (e.key) {
                        case "apiKey":
                            return J.q.value ? {
                                type: e.key,
                                value: J.q.value
                            } : null;
                        case "functionName":
                            return {
                                type: e.key,
                                value: e.value
                            };
                        default:
                            return null
                    }
                })).filter((e => e))
            },
            gs = () => {
                vs[cs.monitoringDidomiOnLoad] || (hs([{
                    key: "apiKey"
                }]).length && fs({
                    type: cs.monitoringDidomiOnLoad,
                    sampleRate: (0, _.getSDKConfigValue)("metrics").monitoringDidomiOnLoadSampleSize,
                    dimensions: hs([{
                        key: "apiKey"
                    }])
                }), vs[cs.monitoringDidomiOnLoad] = !0)
            },
            ms = o(67336),
            bs = o(62382),
            Ss = e => {
                var t;
                return null == (t = z.I.value) ? void 0 : t[Kt.value.numberIdToVendorMap[e]]
            },
            Cs = e => {
                var t, s;
                return null == (t = be.r.value) || null == (s = t.filter((t => !e || t.namespace === e))) ? void 0 : s.filter((e => "object" == typeof e && !!e))
            },
            ys = o(98291),
            ws = () => {
                var e, t, s;
                if (null == (e = v.noticeConfig.value) ? void 0 : e.version) return "ccpa" === (null == (t = v.noticeConfig.value) || null == (s = t.regulation) ? void 0 : s.name);
                var i, n, r, o, a, u, d = (null == (i = v.noticeConfig.value) ? void 0 : i.regulations) || (null == (n = v.noticeConfig.value) || null == (r = n.website) ? void 0 : r.regulations) || (null == (o = v.noticeConfig.value) || null == (a = o.app) ? void 0 : a.regulations) || {};
                return !(null == d || null == (u = d.ccpa) || !u.enabled)
            };
        A("init-started", {
            detail: "Initialization of the Didomi SDK started"
        });
        var Is = {},
            _s = {},
            Ps = {},
            As = !1;

        function ks(e) {
            var t, s;
            if (e.SiteConfigService.configure(v.noticeConfig.value), e.RemoteConsentService.getRemoteConsentsFromAPI({
                    mergeUsers: !0
                }).then((() => {
                    e.ComponentsService.initComponentsModule()
                })), e.SignatureService.checkUnsignedConsent(), "none" === (null == (t = v.noticeConfig.value) || null == (s = t.regulation) ? void 0 : s.name)) return e.CCPAService.run(), e.TCFService.setupPublicAPIFromLocalStore(), e.IntegrationsService.run(), window.Didomi = Is, e.TagManagersService.run(), rs(_s), void es(Is);
            if (Q.K.value) e.UIService.setModule("ctv");
            else {
                var i, n, r = null == (i = v.noticeConfig.value) || null == (n = i.regulation) ? void 0 : n.name,
                    o = r;
                "gdpr" === r && Y.m.value.semVersion === M.t.tcfVersion2_2 && (o = "gdpr-tcf-2_2"), e.UIService.setModule(o)
            }(0, ds.c)((() => {
                e.StorageService.initStorages((() => {
                    var t = e.StorageService.initStoreFromStorage(),
                        s = t.didomiTokenCreatedFromIABToken,
                        i = t.token;
                    e.WebsiteService.shouldNoticeBeShown() && e.UIService.preLoad(),
                        function(e) {
                            if (window.didomiOnLoad && window.didomiOnLoad.length) {
                                for (var t = window.didomiOnLoad.length, s = 0; s < t; s += 1) {
                                    var i = window.didomiOnLoad.shift();
                                    "function" == typeof i && (Xt(i), i(e))
                                }
                                return !0
                            }
                            return !1
                        }(Is) && (i = e.StorageService.initStoreFromStorage().token, gs()), e.UserService.loadExternalConsent(), e.CookiesService.enable();
                    var n = e.ExperimentsService.run(i);
                    n && Is.configure(n), (0, ds.c)((() => {
                        var t = k.cr.getState();
                        ws() && e.CCPAService.run(), "tv" === (0, v.getNoticeConfigValue)("mode") && (0, ps.g)(), qe(t) ? e.SyncService.run((() => {
                            e.TCFService.setupPublicAPIFromLocalStore(), e.WebsiteService.determineConsentNoticeStatus()
                        })) : (e.SyncService.run(), e.TCFService.setupPublicAPIFromLocalStore(), e.WebsiteService.determineConsentNoticeStatus()), e.IntegrationsService.run(), As = !0, e.EventsService.sendPageview(), window.Didomi = Is, e.TagManagersService.run(), rs(_s), A("init-finished", {
                            detail: "Initialization of the Didomi SDK finished"
                        }), e.UIService.isRenderScheduled() ? (0, N.IH)("ui.ready", (() => {
                            A("notice-shown", {
                                detail: "Didomi notice shown"
                            }), es(Is)
                        })) : es(Is), s ? e.ConsentService.sendEvents(i, !0) : (0, R.T5)(t) && st.k && !1 === St.value && e.ConsentService.sendEvents(i)
                    }), !0)
                }))
            }), !0)
        }

        function Ts(t) {
            Ot(), window.addEventListener("pagehide", (() => {
                    t.EventsService.sendPageview(!0)
                })), Object.assign(_s, {
                    getConfig() {
                        return v.noticeConfig.value
                    },
                    getUserConsentStatus(e, s) {
                        return void 0 === s && (s = null), t.ConsentService.getUserConsentStatus(e, s)
                    },
                    getUserConsentStatusForPurpose(e) {
                        return t.ConsentService.getUserConsentStatusByPurpose(e)
                    },
                    getUserConsentStatusForVendor(e) {
                        return t.ConsentService.getUserConsentStatusForAllPurposesByVendor(e)
                    },
                    getUserStatus() {
                        return t.ConsentService.getUserStatus()
                    }
                }), Object.assign(Ps, {
                    CCPA: {
                        getDoNotSellStatus() {
                            return t.CCPAService.getDoNotSellStatus()
                        },
                        setDoNotSellStatus(e) {
                            return t.CCPAService.setDoNotSellStatus(e)
                        }
                    },
                    getUserAuthToken() {
                        return t.UserService.getAuthToken()
                    },
                    isRegulationApplied(e) {
                        var t, s;
                        return (null == (t = v.noticeConfig.value) || null == (s = t.regulation) ? void 0 : s.name) === e
                    },
                    isConsentRequired() {
                        return t.UserService.isConsentRequired()
                    },
                    requestAuthenticationURL(e) {
                        var {
                            authProviderId: s
                        } = void 0 === e ? {} : e;
                        return t.RemoteConsentService.requestAuthenticationURL({
                            authProviderId: s
                        })
                    },
                    sendEmailLogin(e, s) {
                        return t.RemoteConsentService.sendLogin({
                            value: e,
                            channel: "email",
                            params: s
                        })
                    },
                    sendMessageLogin(e) {
                        var {
                            value: s,
                            channel: i,
                            params: n
                        } = e;
                        return t.RemoteConsentService.sendLogin({
                            value: s,
                            channel: i,
                            params: n
                        })
                    },
                    sendLogin(e) {
                        var {
                            value: s,
                            channel: i,
                            params: n
                        } = e;
                        return t.RemoteConsentService.sendLogin({
                            value: s,
                            channel: i,
                            params: n
                        })
                    },
                    verifyOtpCode(e) {
                        var {
                            code: s,
                            organizationUserId: i,
                            authProviderId: n
                        } = e;
                        return t.RemoteConsentService.verifyOtpCode({
                            code: s,
                            organizationUserId: i,
                            authProviderId: n
                        })
                    },
                    getRemoteConsentsFromAPI() {
                        return t.RemoteConsentService.getRemoteConsentsFromAPI()
                    },
                    Purposes: t.ConsentService.Purposes,
                    on(e, t) {
                        return 0 === (e = e.toLowerCase()).indexOf("consent.pendingchanged") || 0 === e.indexOf("remoteconsent.") || 0 === e.indexOf("consent.") || 0 === e.indexOf("cookies.") || 0 === e.indexOf("integrations.") || 0 === e.indexOf("notice.") || 0 === e.indexOf("preferences.") || 0 === e.indexOf("ui.") || 0 === e.indexOf("components.") || 0 === e.indexOf("sync.") || 0 === e.indexOf("signature.") || 0 === e.indexOf("api.") ? (0, N.on)(e, (function() {
                            try {
                                t(...arguments)
                            } catch (t) {
                                console.error("Didomi SDK - Error in event listener callback for " + e + ".", t)
                            }
                        })) : (console.error('Didomi SDK - Cannot subscribe to unknown event type "' + e + '"'), null)
                    },
                    emit(e) {
                        0 !== (e = e.toLowerCase()).indexOf("consent.") && 0 !== e.indexOf("remoteconsent.") && 0 !== e.indexOf("cookies.") && 0 !== e.indexOf("integrations.") && 0 !== e.indexOf("notice.") && 0 !== e.indexOf("preferences.") && 0 !== e.indexOf("ui.") && 0 !== e.indexOf("components.") && 0 !== e.indexOf("sync.") && 0 !== e.indexOf("signature.") && 0 !== e.indexOf("api.") || console.error("Didomi - You cannot emit those types of events")
                    },
                    initWidgets() {
                        return t.ComponentsService.getRemoteConsentsAndInitComponentsModule()
                    },
                    getTCFVersion() {
                        return Y.m.value.semVersion
                    },
                    isPurposeRestrictedForVendor(e, t, s) {
                        return (0, ms.E)(e, t, s, bs.s.value)
                    },
                    getUserConsentToken() {
                        return t.ConsentService.getUserConsentTokenDeprecated()
                    },
                    getObservableOnUserConsentStatusForVendor(e) {
                        return t.ConsentService.getObservableOnUserConsentStatusForAllPurposesByVendor(e)
                    },
                    getLegitimateInterestStatusForVendor(e) {
                        return t.ConsentService.getLegitimateInterestStatusForVendor(e)
                    },
                    getLegitimateInterestStatusForPurpose(e) {
                        return t.ConsentService.getLegitimateInterestStatusForPurpose(e)
                    },
                    getUserStatusForVendor(e) {
                        return t.ConsentService.getUserStatusForVendor(e)
                    },
                    getUserStatusForVendorAndLinkedPurposes(e) {
                        return t.ConsentService.getUserStatusForVendorAndLinkedPurposes(e)
                    },
                    setUserStatus(e) {
                        return t.ConsentService.setUserStatus(e)
                    },
                    setUserStatusForAll(e) {
                        var {
                            purposesConsentStatus: s,
                            purposesLIStatus: i,
                            vendorsConsentStatus: n,
                            vendorsLIStatus: r,
                            created: o,
                            updated: a,
                            action: u
                        } = e;
                        return t.ConsentService.setUserStatusForAll({
                            purposesConsentStatus: s,
                            purposesLIStatus: i,
                            vendorsConsentStatus: n,
                            vendorsLIStatus: r,
                            created: o,
                            updated: a,
                            action: u
                        })
                    },
                    setUserConsentStatus(e, s, i) {
                        return t.ConsentService.setUserConsentStatusDeprecated(e, s, i)
                    },
                    setUserConsentStatusForAll(e, s, i, n) {
                        return void 0 === e && (e = []), void 0 === s && (s = []), void 0 === i && (i = []), void 0 === n && (n = []), t.ConsentService.setUserConsentStatus(e, s, i, n)
                    },
                    setRemoteConsentStatusForAll(e) {
                        return t.RemoteConsentService.setRemoteConsentStatusForAll(e)
                    },
                    getUserConsentStatusForAll() {
                        return t.ConsentService.getUserConsentStatusForAll()
                    },
                    getRemoteConsentStatusForAll() {
                        return t.RemoteConsentService.getRemoteConsentStatusForAll()
                    },
                    getRemoteConsentEventsForAll(e) {
                        return t.RemoteConsentService.getRemoteConsentEventsForAll(e)
                    },
                    refreshRemoteConsentsForAll() {
                        return t.RemoteConsentService.refreshRemoteConsentsFromAPI()
                    },
                    getPendingConsents() {
                        return t.RemoteConsentService.getPendingConsents()
                    },
                    savePendingConsents(e) {
                        return t.RemoteConsentService.savePendingConsents(e)
                    },
                    resetPendingConsents() {
                        return t.RemoteConsentService.resetPendingConsents()
                    },
                    saveConsentForEntityById(e, s, i, n, r, o, a, u) {
                        return t.RemoteConsentService.saveConsentForEntityById(e, s, i, n, r, o, a, u)
                    },
                    setPendingConsentForEntityById(e, s, i, n) {
                        return t.RemoteConsentService.setPendingConsentForEntityById(e, s, i, n)
                    },
                    openTransaction() {
                        return new E.Z(t.ConsentService.getUserStatus.bind(t.ConsentService), t.ConsentService.setUserStatus.bind(t.ConsentService))
                    },
                    isUserAuthenticated() {
                        return t.RemoteConsentService.isUserAuthenticated()
                    },
                    getAuthProtocol() {
                        return t.RemoteConsentService.getAuthProtocol()
                    },
                    isTCFEnabled() {
                        return t.WebsiteService.isTCFEnabled()
                    },
                    configure(e) {
                        (0, v.updateNoticeConfig)(e), t.SiteConfigService.configure(e), As && t.WebsiteService.determineConsentNoticeStatus()
                    },
                    notice: {
                        configure(e) {
                            k.fw.setConsentNoticeConfig(e)
                        },
                        show() {
                            t.NoticeService.show()
                        },
                        hide() {
                            t.NoticeService.hide()
                        },
                        isVisible() {
                            return t.NoticeService.isVisible()
                        },
                        showDataProcessing() {
                            var e;
                            return null == (e = ce.notice.value) ? void 0 : e.showDataProcessing
                        }
                    },
                    preferences: {
                        hide() {
                            t.PreferencesService.hide()
                        },
                        show(e) {
                            t.PreferencesService.show(e)
                        },
                        isVisible() {
                            return t.PreferencesService.isVisible()
                        }
                    },
                    setUserAgreeToAll(e) {
                        void 0 === e && (e = "external"), t.WebsiteService.setUserAgreeToAll(e)
                    },
                    setUserDisagreeToAll(e) {
                        void 0 === e && (e = "external"), t.WebsiteService.setUserDisagreeToAll(e)
                    },
                    isUserConsentStatusPartial() {
                        return t.WebsiteService.isUserConsentStatusPartial()
                    },
                    setConfigParameter(e, t) {
                        return (0, v.updateNoticeConfigValue)(e, t)
                    },
                    theme: {
                        set(e, t) {
                            var s = e || t;
                            (0, v.updateNoticeConfig)({
                                theme: {
                                    color: s
                                }
                            })
                        }
                    },
                    reset(e) {
                        void 0 === e && (e = null), t.StorageService.reset(e)
                    },
                    getRequiredVendorIds() {
                        return Z.O.value
                    },
                    getRequiredVendors(e) {
                        return Cs(e)
                    },
                    getVendorById(e) {
                        var t;
                        return null == (t = z.I.value) ? void 0 : t[e]
                    },
                    getVendorByNumericId(e) {
                        return Ss(e)
                    },
                    getVendorNumericId(e) {
                        var t, s;
                        return null == (t = Kt.value) || null == (s = t.vendorToNumericIdMap) ? void 0 : s[e]
                    },
                    getVendors() {
                        return Ye._.value
                    },
                    getRequiredPurposeIds() {
                        return q.s.value
                    },
                    getRequiredPurposes(e) {
                        return (0, ys.v)(e)
                    },
                    getPurposeById(e) {
                        return (0, Bt.z)(e)
                    },
                    getPurposes() {
                        return Gt.s.value
                    },
                    getPurposeByNumericId(e) {
                        var t, s, i = null == (t = Wt.value) ? void 0 : t.numberIdToPurposeMap[e];
                        return (null == (s = Gt.s.value) ? void 0 : s[i]) || null
                    },
                    getPurposeNumericId(e) {
                        var t, s, i;
                        return null == (t = Gt.s.value) || null == (s = t[e]) || null == (i = s.namespaces) ? void 0 : i.num
                    },
                    getLanguage() {
                        return P.S.value
                    },
                    getPurposesBasedOnConsent() {
                        return t.WebsiteService.getPurposesBasedOnConsent()
                    },
                    getPurposesBasedOnLegitimateInterest() {
                        return t.WebsiteService.getPurposesBasedOnLegitimateInterest()
                    },
                    getPurposesFromAllLegalBases() {
                        return t.WebsiteService.getPurposesFromAllLegalBases()
                    },
                    getCategories() {
                        var e;
                        return null == (e = fe.c.value) ? void 0 : e.categories
                    },
                    navigate() {
                        console.info("Didomi - Ignoring call to navigate. Ensure that the UI is displayed and that the SDK is ready by wrapping your calls in window.didomiOnReady callbacks")
                    },
                    getTranslationAsHTML() {
                        return console.error("Didomi - The UI module needs to be loaded before using the getTranslationAsHTML function"), null
                    },
                    shouldConsentBeCollected() {
                        return t.WebsiteService.shouldConsentBeCollected()
                    },
                    getExperiment() {
                        return t.ExperimentsService.getCurrentExperiment()
                    },
                    version: "7e0e4e88d0225db89a578b31aa627050b4ce1e0d-2023-11-28T17:42:19.083Z",
                    getCedFactory() {
                        return t.CEDService.getCedFactory()
                    },
                    useCedFactory(e) {
                        return t.CEDService.useCedFactory(e)
                    }
                }), Object.assign(Is, (0, e.Z)({}, _s, Ps)),
                function(e) {
                    if (!window.didomiEventListeners || !0 !== window.didomiEventListeners.stub) {
                        var t = new ss;
                        if (window.didomiOnReady = window.didomiOnReady || [], window.didomiOnReady.push((() => {
                                t.markAsReady()
                            })), Array.isArray(window.didomiEventListeners))
                            for (var s of window.didomiEventListeners) is(t, e, s);
                        window.didomiEventListeners = {
                            stub: !0,
                            push: function() {
                                for (var s = arguments.length, i = new Array(s), n = 0; n < s; n++) i[n] = arguments[n];
                                for (var r of i) is(t, e, r)
                            }
                        }
                    }
                }(Is.on), ts((0, _.getSDKConfigValue)("customSDKPath"), (0, v.getNoticeConfigValue)("website.customSDK") || (0, v.getNoticeConfigValue)("app.customSDK"), J.q.value, Is, (() => {
                    ks(t)
                }))
        }

        function Es() {
            var e, t, s;
            ! function(e) {
                if (e.didomiConfig && e.didomiConfig.sdkPath) {
                    var t = "sdk/7e0e4e88d0225db89a578b31aa627050b4ce1e0d/modern/";
                    e.didomiConfig.sdkPath.endsWith("/") ? o.p = e.didomiConfig.sdkPath + t : o.p = e.didomiConfig.sdkPath + "/" + t
                }
            }(window), e = () => {
                ls(), (0, v.updateNoticeConfig)(I()),
                    function(e, t, s) {
                        var i = {};
                        i.SiteConfigService = new Et(e, t, i), i.EventsService = new X(e, t, i), i.NoticeService = new ve(e, t, i), i.PreferencesService = new he(e, t, i), i.ConsentService = new H(e, t, i), i.CCPAService = new _t(e, t, i), i.CookiesService = new W(e, t, i), i.TagManagersService = new Ce(e, t, i), i.UserService = new Ae(e, t, i), i.WebsiteService = new Te(e, t, i), i.ExperimentsService = new te(e, t, i), i.IntegrationsService = new pe(e, t, i), i.ThirdPartyCookiesService = new Ve(e, t, i), i.LocalCookiesService = new Re(e, t, i), i.LocalStoreService = new Be(e, t, i), i.RemoteConsentService = new ze(e, t, i), i.StorageService = new et(e, t, i), i.UIService = new xt(e, t, i), i.ComponentsService = new Dt(e, t, i), i.SyncService = new Ft(e, t, i), i.MixedRegulationService = new zt(e, t, i), i.CEDService = new Jt(e, t, i), i.SignatureService = new Qt(e, t, i), Y.m.value.semVersion === M.t.tcfVersion2_2 ? o.e("tcf-service-2-2").then(o.bind(o, 90643)).then((n => {
                            var {
                                default: r
                            } = n;
                            i.TCFService = new r(e, t, i), $t(i), s && s(i)
                        })) : Promise.resolve().then(o.bind(o, 39102)).then((n => {
                            var {
                                default: r
                            } = n;
                            i.TCFService = new r(e, t, i), $t(i), s && s(i)
                        }))
                    }(k.cr, k.fw, Ts)
            }, t = (0, os.pD)(), s = (0, os.dH)(), t && s ? Promise.all([as(), us()]).then(e).catch(e) : t ? as().then(e) : s ? us().then(e) : e()
        }
        if (document.body) Es();
        else var Ls = setInterval((() => {
            document.body && (clearInterval(Ls), Es())
        }), 1e3);
        var Us = Is
    }(), window.Didomi = a.default
}();